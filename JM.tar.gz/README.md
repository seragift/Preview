# 🎲 Discord Bot Ular Tangga Multiplayer

Bot Ular Tangga multiplayer (maks. 5 pemain) untuk Discord — Node.js + Discord.js v14 + Canvas.
Tidak menggunakan database, seluruh state game disimpan di memori (`GameManager`).

## 📦 Instalasi

```bash
npm install
```

## 🔐 Konfigurasi

1. Salin `.env.example` menjadi `.env`:
   ```bash
   cp .env.example .env
   ```
2. Isi nilai berikut di `.env`:
   ```
   DISCORD_TOKEN=token_bot_kamu
   CLIENT_ID=client_id_aplikasi_discord
   GUILD_ID=id_server_discord_untuk_testing
   ```

## 🚀 Menjalankan

Daftarkan slash command (sekali saja, atau setiap kali command berubah):

```bash
node deploy-commands.js
```

Jalankan bot:

```bash
node index.js
```

## 🔁 Menjalankan dengan PM2 (production)

```bash
npm install -g pm2
pm2 start index.js --name ular-tangga
pm2 save
```

Perintah PM2 berguna lainnya:

```bash
pm2 logs ular-tangga     # lihat log
pm2 restart ular-tangga  # restart bot
pm2 stop ular-tangga     # stop bot
```

## 🎮 Cara Bermain

1. Ketik `/ular-tangga` di channel untuk membuat lobby.
2. Pemain lain klik **➕ Join** (maks. 5 pemain, min. 2 untuk mulai).
3. Host klik **▶️ Start** untuk memulai game.
4. Pemain yang mendapat giliran klik **🎲 Lempar Dadu**.
5. Setiap pemain punya waktu 30 detik per giliran, jika habis giliran otomatis lanjut ke pemain berikutnya.
6. Pemain pertama yang mencapai tepat kotak 100 menang.
7. Setelah game selesai, Host bisa **🔄 Main Lagi** (ulang dengan pemain yang sama) atau **🏠 Game Baru**.

## 🗂️ Struktur Project

```
ular-tangga/
├── index.js
├── deploy-commands.js
├── package.json
├── .env.example
├── config.json
├── commands/
│   └── ular-tangga.js
├── events/
│   ├── ready.js
│   └── interactionCreate.js
├── game/
│   ├── GameManager.js
│   ├── SnakeLadderGame.js
│   ├── Board.js
│   ├── boardConfig.js
│   ├── Player.js
│   ├── Dice.js
│   └── Renderer.js
└── utils/
    └── helpers.js
```

## ⚙️ Konfigurasi Game (`config.json`)

```json
{
  "maxPlayers": 5,
  "minPlayers": 2,
  "boardSize": 10,
  "totalTiles": 100,
  "turnTimeout": 30000
}
```

Posisi ular & tangga bisa diubah di `game/boardConfig.js`.
