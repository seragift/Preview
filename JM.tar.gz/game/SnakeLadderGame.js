const { EventEmitter } = require('events');
const Player = require('./Player');
const { rollDice } = require('./Dice');
const { checkSnakeOrLadder, TOTAL_TILES } = require('./Board');
const config = require('../config.json');

class SnakeLadderGame extends EventEmitter {
  constructor(channelId, host) {
    super();
    this.channelId = channelId;
    this.hostId = host.id;
    this.players = [new Player(host.id, host.username, 0)];
    this.status = 'lobby'; // lobby | playing | finished
    this.currentTurnIndex = 0;
    this.message = null;
    this.turnTimer = null;
    this.winner = null;
    this.lastEvent = null;
  }

  addPlayer(user) {
    if (this.status !== 'lobby') throw new Error('Game sudah dimulai.');
    if (this.players.length >= config.maxPlayers) throw new Error('Lobby sudah penuh.');
    if (this.players.some((p) => p.id === user.id)) throw new Error('Kamu sudah bergabung.');
    const colorIndex = this.players.length;
    this.players.push(new Player(user.id, user.username, colorIndex));
  }

  removePlayer(userId) {
    if (this.status !== 'lobby') throw new Error('Game sudah dimulai, tidak bisa keluar.');
    const idx = this.players.findIndex((p) => p.id === userId);
    if (idx === -1) throw new Error('Kamu tidak berada di dalam lobby ini.');

    const wasHost = this.hostId === userId;
    this.players.splice(idx, 1);
    this.players.forEach((p, i) => {
      p.colorIndex = i;
    });

    if (wasHost && this.players.length > 0) {
      this.hostId = this.players[0].id;
    }
  }

  isHost(userId) {
    return this.hostId === userId;
  }

  canStart() {
    return this.status === 'lobby' && this.players.length >= config.minPlayers;
  }

  start() {
    if (!this.canStart()) throw new Error(`Minimal ${config.minPlayers} pemain untuk memulai.`);
    this.status = 'playing';
    this.currentTurnIndex = 0;
  }

  getCurrentPlayer() {
    return this.players[this.currentTurnIndex];
  }

  isPlayerTurn(userId) {
    return this.status === 'playing' && this.getCurrentPlayer().id === userId;
  }

  getPlayer(userId) {
    return this.players.find((p) => p.id === userId);
  }

  advanceTurn() {
    this.currentTurnIndex = (this.currentTurnIndex + 1) % this.players.length;
  }

  /**
   * Menjalankan satu giliran untuk pemain yang sedang aktif:
   * lempar dadu, pindahkan pion, cek ular/tangga, cek kemenangan.
   */
  playTurn() {
    const player = this.getCurrentPlayer();
    const roll = rollDice();
    const target = player.position + roll;

    let event;

    if (target > TOTAL_TILES) {
      event = { type: 'blocked', playerId: player.id, from: player.position, roll };
    } else {
      const fromPos = player.position;
      player.position = target;

      if (target === TOTAL_TILES) {
        player.finished = true;
        this.status = 'finished';
        this.winner = player;
        event = { type: 'win', playerId: player.id, from: fromPos, to: target, roll };
      } else {
        const sol = checkSnakeOrLadder(target);
        if (sol) {
          player.position = sol.to;
          event = { type: sol.type, playerId: player.id, from: sol.from, to: sol.to, roll };
        } else {
          event = { type: 'move', playerId: player.id, from: fromPos, to: target, roll };
        }
      }
    }

    this.lastEvent = event;

    if (this.status !== 'finished') {
      this.advanceTurn();
    }

    return event;
  }

  getScoreboard() {
    return [...this.players].sort((a, b) => b.position - a.position);
  }

  clearTurnTimer() {
    if (this.turnTimer) {
      clearTimeout(this.turnTimer);
      this.turnTimer = null;
    }
  }

  resetTurnTimer(callback) {
    this.clearTurnTimer();
    this.turnTimer = setTimeout(callback, config.turnTimeout);
  }

  resetForReplay() {
    this.status = 'lobby';
    this.currentTurnIndex = 0;
    this.winner = null;
    this.lastEvent = null;
    this.players.forEach((p) => {
      p.position = 0;
      p.finished = false;
    });
  }

  destroy() {
    this.clearTurnTimer();
    this.removeAllListeners();
  }
}

module.exports = SnakeLadderGame;
