# Nexsus Samp

Bot Discord untuk komunitas SA-MP/SSRP: cari **skin ID** dan **vehicle ID** lengkap dengan gambarnya langsung di Discord.

## Struktur folder

```
.
├── index.js              # entry point, hanya bootstrap
├── package.json
├── .env                  # token & prefix (dari .env.example)
└── src/
    ├── bot.js            # setup client, routing command, login
    ├── config.js         # nama bot, prefix, range ID
    ├── commands/
    │   ├── skin.js       # !skin
    │   ├── car.js        # !car
    │   └── help.js       # !help
    ├── services/
    │   ├── skinService.js     # cari skin + URL gambar (gta.com.ua)
    │   └── vehicleService.js  # cari kendaraan + resolve gambar (sampwiki API)
    ├── data/
    │   ├── skins.json         # 0-311
    │   └── vehicles.json      # 400-611
    └── utils/
        └── embeds.js     # helper embed sukses/error
```

## Command

| Command | Contoh | Keterangan |
|---|---|---|
| `!skin <id>` | `!skin 1` | Tampilkan skin berdasarkan ID (0-311) |
| `!skin <nama>` | `!skin ballas` | Cari skin berdasarkan nama model |
| `!car <id>` | `!car 500` | Tampilkan kendaraan berdasarkan ID (400-611) |
| `!car <nama>` | `!car mesa` | Cari kendaraan berdasarkan nama |
| `!help` | `!help` | Lihat daftar command |

Prefix `!` bisa diganti lewat `.env` (variabel `PREFIX`).

## Cara kerja gambar

- **Skin**: URL gambar disusun langsung dari pola situs **gta.com.ua**:
  `https://gta.com.ua/img/articles/sa/sa-mp/skins-id/skin_{id}.png`.
- **Kendaraan**: gambar di **sampwiki.blast.hk** disimpan di path yang di-hash, jadi ID saja tidak cukup untuk menyusun link-nya. Bot memanggil **MediaWiki API** milik wiki tersebut untuk mendapatkan URL asli gambar, lalu hasilnya di-cache di memori.

Data nama skin (`src/data/skins.json`) dan nama kendaraan (`src/data/vehicles.json`) sudah lengkap dan bisa diedit langsung kalau ada yang mau ditambah/diubah.

## Instalasi

1. Pastikan Node.js versi 18 ke atas sudah terpasang.
2. Install dependency:
   ```bash
   npm install
   ```
3. Salin `.env.example` menjadi `.env`, lalu isi `DISCORD_TOKEN` dengan token bot dari [Discord Developer Portal](https://discord.com/developers/applications).
4. Aktifkan **Message Content Intent** di menu Bot pada Developer Portal (wajib, karena bot membaca isi pesan untuk command prefix).
5. Jalankan bot:
   ```bash
   npm start
   ```

## Undang bot ke server

Buat invite link dari Developer Portal dengan scope `bot` dan permission minimal:
- Send Messages
- Embed Links
- Read Message History

Bot ini generik untuk server manapun bot di-invite — tidak ada guild ID yang di-hardcode di kode maupun `.env`.
