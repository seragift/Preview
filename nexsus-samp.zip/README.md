# Nexsus Samp

Bot Discord untuk komunitas SA-MP/SSRP:
- Cari **skin ID**, **vehicle ID**, dan **weapon ID** lengkap dengan gambarnya.
- **Monitoring server SA-MP** lewat IP (nama server, gamemode, jumlah pemain, dll) dengan auto-refresh.
- **Auto-responder** saat ada yang ketik kata "ip" di chat.
- **`/help`** (slash command) — penjelasan bot, cara pakai, plus tombol Donasi & Join Server.

## Struktur folder

```
.
├── index.js              # entry point: deploy slash command dulu, baru start bot
├── package.json
├── .env                  # token, client id, prefix (dari .env.example)
├── nexsus-samp.sqlite    # database (otomatis dibuat saat bot pertama kali jalan)
└── src/
    ├── bot.js            # setup client, routing command prefix & slash, auto-responder, login
    ├── config.js         # nama bot, prefix, range ID, link donasi/join server, interval monitor
    ├── deployCommands.js # reset lalu daftarkan ulang slash command (global, tanpa guild id)
    ├── commands/
    │   ├── slash/
    │   │   ├── index.js  # daftar semua slash command
    │   │   └── help.js   # /help
    │   ├── skin.js       # !skin (alias !s)
    │   ├── car.js        # !car (alias !c)
    │   ├── weapon.js     # !weapon (alias !w)
    │   ├── help.js       # !help
    │   ├── setip.js      # !setip
    │   ├── ipedit.js     # !ipedit
    │   ├── ipdell.js     # !ipdell
    │   ├── monitor.js    # !monitor
    │   ├── monitordell.js # !monitordell
    │   └── resip.js      # !resip
    ├── services/
    │   ├── skinService.js       # cari skin + URL gambar (gta.com.ua)
    │   ├── vehicleService.js    # cari kendaraan + URL gambar (data statis)
    │   ├── weaponService.js     # cari weapon + URL gambar (data statis)
    │   └── sampQueryService.js  # query UDP ke server SA-MP (info + rules)
    ├── database/
    │   ├── db.js             # koneksi SQLite + pembuatan tabel
    │   ├── serverRepo.js     # CRUD tabel servers (IP:port per guild)
    │   ├── monitorRepo.js    # CRUD tabel monitors (channel + message id)
    │   └── settingsRepo.js   # CRUD tabel resip_settings (on/off)
    ├── monitor/
    │   └── monitorManager.js # interval refresh 30 detik + restore saat restart
    ├── data/
    │   ├── skins.json         # 0-311 (nama)
    │   ├── vehicles.json      # 400-611 (nama + URL gambar asli dari sampwiki)
    │   └── weapons.json       # 0-46 (nama + URL gambar asli dari gta.com.ua)
    └── utils/
        ├── embeds.js     # helper embed sukses/error/hasil
        └── ipUtils.js    # parsing & validasi format IP:Port
```

## Command — Skin, Vehicle & Weapon

| Command | Alias | Contoh | Keterangan |
|---|---|---|---|
| `!skin <id/nama>` | `!s` | `!skin 1` / `!skin ballas` | Tampilkan skin (ID 0-311) |
| `!car <id/nama>` | `!c` | `!car 500` / `!car mesa` | Tampilkan kendaraan (ID 400-611) |
| `!weapon <id/nama>` | `!w` | `!weapon 30` / `!weapon ak47` | Tampilkan weapon (ID 0-46) |
| `!help` | - | `!help` | Lihat daftar command singkat |
| `/help` | - | `/help` | Slash command: penjelasan bot + cara pakai + tombol Donasi & Join Server |

## Command — Monitoring Server SA-MP

**1 server Discord hanya bisa punya 1 IP SA-MP.** Set IP dulu sebelum pakai `!monitor` atau `!resip`.

| Command | Contoh | Keterangan |
|---|---|---|
| `!setip <ip:port>` | `!setip 51.222.13.10:7777` | Set IP server (sekali saja, kalau sudah ada harus pakai `!ipedit`) |
| `!ipedit <ip:port baru>` | `!ipedit 51.222.13.10:7778` | Ganti IP yang sudah diset |
| `!ipdell <ip:port aktif>` | `!ipdell 51.222.13.10:7777` | Hapus IP — wajib ketik ulang IP yang sedang aktif sebagai konfirmasi |
| `!monitor #channel` | `!monitor #status-server` | Kirim embed status server & auto-refresh **tiap 30 detik** (fix, sama untuk semua server) |
| `!monitordell` | `!monitordell` | Hentikan & hapus data monitoring di server ini |
| `!resip on` / `!resip off` | `!resip on` | Aktif/nonaktifkan auto-responder IP |

### Info yang ditampilkan `!monitor`

Nama server, gamemode, bahasa, jumlah pemain, status password, serta info tambahan dari server (map, cuaca, waktu, versi) — **kecuali daftar/list pemain**, itu sengaja tidak diambil sama sekali. Semua nilai ditampilkan dalam kotak kode (```` ``` ````) biar rapi dan seragam.

### Auto-responder (`!resip`)

Kalau `!resip on` (default aktif setelah IP diset) dan ada yang mengetik kata **"ip"** (berdiri sendiri, tidak peka huruf besar/kecil — bukan bagian dari kata lain seperti "trip") di channel manapun, bot otomatis balas dengan embed berisi IP:Port server dalam kotak kode. Matikan dengan `!resip off`.

## Cara kerja query server

Bot memakai **SA-MP Query Protocol** (UDP) langsung — tanpa API pihak ketiga:
- Opcode `i` → info dasar (hostname, gamemode, bahasa, jumlah pemain, password).
- Opcode `r` → rules server (map, cuaca, waktu, versi, dll).
- Opcode `c` (daftar pemain) **sengaja tidak dipakai**, sesuai permintaan agar list pemain tidak ditampilkan.

Kalau server tidak merespons dalam beberapa detik (timeout), embed otomatis menampilkan status **offline** dan tetap dicoba lagi tiap 30 detik.

## Database

Pakai **SQLite** (`better-sqlite3`), file `nexsus-samp.sqlite` dibuat otomatis di folder project saat bot pertama kali dijalankan. Tiga tabel: `servers`, `monitors`, `resip_settings` — semuanya di-key per Discord server (guild), jadi bot ini bisa dipakai di banyak server Discord sekaligus tanpa data ketuker.

Monitoring yang aktif otomatis dipulihkan setiap kali bot di-restart, dengan cara membaca lagi `channel_id` dan `message_id` yang tersimpan di database.

**Kenapa tidak spam pesan baru tiap 30 detik?** `message_id` pesan yang sedang dipantau disimpan permanen di database (kolom `message_id` tabel `monitors`) — sama seperti IP, tidak ada yang diandalkan dari memori proses. Setiap refresh, bot ambil ulang `message_id` itu dari database lalu **edit** pesan yang sama. Pesan baru cuma dikirim kalau memang belum pernah ada, atau pesan lamanya sudah dihapus manual di channel (barulah `message_id` baru disimpan lagi ke database).

## Cara kerja gambar skin/vehicle/weapon

- **Skin**: URL gambar disusun langsung dari pola situs **gta.com.ua**:
  `https://gta.com.ua/img/articles/sa/sa-mp/skins-id/skin_{id}.png`.
- **Kendaraan**: gambar di **sampwiki.blast.hk** disimpan di path MediaWiki yang di-hash, jadi ID saja tidak cukup untuk menyusun link-nya. Karena wiki tersebut tidak mendukung pemanggilan API secara live, URL asli untuk seluruh 212 kendaraan sudah diambil sekali dari halaman wiki dan disimpan statis di `src/data/vehicles.json`.
- **Weapon**: nama file gambar tiap weapon di **gta.com.ua** tidak mengikuti ID (mis. ID 30/AK-47 → `ak47.png`), jadi URL-nya juga sudah diambil sekali dan disimpan statis di `src/data/weapons.json`.

## Footer embed

Setiap hasil `!skin` dan `!car` otomatis diberi footer **"Nexsus © `{tahun berjalan}`"**, dihitung otomatis dari tanggal sistem. Bisa diubah lewat `BRAND_NAME` di `src/config.js`.

## Instalasi

1. Pastikan Node.js versi 18 ke atas sudah terpasang.
2. Install dependency:
   ```bash
   npm install
   ```
   > `better-sqlite3` adalah native module — kalau instalasi gagal karena build tools, pastikan `python3` dan compiler C++ (mis. `build-essential` di Linux / Xcode CLT di Mac / "Desktop development with C++" di Windows) sudah terpasang.
3. Salin `.env.example` menjadi `.env`, lalu isi:
   - `DISCORD_TOKEN` — token bot dari [Discord Developer Portal](https://discord.com/developers/applications) → menu **Bot**.
   - `CLIENT_ID` — Application ID bot, ada di halaman **General Information** aplikasi yang sama (dipakai untuk deploy slash command `/help`).
4. Aktifkan **Message Content Intent** di menu Bot pada Developer Portal (wajib — bot membaca isi pesan untuk command prefix maupun auto-responder IP).
5. (Opsional) Buka `src/config.js` dan ganti `DONATE_URL` (link Saweria) serta `SUPPORT_SERVER_URL` (invite server) sesuai punyamu — ini yang muncul sebagai tombol di `/help`.
6. Jalankan bot:
   ```bash
   npm start
   ```
   Setiap kali dijalankan, bot otomatis **menghapus lalu mendaftarkan ulang** slash command (`/help`) secara global ke Discord (tanpa guild ID, jadi berlaku di semua server tempat bot di-invite) sebelum login. Slash command global butuh waktu propagasi sampai ±1 jam pertama kali muncul, tapi setelah itu langsung update.

## Undang bot ke server

Buat invite link dari Developer Portal dengan scope `bot` **dan** `applications.commands` (wajib, supaya `/help` bisa muncul), dengan permission minimal:
- Send Messages
- Embed Links
- Read Message History

Bot ini generik untuk server manapun bot di-invite — tidak ada guild ID yang di-hardcode di kode maupun `.env`.
