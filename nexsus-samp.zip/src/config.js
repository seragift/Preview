module.exports = {
  BOT_NAME: 'Nexsus Samp',
  BRAND_NAME: 'Nexsus',
  PREFIX: process.env.PREFIX || '!',
  TOKEN: process.env.DISCORD_TOKEN,
  CLIENT_ID: process.env.CLIENT_ID,

  // Link tombol di /help — tinggal ganti sesuai punyamu
  DONATE_URL: 'https://saweria.co/nexsus',
  SUPPORT_SERVER_URL: 'https://discord.gg/nexsus',

  SKIN_ID_MIN: 0,
  SKIN_ID_MAX: 311,
  SKIN_IMAGE_BASE_URL: 'https://gta.com.ua/img/articles/sa/sa-mp/skins-id',

  VEHICLE_ID_MIN: 400,
  VEHICLE_ID_MAX: 611,

  WEAPON_ID_MIN: 0,
  WEAPON_ID_MAX: 46,

  // Monitoring server SA-MP
  DB_PATH: 'nexsus-samp.sqlite',
  MONITOR_INTERVAL_MS: 30_000,
  QUERY_TIMEOUT_MS: 4000,
};
