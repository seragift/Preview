module.exports = {
  BOT_NAME: 'Nexsus Samp',
  BRAND_NAME: 'Nexsus',
  PREFIX: process.env.PREFIX || '!',
  TOKEN: process.env.DISCORD_TOKEN,

  SKIN_ID_MIN: 0,
  SKIN_ID_MAX: 311,
  SKIN_IMAGE_BASE_URL: 'https://gta.com.ua/img/articles/sa/sa-mp/skins-id',

  VEHICLE_ID_MIN: 400,
  VEHICLE_ID_MAX: 611,
  VEHICLE_WIKI_API_URL: 'https://sampwiki.blast.hk/api.php',
};
