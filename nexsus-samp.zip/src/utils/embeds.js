const { EmbedBuilder } = require('discord.js');

function errorEmbed(description) {
  return new EmbedBuilder().setColor(0xed4245).setDescription(`❌ ${description}`);
}

function resultEmbed({ color, title, imageUrl, footer }) {
  return new EmbedBuilder()
    .setColor(color)
    .setTitle(title)
    .setImage(imageUrl)
    .setFooter({ text: footer });
}

module.exports = { errorEmbed, resultEmbed };
