const { EmbedBuilder } = require('discord.js');
const { BRAND_NAME } = require('../config');

function errorEmbed(description) {
  return new EmbedBuilder().setColor(0xed4245).setDescription(`❌ ${description}`);
}

function footerText() {
  return `${BRAND_NAME} © ${new Date().getFullYear()}`;
}

function resultEmbed({ color, title, imageUrl }) {
  return new EmbedBuilder()
    .setColor(color)
    .setTitle(title)
    .setImage(imageUrl)
    .setFooter({ text: footerText() });
}

module.exports = { errorEmbed, resultEmbed, footerText };
