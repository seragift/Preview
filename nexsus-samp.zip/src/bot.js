const { Client, GatewayIntentBits, ActivityType } = require('discord.js');
const { PREFIX, BOT_NAME, TOKEN } = require('./config');
const { errorEmbed, ipAddressEmbed } = require('./utils/embeds');
const { isIpKeyword } = require('./utils/ipUtils');

require('./database/db'); // pastikan koneksi & tabel sudah siap sebelum dipakai repo manapun
const serverRepo = require('./database/serverRepo');
const settingsRepo = require('./database/settingsRepo');
const { restoreAllMonitors } = require('./monitor/monitorManager');

const handleSkin = require('./commands/skin');
const handleCar = require('./commands/car');
const handleWeapon = require('./commands/weapon');
const handleHelp = require('./commands/help');
const handleSetIp = require('./commands/setip');
const handleIpEdit = require('./commands/ipedit');
const handleIpDell = require('./commands/ipdell');
const handleMonitor = require('./commands/monitor');
const handleMonitorDell = require('./commands/monitordell');
const handleResip = require('./commands/resip');
const slashCommands = require('./commands/slash');

const slashCommandMap = new Map(slashCommands.map((cmd) => [cmd.data.name, cmd]));

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
});

client.once('clientReady', () => {
  console.log(`${BOT_NAME} online sebagai ${client.user.tag}`);
  client.user.setActivity(`${PREFIX}help | ${BOT_NAME}`, { type: ActivityType.Watching });
  restoreAllMonitors(client);
});

client.on('messageCreate', async (message) => {
  if (message.author.bot || !message.guild) return;

  if (!message.content.startsWith(PREFIX)) {
    await handleAutoResponder(message);
    return;
  }

  const args = message.content.slice(PREFIX.length).trim().split(/\s+/);
  const command = args.shift().toLowerCase();

  try {
    if (command === 'skin' || command === 's') {
      await handleSkin(message, args);
    } else if (command === 'car' || command === 'vehicle' || command === 'c') {
      await handleCar(message, args);
    } else if (command === 'weapon' || command === 'gun' || command === 'w') {
      await handleWeapon(message, args);
    } else if (command === 'help' || command === 'menu') {
      await handleHelp(message);
    } else if (command === 'setip') {
      await handleSetIp(message, args);
    } else if (command === 'ipedit') {
      await handleIpEdit(message, args);
    } else if (command === 'ipdell') {
      await handleIpDell(message, args);
    } else if (command === 'monitor') {
      await handleMonitor(message, args);
    } else if (command === 'monitordell') {
      await handleMonitorDell(message, args);
    } else if (command === 'resip') {
      await handleResip(message, args);
    }
  } catch (err) {
    console.error('Command error:', err);
    await message.reply({ embeds: [errorEmbed('Terjadi kesalahan saat memproses command.')] });
  }
});

client.on('interactionCreate', async (interaction) => {
  if (!interaction.isChatInputCommand()) return;

  const command = slashCommandMap.get(interaction.commandName);
  if (!command) return;

  try {
    await command.execute(interaction);
  } catch (err) {
    console.error('Slash command error:', err);
    const payload = { content: '❌ Terjadi kesalahan saat memproses command.', ephemeral: true };
    if (interaction.replied || interaction.deferred) {
      await interaction.followUp(payload);
    } else {
      await interaction.reply(payload);
    }
  }
});

/**
 * Auto-responder: kalau ada yang ketik kata "ip" (berdiri sendiri) di chat
 * dan !resip dalam kondisi ON, bot balas dengan embed berisi IP:Port server.
 */
async function handleAutoResponder(message) {
  const server = serverRepo.getServer(message.guildId);
  if (!server) return;
  if (!settingsRepo.isResipEnabled(message.guildId)) return;
  if (!isIpKeyword(message.content)) return;

  await message.reply({ embeds: [ipAddressEmbed(server)] });
}

client.login(TOKEN);

module.exports = client;
