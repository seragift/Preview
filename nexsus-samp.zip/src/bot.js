const { Client, GatewayIntentBits, ActivityType } = require('discord.js');
const { PREFIX, BOT_NAME, TOKEN } = require('./config');
const { errorEmbed } = require('./utils/embeds');

const handleSkin = require('./commands/skin');
const handleCar = require('./commands/car');
const handleHelp = require('./commands/help');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
});

client.once('clientReady', () => {
  console.log(`${BOT_NAME} online sebagai ${client.user.tag}`);
  client.user.setActivity(`${PREFIX}help | ${BOT_NAME}`, { type: ActivityType.Watching });
});

client.on('messageCreate', async (message) => {
  if (message.author.bot) return;
  if (!message.content.startsWith(PREFIX)) return;

  const args = message.content.slice(PREFIX.length).trim().split(/\s+/);
  const command = args.shift().toLowerCase();

  try {
    if (command === 'skin') {
      await handleSkin(message, args);
    } else if (command === 'car' || command === 'vehicle') {
      await handleCar(message, args);
    } else if (command === 'help' || command === 'menu') {
      await handleHelp(message);
    }
  } catch (err) {
    console.error('Command error:', err);
    await message.reply({ embeds: [errorEmbed('Terjadi kesalahan saat memproses command.')] });
  }
});

client.login(TOKEN);

module.exports = client;
