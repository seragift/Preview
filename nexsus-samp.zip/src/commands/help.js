const { EmbedBuilder } = require('discord.js');
const { PREFIX, BOT_NAME } = require('../config');

module.exports = async function handleHelp(message) {
  const embed = new EmbedBuilder()
    .setColor(0x5865f2)
    .setTitle(`${BOT_NAME} — Daftar Command`)
    .addFields(
      { name: `${PREFIX}skin <id/nama>`, value: `Contoh: \`${PREFIX}skin 1\` atau \`${PREFIX}skin ballas\`` },
      { name: `${PREFIX}car <id/nama>`, value: `Contoh: \`${PREFIX}car 500\` atau \`${PREFIX}car mesa\`` }
    );

  return message.reply({ embeds: [embed] });
};
