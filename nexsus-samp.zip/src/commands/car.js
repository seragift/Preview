const { PREFIX, VEHICLE_ID_MIN, VEHICLE_ID_MAX } = require('../config');
const { getVehicleImageUrl, findVehicle } = require('../services/vehicleService');
const { errorEmbed, resultEmbed } = require('../utils/embeds');

module.exports = async function handleCar(message, args) {
  const query = args.join(' ').trim();

  if (!query) {
    return message.reply({
      embeds: [
        errorEmbed(
          `Gunakan format: \`${PREFIX}car <id>\`\nContoh: \`${PREFIX}car 500\` atau \`${PREFIX}car mesa\``
        ),
      ],
    });
  }

  const vehicle = findVehicle(query);
  if (!vehicle) {
    const hint = /^\d+$/.test(query)
      ? `ID kendaraan harus antara ${VEHICLE_ID_MIN}-${VEHICLE_ID_MAX}.`
      : `Kendaraan dengan nama \`${query}\` tidak ditemukan.`;
    return message.reply({ embeds: [errorEmbed(hint)] });
  }

  const loadingMsg = await message.reply('🔎 Mengambil data kendaraan dari SA-MP Wiki...');

  try {
    const imageUrl = await getVehicleImageUrl(vehicle.id);
    const embed = resultEmbed({
      color: 0x57f287,
      title: `${vehicle.name} (ID: ${vehicle.id})`,
      imageUrl,
      footer: 'Sumber gambar: sampwiki.blast.hk',
    });

    return loadingMsg.edit({ content: null, embeds: [embed] });
  } catch (err) {
    console.error('Gagal mengambil gambar kendaraan:', err);
    return loadingMsg.edit({
      content: null,
      embeds: [errorEmbed(`Gagal mengambil gambar untuk **${vehicle.name} (ID: ${vehicle.id})** dari wiki. Coba lagi sebentar lagi.`)],
    });
  }
};
