const vehicleNames = require('../data/vehicles.json');
const { VEHICLE_ID_MIN, VEHICLE_ID_MAX, VEHICLE_WIKI_API_URL } = require('../config');

// Cache URL gambar hasil resolve dari SA-MP Wiki, supaya ID yang sama
// tidak perlu query API berulang-ulang.
const imageCache = new Map();

/**
 * Gambar kendaraan di SA-MP Wiki disimpan di path MediaWiki yang di-hash
 * (contoh: /wroot/images2/6/6c/Vehicle_500.jpg), jadi tidak bisa ditebak
 * langsung dari ID. Kita minta MediaWiki API untuk resolve URL aslinya.
 */
async function getVehicleImageUrl(id) {
  if (imageCache.has(id)) return imageCache.get(id);

  const apiUrl =
    `${VEHICLE_WIKI_API_URL}?action=query&titles=File:Vehicle_${id}.jpg&prop=imageinfo&iiprop=url&format=json`;

  const res = await fetch(apiUrl, {
    headers: { 'User-Agent': 'Nexsus-Samp-Bot/1.0' },
  });
  if (!res.ok) throw new Error(`Wiki API HTTP ${res.status}`);

  const data = await res.json();
  const pages = data?.query?.pages;
  if (!pages) throw new Error('Format respons wiki tidak dikenali');

  const page = Object.values(pages)[0];
  const url = page?.imageinfo?.[0]?.url;
  if (!url) throw new Error('Gambar tidak ditemukan di wiki');

  imageCache.set(id, url);
  return url;
}

/**
 * Mencari kendaraan berdasarkan ID numerik atau potongan nama.
 * Mengembalikan { id, name } atau null kalau tidak ketemu.
 */
function findVehicle(query) {
  if (/^\d+$/.test(query)) {
    const id = parseInt(query, 10);
    if (id < VEHICLE_ID_MIN || id > VEHICLE_ID_MAX || !(String(id) in vehicleNames)) {
      return null;
    }
    return { id, name: vehicleNames[String(id)] };
  }

  const q = query.toLowerCase();
  const match = Object.entries(vehicleNames).find(([, name]) => name.toLowerCase().includes(q));
  if (!match) return null;

  return { id: parseInt(match[0], 10), name: match[1] };
}

module.exports = { getVehicleImageUrl, findVehicle };
