'use strict';
const https = require('https');
const http = require('http');

const ALLOWED_WEBHOOK_HOSTS = ['discord.com', 'discordapp.com', 'ptb.discord.com', 'canary.discord.com'];

function isWebhookConfigured() {
  return !!process.env.DISCORD_WEBHOOK_URL;
}

// Request POST JSON generik (pilih http/https otomatis dari protokol URL) -
// dipisah dari validasi khusus Discord supaya gampang dites tanpa perlu
// webhook Discord asli.
function postJson(urlString, payload, timeoutMs = 10000) {
  return new Promise((resolve, reject) => {
    let url;
    try { url = new URL(urlString); } catch (err) { return reject(new Error('URL tidak valid.')); }
    const lib = url.protocol === 'http:' ? http : https;
    const data = JSON.stringify(payload);
    const req = lib.request(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) },
      timeout: timeoutMs,
    }, (res) => {
      let body = '';
      res.on('data', (chunk) => { body += chunk; });
      res.on('end', () => {
        if (res.statusCode >= 200 && res.statusCode < 300) resolve({ status: res.statusCode, body });
        else reject(new Error(`HTTP ${res.statusCode}: ${body.slice(0, 300)}`));
      });
    });
    req.on('error', reject);
    req.on('timeout', () => req.destroy(new Error('Timeout mengirim request.')));
    req.write(data);
    req.end();
  });
}

async function sendNotification(message, { title, color } = {}) {
  const webhookUrl = process.env.DISCORD_WEBHOOK_URL;
  if (!webhookUrl) {
    return { success: false, error: 'DISCORD_WEBHOOK_URL belum diisi di .env - notifikasi Discord tidak aktif.' };
  }

  let parsed;
  try { parsed = new URL(webhookUrl); } catch (err) { return { success: false, error: 'DISCORD_WEBHOOK_URL tidak valid.' }; }
  if (parsed.protocol !== 'https:') {
    return { success: false, error: `DISCORD_WEBHOOK_URL harus pakai https:// (dapat "${parsed.protocol}").` };
  }
  if (!ALLOWED_WEBHOOK_HOSTS.includes(parsed.hostname)) {
    return {
      success: false,
      error: `DISCORD_WEBHOOK_URL harus URL webhook Discord resmi (https://discord.com/api/webhooks/...). Host "${parsed.hostname}" tidak diizinkan.`,
    };
  }

  const payload = {
    embeds: [{
      title: title || 'SAMPAI Agent',
      description: String(message || '-').slice(0, 4000),
      color: color != null ? color : 0x5865F2,
      timestamp: new Date().toISOString(),
    }],
  };

  try {
    await postJson(webhookUrl, payload);
    return { success: true };
  } catch (err) {
    return { success: false, error: `Gagal kirim notifikasi Discord: ${err.message}` };
  }
}

const EVENT_COLORS = { online: 0x33AA33, offline: 0xAA3333, crash: 0xFF0000 };
const EVENT_TITLES = { online: '🟢 Server Online', offline: '🔴 Server Offline', crash: '⚠️ Server Crash Terdeteksi' };

// Dipakai internal oleh start_server/stop_server/restart_server - best-effort,
// TIDAK PERNAH throw supaya gagal kirim notifikasi tidak menggagalkan operasi
// server itu sendiri. Diam-diam skip kalau webhook belum dikonfigurasi.
async function notifyServerEvent(event, details = {}) {
  if (!process.env.DISCORD_WEBHOOK_URL) return { success: false, skipped: true };
  const lines = [];
  if (details.binary) lines.push(`Binary: \`${details.binary}\``);
  if (details.port) lines.push(`Port: \`${details.port}\``);
  if (details.pid) lines.push(`PID: \`${details.pid}\``);
  if (details.note) lines.push(details.note);
  return sendNotification(lines.join('\n') || '-', { title: EVENT_TITLES[event] || 'SAMPAI Agent', color: EVENT_COLORS[event] });
}

module.exports = { sendNotification, notifyServerEvent, isWebhookConfigured, postJson, ALLOWED_WEBHOOK_HOSTS };
