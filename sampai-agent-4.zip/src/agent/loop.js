'use strict';
const OpenAI = require('openai');
const { buildContext, isContinuationRequest } = require('./context');
const { buildSystemPrompt } = require('./planner');
const { toolDefinitions, executeTool } = require('../tools/index');
const tasksMem = require('../memory/tasks');
const projectMem = require('../memory/project');
const notifyTool = require('../tools/notify');

const MAX_ITERATIONS = parseInt(process.env.MAX_TOOL_ITERATIONS || '25', 10);
const MAX_ACTIVITY_LINES = 30;

// Ringkasan 1 baris per tool call buat activity log - redact password, dan
// ambil "headline" argumen paling relevan (path/command/sql/dst) biar ringkas.
function redactArgs(args) {
  const safe = { ...(args || {}) };
  for (const k of Object.keys(safe)) {
    if (/password/i.test(k)) safe[k] = '[REDACTED]';
  }
  return safe;
}

function summarizeToolCall(name, args, result) {
  const safeArgs = redactArgs(args);
  const headlineKeys = ['path', 'command', 'sql', 'database_name', 'install_dir', 'binary', 'download_url', 'message', 'title'];
  let headline = '';
  for (const k of headlineKeys) {
    if (safeArgs[k] !== undefined && safeArgs[k] !== null && safeArgs[k] !== '') {
      headline = String(safeArgs[k]);
      break;
    }
  }
  if (headline.length > 80) headline = headline.slice(0, 80) + '…';
  const status = result && typeof result.success === 'boolean' ? (result.success ? '✅' : '❌') : '•';
  const extra = result && result.error ? ` — ${String(result.error).slice(0, 120)}` : '';
  return `${status} \`${name}\`${headline ? ' `' + headline + '`' : ''}${extra}`;
}

function createLoop({ workspace, memoryDir, logger }) {
  const client = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY,
    baseURL: process.env.OPENAI_BASE_URL,
  });
  const model = process.env.OPENAI_MODEL;

  async function runAgent(userMessage) {
    const { summaryText, lastTask } = buildContext(memoryDir);
    logger.agent({ event: 'request', message: userMessage });

    // Continuation heuristic: kalau user minta "lanjutkan" dan ada task yang belum kelar,
    // pakai task_id itu sebagai default supaya tool call otomatis nyambung ke task yang sama.
    let taskId = null;
    if (isContinuationRequest(userMessage) && lastTask && !['completed', 'verified'].includes(lastTask.status)) {
      taskId = lastTask.id;
    }

    const systemPrompt = buildSystemPrompt(summaryText, workspace);
    const messages = [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: userMessage },
    ];

    const ctx = { workspace, memoryDir, taskId, logger };
    let iterations = 0;
    let finalText = '';
    const activityLog = [];

    while (iterations < MAX_ITERATIONS) {
      iterations += 1;
      let response;
      try {
        response = await client.chat.completions.create({
          model,
          messages,
          tools: toolDefinitions,
          tool_choice: 'auto',
        });
      } catch (err) {
        logger.error({ event: 'api_error', message: err.message });
        return `Terjadi error saat memanggil API model (${process.env.OPENAI_BASE_URL}): ${err.message}`;
      }

      const choice = response.choices && response.choices[0];
      if (!choice) {
        logger.error({ event: 'api_error', message: 'Response tanpa choices.' });
        return 'Model tidak mengembalikan response yang valid.';
      }
      const msg = choice.message;
      messages.push(msg);

      if (!msg.tool_calls || msg.tool_calls.length === 0) {
        finalText = msg.content || '';
        break;
      }

      for (const call of msg.tool_calls) {
        let args = {};
        try { args = JSON.parse(call.function.arguments || '{}'); } catch (_) { /* biarkan args = {} */ }

        const result = await executeTool(call.function.name, args, ctx);
        activityLog.push(summarizeToolCall(call.function.name, args, result));

        if (call.function.name === 'create_task' && result && result.id) {
          taskId = result.id;
          ctx.taskId = taskId;
        }

        messages.push({
          role: 'tool',
          tool_call_id: call.id,
          content: JSON.stringify(result).slice(0, 8000),
        });
      }
    }

    if (iterations >= MAX_ITERATIONS && !finalText) {
      finalText = 'Task belum selesai: batas maksimum iterasi tool tercapai (MAX_TOOL_ITERATIONS). Ketik "lanjutkan" untuk melanjutkan dari state terakhir.';
      if (taskId) {
        await tasksMem.updateStatus(memoryDir, taskId, 'blocked', { note: 'Max tool iterations reached' }).catch(() => {});
      }
    }

    await projectMem.patch(memoryDir, { current_state: { last_action: userMessage.slice(0, 200) } }).catch(() => {});

    // Kirim SATU ringkasan aktivitas per request (bukan per tool call) - supaya tidak
    // kena rate limit Discord webhook kalau satu task butuh banyak tool call.
    if (activityLog.length && process.env.DISCORD_WEBHOOK_URL && process.env.DISCORD_ACTIVITY_LOG !== 'false') {
      const shown = activityLog.slice(0, MAX_ACTIVITY_LINES);
      const extraCount = activityLog.length - shown.length;
      const body = shown.join('\n') + (extraCount > 0 ? `\n…+${extraCount} aksi lainnya` : '');
      notifyTool.sendNotification(body, { title: `📋 ${userMessage.slice(0, 80)}`, color: 0x99AAB5 }).catch(() => {});
    }

    logger.agent({ event: 'response', iterations, taskId, length: finalText.length });
    return finalText;
  }

  return { runAgent };
}

module.exports = { createLoop };
