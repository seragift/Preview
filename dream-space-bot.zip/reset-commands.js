require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { REST, Routes } = require('discord.js');

const rest = new REST().setToken(process.env.DISCORD_TOKEN);
const clientId = process.env.CLIENT_ID;
const guildId = process.env.GUILD_ID;

// Ambil semua command dari src/commands untuk didaftarkan ulang
const commands = [];
const commandsPath = path.join(__dirname, 'src', 'commands');
for (const file of fs.readdirSync(commandsPath).filter((f) => f.endsWith('.js'))) {
  const command = require(path.join(commandsPath, file));
  commands.push(command.data.toJSON());
}

(async () => {
  try {
    console.log('🗑️  Menghapus semua command lama di server (guild)...');
    await rest.put(Routes.applicationGuildCommands(clientId, guildId), { body: [] });
    console.log('✅ Command guild lama berhasil dihapus.');

    console.log('🗑️  Menghapus semua command lama global (kalau ada)...');
    await rest.put(Routes.applicationCommands(clientId), { body: [] });
    console.log('✅ Command global lama berhasil dihapus.');

    console.log(`🚀 Mendaftarkan ${commands.length} command baru ke server...`);
    await rest.put(Routes.applicationGuildCommands(clientId, guildId), { body: commands });
    console.log('✅ Command baru berhasil didaftarkan. Selesai!');
  } catch (err) {
    console.error('❌ Gagal reset command:', err);
  }
})();
