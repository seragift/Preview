# Dream Space Bot

Bot Discord untuk store dengan fitur status toko, payment, testimoni, ticket panel, dan garansi.

## Instalasi

1. Install dependencies:
   ```
   npm install
   ```

2. Isi file `.env`:
   ```
   DISCORD_TOKEN=token_bot_kamu
   CLIENT_ID=client_id_bot
   GUILD_ID=id_server_discord
   ```

3. Isi `config.json` sesuai server kamu:
   - `roles.admin` → role ID yang boleh pakai command admin (set status, kirim panel, kelola garansi, addcust)
   - `roles.customer` → role ID yang diberikan lewat `/addcust`
   - `channels.ticketPanel` → channel default untuk panel ticket (`/order`)
   - `channels.testimoni` → channel tempat testimoni otomatis diposting
   - `channels.log` → channel log (ticket dibuat/ditutup, garansi expired)
   - `channels.transcript` → channel tempat transkrip chat ticket dikirim saat ditutup
   - `channels.statusAnnounce` → channel tempat pengumuman `/status` (open/close) dikirim
   - `categories.order` / `categories.askreward` / `categories.garansi` → category ID tempat channel ticket dibuat
   - `payment` → daftar metode pembayaran (nama, detail, gambar QRIS)
   - `garansi.defaultRoleId` → role default yang dipakai `/garansi add` kalau tidak pilih role manual

4. Daftarkan slash command ke server:
   ```
   npm run deploy
   ```

   Kalau ada command lama yang nyangkut/duplikat (misal habis ganti nama command atau pernah daftar ke global), hapus dulu semua command lama baru daftar ulang:
   ```
   npm run reset-commands
   ```

5. Jalankan bot:
   ```
   npm start
   ```

## Daftar Command

- `/status kondisi:<open|close>` — admin only. Update status toko dan **kirim pengumuman embed** ke channel `channels.statusAnnounce` (bukan reply biasa). Kalau `status_custom.tag` diisi lewat `/editstatus`, role tersebut otomatis di-ping saat pengumuman dikirim.
- `/payment` — tampilkan metode pembayaran dengan tombol
- `/testimoni bukti:<attachment> seller:<user>` — kirim testimoni (form detail muncul via modal)
- `/order [channel]` — kirim panel ticket Dream Space ke channel (admin)
- `/garansi add user:<user> durasi:<1h/1d/1w/1m/1y> [role]` — beri garansi ke user (admin)
- `/garansi remove user:<user>` — hapus garansi user (admin)
- `/garansi check user:<user>` — cek status garansi user
- `/addcust user:<user>` — beri role customer ke user (admin)
- `/editstatus [title] [deskripsi] [tag] [image]` — edit tampilan embed `/status` (admin, semua opsi opsional, isi minimal 1). `tag` adalah **role** (misal @everyone atau role Member) yang akan di-ping otomatis setiap kali `/status set` dipakai.

## Catatan

- Database SQLite otomatis dibuat di `database/store.db` saat bot pertama kali jalan.
- Status garansi dicek otomatis setiap 5 menit; kalau sudah kadaluarsa, role dicopot otomatis dan dicatat di channel log.
- Status garansi user otomatis muncul di embed testimoni (ambil dari data `/garansi`), jadi user tidak perlu isi manual.
- Setiap ticket dibuat dan ditutup akan tercatat di `channels.log`.
- Saat ticket ditutup, bot otomatis membuat **transkrip** (file `.txt` berisi seluruh chat) dan mengirimkannya ke `channels.transcript` sebelum channel dihapus.

## Troubleshooting: Command Dobel Respon

Kalau semua command jawab dua kali (dua embed/pesan muncul), penyebab paling umum adalah **ada 2 proses bot yang jalan bersamaan** dengan token yang sama — bukan bug di command itu sendiri. Cek:

1. Pastikan tidak ada proses `node index.js` lama yang masih jalan di background.
   - Kalau pakai panel (Pterodactyl/PM2/screen), stop semua instance dulu sebelum start baru.
   - Di VPS biasa, cek dengan `ps aux | grep node` lalu `kill` proses lama yang duplikat.
2. Kalau pakai `nodemon` untuk auto-restart, pastikan proses lama benar-benar mati sebelum yang baru jalan (jangan restart manual sambil proses lama masih hidup).
3. Pastikan bot cuma login sekali — jangan jalankan `npm start` di dua terminal/tab berbeda secara bersamaan.
4. Kalau masih dobel setelah dipastikan cuma 1 proses, jalankan `npm run reset-commands` untuk bersihkan command yang mungkin ke-duplikat di Discord.
