const { startWarrantyScheduler } = require('../handlers/warrantyScheduler');

module.exports = {
  name: 'ready',
  once: true,
  execute(client) {
    console.log(`✅ Logged in as ${client.user.tag}`);
    startWarrantyScheduler(client);
  },
};
