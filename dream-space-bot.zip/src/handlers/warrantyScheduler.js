const cron = require('node-cron');
const db = require('../utils/database');
const { loadConfig } = require('../utils/config');

function startWarrantyScheduler(client) {
  // Cek setiap 5 menit
  cron.schedule('*/5 * * * *', async () => {
    const now = Date.now();
    const expired = db.prepare(`SELECT * FROM warranties WHERE active = 1 AND expires_at <= ?`).all(now);

    for (const w of expired) {
      try {
        const config = loadConfig();
        const guild = client.guilds.cache.get(config.guildId);
        if (!guild) continue;

        const member = await guild.members.fetch(w.user_id).catch(() => null);
        if (member) await member.roles.remove(w.role_id).catch(() => {});

        db.prepare(`UPDATE warranties SET active = 0 WHERE id = ?`).run(w.id);

        const logChannel = guild.channels.cache.get(config.channels.log);
        if (logChannel) {
          logChannel
            .send(`⏰ Garansi <@${w.user_id}> telah berakhir, role dicopot otomatis.`)
            .catch(() => {});
        }
      } catch (err) {
        console.error('Warranty scheduler error:', err);
      }
    }
  });

  console.log('⏰ Warranty scheduler berjalan setiap 5 menit.');
}

module.exports = { startWarrantyScheduler };
