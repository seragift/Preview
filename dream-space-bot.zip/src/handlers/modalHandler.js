const db = require('../utils/database');
const { testimoniEmbed } = require('../utils/embeds');
const { loadConfig } = require('../utils/config');

async function handleModal(interaction) {
  if (!interaction.customId.startsWith('testimoni_modal_')) return;

  const sellerId = interaction.customId.replace('testimoni_modal_', '');
  const buktiUrl = interaction.client.pendingTestimoni?.get(interaction.user.id);

  const barang = interaction.fields.getTextInputValue('barang');
  const harga = interaction.fields.getTextInputValue('harga');
  const jumlah = interaction.fields.getTextInputValue('jumlah');
  const ratingRaw = interaction.fields.getTextInputValue('rating');
  const note = interaction.fields.getTextInputValue('note') || '-';

  const rating = Math.max(1, Math.min(5, parseInt(ratingRaw, 10) || 1));

  // Ambil status garansi otomatis dari data /garansi, biar user gak perlu isi manual
  const warranty = db
    .prepare(`SELECT * FROM warranties WHERE user_id = ? AND active = 1 ORDER BY expires_at DESC LIMIT 1`)
    .get(interaction.user.id);

  const garansi =
    warranty && warranty.expires_at > Date.now()
      ? `Aktif s.d <t:${Math.floor(warranty.expires_at / 1000)}:d>`
      : 'No Garansi';

  db.prepare(
    `INSERT INTO testimonials (user_id, seller_id, barang, harga, jumlah, garansi, rating, note, bukti_url, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(interaction.user.id, sellerId, barang, harga, jumlah, garansi, rating, note, buktiUrl || null, Date.now());

  const embed = testimoniEmbed({
    userId: interaction.user.id,
    sellerId,
    barang,
    harga,
    jumlah,
    garansi,
    rating,
    note,
    buktiUrl,
  });

  const config = loadConfig();
  const testimoniChannel = interaction.guild.channels.cache.get(config.channels.testimoni);

  if (testimoniChannel) {
    await testimoniChannel.send({ embeds: [embed] });
    await interaction.reply({ content: 'Terima kasih atas testimonimu! ✅', ephemeral: true });
  } else {
    await interaction.reply({
      content: 'Testimoni tersimpan, tapi channel testimoni belum diatur di config.json.',
      ephemeral: true,
    });
  }

  interaction.client.pendingTestimoni?.delete(interaction.user.id);
}

module.exports = { handleModal };
