const db = require('../utils/database');

function ensureRow() {
  const row = db.prepare('SELECT * FROM shop_status WHERE id = 1').get();
  if (!row) {
    db.prepare('INSERT INTO shop_status (id, status, updated_by, updated_at) VALUES (1, ?, NULL, ?)').run(
      'close',
      Date.now()
    );
  }
}

function getStatus() {
  ensureRow();
  return db.prepare('SELECT * FROM shop_status WHERE id = 1').get();
}

function setStatus(status, userId) {
  ensureRow();
  db.prepare('UPDATE shop_status SET status = ?, updated_by = ?, updated_at = ? WHERE id = 1').run(
    status,
    userId,
    Date.now()
  );
}

// Ambil tampilan custom (title, deskripsi, tag role, image) sesuai kondisi (open/close) dari config.json
function getCustomFromConfig(config, kondisi) {
  const status = (config.status && config.status[kondisi]) || {};
  return {
    title: status.title || null,
    description: status.description || null,
    tag: status.tagRoleId || null,
    image_url: status.image || null,
  };
}

module.exports = { getStatus, setStatus, getCustomFromConfig };
