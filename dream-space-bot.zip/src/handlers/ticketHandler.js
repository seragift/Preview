const {
  ChannelType,
  PermissionFlagsBits,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  AttachmentBuilder,
} = require('discord.js');
const { loadConfig } = require('../utils/config');
const db = require('../utils/database');
const {
  ticketWelcomeEmbed,
  ticketCreateLogEmbed,
  ticketCloseLogEmbed,
  successEmbed,
  errorEmbed,
  infoEmbed,
} = require('../utils/embeds');
const { generateTranscript } = require('../utils/transcript');

async function createTicket(interaction, type) {
  const config = loadConfig();
  const guild = interaction.guild;
  const categoryId = config.categories[type];

  const existing = db
    .prepare(`SELECT * FROM tickets WHERE user_id = ? AND category = ? AND status = 'open'`)
    .get(interaction.user.id, type);

  if (existing) {
    return interaction.reply({
      embeds: [errorEmbed(`Kamu sudah punya ticket aktif: <#${existing.channel_id}>`)],
      ephemeral: true,
    });
  }

  const channel = await guild.channels.create({
    name: `${type}-${interaction.user.username}`.toLowerCase().slice(0, 90),
    type: ChannelType.GuildText,
    parent: categoryId || null,
    permissionOverwrites: [
      { id: guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
      {
        id: interaction.user.id,
        allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.AttachFiles],
      },
      ...(config.roles.admin
        ? [
            {
              id: config.roles.admin,
              allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.AttachFiles],
            },
          ]
        : []),
    ],
  });

  db.prepare(
    `INSERT INTO tickets (channel_id, user_id, category, status, created_at) VALUES (?, ?, ?, 'open', ?)`
  ).run(channel.id, interaction.user.id, type, Date.now());

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`ticket_claim_${channel.id}`)
      .setLabel('Klaim')
      .setStyle(ButtonStyle.Primary)
      .setEmoji('🙋'),
    new ButtonBuilder()
      .setCustomId(`ticket_close_${channel.id}`)
      .setLabel('Close Ticket')
      .setStyle(ButtonStyle.Danger)
      .setEmoji('🔒')
  );

  // Pesan publik di dalam channel ticket - tetap terlihat oleh user & admin yang ada akses
  await channel.send({
    content: `${config.roles.admin ? `<@&${config.roles.admin}> ` : ''}<@${interaction.user.id}>`,
    embeds: [ticketWelcomeEmbed(type, interaction.user)],
    components: [row],
  });

  const logChannel = guild.channels.cache.get(config.channels.log);
  if (logChannel) {
    logChannel.send({ embeds: [ticketCreateLogEmbed(type, interaction.user, channel)] }).catch(() => {});
  }

  await interaction.reply({
    embeds: [successEmbed(`Ticket berhasil dibuat: ${channel}`)],
    ephemeral: true,
  });
}

async function claimTicket(interaction, channelId) {
  const config = loadConfig();
  if (config.roles.admin && !interaction.member.roles.cache.has(config.roles.admin)) {
    return interaction.reply({
      embeds: [errorEmbed('Hanya admin yang bisa klaim ticket ini.')],
      ephemeral: true,
    });
  }

  db.prepare(`UPDATE tickets SET claimed_by = ? WHERE channel_id = ?`).run(interaction.user.id, channelId);

  // Info klaim ini relevan untuk semua yang ada di ticket, jadi tetap publik (bukan ephemeral)
  await interaction.reply({ embeds: [infoEmbed(`Ticket diklaim oleh <@${interaction.user.id}>`)] });
}

async function closeTicket(interaction, channelId) {
  const config = loadConfig();
  if (config.roles.admin && !interaction.member.roles.cache.has(config.roles.admin)) {
    return interaction.reply({
      embeds: [errorEmbed('Hanya admin yang bisa menutup ticket ini.')],
      ephemeral: true,
    });
  }

  const ticket = db.prepare(`SELECT * FROM tickets WHERE channel_id = ?`).get(channelId);

  await interaction.reply({ embeds: [infoEmbed('Membuat transkrip dan menutup ticket dalam 5 detik...')] });

  try {
    const transcriptText = await generateTranscript(interaction.channel);
    const attachment = new AttachmentBuilder(Buffer.from(transcriptText, 'utf-8'), {
      name: `transcript-${interaction.channel.name}.txt`,
    });

    const transcriptChannel = interaction.guild.channels.cache.get(config.channels.transcript);
    if (transcriptChannel && ticket) {
      await transcriptChannel
        .send({
          embeds: [
            ticketCloseLogEmbed({
              type: ticket.category,
              userId: ticket.user_id,
              channelName: interaction.channel.name,
              closedBy: interaction.user.id,
              claimedBy: ticket.claimed_by,
              createdAt: ticket.created_at,
            }),
          ],
          files: [attachment],
        })
        .catch(() => {});
    }

    const logChannel = interaction.guild.channels.cache.get(config.channels.log);
    if (logChannel && ticket) {
      logChannel
        .send({
          embeds: [
            ticketCloseLogEmbed({
              type: ticket.category,
              userId: ticket.user_id,
              channelName: interaction.channel.name,
              closedBy: interaction.user.id,
              claimedBy: ticket.claimed_by,
              createdAt: ticket.created_at,
            }),
          ],
        })
        .catch(() => {});
    }
  } catch (err) {
    console.error('Gagal membuat transkrip ticket:', err);
  }

  db.prepare(`UPDATE tickets SET status = 'closed', closed_at = ? WHERE channel_id = ?`).run(Date.now(), channelId);

  setTimeout(() => {
    interaction.channel.delete().catch(() => {});
  }, 5000);
}

module.exports = { createTicket, claimTicket, closeTicket };
