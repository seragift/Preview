const { createTicket, claimTicket, closeTicket } = require('./ticketHandler');
const { loadConfig } = require('../utils/config');
const { paymentDetailEmbed, errorEmbed } = require('../utils/embeds');

async function handleButton(interaction) {
  const id = interaction.customId;

  if (id === 'ticket_order') return createTicket(interaction, 'order');
  if (id === 'ticket_askreward') return createTicket(interaction, 'askreward');
  if (id === 'ticket_garansi') return createTicket(interaction, 'garansi');

  if (id.startsWith('ticket_claim_')) return claimTicket(interaction, id.replace('ticket_claim_', ''));
  if (id.startsWith('ticket_close_')) return closeTicket(interaction, id.replace('ticket_close_', ''));

  if (id.startsWith('payment_')) {
    const index = parseInt(id.replace('payment_', ''), 10);
    const config = loadConfig();
    const method = config.payment[index];

    if (!method) {
      return interaction.reply({ embeds: [errorEmbed('Metode pembayaran tidak ditemukan.')], ephemeral: true });
    }

    return interaction.reply({ embeds: [paymentDetailEmbed(method)], ephemeral: true });
  }
}

module.exports = { handleButton };
