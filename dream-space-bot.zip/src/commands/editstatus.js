const { SlashCommandBuilder } = require('discord.js');
const db = require('../utils/database');
const { loadConfig } = require('../utils/config');
const { statusEmbed } = require('../utils/embeds');

function ensureCustomRow() {
  const row = db.prepare('SELECT * FROM status_custom WHERE id = 1').get();
  if (!row) {
    db.prepare('INSERT INTO status_custom (id, title, description, tag, image_url) VALUES (1, NULL, NULL, NULL, NULL)').run();
  }
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('editstatus')
    .setDescription('Edit tampilan embed /status (admin only)')
    .addStringOption((opt) => opt.setName('title').setDescription('Judul embed status').setRequired(false))
    .addStringOption((opt) => opt.setName('deskripsi').setDescription('Deskripsi embed status').setRequired(false))
    .addRoleOption((opt) =>
      opt.setName('tag').setDescription('Role yang di-tag saat status diupdate (misal @everyone)').setRequired(false)
    )
    .addAttachmentOption((opt) =>
      opt.setName('image').setDescription('Gambar untuk embed status').setRequired(false)
    ),

  async execute(interaction) {
    const config = loadConfig();
    if (config.roles.admin && !interaction.member.roles.cache.has(config.roles.admin)) {
      return interaction.reply({ content: 'Kamu tidak punya izin untuk mengubah tampilan status.', ephemeral: true });
    }

    const title = interaction.options.getString('title');
    const deskripsi = interaction.options.getString('deskripsi');
    const tagRole = interaction.options.getRole('tag');
    const image = interaction.options.getAttachment('image');
    const tag = tagRole ? tagRole.id : null;

    if (!title && !deskripsi && !tag && !image) {
      return interaction.reply({
        content: 'Isi minimal salah satu opsi: title, deskripsi, tag, atau image.',
        ephemeral: true,
      });
    }

    ensureCustomRow();

    db.prepare(
      `UPDATE status_custom SET
        title = COALESCE(?, title),
        description = COALESCE(?, description),
        tag = COALESCE(?, tag),
        image_url = COALESCE(?, image_url)
      WHERE id = 1`
    ).run(title, deskripsi, tag, image ? image.url : null);

    const custom = db.prepare('SELECT * FROM status_custom WHERE id = 1').get();
    const shopRow = db.prepare('SELECT * FROM shop_status WHERE id = 1').get() || { status: 'close' };

    await interaction.reply({
      content: 'Tampilan embed status berhasil diperbarui. Preview:',
      embeds: [statusEmbed(shopRow.status, shopRow.updated_by, shopRow.updated_at, custom)],
    });
  },
};
