const { SlashCommandBuilder } = require('discord.js');
const db = require('../utils/database');
const { parseDuration, formatDuration } = require('../utils/duration');
const { loadConfig } = require('../utils/config');
const { successEmbed, errorEmbed, infoEmbed } = require('../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('garansi')
    .setDescription('Kelola garansi user')
    .addSubcommand((sub) =>
      sub
        .setName('add')
        .setDescription('Tambahkan garansi ke user')
        .addUserOption((opt) => opt.setName('user').setDescription('User yang diberi garansi').setRequired(true))
        .addStringOption((opt) =>
          opt.setName('durasi').setDescription('Contoh: 1h, 1d, 1w, 1m, 1y').setRequired(true)
        )
        .addRoleOption((opt) =>
          opt.setName('role').setDescription('Role garansi (default dari config.json)').setRequired(false)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName('remove')
        .setDescription('Hapus garansi user')
        .addUserOption((opt) => opt.setName('user').setDescription('User').setRequired(true))
    )
    .addSubcommand((sub) =>
      sub
        .setName('check')
        .setDescription('Cek status garansi user')
        .addUserOption((opt) => opt.setName('user').setDescription('User').setRequired(true))
    ),

  async execute(interaction) {
    const config = loadConfig();
    if (config.roles.admin && !interaction.member.roles.cache.has(config.roles.admin)) {
      return interaction.reply({
        embeds: [errorEmbed('Kamu tidak punya izin untuk mengelola garansi.')],
        ephemeral: true,
      });
    }

    const sub = interaction.options.getSubcommand();
    const user = interaction.options.getUser('user');

    if (sub === 'add') {
      const durasi = interaction.options.getString('durasi');
      const role = interaction.options.getRole('role');
      const roleId = role ? role.id : config.garansi.defaultRoleId;

      if (!roleId || roleId.startsWith('ISI_')) {
        return interaction.reply({
          embeds: [errorEmbed('Role garansi belum diatur di config.json.')],
          ephemeral: true,
        });
      }

      const ms = parseDuration(durasi);
      if (!ms) {
        return interaction.reply({
          embeds: [errorEmbed('Format durasi salah. Gunakan contoh: 1h, 1d, 1w, 1m, 1y')],
          ephemeral: true,
        });
      }

      const member = await interaction.guild.members.fetch(user.id);
      await member.roles.add(roleId).catch(() => {});

      const now = Date.now();
      const expiresAt = now + ms;

      db.prepare(`UPDATE warranties SET active = 0 WHERE user_id = ? AND role_id = ? AND active = 1`).run(
        user.id,
        roleId
      );
      db.prepare(
        `INSERT INTO warranties (user_id, role_id, started_at, expires_at, active) VALUES (?, ?, ?, ?, 1)`
      ).run(user.id, roleId, now, expiresAt);

      return interaction.reply({
        embeds: [
          successEmbed(
            `Garansi untuk <@${user.id}> aktif selama ${formatDuration(ms)}, berakhir <t:${Math.floor(
              expiresAt / 1000
            )}:F>`
          ),
        ],
        ephemeral: true,
      });
    }

    if (sub === 'remove') {
      const warranty = db
        .prepare(`SELECT * FROM warranties WHERE user_id = ? AND active = 1 ORDER BY expires_at DESC LIMIT 1`)
        .get(user.id);

      if (!warranty) {
        return interaction.reply({
          embeds: [errorEmbed('User tidak memiliki garansi aktif.')],
          ephemeral: true,
        });
      }

      const member = await interaction.guild.members.fetch(user.id);
      await member.roles.remove(warranty.role_id).catch(() => {});
      db.prepare(`UPDATE warranties SET active = 0 WHERE id = ?`).run(warranty.id);

      return interaction.reply({
        embeds: [successEmbed(`Garansi <@${user.id}> berhasil dihapus.`)],
        ephemeral: true,
      });
    }

    if (sub === 'check') {
      const warranty = db
        .prepare(`SELECT * FROM warranties WHERE user_id = ? AND active = 1 ORDER BY expires_at DESC LIMIT 1`)
        .get(user.id);

      if (!warranty || warranty.expires_at < Date.now()) {
        return interaction.reply({
          embeds: [infoEmbed(`<@${user.id}> tidak memiliki garansi aktif.`)],
          ephemeral: true,
        });
      }

      return interaction.reply({
        embeds: [
          infoEmbed(`<@${user.id}> memiliki garansi aktif hingga <t:${Math.floor(warranty.expires_at / 1000)}:F>`),
        ],
        ephemeral: true,
      });
    }
  },
};
