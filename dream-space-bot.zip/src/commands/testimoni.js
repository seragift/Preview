const { SlashCommandBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('testimoni')
    .setDescription('Kirim testimoni transaksi kamu')
    .addAttachmentOption((opt) =>
      opt.setName('bukti').setDescription('Screenshot bukti transaksi').setRequired(true)
    )
    .addUserOption((opt) =>
      opt.setName('seller').setDescription('Seller/admin yang melayani transaksi').setRequired(true)
    ),

  async execute(interaction) {
    const bukti = interaction.options.getAttachment('bukti');
    const seller = interaction.options.getUser('seller');

    // Simpan sementara URL attachment karena modal tidak mendukung field attachment
    if (!interaction.client.pendingTestimoni) interaction.client.pendingTestimoni = new Map();
    interaction.client.pendingTestimoni.set(interaction.user.id, bukti.url);

    const modal = new ModalBuilder().setCustomId(`testimoni_modal_${seller.id}`).setTitle('Form Testimoni');

    const barang = new TextInputBuilder()
      .setCustomId('barang')
      .setLabel('Nama Produk')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    const harga = new TextInputBuilder()
      .setCustomId('harga')
      .setLabel('Harga')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    const jumlah = new TextInputBuilder()
      .setCustomId('jumlah')
      .setLabel('Jumlah')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    const rating = new TextInputBuilder()
      .setCustomId('rating')
      .setLabel('Rating (isi angka 1-5)')
      .setStyle(TextInputStyle.Short)
      .setRequired(true)
      .setMaxLength(1);

    const note = new TextInputBuilder()
      .setCustomId('note')
      .setLabel('Catatan (opsional)')
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(false);

    modal.addComponents(
      new ActionRowBuilder().addComponents(barang),
      new ActionRowBuilder().addComponents(harga),
      new ActionRowBuilder().addComponents(jumlah),
      new ActionRowBuilder().addComponents(rating),
      new ActionRowBuilder().addComponents(note)
    );

    await interaction.showModal(modal);
  },
};
