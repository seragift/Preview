const { SlashCommandBuilder } = require('discord.js');
const { loadConfig } = require('../utils/config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('addcust')
    .setDescription('Tambahkan role customer ke user (admin only)')
    .addUserOption((opt) => opt.setName('user').setDescription('User yang jadi customer').setRequired(true)),

  async execute(interaction) {
    const config = loadConfig();
    if (config.roles.admin && !interaction.member.roles.cache.has(config.roles.admin)) {
      return interaction.reply({ content: 'Kamu tidak punya izin untuk menjalankan command ini.', ephemeral: true });
    }

    if (!config.roles.customer || config.roles.customer.startsWith('ISI_')) {
      return interaction.reply({ content: 'Role customer belum diatur di config.json.', ephemeral: true });
    }

    const user = interaction.options.getUser('user');
    const member = await interaction.guild.members.fetch(user.id);
    await member.roles.add(config.roles.customer);

    return interaction.reply({ content: `<@${user.id}> berhasil ditambahkan sebagai customer.` });
  },
};
