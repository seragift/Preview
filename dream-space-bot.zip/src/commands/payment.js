const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { paymentEmbed } = require('../utils/embeds');
const { loadConfig } = require('../utils/config');

// Cycling warna: Primary = biru, Success = hijau, Danger = merah
const COLOR_CYCLE = [ButtonStyle.Primary, ButtonStyle.Success, ButtonStyle.Danger];

module.exports = {
  data: new SlashCommandBuilder().setName('payment').setDescription('Lihat metode pembayaran yang tersedia'),

  async execute(interaction) {
    const config = loadConfig();
    const row = new ActionRowBuilder();

    config.payment.slice(0, 5).forEach((method, index) => {
      row.addComponents(
        new ButtonBuilder()
          .setCustomId(`payment_${index}`)
          .setLabel(method.name)
          .setStyle(COLOR_CYCLE[index % COLOR_CYCLE.length])
      );
    });

    await interaction.reply({ embeds: [paymentEmbed()], components: [row] });
  },
};
