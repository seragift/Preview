const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType } = require('discord.js');
const { ticketPanelEmbed, successEmbed, errorEmbed } = require('../utils/embeds');
const { loadConfig } = require('../utils/config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('order')
    .setDescription('Kirim panel ticket ke channel tertentu (admin only)')
    .addChannelOption((opt) =>
      opt
        .setName('channel')
        .setDescription('Channel tujuan panel (default: channel dari config.json)')
        .addChannelTypes(ChannelType.GuildText)
        .setRequired(false)
    ),

  async execute(interaction) {
    const config = loadConfig();
    if (config.roles.admin && !interaction.member.roles.cache.has(config.roles.admin)) {
      return interaction.reply({
        embeds: [errorEmbed('Kamu tidak punya izin untuk mengirim panel ticket.')],
        ephemeral: true,
      });
    }

    const targetChannel =
      interaction.options.getChannel('channel') || interaction.guild.channels.cache.get(config.channels.ticketPanel);

    if (!targetChannel) {
      return interaction.reply({
        embeds: [
          errorEmbed(
            'Channel tujuan tidak ditemukan. Set "channels.ticketPanel" di config.json atau pilih channel manual.'
          ),
        ],
        ephemeral: true,
      });
    }

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('ticket_order').setLabel('Order').setEmoji('🛒').setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId('ticket_askreward')
        .setLabel('Ask/Reward')
        .setEmoji('🎉')
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId('ticket_garansi')
        .setLabel('Claim Garansi')
        .setEmoji('✅')
        .setStyle(ButtonStyle.Primary)
    );

    // Panel ini pesan publik ke channel tujuan, bukan reply command - tetap terlihat semua orang
    await targetChannel.send({ embeds: [ticketPanelEmbed()], components: [row] });

    await interaction.reply({
      embeds: [successEmbed(`Panel ticket berhasil dikirim ke ${targetChannel}`)],
      ephemeral: true,
    });
  },
};
