const { SlashCommandBuilder } = require('discord.js');
const { statusEmbed, successEmbed, errorEmbed } = require('../utils/embeds');
const { loadConfig } = require('../utils/config');
const { getStatus, setStatus, getCustomFromConfig } = require('../handlers/statusHelper');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('status')
    .setDescription('Kirim pengumuman status toko open/close (admin only)')
    .addStringOption((opt) =>
      opt
        .setName('kondisi')
        .setDescription('open atau close')
        .setRequired(true)
        .addChoices({ name: 'Open', value: 'open' }, { name: 'Close', value: 'close' })
    ),

  async execute(interaction) {
    const config = loadConfig();
    if (config.roles.admin && !interaction.member.roles.cache.has(config.roles.admin)) {
      return interaction.reply({
        embeds: [errorEmbed('Kamu tidak punya izin untuk mengubah status toko.')],
        ephemeral: true,
      });
    }

    const announceChannel = interaction.guild.channels.cache.get(config.channels.statusAnnounce);
    if (!announceChannel) {
      return interaction.reply({
        embeds: [errorEmbed('Channel pengumuman status belum diatur. Isi "channels.statusAnnounce" di config.json.')],
        ephemeral: true,
      });
    }

    const kondisi = interaction.options.getString('kondisi');
    setStatus(kondisi, interaction.user.id);
    const row = getStatus();
    const custom = getCustomFromConfig(config, kondisi);

    // Ini pesan publik ke channel pengumuman, bukan reply command - tetap terlihat semua orang
    await announceChannel.send({
      content: custom.tag ? `<@&${custom.tag}>` : undefined,
      embeds: [statusEmbed(row.status, row.updated_by, row.updated_at, custom)],
    });

    return interaction.reply({
      embeds: [
        successEmbed(
          `Status toko berhasil diupdate jadi **${kondisi.toUpperCase()}** dan diumumkan di ${announceChannel}.`
        ),
      ],
      ephemeral: true,
    });
  },
};
