const fs = require('fs');
const path = require('path');

const CONFIG_PATH = path.join(__dirname, '..', '..', 'config.json');

/**
 * Selalu membaca ulang config.json dari disk,
 * supaya perubahan manual oleh admin langsung kepakai tanpa restart bot.
 */
function loadConfig() {
  const raw = fs.readFileSync(CONFIG_PATH, 'utf8');
  return JSON.parse(raw);
}

module.exports = { loadConfig, CONFIG_PATH };
