const { EmbedBuilder } = require('discord.js');
const { loadConfig } = require('./config');

function baseEmbed() {
  const config = loadConfig();
  const embed = new EmbedBuilder()
    .setColor(config.branding.color || '#5865F2')
    .setFooter({ text: config.branding.footer || config.branding.name });

  if (config.branding.thumbnail) embed.setThumbnail(config.branding.thumbnail);
  return embed;
}

function statusEmbed(status, updatedBy, updatedAt, custom = {}) {
  const config = loadConfig();
  const isOpen = status === 'open';
  const emojiOpen = config.branding.statusEmojis?.open || '🟢';
  const emojiClose = config.branding.statusEmojis?.close || '🔴';

  const defaultDesc = isOpen
    ? `## ${emojiOpen} STORE OPENED\nToko telah **dibuka**. Silakan order via PM atau buat tiket.\n\nDan jika ada yang ingin ditanyakan silahkan chat, admin sudah online siap membantu.`
    : `## ${emojiClose} STORE CLOSED\nToko sedang **tutup**. Silakan cek kembali di jam operasional berikutnya.\n\nUntuk info lebih lanjut silakan hubungi admin, kami akan segera online kembali.`;

  const embed = baseEmbed()
    .setColor(isOpen ? '#57F287' : '#ED4245')
    .setDescription(custom.description || defaultDesc)
    .setTimestamp(updatedAt || Date.now());

  if (custom.title) embed.setTitle(custom.title);
  if (custom.image_url) embed.setImage(custom.image_url);

  return embed;
}

function ticketCreateLogEmbed(type, user, channel) {
  return baseEmbed()
    .setTitle('🎫 Ticket Dibuat')
    .setColor('#57F287')
    .addFields(
      { name: 'Kategori', value: type, inline: true },
      { name: 'User', value: `<@${user.id}>`, inline: true },
      { name: 'Channel', value: `<#${channel.id}>`, inline: true }
    )
    .setTimestamp();
}

function ticketCloseLogEmbed({ type, userId, channelName, closedBy, claimedBy, createdAt }) {
  const embed = baseEmbed()
    .setTitle('🔒 Ticket Ditutup')
    .setColor('#ED4245')
    .addFields(
      { name: 'Kategori', value: type, inline: true },
      { name: 'User', value: `<@${userId}>`, inline: true },
      { name: 'Channel', value: `#${channelName}`, inline: true },
      { name: 'Ditutup Oleh', value: `<@${closedBy}>`, inline: true }
    )
    .setTimestamp();

  if (claimedBy) embed.addFields({ name: 'Diklaim Oleh', value: `<@${claimedBy}>`, inline: true });
  if (createdAt) embed.addFields({ name: 'Dibuat', value: `<t:${Math.floor(createdAt / 1000)}:R>`, inline: true });

  return embed;
}

function paymentEmbed() {
  const config = loadConfig();
  const embed = baseEmbed()
    .setTitle('💳 Metode Pembayaran')
    .setDescription('Pilih salah satu tombol di bawah untuk melihat detail pembayaran.');

  config.payment.forEach((p) => {
    embed.addFields({ name: p.name, value: 'Klik tombol di bawah untuk detail', inline: true });
  });

  return embed;
}

function paymentDetailEmbed(method) {
  const embed = baseEmbed()
    .setTitle(`💰 ${method.name}`)
    .setDescription(method.detail || 'Tidak ada detail');

  if (method.image) embed.setImage(method.image);
  return embed;
}

function starRating(rating) {
  const r = Math.max(1, Math.min(5, rating));
  return '⭐'.repeat(r) + '☆'.repeat(5 - r);
}

function testimoniEmbed(data) {
  const config = loadConfig();
  const embed = baseEmbed()
    .setTitle(`✅ NEW TESTIMONY - ${config.branding.name.toUpperCase()}`)
    .setDescription('Sebuah transaksi baru telah berhasil diselesaikan!')
    .addFields(
      { name: '👤 Pembeli', value: `<@${data.userId}>` },
      { name: '📦 Barang', value: data.barang, inline: true },
      { name: '💰 Harga', value: data.harga, inline: true },
      { name: '🔢 Jumlah', value: data.jumlah, inline: true },
      { name: '🛡️ Garansi', value: data.garansi || 'No Garansi', inline: true },
      { name: '⭐ Rating', value: starRating(data.rating), inline: true },
      { name: '📝 Note', value: data.note || '-' },
      { name: '🧑\u200d💼 Seller', value: `<@${data.sellerId}>` }
    );

  if (data.buktiUrl) embed.setImage(data.buktiUrl);
  return embed;
}

function ticketPanelEmbed() {
  const config = loadConfig();
  return baseEmbed()
    .setTitle(`${config.branding.name} — Ticket Panel`)
    .setDescription(
      'Pilih kategori yang sesuai, lalu ikuti langkah berikutnya.\n' +
      'Membuat ticket harus memiliki tujuan yang jelas!\n\n' +
      '🛒 **Order**\nPembelian layanan, produk, atau jasa baru.\n\n' +
      '🎉 **Ask/Reward**\nBertanya seputar produk atau diskusi dan claim reward dari giveaway Admin.\n\n' +
      '✅ **Claim Garansi**\nKendala teknis atau pengajuan garansi pembelian.'
    );
}

function ticketWelcomeEmbed(category, user) {
  const titles = {
    order: '🛒 Ticket Order',
    askreward: '🎉 Ticket Ask/Reward',
    garansi: '✅ Ticket Claim Garansi',
  };
  const desc = {
    order: 'Silakan jelaskan produk/jasa yang ingin kamu order beserta detailnya. Admin akan segera membantu.',
    askreward: 'Silakan tulis pertanyaan seputar produk atau info claim reward giveaway kamu.',
    garansi: 'Silakan jelaskan kendala yang kamu alami beserta bukti pembelian untuk pengajuan garansi.',
  };

  return baseEmbed()
    .setTitle(titles[category] || 'Ticket')
    .setDescription(`Halo <@${user.id}>, terima kasih sudah membuat ticket.\n\n${desc[category] || ''}`);
}

function simpleEmbed(message, color = '#5865F2') {
  return baseEmbed().setDescription(message).setColor(color);
}

function successEmbed(message) {
  return simpleEmbed(`✅ ${message}`, '#57F287');
}

function errorEmbed(message) {
  return simpleEmbed(`❌ ${message}`, '#ED4245');
}

function infoEmbed(message) {
  return simpleEmbed(`ℹ️ ${message}`, '#5865F2');
}

module.exports = {
  statusEmbed,
  paymentEmbed,
  paymentDetailEmbed,
  testimoniEmbed,
  ticketPanelEmbed,
  ticketWelcomeEmbed,
  ticketCreateLogEmbed,
  ticketCloseLogEmbed,
  starRating,
  simpleEmbed,
  successEmbed,
  errorEmbed,
  infoEmbed,
};
