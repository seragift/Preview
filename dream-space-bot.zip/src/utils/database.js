const Database = require('better-sqlite3');
const path = require('path');

const db = new Database(path.join(__dirname, '..', '..', 'database', 'store.db'));
db.pragma('journal_mode = WAL');

db.exec(`
  CREATE TABLE IF NOT EXISTS shop_status (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    status TEXT,
    updated_by TEXT,
    updated_at INTEGER
  );

  CREATE TABLE IF NOT EXISTS tickets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    channel_id TEXT UNIQUE,
    user_id TEXT,
    category TEXT,
    status TEXT DEFAULT 'open',
    claimed_by TEXT,
    created_at INTEGER,
    closed_at INTEGER
  );

  CREATE TABLE IF NOT EXISTS testimonials (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT,
    seller_id TEXT,
    barang TEXT,
    harga TEXT,
    jumlah TEXT,
    garansi TEXT,
    rating INTEGER,
    note TEXT,
    bukti_url TEXT,
    created_at INTEGER
  );

  CREATE TABLE IF NOT EXISTS warranties (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT,
    role_id TEXT,
    started_at INTEGER,
    expires_at INTEGER,
    active INTEGER DEFAULT 1
  );
`);

module.exports = db;
