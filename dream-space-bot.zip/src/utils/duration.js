/**
 * Parse string durasi seperti "1h", "3d", "2w", "1m", "1y" menjadi milidetik.
 * h = jam, d = hari, w = minggu, m = bulan (~30 hari), y = tahun (~365 hari)
 */
function parseDuration(input) {
  const match = /^(\d+)\s*(h|d|w|m|y)$/i.exec(String(input).trim());
  if (!match) return null;

  const value = parseInt(match[1], 10);
  const unit = match[2].toLowerCase();

  const unitMs = {
    h: 60 * 60 * 1000,
    d: 24 * 60 * 60 * 1000,
    w: 7 * 24 * 60 * 60 * 1000,
    m: 30 * 24 * 60 * 60 * 1000,
    y: 365 * 24 * 60 * 60 * 1000,
  };

  return value * unitMs[unit];
}

function formatDuration(ms) {
  const days = Math.floor(ms / (24 * 60 * 60 * 1000));
  if (days >= 365) return `${Math.round(days / 365)} tahun`;
  if (days >= 30) return `${Math.round(days / 30)} bulan`;
  if (days >= 7) return `${Math.round(days / 7)} minggu`;
  if (days >= 1) return `${days} hari`;
  const hours = Math.floor(ms / (60 * 60 * 1000));
  return `${hours} jam`;
}

module.exports = { parseDuration, formatDuration };
