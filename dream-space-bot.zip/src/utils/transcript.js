/**
 * Ambil semua pesan di sebuah channel ticket (maks limit), urut dari lama ke baru.
 */
async function fetchAllMessages(channel, limit = 500) {
  const collected = [];
  let lastId;

  while (collected.length < limit) {
    const options = { limit: 100 };
    if (lastId) options.before = lastId;

    const fetched = await channel.messages.fetch(options);
    if (fetched.size === 0) break;

    collected.push(...fetched.values());
    lastId = fetched.last().id;

    if (fetched.size < 100) break;
  }

  return collected.reverse();
}

/**
 * Ubah kumpulan pesan menjadi teks transkrip yang bisa dibaca.
 */
function buildTranscriptText(messages, channelName) {
  let text = `Transkrip Ticket: #${channelName}\n`;
  text += `Diekspor: ${new Date().toLocaleString('id-ID')}\n`;
  text += '='.repeat(60) + '\n\n';

  for (const msg of messages) {
    const time = new Date(msg.createdTimestamp).toLocaleString('id-ID');
    text += `[${time}] ${msg.author.tag}: ${msg.content || '(tidak ada teks)'}\n`;

    if (msg.attachments.size > 0) {
      msg.attachments.forEach((att) => {
        text += `    📎 Attachment: ${att.url}\n`;
      });
    }

    if (msg.embeds.length > 0) {
      msg.embeds.forEach((e) => {
        text += `    📩 Embed: ${e.title || ''} ${e.description ? '- ' + e.description : ''}\n`;
      });
    }
  }

  if (messages.length === 0) text += '(Tidak ada pesan di ticket ini)\n';

  return text;
}

async function generateTranscript(channel) {
  const messages = await fetchAllMessages(channel);
  return buildTranscriptText(messages, channel.name);
}

module.exports = { generateTranscript };
