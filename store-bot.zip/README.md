# Dream Space Utility — Discord Store Bot

Bot Discord untuk kebutuhan toko/store: pembayaran, ticket system, manajemen customer,
garansi otomatis, dan testimoni — semua dikonfigurasi lewat `config.json` (tanpa
hardcode ID di source code) dan disimpan sebagai file JSON (tanpa database eksternal).

## Struktur Project

```
store-bot/
├── .env                     # token & ID rahasia (JANGAN dikomit)
├── config.json              # semua konfigurasi yang bisa diubah admin
├── index.js                 # entry point bot
├── package.json
└── src/
    ├── deploy-commands.js   # register slash command
    ├── commands/            # payment, panelticket, addcus, garansi, testimoni
    ├── events/               # ready, interactionCreate
    ├── handlers/             # commandHandler, interactionHandler
    ├── utils/                # configManager, warrantyManager, ticketManager, embedBuilder, permissions
    └── data/
        └── warranties.json   # data garansi aktif (auto-generated)
```

## 1. Persiapan Bot di Discord Developer Portal

1. Buka https://discord.com/developers/applications → **New Application**.
2. Masuk ke tab **Bot** → **Reset Token** → salin token (untuk `DISCORD_TOKEN`).
3. Di tab **Bot**, aktifkan **Server Members Intent** (privileged intent — wajib,
   karena bot menambah/menghapus role customer & garansi).
4. Salin **Application ID** di tab **General Information** (untuk `CLIENT_ID`).
5. Di tab **OAuth2 → URL Generator**, centang scope `bot` dan `applications.commands`,
   lalu centang permission minimal: `Manage Roles`, `Manage Channels`, `View Channels`,
   `Send Messages`, `Manage Messages`, `Read Message History`, `Embed Links`,
   `Attach Files`, `Use Slash Commands`.
6. Buka URL yang dihasilkan, undang bot ke server kamu.
7. Ambil **Server/Guild ID** (klik kanan nama server di Discord dengan Developer Mode aktif)
   untuk `GUILD_ID`.
8. **Penting**: role bot harus berada **di atas** role buyer & garansi di urutan role server,
   supaya bot bisa menambah/menghapus role tersebut.

## 2. Konfigurasi `.env`

```
DISCORD_TOKEN=isi_token_bot
CLIENT_ID=isi_application_id
GUILD_ID=isi_server_id
```

## 3. Konfigurasi `config.json`

Isi field kosong sesuai kebutuhan server kamu, contoh:

- `roles.adminRoleId` — role yang boleh menjalankan command admin.
- `roles.buyerRoleId` — role yang diberikan lewat `/addcus`.
- `roles.warrantyRoleId` — role yang diberikan lewat `/garansi`.
- `channels.ticketCategoryId` — category tempat channel ticket dibuat.
- `channels.logChannelId` — channel log (opsional, kosongkan jika tidak perlu).
- `testimony.channelId` — channel tujuan pengiriman testimoni.
- `payment.dana` / `payment.qris` — data pembayaran (nomor, nama, gambar QRIS).

File ini akan **ditulis ulang otomatis** oleh bot saat counter testimoni bertambah,
jadi jangan edit manual saat bot sedang berjalan untuk menghindari konflik.

## 4. Instalasi & Menjalankan Bot secara Lokal

```bash
npm install
npm run deploy   # daftarkan slash command ke server (GUILD_ID)
npm start        # jalankan bot
```

## 5. Setup di VPS (Ubuntu) dari Awal sampai Online dengan PM2

```bash
# 1) Update sistem
sudo apt update && sudo apt upgrade -y

# 2) Install Node.js 20 (via NodeSource)
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs
node -v   # pastikan v20.x

# 3) Upload / clone project ke VPS, lalu masuk ke folder project
cd store-bot

# 4) Install dependency
npm install

# 5) Buat file .env dan isi TOKEN/CLIENT_ID/GUILD_ID
nano .env

# 6) Isi config.json sesuai kebutuhan (role, channel, payment, dst.)
nano config.json

# 7) Daftarkan slash command
npm run deploy

# 8) Install PM2 secara global
sudo npm install -g pm2

# 9) Jalankan bot dengan PM2
pm2 start index.js --name store-bot

# 10) Simpan proses PM2 agar auto-restart saat VPS reboot
pm2 save
pm2 startup
# jalankan perintah yang ditampilkan pm2 startup (biasanya diawali "sudo env PATH=...")

# Perintah PM2 yang berguna:
pm2 logs store-bot     # lihat log realtime
pm2 restart store-bot  # restart bot (misalnya setelah update config)
pm2 stop store-bot
pm2 status
```

## 6. Catatan Teknis Penting

- **Modal Discord maksimal 5 field.** Spesifikasi `/testimoni` awal meminta 7 data
  (Buyer, Barang, Harga, Garansi, Note, Seller, Bukti). Karena keterbatasan Discord,
  `Seller` dan `Bukti` diambil sebagai **option slash command**
  (`/testimoni seller:@user bukti:<url>`), sedangkan 5 sisanya diisi lewat modal popup.
- **Restart-safe**: role buyer, role garansi, konfigurasi payment, counter testimoni
  (semua di `config.json`), dan data garansi aktif (`src/data/warranties.json`) tetap
  ada setelah bot di-restart. Warranty dicek ulang saat startup + safety-net interval
  setiap 5 menit (selain `setTimeout` per-user).
- **Tidak ada hardcode ID** — semua role/channel/payment diambil dari `config.json`.
- **Tidak menggunakan database** (SQLite/MongoDB) karena seluruh kebutuhan penyimpanan
  cukup ditangani dengan `config.json` dan `src/data/warranties.json`.

## 7. Daftar Command

| Command | Deskripsi | Akses |
|---|---|---|
| `/payment` | Menampilkan metode pembayaran (DANA/QRIS) | Admin |
| `/panelticket` | Mengirim panel ticket (Order/Ask-Reward/Garansi) | Admin |
| `/addcus user:@user` | Menambahkan role buyer | Admin |
| `/garansi user:@user hari:<1-999>` | Menambahkan garansi + role garansi langsung | Admin |
| `/testimoni buyer:@buyer seller:@seller garansi:<1-999> bukti:<attachment opsional>` | Membuka sesi testimoni untuk buyer | Admin |

### Alur `/testimoni` (2 tahap)

1. **Seller/admin** menjalankan `/testimoni` dengan mengisi option `buyer`, `seller`,
   `garansi` (hari), dan `bukti` (attachment gambar, opsional).
2. Bot mengirim embed **"📝 Isi Testimoni"** dengan tombol **Isi Testimoni** di channel
   yang sama. Role garansi **belum** ditambahkan pada tahap ini.
3. **Buyer** (harus user yang sama dengan option `buyer`) menekan tombol tersebut,
   lalu mengisi modal: **Barang**, **Harga**, **Rating (1-5)**.
4. Setelah submit:
   - Bot mengirim embed testimoni lengkap (Buyer, Seller, Barang, Harga, Rating
     dalam bentuk bintang 🌟, Garansi, dan Bukti) ke `testimony.channelId`.
   - Role garansi (`roles.warrantyRoleId` dari `config.json`) otomatis ditambahkan
     ke buyer, dan dijadwalkan untuk dicopot otomatis saat masa garansi habis
     (ditangani oleh `warrantyManager.js`, restart-safe).
   - Tombol pada embed prompt dikunci (disabled) supaya tidak bisa diisi dua kali.
5. **Selama buyer belum mengisi testimoni, role garansi tidak akan pernah
   ditambahkan** — jadi garansi otomatis tidak bisa diklaim sebelum testimoni diisi.

Data sesi testimoni yang belum diisi disimpan di `src/data/pending-testimoni.json`
(auto-generated, restart-safe) sampai buyer selesai mengisi modal.
