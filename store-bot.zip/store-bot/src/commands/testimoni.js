'use strict';

const {
  SlashCommandBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActionRowBuilder,
  EmbedBuilder,
} = require('discord.js');
const { getConfig, incrementTestimonyCounter } = require('../utils/configManager');
const { isAdmin } = require('../utils/permissions');
const { errorEmbed, successEmbed } = require('../utils/embedBuilder');

// CATATAN TEKNIS:
// Discord membatasi modal maksimal 5 komponen (5 text input).
// Spesifikasi awal meminta 7 field (Buyer, Barang, Harga, Garansi, Note, Seller, Bukti).
// Solusi: "Seller" dan "Bukti" diambil sebagai OPTION pada slash command /testimoni
// (dikumpulkan sebelum modal dibuka), sisanya (5 field) diisi lewat modal.
const pendingTestimoni = new Map();

module.exports = {
  data: new SlashCommandBuilder()
    .setName('testimoni')
    .setDescription('Mengirim testimoni transaksi baru.')
    .addUserOption((option) => option.setName('seller').setDescription('Seller yang menangani transaksi ini').setRequired(true))
    .addStringOption((option) => option.setName('bukti').setDescription('URL gambar bukti transaksi (opsional)').setRequired(false)),

  async execute(interaction) {
    const config = getConfig();

    if (!isAdmin(interaction.member, config)) {
      return interaction.reply({
        embeds: [errorEmbed('Kamu tidak memiliki permission untuk menggunakan command ini.')],
        ephemeral: true,
      });
    }

    const seller = interaction.options.getUser('seller', true);
    const buktiUrl = interaction.options.getString('bukti') || null;

    if (buktiUrl && !/^https?:\/\/.+\.(png|jpe?g|gif|webp)(\?.*)?$/i.test(buktiUrl)) {
      return interaction.reply({
        embeds: [errorEmbed('URL bukti tidak valid. Gunakan link gambar (png/jpg/jpeg/gif/webp).')],
        ephemeral: true,
      });
    }

    pendingTestimoni.set(interaction.user.id, { sellerId: seller.id, buktiUrl });

    const modal = new ModalBuilder().setCustomId('testimoni_modal').setTitle('Testimoni');

    const buyerInput = new TextInputBuilder()
      .setCustomId('testimoni_buyer')
      .setLabel('Buyer (mention / ID)')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    const barangInput = new TextInputBuilder()
      .setCustomId('testimoni_barang')
      .setLabel('Barang')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    const hargaInput = new TextInputBuilder()
      .setCustomId('testimoni_harga')
      .setLabel('Harga')
      .setPlaceholder('Contoh: Rp 100.000')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    const garansiInput = new TextInputBuilder()
      .setCustomId('testimoni_garansi')
      .setLabel('Garansi')
      .setPlaceholder('Contoh: 7 Hari / No Garansi')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    const noteInput = new TextInputBuilder()
      .setCustomId('testimoni_note')
      .setLabel('Note')
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(true);

    modal.addComponents(
      new ActionRowBuilder().addComponents(buyerInput),
      new ActionRowBuilder().addComponents(barangInput),
      new ActionRowBuilder().addComponents(hargaInput),
      new ActionRowBuilder().addComponents(garansiInput),
      new ActionRowBuilder().addComponents(noteInput),
    );

    await interaction.showModal(modal);
  },

  async handleModalSubmit(interaction) {
    const config = getConfig();
    const pending = pendingTestimoni.get(interaction.user.id);
    pendingTestimoni.delete(interaction.user.id);

    const buyerRaw = interaction.fields.getTextInputValue('testimoni_buyer').trim();
    const barang = interaction.fields.getTextInputValue('testimoni_barang').trim();
    const harga = interaction.fields.getTextInputValue('testimoni_harga').trim();
    const garansi = interaction.fields.getTextInputValue('testimoni_garansi').trim();
    const note = interaction.fields.getTextInputValue('testimoni_note').trim();

    await interaction.deferReply({ ephemeral: true });

    const testimonyChannelId = config.testimony?.channelId || config.channels?.testimonyChannelId;
    if (!testimonyChannelId) {
      return interaction.editReply({ embeds: [errorEmbed('Channel testimoni belum dikonfigurasi.')] });
    }

    let channel;
    try {
      channel = await interaction.guild.channels.fetch(testimonyChannelId);
    } catch (err) {
      return interaction.editReply({ embeds: [errorEmbed('Channel testimoni tidak ditemukan.')] });
    }

    if (!channel?.isTextBased()) {
      return interaction.editReply({ embeds: [errorEmbed('Channel testimoni tidak valid.')] });
    }

    const buyerIdMatch = buyerRaw.match(/\d{15,20}/);
    const buyerMention = buyerIdMatch ? `<@${buyerIdMatch[0]}>` : buyerRaw;
    const sellerMention = pending?.sellerId ? `<@${pending.sellerId}>` : `<@${interaction.user.id}>`;

    const counter = await incrementTestimonyCounter();

    const embed = new EmbedBuilder()
      .setColor(config.bot?.color || '#5865F2')
      .setTitle('✅ NEW TESTIMONY - DREAM SPACE STORE')
      .setDescription('Sebuah transaksi baru telah berhasil diselesaikan!')
      .addFields(
        { name: '👤 Pembeli', value: buyerMention, inline: true },
        { name: '👨‍💼 Seller', value: sellerMention, inline: true },
        { name: '📦 Barang', value: `\`${barang}\`` },
        { name: '💰 Harga', value: `\`${harga}\`` },
        { name: '🛡️ Garansi', value: `\`${garansi}\`` },
        { name: '📝 Note', value: note },
      )
      .setFooter({ text: config.bot?.footer || 'Dream Space © 2026' })
      .setTimestamp();

    if (pending?.buktiUrl) {
      embed.setImage(pending.buktiUrl);
    }

    await channel.send({
      content: `Makasih Dah Order & Testimoni #${counter}`,
      embeds: [embed],
    });

    await interaction.editReply({
      embeds: [successEmbed({ title: '✅ Berhasil', description: `Testimoni #${counter} berhasil dikirim ke <#${channel.id}>` })],
    });
  },
};
