'use strict';

const { Events } = require('discord.js');
const { handleChatInputCommand, handleButton, handleModal } = require('../handlers/interactionHandler');

module.exports = {
  name: Events.InteractionCreate,
  async execute(interaction, client) {
    if (interaction.isChatInputCommand()) {
      return handleChatInputCommand(interaction, client);
    }
    if (interaction.isButton()) {
      return handleButton(interaction, client);
    }
    if (interaction.isModalSubmit()) {
      return handleModal(interaction, client);
    }
  },
};
