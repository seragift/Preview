'use strict';

const { Events } = require('discord.js');
const { init } = require('../utils/warrantyManager');

module.exports = {
  name: Events.ClientReady,
  once: true,
  async execute(client) {
    console.log(`[Ready] Login sebagai ${client.user.tag}`);
    init(client);
  },
};
