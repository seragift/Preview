'use strict';

const {
  ChannelType,
  PermissionsBitField,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require('discord.js');
const { getConfig } = require('./configManager');
const { infoEmbed, errorEmbed, successEmbed } = require('./embedBuilder');

const CATEGORY_INFO = {
  ticket_order: { prefix: 'order', label: '🛒 Order' },
  ticket_ask_reward: { prefix: 'ask', label: '🎉 Ask/Reward' },
  ticket_warranty: { prefix: 'garansi', label: '✅ Claim Garansi' },
};

function sanitizeUsername(username) {
  return username.toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 20) || 'user';
}

function findExistingTicket(guild, prefix, userId) {
  return guild.channels.cache.find((ch) => ch.topic === `ticket:${prefix}:${userId}`) || null;
}

async function createTicket(interaction, customId) {
  const config = getConfig();
  const info = CATEGORY_INFO[customId];
  if (!info) return;

  const { guild, user } = interaction;
  const categoryId = config.channels?.ticketCategoryId;

  if (!categoryId) {
    return interaction.reply({
      embeds: [errorEmbed('Kategori ticket belum dikonfigurasi. Hubungi admin.')],
      ephemeral: true,
    });
  }

  await interaction.deferReply({ ephemeral: true });

  const existing = findExistingTicket(guild, info.prefix, user.id);
  if (existing) {
    return interaction.editReply({
      embeds: [errorEmbed(`Kamu sudah memiliki ticket kategori ini: <#${existing.id}>`)],
    });
  }

  const adminRoleId = config.roles?.adminRoleId;
  const channelName = `${info.prefix}-${sanitizeUsername(user.username)}`;

  const overwrites = [
    {
      id: guild.roles.everyone.id,
      deny: [PermissionsBitField.Flags.ViewChannel],
    },
    {
      id: user.id,
      allow: [
        PermissionsBitField.Flags.ViewChannel,
        PermissionsBitField.Flags.SendMessages,
        PermissionsBitField.Flags.ReadMessageHistory,
      ],
    },
    {
      id: guild.members.me.id,
      allow: [
        PermissionsBitField.Flags.ViewChannel,
        PermissionsBitField.Flags.SendMessages,
        PermissionsBitField.Flags.ManageChannels,
        PermissionsBitField.Flags.ManageMessages,
      ],
    },
  ];

  if (adminRoleId) {
    overwrites.push({
      id: adminRoleId,
      allow: [PermissionsBitField.Flags.ViewChannel],
    });
  }

  let channel;
  try {
    channel = await guild.channels.create({
      name: channelName,
      type: ChannelType.GuildText,
      parent: categoryId,
      topic: `ticket:${info.prefix}:${user.id}`,
      permissionOverwrites: overwrites,
    });
  } catch (err) {
    console.error('[TicketManager] Gagal membuat channel ticket:', err.message);
    return interaction.editReply({
      embeds: [errorEmbed('Gagal membuat ticket. Periksa permission bot atau category ID di config.json.')],
    });
  }

  const embed = infoEmbed({
    title: '🎫 Ticket Dibuat',
    description: 'Silakan jelaskan kebutuhan kamu dengan jelas.',
    fields: [
      { name: 'Kategori', value: info.label, inline: true },
      { name: 'Customer', value: `<@${user.id}>`, inline: true },
    ],
  });

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('ticket_close').setLabel('Tutup Ticket').setEmoji('🔒').setStyle(ButtonStyle.Danger),
  );

  await channel.send({ content: `<@${user.id}>`, embeds: [embed], components: [row] });

  await interaction.editReply({
    embeds: [successEmbed({ title: '✅ Ticket Dibuat', description: `Ticket kamu telah dibuat di <#${channel.id}>` })],
  });
}

async function requestCloseConfirmation(interaction) {
  const embed = infoEmbed({
    title: '🔒 Tutup Ticket',
    description: 'Apakah kamu yakin ingin menutup ticket ini?',
  });

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('ticket_close_confirm').setLabel('Tutup').setEmoji('✅').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId('ticket_close_cancel').setLabel('Batal').setEmoji('❌').setStyle(ButtonStyle.Secondary),
  );

  await interaction.reply({ embeds: [embed], components: [row], ephemeral: true });
}

async function confirmClose(interaction) {
  const { channel } = interaction;

  await interaction.update({
    embeds: [successEmbed({ title: '🔒 Ticket Ditutup', description: 'Channel ini telah dikunci dan akan segera dihapus.' })],
    components: [],
  });

  try {
    const topicParts = (channel.topic || '').split(':');
    const ticketUserId = topicParts[2];
    if (ticketUserId) {
      await channel.permissionOverwrites.edit(ticketUserId, { SendMessages: false });
    }
  } catch (err) {
    console.error('[TicketManager] Gagal mengunci channel:', err.message);
  }

  setTimeout(async () => {
    try {
      await channel.delete('Ticket ditutup oleh user.');
    } catch (err) {
      console.error('[TicketManager] Gagal menghapus channel:', err.message);
    }
  }, 5000);
}

async function cancelClose(interaction) {
  await interaction.update({
    embeds: [infoEmbed({ title: '❌ Dibatalkan', description: 'Penutupan ticket dibatalkan.' })],
    components: [],
  });
}

module.exports = { createTicket, requestCloseConfirmation, confirmClose, cancelClose };
