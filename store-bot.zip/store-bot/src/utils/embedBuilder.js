'use strict';

const { EmbedBuilder } = require('discord.js');
const { getConfig } = require('./configManager');

function baseEmbed() {
  const config = getConfig();
  return new EmbedBuilder()
    .setColor(config.bot?.color || '#5865F2')
    .setFooter({ text: config.bot?.footer || 'Dream Space © 2026' })
    .setTimestamp();
}

function infoEmbed({ title, description, fields } = {}) {
  const embed = baseEmbed();
  if (title) embed.setTitle(title);
  if (description) embed.setDescription(description);
  if (fields) embed.addFields(fields);
  return embed;
}

function successEmbed({ title, description, fields } = {}) {
  const embed = baseEmbed().setTitle(title || '✅ Berhasil');
  if (description) embed.setDescription(description);
  if (fields) embed.addFields(fields);
  return embed;
}

function errorEmbed(description) {
  return baseEmbed()
    .setTitle('❌ Terjadi Kesalahan')
    .setDescription(description)
    .setColor('#ED4245');
}

module.exports = { baseEmbed, infoEmbed, successEmbed, errorEmbed };
