'use strict';

/**
 * Mengecek apakah member memiliki role admin yang dikonfigurasi di config.json.
 * Sengaja TIDAK mengandalkan Discord Administrator permission bawaan,
 * sesuai requirement: hanya role admin dari config.json yang dihitung.
 */
function isAdmin(member, config) {
  const adminRoleId = config?.roles?.adminRoleId;
  if (!member || !adminRoleId) return false;
  return member.roles.cache.has(adminRoleId);
}

module.exports = { isAdmin };
