'use strict';

const fs = require('fs');
const path = require('path');
const { getConfig } = require('./configManager');

const DATA_PATH = path.join(__dirname, '..', 'data', 'warranties.json');
const CHECK_INTERVAL_MS = 5 * 60 * 1000; // safety-net check setiap 5 menit
const MAX_TIMEOUT = 2147483647; // batas maksimum setTimeout di Node.js (~24.8 hari)

let client = null;
const timers = new Map();

function loadWarranties() {
  try {
    const raw = fs.readFileSync(DATA_PATH, 'utf-8');
    return JSON.parse(raw || '{}');
  } catch (err) {
    if (err.code === 'ENOENT') {
      fs.writeFileSync(DATA_PATH, '{}', 'utf-8');
      return {};
    }
    throw err;
  }
}

function saveWarranties(data) {
  fs.writeFileSync(DATA_PATH, JSON.stringify(data, null, 2), 'utf-8');
}

function clearTimer(userId) {
  if (timers.has(userId)) {
    clearTimeout(timers.get(userId));
    timers.delete(userId);
  }
}

function scheduleTimer(userId, expiresAt) {
  clearTimer(userId);
  const delay = expiresAt - Date.now();
  // Kalau sudah lewat atau delay lebih besar dari batas setTimeout,
  // biarkan interval check (safety-net) yang menanganinya.
  if (delay <= 0 || delay > MAX_TIMEOUT) return;

  const timer = setTimeout(() => {
    processExpiry(userId).catch((err) => console.error('[WarrantyManager] Gagal proses expiry:', err.message));
  }, delay);

  timers.set(userId, timer);
}

function scheduleAllTimers() {
  const data = loadWarranties();
  for (const [userId, info] of Object.entries(data)) {
    scheduleTimer(userId, info.expiresAt);
  }
}

async function sendLog(message) {
  if (!client) return;
  const config = getConfig();
  const logChannelId = config.channels?.logChannelId;
  if (!logChannelId) return;

  try {
    const channel = await client.channels.fetch(logChannelId);
    if (channel?.isTextBased()) {
      await channel.send({ content: message });
    }
  } catch (err) {
    console.error('[WarrantyManager] Gagal mengirim log:', err.message);
  }
}

async function removeWarrantyRole(userId, roleId) {
  if (!client) return;
  const guildId = process.env.GUILD_ID;

  try {
    const guild = await client.guilds.fetch(guildId);
    const member = await guild.members.fetch(userId).catch(() => null);

    if (member && roleId && member.roles.cache.has(roleId)) {
      await member.roles.remove(roleId).catch((err) => {
        console.error('[WarrantyManager] Gagal menghapus role:', err.message);
      });
    }

    await sendLog(`⏰ Garansi untuk <@${userId}> telah **berakhir** dan role garansi telah dihapus.`);
  } catch (err) {
    console.error('[WarrantyManager] Gagal memproses penghapusan role garansi:', err.message);
  }
}

async function processExpiry(userId) {
  const data = loadWarranties();
  const info = data[userId];
  if (!info) return;

  await removeWarrantyRole(userId, info.roleId);

  delete data[userId];
  saveWarranties(data);
  clearTimer(userId);
}

async function checkExpiredWarranties() {
  const data = loadWarranties();
  const now = Date.now();
  const expiredUserIds = Object.entries(data)
    .filter(([, info]) => info.expiresAt <= now)
    .map(([userId]) => userId);

  for (const userId of expiredUserIds) {
    await processExpiry(userId);
  }
}

/**
 * Menambahkan / menimpa data garansi untuk seorang user.
 */
async function addWarranty(userId, roleId, days) {
  const data = loadWarranties();
  const expiresAt = Date.now() + days * 24 * 60 * 60 * 1000;
  data[userId] = { roleId, expiresAt };
  saveWarranties(data);
  scheduleTimer(userId, expiresAt);
  return expiresAt;
}

function getWarranty(userId) {
  const data = loadWarranties();
  return data[userId] || null;
}

/**
 * Dipanggil sekali saat bot ready: melakukan pengecekan warranty expired,
 * menjadwalkan ulang semua timer, dan mengaktifkan safety-net interval.
 */
function init(discordClient) {
  client = discordClient;
  checkExpiredWarranties().catch((err) => console.error('[WarrantyManager] Gagal cek warranty saat startup:', err.message));
  scheduleAllTimers();
  setInterval(() => {
    checkExpiredWarranties().catch((err) => console.error('[WarrantyManager] Gagal cek warranty (interval):', err.message));
  }, CHECK_INTERVAL_MS);
}

module.exports = {
  init,
  addWarranty,
  getWarranty,
  checkExpiredWarranties,
};
