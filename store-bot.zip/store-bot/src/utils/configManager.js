'use strict';

const fs = require('fs');
const path = require('path');

const CONFIG_PATH = path.join(__dirname, '..', '..', 'config.json');

let configCache = null;
let writeQueue = Promise.resolve();

function loadConfig() {
  const raw = fs.readFileSync(CONFIG_PATH, 'utf-8');
  configCache = JSON.parse(raw);
  return configCache;
}

function getConfig() {
  if (!configCache) {
    loadConfig();
  }
  return configCache;
}

function saveConfig(newConfig) {
  writeQueue = writeQueue.then(
    () =>
      new Promise((resolve, reject) => {
        fs.writeFile(CONFIG_PATH, JSON.stringify(newConfig, null, 2), 'utf-8', (err) => {
          if (err) return reject(err);
          configCache = newConfig;
          resolve(configCache);
        });
      }),
  );
  return writeQueue;
}

/**
 * Update config secara aman. `updater` bisa berupa function (cfg) => cfg
 * atau object partial yang akan digabung dengan config saat ini.
 */
async function updateConfig(updater) {
  const current = getConfig();
  const updated = typeof updater === 'function' ? updater(current) : { ...current, ...updater };
  await saveConfig(updated);
  return updated;
}

async function setBuyerRole(roleId) {
  return updateConfig((cfg) => {
    cfg.roles = cfg.roles || {};
    cfg.roles.buyerRoleId = roleId;
    return cfg;
  });
}

async function setWarrantyRole(roleId) {
  return updateConfig((cfg) => {
    cfg.roles = cfg.roles || {};
    cfg.roles.warrantyRoleId = roleId;
    return cfg;
  });
}

async function incrementTestimonyCounter() {
  const cfg = getConfig();
  const next = (cfg.testimony?.counter || 0) + 1;
  await updateConfig((c) => {
    c.testimony = c.testimony || {};
    c.testimony.counter = next;
    return c;
  });
  return next;
}

module.exports = {
  getConfig,
  loadConfig,
  updateConfig,
  setBuyerRole,
  setWarrantyRole,
  incrementTestimonyCounter,
};
