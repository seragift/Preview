'use strict';

require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { REST, Routes } = require('discord.js');

const commands = [];
const commandsPath = path.join(__dirname, 'commands');
const commandFiles = fs.readdirSync(commandsPath).filter((file) => file.endsWith('.js'));

for (const file of commandFiles) {
  const command = require(path.join(commandsPath, file));
  if ('data' in command && 'execute' in command) {
    commands.push(command.data.toJSON());
  } else {
    console.warn(`[Deploy] Command di ${file} tidak valid, dilewati.`);
  }
}

if (!process.env.DISCORD_TOKEN || !process.env.CLIENT_ID || !process.env.GUILD_ID) {
  console.error('[Deploy] DISCORD_TOKEN, CLIENT_ID, dan GUILD_ID wajib diisi di file .env');
  process.exit(1);
}

const rest = new REST().setToken(process.env.DISCORD_TOKEN);

(async () => {
  try {
    console.log(`[Deploy] Mendaftarkan ${commands.length} slash command ke guild...`);

    const data = await rest.put(
      Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID),
      { body: commands },
    );

    console.log(`[Deploy] Berhasil mendaftarkan ${data.length} slash command.`);
  } catch (err) {
    console.error('[Deploy] Gagal mendaftarkan command:', err);
  }
})();
