'use strict';

const fs = require('fs');
const path = require('path');
const { Collection } = require('discord.js');

function loadCommands(client) {
  client.commands = new Collection();
  const commandsPath = path.join(__dirname, '..', 'commands');
  const commandFiles = fs.readdirSync(commandsPath).filter((file) => file.endsWith('.js'));

  for (const file of commandFiles) {
    const filePath = path.join(commandsPath, file);
    const command = require(filePath);

    if ('data' in command && 'execute' in command) {
      client.commands.set(command.data.name, command);
    } else {
      console.warn(`[CommandHandler] Command di ${file} tidak memiliki 'data' atau 'execute', dilewati.`);
    }
  }

  console.log(`[CommandHandler] ${client.commands.size} command berhasil dimuat.`);
  return client.commands;
}

module.exports = { loadCommands };
