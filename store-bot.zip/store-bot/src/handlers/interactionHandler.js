'use strict';

const { getConfig } = require('../utils/configManager');
const { errorEmbed, infoEmbed } = require('../utils/embedBuilder');
const ticketManager = require('../utils/ticketManager');

async function replyError(interaction, message) {
  const payload = { embeds: [errorEmbed(message)], ephemeral: true };
  if (interaction.replied || interaction.deferred) {
    await interaction.followUp(payload).catch(() => {});
  } else {
    await interaction.reply(payload).catch(() => {});
  }
}

async function handleChatInputCommand(interaction, client) {
  const command = client.commands.get(interaction.commandName);
  if (!command) {
    console.warn(`[InteractionHandler] Command tidak ditemukan: ${interaction.commandName}`);
    return;
  }

  try {
    await command.execute(interaction, client);
  } catch (err) {
    console.error(`[InteractionHandler] Error pada command ${interaction.commandName}:`, err);
    await replyError(interaction, 'Terjadi kesalahan saat menjalankan command ini.');
  }
}

async function handleButton(interaction) {
  const { customId } = interaction;
  const config = getConfig();

  try {
    if (customId === 'payment_dana') {
      const dana = config.payment?.dana;
      if (!dana?.enabled) {
        return interaction.reply({ embeds: [errorEmbed('Metode pembayaran DANA sedang tidak tersedia.')], ephemeral: true });
      }
      const embed = infoEmbed({
        title: '💳 Pembayaran DANA',
        fields: [
          { name: 'Nomor', value: `\`${dana.number || '-'}\`` },
          { name: 'Atas Nama', value: `\`${dana.name || '-'}\`` },
        ],
      });
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    if (customId === 'payment_qris') {
      const qris = config.payment?.qris;
      if (!qris?.enabled) {
        return interaction.reply({ embeds: [errorEmbed('Metode pembayaran QRIS sedang tidak tersedia.')], ephemeral: true });
      }
      const embed = infoEmbed({
        title: '💳 Pembayaran QRIS',
        description: `Silakan scan QRIS di bawah.\n\nAtas Nama: \`${qris.name || '-'}\``,
      });
      if (qris.image) embed.setImage(qris.image);
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    if (['ticket_order', 'ticket_ask_reward', 'ticket_warranty'].includes(customId)) {
      return ticketManager.createTicket(interaction, customId);
    }

    if (customId === 'ticket_close') {
      return ticketManager.requestCloseConfirmation(interaction);
    }

    if (customId === 'ticket_close_confirm') {
      return ticketManager.confirmClose(interaction);
    }

    if (customId === 'ticket_close_cancel') {
      return ticketManager.cancelClose(interaction);
    }
  } catch (err) {
    console.error('[InteractionHandler] Error pada button interaction:', err);
    await replyError(interaction, 'Terjadi kesalahan saat memproses tombol ini.');
  }
}

async function handleModal(interaction) {
  try {
    if (interaction.customId === 'testimoni_modal') {
      const testimoniCommand = require('../commands/testimoni');
      return testimoniCommand.handleModalSubmit(interaction);
    }
  } catch (err) {
    console.error('[InteractionHandler] Error pada modal submit:', err);
    await replyError(interaction, 'Terjadi kesalahan saat memproses form ini.');
  }
}

module.exports = { handleChatInputCommand, handleButton, handleModal };
