'use strict';

require('dotenv').config();
const { Client, GatewayIntentBits, Partials } = require('discord.js');
const { loadCommands } = require('./src/handlers/commandHandler');
const { getConfig } = require('./src/utils/configManager');

// Pastikan config.json bisa dibaca sebelum bot login.
try {
  getConfig();
} catch (err) {
  console.error('[Startup] Gagal membaca config.json:', err.message);
  process.exit(1);
}

if (!process.env.DISCORD_TOKEN || !process.env.CLIENT_ID || !process.env.GUILD_ID) {
  console.error('[Startup] DISCORD_TOKEN, CLIENT_ID, dan GUILD_ID wajib diisi di file .env');
  process.exit(1);
}

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
  ],
  partials: [Partials.Channel],
});

loadCommands(client);

const readyEvent = require('./src/events/ready');
const interactionCreateEvent = require('./src/events/interactionCreate');

if (readyEvent.once) {
  client.once(readyEvent.name, (readyClient) => readyEvent.execute(readyClient));
} else {
  client.on(readyEvent.name, (readyClient) => readyEvent.execute(readyClient));
}

client.on(interactionCreateEvent.name, (interaction) => interactionCreateEvent.execute(interaction, client));

client.on('error', (err) => {
  console.error('[Client Error]', err);
});

process.on('unhandledRejection', (err) => {
  console.error('[Unhandled Rejection]', err);
});

client.login(process.env.DISCORD_TOKEN);
