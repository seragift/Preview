# Nexsus Samp

Bot Discord untuk komunitas SA-MP/SSRP:
- Cari **skin ID** dan **vehicle ID** lengkap dengan gambarnya.
- **Monitoring server SA-MP** lewat IP (nama server, gamemode, jumlah pemain, dll) dengan auto-refresh.
- **Auto-responder** saat ada yang ketik IP server di chat.

## Struktur folder

```
.
├── index.js              # entry point, hanya bootstrap
├── package.json
├── .env                  # token & prefix (dari .env.example)
├── nexsus-samp.sqlite    # database (otomatis dibuat saat bot pertama kali jalan)
└── src/
    ├── bot.js            # setup client, routing command, auto-responder, login
    ├── config.js         # nama bot, prefix, range ID, interval monitor
    ├── commands/
    │   ├── skin.js       # !skin
    │   ├── car.js        # !car
    │   ├── help.js       # !help
    │   ├── setip.js      # !setip
    │   ├── ipedit.js     # !ipedit
    │   ├── ipdell.js     # !ipdell
    │   ├── monitor.js    # !monitor
    │   ├── monitordell.js # !monitordell
    │   └── resip.js      # !resip
    ├── services/
    │   ├── skinService.js       # cari skin + URL gambar (gta.com.ua)
    │   ├── vehicleService.js    # cari kendaraan + URL gambar (data statis)
    │   └── sampQueryService.js  # query UDP ke server SA-MP (info + rules)
    ├── database/
    │   ├── db.js             # koneksi SQLite + pembuatan tabel
    │   ├── serverRepo.js     # CRUD tabel servers (IP:port per guild)
    │   ├── monitorRepo.js    # CRUD tabel monitors (channel + message id)
    │   └── settingsRepo.js   # CRUD tabel resip_settings (on/off)
    ├── monitor/
    │   └── monitorManager.js # interval refresh 30 detik + restore saat restart
    ├── data/
    │   ├── skins.json         # 0-311 (nama)
    │   └── vehicles.json      # 400-611 (nama + URL gambar asli dari sampwiki)
    └── utils/
        ├── embeds.js     # helper embed sukses/error/hasil
        └── ipUtils.js    # parsing & validasi format IP:Port
```

## Command — Skin & Vehicle

| Command | Contoh | Keterangan |
|---|---|---|
| `!skin <id/nama>` | `!skin 1` / `!skin ballas` | Tampilkan skin (ID 0-311) |
| `!car <id/nama>` | `!car 500` / `!car mesa` | Tampilkan kendaraan (ID 400-611) |
| `!help` | `!help` | Lihat daftar command |

## Command — Monitoring Server SA-MP

**1 server Discord hanya bisa punya 1 IP SA-MP.** Set IP dulu sebelum pakai `!monitor` atau `!resip`.

| Command | Contoh | Keterangan |
|---|---|---|
| `!setip <ip:port>` | `!setip 51.222.13.10:7777` | Set IP server (sekali saja, kalau sudah ada harus pakai `!ipedit`) |
| `!ipedit <ip:port baru>` | `!ipedit 51.222.13.10:7778` | Ganti IP yang sudah diset |
| `!ipdell <ip:port aktif>` | `!ipdell 51.222.13.10:7777` | Hapus IP — wajib ketik ulang IP yang sedang aktif sebagai konfirmasi |
| `!monitor #channel` | `!monitor #status-server` | Kirim embed status server & auto-refresh **tiap 30 detik** (fix, sama untuk semua server) |
| `!monitordell` | `!monitordell` | Hentikan & hapus data monitoring di server ini |
| `!resip on` / `!resip off` | `!resip on` | Aktif/nonaktifkan auto-responder IP |

### Info yang ditampilkan `!monitor`

Nama server, gamemode, bahasa, jumlah pemain, status password, serta info tambahan dari server (map, cuaca, waktu, versi, website) — **kecuali daftar/list pemain**, itu sengaja tidak diambil sama sekali.

### Auto-responder (`!resip`)

Kalau `!resip on` (default aktif setelah IP diset) dan ada yang mengetik IP:Port server ini di channel manapun, bot otomatis balas dengan embed yang isinya cuma `IP:Port` itu saja. Matikan dengan `!resip off`.

## Cara kerja query server

Bot memakai **SA-MP Query Protocol** (UDP) langsung — tanpa API pihak ketiga:
- Opcode `i` → info dasar (hostname, gamemode, bahasa, jumlah pemain, password).
- Opcode `r` → rules server (map, cuaca, waktu, versi, dll).
- Opcode `c` (daftar pemain) **sengaja tidak dipakai**, sesuai permintaan agar list pemain tidak ditampilkan.

Kalau server tidak merespons dalam beberapa detik (timeout), embed otomatis menampilkan status **offline** dan tetap dicoba lagi tiap 30 detik.

## Database

Pakai **SQLite** (`better-sqlite3`), file `nexsus-samp.sqlite` dibuat otomatis di folder project saat bot pertama kali dijalankan. Tiga tabel: `servers`, `monitors`, `resip_settings` — semuanya di-key per Discord server (guild), jadi bot ini bisa dipakai di banyak server Discord sekaligus tanpa data ketuker.

Monitoring yang aktif otomatis dipulihkan (embed lama diedit lagi, bukan bikin baru) setiap kali bot di-restart.

## Cara kerja gambar skin/vehicle

- **Skin**: URL gambar disusun langsung dari pola situs **gta.com.ua**:
  `https://gta.com.ua/img/articles/sa/sa-mp/skins-id/skin_{id}.png`.
- **Kendaraan**: gambar di **sampwiki.blast.hk** disimpan di path MediaWiki yang di-hash, jadi ID saja tidak cukup untuk menyusun link-nya. Karena wiki tersebut tidak mendukung pemanggilan API secara live, URL asli untuk seluruh 212 kendaraan sudah diambil sekali dari halaman wiki dan disimpan statis di `src/data/vehicles.json`.

## Footer embed

Setiap hasil `!skin` dan `!car` otomatis diberi footer **"Nexsus © `{tahun berjalan}`"**, dihitung otomatis dari tanggal sistem. Bisa diubah lewat `BRAND_NAME` di `src/config.js`.

## Instalasi

1. Pastikan Node.js versi 18 ke atas sudah terpasang.
2. Install dependency:
   ```bash
   npm install
   ```
   > `better-sqlite3` adalah native module — kalau instalasi gagal karena build tools, pastikan `python3` dan compiler C++ (mis. `build-essential` di Linux / Xcode CLT di Mac / "Desktop development with C++" di Windows) sudah terpasang.
3. Salin `.env.example` menjadi `.env`, lalu isi `DISCORD_TOKEN` dengan token bot dari [Discord Developer Portal](https://discord.com/developers/applications).
4. Aktifkan **Message Content Intent** di menu Bot pada Developer Portal (wajib — bot membaca isi pesan untuk command prefix maupun auto-responder IP).
5. Jalankan bot:
   ```bash
   npm start
   ```

## Undang bot ke server

Buat invite link dari Developer Portal dengan scope `bot` dan permission minimal:
- Send Messages
- Embed Links
- Read Message History

Bot ini generik untuk server manapun bot di-invite — tidak ada guild ID yang di-hardcode di kode maupun `.env`.
