const { Client, GatewayIntentBits, ActivityType, EmbedBuilder } = require('discord.js');
const { PREFIX, BOT_NAME, TOKEN } = require('./config');
const { errorEmbed } = require('./utils/embeds');
const { findIpPortInText } = require('./utils/ipUtils');

require('./database/db'); // pastikan koneksi & tabel sudah siap sebelum dipakai repo manapun
const serverRepo = require('./database/serverRepo');
const settingsRepo = require('./database/settingsRepo');
const { restoreAllMonitors } = require('./monitor/monitorManager');

const handleSkin = require('./commands/skin');
const handleCar = require('./commands/car');
const handleHelp = require('./commands/help');
const handleSetIp = require('./commands/setip');
const handleIpEdit = require('./commands/ipedit');
const handleIpDell = require('./commands/ipdell');
const handleMonitor = require('./commands/monitor');
const handleMonitorDell = require('./commands/monitordell');
const handleResip = require('./commands/resip');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
});

client.once('clientReady', () => {
  console.log(`${BOT_NAME} online sebagai ${client.user.tag}`);
  client.user.setActivity(`${PREFIX}help | ${BOT_NAME}`, { type: ActivityType.Watching });
  restoreAllMonitors(client);
});

client.on('messageCreate', async (message) => {
  if (message.author.bot || !message.guild) return;

  if (!message.content.startsWith(PREFIX)) {
    await handleAutoResponder(message);
    return;
  }

  const args = message.content.slice(PREFIX.length).trim().split(/\s+/);
  const command = args.shift().toLowerCase();

  try {
    if (command === 'skin') {
      await handleSkin(message, args);
    } else if (command === 'car' || command === 'vehicle') {
      await handleCar(message, args);
    } else if (command === 'help' || command === 'menu') {
      await handleHelp(message);
    } else if (command === 'setip') {
      await handleSetIp(message, args);
    } else if (command === 'ipedit') {
      await handleIpEdit(message, args);
    } else if (command === 'ipdell') {
      await handleIpDell(message, args);
    } else if (command === 'monitor') {
      await handleMonitor(message, args);
    } else if (command === 'monitordell') {
      await handleMonitorDell(message, args);
    } else if (command === 'resip') {
      await handleResip(message, args);
    }
  } catch (err) {
    console.error('Command error:', err);
    await message.reply({ embeds: [errorEmbed('Terjadi kesalahan saat memproses command.')] });
  }
});

/**
 * Auto-responder: kalau ada yang ketik IP:Port yang cocok dengan IP server
 * yang sudah diset (!setip) dan !resip dalam kondisi ON, bot balas dengan
 * embed yang isinya cuma IP:Port itu saja.
 */
async function handleAutoResponder(message) {
  const server = serverRepo.getServer(message.guildId);
  if (!server) return;
  if (!settingsRepo.isResipEnabled(message.guildId)) return;

  const found = findIpPortInText(message.content);
  if (!found || found.ip !== server.ip) return;

  const embed = new EmbedBuilder().setColor(0x5865f2).setDescription(`\`${server.ip}:${server.port}\``);
  await message.reply({ embeds: [embed] });
}

client.login(TOKEN);

module.exports = client;
