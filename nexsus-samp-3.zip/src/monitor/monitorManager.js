const { EmbedBuilder } = require('discord.js');
const { MONITOR_INTERVAL_MS, BRAND_NAME } = require('../config');
const { querySampServer } = require('../services/sampQueryService');
const monitorRepo = require('../database/monitorRepo');
const serverRepo = require('../database/serverRepo');

// guildId -> intervalId. Disimpan di memori proses, dibangun ulang dari
// database (restoreAllMonitors) tiap kali bot start/restart.
const activeIntervals = new Map();

function footerText() {
  return `${BRAND_NAME} © ${new Date().getFullYear()} • Update tiap ${MONITOR_INTERVAL_MS / 1000} detik`;
}

function buildOnlineEmbed(server, data) {
  const fields = [
    { name: 'IP:Port', value: `\`${server.ip}:${server.port}\``, inline: true },
    { name: 'Gamemode', value: data.gamemode || '-', inline: true },
    { name: 'Bahasa', value: data.language || '-', inline: true },
    { name: 'Pemain', value: `${data.players}/${data.maxPlayers}`, inline: true },
    { name: 'Password', value: data.passworded ? 'Ya' : 'Tidak', inline: true },
  ];

  if (data.rules.mapname) fields.push({ name: 'Map', value: data.rules.mapname, inline: true });
  if (data.rules.weather) fields.push({ name: 'Cuaca', value: data.rules.weather, inline: true });
  if (data.rules.worldtime) fields.push({ name: 'Waktu', value: data.rules.worldtime, inline: true });
  if (data.rules.version) fields.push({ name: 'Versi', value: data.rules.version, inline: true });
  if (data.rules.weburl) fields.push({ name: 'Website', value: data.rules.weburl, inline: true });

  return new EmbedBuilder()
    .setColor(0x57f287)
    .setTitle(`🟢 ${data.hostname || 'Server SA-MP'}`)
    .addFields(fields)
    .setFooter({ text: footerText() })
    .setTimestamp();
}

function buildOfflineEmbed(server) {
  return new EmbedBuilder()
    .setColor(0xed4245)
    .setTitle('🔴 Server tidak dapat dijangkau')
    .addFields({ name: 'IP:Port', value: `\`${server.ip}:${server.port}\`` })
    .setFooter({ text: footerText() })
    .setTimestamp();
}

async function refresh(client, guildId) {
  const server = serverRepo.getServer(guildId);
  const monitor = monitorRepo.getMonitor(guildId);

  // Kalau data sudah dihapus (mis. lewat !monitordell) tapi interval lama
  // masih sempat jalan, hentikan supaya tidak nyangkut.
  if (!server || !monitor) {
    stopMonitor(guildId);
    return;
  }

  let embed;
  try {
    const data = await querySampServer(server.ip, server.port);
    embed = buildOnlineEmbed(server, data);
  } catch (err) {
    embed = buildOfflineEmbed(server);
  }

  try {
    const channel = await client.channels.fetch(monitor.channel_id);
    let message = monitor.message_id
      ? await channel.messages.fetch(monitor.message_id).catch(() => null)
      : null;

    if (message) {
      await message.edit({ embeds: [embed] });
    } else {
      const sent = await channel.send({ embeds: [embed] });
      monitorRepo.setMonitorMessageId(guildId, sent.id);
    }
  } catch (err) {
    console.error(`Gagal update monitor untuk guild ${guildId}:`, err.message);
  }
}

function startMonitor(client, guildId) {
  stopMonitor(guildId); // cegah interval dobel kalau !monitor dipanggil ulang

  refresh(client, guildId); // update pertama kali langsung, tanpa nunggu 30 detik
  const intervalId = setInterval(() => refresh(client, guildId), MONITOR_INTERVAL_MS);
  activeIntervals.set(guildId, intervalId);
}

function stopMonitor(guildId) {
  const intervalId = activeIntervals.get(guildId);
  if (intervalId) {
    clearInterval(intervalId);
    activeIntervals.delete(guildId);
  }
}

function restoreAllMonitors(client) {
  const monitors = monitorRepo.getAllMonitors();
  for (const m of monitors) {
    startMonitor(client, m.guild_id);
  }
}

module.exports = { startMonitor, stopMonitor, restoreAllMonitors };
