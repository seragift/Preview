// Menjalankan bot Discord + web dashboard dalam satu proses,
// supaya cukup 1 panel/startup command saja, dan dashboard bisa
// ambil data + broadcast realtime langsung dari client bot yang sama.

console.log('=== Starting Discord bot (index.js) ===');
const client = require('./index.js');

console.log('=== Starting dashboard server (server.js) ===');
const startServer = require('./server.js');
startServer(client);
