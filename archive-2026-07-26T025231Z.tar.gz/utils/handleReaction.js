const handleExp = require('./handleExp');

const dbEvents = require('./dbEvents');

module.exports = (client, userId) => {

    try {

        // 1. Pastikan user terdaftar di database

        // Kita set default nilai level 1 dan xp 0 jika baru masuk

        client.db.prepare("INSERT OR IGNORE INTO users (userId, level, xp, tokens, messages, reactions, voiceMins) VALUES (?, 1, 0, 0, 0, 0, 0)").run(userId);

        // 2. Update jumlah reaction

        const update = client.db.prepare("UPDATE users SET reactions = reactions + 1 WHERE userId = ?").run(userId);

        if (update.changes > 0) {

            console.log(`[DB] Berhasil menambah 1 reaction untuk user: ${userId}`);

            dbEvents.emit('usersChanged');

        }

        // 3. Beri XP (10 XP per reaction)

        handleExp(client, userId, 10);

    } catch (error) {

        console.error(`[ERROR] Gagal memproses handleReaction untuk ${userId}:`, error.message);

    }

};