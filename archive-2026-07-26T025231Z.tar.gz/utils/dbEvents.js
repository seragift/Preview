// Event bus kecil supaya bot & dashboard bisa "ngobrol" dalam satu proses.
// Setiap kali tabel `users` berubah (xp naik, voice minutes nambah, dst),
// modul lain tinggal panggil dbEvents.emit('usersChanged') dan
// server.js akan langsung broadcast data terbaru ke semua client dashboard
// lewat Socket.io — tanpa perlu polling manual dari browser.

const EventEmitter = require('events');

class DbEvents extends EventEmitter {}

module.exports = new DbEvents();
