const handleExp = require('./handleExp');

const dbEvents = require('./dbEvents');

// Menyimpan ID interval untuk setiap user agar bisa dihentikan saat keluar

const voiceIntervals = new Map();

module.exports = (client, oldState, newState) => {

    const userId = newState.id;

    const guildId = newState.guild.id;

    // 1. USER JOIN (Masuk ke voice channel)

    if (!oldState.channelId && newState.channelId) {

        if (newState.member.user.bot) return;

        console.log(`[VOICE] ${newState.member.user.username} join. Memulai hitungan menit...`);

        // Set interval untuk cek setiap 60 detik (1 menit)

        const interval = setInterval(() => {

            // Update database menit voice

            client.db.prepare("INSERT OR IGNORE INTO users (userId) VALUES (?)").run(userId);

            client.db.prepare("UPDATE users SET voiceMins = voiceMins + 1 WHERE userId = ?").run(userId);

            dbEvents.emit('usersChanged');

            // Beri XP (Misal 60 XP per menit)

            handleExp(client, userId, 60);

            console.log(`[VOICE] 1 Menit berlalu untuk ${newState.member.user.username}. Data diupdate.`);

        }, 60000);

        // Simpan interval ke Map

        voiceIntervals.set(userId, interval);

    }

    // 2. USER LEAVE (Keluar dari voice channel)

    else if (oldState.channelId && !newState.channelId) {

        const interval = voiceIntervals.get(userId);

        

        if (interval) {

            clearInterval(interval); // Hentikan hitungan menit

            voiceIntervals.delete(userId);

            console.log(`[VOICE] ${newState.member.user.username} keluar. Hitungan dihentikan.`);

        }

    }

    // 3. PINDAH CHANNEL

    // Jika hanya pindah channel, kita tidak perlu menghentikan interval.

};