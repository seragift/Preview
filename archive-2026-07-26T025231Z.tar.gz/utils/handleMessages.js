const handleExp = require('./handleExp');

const dbEvents = require('./dbEvents');

// ======================

// XP COOLDOWN

// ======================

const xpCooldown = new Map();

module.exports = async (client, message) => {

    if (!message.guild || message.author.bot) return;

    const userId = message.author.id;

    // ======================

    // INIT USER

    // ======================

    client.db.prepare(`

        INSERT OR IGNORE INTO users (userId) VALUES (?)

    `).run(userId);

    // ======================

    // MESSAGE COUNT

    // ======================

    client.db.prepare(`

        UPDATE users SET messages = messages + 1 WHERE userId = ?

    `).run(userId);

    dbEvents.emit('usersChanged');

    // ======================

    // XP COOLDOWN

    // ======================

    const now = Date.now();

    const cooldown = 1000;

    if (xpCooldown.has(userId)) {

        const expire = xpCooldown.get(userId);

        if (now < expire) return;

    }

    xpCooldown.set(userId, now + cooldown);

    // ======================

    // ADD XP + REALTIME ROLE UPDATE 🔥

    // ======================

    await handleExp(client, userId, 20, message);

};