const { EmbedBuilder } = require("discord.js");

function getTextLeaderboard(client) {

    return client.db

        .prepare("SELECT userId, level, xp FROM users ORDER BY level DESC, xp DESC LIMIT 10")

        .all();

}

function createLeaderboardEmbed(users) {

    if (!users.length) {

        return { content: "Belum ada data leaderboard." };

    }

    const medals = ["🥇", "🥈", "🥉"];

    const description = users.map((user, i) => {

        const rank = medals[i] || `**${i + 1}.**`;

        return `${rank} <@${user.userId}>\nLevel: **${user.level}** | XP: **${user.xp}**`;

    }).join("\n\n");

    const embed = new EmbedBuilder()

        .setTitle("🏆 Leaderboard Top 10")

        .setDescription(description)

        .setColor(0x00AE86)

        .setTimestamp();

    return { embeds: [embed] };

}

module.exports = {

    getTextLeaderboard,

    createLeaderboardEmbed

};