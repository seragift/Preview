const { EmbedBuilder } = require("discord.js");

// Ambil top chat dari DB

function getTopChat(client) {

    try {

        return client.db

            .prepare("SELECT userId, messages FROM users ORDER BY messages DESC LIMIT 10")

            .all();

    } catch (err) {

        console.error("Error ambil top chat:", err);

        return [];

    }

}

// Buat embed

function createTopChatEmbed(users, message) {

    if (!users.length) {

        return { content: "Belum ada data chat." };

    }

    const medals = ["🥇", "🥈", "🥉"];

    const description = users.map((user, i) => {

        const rank = medals[i] || `**${i + 1}.**`;

        return `${rank} <@${user.userId}>\n💬 Messages: **${user.messages}**`;

    }).join("\n\n");

    const embed = new EmbedBuilder()

        .setTitle("💬 Top Chat Leaderboard")

        .setDescription(description)

        .setColor(0xF1C40F)

        .setFooter({

            text: `Requested by ${message.author.username}`

        })

        .setTimestamp();

    return { embeds: [embed] };

}

module.exports = {

    getTopChat,

    createTopChatEmbed

};