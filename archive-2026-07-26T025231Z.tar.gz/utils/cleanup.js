const dbEvents = require('./dbEvents');

// ======================
// HAPUS DATA 1 USER
// ======================
function removeUserData(client, userId) {
    const exists = client.db.prepare('SELECT 1 FROM users WHERE userId = ?').get(userId);

    client.db.prepare('DELETE FROM users WHERE userId = ?').run(userId);
    client.db.prepare('DELETE FROM temp_roles WHERE userId = ?').run(userId);
    client.db.prepare('DELETE FROM afk WHERE userId = ?').run(userId);

    if (exists) {
        console.log(`[CLEANUP] Data level user ${userId} dihapus (sudah tidak ada di server).`);
        dbEvents.emit('usersChanged');
    }
}

// ======================
// SYNC SEMUA MEMBER GUILD
// Dipanggil saat bot startup untuk bersih-bersih user yang
// keluar server selagi bot offline.
// ======================
async function syncGuildMembers(client, guild) {
    try {
        const members = await guild.members.fetch();
        const memberIds = new Set(members.keys());

        const rows = client.db.prepare('SELECT userId FROM users').all();
        let removed = 0;

        for (const row of rows) {
            if (!memberIds.has(row.userId)) {
                removeUserData(client, row.userId);
                removed++;
            }
        }

        if (removed > 0) {
            console.log(`[CLEANUP] Sync startup selesai: ${removed} user dihapus (sudah keluar server).`);
        }
    } catch (err) {
        console.error('[CLEANUP] Gagal sync member guild:', err.message);
    }
}

module.exports = { removeUserData, syncGuildMembers };
