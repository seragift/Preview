const ROLE_PREFIX = "Top Leaderboard #";

// ======================

// CACHE SYSTEM 🔥

// ======================

let lastTop = [];

// ======================

// WARNA TIAP RANK 🎨

// ======================

const roleColors = {

    1: 0xFFD700, // gold

    2: 0xC0C0C0, // silver

    3: 0xCD7F32, // bronze

    4: 0x9B59B6,

    5: 0x3498DB,

    6: 0x1ABC9C,

    7: 0x2ECC71,

    8: 0xF1C40F,

    9: 0xE67E22,

    10: 0xE74C3C

};

// ======================

// GET / CREATE ROLE

// ======================

async function getOrCreateRole(guild, rank) {

    const roleName = `${ROLE_PREFIX}${rank}`;

    let role = guild.roles.cache.find(r => r.name === roleName);

    if (!role) {

        role = await guild.roles.create({

            name: roleName,

            color: roleColors[rank] || 0xffffff,

            reason: "Auto leaderboard role"

        });

    }

    return role;

}

// ======================

// CEK PERUBAHAN CACHE

// ======================

function isChanged(newTop) {

    if (newTop.length !== lastTop.length) return true;

    for (let i = 0; i < newTop.length; i++) {

        if (newTop[i].userId !== lastTop[i]?.userId) return true;

    }

    return false;

}

// ======================

// UPDATE ROLES

// ======================

async function updateLeaderboardRoles(client, guild) {

    const top = client.db.prepare(`

        SELECT userId FROM users 

        ORDER BY level DESC, xp DESC 

        LIMIT 10

    `).all();

    // 🚀 CEK CACHE

    if (!isChanged(top)) return;

    console.log("[LEADERBOARD ROLE] Updating...");

    lastTop = top;

    const members = await guild.members.fetch();

    for (const member of members.values()) {

        const index = top.findIndex(u => u.userId === member.id);

        const rank = index !== -1 ? index + 1 : null;

        // ======================

        // REMOVE OLD ROLES

        // ======================

        for (let i = 1; i <= 10; i++) {

            const roleName = `${ROLE_PREFIX}${i}`;

            const role = guild.roles.cache.find(r => r.name === roleName);

            if (role && member.roles.cache.has(role.id)) {

                await member.roles.remove(role).catch(() => {});

            }

        }

        // ======================

        // ADD NEW ROLE

        // ======================

        if (rank) {

            const role = await getOrCreateRole(guild, rank);

            await member.roles.add(role).catch(() => {});

        }

    }

    console.log("[LEADERBOARD ROLE] Updated!");

}

module.exports = {

    updateLeaderboardRoles

};