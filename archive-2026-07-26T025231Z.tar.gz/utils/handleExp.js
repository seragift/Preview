const { EmbedBuilder } = require('discord.js');

const { updateLeaderboardRoles } = require('./leaderboardRole');

const dbEvents = require('./dbEvents');

// ======================

// PROGRESS BAR

// ======================

function progressBar(current, max) {

    const size = 12;

    const percent = current / max;

    const progress = Math.round(size * percent);

    const bar = "▰".repeat(progress) + "▱".repeat(size - progress);

    const percentText = Math.floor(percent * 100);

    return `${bar} ${percentText}%`;

}

// ======================

// GET RANK

// ======================

function getUserRank(client, userId) {

    const users = client.db.prepare(`

        SELECT userId, level, xp 

        FROM users 

        ORDER BY level DESC, xp DESC

    `).all();

    const index = users.findIndex(u => u.userId === userId);

    return index === -1 ? "?" : index + 1;

}

module.exports = async (client, userId, amount, message) => {

    let user = client.db.prepare("SELECT * FROM users WHERE userId = ?").get(userId);

    if (!user) {

        client.db.prepare("INSERT INTO users (userId, xp, level, tokens) VALUES (?, ?, ?, 0)")

            .run(userId, amount, 1);

        dbEvents.emit('usersChanged');

        return;

    }

    let newXp = user.xp + amount;

    let nextLevelXp = user.level * 300;

    let leveledUp = false;

    if (newXp >= nextLevelXp) {

        const newLevel = user.level + 1;

        const rewardTokens = client.config.tokenPerLevel;

        const totalTokens = (user.tokens || 0) + rewardTokens;

        const remainingXp = newXp - nextLevelXp;

        client.db.prepare(`

            UPDATE users SET xp = ?, level = ?, tokens = ? WHERE userId = ?

        `).run(remainingXp, newLevel, totalTokens, userId);

        leveledUp = true;

        // ======================

        // EMBED UPGRADE 🔥

        // ======================

        const logChannel = client.channels.cache.get(client.config.logChannelId);

        if (logChannel) {

            const rank = getUserRank(client, userId);

            const maxXp = newLevel * 300;

            const embed = new EmbedBuilder()

                .setColor(0xFFD700)

                .setThumbnail(client.users.cache.get(userId)?.displayAvatarURL({ dynamic: true }))

                .setTitle("🎉 LEVEL UP!")

                .setDescription(`🔥 <@${userId}> berhasil naik ke **Level ${newLevel}**!\nTerus aktif untuk naik leaderboard 🚀`)

                .addFields(

                    {

                        name: "📈 Level",

                        value: `\`${user.level} ➜ ${newLevel}\``,

                        inline: true

                    },

                    {

                        name: "🏆 Rank",

                        value: `**#${rank}**`,

                        inline: true

                    },

                    {

                        name: "⭐ XP",

                        value: `\`${remainingXp} / ${maxXp}\``,

                        inline: true

                    },

                    {

                        name: "📊 Progress",

                        value: progressBar(remainingXp, maxXp)

                    },

                    {

                        name: "🎁 Reward",

                        value: `💎 +${rewardTokens} Tokens\n💰 Total: ${totalTokens}`

                    }

                )

                .setFooter({

                    text: `Level System`,

                    iconURL: client.user.displayAvatarURL()

                })

                .setTimestamp();

            logChannel.send({ content: `<@${userId}>`, embeds: [embed] });

        }

    } else {

        client.db.prepare("UPDATE users SET xp = ? WHERE userId = ?")

            .run(newXp, userId);

    }

    // ======================

    // 🔥 REALTIME DASHBOARD UPDATE

    // ======================

    dbEvents.emit('usersChanged');

    // ======================

    // 🔥 REALTIME ROLE UPDATE

    // ======================

    if (leveledUp && message?.guild) {

        try {

            await updateLeaderboardRoles(client, message.guild);

        } catch (err) {

            console.error("Role Update Error:", err.message);

        }

    }

};