const { EmbedBuilder } = require("discord.js");

// ======================

// INIT TABLE

// ======================

function initAFKTable(client) {

    client.db.prepare(`

        CREATE TABLE IF NOT EXISTS afk (

            userId TEXT PRIMARY KEY,

            reason TEXT,

            since INTEGER

        )

    `).run();

}

// ======================

// SET AFK

// ======================

async function setAFK(client, message, reason) {

    const userId = message.author.id;

    client.db.prepare(`

        INSERT OR REPLACE INTO afk (userId, reason, since)

        VALUES (?, ?, ?)

    `).run(userId, reason, Date.now());

    // Ubah nickname jadi [AFK]

    try {

        const member = message.member;

        if (member && member.manageable) {

            const currentName = member.nickname || member.user.username;

            if (!currentName.startsWith("[AFK]")) {

                await member.setNickname(`[AFK] ${currentName}`);

            }

        }

    } catch (err) {

        console.log("Gagal ubah nickname:", err.message);

    }

}

// ======================

// GET AFK

// ======================

function getAFK(client, userId) {

    return client.db.prepare(`

        SELECT * FROM afk WHERE userId = ?

    `).get(userId);

}

// ======================

// REMOVE AFK

// ======================

async function removeAFK(client, message) {

    const userId = message.author.id;

    const data = getAFK(client, userId);

    client.db.prepare(`

        DELETE FROM afk WHERE userId = ?

    `).run(userId);

    // Balikin nickname

    try {

        const member = message.member;

        if (member && member.manageable) {

            const currentName = member.nickname || member.user.username;

            if (currentName.startsWith("[AFK] ")) {

                const newName = currentName.replace("[AFK] ", "");

                await member.setNickname(newName);

            }

        }

    } catch (err) {

        console.log("Gagal balikin nickname:", err.message);

    }

    return data;

}

// ======================

// GET ALL AFK

// ======================

function getAllAFK(client) {

    return client.db.prepare(`

        SELECT * FROM afk ORDER BY since DESC

    `).all();

}

// ======================

// FORMAT DURASI

// ======================

function formatDuration(ms) {

    const seconds = Math.floor(ms / 1000);

    const m = Math.floor(seconds / 60);

    const h = Math.floor(m / 60);

    return `${h}h ${m % 60}m`;

}

// ======================

// EMBED SET AFK 🔥

// ======================

function afkSetEmbed(message, reason) {

    const user = message.author;

    const embed = new EmbedBuilder()

        .setColor(0xF1C40F)

        .setAuthor({

            name: `${user.username} sekarang AFK`,

            iconURL: user.displayAvatarURL({ dynamic: true })

        })

        .setDescription(`💤 **Status AFK diaktifkan**\n\n📝 **Alasan:**\n> ${reason}`)

        .setThumbnail(user.displayAvatarURL({ dynamic: true }))

        .setFooter({

            text: `User ID: ${user.id}`

        })

        .setTimestamp();

    return { embeds: [embed] };

}

// ======================

// EMBED BALIK 🔥

// ======================

function afkBackEmbed(message, duration) {

    const user = message.author;

    const embed = new EmbedBuilder()

        .setColor(0x2ECC71)

        .setAuthor({

            name: `${user.username} kembali dari AFK`,

            iconURL: user.displayAvatarURL({ dynamic: true })

        })

        .setDescription(

            `👋 **Welcome back!**\n\n⏱️ Kamu AFK selama:\n> **${duration}**`

        )

        .setThumbnail(user.displayAvatarURL({ dynamic: true }))

        .setTimestamp();

    return { embeds: [embed] };

}

// ======================

// EMBED MENTION 🔥

// ======================

function afkMentionEmbed(userId, reason, duration, client) {

    const user = client.users.cache.get(userId);

    const embed = new EmbedBuilder()

        .setColor(0xE74C3C)

        .setAuthor({

            name: `${user?.username || "User"} sedang AFK`,

            iconURL: user?.displayAvatarURL({ dynamic: true })

        })

        .setDescription(

            `🚫 <@${userId}> sedang tidak tersedia\n\n` +

            `📝 **Alasan:**\n> ${reason}\n\n` +

            `⏱️ **Durasi AFK:**\n> ${duration}`

        )

        .setThumbnail(user?.displayAvatarURL({ dynamic: true }))

        .setTimestamp();

    return { embeds: [embed] };

}

// ======================

// EMBED LIST AFK 🔥

// ======================

function afkListEmbed(data) {

    if (!data.length) {

        return {

            embeds: [

                new EmbedBuilder()

                    .setColor(0xE74C3C)

                    .setDescription("❌ Tidak ada user yang sedang AFK.")

            ]

        };

    }

    const now = Date.now();

    let desc = "";

    data.forEach((u, i) => {

        const duration = formatDuration(now - u.since);

        desc += `**${i + 1}.** <@${u.userId}>\n`;

        desc += `📝 ${u.reason}\n`;

        desc += `⏱️ AFK selama: ${duration}\n\n`;

    });

    const embed = new EmbedBuilder()

        .setColor(0xF1C40F)

        .setTitle("💤 Daftar User AFK")

        .setDescription(desc)

        .setFooter({

            text: `Total: ${data.length} user AFK`

        })

        .setTimestamp();

    return { embeds: [embed] };

}

// ======================

// EXPORT

// ======================

module.exports = {

    initAFKTable,

    setAFK,

    getAFK,

    removeAFK,

    getAllAFK,

    afkSetEmbed,

    afkBackEmbed,

    afkMentionEmbed,

    afkListEmbed,

    formatDuration

};