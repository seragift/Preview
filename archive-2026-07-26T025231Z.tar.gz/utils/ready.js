const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, AttachmentBuilder, Events } = require('discord.js');

const handleVoice = require('../utils/handleVoice');

const fs = require('fs');

module.exports = async (client) => {

    // Mengubah log menjadi info event clientReady

    console.log(`[Event: clientReady] Logged in as ${client.user.username}`);

    

    // --- LOGIKA AUTO-RESUME VOICE ---

    client.guilds.cache.forEach(guild => {

        guild.channels.cache.forEach(channel => {

            if (channel.isVoiceBased()) {

                channel.members.forEach(member => {

                    if (member.user.bot) return;

                    handleVoice(client, 

                        { channelId: null }, 

                        { id: member.id, guild: guild, channelId: channel.id, member: member }

                    );

                });

            }

        });

    });

    // --- LOGIKA REDEEM PANEL ---

    const channel = client.channels.cache.get(client.config.redeemPanelChannelId);

    if (channel) {

        const embed = new EmbedBuilder()

            .setTitle("🎁 ✨ REDEEM PANEL ✨")

            .setColor("LuminousVividPink")

            .setThumbnail(client.user.displayAvatarURL())

            .setDescription(`

🍱 **Cara Mendapat Poin:**

• Naik level = **+${client.config.tokenPerLevel} 💎** poin

• Aktif di chat, reaction, dan voice

• Semakin aktif, semakin banyak poin!

🎁 **Redeem Items Available:**

• 🏷️ Role Sementara (7/14/30 hari)

• 🎨 Custom Nickname

✨ **Gunakan poin dengan bijak!** • Leveling System v4.0

            `)

            .setFooter({ text: `Echo lounge Leveling System`, iconURL: client.user.displayAvatarURL() });

        const row = new ActionRowBuilder().addComponents(

            new ButtonBuilder().setCustomId('my_profile').setLabel('My Profile').setEmoji('📋').setStyle(ButtonStyle.Primary),

            new ButtonBuilder().setCustomId('leaderboard').setLabel('Leaderboard').setEmoji('🏆').setStyle(ButtonStyle.Secondary),

            new ButtonBuilder().setCustomId('menu_redeem').setLabel('Redeem Menu').setEmoji('🎁').setStyle(ButtonStyle.Success)

        );

        await channel.bulkDelete(5).catch(() => {});

        channel.send({ embeds: [embed], components: [row] });

    }

    // --- LOGIKA AUTO SAVE & EXPORT DATABASE ---

    // Melakukan backup setiap 6 jam

    setInterval(async () => {

        const backupChannel = client.channels.cache.get(client.config.backupChannelId);

        if (!backupChannel) return;

        const dbPath = './levels.db';

        if (fs.existsSync(dbPath)) {

            const attachment = new AttachmentBuilder(dbPath, { name: `backup-levels-${Date.now()}.db` });

            

            const backupEmbed = new EmbedBuilder()

                .setTitle("💾 Database Auto-Backup")

                .setColor("Blue")

                .setDescription(`Sistem berhasil mengekspor database leveling secara otomatis.\n\n📅 **Waktu:** ${new Date().toLocaleString('id-ID')}`)

                .setFooter({ text: "Database Security System" });

            await backupChannel.send({ embeds: [backupEmbed], files: [attachment] });

        }

    }, 21600000); // 6 jam dalam milidetik

};