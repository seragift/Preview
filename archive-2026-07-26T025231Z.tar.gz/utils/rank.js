const { EmbedBuilder } = require("discord.js");

// ======================

// PROGRESS BAR

// ======================

function generateBar(percent, size = 14) {

    const filled = Math.round(size * percent);

    const empty = size - filled;

    return "▰".repeat(filled) + "▱".repeat(empty) + ` ${Math.round(percent * 100)}%`;

}

// ======================

// VOICE FORMAT

// ======================

function formatVoice(sec) {

    const h = Math.floor(sec / 3600);

    const m = Math.floor((sec % 3600) / 60);

    return `${h}h ${m}m`;

}

// ======================

// RANK ICON

// ======================

function getRankIcon(rank) {

    if (rank === 1) return "🥇";

    if (rank === 2) return "🥈";

    if (rank === 3) return "🥉";

    return "🏅";

}

// ======================

// FAKE GRADIENT TEXT

// ======================

function gradientText(text) {

    return `✨ ${text} ✨`;

}

// ======================

// MAIN FUNCTION

// ======================

async function createRankEmbed(client, data, message, user) {

    const level = data.level;

    const xp = data.xp;

    const nextXp = level * 300;

    const percent = xp / nextXp;

    const rankIcon = getRankIcon(data.rank);

    // ======================

    // BADGES

    // ======================

    const badges = [];

    if (data.rank <= 3) badges.push("🏆 Elite");

    if (data.messages > 1000) badges.push("💬 Talkative");

    if (data.voice > 36000) badges.push("🎤 VC Master");

    if (data.level >= 10) badges.push("🔥 Grinder");

    const badgeLine = badges.join(" • ") || "—";

    // ======================

    // SEND BASE MESSAGE

    // ======================

    const msg = await message.reply({ content: "⚡ Loading profile..." });

    // ======================

    // ANIMATION LOOP 🎬

    // ======================

    for (let i = 0; i <= percent; i += 0.1) {

        const bar = generateBar(i);

        const embed = new EmbedBuilder()

            .setColor("#111111") // 🔥 dark elite

            .setAuthor({

                name: `${gradientText(user.username)}`,

                iconURL: user.displayAvatarURL()

            })

            .setDescription(

                `${rankIcon} **Rank #${data.rank}**\n` +

                `Level **${level}**\n\n` +

                `\`${bar}\`\n\n` +

                `✧ XP: **${xp} / ${nextXp}**\n` +

                `✧ Tokens: **${data.tokens || 0}**\n\n` +

                `✧ Messages: **${data.messages}**\n` +

                `✧ Voice: **${formatVoice(data.voice)}**\n\n` +

                `**${badgeLine}**`

            )

            .setThumbnail(user.displayAvatarURL())

            .setFooter({

                text: "Echo Ultra Profile ⚡"

            });

        await msg.edit({ content: "", embeds: [embed] });

        await new Promise(r => setTimeout(r, 80)); // ⚡ smooth tapi ringan

    }

    return;

}

module.exports = { createRankEmbed };