const { EmbedBuilder } = require("discord.js");

// ======================

// FORMAT TIME

// ======================

function formatTime(ms) {

    const s = Math.floor(ms / 1000);

    const m = Math.floor(s / 60);

    const h = Math.floor(m / 60);

    const d = Math.floor(h / 24);

    return `${d}d ${h % 24}h ${m % 60}m`;

}

// ======================

// FORMAT DATE

// ======================

function formatDate(timestamp) {

    return `<t:${Math.floor(timestamp / 1000)}:F>`;

}

// ======================

// GET TEMP ROLES

// ======================

function getTempRoles(client, guildId) {

    return client.db.prepare(`

        SELECT * FROM temp_roles WHERE guildId = ?

    `).all(guildId);

}

// ======================

// MULTI EMBED (5 PER PAGE)

// ======================

function createTempRoleEmbeds(client, roles, guild) {

    if (!roles.length) {

        return [

            new EmbedBuilder()

                .setColor(0xE74C3C)

                .setDescription("❌ Tidak ada temp role aktif.")

        ];

    }

    const perPage = 5;

    const embeds = [];

    for (let i = 0; i < roles.length; i += perPage) {

        const chunk = roles.slice(i, i + perPage);

        let desc = "";

        chunk.forEach((r, index) => {

            const role = guild.roles.cache.get(r.roleId);

            const now = Date.now();

            const remaining = r.expiry - now;

            desc += `╭━━━━━━━━━━━━━━━━━━╮\n`;

            desc += `**${i + index + 1}. ${role ? role.name : "Role tidak ditemukan"}**\n`;

            desc += `╰━━━━━━━━━━━━━━━━━━╯\n`;

            desc += `👤 User: <@${r.userId}>\n`;

            desc += `🆔 Role ID: \`${r.roleId}\`\n`;

            desc += `📅 Expired: ${formatDate(r.expiry)}\n`;

            desc += `⏳ Sisa: ${remaining > 0 ? formatTime(remaining) : "Expired"}\n\n`;

        });

        const embed = new EmbedBuilder()

            .setColor(0x5865F2)

            .setTitle(`⏳ Temp Roles Aktif • Page ${Math.floor(i / perPage) + 1}`)

            .setDescription(

                `📦 Total: **${roles.length} role**\n\n` +

                desc

            )

            .setFooter({

                text: `Page ${Math.floor(i / perPage) + 1} / ${Math.ceil(roles.length / perPage)}`

            })

            .setTimestamp();

        embeds.push(embed);

    }

    return embeds;

}

module.exports = {

    getTempRoles,

    createTempRoleEmbeds

};