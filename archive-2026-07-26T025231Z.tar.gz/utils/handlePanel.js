const { EmbedBuilder } = require('discord.js');

// ======================

// 📊 PROGRESS BAR

// ======================

function createBar(current, max, size = 12) {

    const percent = Math.floor((current / max) * size);

    return "▰".repeat(percent) + "▱".repeat(size - percent);

}

// ======================

// 🏆 GET RANK

// ======================

function getRank(client, userId) {

    const users = client.db.prepare(`

        SELECT userId FROM users ORDER BY level DESC, xp DESC

    `).all();

    return users.findIndex(u => u.userId === userId) + 1;

}

module.exports = {

    // ======================

    // 🧾 PROFILE (ULTRA CLEAN)

    // ======================

    getProfile: (client, userId) => {

        const user = client.db.prepare(

            "SELECT * FROM users WHERE userId = ?"

        ).get(userId);

        if (!user) {

            return new EmbedBuilder()

                .setColor("Red")

                .setDescription("❌ User belum memiliki data.");

        }

        const level = user.level || 1;

        const xp = user.xp || 0;

        const nextXP = level * 300;

        const totalXp = ((level - 1) * 300) + xp;

        const percent = Math.floor((xp / nextXP) * 100);

        const bar = createBar(xp, nextXP);

        const rank = getRank(client, userId);

        const member = client.guilds.cache

            .get(client.config.guildId)

            ?.members.cache.get(userId);

        const avatar = member?.user.displayAvatarURL({ dynamic: true }) 

            || client.user.displayAvatarURL();

        return new EmbedBuilder()

            .setColor("#5865F2")

            .setAuthor({

                name: member?.user.username || "Unknown User",

                iconURL: avatar

            })

            .setThumbnail(avatar)

            .setDescription(

                `╭━━━━━━━━━━━━━━━━━━╮\n` +

                `┃ ${bar} ┃\n` +

                `╰━━━━━━━━━━━━━━━━━━╯\n` +

                `📊 **${percent}% Progress**\n\n` +

                `🏆 **Rank:** #${rank}\n` +

                `📈 **Level:** ${level}\n` +

                `⭐ **XP:** ${xp} / ${nextXP}\n` +

                `🎯 **Total XP:** ${totalXp}\n\n` +

                `💎 **Tokens:** ${user.tokens || 0}\n` +

                `💬 **Messages:** ${user.messages || 0}\n` +

                `😀 **Reactions:** ${user.reactions || 0}\n` +

                `🎧 **Voice:** ${user.voiceMins || 0} min\n\n` +

                `━━━━━━━━━━━━━━━━━━━`

            )

            .setFooter({

                text: "Echo Profile • Advanced System",

                iconURL: client.user.displayAvatarURL()

            })

            .setTimestamp();

    },

    // ======================

    // 🏆 LEADERBOARD (PREMIUM)

    // ======================

    getLeaderboard: (client, userId) => {

        const top = client.db.prepare(`

            SELECT userId, level, xp 

            FROM users 

            ORDER BY level DESC, xp DESC 

            LIMIT 10

        `).all();

        const all = client.db.prepare(`

            SELECT userId 

            FROM users 

            ORDER BY level DESC, xp DESC

        `).all();

        const rank = all.findIndex(x => x.userId === userId) + 1;

        const medals = ['🥇', '🥈', '🥉'];

        const list = top.length > 0

            ? top.map((u, i) => {

                const icon = medals[i] || `\`#${i + 1}\``;

                return (

                    `${icon} <@${u.userId}>\n` +

                    `┗ 📈 Level **${u.level}** • ⭐ ${u.xp} XP`

                );

            }).join('\n\n')

            : "Belum ada data.";

        return new EmbedBuilder()

            .setColor("#F1C40F")

            .setAuthor({

                name: "🏆 GLOBAL LEADERBOARD",

            })

            .setDescription(

                `╭━━━━━━━━━━━━━━━━━━╮\n` +

                `┃ TOP 10 PLAYER 🔥 ┃\n` +

                `╰━━━━━━━━━━━━━━━━━━╯\n\n` +

                list

            )

            .addFields({

                name: "📊 YOUR POSITION",

                value: `🏆 Rank **#${rank || "N/A"}** dari **${all.length} user**`,

            })

            .setFooter({

                text: "Keep grinding 💀",

                iconURL: client.user.displayAvatarURL()

            })

            .setTimestamp();

    }

};