const { 

    getTextLeaderboard, 

    createLeaderboardEmbed

} = require("./leaderboard");

const { 

    getTopVoice, 

    createTopVoiceEmbed 

} = require("./topvoice");

const {

    getTopChat,

    createTopChatEmbed

} = require("./topchat");

const {

    setAFK,

    afkSetEmbed,

    getAllAFK,

    afkListEmbed

} = require("./afk");

const {

    getTempRoles,

    createTempRoleEmbeds // 🔥 UPDATE

} = require("./temprole");

const {

    getRank,

    createRankEmbed

} = require("./rank");

const { EmbedBuilder } = require("discord.js");

module.exports = async (client, message, command, args) => {

    try {

        if (!message.guild || message.author.bot) return;

        // ======================

        // LEADERBOARD XP

        // ======================

        if (command === "leaderboard") {

            const data = getTextLeaderboard(client);

            return message.reply(createLeaderboardEmbed(data));

        }

        // ======================

        // TOP VOICE

        // ======================

        if (command === "topvoice") {

            const data = getTopVoice(client);

            return message.reply(createTopVoiceEmbed(data, message));

        }

        // ======================

        // TOP CHAT

        // ======================

        if (command === "topchat") {

            const data = getTopChat(client);

            return message.reply(createTopChatEmbed(data, message));

        }

        // ======================

        // RANK

        // ======================

        if (command === "rank") {

            let user = message.author;

            // mention

            if (message.mentions.users.first()) {

                user = message.mentions.users.first();

            }

            // ID user

            if (args[0] && /^\d+$/.test(args[0])) {

                try {

                    const fetched = await client.users.fetch(args[0]);

                    if (fetched) user = fetched;

                } catch {}

            }

            const data = getRank(client, user.id);

            return message.reply(

                createRankEmbed(client, data, message, user)

            );

        }

        // ======================

        // AFK

        // ======================

        if (command === "afk") {

            const reason = args.join(" ") || "Tidak ada alasan";

            await setAFK(client, message, reason);

            return message.reply(afkSetEmbed(message, reason));

        }

        // ======================

        // AFK LIST

        // ======================

        if (command === "afklist" || command === "asklist") {

            const data = getAllAFK(client);

            return message.reply(afkListEmbed(data));

        }

        // ======================

        // TEMP ROLE LIST (MULTI EMBED 🔥)

        // ======================

        if (command === "temprole") {

            const data = getTempRoles(client, message.guild.id);

            const embeds = createTempRoleEmbeds(client, data, message.guild);

            // optional: hapus command biar clean

            // await message.delete().catch(() => {});

            for (const embed of embeds) {

                await message.channel.send({ embeds: [embed] });

            }

            return;

        }

        // ======================

        // PROFILE PICTURE (.pp)

        // ======================

        if (command === "pp") {

            let user = message.author;

            // 1. Reply

            if (message.reference?.messageId) {

                try {

                    const replied = await message.channel.messages.fetch(message.reference.messageId);

                    if (replied?.author) user = replied.author;

                } catch {}

            }

            // 2. Mention

            if (message.mentions.users.first()) {

                user = message.mentions.users.first();

            }

            // 3. ID USER 🔥

            if (args[0] && /^\d+$/.test(args[0])) {

                try {

                    const fetchedUser = await client.users.fetch(args[0]);

                    if (fetchedUser) user = fetchedUser;

                } catch {

                    return message.reply("❌ User dengan ID tersebut tidak ditemukan.");

                }

            }

            const avatar = user.displayAvatarURL({

                size: 1024,

                dynamic: true

            });

            const embed = new EmbedBuilder()

                .setColor("#5865F2")

                .setAuthor({

                    name: `Avatar • ${user.username}`,

                    iconURL: avatar

                })

                .setImage(avatar)

                .setFooter({

                    text: `Requested by ${message.author.username}`

                })

                .setTimestamp();

            return message.reply({ embeds: [embed] });

        }

        // ======================

        // PING

        // ======================

        if (command === "ping") {

            return message.reply("Pong!");

        }

    } catch (err) {

        console.error("Command Error:", err);

        return message.reply("❌ Terjadi error saat menjalankan command.");

    }

};