const { 

    getAFK, 

    removeAFK, 

    afkBackEmbed, 

    afkMentionEmbed, 

    formatDuration 

} = require("./afk");

// 🔥 anti spam

const cooldown = new Map();

module.exports = async (client, message) => {

    const userId = message.author.id;

    // ======================

    // 1. BALIK DARI AFK

    // ======================

    const afkData = getAFK(client, userId);

    if (afkData) {

        const data = await removeAFK(client, message);

        const duration = formatDuration(Date.now() - data.since);

        return message.reply(afkBackEmbed(message, duration)); // 🔥 STOP DI SINI

    }

    // ======================

    // 2. CEK MENTION AFK

    // ======================

    if (message.mentions.users.size === 0) return;

    for (const user of message.mentions.users.values()) {

        // skip diri sendiri

        if (user.id === userId) continue;

        const afk = getAFK(client, user.id);

        if (!afk) continue;

        // ======================

        // ANTI SPAM 🔥

        // ======================

        const key = `${userId}-${user.id}`;

        const now = Date.now();

        if (cooldown.has(key)) {

            if (now < cooldown.get(key)) continue;

        }

        cooldown.set(key, now + 5000);

        const duration = formatDuration(Date.now() - afk.since);

        message.reply(

            afkMentionEmbed(user.id, afk.reason, duration)

        );

    }

};