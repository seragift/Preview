const { EmbedBuilder } = require("discord.js");

// Ambil top voice (pakai voiceMins)

function getTopVoice(client) {

    try {

        return client.db

            .prepare("SELECT userId, voiceMins FROM users ORDER BY voiceMins DESC LIMIT 10")

            .all();

    } catch (err) {

        console.error("Error ambil top voice:", err);

        return [];

    }

}

// Format menit → jam & menit

function formatTime(minutes) {

    const h = Math.floor(minutes / 60);

    const m = minutes % 60;

    return `${h}h ${m}m`;

}

// Buat embed

function createTopVoiceEmbed(users, message) {

    if (!users.length) {

        return { content: "Belum ada data voice." };

    }

    const medals = ["🥇", "🥈", "🥉"];

    const description = users.map((user, i) => {

        const rank = medals[i] || `**${i + 1}.**`;

        const time = formatTime(user.voiceMins || 0);

        return `${rank} <@${user.userId}>\n🎤 Voice Time: **${time}**`;

    }).join("\n\n");

    const embed = new EmbedBuilder()

        .setTitle("🎤 Top Voice Leaderboard")

        .setDescription(description)

        .setColor(0x5865F2)

        .setFooter({

            text: `Requested by ${message.author.username}`

        })

        .setTimestamp();

    return { embeds: [embed] };

}

module.exports = {

    getTopVoice,

    createTopVoiceEmbed

};