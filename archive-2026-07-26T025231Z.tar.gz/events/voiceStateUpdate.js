const handleVoice = require('../utils/handleVoice');

module.exports = (client, oldState, newState) => {

    // Pastikan user bukan bot

    if (newState.member && newState.member.user.bot) return;

    

    // Panggil utilitas handleVoice

    handleVoice(client, oldState, newState);

};