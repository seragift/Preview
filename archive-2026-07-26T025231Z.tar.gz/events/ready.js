const { 

    EmbedBuilder, 

    ActionRowBuilder, 

    ButtonBuilder, 

    ButtonStyle, 

    AttachmentBuilder 

} = require('discord.js');

const handleVoice = require('../utils/handleVoice');

const { syncGuildMembers } = require('../utils/cleanup');

const fs = require('fs');

module.exports = async (client) => {

    console.log(`[Event: clientReady] Logged in as ${client.user.username}`);

    // ======================

    // 🧹 SYNC MEMBER (hapus data user yang sudah keluar server)

    // ======================

    const mainGuild = client.guilds.cache.get(client.config.guildId);

    if (mainGuild) {

        await syncGuildMembers(client, mainGuild);

    }

    // ======================

    // 🔊 AUTO RESUME VOICE

    // ======================

    client.guilds.cache.forEach(guild => {

        guild.channels.cache.forEach(channel => {

            if (channel.isVoiceBased()) {

                channel.members.forEach(member => {

                    if (member.user.bot) return;

                    handleVoice(client,

                        { channelId: null },

                        { id: member.id, guild, channelId: channel.id, member }

                    );

                });

            }

        });

    });

    // ======================

    // 🎁 REDEEM PANEL (FUTURISTIC UI 💀)

    // ======================

    const channel = client.channels.cache.get(client.config.redeemPanelChannelId);

    if (channel) {

        const embed = new EmbedBuilder()

            // 🎨 fake gradient effect

            .setColor("#FF4D6D")

            .setAuthor({

                name: "⚡ ECHO SYSTEM INTERFACE",

                iconURL: client.user.displayAvatarURL()

            })

            .setThumbnail(client.user.displayAvatarURL())

            .setDescription(

                `\`\`\`diff\n+ SYSTEM ONLINE • READY\n\`\`\`\n` +

                `╭━━━━━━━━━━━━━━━━━━━━━━╮\n` +

                `┃ 💎 TOKEN ENGINE ACTIVE ┃\n` +

                `╰━━━━━━━━━━━━━━━━━━━━━━╯\n\n` +

                `🌐 **EARNING SYSTEM**\n` +

                `▰ Level Up → **+${client.config.tokenPerLevel} 💎**\n` +

                `▰ Chat • Reaction • Voice Activity\n\n` +

                `🛒 **REWARD MARKET**\n` +

                `▰ 🏷️ Temporary Role (7 / 14 / 30 Days)\n` +

                `▰ 🎨 Custom Identity\n\n` +

                `⚡ *Grind. Earn. Dominate.*`

            )

            .addFields(

                {

                    name: "🧠 SYSTEM CORE",

                    value:

                        `▰ Version: **v4.0**\n` +

                        `▰ Status: 🟢 Stable\n` +

                        `▰ Engine: Economy + Leveling`,

                    inline: true

                },

                {

                    name: "🎮 CONTROL PANEL",

                    value:

                        `▰ 📋 Profile\n` +

                        `▰ 🏆 Leaderboard\n` +

                        `▰ 🎁 Redeem`,

                    inline: true

                }

            )

            // 🎨 fake neon divider

            .addFields({

                name: "━━━━━━━━━━━━━━━━━━━━━━",

                value: "⚡ Real-time System Interface",

                inline: false

            })

            .setFooter({

                text: "Echo Lounge • Futuristic UI 💀",

                iconURL: client.user.displayAvatarURL()

            })

            .setTimestamp();

        const row = new ActionRowBuilder().addComponents(

            new ButtonBuilder()

                .setCustomId('my_profile')

                .setLabel('Profile')

                .setEmoji('📋')

                .setStyle(ButtonStyle.Primary),

            new ButtonBuilder()

                .setCustomId('leaderboard')

                .setLabel('Leaderboard')

                .setEmoji('🏆')

                .setStyle(ButtonStyle.Secondary),

            new ButtonBuilder()

                .setCustomId('menu_redeem')

                .setLabel('Redeem')

                .setEmoji('🎁')

                .setStyle(ButtonStyle.Success)

        );

        await channel.bulkDelete(5).catch(() => {});

        await channel.send({ embeds: [embed], components: [row] });

    }

    // ======================

    // 💾 AUTO BACKUP

    // ======================

    setInterval(async () => {

        const backupChannel = client.channels.cache.get(client.config.backupChannelId);

        if (!backupChannel) return;

        const dbPath = './levels.db';

        if (fs.existsSync(dbPath)) {

            const attachment = new AttachmentBuilder(dbPath, {

                name: `levels.db`

            });

            const embed = new EmbedBuilder()

                .setColor("#3498DB")

                .setAuthor({

                    name: "💾 DATABASE BACKUP SYSTEM",

                    iconURL: client.user.displayAvatarURL()

                })

                .setDescription(

                    `\`\`\`fix\n✓ BACKUP SUCCESS\n\`\`\`\n` +

                    `📦 Database berhasil diamankan\n\n` +

                    `🕒 <t:${Math.floor(Date.now()/1000)}:F>\n` +

                    `🔐 Status: Secure`

                )

                .setFooter({

                    text: "Auto Backup • Security Layer"

                })

                .setTimestamp();

            await backupChannel.send({

                embeds: [embed],

                files: [attachment]

            });

        }

    }, 21600000);

};