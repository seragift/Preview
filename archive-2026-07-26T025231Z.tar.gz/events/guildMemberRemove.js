const { removeUserData } = require('../utils/cleanup');

module.exports = (client, member) => {
    if (member.user?.bot) return;
    removeUserData(client, member.id);
};
