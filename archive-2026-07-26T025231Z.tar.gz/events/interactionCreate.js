const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');

const { getProfile, getLeaderboard } = require('../utils/handlePanel');

const ms = require('ms');

// Helper untuk mengubah nama warna ke HEX

const colorMap = {

    "putih": "#FFFFFF",

    "hitam": "#000000",

    "merah": "#FF0000",

    "biru": "#0000FF",

    "hijau": "#00FF00",

    "kuning": "#FFFF00",

    "ungu": "#800080",

    "pink": "#FFC0CB",

    "orange": "#FFA500",

    "abu": "#808080",

    "coklat": "#A52A2A",

    "biru muda": "#ADD8E6"

};

module.exports = async (client, interaction) => {

    const userId = interaction.user.id;

    if (interaction.isButton()) {

        // ... (Logika My Profile & Leaderboard tetap sama)

        if (interaction.customId === 'my_profile') return interaction.reply({ embeds: [getProfile(client, userId)], ephemeral: true });

        if (interaction.customId === 'leaderboard') return interaction.reply({ embeds: [getLeaderboard(client, userId)], ephemeral: true });

        if (interaction.customId === 'menu_redeem') {

            const row = new ActionRowBuilder().addComponents(

                new ButtonBuilder().setCustomId('rdm_role_7').setLabel('Role (7H) - 30💎').setStyle(ButtonStyle.Primary),

                new ButtonBuilder().setCustomId('rdm_role_14').setLabel('Role (14H) - 50💎').setStyle(ButtonStyle.Primary),

                new ButtonBuilder().setCustomId('rdm_role_30').setLabel('Role (30H) - 70💎').setStyle(ButtonStyle.Primary),

                new ButtonBuilder().setCustomId('rdm_nick_btn').setLabel('changename - 10💎').setStyle(ButtonStyle.Secondary)

            );

            return interaction.reply({ content: "Pilih item yang ingin di-redeem:", components: [row], ephemeral: true });

        }

        // Modal untuk Ganti Nickname

        if (interaction.customId === 'rdm_nick_btn') {

            const modal = new ModalBuilder().setCustomId('modal_nick').setTitle('Redeem Custom Nickname');

            const input = new TextInputBuilder().setCustomId('new_name').setLabel("Masukkan Nickname Baru").setStyle(TextInputStyle.Short).setRequired(true);

            modal.addComponents(new ActionRowBuilder().addComponents(input));

            return await interaction.showModal(modal);

        }

        // Modal untuk Custom Role

        if (interaction.customId.startsWith('rdm_role_')) {

            const days = interaction.customId.split('_')[2];

            const modal = new ModalBuilder().setCustomId(`modal_role_${days}`).setTitle(`Redeem Role (${days} Hari)`);

            

            const nameInput = new TextInputBuilder().setCustomId('role_name').setLabel("Nama Role").setStyle(TextInputStyle.Short).setRequired(true);

            const colorInput = new TextInputBuilder().setCustomId('role_color').setLabel("Warna (Putih, Merah, Biru, dll)").setStyle(TextInputStyle.Short).setRequired(true);

            const emojiInput = new TextInputBuilder().setCustomId('role_emoji').setLabel("Emoji (Boleh Kosong)").setStyle(TextInputStyle.Short).setRequired(false);

            modal.addComponents(

                new ActionRowBuilder().addComponents(nameInput), 

                new ActionRowBuilder().addComponents(colorInput), 

                new ActionRowBuilder().addComponents(emojiInput)

            );

            await interaction.showModal(modal);

        }

    }

    if (interaction.isModalSubmit()) {

        const user = client.db.prepare("SELECT tokens FROM users WHERE userId = ?").get(userId);

        // LOGIKA REDEEM NICKNAME

        if (interaction.customId === 'modal_nick') {

            const price = client.config.prices.nickname;

            if (!user || user.tokens < price) return interaction.reply({ content: "Token tidak cukup!", ephemeral: true });

            const newNick = interaction.fields.getTextInputValue('new_name');

            try {

                await interaction.member.setNickname(newNick);

                client.db.prepare("UPDATE users SET tokens = tokens - ? WHERE userId = ?").run(price, userId);

                return interaction.reply({ content: `✅ Nickname berhasil diubah menjadi **${newNick}**!`, ephemeral: true });

            } catch (err) {

                return interaction.reply({ content: "Gagal mengubah nickname. Pastikan posisi Role Bot berada di atas user.", ephemeral: true });

            }

        }

        // LOGIKA REDEEM ROLE

        if (interaction.customId.startsWith('modal_role_')) {

            const days = interaction.customId.split('_')[2];

            const price = client.config.prices[`role_${days}d`];

            if (!user || user.tokens < price) return interaction.reply({ content: "Token tidak cukup!", ephemeral: true });

            const name = interaction.fields.getTextInputValue('role_name');

            const colorName = interaction.fields.getTextInputValue('role_color').toLowerCase();

            const emoji = interaction.fields.getTextInputValue('role_emoji');

            // Ambil HEX dari map, jika tidak ada gunakan default abu-abu

            const hexColor = colorMap[colorName] || "#808080";

            try {

                const role = await interaction.guild.roles.create({

                    name: emoji ? `${emoji} ${name}` : name,

                    color: hexColor,

                    reason: `Redeem role by ${interaction.user.tag}`

                });

                await interaction.member.roles.add(role);

                

                const expiry = Date.now() + ms(`${days}d`);

                client.db.prepare("INSERT INTO temp_roles (roleId, userId, guildId, expiry) VALUES (?, ?, ?, ?)").run(role.id, userId, interaction.guild.id, expiry);

                client.db.prepare("UPDATE users SET tokens = tokens - ? WHERE userId = ?").run(price, userId);

                interaction.reply({ content: `✅ Role **${name}** berwarna **${colorName}** aktif selama ${days} hari!`, ephemeral: true });

            } catch (e) {

                interaction.reply({ content: "Gagal membuat role. Periksa izin bot!", ephemeral: true });

            }

        }

    }

};