const handleMessages = require('../utils/handleMessages');

const handleCommands = require('../utils/commands');

const handleAFK = require('../utils/afkHandler');

const config = require('../config.json');

const prefix = config.prefix || ".";

module.exports = (client, message) => {

    if (message.author.bot || !message.guild) return;

    // ======================

    // XP SYSTEM

    // ======================

    handleMessages(client, message);

    // ======================

    // AFK SYSTEM

    // ======================

    handleAFK(client, message);

    // ======================

    // PREFIX SYSTEM

    // ======================

    if (!message.content.startsWith(prefix)) return;

    const args = message.content.slice(prefix.length).trim().split(/ +/);

    const command = args.shift().toLowerCase();

    // ======================

    // COMMAND HANDLER

    // ======================

    handleCommands(client, message, command, args);

};