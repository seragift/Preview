const handleReaction = require('../utils/handleReaction');

module.exports = async (client, reaction, user) => {

    // Abaikan jika yang memberi emoji adalah bot

    if (user.bot) return;

    // Ambil data jika pesan ada di channel yang tidak ter-cache (Partials)

    if (reaction.partial) {

        try {

            await reaction.fetch();

        } catch (error) {

            console.error('Gagal mengambil partial reaction:', error);

            return;

        }

    }

    // Panggil utilitas handleReaction

    handleReaction(client, user.id);

};