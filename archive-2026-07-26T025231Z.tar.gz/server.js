const express = require('express');
const path = require('path');
const http = require('http');
const { Server } = require('socket.io');
const Database = require('better-sqlite3');
const dbEvents = require('./utils/dbEvents');

// server.js bisa dipakai 2 cara:
// 1. Digabung dalam 1 proses bareng bot lewat start.js -> startServer(client)
//    di sini dashboard langsung pakai koneksi DB (read/write) dan cache
//    Discord.js milik bot -> update realtime tanpa perlu panggil REST API lagi.
// 2. Dijalankan sendiri (`node server.js`) di panel terpisah dari bot -> fallback
//    ke mode lama: buka levels.db read-only + fetch data user lewat REST API.

// Rumus level dipakai sama persis kayak di utils/handleExp.js
const XP_PER_LEVEL = 300;

function startServer(botClient) {
  let config = {};
  try {
    config = require('./config.json');
  } catch (e) {
    console.warn('config.json not found, falling back to environment variables only.');
  }

  const PORT = process.env.PORT || 7015;
  const HOST = '0.0.0.0';
  const TOKEN = process.env.DISCORD_TOKEN || config.token;
  const GUILD_ID = process.env.GUILD_ID || config.guildId;
  const standalone = !botClient;

  if (standalone && (!TOKEN || !GUILD_ID)) {
    console.warn('Warning: missing Discord bot token or guildId. Usernames/avatars will not load.');
  }

  // Mode gabung: pakai db bot (read/write, live). Mode standalone: buka sendiri read-only.
  const db = botClient
    ? botClient.db
    : new Database(path.join(__dirname, 'levels.db'), { readonly: true, fileMustExist: true });

  // ---- Prepared statements (disiapkan sekali di awal, bukan tiap request -> lebih ringan) ----
  const stmt = {
    countUsers: db.prepare('SELECT COUNT(*) AS c FROM users'),
    leaderboardAll: db.prepare(
      'SELECT userId, xp, level, tokens, messages, reactions, voiceMins FROM users ORDER BY level DESC, xp DESC'
    ),
    leaderboardLimit: db.prepare(
      'SELECT userId, xp, level, tokens, messages, reactions, voiceMins FROM users ORDER BY level DESC, xp DESC LIMIT ?'
    ),
    topVoiceAll: db.prepare(
      'SELECT userId, voiceMins, level FROM users WHERE voiceMins > 0 ORDER BY voiceMins DESC'
    ),
    topVoiceLimit: db.prepare(
      'SELECT userId, voiceMins, level FROM users WHERE voiceMins > 0 ORDER BY voiceMins DESC LIMIT ?'
    ),
    topChatAll: db.prepare(
      'SELECT userId, messages, level FROM users WHERE messages > 0 ORDER BY messages DESC'
    ),
    topChatLimit: db.prepare(
      'SELECT userId, messages, level FROM users WHERE messages > 0 ORDER BY messages DESC LIMIT ?'
    ),
    userStats: db.prepare(
      'SELECT xp, level, tokens, messages, reactions, voiceMins FROM users WHERE userId = ?'
    ),
    higherRankCount: db.prepare(
      'SELECT COUNT(*) AS c FROM users WHERE level > ? OR (level = ? AND xp > ?)'
    )
  };

  const app = express();
  const httpServer = http.createServer(app);
  const io = new Server(httpServer);

  app.use(express.static(path.join(__dirname, 'public'), { maxAge: '1h' }));

  const DISCORD_API = 'https://discord.com/api/v10';

  // ---- Fallback REST helpers (dipakai kalau standalone, tanpa client Discord.js live) ----
  const memberCache = new Map();
  const MEMBER_TTL_MS = 5 * 60 * 1000;
  let guildInfoCache = { data: null, expiresAt: 0 };

  async function discordFetch(pathSuffix) {
    if (!TOKEN) return null;
    try {
      const res = await fetch(`${DISCORD_API}${pathSuffix}`, {
        headers: { Authorization: `Bot ${TOKEN}` }
      });
      if (res.status === 429) {
        const body = await res.json().catch(() => ({}));
        const retryAfterMs = Math.ceil((body.retry_after || 1) * 1000);
        await new Promise((r) => setTimeout(r, retryAfterMs));
        return discordFetch(pathSuffix);
      }
      if (!res.ok) return null;
      return res.json();
    } catch (err) {
      console.error('Discord API error:', err.message);
      return null;
    }
  }

  function defaultAvatarIndex(userId, discriminator) {
    if (discriminator && discriminator !== '0') {
      return Number(discriminator) % 5;
    }
    try {
      return Number((BigInt(userId) >> 22n) % 6n);
    } catch {
      return 0;
    }
  }

  function avatarUrlFor(userId, member) {
    if (member?.avatar) {
      return `https://cdn.discordapp.com/guilds/${GUILD_ID}/users/${userId}/avatars/${member.avatar}.png?size=64`;
    }
    const user = member?.user;
    if (user?.avatar) {
      return `https://cdn.discordapp.com/avatars/${userId}/${user.avatar}.png?size=64`;
    }
    const idx = defaultAvatarIndex(userId, user?.discriminator);
    return `https://cdn.discordapp.com/embed/avatars/${idx}.png`;
  }

  // ---- Info guild & member: pakai cache live kalau ada botClient, kalau tidak REST ----
  async function getGuildInfo() {
    if (botClient) {
      const guild = botClient.guilds.cache.get(GUILD_ID);
      if (guild) {
        return {
          name: guild.name,
          icon: guild.iconURL ? guild.iconURL({ size: 64 }) : null
        };
      }
      return { name: 'Community', icon: null };
    }

    if (guildInfoCache.data && guildInfoCache.expiresAt > Date.now()) return guildInfoCache.data;
    const data = await discordFetch(`/guilds/${GUILD_ID}`);
    const info = data
      ? {
          name: data.name,
          icon: data.icon ? `https://cdn.discordapp.com/icons/${GUILD_ID}/${data.icon}.png` : null
        }
      : { name: 'Community', icon: null };
    guildInfoCache = { data: info, expiresAt: Date.now() + 10 * 60 * 1000 };
    return info;
  }

  function getMemberFast(userId) {
    // Versi sync, no I/O sama sekali -> dipakai saat enrich list besar (leaderboard/topvoice/topchat)
    if (botClient) {
      const guild = botClient.guilds.cache.get(GUILD_ID);
      const member = guild?.members.cache.get(userId);
      if (member) {
        return {
          id: userId,
          username: member.user.username,
          displayName: member.nickname || member.user.globalName || member.user.username || `User ${userId.slice(-4)}`,
          avatar: member.displayAvatarURL({ size: 64 })
        };
      }
      return {
        id: userId,
        username: 'unknown',
        displayName: `User ${userId.slice(-4)}`,
        avatar: avatarUrlFor(userId, null)
      };
    }

    const cached = memberCache.get(userId);
    if (cached && cached.expiresAt > Date.now()) return cached.data;
    return null; // butuh REST -> ditangani di getMember (async)
  }

  async function getMember(userId) {
    const fast = getMemberFast(userId);
    if (fast || botClient) return fast; // attached mode selalu sync, no fetch needed

    const member = await discordFetch(`/guilds/${GUILD_ID}/members/${userId}`);
    const data = member
      ? {
          id: userId,
          username: member.user?.username || userId,
          displayName: member.nick || member.user?.global_name || member.user?.username || `User ${userId.slice(-4)}`,
          avatar: avatarUrlFor(userId, member)
        }
      : {
          id: userId,
          username: 'unknown',
          displayName: `User ${userId.slice(-4)}`,
          avatar: avatarUrlFor(userId, null)
        };

    memberCache.set(userId, { data, expiresAt: Date.now() + MEMBER_TTL_MS });
    return data;
  }

  async function enrich(rows) {
    // Mode attached: semua data dari cache (sync), jadi nggak perlu Promise.all yang mahal.
    if (botClient) {
      return rows.map((row) => ({ ...row, member: getMemberFast(row.userId) }));
    }
    return Promise.all(rows.map(async (row) => ({ ...row, member: await getMember(row.userId) })));
  }

  // ---- Progress XP (dipakai di leaderboard ringkas & di card profil) ----
  function xpProgress(level, xp) {
    const lvl = level || 1;
    const nextLevelXp = lvl * XP_PER_LEVEL;
    const percent = nextLevelXp > 0 ? Math.min(100, Math.round((xp / nextLevelXp) * 100)) : 0;
    return { nextLevelXp, percent };
  }

  // ---- Profil user lengkap (buat card saat diklik) ----
  const DISCORD_EPOCH = 1420070400000n;
  function snowflakeToDate(id) {
    try {
      const ms = (BigInt(id) >> 22n) + DISCORD_EPOCH;
      return new Date(Number(ms));
    } catch {
      return null;
    }
  }

  let rolesCache = { data: null, expiresAt: 0 };
  async function getGuildRolesRest() {
    if (rolesCache.data && rolesCache.expiresAt > Date.now()) return rolesCache.data;
    const data = await discordFetch(`/guilds/${GUILD_ID}/roles`);
    const map = new Map();
    (data || []).forEach((r) => map.set(r.id, r));
    rolesCache = { data: map, expiresAt: Date.now() + 10 * 60 * 1000 };
    return map;
  }

  function getUserStatsAndRank(userId) {
    const stats = stmt.userStats.get(userId) || {
      xp: 0,
      level: 1,
      tokens: 0,
      messages: 0,
      reactions: 0,
      voiceMins: 0
    };
    const { nextLevelXp, percent } = xpProgress(stats.level, stats.xp);
    const rank = stmt.higherRankCount.get(stats.level, stats.level, stats.xp).c + 1;
    return {
      level: stats.level || 1,
      xp: stats.xp || 0,
      nextLevelXp,
      xpPercent: percent,
      tokens: stats.tokens || 0,
      messages: stats.messages || 0,
      reactions: stats.reactions || 0,
      voiceMins: stats.voiceMins || 0,
      rank
    };
  }

  async function getUserProfile(userId) {
    const stats = getUserStatsAndRank(userId);

    if (botClient) {
      const guild = botClient.guilds.cache.get(GUILD_ID);
      if (!guild) return null;
      let member = guild.members.cache.get(userId);
      if (!member) {
        member = await guild.members.fetch(userId).catch(() => null);
      }
      if (!member) return null;

      const roles = member.roles.cache
        .filter((r) => r.id !== guild.id)
        .sort((a, b) => b.position - a.position)
        .map((r) => ({
          id: r.id,
          name: r.name,
          color: r.hexColor && r.hexColor !== '#000000' ? r.hexColor : '#99aab5'
        }));

      return {
        id: userId,
        username: member.user.username,
        displayName: member.displayName,
        avatar: member.displayAvatarURL({ size: 256 }),
        createdAt: member.user.createdAt,
        joinedAt: member.joinedAt,
        roles,
        ...stats
      };
    }

    // Standalone fallback (REST)
    const [memberData, rolesMap] = await Promise.all([
      discordFetch(`/guilds/${GUILD_ID}/members/${userId}`),
      getGuildRolesRest()
    ]);
    if (!memberData) return null;

    const roles = (memberData.roles || [])
      .map((id) => rolesMap.get(id))
      .filter(Boolean)
      .sort((a, b) => b.position - a.position)
      .map((r) => ({
        id: r.id,
        name: r.name,
        color: r.color ? `#${r.color.toString(16).padStart(6, '0')}` : '#99aab5'
      }));

    return {
      id: userId,
      username: memberData.user?.username || 'unknown',
      displayName: memberData.nick || memberData.user?.global_name || memberData.user?.username || `User ${userId.slice(-4)}`,
      avatar: avatarUrlFor(userId, memberData),
      createdAt: snowflakeToDate(userId),
      joinedAt: memberData.joined_at ? new Date(memberData.joined_at) : null,
      roles,
      ...stats
    };
  }

  async function getLeaderboard(limit) {
    const rows = limit ? stmt.leaderboardLimit.all(limit) : stmt.leaderboardAll.all();
    return enrich(rows);
  }

  async function getTopVoice(limit) {
    const rows = limit ? stmt.topVoiceLimit.all(limit) : stmt.topVoiceAll.all();
    return enrich(rows);
  }

  async function getTopChat(limit) {
    const rows = limit ? stmt.topChatLimit.all(limit) : stmt.topChatAll.all();
    return enrich(rows);
  }

  // Payload lengkap dipakai buat broadcast Socket.io realtime — tanpa limit,
  // supaya leaderboard di dashboard menampilkan SEMUA user, bukan cuma top N.
  async function buildPayload() {
    const [guild, leaderboard, topvoice, topchat] = await Promise.all([
      getGuildInfo(),
      getLeaderboard(null),
      getTopVoice(null),
      getTopChat(null)
    ]);
    const totalUsers = stmt.countUsers.get().c;
    return { guild, totalUsers, leaderboard, topvoice, topchat, updatedAt: Date.now() };
  }

  // ---- REST API (tetap disediakan untuk kompatibilitas / fallback) ----
  app.get('/api/meta', async (req, res) => {
    const info = await getGuildInfo();
    const totalUsers = stmt.countUsers.get().c;
    res.json({ guild: info, totalUsers, updatedAt: Date.now() });
  });

  // Tanpa ?limit= -> kembalikan SEMUA user. Kasih ?limit=N kalau mau dibatasi.
  app.get('/api/leaderboard', async (req, res) => {
    const limit = req.query.limit ? Math.min(Number(req.query.limit), 100000) : null;
    res.json(await getLeaderboard(limit));
  });

  app.get('/api/topvoice', async (req, res) => {
    const limit = req.query.limit ? Math.min(Number(req.query.limit), 100000) : null;
    res.json(await getTopVoice(limit));
  });

  app.get('/api/topchat', async (req, res) => {
    const limit = req.query.limit ? Math.min(Number(req.query.limit), 100000) : null;
    res.json(await getTopChat(limit));
  });

  // Detail 1 user buat card popup: username, avatar, tanggal buat akun, tanggal join,
  // roles, DAN progress xp / target xp / rank / stats lain.
  app.get('/api/user/:id', async (req, res) => {
    try {
      const profile = await getUserProfile(req.params.id);
      if (!profile) return res.status(404).json({ error: 'User tidak ditemukan di server.' });
      res.json(profile);
    } catch (err) {
      console.error('[DASHBOARD] Gagal ambil profil user:', err.message);
      res.status(500).json({ error: 'Gagal mengambil data user.' });
    }
  });

  // ---- Socket.io: push data realtime tiap kali DB berubah ----
  // Di-debounce supaya server nggak query+broadcast full list ke semua client
  // di SETIAP pesan chat / tick voice — ditunggu dulu beberapa event numpuk,
  // baru broadcast sekali. Jauh lebih ringan di server yang aktif.
  const BROADCAST_DEBOUNCE_MS = 1500;
  const BROADCAST_MAX_WAIT_MS = 6000;

  let cachedPayload = null;
  let broadcasting = false;
  let broadcastTimer = null;
  let pendingSince = null;

  async function broadcastNow() {
    if (broadcasting) return;
    broadcasting = true;
    try {
      const payload = await buildPayload();
      cachedPayload = payload;
      io.emit('dashboard:update', payload);
    } catch (err) {
      console.error('[DASHBOARD] Gagal broadcast update:', err.message);
    } finally {
      broadcasting = false;
    }
  }

  function scheduleBroadcast() {
    const now = Date.now();
    if (!pendingSince) pendingSince = now;

    const waited = now - pendingSince;
    const delay = waited >= BROADCAST_MAX_WAIT_MS ? 0 : BROADCAST_DEBOUNCE_MS;

    if (broadcastTimer) clearTimeout(broadcastTimer);
    broadcastTimer = setTimeout(() => {
      pendingSince = null;
      broadcastTimer = null;
      broadcastNow();
    }, delay);
  }

  // Trigger tiap ada perubahan (xp naik, chat, voice, user keluar, dst) — di-debounce
  dbEvents.on('usersChanged', scheduleBroadcast);

  // Fallback tick jarang-jarang, jaga-jaga kalau ada perubahan DB yang lolos dari dbEvents
  setInterval(broadcastNow, 20000);

  io.on('connection', async (socket) => {
    try {
      // Pakai payload yang sudah di-cache kalau ada, biar nggak query ulang tiap 1 tab dibuka
      socket.emit('dashboard:update', cachedPayload || (await buildPayload()));
    } catch (err) {
      console.error('[DASHBOARD] Gagal kirim data awal ke client:', err.message);
    }
  });

  httpServer.listen(PORT, HOST, () => {
    console.log(`Dashboard listening on http://${HOST}:${PORT}${standalone ? ' (standalone mode)' : ' (attached ke bot)'}`);
    // Siapkan payload pertama di awal biar koneksi pertama nggak nunggu query
    broadcastNow();
  });

  return { app, httpServer, io };
}

if (require.main === module) {
  // Dijalankan langsung: node server.js -> mode standalone
  startServer(null);
}

module.exports = startServer;
