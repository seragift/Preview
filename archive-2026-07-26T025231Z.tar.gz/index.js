const { Client, GatewayIntentBits, Partials } = require('discord.js');

const config = require('./config.json');

const Database = require('better-sqlite3');

const fs = require('fs');

// ======================

// DATABASE

// ======================

const db = new Database('levels.db');

// USERS TABLE

db.prepare(`CREATE TABLE IF NOT EXISTS users (

    userId TEXT PRIMARY KEY, 

    xp INTEGER DEFAULT 0, 

    level INTEGER DEFAULT 1, 

    tokens INTEGER DEFAULT 0,

    messages INTEGER DEFAULT 0,

    reactions INTEGER DEFAULT 0,

    voiceMins INTEGER DEFAULT 0

)`).run();

// TEMP ROLE TABLE

db.prepare(`CREATE TABLE IF NOT EXISTS temp_roles (

    roleId TEXT PRIMARY KEY,

    userId TEXT,

    guildId TEXT,

    expiry INTEGER

)`).run();

// ======================

// CLIENT

// ======================

const client = new Client({

    intents: [

        GatewayIntentBits.Guilds,

        GatewayIntentBits.GuildMembers, // 🔥 INI YANG DITAMBAH

        GatewayIntentBits.GuildMessages,

        GatewayIntentBits.MessageContent,

        GatewayIntentBits.GuildVoiceStates,

        GatewayIntentBits.GuildMessageReactions

    ],

    partials: [Partials.Message, Partials.Channel, Partials.Reaction]

});

client.db = db;

client.config = config;

// ======================

// INIT AFK TABLE

// ======================

const { initAFKTable } = require('./utils/afk');

initAFKTable(client);

// ======================

// LOAD EVENTS

// ======================

const eventFiles = fs.readdirSync('./events').filter(file => file.endsWith('.js'));

for (const file of eventFiles) {

    const event = require(`./events/${file}`);

    const eventName = file.split('.')[0];

    client.on(eventName, (...args) => event(client, ...args));

}

// ======================

// AUTO DELETE TEMP ROLE

// ======================

setInterval(async () => {

    const now = Date.now();

    const expired = db.prepare(

        "SELECT * FROM temp_roles WHERE expiry < ?"

    ).all(now);

    for (const row of expired) {

        try {

            const guild = client.guilds.cache.get(row.guildId) 

                || await client.guilds.fetch(row.guildId).catch(() => null);

            if (!guild) {

                db.prepare("DELETE FROM temp_roles WHERE roleId = ?").run(row.roleId);

                continue;

            }

            const role = guild.roles.cache.get(row.roleId) 

                || await guild.roles.fetch(row.roleId).catch(() => null);

            if (role) {

                await role.delete("Sewa role berakhir (Redeem System)");

                console.log(`[EXPIRED] Role ${row.roleId} telah dihapus.`);

            }

        } catch (error) {

            console.error(`[ERROR] Gagal menghapus role ${row.roleId}:`, error.message);

        } finally {

            db.prepare("DELETE FROM temp_roles WHERE roleId = ?").run(row.roleId);

        }

    }

}, 60000);

// ======================

// ERROR HANDLER

// ======================

process.on('unhandledRejection', error => {

    console.error('Unhandled promise rejection:', error);

});

// ======================

// LOGIN

// ======================

client.login(config.token);

module.exports = client;