# Live Activity Dashboard

Landing page langsung (tanpa OAuth2/login) yang menampilkan tiga scoreboard **realtime** dari `levels.db` bot leveling kamu:

- **Leaderboard** — urut berdasarkan level & XP
- **Top Voice** — urut berdasarkan total menit di voice channel
- **Top Chat** — urut berdasarkan jumlah pesan

Dashboard dan bot jalan dalam **1 proses** (lewat `start.js`), jadi data yang tampil diambil langsung dari koneksi database bot (bukan file terpisah) dan di-push ke browser via **Socket.io** setiap kali ada perubahan (chat, voice, reaction, level up, dsb) — bukan polling.

## 🧹 Auto-cleanup member yang keluar

Kalau seorang user keluar dari server, data level/xp/temp role/AFK-nya **otomatis dihapus** dari database:

- Realtime lewat event `guildMemberRemove` — begitu user leave, datanya langsung hilang dari dashboard.
- Sync tambahan saat bot startup (`syncGuildMembers`) untuk membersihkan user yang sempat keluar selagi bot offline.

## Menjalankan secara lokal

```bash
npm install
npm start
```

`npm start` menjalankan `start.js`, yang otomatis start bot Discord (`index.js`) **dan** dashboard (`server.js`) sekaligus. Server akan listen di `0.0.0.0:7015` (bisa diganti lewat env var `PORT`).

## Konfigurasi

Server membaca token & guild ID dari `config.json`. Kalau mau override tanpa ubah file, set environment variable:

```bash
DISCORD_TOKEN=xxxx GUILD_ID=xxxx PORT=7015 npm start
```

> **Penting soal keamanan:** token di `config.json` kamu sempat ter-upload dalam bentuk plain text. Sebaiknya **reset token bot** itu di Discord Developer Portal (Bot → Reset Token), lalu ganti nilainya di `config.json` dengan yang baru sebelum deploy.

## Deploy ke panel (Pterodactyl dkk.)

1. Upload seluruh folder ini.
2. Startup command: `npm install && npm start`
3. Pastikan panel mem-bind port **7015** ke `0.0.0.0` (sudah default di `server.js`).
4. Cukup 1 panel — bot dan dashboard jalan bareng dalam satu proses.

## Catatan

- Endpoint REST tetap ada untuk kompatibilitas/fallback: `/api/meta`, `/api/leaderboard`, `/api/topvoice`, `/api/topchat` (query `?limit=` opsional, maksimal 100). Sumber utama data browser sekarang adalah event Socket.io `dashboard:update`.
- `server.js` juga masih bisa dijalankan sendiri (`node server.js`, mode standalone, baca `levels.db` read-only + REST API) kalau suatu saat kamu mau pisah lagi jadi 2 panel.

