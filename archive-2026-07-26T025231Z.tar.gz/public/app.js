const REFRESH_MS = 8000;
const ACCENTS = { xp: '#9b8cff', voice: '#4fe3d1', chat: '#ffb454' };
const ACCENT_DIM = { xp: '#9b8cff26', voice: '#4fe3d126', chat: '#ffb45426' };

function formatVoiceMinutes(mins) {
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  if (h <= 0) return `${m}m`;
  return `${h}h ${m}m`;
}

function formatCompact(n) {
  return new Intl.NumberFormat('en-US', { notation: 'compact', maximumFractionDigits: 1 }).format(n);
}

function escapeHtml(str) {
  return String(str).replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
}

const MEDALS = { 1: ['gold', '1'], 2: ['silver', '2'], 3: ['bronze', '3'] };
const PAGE_SIZE = 15;

// Remembers each row's last numeric value per board, so we can briefly
// flash a row when its live stat actually changes (visual "pulse" of activity).
const lastValues = { rowsXp: new Map(), rowsVoice: new Map(), rowsChat: new Map() };

// Per-board UI state: search text, sort direction, how many rows are visible.
// Kept outside renderRows so it survives across realtime dashboard:update pushes.
const boardState = {
  rowsXp: { search: '', dir: 'desc', visible: PAGE_SIZE },
  rowsVoice: { search: '', dir: 'desc', visible: PAGE_SIZE },
  rowsChat: { search: '', dir: 'desc', visible: PAGE_SIZE }
};

// Cache of the last full (unfiltered, server-order) item list per board,
// so search/sort/pagination can re-render instantly without new data.
const boardData = { rowsXp: [], rowsVoice: [], rowsChat: [] };

function avatarImgHtml(member) {
  const initial = escapeHtml((member.displayName || '?').charAt(0).toUpperCase());
  return `<img class="avatar" src="${member.avatar}" alt="" loading="lazy" onerror="this.outerHTML='&lt;div class=&quot;avatar avatar-fallback&quot;&gt;${initial}&lt;/div&gt;'" />`;
}

function renderRows(containerId, items, opts) {
  const el = document.getElementById(containerId);
  const seen = lastValues[containerId];
  const state = boardState[containerId];
  const countEl = document.getElementById(opts.countId);
  const moreBtn = document.getElementById(opts.moreId);

  // Attach the true (server-order) rank to each item before filtering/sorting,
  // so rank badges always reflect real standing even mid-search or reverse-sorted.
  const withRank = items.map((item, i) => ({ item, trueRank: i + 1 }));

  const q = state.search.trim().toLowerCase();
  let filtered = q
    ? withRank.filter((r) => r.item.member.displayName.toLowerCase().includes(q))
    : withRank;

  if (state.dir === 'asc') {
    filtered = [...filtered].sort((a, b) => opts.getValue(a.item) - opts.getValue(b.item));
  }

  if (countEl) {
    countEl.textContent = filtered.length ? `${Math.min(state.visible, filtered.length)} / ${filtered.length}` : '';
  }

  if (!filtered.length) {
    el.innerHTML = `<li class="empty-state">${q ? 'Tidak ada nama yang cocok.' : 'Belum ada data untuk ditampilkan.'}</li>`;
    if (moreBtn) moreBtn.hidden = true;
    return;
  }

  const max = Math.max(...filtered.map((r) => opts.getValue(r.item)), 1);
  const visibleSlice = filtered.slice(0, state.visible);

  el.innerHTML = visibleSlice.map(({ item, trueRank }) => {
    const value = opts.getValue(item);
    const pct = Math.max(6, Math.round((value / max) * 100));
    const isFirst = trueRank === 1 && state.dir === 'desc' && !q;
    const medal = MEDALS[trueRank];
    const rowStyle = isFirst
      ? `style="--row-accent:${ACCENTS[opts.accent]};--row-accent-dim:${ACCENT_DIM[opts.accent]}"`
      : '';

    const prev = seen.get(item.member.id);
    const didChange = prev !== undefined && prev !== value;
    seen.set(item.member.id, value);

    const rankHtml = medal
      ? `<span class="rank is-medal ${medal[0]}">${medal[1]}</span>`
      : `<span class="rank ${trueRank <= 10 ? 'is-top10' : ''}">${trueRank}</span>`;

    return `
      <li class="row ${isFirst ? 'is-first' : ''} ${didChange ? 'is-updated' : ''}" ${rowStyle} data-user-id="${item.member.id}">
        ${rankHtml}
        ${avatarImgHtml(item.member)}
        <div class="who">
          <div class="who-name">${escapeHtml(item.member.displayName)}</div>
          <div class="who-sub">${opts.getSub(item)}</div>
        </div>
        <div class="stat">
          <span class="stat-value">${opts.getLabel(item)}</span>
          <div class="signal"><div class="signal-fill" style="width:${pct}%"></div></div>
        </div>
      </li>
    `;
  }).join('');

  if (moreBtn) moreBtn.hidden = state.visible >= filtered.length;
}

async function fetchJson(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`${url} -> ${res.status}`);
  return res.json();
}

function renderMeta(meta) {
  document.getElementById('guildName').textContent = meta.guild.name;
  document.getElementById('metaLine').textContent = `${meta.totalUsers.toLocaleString('id-ID')} member terlacak`;
  const iconEl = document.getElementById('guildIcon');
  if (meta.guild.icon) {
    iconEl.innerHTML = `<img src="${meta.guild.icon}" alt="" />`;
  } else {
    iconEl.textContent = (meta.guild.name || '?').charAt(0).toUpperCase();
  }
}

const BOARD_OPTS = {
  rowsXp: {
    accent: 'xp',
    countId: 'countXp',
    moreId: 'moreXp',
    getValue: (r) => r.xp,
    getLabel: (r) => `${formatCompact(r.xp)} xp`,
    getSub: (r) => `Level ${r.level}`
  },
  rowsVoice: {
    accent: 'voice',
    countId: 'countVoice',
    moreId: 'moreVoice',
    getValue: (r) => r.voiceMins,
    getLabel: (r) => formatVoiceMinutes(r.voiceMins),
    getSub: (r) => `Level ${r.level}`
  },
  rowsChat: {
    accent: 'chat',
    countId: 'countChat',
    moreId: 'moreChat',
    getValue: (r) => r.messages,
    getLabel: (r) => `${formatCompact(r.messages)} pesan`,
    getSub: (r) => `Level ${r.level}`
  }
};

function renderBoards({ leaderboard, topvoice, topchat }) {
  boardData.rowsXp = leaderboard;
  boardData.rowsVoice = topvoice;
  boardData.rowsChat = topchat;

  renderRows('rowsXp', leaderboard, BOARD_OPTS.rowsXp);
  renderRows('rowsVoice', topvoice, BOARD_OPTS.rowsVoice);
  renderRows('rowsChat', topchat, BOARD_OPTS.rowsChat);
}

// Re-renders a single board from cached data — used when the user types in
// search, flips sort direction, or clicks "load more" (no network round-trip).
function rerenderBoard(containerId) {
  renderRows(containerId, boardData[containerId] || [], BOARD_OPTS[containerId]);
}

function setupBoardControls() {
  Object.keys(BOARD_OPTS).forEach((containerId) => {
    const suffix = containerId.replace('rows', ''); // Xp | Voice | Chat
    const searchInput = document.getElementById(`search${suffix}`);
    const sortBtn = document.getElementById(`sort${suffix}`);
    const moreBtn = document.getElementById(`more${suffix}`);
    const state = boardState[containerId];

    let debounce;
    searchInput?.addEventListener('input', (e) => {
      clearTimeout(debounce);
      debounce = setTimeout(() => {
        state.search = e.target.value;
        state.visible = PAGE_SIZE;
        rerenderBoard(containerId);
      }, 120);
    });

    sortBtn?.addEventListener('click', () => {
      state.dir = state.dir === 'desc' ? 'asc' : 'desc';
      state.visible = PAGE_SIZE;
      sortBtn.dataset.dir = state.dir;
      rerenderBoard(containerId);
    });

    moreBtn?.addEventListener('click', () => {
      state.visible += PAGE_SIZE;
      rerenderBoard(containerId);
    });
  });
}

function setSyncLabel(text) {
  document.getElementById('updatedAt').textContent = text;
}

// ======================
// REALTIME (Socket.io) — sumber utama data dashboard
// ======================
let liveConnected = false;

function setupRealtime() {
  if (typeof io === 'undefined') return false;

  const socket = io();

  socket.on('connect', () => {
    liveConnected = true;
    setSyncLabel('live • tersambung');
  });

  socket.on('dashboard:update', (payload) => {
    renderMeta(payload);
    renderBoards(payload);
    setSyncLabel(`live • ${new Date(payload.updatedAt).toLocaleTimeString('id-ID')}`);
  });

  socket.on('disconnect', () => {
    liveConnected = false;
    setSyncLabel('koneksi live terputus — mencoba lagi…');
  });

  return true;
}

// ======================
// FALLBACK: polling REST biasa, dipakai kalau Socket.io gagal konek
// ======================
async function refreshMeta() {
  if (liveConnected) return;
  try {
    const meta = await fetchJson('/api/meta');
    renderMeta(meta);
  } catch (e) {
    console.error(e);
  }
}

async function refreshBoards() {
  if (liveConnected) return;
  try {
    const [leaderboard, topvoice, topchat] = await Promise.all([
      fetchJson('/api/leaderboard'),
      fetchJson('/api/topvoice'),
      fetchJson('/api/topchat')
    ]);

    renderBoards({ leaderboard, topvoice, topchat });
    setSyncLabel(`terakhir sinkron ${new Date().toLocaleTimeString('id-ID')}`);
  } catch (e) {
    console.error(e);
    setSyncLabel('gagal sinkron — mencoba lagi…');
  }
}

function tickClock() {
  document.getElementById('clock').textContent = new Date().toLocaleTimeString('id-ID', { hour12: false });
}

// ======================
// USER CARD MODAL
// ======================
function formatDateTime(value) {
  if (!value) return '—';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '—';
  return `${date.toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })} • ${date.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })}`;
}

function openUserModal() {
  document.getElementById('userModalOverlay').classList.add('is-open');
}

function closeUserModal() {
  document.getElementById('userModalOverlay').classList.remove('is-open');
}

async function showUserCard(userId) {
  openUserModal();

  document.getElementById('ucAvatar').src = '';
  document.getElementById('ucDisplayName').textContent = 'Memuat…';
  document.getElementById('ucUsername').textContent = '';
  document.getElementById('ucCreated').textContent = '—';
  document.getElementById('ucJoined').textContent = '—';
  document.getElementById('ucLevel').textContent = '—';
  document.getElementById('ucRank').textContent = '—';
  document.getElementById('ucXpText').textContent = '—';
  document.getElementById('ucXpFill').style.width = '0%';
  document.getElementById('ucTokens').textContent = '—';
  document.getElementById('ucMessages').textContent = '—';
  document.getElementById('ucReactions').textContent = '—';
  document.getElementById('ucVoice').textContent = '—';
  document.getElementById('ucRoles').innerHTML = '';

  try {
    const profile = await fetchJson(`/api/user/${userId}`);
    document.getElementById('ucAvatar').src = profile.avatar;
    document.getElementById('ucDisplayName').textContent = profile.displayName;
    document.getElementById('ucUsername').textContent = `@${profile.username}`;
    document.getElementById('ucCreated').textContent = formatDateTime(profile.createdAt);
    document.getElementById('ucJoined').textContent = formatDateTime(profile.joinedAt);

    document.getElementById('ucLevel').textContent = profile.level;
    document.getElementById('ucRank').textContent = `#${profile.rank}`;
    document.getElementById('ucXpText').textContent = `${formatCompact(profile.xp)} / ${formatCompact(profile.nextLevelXp)} xp`;
    document.getElementById('ucXpFill').style.width = `${Math.max(4, profile.xpPercent)}%`;

    document.getElementById('ucTokens').textContent = formatCompact(profile.tokens);
    document.getElementById('ucMessages').textContent = formatCompact(profile.messages);
    document.getElementById('ucReactions').textContent = formatCompact(profile.reactions);
    document.getElementById('ucVoice').textContent = formatVoiceMinutes(profile.voiceMins);

    const rolesEl = document.getElementById('ucRoles');
    if (!profile.roles || profile.roles.length === 0) {
      rolesEl.innerHTML = '<span class="role-chip role-chip-empty">Tidak ada role</span>';
    } else {
      rolesEl.innerHTML = profile.roles
        .map((r) => `<span class="role-chip" style="--role-color:${r.color}">${escapeHtml(r.name)}</span>`)
        .join('');
    }
  } catch (e) {
    console.error(e);
    document.getElementById('ucDisplayName').textContent = 'Gagal memuat data user';
  }
}

function setupUserCard() {
  document.getElementById('userModalClose').addEventListener('click', closeUserModal);
  document.getElementById('userModalOverlay').addEventListener('click', (e) => {
    if (e.target.id === 'userModalOverlay') closeUserModal();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeUserModal();
  });

  ['rowsXp', 'rowsVoice', 'rowsChat'].forEach((id) => {
    const el = document.getElementById(id);
    el.addEventListener('click', (e) => {
      const row = e.target.closest('.row');
      if (!row || !row.dataset.userId) return;
      showUserCard(row.dataset.userId);
    });
  });
}

function moveTabThumb(btn) {
  const thumb = document.getElementById('tabbarThumb');
  if (!thumb || !btn) return;
  const index = Array.from(btn.parentElement.querySelectorAll('.tab-btn')).indexOf(btn);
  thumb.style.transform = `translateX(${index * 100}%)`;
}

// ======================
// ME FINDER — quick "find yourself" lookup across all tracked members,
// opens the same user-card modal used elsewhere (no separate stats view needed
// since the leaderboard board already contains every tracked user).
// ======================
function setupMeFinder() {
  const input = document.getElementById('meFinderInput');
  const results = document.getElementById('meFinderResults');
  if (!input || !results) return;

  function closeResults() {
    results.classList.remove('is-open');
    results.innerHTML = '';
  }

  let debounce;
  input.addEventListener('input', () => {
    clearTimeout(debounce);
    debounce = setTimeout(() => {
      const q = input.value.trim().toLowerCase();
      if (!q) return closeResults();

      const pool = boardData.rowsXp.length ? boardData.rowsXp : boardData.rowsVoice;
      const matches = pool
        .filter((r) => r.member.displayName.toLowerCase().includes(q))
        .slice(0, 8);

      if (!matches.length) {
        results.innerHTML = '<div class="me-finder-empty">Tidak ditemukan.</div>';
        results.classList.add('is-open');
        return;
      }

      results.innerHTML = matches.map((r) => `
        <div class="me-finder-row" data-user-id="${r.member.id}">
          <img src="${r.member.avatar}" alt="" />
          <span class="me-finder-row-name">${escapeHtml(r.member.displayName)}</span>
          <span class="me-finder-row-sub">Lv.${r.level}</span>
        </div>
      `).join('');
      results.classList.add('is-open');
    }, 120);
  });

  results.addEventListener('click', (e) => {
    const row = e.target.closest('.me-finder-row');
    if (!row) return;
    showUserCard(row.dataset.userId);
    input.value = '';
    closeResults();
  });

  document.addEventListener('click', (e) => {
    if (!e.target.closest('.me-finder')) closeResults();
  });
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeResults();
  });
}

function setupTabs() {
  const buttons = document.querySelectorAll('.tab-btn');
  buttons.forEach((btn) => {
    btn.addEventListener('click', () => {
      buttons.forEach((b) => b.classList.remove('is-active'));
      document.querySelectorAll('.panel').forEach((p) => p.classList.remove('is-active'));
      btn.classList.add('is-active');
      document.getElementById(btn.dataset.panel).classList.add('is-active');
      moveTabThumb(btn);
    });
  });
  // default: show first panel on mobile
  document.getElementById('panel-xp').classList.add('is-active');
  moveTabThumb(document.querySelector('.tab-btn.is-active'));
}

setupTabs();
setupUserCard();
setupBoardControls();
setupMeFinder();
tickClock();
setInterval(tickClock, 1000);

setupRealtime();

// Selalu load sekali dari REST saat pertama buka (biar nggak nunggu event pertama),
// setelah itu Socket.io yang ambil alih kalau berhasil konek.
refreshMeta();
refreshBoards();

// Fallback polling — otomatis no-op selama Socket.io masih tersambung (liveConnected = true)
setInterval(refreshMeta, 60000);
setInterval(refreshBoards, REFRESH_MS);
