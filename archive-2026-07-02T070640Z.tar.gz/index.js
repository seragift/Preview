const { Client, GatewayIntentBits, Collection } = require('discord.js');

const fs = require('fs');

const path = require('path');

const config = require('./config.json');

const client = new Client({

    intents: [

        GatewayIntentBits.Guilds,

        GatewayIntentBits.GuildMessages,

        GatewayIntentBits.MessageContent

    ]

});

client.commands = new Collection();

// Baca Perintah (Commands) dari subfolder

const commandsPath = path.join(__dirname, 'src/commands');

const commandFolders = fs.readdirSync(commandsPath);

for (const folder of commandFolders) {

    const folderPath = path.join(commandsPath, folder);

    const commandFiles = fs.readdirSync(folderPath).filter(file => file.endsWith('.js'));

    for (const file of commandFiles) {

        const filePath = path.join(folderPath, file);

        const command = require(filePath);

        if ('data' in command && 'execute' in command) {

            client.commands.set(command.data.name, command);

        }

    }

}

// Baca Event (Events)

const eventsPath = path.join(__dirname, 'src/events');

const eventFiles = fs.readdirSync(eventsPath).filter(file => file.endsWith('.js'));

for (const file of eventFiles) {

    const filePath = path.join(eventsPath, file);

    const event = require(filePath);

    if (event.once) {

        client.once(event.name, (...args) => event.execute(...args, client));

    } else {

        client.on(event.name, (...args) => event.execute(...args, client));

    }

}

// Handler Interaksi untuk Slash Commands

client.on('interactionCreate', async interaction => {

    if (!interaction.isChatInputCommand()) return;

    const command = client.commands.get(interaction.commandName);

    if (!command) return;

    try {

        await command.execute(interaction);

    } catch (error) {

        console.error(error);

        if (interaction.replied || interaction.deferred) {

            await interaction.followUp({ content: 'Terjadi error saat menjalankan command!', ephemeral: true });

        } else {

            await interaction.reply({ content: 'Terjadi error saat menjalankan command!', ephemeral: true });

        }

    }

});

client.login(config.token);