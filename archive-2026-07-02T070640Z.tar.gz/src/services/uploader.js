const axios = require('axios');

const FormData = require('form-data');

const fs = require('fs');

module.exports = {

    uploadToTop4Top: async (filePath, fileName) => {

        const formData = new FormData();

        formData.append('file_0_', fs.createReadStream(filePath), {

            filename: fileName,

            contentType: 'audio/mpeg'

        });

        formData.append('submitr', 'تحميل الملفات');

        const response = await axios.post('https://top4top.io/index.php', formData, {

            headers: {

                ...formData.getHeaders(),

                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'

            },

            maxContentLength: Infinity,

            maxBodyLength: Infinity

        });

        const html = response.data;

        const linkMatch = html.match(/value="(https:\/\/top4top\.io\/downloadf-[^"]+)"/) || 

                          html.match(/href="(https?:\/\/b\.top4top\.io\/m_[^"]+\.mp3)"/) ||

                          html.match(/value="(https?:\/\/.\.top4top\.io\/m_[^"]+\.mp3)"/);

        if (!linkMatch) throw new Error('Gagal memparsing link upload Top4top.');

        return linkMatch[1];

    }

};