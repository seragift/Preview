const YTDlpWrap = require('yt-dlp-wrap').default;

const ffmpeg = require('fluent-ffmpeg');

const path = require('path');

const fs = require('fs');

const ytdlpPath = path.join(process.cwd(), 'yt-dlp');

let ytdlp;

async function initYtdlp() {

    if (!fs.existsSync(ytdlpPath)) {

        console.log('📥 yt-dlp tidak ditemukan. Mengunduh yt-dlp otomatis...');

        try {

            await YTDlpWrap.downloadFromGithub(ytdlpPath);

            fs.chmodSync(ytdlpPath, '755');

            console.log('✅ yt-dlp berhasil diunduh otomatis!');

        } catch (err) {

            console.error('❌ Gagal mengunduh yt-dlp otomatis:', err);

            process.exit(1);

        }

    }

    ytdlp = new YTDlpWrap(ytdlpPath);

}

function formatDuration(seconds) {

    if (!seconds) return '00:00';

    const date = new Date(0);

    date.setSeconds(seconds);

    const timeString = date.toISOString().substr(11, 8);

    return timeString.startsWith('00:') ? timeString.substr(3) : timeString;

}

async function getVideoInfo(videoUrl) {

    if (!ytdlp) await initYtdlp();

    const metadata = await ytdlp.getVideoInfo(videoUrl);

    

    // Cari thumbnail terbaik

    const thumbnail = metadata.thumbnail || (metadata.thumbnails && metadata.thumbnails.length ? metadata.thumbnails[metadata.thumbnails.length - 1].url : 'https://i.imgur.com/8Q5FqW0.png');

    return {

        title: metadata.title || 'Unknown Title',

        durationSeconds: metadata.duration || 0,

        durationString: formatDuration(metadata.duration),

        channelName: metadata.uploader || 'Unknown Channel',

        views: metadata.view_count ? metadata.view_count.toLocaleString('id-ID') : '0',

        thumbnailUrl: thumbnail

    };

}

async function processAudio(videoUrl, videoId) {

    if (!ytdlp) await initYtdlp();

    const tempVideoPath = path.join(process.cwd(), `video_${videoId}.mp4`);

    const tempAudioPath = path.join(process.cwd(), `audio_${videoId}.mp3`);

    // 1. Download Audio Mentah

    await ytdlp.execPromise([videoUrl, '-f', 'ba', '-o', tempVideoPath]);

    // 2. Convert ke MP3 via FFmpeg sesuai settinganmu

    await new Promise((resolve, reject) => {

        ffmpeg(tempVideoPath)

            .toFormat('mp3')

            .audioBitrate(192)

            .on('end', resolve)

            .on('error', reject)

            .save(tempAudioPath);

    });

    // Hapus file mentah mp4 sementara

    if (fs.existsSync(tempVideoPath)) fs.unlinkSync(tempVideoPath);

    return tempAudioPath; // Kembalikan path mp3 siap upload

}

module.exports = {

    initYtdlp,

    getVideoInfo,

    processAudio

};