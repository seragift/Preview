const db = require('../database/database');

const ytService = require('../services/youtube');

const { uploadToTop4Top } = require('../services/uploader');

const { createMusicEmbed } = require('../embeds/musicEmbed');

const { EmbedBuilder } = require('discord.js');

const fs = require('fs');

// Library untuk Spotify info dan Play-DL pencarian YouTube

const spotifyUrlInfo = require('spotify-url-info')(require('isomorphic-unfetch')); 

const play = require('play-dl'); 

function getWIBDate() {

    const d = new Date();

    const wibTime = new Date(d.getTime() + (7 * 60 * 60 * 1000));

    return wibTime.toISOString().split('T')[0];

}

function checkUserStatus(userId) {

    const now = Date.now();

    const premium = db.prepare('SELECT expires_at FROM premium_users WHERE user_id = ?').get(userId);

    if (premium && premium.expires_at > now) {

        return { isPremium: true, maxDuration: Infinity };

    }

    if (premium) {

        db.prepare('DELETE FROM premium_users WHERE user_id = ?').run(userId);

    }

    const today = getWIBDate();

    let userLimit = db.prepare('SELECT * FROM daily_limits WHERE user_id = ?').get(userId);

    if (!userLimit || userLimit.last_reset !== today) {

        db.prepare('INSERT OR REPLACE INTO daily_limits (user_id, count, last_reset) VALUES (?, 0, ?)')

          .run(userId, today);

        userLimit = { count: 0 };

    }

    return { isPremium: false, count: userLimit.count, maxDuration: 3600 };

}

function incrementLimit(userId) {

    const today = getWIBDate();

    db.prepare('UPDATE daily_limits SET count = count + 1 WHERE user_id = ? AND last_reset = ?')

      .run(userId, today);

}

function createProgressEmbed(message, statusTitle, progressBar) {

    const botName = message.client.user.username;

    const serverName = message.guild.name;

    return new EmbedBuilder()

        .setColor('#1DB954') // Menggunakan warna khas Spotify hijau

        .setTitle(statusTitle)

        .setDescription(`Mohon tunggu sebentar, sistem sedang memproses permintaanmu.\n\n${progressBar}`)

        .setFooter({ text: `${botName} • ${serverName}` })

        .setTimestamp();

}

/**

 * Handle konversi Link Spotify

 */

async function handleSpotifyConversion(message, spotifyUrl, forceConvert = false) {

    const botName = message.client.user.username;

    const serverName = message.guild.name;

    const embedTitle = forceConvert ? '♻️ [CONVERT ULANG] Memproses Spotify...' : '🎵 Memproses Spotify...';

    // Kirim loading awal pencarian metadata Spotify (Progres 10%)

    const loadingMessage = await message.reply({ 

        embeds: [createProgressEmbed(message, embedTitle, '▰▱▱▱▱▱▱▱▱▱')] 

    });

    try {

        // 1. Ambil data lagu dari Spotify URL

        const trackData = await spotifyUrlInfo.getPreview(spotifyUrl);

        const querySearch = `${trackData.title} - ${trackData.artist}`;

        // 2. Update loading: Mencari lagu di YouTube (Progres 30%)

        await loadingMessage.edit({ 

            embeds: [createProgressEmbed(message, embedTitle, '▰▰▰▱▱▱▱▱▱▱')] 

        });

        // PERBAIKAN: Menggunakan play-dl untuk mencari video di YouTube

        const ytSearch = await play.search(querySearch, { limit: 1, source: { youtube: 'video' } });

        

        if (!ytSearch || ytSearch.length === 0) {

            const noResultEmbed = new EmbedBuilder()

                .setColor('#C0392B')

                .setTitle('❌ Lagu Tidak Ditemukan')

                .setDescription(`Sistem gagal menemukan padanan lagu **${querySearch}** di platform streaming YouTube.`)

                .setFooter({ text: `${botName} • ${serverName}` })

                .setTimestamp();

            return await loadingMessage.edit({ embeds: [noResultEmbed] });

        }

        const videoUrl = ytSearch[0].url;

        const videoId = ytSearch[0].id;

        // 3. Hapus pesan loading pencarian Spotify, lalu oper ke handler utama youtube convert

        await loadingMessage.delete();

        await handleVideoConversion(message, videoUrl, videoId, forceConvert);

    } catch (error) {

        console.error(error);

        const errorEmbed = new EmbedBuilder()

            .setColor('#C0392B')

            .setTitle('❌ Spotify Fetch Gagal')

            .setDescription(`Gagal mengambil informasi dari link Spotify tersebut.\n\n**Penyebab:** \`${error.message}\``)

            .setFooter({ text: `${botName} • ${serverName}` })

            .setTimestamp();

            

        if (loadingMessage) await loadingMessage.edit({ embeds: [errorEmbed] });

    }

}

/**

 * Handle inti konversi video YouTube ke MP3 dan Upload ke Top4Top

 */

async function handleVideoConversion(message, videoUrl, videoId, forceConvert = false) {

    const userId = message.author.id;

    const botName = message.client.user.username;

    const serverName = message.guild.name;

    if (!forceConvert) {

        const cachedVideo = db.prepare('SELECT * FROM converted_videos WHERE video_id = ?').get(videoId);

        if (cachedVideo) {

            const embed = createMusicEmbed({

                title: cachedVideo.title,

                duration: cachedVideo.duration,

                convertDuration: cachedVideo.convert_duration,

                channel: cachedVideo.channel_name,

                views: cachedVideo.views,

                thumbnail: cachedVideo.thumbnail_url,

                url: cachedVideo.converted_url,

                author: message.author,

                status: `⚡ Diambil langsung dari Database Cache! | ${botName} • ${serverName}`

            });

            return message.reply({ embeds: [embed] });

        }

    }

    const userStatus = checkUserStatus(userId);

    if (!userStatus.isPremium && userStatus.count >= 5) {

        const limitEmbed = new EmbedBuilder()

            .setColor('#C0392B')

            .setTitle('❌ Kuota Habis')

            .setDescription('Kuota harian kamu habis! (Maks 5x convert per hari).\nQuota reset otomatis setiap jam **00:00 WIB**.')

            .setFooter({ text: `${botName} • ${serverName}` })

            .setTimestamp();

        return message.reply({ embeds: [limitEmbed] });

    }

    const embedTitle = forceConvert ? '♻️ [CONVERT ULANG] Memproses Musik...' : '🎵 Memproses Musik...';

    

    // Progres 50% saat mulai download

    const loadingMessage = await message.reply({ 

        embeds: [createProgressEmbed(message, embedTitle, '▰▰▰▰▰▱▱▱▱▱')] 

    });

    const startTime = Date.now();

    let tempAudioPath = null;

    try {

        const videoInfo = await ytService.getVideoInfo(videoUrl);

        if (!userStatus.isPremium && videoInfo.durationSeconds > userStatus.maxDuration) {

            const durationEmbed = new EmbedBuilder()

                .setColor('#C0392B')

                .setTitle('❌ Durasi Melebihi Batas')

                .setDescription('Durasi video melebihi batas maksimal **1 jam** untuk user non-premium!')

                .setFooter({ text: `${botName} • ${serverName}` })

                .setTimestamp();

            await loadingMessage.delete();

            return message.reply({ embeds: [durationEmbed] });

        }

        // Progres 80% saat upload ke Top4Top

        await loadingMessage.edit({ 

            embeds: [createProgressEmbed(message, embedTitle, '▰▰▰▰▰▰▰▰▱▱')] 

        });

        tempAudioPath = await ytService.processAudio(videoUrl, videoId);

        const safeTitle = `${videoInfo.title.replace(/[^a-zA-Z0-9]/g, '_')}.mp3`;

        const downloadLink = await uploadToTop4Top(tempAudioPath, safeTitle);

        const processedTime = Math.round((Date.now() - startTime) / 1000) + ' detik';

        db.prepare(`

            INSERT OR REPLACE INTO converted_videos (video_id, title, duration, convert_duration, channel_name, views, thumbnail_url, converted_url)

            VALUES (?, ?, ?, ?, ?, ?, ?, ?)

        `).run(videoId, videoInfo.title, videoInfo.durationString, processedTime, videoInfo.channelName, videoInfo.views, videoInfo.thumbnailUrl, downloadLink);

        if (!userStatus.isPremium) {

            incrementLimit(userId);

        }

        const embed = createMusicEmbed({

            title: videoInfo.title,

            duration: videoInfo.durationString,

            convertDuration: processedTime,

            channel: videoInfo.channelName,

            views: videoInfo.views,

            thumbnail: videoInfo.thumbnailUrl,

            url: downloadLink,

            author: message.author,

            status: forceConvert 

                ? `♻️ Berhasil diconvert ulang dan memperbarui database! | ${botName} • ${serverName}` 

                : `✅ Berhasil dikonversi dan disimpan ke cache! | ${botName} • ${serverName}`

        });

        await loadingMessage.edit({ embeds: [embed] });

    } catch (error) {

        console.error(error);

        const errorEmbed = new EmbedBuilder()

            .setColor('#C0392B')

            .setTitle('❌ Proses Konversi Gagal')

            .setDescription(`Terjadi kesalahan internal saat memproses video ke Top4Top.\n\n**Penyebab:** \`${error.message}\``)

            .setFooter({ text: `${botName} • ${serverName}` })

            .setTimestamp();

            

        if (loadingMessage) await loadingMessage.edit({ embeds: [errorEmbed] });

    } finally {

        if (tempAudioPath && fs.existsSync(tempAudioPath)) fs.unlinkSync(tempAudioPath);

    }

}

module.exports = {

    checkUserStatus,

    incrementLimit,

    handleVideoConversion,

    handleSpotifyConversion

};