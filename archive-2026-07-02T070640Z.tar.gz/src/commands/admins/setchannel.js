const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

const db = require('../../database/database');

module.exports = {

    data: new SlashCommandBuilder()

        .setName('setchannel')

        .setDescription('Mengatur status auto convert di channel ini')

        .addChannelOption(option => option.setName('channel').setDescription('Pilih channel').setRequired(true))

        .addStringOption(option => 

            option.setName('status')

                .setDescription('Aktifkan atau Matikan')

                .setRequired(true)

                .addChoices(

                    { name: 'ON', value: 'ON' },

                    { name: 'OFF', value: 'OFF' }

                ))

        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator), // Hanya Administrator

    async execute(interaction) {

        const channel = interaction.options.getChannel('channel');

        const status = interaction.options.getString('status');

        if (status === 'ON') {

            db.prepare('INSERT OR REPLACE INTO active_channels (channel_id) VALUES (?)').run(channel.id);

            return interaction.reply({ content: `✅ Auto-convert berhasil di-**ON**-kan untuk channel ${channel}.` });

        } else {

            db.prepare('DELETE FROM active_channels WHERE channel_id = ?').run(channel.id);

            return interaction.reply({ content: `❌ Auto-convert berhasil di-**OFF**-kan untuk channel ${channel}, data channel dihapus.` });

        }

    }

};