const { SlashCommandBuilder } = require('discord.js');

const db = require('../../database/database');

const config = require('../../../config.json');

module.exports = {

    data: new SlashCommandBuilder()

        .setName('statsconvert')

        .setDescription('Melihat statistik database converter (Owner Only)'),

    async execute(interaction) {

        if (interaction.user.id !== config.ownerId) {

            return interaction.reply({ content: '❌ Perintah ini hanya bisa diakses oleh Owner Bot!', ephemeral: true });

        }

        const totalCache = db.prepare('SELECT COUNT(*) as total FROM converted_videos').get().total;

        const totalPremium = db.prepare('SELECT COUNT(*) as total FROM premium_users').get().total;

        return interaction.reply({

            content: `📊 **Statistik Bot Converter**:\n• Total Video di Cache: **${totalCache}**\n• Total User Premium Aktif: **${totalPremium}**`

        });

    }

};