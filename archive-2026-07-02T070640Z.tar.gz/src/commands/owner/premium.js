const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

const db = require('../../database/database');

const config = require('../../../config.json');

module.exports = {

    data: new SlashCommandBuilder()

        .setName('premium')

        .setDescription('Memberikan akses premium ke user (Owner Only)')

        .addUserOption(option => option.setName('target').setDescription('Target user').setRequired(true))

        .addIntegerOption(option => option.setName('jumlah').setDescription('Jumlah waktu (1-100)').setRequired(true).setMinValue(1).setMaxValue(100))

        .addStringOption(option => 

            option.setName('durasi')

                .setDescription('Satuan waktu')

                .setRequired(true)

                .addChoices(

                    { name: 'Jam', value: 'jam' },

                    { name: 'Hari', value: 'hari' },

                    { name: 'Bulan', value: 'bulan' }

                )),

    async execute(interaction) {

        if (interaction.user.id !== config.ownerId) {

            return interaction.reply({ content: '❌ Perintah ini hanya bisa diakses oleh Owner Bot!', ephemeral: true });

        }

        const target = interaction.options.getUser('target');

        const jumlah = interaction.options.getInteger('jumlah');

        const durasi = interaction.options.getString('durasi');

        let durationMs = 0;

        if (durasi === 'jam') durationMs = jumlah * 60 * 60 * 1000;

        else if (durasi === 'hari') durationMs = jumlah * 24 * 60 * 60 * 1000;

        else if (durasi === 'bulan') durationMs = jumlah * 30 * 24 * 60 * 60 * 1000;

        const expiresAt = Date.now() + durationMs;

        db.prepare('INSERT OR REPLACE INTO premium_users (user_id, expires_at) VALUES (?, ?)')

          .run(target.id, expiresAt);

        return interaction.reply({

            content: `✅ Berhasil menambahkan Premium ke **${target.tag}** selama **${jumlah} ${durasi}**.`

        });

    }

};