'use strict';

const fs = require('fs');
const path = require('path');
const { runProcess } = require('../utils/process');
const { parseYtDlpProgress } = require('../utils/progress');

const TMP_DIR = path.join(__dirname, '..', '..', 'tmp', 'downloads');
if (!fs.existsSync(TMP_DIR)) fs.mkdirSync(TMP_DIR, { recursive: true });

/**
 * Engine untuk binary `yt-dlp`. Satu-satunya tempat di seluruh bot yang
 * benar-benar men-spawn proses `yt-dlp` — reusable, tidak nyatu dengan logic
 * event/command. Semua pemanggilan yt-dlp (metadata fallback, download audio
 * asli, download benchmark -N) lewat sini, supaya kalau ada perubahan
 * argumen/flag yt-dlp, cukup diubah di satu file.
 *
 * Dipakai oleh:
 *   - services/youtube.js   -> getMetadata() (fallback saat YOUTUBE_API_KEY kosong/gagal)
 *   - services/downloader.js -> download()   (download audio asli untuk pipeline)
 *   - services/benchmark.js  -> downloadRaw() (benchmark -N 1/4/8/16)
 */

/**
 * Ambil metadata video via `yt-dlp --dump-single-json`.
 */
async function getMetadata(url) {
  const { promise } = runProcess(
    'yt-dlp',
    ['--dump-single-json', '--no-playlist', '--skip-download', url],
    { timeoutMs: 30_000 }
  );

  const { stdout } = await promise;

  let data;
  try {
    data = JSON.parse(stdout);
  } catch (err) {
    throw new Error('Gagal parse metadata dari yt-dlp (output bukan JSON valid).');
  }

  return {
    videoId: data.id,
    title: data.title,
    channel: data.uploader || data.channel || 'Unknown',
    duration: Math.round(data.duration || 0),
    thumbnail: data.thumbnail,
    webpageUrl: data.webpage_url || url
  };
}

/**
 * Download audio (format terbaik / sesuai config) via `yt-dlp` langsung
 * lewat spawn() — bukan exec() — supaya URL user tidak pernah masuk ke shell
 * string interpolation. File hasil disimpan sebagai `<videoId>.<ext asli>`
 * di tmp/downloads/.
 *
 * @param {string} url
 * @param {string} videoId
 * @param {{format?:string, noPlaylist?:boolean, concurrentFragments?:number}} options
 * @param {(p: {percent:number, totalSize:string, speed:string, eta:string}) => void} [onProgress]
 */
async function download(url, videoId, options = {}, onProgress) {
  const { format = 'ba', noPlaylist = true, concurrentFragments = 1 } = options;
  const outputTemplate = path.join(TMP_DIR, '%(id)s.%(ext)s');

  const args = ['-f', format, '--no-part', '--newline'];
  if (noPlaylist) args.push('--no-playlist');
  if (concurrentFragments > 1) args.push('-N', String(concurrentFragments));
  args.push('-o', outputTemplate, url);

  const { promise } = runProcess('yt-dlp', args, {
    timeoutMs: 15 * 60 * 1000, // 15 menit safety timeout untuk download
    onStdout: (chunk) => {
      if (!onProgress) return;
      for (const line of chunk.split('\n')) {
        const parsed = parseYtDlpProgress(line);
        if (parsed) onProgress(parsed);
      }
    }
  });

  await promise;

  // yt-dlp menentukan ekstensi sendiri (webm/m4a/opus/dll) tergantung format
  // sumber, jadi cari file yang benar-benar dihasilkan berdasarkan prefix ID.
  const files = fs
    .readdirSync(TMP_DIR)
    .filter((f) => f.startsWith(`${videoId}.`) && !f.endsWith('.part'));

  if (files.length === 0) {
    throw new Error('File hasil download tidak ditemukan setelah yt-dlp selesai.');
  }

  const filePath = path.join(TMP_DIR, files[0]);
  const size = fs.statSync(filePath).size;

  return { filePath, size };
}

/**
 * Download "mentah" khusus untuk benchmark -N (services/benchmark.js) —
 * output template & concurrency-nya diatur bebas oleh caller, tidak ikut
 * mengecek/menamai file hasil seperti download() biasa (file benchmark
 * dihapus lagi begitu selesai diukur, bukan diproses lebih lanjut).
 */
async function downloadRaw(url, outputTemplate, options = {}) {
  const { format = 'ba', concurrentFragments = 1, timeoutMs = 5 * 60 * 1000 } = options;

  const args = [
    '-f', format,
    '--no-playlist',
    '--no-part',
    '-N', String(concurrentFragments),
    '-o', outputTemplate,
    url
  ];

  const { promise } = runProcess('yt-dlp', args, { timeoutMs });
  await promise;
}

module.exports = { getMetadata, download, downloadRaw, TMP_DIR };
