'use strict';

const fs = require('fs');
const path = require('path');

const CONFIG_PATH = path.join(__dirname, '..', 'config.json');

// Dipakai kalau config.json belum ada / rusak / sebagian field belum diisi —
// bot tetap bisa jalan tanpa config.json sama sekali (nilainya sama dengan
// yang ada di config.json bawaan project).
const DEFAULT_CONFIG = {
  youtube: {
    format: 'ba',
    concurrentFragments: 4,
    noPlaylist: true
  },
  audio: {
    codec: 'libshine',
    bitrate: '128k'
  },
  queue: {
    maxConcurrent: 5,
    maxWaiting: 100
  },
  limits: {
    maxDuration: 3600,
    maxFileSize: 100000000,
    maxConcurrentJobs: 5,
    dailyConvertLimit: 50
  },
  top4top: {
    enabled: true,
    verifyRetries: 3
  },
  cache: {
    ttlSeconds: 604800
  },
  progress: {
    editIntervalMs: 1500
  },
  embed: {
    color: '#57F287',
    footerText: 'YouTube/Spotify to MP3 • Top4Top'
  }
};

/**
 * Merge dangkal-per-kategori: tiap key top-level (`youtube`, `audio`, dst)
 * dari config.json ditimpakan ke atas default-nya, jadi kalau user cuma
 * ngisi sebagian field (mis. cuma `audio.bitrate`) field lain di kategori
 * yang sama tetap kepakai dari default, bukan hilang semua.
 */
function mergeWithDefaults(userConfig) {
  const merged = {};
  for (const key of Object.keys(DEFAULT_CONFIG)) {
    const defaultSection = DEFAULT_CONFIG[key];
    const userSection = userConfig[key];

    if (
      userSection &&
      typeof userSection === 'object' &&
      !Array.isArray(userSection) &&
      typeof defaultSection === 'object'
    ) {
      merged[key] = { ...defaultSection, ...userSection };
    } else {
      merged[key] = userSection !== undefined ? userSection : defaultSection;
    }
  }
  return merged;
}

function loadConfig() {
  if (!fs.existsSync(CONFIG_PATH)) {
    console.warn('[CONFIG] config.json tidak ditemukan — memakai konfigurasi default bawaan.');
    return DEFAULT_CONFIG;
  }

  let raw;
  try {
    raw = fs.readFileSync(CONFIG_PATH, 'utf8');
  } catch (err) {
    console.warn(`[CONFIG] Gagal baca config.json (${err.message}) — memakai konfigurasi default bawaan.`);
    return DEFAULT_CONFIG;
  }

  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch (err) {
    console.warn(`[CONFIG] config.json tidak valid (${err.message}) — memakai konfigurasi default bawaan.`);
    return DEFAULT_CONFIG;
  }

  return mergeWithDefaults(parsed);
}

// Dimuat sekali saat pertama kali di-require, lalu di-cache oleh Node
// (perilakunya sama seperti `require('./config.json')` langsung).
module.exports = loadConfig();
