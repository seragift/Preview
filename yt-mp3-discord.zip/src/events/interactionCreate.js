'use strict';

const { Events, PermissionFlagsBits } = require('discord.js');

async function handleDeleteButton(interaction) {
  const [, requesterId] = interaction.customId.split(':');

  const isRequester = interaction.user.id === requesterId;
  const isManager = interaction.inGuild() && interaction.memberPermissions?.has(PermissionFlagsBits.ManageMessages);

  if (!isRequester && !isManager) {
    return interaction.reply({
      content: '❌ Cuma yang request atau admin (Manage Messages) yang bisa hapus pesan ini.',
      ephemeral: true
    });
  }

  await interaction.message.delete().catch(() => {});
}

module.exports = {
  name: Events.InteractionCreate,
  async execute(interaction) {
    if (interaction.isButton() && interaction.customId.startsWith('ytmp3_delete:')) {
      return handleDeleteButton(interaction).catch((err) => {
        console.error('[ERROR] Gagal handle tombol Hapus:', err);
      });
    }

    if (!interaction.isChatInputCommand()) return;

    const command = interaction.client.commands.get(interaction.commandName);
    if (!command) return;

    try {
      await command.execute(interaction);
    } catch (err) {
      console.error(`[ERROR] Command ${interaction.commandName} gagal:`, err);

      const payload = { content: '❌ Terjadi kesalahan saat menjalankan command.', ephemeral: true };
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp(payload).catch(() => {});
      } else {
        await interaction.reply(payload).catch(() => {});
      }
    }
  }
};
