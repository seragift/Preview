'use strict';

const { Events } = require('discord.js');
const { getConfiguredChannel } = require('../services/channelConfig');
const { isYoutubeUrl } = require('../services/youtube');
const { isSpotifyUrl } = require('../services/spotify');
const jobQueue = require('../services/queueInstance');
const { runYoutubeJob } = require('../utils/discordRunner');
const config = require('../config');

const MAX_WAITING = config.queue?.maxWaiting ?? 100;

// Ambil kandidat URL pertama dari isi pesan (user cukup paste link saja).
const URL_RE = /https?:\/\/[^\s<>]+/i;

module.exports = {
  name: Events.MessageCreate,
  async execute(message) {
    if (message.author.bot) return;
    if (!message.inGuild()) return;

    const configuredChannel = getConfiguredChannel(message.guildId);
    if (!configuredChannel || configuredChannel !== message.channelId) return;

    const found = message.content.match(URL_RE);
    if (!found) return; // bukan link, biarkan chat biasa berjalan di channel ini

    const url = found[0];
    if (!isYoutubeUrl(url) && !isSpotifyUrl(url)) return; // link tapi bukan YouTube/Spotify -> abaikan diam-diam

    if (jobQueue.queueLength >= MAX_WAITING) {
      await message.reply('❌ Antrian penuh, coba lagi nanti.').catch(() => {});
      return;
    }

    const statusMessage = await message.reply('⏳ Memproses video...').catch(() => null);
    if (!statusMessage) return;

    jobQueue
      .add(() => runYoutubeJob(statusMessage, url, message.author.id))
      .catch(() => {
        /* pesan error sudah ditangani & ditampilkan di dalam runYoutubeJob */
      });
  }
};
