'use strict';

const fs = require('fs');
const path = require('path');
const { REST, Routes } = require('discord.js');

const COMMANDS_DIR = path.join(__dirname, '..', 'commands');

/**
 * Load seluruh file command dari src/commands/ dan kembalikan array JSON
 * (data.toJSON()) siap dikirim ke Discord API.
 */
function loadCommandData() {
  const files = fs.readdirSync(COMMANDS_DIR).filter((f) => f.endsWith('.js'));
  return files.map((file) => {
    const command = require(path.join(COMMANDS_DIR, file));
    if (!command?.data || !command?.execute) {
      throw new Error(`Command file "${file}" tidak valid (harus punya "data" & "execute").`);
    }
    return command.data.toJSON();
  });
}

/**
 * Reset (hapus semua command lama) lalu deploy ulang command yang baru.
 * Dipakai baik oleh script standalone (deploy-commands.js) maupun otomatis
 * setiap kali index.js dijalankan, supaya command yang di-rename/dihapus
 * dari kode tidak nyangkut jadi "command hantu" di Discord.
 *
 * Menggunakan guild commands (instan) jika GUILD_ID di-set di .env,
 * jika tidak akan deploy sebagai global commands (propagasi bisa ~1 jam).
 */
async function deployCommands({ token, clientId, guildId, log = console.log } = {}) {
  const rest = new REST({ version: '10' }).setToken(token);
  const route = guildId
    ? Routes.applicationGuildCommands(clientId, guildId)
    : Routes.applicationCommands(clientId);

  const commandsData = loadCommandData();

  log(`[DEPLOY] Reset command lama (${guildId ? 'guild' : 'global'})...`);
  await rest.put(route, { body: [] });

  log(`[DEPLOY] Mendaftarkan ${commandsData.length} command baru...`);
  const result = await rest.put(route, { body: commandsData });

  log(`[DEPLOY] Selesai. ${result.length} command aktif: ${commandsData.map((c) => c.name).join(', ')}`);
  return result;
}

module.exports = { deployCommands, loadCommandData };
