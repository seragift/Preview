'use strict';

const ytdlpEngine = require('../engine/ytdlp');

/**
 * Download audio untuk pipeline utama. Logic spawn yt-dlp yang sebenarnya
 * ada di src/engine/ytdlp.js (satu-satunya tempat binary yt-dlp dipanggil)
 * — file ini hanya menjembatani config.json bot ke opsi engine.
 */
async function downloadAudio(url, videoId, config, onProgress) {
  return ytdlpEngine.download(
    url,
    videoId,
    {
      format: config.youtube.format || 'ba',
      noPlaylist: config.youtube.noPlaylist !== false,
      concurrentFragments: config.youtube.concurrentFragments || 1
    },
    onProgress
  );
}

module.exports = { downloadAudio, TMP_DIR: ytdlpEngine.TMP_DIR };
