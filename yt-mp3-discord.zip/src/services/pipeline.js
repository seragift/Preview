'use strict';

const path = require('path');
const config = require('../config');

const { isYoutubeUrl, validateYoutubeUrl, getMetadata } = require('./youtube');
const { isSpotifyUrl, extractTrackId, getTrackMetadata, findYoutubeMatch } = require('./spotify');
const { downloadAudio } = require('./downloader');
const { convertToMp3, validateMp3 } = require('./converter');
const { uploadWithVerification } = require('./top4top');
const { getCached, setCached } = require('./cache');
const { checkAndConsume } = require('./dailyLimiter');
const { cleanupFiles } = require('../utils/cleanup');
const { formatBytes, formatSeconds } = require('../utils/format');

const MP3_DIR = path.join(__dirname, '..', '..', 'tmp', 'downloads');

// Video yang sedang diproses (belum selesai) dikunci di sini per video_id.
// Bot dipakai di banyak server sekaligus dengan beberapa worker paralel
// (lihat services/queue.js, config.queue.maxConcurrent) — tanpa lock ini,
// dua guild yang kebetulan request video YANG SAMA secara bersamaan akan
// saling menimpa file temporary (nama file dibuat dari video_id) dan
// men-download/convert video yang sama dua kali secara sia-sia. Request
// kedua & seterusnya cukup "menumpang" pada job pertama yang sedang jalan.
const inFlightJobs = new Map(); // video_id -> Promise<result>

/**
 * Resolusi input URL (YouTube atau Spotify track) menjadi URL YouTube yang
 * siap didownload. Untuk Spotify: ambil metadata track lalu cari padanan
 * videonya di YouTube berdasarkan judul+artis+kemiripan durasi.
 */
async function resolveSourceUrl(rawUrl) {
  if (isYoutubeUrl(rawUrl)) {
    const validation = validateYoutubeUrl(rawUrl);
    if (!validation.valid) {
      const err = new Error(validation.reason);
      err.userFacing = true;
      throw err;
    }
    return { url: validation.url, sourceType: 'youtube', spotifyMeta: null };
  }

  if (isSpotifyUrl(rawUrl)) {
    const trackId = extractTrackId(rawUrl);
    if (!trackId) {
      const err = new Error('Link Spotify tidak valid (bukan link track).');
      err.userFacing = true;
      throw err;
    }

    const spotifyMeta = await getTrackMetadata(trackId);
    const match = await findYoutubeMatch(spotifyMeta);

    return { url: match.webpageUrl, sourceType: 'spotify', spotifyMeta };
  }

  const err = new Error('Hanya link YouTube atau Spotify (track) yang didukung.');
  err.userFacing = true;
  throw err;
}

/**
 * Jalankan pipeline lengkap untuk satu URL (YouTube / Spotify track):
 *   resolve source -> metadata -> limit harian -> (cache? / job sama sedang
 *   berjalan?) -> download -> convert -> validate -> upload+verify -> cache
 *   -> cleanup
 *
 * @param {string} rawUrl
 * @param {object} callbacks
 * @param {(stage: string) => void} [callbacks.onStage] - dipanggil tiap pindah tahap
 * @param {(p: object) => void} [callbacks.onDownloadProgress]
 * @param {(p: object) => void} [callbacks.onConvertProgress]
 * @returns {Promise<object>} hasil lengkap untuk dirender ke embed
 */
async function processYoutubeUrl(rawUrl, callbacks = {}) {
  const { onStage, onDownloadProgress, onConvertProgress } = callbacks;

  // 1. Resolusi sumber (YouTube langsung, atau Spotify -> cari padanan YouTube)
  onStage?.('resolve');
  const { url, sourceType, spotifyMeta } = await resolveSourceUrl(rawUrl);

  // 2. Metadata
  onStage?.('metadata');
  const meta = await getMetadata(url);

  if (meta.duration > config.limits.maxDuration) {
    const err = new Error(
      `Video terlalu panjang. Maksimal: ${Math.floor(config.limits.maxDuration / 60)} menit.`
    );
    err.userFacing = true;
    throw err;
  }

  // 2b. Cek cache (video sudah pernah selesai diproses sebelumnya) — tidak
  // memotong kuota harian, karena tidak ada proses baru yang dilakukan.
  const cached = getCached(meta.videoId);
  if (cached) {
    return {
      fromCache: true,
      sourceType,
      spotifyMeta,
      meta,
      mp3Url: cached.mp3_url,
      sourceSize: null,
      mp3Size: cached.file_size,
      quality: config.audio.bitrate,
      dailyUsage: null,
      timings: { downloadTime: 0, conversionTime: 0, uploadTime: 0, totalTime: 0 }
    };
  }

  // 2c. Video yang sama sedang diproses job lain (server/user berbeda) -> tumpang
  const existingJob = inFlightJobs.get(meta.videoId);
  if (existingJob) {
    onStage?.('shared');
    const result = await existingJob;
    return { ...result, fromCache: false, shared: true };
  }

  // 2d. Limit harian — hanya dipotong untuk proses BARU (bukan cache/shared)
  const limitCheck = checkAndConsume(config.limits.dailyConvertLimit);
  if (!limitCheck.allowed) {
    const err = new Error(
      `Limit harian tercapai (${limitCheck.used}/${limitCheck.limit}). Coba lagi besok.`
    );
    err.userFacing = true;
    throw err;
  }

  // 3-7. Job baru: download -> convert -> validate -> upload -> cache
  const jobPromise = runFullPipeline(meta, url, sourceType, spotifyMeta, limitCheck, {
    onStage,
    onDownloadProgress,
    onConvertProgress
  });
  inFlightJobs.set(meta.videoId, jobPromise);

  try {
    return await jobPromise;
  } finally {
    inFlightJobs.delete(meta.videoId);
  }
}

async function runFullPipeline(meta, url, sourceType, spotifyMeta, dailyUsage, callbacks) {
  const { onStage, onDownloadProgress, onConvertProgress } = callbacks;
  const timings = {};
  const totalStart = performance.now();
  let webmPath = null;
  let mp3Path = null;

  try {
    // 3. Download audio
    onStage?.('download');
    const downloadStart = performance.now();
    const downloaded = await downloadAudio(url, meta.videoId, config, onDownloadProgress);
    webmPath = downloaded.filePath;
    timings.downloadTime = performance.now() - downloadStart;

    if (downloaded.size > config.limits.maxFileSize) {
      const err = new Error('File terlalu besar.');
      err.userFacing = true;
      throw err;
    }

    // 4. Convert ke MP3
    onStage?.('convert');
    mp3Path = path.join(MP3_DIR, `${meta.videoId}.mp3`);
    const convertStart = performance.now();
    const converted = await convertToMp3(webmPath, mp3Path, config, meta.duration, onConvertProgress);
    timings.conversionTime = performance.now() - convertStart;

    // 5. Validasi hasil MP3 (ffprobe) sebelum upload
    const validated = await validateMp3(mp3Path);
    if (!validated.valid) {
      throw new Error(`Validasi MP3 gagal: ${validated.reason}`);
    }

    // 6. Upload ke Top4Top dengan verifikasi + retry otomatis
    onStage?.('upload');
    const uploadStart = performance.now();
    const mp3Url = await uploadWithVerification(mp3Path, config.top4top.verifyRetries || 3);
    timings.uploadTime = performance.now() - uploadStart;

    timings.totalTime = performance.now() - totalStart;

    // 7. Simpan ke cache
    setCached({
      videoId: meta.videoId,
      title: meta.title,
      channel: meta.channel,
      duration: meta.duration,
      mp3Url,
      fileSize: converted.size
    });

    // Log performance per job (requirement #24)
    console.log(`[JOB] video_id=${meta.videoId} source=${sourceType}`);
    console.log(`[DOWNLOAD] ${formatSeconds(timings.downloadTime)}`);
    console.log(`[CONVERT] ${formatSeconds(timings.conversionTime)}`);
    console.log(`[UPLOAD] ${formatSeconds(timings.uploadTime)}`);
    console.log(`[TOTAL] ${formatSeconds(timings.totalTime)}`);
    console.log(`Source size: ${formatBytes(downloaded.size)} | MP3 size: ${formatBytes(converted.size)}`);

    return {
      fromCache: false,
      sourceType,
      spotifyMeta,
      meta,
      mp3Url,
      sourceSize: downloaded.size,
      mp3Size: converted.size,
      quality: config.audio.bitrate,
      dailyUsage,
      timings
    };
  } finally {
    await cleanupFiles([webmPath, mp3Path]);
  }
}

module.exports = { processYoutubeUrl };
