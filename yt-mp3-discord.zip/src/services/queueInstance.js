'use strict';

const { JobQueue } = require('./queue');
const config = require('../config');

// Singleton queue supaya /youtube (slash command) dan auto-detect link di
// channel (dari /setchannel) berbagi batas concurrency yang sama.
const jobQueue = new JobQueue(config.queue.maxConcurrent);

module.exports = jobQueue;
