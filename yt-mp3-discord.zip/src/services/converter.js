'use strict';

const fs = require('fs');
const { runProcess } = require('../utils/process');
const { createFfmpegProgressParser } = require('../utils/progress');

/**
 * Pastikan encoder libshine tersedia di build FFmpeg server ini.
 * Dipanggil sekali saat startup bot (lihat index.js).
 */
async function validateFfmpegEncoders() {
  const { promise } = runProcess('ffmpeg', ['-hide_banner', '-encoders'], {
    timeoutMs: 10_000
  });

  const { stdout } = await promise;

  if (!/libshine/i.test(stdout)) {
    throw new Error(
      'FFmpeg terpasang TIDAK memiliki encoder "libshine". ' +
        'Install ulang FFmpeg dengan --enable-libshine, atau ganti codec di config.json.'
    );
  }
}

/**
 * Convert file audio input menjadi MP3 menggunakan encoder libshine.
 * Menggunakan pipeline: file temporary -> FFmpeg (BUKAN pipe langsung dari
 * yt-dlp), karena pada benchmark VPS pipeline pipe lebih lambat.
 */
async function convertToMp3(inputPath, outputPath, config, durationSeconds, onProgress) {
  const bitrate = config.audio.bitrate || '128k';
  const codec = config.audio.codec || 'libshine';

  const args = [
    '-hide_banner',
    '-y',
    '-i', inputPath,
    '-vn',
    '-codec:a', codec,
    '-b:a', bitrate,
    '-ac', '2', // tetap stereo, jangan force mono
    '-progress', 'pipe:1',
    outputPath
  ];

  const handleProgress = onProgress
    ? createFfmpegProgressParser(durationSeconds, onProgress)
    : null;

  const { promise } = runProcess('ffmpeg', args, {
    timeoutMs: 20 * 60 * 1000, // 20 menit safety timeout untuk conversion
    onStdout: (chunk) => {
      if (handleProgress) handleProgress(chunk);
    }
  });

  await promise;

  if (!fs.existsSync(outputPath)) {
    throw new Error('FFmpeg selesai tapi file MP3 output tidak ditemukan.');
  }

  return { filePath: outputPath, size: fs.statSync(outputPath).size };
}

/**
 * Validasi hasil MP3 dengan ffprobe: codec=mp3, duration>0, file ada & size>0.
 * Jika gagal, file TIDAK BOLEH diupload ke Top4Top.
 */
async function validateMp3(filePath) {
  if (!fs.existsSync(filePath)) {
    return { valid: false, reason: 'File MP3 tidak ditemukan.' };
  }

  const size = fs.statSync(filePath).size;
  if (size <= 0) {
    return { valid: false, reason: 'Ukuran file MP3 = 0 byte.' };
  }

  const { promise } = runProcess(
    'ffprobe',
    [
      '-v', 'quiet',
      '-print_format', 'json',
      '-show_format',
      '-show_streams',
      filePath
    ],
    { timeoutMs: 15_000 }
  );

  let stdout;
  try {
    ({ stdout } = await promise);
  } catch (err) {
    return { valid: false, reason: `ffprobe gagal dijalankan: ${err.message}` };
  }

  let info;
  try {
    info = JSON.parse(stdout);
  } catch (_) {
    return { valid: false, reason: 'Output ffprobe bukan JSON valid.' };
  }

  const audioStream = (info.streams || []).find((s) => s.codec_type === 'audio');
  const codecName = audioStream?.codec_name || '';
  const formatName = info.format?.format_name || '';
  const duration = parseFloat(info.format?.duration || '0');

  if (!/mp3/i.test(codecName)) {
    return { valid: false, reason: `Codec bukan mp3 (terdeteksi: ${codecName || 'tidak diketahui'}).` };
  }
  if (!/mp3/i.test(formatName)) {
    return { valid: false, reason: `Format bukan mp3 (terdeteksi: ${formatName || 'tidak diketahui'}).` };
  }
  if (!(duration > 0)) {
    return { valid: false, reason: 'Durasi hasil MP3 = 0.' };
  }

  return { valid: true, duration, size };
}

module.exports = { validateFfmpegEncoders, convertToMp3, validateMp3 };
