'use strict';

const db = require('../database/database');

const getStmt = db.prepare('SELECT count FROM daily_usage WHERE usage_date = ?');
const upsertStmt = db.prepare(`
  INSERT INTO daily_usage (usage_date, count)
  VALUES (@date, 1)
  ON CONFLICT(usage_date) DO UPDATE SET count = count + 1
`);

/**
 * Tanggal hari ini dalam format YYYY-MM-DD. Karena ini string tanggal biasa
 * (bukan timestamp), limit otomatis "reset" begitu tanggal berganti — tidak
 * perlu cron/scheduler terpisah.
 */
function todayKey() {
  return new Date().toISOString().slice(0, 10);
}

function getUsedToday() {
  const row = getStmt.get(todayKey());
  return row ? row.count : 0;
}

/**
 * Cek + konsumsi 1 kuota harian sekaligus (atomic, karena better-sqlite3
 * sinkron dan Node.js single-threaded — aman dipanggil dari beberapa worker
 * bersamaan tanpa race condition).
 *
 * @returns {{ allowed: boolean, used: number, limit: number }}
 */
function checkAndConsume(limit) {
  const usedBefore = getUsedToday();

  if (usedBefore >= limit) {
    return { allowed: false, used: usedBefore, limit };
  }

  upsertStmt.run({ date: todayKey() });
  return { allowed: true, used: usedBefore + 1, limit };
}

module.exports = { getUsedToday, checkAndConsume };
