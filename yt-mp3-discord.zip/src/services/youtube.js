'use strict';

const ytdlpEngine = require('../engine/ytdlp');
const { extractVideoId, getMetadataViaApi } = require('./youtubeApi');

const ALLOWED_HOSTS = new Set([
  'youtube.com',
  'www.youtube.com',
  'youtu.be',
  'm.youtube.com'
]);

/**
 * Cek apakah sebuah string URL adalah URL YouTube yang didukung.
 */
function isYoutubeUrl(rawUrl) {
  try {
    const parsed = new URL(rawUrl);
    return ALLOWED_HOSTS.has(parsed.hostname);
  } catch (_) {
    return false;
  }
}

/**
 * Validasi bahwa URL yang dikirim user benar-benar URL YouTube yang valid.
 * Menolak domain arbitrary agar bot tidak disalahgunakan sebagai downloader
 * situs lain.
 */
function validateYoutubeUrl(rawUrl) {
  let parsed;
  try {
    parsed = new URL(rawUrl);
  } catch (_) {
    return { valid: false, reason: 'URL tidak valid.' };
  }

  if (!['http:', 'https:'].includes(parsed.protocol)) {
    return { valid: false, reason: 'URL harus menggunakan http/https.' };
  }

  if (!ALLOWED_HOSTS.has(parsed.hostname)) {
    return { valid: false, reason: 'Hanya URL YouTube yang diizinkan.' };
  }

  return { valid: true, url: parsed.toString() };
}

// Cache in-flight promise per URL supaya request metadata untuk video yang
// sama yang datang beruntun (mis. dua user paste link sama bersamaan) tidak
// memicu dua kali pemanggilan API/yt-dlp.
const inFlightMetadata = new Map();

/**
 * Ambil metadata video. Prioritas: YouTube Data API v3 (cepat, resmi, tidak
 * menyentuh proteksi anti-bot YouTube). Kalau YOUTUBE_API_KEY belum diisi
 * atau API error, fallback otomatis ke engine yt-dlp (`--dump-single-json`)
 * — pemanggilan yt-dlp-nya sendiri sudah disatukan di src/engine/ytdlp.js,
 * bukan spawn terpisah di sini.
 */
async function getMetadata(url) {
  if (inFlightMetadata.has(url)) {
    return inFlightMetadata.get(url);
  }

  const task = (async () => {
    const videoId = extractVideoId(url);

    if (process.env.YOUTUBE_API_KEY && videoId) {
      try {
        return await getMetadataViaApi(videoId);
      } catch (err) {
        if (err.userFacing) throw err; // video privat/dihapus -> jangan fallback, tampilkan apa adanya
        console.warn(`[YOUTUBE_API] Gagal ambil metadata via API (${err.message}), fallback ke yt-dlp...`);
      }
    }

    return ytdlpEngine.getMetadata(url);
  })();

  inFlightMetadata.set(url, task);
  try {
    return await task;
  } finally {
    inFlightMetadata.delete(url);
  }
}

module.exports = { isYoutubeUrl, validateYoutubeUrl, getMetadata };
