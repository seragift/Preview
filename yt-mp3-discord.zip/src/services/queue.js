'use strict';

/**
 * Queue sederhana dengan batas konsentrasi job (maxConcurrent), supaya
 * beberapa conversion FFmpeg tidak berjalan tak terbatas dan membuat VPS
 * overload. Job dieksekusi FIFO begitu ada slot kosong.
 */
class JobQueue {
  constructor(maxConcurrent = 2) {
    this.maxConcurrent = maxConcurrent;
    this.active = 0;
    this.pending = [];
    this.stats = { totalProcessed: 0, successful: 0, failed: 0, totalTimeMs: 0 };
  }

  get queueLength() {
    return this.pending.length;
  }

  get activeCount() {
    return this.active;
  }

  get averageTimeMs() {
    return this.stats.totalProcessed > 0
      ? this.stats.totalTimeMs / this.stats.totalProcessed
      : 0;
  }

  /**
   * Tambahkan job (fungsi async) ke queue. Resolve/reject mengikuti hasil job.
   */
  add(jobFn) {
    return new Promise((resolve, reject) => {
      this.pending.push({ jobFn, resolve, reject });
      this._tryNext();
    });
  }

  _tryNext() {
    if (this.active >= this.maxConcurrent) return;
    const item = this.pending.shift();
    if (!item) return;

    this.active++;
    const startedAt = Date.now();

    Promise.resolve()
      .then(() => item.jobFn())
      .then((result) => {
        this._recordStats(true, Date.now() - startedAt);
        item.resolve(result);
      })
      .catch((err) => {
        this._recordStats(false, Date.now() - startedAt);
        item.reject(err);
      })
      .finally(() => {
        this.active--;
        this._tryNext();
      });
  }

  _recordStats(success, timeMs) {
    this.stats.totalProcessed++;
    if (success) this.stats.successful++;
    else this.stats.failed++;
    this.stats.totalTimeMs += timeMs;
  }
}

module.exports = { JobQueue };
