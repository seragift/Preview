'use strict';

const axios = require('axios');
const { searchVideos } = require('./youtubeApi');

const TOKEN_URL = 'https://accounts.spotify.com/api/token';
const API_BASE = 'https://api.spotify.com/v1';

let cachedToken = null; // { token, expiresAt }

function isSpotifyUrl(rawUrl) {
  try {
    const parsed = new URL(rawUrl);
    return (
      (parsed.hostname === 'open.spotify.com' || parsed.hostname === 'spotify.com') &&
      /\/track\//.test(parsed.pathname)
    );
  } catch (_) {
    return false;
  }
}

function extractTrackId(rawUrl) {
  const match = /\/track\/([a-zA-Z0-9]+)/.exec(rawUrl);
  return match ? match[1] : null;
}

async function getAccessToken() {
  const { SPOTIFY_CLIENT_ID, SPOTIFY_CLIENT_SECRET } = process.env;

  if (!SPOTIFY_CLIENT_ID || !SPOTIFY_CLIENT_SECRET) {
    const err = new Error(
      'SPOTIFY_CLIENT_ID / SPOTIFY_CLIENT_SECRET belum diisi di .env — convert dari Spotify tidak bisa dipakai.'
    );
    err.userFacing = true;
    throw err;
  }

  if (cachedToken && cachedToken.expiresAt > Date.now() + 5000) {
    return cachedToken.token;
  }

  const basicAuth = Buffer.from(`${SPOTIFY_CLIENT_ID}:${SPOTIFY_CLIENT_SECRET}`).toString('base64');

  const { data } = await axios.post(
    TOKEN_URL,
    new URLSearchParams({ grant_type: 'client_credentials' }).toString(),
    {
      headers: {
        Authorization: `Basic ${basicAuth}`,
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      timeout: 15_000
    }
  );

  cachedToken = {
    token: data.access_token,
    expiresAt: Date.now() + data.expires_in * 1000
  };

  return cachedToken.token;
}

/**
 * Ambil metadata track Spotify (judul, artis, durasi) via Spotify Web API.
 * Spotify TIDAK menyediakan audio-nya (DRM) — ini hanya dipakai untuk cari
 * padanan videonya di YouTube.
 */
async function getTrackMetadata(trackId) {
  const token = await getAccessToken();

  let data;
  try {
    ({ data } = await axios.get(`${API_BASE}/tracks/${trackId}`, {
      headers: { Authorization: `Bearer ${token}` },
      timeout: 15_000
    }));
  } catch (err) {
    if (err.response?.status === 404) {
      const e = new Error('Track Spotify tidak ditemukan.');
      e.userFacing = true;
      throw e;
    }
    throw new Error(`Gagal ambil data Spotify: ${err.message}`);
  }

  return {
    title: data.name,
    artists: (data.artists || []).map((a) => a.name).join(', '),
    durationMs: data.duration_ms,
    albumArt: data.album?.images?.[0]?.url || null
  };
}

/**
 * Cari video YouTube yang paling cocok untuk sebuah track Spotify: cari
 * dengan query "artis - judul", lalu dari kandidat hasil pencarian pilih
 * yang durasinya paling mendekati durasi asli track Spotify (toleransi
 * beberapa detik) — supaya tidak salah ambil versi live/remix/cover.
 */
async function findYoutubeMatch(trackMeta) {
  const query = `${trackMeta.artists} - ${trackMeta.title}`;
  const candidates = await searchVideos(query, 5);

  if (candidates.length === 0) {
    const err = new Error(`Tidak ditemukan padanan YouTube untuk "${query}".`);
    err.userFacing = true;
    throw err;
  }

  const targetSeconds = trackMeta.durationMs / 1000;
  let best = candidates[0];
  let bestDiff = Math.abs(best.duration - targetSeconds);

  for (const candidate of candidates.slice(1)) {
    const diff = Math.abs(candidate.duration - targetSeconds);
    if (diff < bestDiff) {
      best = candidate;
      bestDiff = diff;
    }
  }

  return best;
}

module.exports = { isSpotifyUrl, extractTrackId, getTrackMetadata, findYoutubeMatch };
