'use strict';

/**
 * =====================================================================
 * PENTING — BACA DULU SEBELUM DEPLOY
 * =====================================================================
 * Top4Top TIDAK memiliki dokumentasi API resmi/publik. Implementasi di
 * bawah ini adalah pendekatan "form upload" umum yang dipakai banyak
 * file-host sejenis (upload multipart ke endpoint upload.php, lalu parse
 * HTML hasil untuk mengambil direct link). Endpoint & struktur HTML bisa
 * SAJA sudah berubah kapan pun tanpa pemberitahuan.
 *
 * Sesuai requirement #12 di spec awal: seluruh logic khusus Top4Top
 * SENGAJA diisolasi di file ini (terpisah dari downloader/converter) agar
 * ketika parsing rusak, perbaikannya cukup di satu tempat:
 *   1. Cek endpoint upload terbaru (buka top4top.io, inspect network tab
 *      saat upload manual, cari request POST multipart).
 *   2. Update UPLOAD_ENDPOINT & FIELD_NAME di bawah.
 *   3. Update extractDirectLink() sesuai HTML/JSON response terbaru.
 * =====================================================================
 */

const fs = require('fs');
const axios = require('axios');
const FormData = require('form-data');

const UPLOAD_ENDPOINT = 'https://top4top.io/index.php'; // TODO: ganti jika endpoint form berubah
const FIELD_NAME = 'file[]'; // TODO: sesuaikan nama field form upload yang sebenarnya

// Regex longgar untuk menangkap direct link file audio di respons HTML.
// Top4Top biasanya menyajikan direct link di subdomain seperti
// "d.top4top.io", "s##.top4top.io", dst dengan ekstensi asli file.
const DIRECT_LINK_RE = /https?:\/\/[a-z0-9.-]*top4top\.[a-z]+\/[^\s"'<>]+\.mp3/i;

/**
 * Upload file MP3 ke Top4Top dan kembalikan direct download URL.
 * Melempar error jika upload gagal atau direct link tidak bisa diparse
 * (bot TIDAK BOLEH menganggap URL halaman upload sebagai direct link).
 */
async function uploadToTop4Top(filePath) {
  if (!fs.existsSync(filePath)) {
    throw new Error('File untuk diupload tidak ditemukan.');
  }

  const form = new FormData();
  form.append(FIELD_NAME, fs.createReadStream(filePath));

  let response;
  try {
    response = await axios.post(UPLOAD_ENDPOINT, form, {
      headers: form.getHeaders(),
      maxBodyLength: Infinity,
      maxContentLength: Infinity,
      timeout: 5 * 60 * 1000 // 5 menit
    });
  } catch (err) {
    throw new Error(`Upload ke Top4Top gagal: ${err.message}`);
  }

  const directUrl = extractDirectLink(response.data);
  if (!directUrl) {
    throw new Error(
      'Upload sepertinya berhasil tapi direct link tidak ditemukan di response. ' +
        'Kemungkinan struktur HTML Top4Top berubah — cek src/services/top4top.js.'
    );
  }

  return directUrl;
}

/**
 * Ambil direct download URL dari response upload (HTML atau JSON).
 * JANGAN kembalikan URL halaman upload (mis. yang masih mengandung
 * "/index.php" atau "/download.php?id=") — harus benar-benar direct file link.
 */
function extractDirectLink(responseData) {
  const raw = typeof responseData === 'string' ? responseData : JSON.stringify(responseData);
  const match = DIRECT_LINK_RE.exec(raw);
  return match ? match[0] : null;
}

module.exports.extractDirectLink = extractDirectLink;
module.exports.uploadToTop4Top = uploadToTop4Top;

/**
 * Verifikasi bahwa direct link hasil upload benar-benar bisa diakses
 * (HEAD request: status 200 & content-length > 0). Dipakai sebelum link
 * dikirim ke user — kalau ternyata invalid, upload akan diulang.
 */
async function verifyLink(url) {
  try {
    const res = await axios.head(url, { timeout: 15_000, validateStatus: () => true });
    const contentLength = Number(res.headers['content-length'] || 0);
    return res.status === 200 && contentLength > 0;
  } catch (_) {
    return false;
  }
}

/**
 * Upload ke Top4Top dengan verifikasi otomatis: kalau link hasil ternyata
 * tidak valid (mis. respons berubah / upload gagal parsial), upload diulang
 * sampai `maxRetries` kali sebelum benar-benar dianggap gagal.
 */
async function uploadWithVerification(filePath, maxRetries = 3) {
  let lastError = null;

  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      const url = await uploadToTop4Top(filePath);
      const valid = await verifyLink(url);

      if (valid) return url;

      lastError = new Error('Link hasil upload tidak valid setelah diverifikasi.');
      console.warn(`[TOP4TOP] Percobaan ${attempt}/${maxRetries}: link invalid, upload ulang...`);
    } catch (err) {
      lastError = err;
      console.warn(`[TOP4TOP] Percobaan ${attempt}/${maxRetries} gagal: ${err.message}`);
    }
  }

  throw new Error(`Upload ke Top4Top gagal setelah ${maxRetries}x percobaan: ${lastError?.message}`);
}

module.exports.verifyLink = verifyLink;
module.exports.uploadWithVerification = uploadWithVerification;
