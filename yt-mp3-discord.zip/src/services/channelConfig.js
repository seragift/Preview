'use strict';

const db = require('../database/database');

const getStmt = db.prepare('SELECT channel_id FROM guild_config WHERE guild_id = ?');
const upsertStmt = db.prepare(`
  INSERT INTO guild_config (guild_id, channel_id, updated_at)
  VALUES (@guild_id, @channel_id, @updated_at)
  ON CONFLICT(guild_id) DO UPDATE SET
    channel_id = excluded.channel_id,
    updated_at = excluded.updated_at
`);
const deleteStmt = db.prepare('DELETE FROM guild_config WHERE guild_id = ?');

/**
 * Ambil channel_id yang di-set untuk auto-process link YouTube di guild ini.
 * Return null jika belum pernah di-set.
 */
function getConfiguredChannel(guildId) {
  const row = getStmt.get(guildId);
  return row ? row.channel_id : null;
}

function setConfiguredChannel(guildId, channelId) {
  upsertStmt.run({
    guild_id: guildId,
    channel_id: channelId,
    updated_at: Date.now()
  });
}

function clearConfiguredChannel(guildId) {
  deleteStmt.run(guildId);
}

module.exports = { getConfiguredChannel, setConfiguredChannel, clearConfiguredChannel };
