'use strict';

const fs = require('fs');
const path = require('path');
const ytdlpEngine = require('../engine/ytdlp');
const { validateYoutubeUrl } = require('./youtube');

const CONFIGS = [1, 4, 8, 16];
const TMP_DIR = ytdlpEngine.TMP_DIR;

/**
 * Jalankan download yang SAMA satu per satu (bukan bersamaan) dengan
 * -N 1 / 4 / 8 / 16, ukur waktunya, lalu rekomendasikan config tercepat
 * berdasarkan hasil aktual. File hasil setiap benchmark langsung dihapus
 * supaya tidak menumpuk di tmp/. Pemanggilan yt-dlp-nya lewat
 * `engine/ytdlp.js` (downloadRaw), sama seperti download asli & fallback
 * metadata — satu engine untuk semua kebutuhan yt-dlp.
 */
async function runBenchmark(url, format = 'ba') {
  const validation = validateYoutubeUrl(url);
  if (!validation.valid) {
    const err = new Error(validation.reason);
    err.userFacing = true;
    throw err;
  }

  const results = [];

  for (const fragments of CONFIGS) {
    const outputTemplate = path.join(TMP_DIR, `benchmark_${fragments}.%(ext)s`);
    const start = performance.now();

    try {
      await ytdlpEngine.downloadRaw(validation.url, outputTemplate, {
        format,
        concurrentFragments: fragments,
        timeoutMs: 5 * 60 * 1000
      });

      const elapsedSeconds = (performance.now() - start) / 1000;
      results.push({ fragments, seconds: elapsedSeconds, ok: true });
    } catch (err) {
      results.push({ fragments, seconds: null, ok: false, error: err.message });
    } finally {
      // Bersihkan file hasil benchmark config ini sebelum lanjut ke config berikutnya.
      const leftover = fs
        .readdirSync(TMP_DIR)
        .filter((f) => f.startsWith(`benchmark_${fragments}.`));
      for (const f of leftover) {
        fs.promises.unlink(path.join(TMP_DIR, f)).catch(() => {});
      }
    }
  }

  const successful = results.filter((r) => r.ok);
  const fastest = successful.length
    ? successful.reduce((a, b) => (b.seconds < a.seconds ? b : a))
    : null;

  return { results, fastest };
}

module.exports = { runBenchmark, CONFIGS };
