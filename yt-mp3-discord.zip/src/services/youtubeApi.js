'use strict';

const axios = require('axios');

const BASE_URL = 'https://www.googleapis.com/youtube/v3';

function getApiKey() {
  const key = process.env.YOUTUBE_API_KEY;
  if (!key) {
    throw new Error(
      'YOUTUBE_API_KEY belum diisi di .env. Buat API key di Google Cloud Console (aktifkan "YouTube Data API v3").'
    );
  }
  return key;
}

/**
 * Ambil video ID dari berbagai bentuk URL YouTube:
 * youtube.com/watch?v=ID, youtu.be/ID, youtube.com/shorts/ID, m.youtube.com/...
 */
function extractVideoId(url) {
  try {
    const parsed = new URL(url);

    if (parsed.hostname === 'youtu.be') {
      return parsed.pathname.slice(1).split('/')[0] || null;
    }

    if (parsed.pathname.startsWith('/shorts/')) {
      return parsed.pathname.split('/')[2] || null;
    }

    const v = parsed.searchParams.get('v');
    if (v) return v;

    return null;
  } catch (_) {
    return null;
  }
}

/**
 * Konversi durasi ISO 8601 (mis. "PT29M3S") dari YouTube Data API menjadi detik.
 */
function parseIso8601Duration(iso) {
  const match = /PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/.exec(iso || '');
  if (!match) return 0;
  const [, h, m, s] = match;
  return (parseInt(h || '0', 10) * 3600) + (parseInt(m || '0', 10) * 60) + parseInt(s || '0', 10);
}

/**
 * Ambil metadata video via YouTube Data API v3 (videos.list).
 * Jauh lebih cepat & ringan dibanding `yt-dlp --dump-single-json`, dan tidak
 * memicu proteksi "Sign in to confirm you're not a bot" karena bukan request
 * ke halaman video, murni REST API resmi.
 */
async function getMetadataViaApi(videoId) {
  const apiKey = getApiKey();

  const { data } = await axios.get(`${BASE_URL}/videos`, {
    params: {
      part: 'snippet,contentDetails,status',
      id: videoId,
      key: apiKey
    },
    timeout: 15_000
  });

  const item = data.items?.[0];
  if (!item) {
    const err = new Error('Video tidak ditemukan / privat / sudah dihapus.');
    err.userFacing = true;
    throw err;
  }

  if (item.status?.privacyStatus === 'private') {
    const err = new Error('Video bersifat privat, tidak bisa diproses.');
    err.userFacing = true;
    throw err;
  }

  const thumb =
    item.snippet.thumbnails?.maxres ||
    item.snippet.thumbnails?.high ||
    item.snippet.thumbnails?.medium ||
    item.snippet.thumbnails?.default;

  return {
    videoId: item.id,
    title: item.snippet.title,
    channel: item.snippet.channelTitle,
    duration: parseIso8601Duration(item.contentDetails.duration),
    thumbnail: thumb?.url || null,
    webpageUrl: `https://www.youtube.com/watch?v=${item.id}`
  };
}

/**
 * Cari video YouTube berdasarkan query teks (dipakai untuk mencari padanan
 * dari track Spotify). Mengembalikan beberapa kandidat lengkap dengan durasi
 * (lewat panggilan videos.list kedua) supaya bisa dicocokkan ke durasi asli
 * track Spotify-nya.
 */
async function searchVideos(query, maxResults = 5) {
  const apiKey = getApiKey();

  const { data: searchData } = await axios.get(`${BASE_URL}/search`, {
    params: {
      part: 'snippet',
      q: query,
      type: 'video',
      maxResults,
      videoCategoryId: '10', // Music
      key: apiKey
    },
    timeout: 15_000
  });

  const ids = (searchData.items || []).map((i) => i.id.videoId).filter(Boolean);
  if (ids.length === 0) return [];

  const { data: detailData } = await axios.get(`${BASE_URL}/videos`, {
    params: {
      part: 'snippet,contentDetails',
      id: ids.join(','),
      key: apiKey
    },
    timeout: 15_000
  });

  return (detailData.items || []).map((item) => ({
    videoId: item.id,
    title: item.snippet.title,
    channel: item.snippet.channelTitle,
    duration: parseIso8601Duration(item.contentDetails.duration),
    thumbnail: item.snippet.thumbnails?.high?.url || item.snippet.thumbnails?.default?.url || null,
    webpageUrl: `https://www.youtube.com/watch?v=${item.id}`
  }));
}

module.exports = { extractVideoId, parseIso8601Duration, getMetadataViaApi, searchVideos };
