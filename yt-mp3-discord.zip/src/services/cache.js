'use strict';

const db = require('../database/database');
const config = require('../config');

const ttlSeconds = config.cache?.ttlSeconds ?? 604800; // default 7 hari

const getStmt = db.prepare('SELECT * FROM cache WHERE video_id = ?');
const upsertStmt = db.prepare(`
  INSERT INTO cache (video_id, title, channel, duration, mp3_url, file_size, created_at, expires_at)
  VALUES (@video_id, @title, @channel, @duration, @mp3_url, @file_size, @created_at, @expires_at)
  ON CONFLICT(video_id) DO UPDATE SET
    title = excluded.title,
    channel = excluded.channel,
    duration = excluded.duration,
    mp3_url = excluded.mp3_url,
    file_size = excluded.file_size,
    created_at = excluded.created_at,
    expires_at = excluded.expires_at
`);
const deleteStmt = db.prepare('DELETE FROM cache WHERE video_id = ?');

/**
 * Ambil entry cache yang masih valid (belum expired) untuk video_id tertentu.
 * Mengembalikan null jika tidak ada / sudah kedaluwarsa.
 */
function getCached(videoId) {
  const row = getStmt.get(videoId);
  if (!row) return null;

  if (row.expires_at && row.expires_at < Date.now()) {
    deleteStmt.run(videoId);
    return null;
  }

  return row;
}

/**
 * Simpan/replace hasil proses video ke cache.
 */
function setCached({ videoId, title, channel, duration, mp3Url, fileSize }) {
  const now = Date.now();
  upsertStmt.run({
    video_id: videoId,
    title,
    channel,
    duration,
    mp3_url: mp3Url,
    file_size: fileSize,
    created_at: now,
    expires_at: now + ttlSeconds * 1000
  });
}

module.exports = { getCached, setCached };
