'use strict';

const path = require('path');
const Database = require('better-sqlite3');

const DB_PATH = path.join(__dirname, '..', '..', 'database.sqlite');

const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');

db.exec(`
  CREATE TABLE IF NOT EXISTS cache (
      video_id TEXT PRIMARY KEY,
      title TEXT,
      channel TEXT,
      duration INTEGER,
      mp3_url TEXT,
      file_size INTEGER,
      created_at INTEGER,
      expires_at INTEGER
  );

  CREATE TABLE IF NOT EXISTS guild_config (
      guild_id TEXT PRIMARY KEY,
      channel_id TEXT NOT NULL,
      updated_at INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS job_stats (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      video_id TEXT,
      success INTEGER NOT NULL,
      total_time_ms INTEGER,
      created_at INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS daily_usage (
      usage_date TEXT PRIMARY KEY,
      count INTEGER NOT NULL DEFAULT 0
  );
`);

module.exports = db;
