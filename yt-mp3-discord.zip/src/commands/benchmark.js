'use strict';

const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { runBenchmark } = require('../services/benchmark');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('benchmark')
    .setDescription('[Admin] Benchmark konfigurasi concurrent fragments (-N) untuk VPS ini')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addStringOption((opt) =>
      opt.setName('url').setDescription('URL YouTube sample untuk benchmark').setRequired(true)
    ),

  async execute(interaction) {
    await interaction.reply('🧪 Menjalankan benchmark -N 1 / 4 / 8 / 16 secara berurutan...\nIni mungkin butuh beberapa menit.');

    try {
      const { results, fastest } = await runBenchmark(interaction.options.getString('url', true));

      const lines = results.map((r) =>
        r.ok ? `-N ${r.fragments}\t→ ${r.seconds.toFixed(1)}s` : `-N ${r.fragments}\t→ gagal (${r.error})`
      );

      const embed = new EmbedBuilder()
        .setColor(0xfee75c)
        .setTitle('🧪 Hasil Benchmark')
        .setDescription('```\n' + lines.join('\n') + '\n```')
        .addFields({
          name: 'Rekomendasi',
          value: fastest
            ? `**-N ${fastest.fragments}** (${fastest.seconds.toFixed(1)}s) — set \`youtube.concurrentFragments\` di config.json ke nilai ini.`
            : 'Semua config gagal, cek log server.'
        });

      await interaction.editReply({ content: null, embeds: [embed] });
    } catch (err) {
      console.error('[ERROR][BENCHMARK]', err);
      const msg = err.userFacing ? `❌ ${err.message}` : '❌ Benchmark gagal dijalankan.';
      await interaction.editReply(msg);
    }
  }
};
