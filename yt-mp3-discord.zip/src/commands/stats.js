'use strict';

const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const jobQueue = require('../services/queueInstance');
const { getUsedToday } = require('../services/dailyLimiter');
const { formatSeconds } = require('../utils/format');
const config = require('../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('stats')
    .setDescription('Statistik pemrosesan bot'),

  async execute(interaction) {
    const dailyLimit = config.limits?.dailyConvertLimit ?? 50;

    const embed = new EmbedBuilder()
      .setColor(config.embed?.color || 0x5865f2)
      .setTitle('📊 Bot Stats')
      .addFields(
        { name: 'Queue', value: String(jobQueue.queueLength), inline: true },
        { name: 'Active jobs (worker)', value: `${jobQueue.activeCount}/${config.queue.maxConcurrent}`, inline: true },
        { name: 'Limit Hari Ini', value: `${getUsedToday()}/${dailyLimit}`, inline: true },
        { name: 'Total processed', value: String(jobQueue.stats.totalProcessed), inline: true },
        { name: 'Successful', value: String(jobQueue.stats.successful), inline: true },
        { name: 'Failed', value: String(jobQueue.stats.failed), inline: true },
        {
          name: 'Average processing time',
          value: jobQueue.averageTimeMs > 0 ? formatSeconds(jobQueue.averageTimeMs) : '-',
          inline: true
        }
      );

    await interaction.reply({ embeds: [embed] });
  }
};
