'use strict';

const { SlashCommandBuilder, ChannelType, PermissionFlagsBits } = require('discord.js');
const { setConfiguredChannel } = require('../services/channelConfig');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setchannel')
    .setDescription('Set channel khusus: kirim link YouTube/Spotify di sana akan otomatis diproses')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addChannelOption((opt) =>
      opt
        .setName('channel')
        .setDescription('Channel target')
        .addChannelTypes(ChannelType.GuildText)
        .setRequired(true)
    ),

  async execute(interaction) {
    if (!interaction.inGuild()) {
      return interaction.reply({ content: '❌ Command ini hanya bisa dipakai di server.', ephemeral: true });
    }

    const channel = interaction.options.getChannel('channel', true);

    setConfiguredChannel(interaction.guildId, channel.id);

    await interaction.reply({
      content: `✅ Channel auto-convert diset ke ${channel}. Kirim link YouTube atau Spotify (track) di sana, bot akan otomatis memprosesnya (tanpa perlu \`/youtube\`).`,
      ephemeral: true
    });
  }
};
