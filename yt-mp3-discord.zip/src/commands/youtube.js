'use strict';

const { SlashCommandBuilder } = require('discord.js');
const jobQueue = require('../services/queueInstance');
const { runYoutubeJob } = require('../utils/discordRunner');
const config = require('../config');

const MAX_WAITING = config.queue?.maxWaiting ?? 100;

module.exports = {
  data: new SlashCommandBuilder()
    .setName('youtube')
    .setDescription('Convert audio YouTube/Spotify (track) menjadi MP3 dan upload ke Top4Top')
    .addStringOption((opt) =>
      opt.setName('url').setDescription('Link YouTube atau Spotify track').setRequired(true)
    ),

  async execute(interaction) {
    const url = interaction.options.getString('url', true);

    if (jobQueue.queueLength >= MAX_WAITING) {
      return interaction.reply({ content: '❌ Antrian penuh, coba lagi nanti.', ephemeral: true });
    }

    await interaction.reply('⏳ Memproses video...');
    const statusMessage = await interaction.fetchReply();

    jobQueue
      .add(() => runYoutubeJob(statusMessage, url, interaction.user.id))
      .catch(() => {
        /* pesan error sudah ditangani & ditampilkan di dalam runYoutubeJob */
      });
  }
};
