'use strict';

/**
 * Format ukuran bytes menjadi string MB yang konsisten.
 * Menggunakan basis 1024 (MiB) tapi label "MB" agar familiar untuk user,
 * dan SELALU dihitung lewat fs.statSync().size, bukan lewat `ls`.
 */
function formatBytes(bytes, decimals = 2) {
  if (!Number.isFinite(bytes) || bytes < 0) return '0 MB';
  if (bytes === 0) return '0 MB';

  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  const k = 1024;
  const i = Math.min(
    Math.floor(Math.log(bytes) / Math.log(k)),
    units.length - 1
  );
  const value = bytes / Math.pow(k, i);

  return `${value.toFixed(i === 0 ? 0 : decimals)} ${units[i]}`;
}

/**
 * Format durasi panjang: "29 menit 3 detik" / "1 jam 5 menit 10 detik".
 */
function formatDurationLong(totalSeconds) {
  const sec = Math.max(0, Math.floor(totalSeconds || 0));
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;

  const parts = [];
  if (h > 0) parts.push(`${h} jam`);
  if (m > 0 || h > 0) parts.push(`${m} menit`);
  parts.push(`${s} detik`);

  return parts.join(' ');
}

/**
 * Format durasi singkat: "29:03" / "1:05:10" (dipakai di embed & progress bar).
 */
function formatDurationShort(totalSeconds) {
  const sec = Math.max(0, Math.floor(totalSeconds || 0));
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;

  const mm = h > 0 ? String(m).padStart(2, '0') : String(m);
  const ss = String(s).padStart(2, '0');

  return h > 0 ? `${h}:${mm}:${ss}` : `${mm}:${ss}`;
}

/**
 * Format detik proses menjadi "38.452s" (3 desimal, konsisten dengan log).
 */
function formatSeconds(ms) {
  return `${(ms / 1000).toFixed(3)}s`;
}

/**
 * Progress bar teks sederhana, mis. "████████████████░░░░ 82%".
 */
function progressBar(percent, length = 20) {
  const clamped = Math.max(0, Math.min(100, percent || 0));
  const filled = Math.round((clamped / 100) * length);
  const empty = length - filled;
  return `${'█'.repeat(filled)}${'░'.repeat(empty)} ${clamped.toFixed(0)}%`;
}

module.exports = {
  formatBytes,
  formatDurationLong,
  formatDurationShort,
  formatSeconds,
  progressBar
};
