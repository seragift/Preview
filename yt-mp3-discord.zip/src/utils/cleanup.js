'use strict';

const fs = require('fs');

/**
 * Hapus daftar file temporary. Tidak melempar error jika file sudah tidak ada
 * (misalnya proses gagal sebelum file sempat dibuat). Dipanggil di blok
 * `finally` supaya tmp/ tetap bersih walaupun job gagal di tengah jalan.
 */
async function cleanupFiles(paths = []) {
  const results = await Promise.allSettled(
    paths.filter(Boolean).map((p) => fs.promises.unlink(p))
  );

  results.forEach((r, idx) => {
    if (r.status === 'rejected' && r.reason?.code !== 'ENOENT') {
      console.error(`[CLEANUP] Gagal hapus ${paths[idx]}:`, r.reason.message);
    }
  });
}

module.exports = { cleanupFiles };
