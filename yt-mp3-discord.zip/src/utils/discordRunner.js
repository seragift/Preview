'use strict';

const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { processYoutubeUrl } = require('../services/pipeline');
const { getUsedToday } = require('../services/dailyLimiter');
const { createThrottler } = require('./progress');
const config = require('../config');
const {
  formatBytes,
  formatDurationShort,
  formatSeconds,
  progressBar
} = require('./format');

const editThrottleMs = config.progress?.editIntervalMs ?? 1500;
const dailyLimit = config.limits?.dailyConvertLimit ?? 50;

const STAGE_TEXT = {
  resolve: '🔎 Mencari padanan di YouTube...', // hanya muncul untuk link Spotify
  metadata: '⏳ Memproses video...',
  shared: '🔁 Video yang sama sedang diproses request lain, menunggu hasilnya...',
  download: '📥 Downloading audio...',
  convert: '🎧 Converting to MP3...',
  upload: '☁️ Uploading to Top4Top...'
};

function buildResultButtons(mp3Url, requesterId) {
  const openButton = new ButtonBuilder()
    .setLabel('Buka Link')
    .setStyle(ButtonStyle.Link)
    .setURL(mp3Url);

  const deleteButton = new ButtonBuilder()
    .setCustomId(`ytmp3_delete:${requesterId}`)
    .setLabel('Hapus')
    .setStyle(ButtonStyle.Danger);

  return [new ActionRowBuilder().addComponents(openButton, deleteButton)];
}

/**
 * Jalankan pipeline lengkap untuk 1 URL (YouTube/Spotify) dan update
 * `statusMessage` (objek Discord Message yang bisa di-.edit()) sepanjang
 * prosesnya. Dipakai bersama oleh /youtube command maupun auto-detect di
 * channel yang di-set lewat /setchannel.
 *
 * @param {import('discord.js').Message} statusMessage
 * @param {string} url
 * @param {string} requesterId - dipakai untuk membatasi tombol "Hapus"
 */
async function runYoutubeJob(statusMessage, url, requesterId) {
  const throttledEdit = createThrottler(editThrottleMs);

  const safeEdit = (content, immediate = false) => {
    const doEdit = () => statusMessage.edit(content).catch(() => {});
    if (immediate) doEdit();
    else throttledEdit(doEdit);
  };

  try {
    const result = await processYoutubeUrl(url, {
      onStage: (stage) => {
        const stageText = STAGE_TEXT[stage];
        if (stageText) safeEdit(stageText, true);
      },
      onDownloadProgress: (p) => {
        safeEdit(
          `📥 Downloading...\n\n${progressBar(p.percent)}\n` +
            `${p.totalSize ? `${p.totalSize} @ ` : ''}Speed: ${p.speed} | ETA: ${p.eta}`
        );
      },
      onConvertProgress: (p) => {
        safeEdit(
          `🎧 Converting...\n\n${progressBar(p.percent)}\n` +
            `${formatDurationShort(p.currentSeconds)} / ${formatDurationShort(p.totalSeconds)}`
        );
      }
    });

    const usedToday = getUsedToday();

    const embed = new EmbedBuilder()
      .setColor(config.embed?.color || 0x57f287)
      .setTitle('✅ Selesai!')
      .addFields(
        { name: '🎵 Judul', value: result.meta.title || '-' },
        { name: '⏱️ Durasi', value: formatDurationShort(result.meta.duration), inline: true },
        { name: '👤 Channel', value: result.meta.channel || '-', inline: true },
        { name: '🎚️ Quality', value: result.quality || config.audio.bitrate, inline: true },
        {
          name: '📦 Size',
          value: result.mp3Size ? formatBytes(result.mp3Size) : '(dari cache)',
          inline: true
        },
        {
          name: '☁️ Upload',
          value: result.fromCache ? 'Instan (dari cache)' : formatSeconds(result.timings.uploadTime),
          inline: true
        },
        { name: '📊 Limit Hari Ini', value: `${usedToday}/${dailyLimit}`, inline: true },
        { name: '🔗 Link Top4Top', value: result.mp3Url }
      )
      .setFooter({ text: config.embed?.footerText || 'YouTube/Spotify to MP3 • Top4Top' });

    if (result.sourceType === 'spotify' && result.spotifyMeta) {
      embed.addFields({
        name: '🎧 Dari Spotify',
        value: `${result.spotifyMeta.artists} - ${result.spotifyMeta.title}`
      });
    }

    if (result.meta.thumbnail) embed.setThumbnail(result.meta.thumbnail);

    await statusMessage
      .edit({ content: null, embeds: [embed], components: buildResultButtons(result.mp3Url, requesterId) })
      .catch(() => {});
    return result;
  } catch (err) {
    console.error('[ERROR]', err);

    const userMessage = err.userFacing
      ? `❌ ${err.message}`
      : '❌ Gagal memproses video.\nSilakan coba URL lain.';

    await statusMessage.edit({ content: userMessage, embeds: [], components: [] }).catch(() => {});
    throw err;
  }
}

module.exports = { runYoutubeJob };
