'use strict';

/**
 * Buat fungsi throttle sederhana: pemanggilan lebih cepat dari `intervalMs`
 * akan di-drop, kecuali `flush()` dipanggil manual (dipakai untuk update terakhir).
 * Dipakai supaya kita tidak terlalu sering edit message Discord (rate limit).
 */
function createThrottler(intervalMs) {
  let lastRun = 0;
  let pendingArgs = null;
  let timer = null;

  function throttled(fn, ...args) {
    const now = Date.now();
    const elapsed = now - lastRun;

    if (elapsed >= intervalMs) {
      lastRun = now;
      fn(...args);
    } else {
      pendingArgs = { fn, args };
      if (!timer) {
        timer = setTimeout(() => {
          timer = null;
          if (pendingArgs) {
            lastRun = Date.now();
            const { fn: f, args: a } = pendingArgs;
            pendingArgs = null;
            f(...a);
          }
        }, intervalMs - elapsed);
      }
    }
  }

  return throttled;
}

// Contoh baris yt-dlp dengan --newline:
// [download]  82.0% of   30.20MiB at  118.20MiB/s ETA 00:02
const YTDLP_PROGRESS_RE =
  /\[download\]\s+(\d+(?:\.\d+)?)%\s+of\s+~?\s*([\d.]+\w+)\s+at\s+([\d.]+\w+\/s|Unknown speed)\s+ETA\s+([\d:]+|Unknown)/i;

function parseYtDlpProgress(line) {
  const match = YTDLP_PROGRESS_RE.exec(line);
  if (!match) return null;

  const [, percent, totalSize, speed, eta] = match;
  return {
    percent: parseFloat(percent),
    totalSize,
    speed: speed.replace(/Unknown speed/i, '-'),
    eta: eta.replace(/Unknown/i, '-')
  };
}

/**
 * Parser untuk output FFmpeg `-progress pipe:1`, berupa key=value per baris:
 * out_time_ms=123456
 * progress=continue|end
 */
function createFfmpegProgressParser(totalDurationSeconds, onUpdate) {
  let buffer = {};

  return function handle(chunk) {
    const lines = chunk.split('\n');
    for (const line of lines) {
      const idx = line.indexOf('=');
      if (idx === -1) continue;
      const key = line.slice(0, idx).trim();
      const value = line.slice(idx + 1).trim();
      buffer[key] = value;

      if (key === 'progress') {
        const outTimeMs = Number(buffer.out_time_ms || 0);
        const currentSeconds = outTimeMs / 1_000_000;
        const percent =
          totalDurationSeconds > 0
            ? Math.min(100, (currentSeconds / totalDurationSeconds) * 100)
            : 0;

        onUpdate({
          percent,
          currentSeconds,
          totalSeconds: totalDurationSeconds,
          done: value === 'end'
        });

        buffer = {};
      }
    }
  };
}

module.exports = {
  createThrottler,
  parseYtDlpProgress,
  createFfmpegProgressParser
};
