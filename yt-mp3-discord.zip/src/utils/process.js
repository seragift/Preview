'use strict';

const { spawn } = require('child_process');

/**
 * Jalankan external process menggunakan spawn() (BUKAN exec()) supaya
 * argumen dilewatkan sebagai array -> aman dari shell injection, dan
 * mendukung streaming stdout/stderr untuk progress parsing.
 *
 * @param {string} command - nama binary, mis. "yt-dlp" / "ffmpeg"
 * @param {string[]} args - argumen dalam bentuk array (JANGAN gabungkan jadi string)
 * @param {object} options
 * @param {number} [options.timeoutMs] - kill proses jika melebihi durasi ini
 * @param {(chunk: string) => void} [options.onStdout]
 * @param {(chunk: string) => void} [options.onStderr]
 * @param {AbortSignal} [options.signal] - untuk cancellation dari luar
 * @returns {{ promise: Promise<{stdout:string, stderr:string, code:number}>, cancel: () => void }}
 */
function runProcess(command, args, options = {}) {
  const { timeoutMs, onStdout, onStderr, signal, cwd } = options;

  const child = spawn(command, args, { cwd });

  let stdout = '';
  let stderr = '';
  let settled = false;
  let timeoutHandle = null;

  const cancel = (sig = 'SIGKILL') => {
    if (!child.killed) {
      try {
        child.kill(sig);
      } catch (_) {
        /* proses sudah mati, aman diabaikan */
      }
    }
  };

  const promise = new Promise((resolve, reject) => {
    child.stdout?.on('data', (chunk) => {
      const str = chunk.toString();
      stdout += str;
      if (onStdout) onStdout(str);
    });

    child.stderr?.on('data', (chunk) => {
      const str = chunk.toString();
      stderr += str;
      if (onStderr) onStderr(str);
    });

    child.on('error', (err) => {
      if (settled) return;
      settled = true;
      if (timeoutHandle) clearTimeout(timeoutHandle);
      reject(Object.assign(new Error(`Gagal menjalankan ${command}: ${err.message}`), {
        stdout,
        stderr,
        code: null
      }));
    });

    child.on('close', (code, killedSignal) => {
      if (settled) return;
      settled = true;
      if (timeoutHandle) clearTimeout(timeoutHandle);

      if (killedSignal === 'SIGKILL' || killedSignal === 'SIGTERM') {
        const err = new Error(`${command} dihentikan (${killedSignal})`);
        err.stdout = stdout;
        err.stderr = stderr;
        err.code = code;
        err.signal = killedSignal;
        return reject(err);
      }

      if (code === 0) {
        resolve({ stdout, stderr, code });
      } else {
        const err = new Error(`${command} exited with code ${code}`);
        err.stdout = stdout;
        err.stderr = stderr;
        err.code = code;
        reject(err);
      }
    });

    if (timeoutMs) {
      timeoutHandle = setTimeout(() => {
        cancel('SIGKILL');
      }, timeoutMs);
    }

    if (signal) {
      if (signal.aborted) cancel('SIGKILL');
      else signal.addEventListener('abort', () => cancel('SIGKILL'), { once: true });
    }
  });

  return { promise, cancel, child };
}

module.exports = { runProcess };
