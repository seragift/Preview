'use strict';

require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { Client, GatewayIntentBits, Collection } = require('discord.js');

const { validateFfmpegEncoders } = require('./src/services/converter');
const { deployCommands } = require('./src/deploy/deployCommands');

const { DISCORD_TOKEN, CLIENT_ID, GUILD_ID } = process.env;

if (!DISCORD_TOKEN || !CLIENT_ID) {
  console.error('[STARTUP] DISCORD_TOKEN dan CLIENT_ID wajib diisi di .env');
  process.exit(1);
}

async function main() {
  // 1. Validasi FFmpeg (libshine) sebelum bot dijalankan sama sekali.
  try {
    await validateFfmpegEncoders();
    console.log('[STARTUP] FFmpeg encoder "libshine" tersedia ✔');
  } catch (err) {
    console.error(`[STARTUP] ${err.message}`);
    process.exit(1);
  }

  // 2. Reset command lama lalu deploy command baru — otomatis setiap kali
  //    "node index.js" dijalankan, supaya perubahan command (rename/hapus/
  //    tambah) selalu sinkron tanpa perlu jalankan deploy-commands.js manual.
  try {
    await deployCommands({ token: DISCORD_TOKEN, clientId: CLIENT_ID, guildId: GUILD_ID || null });
  } catch (err) {
    console.error('[STARTUP] Gagal reset/deploy slash command:', err);
    process.exit(1);
  }

  // 3. Siapkan client & load command handlers
  const client = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.MessageContent
    ]
  });

  client.commands = new Collection();
  const commandsPath = path.join(__dirname, 'src', 'commands');
  for (const file of fs.readdirSync(commandsPath).filter((f) => f.endsWith('.js'))) {
    const command = require(path.join(commandsPath, file));
    client.commands.set(command.data.name, command);
  }

  // 4. Load event handlers
  const eventsPath = path.join(__dirname, 'src', 'events');
  for (const file of fs.readdirSync(eventsPath).filter((f) => f.endsWith('.js'))) {
    const event = require(path.join(eventsPath, file));
    if (event.once) client.once(event.name, (...args) => event.execute(...args));
    else client.on(event.name, (...args) => event.execute(...args));
  }

  // 5. Jangan biarkan proses zombie kalau ada unhandled rejection.
  process.on('unhandledRejection', (err) => {
    console.error('[UNHANDLED REJECTION]', err);
  });

  await client.login(DISCORD_TOKEN);
}

main();
