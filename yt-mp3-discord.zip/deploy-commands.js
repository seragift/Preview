'use strict';

require('dotenv').config();
const { deployCommands } = require('./src/deploy/deployCommands');

const { DISCORD_TOKEN, CLIENT_ID, GUILD_ID } = process.env;

if (!DISCORD_TOKEN || !CLIENT_ID) {
  console.error('[DEPLOY] DISCORD_TOKEN dan CLIENT_ID wajib diisi di .env');
  process.exit(1);
}

deployCommands({ token: DISCORD_TOKEN, clientId: CLIENT_ID, guildId: GUILD_ID || null })
  .then(() => process.exit(0))
  .catch((err) => {
    console.error('[DEPLOY] Gagal deploy command:', err);
    process.exit(1);
  });
