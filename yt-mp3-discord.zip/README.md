# yt-mp3-discord

Bot Discord: **URL YouTube → metadata → download audio → convert MP3 (libshine) → upload Top4Top → kirim link**.

## 1. Struktur Folder

```
yt-mp3-discord/
├── index.js                  # entry point (validasi ffmpeg, auto reset+deploy command, login)
├── deploy-commands.js        # deploy command manual (opsional, index.js sudah otomatis)
├── package.json
├── config.json                # konfigurasi performance (lihat bagian 13)
├── .env.example
├── src/
│   ├── config.js               # loader config.json + default fallback (tidak crash kalau belum ada)
│   ├── commands/
│   │   ├── youtube.js         # /youtube url:<link>
│   │   ├── setchannel.js      # /setchannel channel:<#channel>
│   │   ├── stats.js           # /stats
│   │   └── benchmark.js       # /benchmark url:<link> (admin only)
│   ├── events/
│   │   ├── ready.js
│   │   ├── interactionCreate.js
│   │   └── messageCreate.js   # auto-proses link YouTube di channel ter-set
│   ├── services/
│   │   ├── youtube.js         # deteksi URL + metadata (API v3, fallback engine/ytdlp)
│   │   ├── youtubeApi.js      # YouTube Data API v3 (metadata & search)
│   │   ├── spotify.js         # Spotify Web API (metadata track + cari padanan YouTube)
│   │   ├── downloader.js      # wrapper tipis config.json -> engine/ytdlp.download()
│   │   ├── converter.js       # ffmpeg convert + ffprobe validasi
│   │   ├── top4top.js         # upload + verifikasi + retry, parsing direct link (terisolasi)
│   │   ├── cache.js           # cache SQLite per video_id
│   │   ├── dailyLimiter.js    # limit convert harian, auto reset per tanggal
│   │   ├── channelConfig.js   # channel target per guild (/setchannel)
│   │   ├── queue.js / queueInstance.js
│   │   ├── benchmark.js       # -N 1/4/8/16 lewat engine/ytdlp.downloadRaw()
│   │   └── pipeline.js        # orkestrasi seluruh tahap + timing
│   ├── engine/
│   │   └── ytdlp.js           # SATU-SATUNYA tempat binary yt-dlp di-spawn (reusable)
│   ├── deploy/
│   │   └── deployCommands.js  # reset lalu deploy ulang slash command
│   ├── utils/
│   │   ├── process.js         # wrapper spawn()
│   │   ├── format.js          # formatBytes, formatDuration, progressBar
│   │   ├── progress.js        # parser progress yt-dlp & ffmpeg
│   │   ├── cleanup.js         # hapus file temporary
│   │   └── discordRunner.js   # UX bersama (progress msg + embed hasil)
│   └── database/
│       └── database.js        # better-sqlite3 (cache, guild_config, daily_usage, job_stats)
├── tmp/downloads/              # file sementara (.webm/.m4a & .mp3), auto-dibersihkan
└── database.sqlite             # dibuat otomatis saat pertama jalan
```

## 2. Fitur Baru: `/setchannel`

- `/setchannel channel:#nama-channel` (butuh permission **Manage Server**) menyimpan
  channel target per-server ke SQLite (`guild_config`).
- Setelah di-set, **user tinggal paste link YouTube saja** di channel tersebut —
  tanpa perlu `/youtube` — bot otomatis mendeteksi & memprosesnya
  (`src/events/messageCreate.js`).
- Command `/youtube` tetap bisa dipakai di channel manapun seperti biasa.
- Pesan di channel tersebut yang **bukan** link YouTube dibiarkan lewat begitu saja
  (chat biasa tidak terganggu).

## 3. Engine yt-dlp Terpisah (`src/engine/ytdlp.js`)

Binary `yt-dlp` **hanya di-spawn dari satu tempat**: `src/engine/ytdlp.js`.
Tidak ada file event/command yang langsung `spawn('yt-dlp', ...)` sendiri —
semuanya lewat 3 fungsi di engine ini:

| Fungsi | Dipakai oleh | Untuk apa |
|---|---|---|
| `getMetadata(url)` | `services/youtube.js` | Fallback metadata saat `YOUTUBE_API_KEY` kosong/gagal |
| `download(url, videoId, opts, onProgress)` | `services/downloader.js` | Download audio asli untuk pipeline |
| `downloadRaw(url, outputTemplate, opts)` | `services/benchmark.js` | Download percobaan `-N 1/4/8/16` |

Manfaatnya: kalau suatu saat perlu ubah flag/argumen yt-dlp (mis. ada flag
baru, atau ganti strategi format), cukup diubah di satu file ini — tidak
perlu telusuri satu-satu ke downloader/youtube/benchmark. Layer di atasnya
(`services/*.js`) hanya menjembatani `config.json` ke opsi yang diterima engine.

## 4. `config.json` Opsional (Tidak Crash Kalau Belum Ada)

Semua file yang butuh config **tidak lagi** `require('config.json')` langsung
— melainkan lewat `src/config.js`, yang:

1. Kalau `config.json` **tidak ada** → pakai default bawaan (sama persis
   dengan isi `config.json` yang di-ship di project ini), bot tetap jalan.
2. Kalau `config.json` **ada tapi JSON-nya rusak** (typo, koma nyasar, dll)
   → di-catch, fallback ke default, ada warning di console
   (`[CONFIG] config.json tidak valid (...) — memakai konfigurasi default bawaan.`).
3. Kalau `config.json` **ada tapi cuma isi sebagian** (mis. cuma
   `{"audio":{"bitrate":"320k"}}`) → field yang diisi dipakai, field lain di
   kategori yang sama tetap ambil default (tidak hilang semua jadi
   `undefined`).

Jadi `config.json` sifatnya benar-benar opsional untuk override — hapus atau
lupa taruh saat deploy tidak akan bikin bot crash `MODULE_NOT_FOUND` seperti
sebelumnya.

## 5. Metadata via YouTube Data API v3

- `services/youtube.js` mengambil metadata (judul, channel, durasi, thumbnail)
  lewat **YouTube Data API v3** (`services/youtubeApi.js`) kalau `YOUTUBE_API_KEY`
  diisi di `.env` — lebih cepat, resmi, dan **tidak menambah risiko** kena
  proteksi "Sign in to confirm you're not a bot" (beda dari `yt-dlp
  --dump-single-json` yang menyentuh halaman video langsung).
- `yt-dlp` tetap dipakai **hanya untuk download audio-nya**, karena Data API
  tidak menyediakan stream audio.
- Kalau `YOUTUBE_API_KEY` kosong atau API gagal (kecuali video privat/dihapus
  — itu ditampilkan apa adanya), otomatis **fallback ke `yt-dlp
  --dump-single-json`** supaya bot tetap jalan.
- Bot **tidak memakai cookie YouTube sama sekali** (sesuai permintaan) — jadi
  video age-restricted / butuh login tetap akan gagal didownload seperti biasa.

## 6. Convert dari Spotify (track)

- Kirim link `open.spotify.com/track/...` (lewat `/youtube url:` atau di
  channel yang di-`/setchannel`) — bot ambil judul+artis+durasi track via
  Spotify Web API (`services/spotify.js`, client-credentials flow, butuh
  `SPOTIFY_CLIENT_ID` & `SPOTIFY_CLIENT_SECRET` di `.env`), lalu cari
  padanannya di YouTube (YouTube Data API `search.list`) dan **pilih kandidat
  dengan durasi paling mendekati durasi asli Spotify-nya** (menghindari salah
  ambil versi live/remix/cover). Sisanya proses sama seperti link YouTube biasa.
- Spotify sendiri tidak dipakai untuk audio (DRM) — murni sumber metadata +
  pencarian padanan.

## 7. Limit Harian, Retry Upload, & Tombol Hasil

- **Limit harian** (`config.json` → `limits.dailyConvertLimit`, default 50):
  dihitung per hari kalender, **auto-reset sendiri saat tanggal berganti**
  (`services/dailyLimiter.js` — kunci row SQLite-nya memang tanggal hari itu,
  jadi tidak butuh cron terpisah). Limit hanya dipotong untuk proses **baru**
  — hasil dari cache atau job yang "menumpang" job lain tidak memotong kuota.
- **Retry + verifikasi upload** (`services/top4top.js` →
  `uploadWithVerification`): setelah upload, link hasil di-`HEAD` request dulu
  untuk memastikan benar-benar bisa diakses; kalau tidak valid, upload
  otomatis diulang sampai `config.json` → `top4top.verifyRetries` kali (default 3).
- **Tombol di embed hasil**:
  - `Buka Link` — link button langsung ke direct download Top4Top.
  - `Hapus` — hapus pesan hasil, **hanya bisa dipencet oleh requester asli
    atau member dengan permission Manage Messages** (`events/interactionCreate.js`).
- Warna & footer embed diatur terpusat lewat `config.json` → `embed.color` /
  `embed.footerText`.

## 8. Multi-Server & 5 Worker Paralel

- **Multi-server**: satu bot (satu token) bisa di-invite ke banyak server sekaligus.
  `/setchannel` disimpan **per guild_id** di SQLite, jadi tiap server punya channel
  auto-YouTube-nya sendiri-sendiri tanpa saling ganggu.
- **Worker**: `config.json` → `queue.maxConcurrent: 5` — maksimal **5 job
  (download+convert+upload) berjalan bersamaan**, lintas server. Request ke-6
  dst otomatis masuk antrian (`queue.maxWaiting`, default 100) dan diproses
  begitu ada worker kosong. Ubah `maxConcurrent` sesuai kekuatan CPU/RAM VPS.
- **Dedupe video sama**: kalau 2+ server (atau 2+ user) kebetulan request video
  YouTube yang **sama** di waktu bersamaan, hanya 1 worker yang benar-benar
  download/convert/upload — request lainnya otomatis "menumpang" job yang
  sedang jalan dan dapat hasil yang sama begitu selesai (`🔁 Video yang sama
  sedang diproses request lain...`). Ini juga mencegah file temporary
  (dinamai dari video_id) saling tabrakan antar worker.

## 9. Auto Reset + Deploy Command di `node index.js`

Setiap kali `node index.js` dijalankan:
1. Bot mengecek encoder `libshine` di FFmpeg (gagal start jika tidak ada).
2. Bot **menghapus semua slash command lama** (`PUT` body `[]`) lalu
   **mendaftarkan ulang seluruh command dari `src/commands/`** — jadi command
   yang sudah di-rename/dihapus dari kode tidak akan nyangkut jadi "command hantu"
   di Discord, tanpa perlu jalankan `deploy-commands.js` manual.
3. Baru setelah itu bot login (`client.login`).

Kalau `GUILD_ID` diisi di `.env` → command didaftarkan sebagai **guild command**
(langsung muncul, cocok untuk development). Kalau dikosongkan → **global command**
(propagasi ke Discord bisa sampai ~1 jam).

`deploy-commands.js` tetap disediakan sebagai cara manual/terpisah jika suatu
saat dibutuhkan.

## 10. Instalasi

### a. Dependency sistem (VPS)

```bash
# yt-dlp
sudo curl -L https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp -o /usr/local/bin/yt-dlp
sudo chmod a+rx /usr/local/bin/yt-dlp
yt-dlp --version

# ffmpeg + ffprobe (pastikan build punya libshine)
sudo apt install ffmpeg
ffmpeg -encoders | grep libshine   # HARUS muncul, kalau tidak build ulang ffmpeg --enable-libshine

# deno (dibutuhkan yt-dlp untuk beberapa PO token / JS runtime)
curl -fsSL https://deno.land/install.sh | sh
deno --version
```

### b. Dependency Node.js

```bash
npm install
```

### c. Environment variable

```bash
cp .env.example .env
# isi DISCORD_TOKEN, CLIENT_ID, (opsional) GUILD_ID
# isi YOUTUBE_API_KEY -> aktifkan "YouTube Data API v3" di Google Cloud Console
# (opsional) isi SPOTIFY_CLIENT_ID & SPOTIFY_CLIENT_SECRET kalau mau dukung link Spotify
```

## 11. Menjalankan

```bash
node index.js
```

(otomatis reset + deploy command, lalu bot online — tidak perlu langkah terpisah)

Deploy command manual (opsional):

```bash
node deploy-commands.js
```

Menjalankan benchmark dari command line tidak disediakan terpisah — pakai
`/benchmark url:<link>` di Discord (admin only), hasilnya langsung
merekomendasikan `concurrentFragments` tercepat untuk VPS ini.

## 12. PM2 (production)

```bash
npm install -g pm2
pm2 start index.js --name yt-mp3-bot
pm2 save
pm2 logs yt-mp3-bot
```

## 13. Konfigurasi Performance (`config.json`)

| Key | Fungsi |
|---|---|
| `youtube.concurrentFragments` | `-N` untuk yt-dlp (1/4/8/16) — tes dengan `/benchmark` sebelum ubah |
| `audio.bitrate` | bitrate MP3 (64k–320k), default `128k`, tetap stereo |
| `queue.maxConcurrent` | jumlah conversion FFmpeg paralel maksimum (worker) |
| `queue.maxWaiting` | kapasitas antrian sebelum request baru ditolak |
| `limits.maxDuration` | detik, video lebih panjang ditolak |
| `limits.maxFileSize` | bytes, file source lebih besar ditolak |
| `limits.dailyConvertLimit` | maksimal convert baru per hari (reset otomatis tiap ganti tanggal) |
| `top4top.verifyRetries` | maksimal percobaan ulang upload kalau link hasil tidak valid |
| `cache.ttlSeconds` | lama cache video_id sebelum dianggap kedaluwarsa |
| `progress.editIntervalMs` | throttle edit pesan Discord (hindari rate limit) |
| `embed.color` / `embed.footerText` | warna & footer embed hasil convert |

## 14. Catatan penting: Top4Top

Top4Top **tidak punya API resmi**. `src/services/top4top.js` sengaja
diisolasi dari downloader/converter — kalau parsing direct link rusak
(situs berubah struktur), perbaikan cukup dilakukan di satu file itu saja
(lihat komentar di bagian atas file tersebut untuk cara debug-nya).
