'use strict';

const logger = require('../utils/logger');
const { startWeatherUpdater } = require('../services/weather/weatherUpdater');
const { startEarthquakeMonitor } = require('../services/earthquake/earthquakeMonitor');
const { startTsunamiMonitor } = require('../services/earthquake/tsunamiMonitor');

module.exports = {
  name: 'ready',
  once: true,
  async execute(client) {
    logger.success(`Discord bot connected sebagai ${client.user.tag}`);

    await startWeatherUpdater(client);
    logger.info('Weather updater started');

    startEarthquakeMonitor(client);
    startTsunamiMonitor(client);
  }
};
