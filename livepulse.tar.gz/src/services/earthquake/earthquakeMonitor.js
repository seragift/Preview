'use strict';

const logger = require('../../utils/logger');
const { fetchRecentEarthquakes } = require('../../providers/bmkgProvider');
const {
  broadcastEarthquake,
  isEarthquakeAlreadySent,
  saveEarthquakeEvent
} = require('./earthquakeService');
const { getConnection } = require('../../../database/connection');
const { deriveTsunamiStatus } = require('../../providers/bmkgProvider');

let pollTimer = null;
let isPolling = false;

async function pollOnce(client) {
  if (isPolling) return; // cegah polling tumpang-tindih
  isPolling = true;
  try {
    logger.info('Checking BMKG earthquake feed');
    const quakes = await fetchRecentEarthquakes();

    // BMKG mengurutkan dari terbaru -> terlama; balik agar dikirim kronologis.
    const chronological = [...quakes].reverse();

    let newCount = 0;
    for (const gempa of chronological) {
      if (!gempa.eventId) continue;
      if (isEarthquakeAlreadySent(gempa.eventId)) continue;

      logger.info(`New earthquake detected: ${gempa.magnitude}`);
      const tsunamiStatus = deriveTsunamiStatus(gempa.potensi);

      saveEarthquakeEvent(gempa, tsunamiStatus);
      await broadcastEarthquake(client, gempa);
      newCount++;
    }

    if (newCount === 0) {
      logger.info('No new earthquake');
    }
  } catch (err) {
    logger.error(`Gagal polling data gempa BMKG: ${err.message}`);
  } finally {
    isPolling = false;
  }
}

/**
 * Mulai monitor gempa (polling global, dikirim ke semua guild terkonfigurasi).
 * Interval memakai EARTHQUAKE_INTERVAL dari .env sebagai basis; nilai
 * earthquake_interval per-guild pada /setup dipakai sebagai preferensi
 * tampilan/estimasi karena feed BMKG bersifat global (satu sumber untuk
 * semua guild), bukan per-guild.
 */
function startEarthquakeMonitor(client) {
  const baseInterval = parseInt(process.env.EARTHQUAKE_INTERVAL, 10) || 60000;

  if (pollTimer) clearInterval(pollTimer);
  pollOnce(client);
  pollTimer = setInterval(() => pollOnce(client), baseInterval);

  logger.success(`Earthquake monitor berjalan (interval ${baseInterval}ms)`);
}

function stopEarthquakeMonitor() {
  if (pollTimer) clearInterval(pollTimer);
  pollTimer = null;
}

module.exports = { startEarthquakeMonitor, stopEarthquakeMonitor, pollOnce };
