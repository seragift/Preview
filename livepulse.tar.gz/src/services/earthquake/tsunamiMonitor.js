'use strict';

const logger = require('../../utils/logger');
const { getConnection } = require('../../../database/connection');
const { fetchRecentEarthquakes, deriveTsunamiStatus } = require('../../providers/bmkgProvider');
const { buildTsunamiEmbed } = require('../../embeds/tsunamiEmbed');

let pollTimer = null;
let isPolling = false;

function getExistingAlert(alertId) {
  const db = getConnection();
  return db.prepare('SELECT * FROM tsunami_alerts WHERE alert_id = ?').get(alertId);
}

function upsertAlert(alertId, status, region, eventTime) {
  const db = getConnection();
  const existing = getExistingAlert(alertId);
  if (existing) {
    if (existing.status !== status) {
      db.prepare(
        "UPDATE tsunami_alerts SET status = ?, updated_at = datetime('now') WHERE alert_id = ?"
      ).run(status, alertId);
      return 'updated';
    }
    return 'unchanged';
  }
  db.prepare(
    `INSERT INTO tsunami_alerts (alert_id, status, region, event_time, source)
     VALUES (?, ?, ?, ?, 'BMKG')`
  ).run(alertId, status, region, eventTime);
  return 'created';
}

async function broadcastTsunami(client, alert) {
  const db = getConnection();
  const guilds = db
    .prepare('SELECT guild_id, tsunami_channel_id, mention_enabled FROM guild_settings WHERE tsunami_channel_id IS NOT NULL AND enabled = 1')
    .all();

  const embed = buildTsunamiEmbed(alert);
  const isWarning = alert.status === 'WARNING';

  for (const g of guilds) {
    const channel = await client.channels.fetch(g.tsunami_channel_id).catch(() => null);
    if (!channel) {
      logger.warn(`Channel tsunami tidak ditemukan (guild ${g.guild_id}), menonaktifkan`);
      db.prepare("UPDATE guild_settings SET tsunami_channel_id = NULL, updated_at = datetime('now') WHERE guild_id = ?").run(g.guild_id);
      continue;
    }
    // @everyone hanya untuk status WARNING resmi DAN mention diaktifkan admin.
    const content = isWarning && g.mention_enabled ? '@everyone' : undefined;
    await channel
      .send({ content, embeds: [embed] })
      .catch((err) => logger.error(`Gagal mengirim alert tsunami ke guild ${g.guild_id}: ${err.message}`));
  }

  db.prepare("UPDATE guild_settings SET last_tsunami_check = datetime('now')").run();
}

async function pollOnce(client) {
  if (isPolling) return;
  isPolling = true;
  try {
    const quakes = await fetchRecentEarthquakes();
    const chronological = [...quakes].reverse();

    for (const gempa of chronological) {
      const status = deriveTsunamiStatus(gempa.potensi);
      // Hanya proses jika BMKG secara eksplisit menyatakan status (WARNING/NORMAL).
      // Tidak pernah menyimpulkan dari magnitudo semata.
      if (!status) continue;

      const alertId = gempa.eventId;
      const result = upsertAlert(alertId, status, gempa.location, gempa.dateTime);

      if (result === 'created' && status === 'WARNING') {
        logger.warn(`Peringatan tsunami baru terdeteksi: ${gempa.location}`);
        await broadcastTsunami(client, { status, region: gempa.location, jam: gempa.jam, source: 'BMKG' });
      } else if (result === 'updated') {
        logger.info(`Status tsunami diperbarui menjadi ${status}: ${gempa.location}`);
        await broadcastTsunami(client, { status, region: gempa.location, jam: gempa.jam, source: 'BMKG' });
      }
    }
  } catch (err) {
    logger.error(`Gagal polling status tsunami BMKG: ${err.message}`);
  } finally {
    isPolling = false;
  }
}

function startTsunamiMonitor(client) {
  const baseInterval = parseInt(process.env.TSUNAMI_INTERVAL, 10) || 60000;

  if (pollTimer) clearInterval(pollTimer);
  pollOnce(client);
  pollTimer = setInterval(() => pollOnce(client), baseInterval);

  logger.success(`Tsunami monitor berjalan (interval ${baseInterval}ms)`);
}

function stopTsunamiMonitor() {
  if (pollTimer) clearInterval(pollTimer);
  pollTimer = null;
}

module.exports = { startTsunamiMonitor, stopTsunamiMonitor, pollOnce };
