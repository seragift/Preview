'use strict';

const { getConnection } = require('../../../database/connection');
const logger = require('../../utils/logger');
const { fetchAllCitiesWeather } = require('../../providers/weatherProvider');
const { buildWeatherEmbed } = require('../../embeds/weatherEmbed');

// Cache in-memory data cuaca terakhir yang berhasil diambil, dipakai
// sebagai fallback ketika API sedang gagal ("pertahankan data terakhir").
let lastGoodWeather = null;
let lastFetchFailed = false;

async function getWeatherSnapshot() {
  try {
    const data = await fetchAllCitiesWeather();
    lastGoodWeather = data;
    lastFetchFailed = false;
    return { data, isStale: false };
  } catch (err) {
    logger.error(`Gagal mengambil data cuaca: ${err.message}`);
    lastFetchFailed = true;
    return { data: lastGoodWeather, isStale: true };
  }
}

/**
 * Buat atau perbarui dashboard cuaca di sebuah guild.
 * Mencari message_id tersimpan di DB - jika tidak ada / sudah terhapus,
 * dashboard baru dibuat dan message_id baru disimpan (bukan menambah pesan
 * baru setiap update).
 */
async function updateWeatherDashboard(client, guildId) {
  const db = getConnection();
  const settings = db.prepare('SELECT * FROM guild_settings WHERE guild_id = ?').get(guildId);

  if (!settings || !settings.weather_channel_id || !settings.enabled) return;

  const channel = await client.channels.fetch(settings.weather_channel_id).catch(() => null);
  if (!channel) {
    logger.warn(`Channel cuaca tidak ditemukan untuk guild ${guildId}, menandai disabled`);
    db.prepare('UPDATE guild_settings SET weather_channel_id = NULL, updated_at = datetime(\'now\') WHERE guild_id = ?').run(guildId);
    return;
  }

  const { data, isStale } = await getWeatherSnapshot();
  const embed = buildWeatherEmbed(data, isStale);

  let messageId = settings.weather_message_id;
  let message = null;

  if (messageId) {
    message = await channel.messages.fetch(messageId).catch(() => null);
  }

  if (message) {
    await message.edit({ embeds: [embed] }).catch(async (err) => {
      logger.warn(`Gagal edit dashboard cuaca (${err.message}), membuat dashboard baru`);
      message = null;
    });
  }

  if (!message) {
    const sent = await channel.send({ embeds: [embed] }).catch((err) => {
      logger.error(`Gagal mengirim dashboard cuaca baru: ${err.message}`);
      return null;
    });
    if (!sent) return;
    messageId = sent.id;
  }

  db.prepare(
    `UPDATE guild_settings
     SET weather_message_id = ?, weather_status = ?, last_weather_update = datetime('now'), updated_at = datetime('now')
     WHERE guild_id = ?`
  ).run(messageId, isStale ? 'stale' : 'online', guildId);

  logger.info(`Dashboard cuaca diperbarui untuk guild ${guildId}${isStale ? ' (data lama/stale)' : ''}`);
}

module.exports = { updateWeatherDashboard, getWeatherSnapshot };
