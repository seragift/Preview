'use strict';

const { getConnection } = require('../../../database/connection');
const logger = require('../../utils/logger');
const { updateWeatherDashboard } = require('./weatherService');

// Map<guildId, NodeJS.Timeout> - mencegah interval duplikat per guild.
const activeIntervals = new Map();

function scheduleGuildWeather(client, guildId, intervalMs) {
  if (activeIntervals.has(guildId)) {
    clearInterval(activeIntervals.get(guildId));
  }
  const handle = setInterval(() => {
    updateWeatherDashboard(client, guildId).catch((err) =>
      logger.error(`Weather updater error (guild ${guildId}): ${err.message}`)
    );
  }, intervalMs);
  activeIntervals.set(guildId, handle);
}

function unscheduleGuildWeather(guildId) {
  if (activeIntervals.has(guildId)) {
    clearInterval(activeIntervals.get(guildId));
    activeIntervals.delete(guildId);
  }
}

/**
 * Dipanggil sekali saat bot ready: jadwalkan updater untuk semua guild
 * yang sudah memiliki weather_channel_id, dan lakukan update pertama.
 */
async function startWeatherUpdater(client) {
  const db = getConnection();
  const rows = db
    .prepare('SELECT guild_id, weather_interval FROM guild_settings WHERE weather_channel_id IS NOT NULL AND enabled = 1')
    .all();

  for (const row of rows) {
    await updateWeatherDashboard(client, row.guild_id).catch((err) =>
      logger.error(`Gagal update awal cuaca (guild ${row.guild_id}): ${err.message}`)
    );
    scheduleGuildWeather(client, row.guild_id, row.weather_interval);
  }

  logger.success(`Weather updater berjalan untuk ${rows.length} guild`);
}

module.exports = { startWeatherUpdater, scheduleGuildWeather, unscheduleGuildWeather };
