'use strict';

// Logger sederhana - tidak pernah mencetak token/API key ke console.
function timestamp() {
  return new Date().toISOString();
}

function info(msg) {
  console.log(`[INFO] ${timestamp()} - ${msg}`);
}

function warn(msg) {
  console.warn(`[WARN] ${timestamp()} - ${msg}`);
}

function error(msg) {
  console.error(`[ERROR] ${timestamp()} - ${msg}`);
}

function success(msg) {
  console.log(`[SUCCESS] ${timestamp()} - ${msg}`);
}

module.exports = { info, warn, error, success };
