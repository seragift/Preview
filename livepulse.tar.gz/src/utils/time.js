'use strict';

const TIMEZONE = process.env.TIMEZONE || 'Asia/Jakarta';

// Format Date -> "02 September 2026 15:42 WIB"
function formatDateTimeWIB(date = new Date()) {
  const formatter = new Intl.DateTimeFormat('id-ID', {
    timeZone: TIMEZONE,
    day: '2-digit',
    month: 'long',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false
  });
  const parts = formatter.formatToParts(date);
  const get = (t) => parts.find((p) => p.type === t)?.value;
  return `${get('day')} ${get('month')} ${get('year')} • ${get('hour')}:${get('minute')}:${get('second')} WIB`;
}

// Format singkat -> "15:42 WIB"
function formatShortTimeWIB(date = new Date()) {
  const formatter = new Intl.DateTimeFormat('id-ID', {
    timeZone: TIMEZONE,
    hour: '2-digit',
    minute: '2-digit',
    hour12: false
  });
  return `${formatter.format(date)} WIB`;
}

// Format footer dashboard -> "02 Sep 2026 • 15:42 WIB"
function formatFooterWIB(date = new Date()) {
  const formatter = new Intl.DateTimeFormat('id-ID', {
    timeZone: TIMEZONE,
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false
  });
  const parts = formatter.formatToParts(date);
  const get = (t) => parts.find((p) => p.type === t)?.value;
  return `${get('day')} ${get('month')} ${get('year')} • ${get('hour')}:${get('minute')} WIB`;
}

function formatUptime(ms) {
  const totalSeconds = Math.floor(ms / 1000);
  const days = Math.floor(totalSeconds / 86400);
  const hours = Math.floor((totalSeconds % 86400) / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  const parts = [];
  if (days) parts.push(`${days}h`);
  if (hours) parts.push(`${hours}j`);
  if (minutes) parts.push(`${minutes}m`);
  parts.push(`${seconds}d`);
  return parts.join(' ');
}

module.exports = { TIMEZONE, formatDateTimeWIB, formatShortTimeWIB, formatFooterWIB, formatUptime };
