'use strict';

const cityData = require('../../data/indonesia-cities.json');

// Kembalikan array datar seluruh kota beserta region induknya.
function getAllCitiesFlat() {
  const flat = [];
  for (const region of cityData.regions) {
    for (const city of region.cities) {
      flat.push({ ...city, region: region.name, regionEmoji: region.emoji });
    }
  }
  return flat;
}

function getRegions() {
  return cityData.regions;
}

// BMKG memberi format "6.21 LS" / "106.82 BT" -> ubah ke desimal bertanda.
// LS (Lintang Selatan) = negatif, LU (Lintang Utara) = positif
// BT (Bujur Timur) = positif, BB (Bujur Barat) = negatif
function parseBmkgCoordinate(value) {
  if (!value) return null;
  const match = String(value).trim().match(/^(-?\d+(?:\.\d+)?)\s*(LS|LU|BT|BB)?$/i);
  if (!match) return null;
  let num = parseFloat(match[1]);
  const dir = (match[2] || '').toUpperCase();
  if (dir === 'LS' || dir === 'BB') num = -Math.abs(num);
  return num;
}

module.exports = { getAllCitiesFlat, getRegions, parseBmkgCoordinate };
