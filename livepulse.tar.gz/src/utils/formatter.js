'use strict';

// Peta kode cuaca WMO (dipakai Open-Meteo) -> deskripsi & emoji Bahasa Indonesia.
// Referensi kode: https://open-meteo.com/en/docs (WMO Weather interpretation codes)
const WEATHER_CODE_MAP = {
  0: { text: 'Cerah', emoji: '☀️' },
  1: { text: 'Cerah Berawan', emoji: '🌤️' },
  2: { text: 'Cerah Berawan', emoji: '🌤️' },
  3: { text: 'Berawan', emoji: '☁️' },
  45: { text: 'Berkabut', emoji: '🌫️' },
  48: { text: 'Berkabut', emoji: '🌫️' },
  51: { text: 'Hujan Lokal', emoji: '🌦️' },
  53: { text: 'Hujan Lokal', emoji: '🌦️' },
  55: { text: 'Hujan Lokal', emoji: '🌦️' },
  56: { text: 'Hujan Lokal', emoji: '🌦️' },
  57: { text: 'Hujan Lokal', emoji: '🌦️' },
  61: { text: 'Hujan', emoji: '🌧️' },
  63: { text: 'Hujan', emoji: '🌧️' },
  65: { text: 'Hujan', emoji: '🌧️' },
  66: { text: 'Hujan', emoji: '🌧️' },
  67: { text: 'Hujan', emoji: '🌧️' },
  71: { text: 'Hujan', emoji: '🌧️' },
  73: { text: 'Hujan', emoji: '🌧️' },
  75: { text: 'Hujan', emoji: '🌧️' },
  77: { text: 'Hujan', emoji: '🌧️' },
  80: { text: 'Hujan Lokal', emoji: '🌦️' },
  81: { text: 'Hujan', emoji: '🌧️' },
  82: { text: 'Hujan', emoji: '🌧️' },
  95: { text: 'Hujan Petir', emoji: '⛈️' },
  96: { text: 'Hujan Petir', emoji: '⛈️' },
  99: { text: 'Hujan Petir', emoji: '⛈️' }
};

function describeWeatherCode(code) {
  return WEATHER_CODE_MAP[code] || { text: 'Tidak Diketahui', emoji: '❔' };
}

function formatTemperature(celsius) {
  if (celsius === null || celsius === undefined || Number.isNaN(celsius)) return 'N/A';
  return `${Math.round(celsius)}°C`;
}

// "5.7" -> "5.7 SR" style label untuk magnitudo
function formatMagnitude(mag) {
  if (mag === null || mag === undefined) return 'N/A';
  return `${mag}`;
}

module.exports = { describeWeatherCode, formatTemperature, formatMagnitude };
