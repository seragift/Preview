'use strict';

const { EmbedBuilder } = require('discord.js');

const STATUS_LABEL = {
  WARNING: '⚠️ WARNING',
  ADVISORY: '🟠 ADVISORY',
  NORMAL: '🟢 NORMAL / BERAKHIR'
};

const STATUS_COLOR = {
  WARNING: 0xe74c3c,
  ADVISORY: 0xf39c12,
  NORMAL: 0x2ecc71
};

/**
 * Bangun embed peringatan/status tsunami.
 * @param {object} alert - { status, region, jam, tanggal, source }
 */
function buildTsunamiEmbed(alert) {
  const isWarning = alert.status === 'WARNING';

  const embed = new EmbedBuilder()
    .setTitle(isWarning ? '🌊🚨 PERINGATAN TSUNAMI' : '🌊 STATUS TSUNAMI')
    .setColor(STATUS_COLOR[alert.status] || 0x95a5a6)
    .addFields(
      { name: 'Wilayah', value: alert.region || 'N/A', inline: false },
      { name: 'Status', value: STATUS_LABEL[alert.status] || alert.status, inline: true },
      { name: 'Waktu', value: alert.jam || 'N/A', inline: true }
    )
    .setFooter({ text: `Sumber: ${alert.source || 'BMKG'}` });

  if (isWarning) {
    embed.setDescription('**TERDAPAT PERINGATAN TSUNAMI**');
  }

  return embed;
}

module.exports = { buildTsunamiEmbed };
