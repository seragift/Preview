'use strict';

const { EmbedBuilder } = require('discord.js');
const { formatMagnitude } = require('../utils/formatter');

/**
 * Bangun embed peringatan gempa dari 1 event gempa BMKG ternormalisasi.
 * @param {object} gempa - hasil normalizeGempa() dari bmkgProvider
 */
function buildEarthquakeEmbed(gempa) {
  const coordText = `${gempa.lintangRaw || gempa.latitude}, ${gempa.bujurRaw || gempa.longitude}`;

  return new EmbedBuilder()
    .setTitle('🚨 PERINGATAN GEMPA')
    .setColor(0xe74c3c)
    .addFields(
      { name: 'Magnitudo', value: formatMagnitude(gempa.magnitude), inline: true },
      { name: 'Kedalaman', value: gempa.depth || 'N/A', inline: true },
      { name: '\u200b', value: '\u200b', inline: true },
      { name: 'Lokasi', value: gempa.location || 'N/A', inline: false },
      { name: 'Waktu', value: `${gempa.tanggal || ''}\n${gempa.jam || ''}`, inline: true },
      { name: '📍 Koordinat', value: coordText, inline: true }
    )
    .setFooter({ text: `Sumber: ${gempa.source}` });
}

module.exports = { buildEarthquakeEmbed };
