'use strict';

const { EmbedBuilder } = require('discord.js');
const { getRegions } = require('../utils/location');
const { describeWeatherCode, formatTemperature } = require('../utils/formatter');
const { formatFooterWIB } = require('../utils/time');

/**
 * Bangun 1 embed dashboard cuaca Indonesia berisi seluruh region/kota.
 * @param {Map<string,{temperature:number, weatherCode:number}>|null} weatherByCity
 * @param {boolean} isStale - true jika data terakhir gagal diperbarui (API down)
 */
function buildWeatherEmbed(weatherByCity, isStale = false) {
  const regions = getRegions();

  const embed = new EmbedBuilder()
    .setTitle('🇮🇩 CUACA INDONESIA')
    .setColor(isStale ? 0xe67e22 : 0x2ecc71)
    .setFooter({ text: `🔄 Diperbarui: ${formatFooterWIB()}` });

  for (const region of regions) {
    const lines = region.cities.map((city) => {
      const data = weatherByCity?.get(city.name);
      if (!data) {
        return `📍 ${city.name.padEnd(12, ' ')} ❔ N/A`;
      }
      const { text, emoji } = describeWeatherCode(data.weatherCode);
      const temp = formatTemperature(data.temperature);
      return `📍 ${city.name.padEnd(12, ' ')} ${emoji} ${temp}`;
    });
    embed.addFields({
      name: `${region.emoji} ${region.name}`,
      value: lines.join('\n'),
      inline: false
    });
  }

  if (isStale) {
    embed.setDescription('⚠️ Data cuaca sedang tidak tersedia. Menampilkan data terakhir yang berhasil diambil.');
  }

  return embed;
}

module.exports = { buildWeatherEmbed };
