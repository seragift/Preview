'use strict';

const axios = require('axios');

// Sumber resmi BMKG - Data Gempabumi Terbuka
// https://data.bmkg.go.id/gempabumi
const AUTOGEMPA_URL = 'https://data.bmkg.go.id/DataMKG/TEWS/autogempa.json';
const GEMPATERKINI_URL = 'https://data.bmkg.go.id/DataMKG/TEWS/gempaterkini.json';

const TIMEOUT_MS = 10000;
const HEADERS = { 'User-Agent': 'LivePulse-Indonesia/1.0 (Discord Bot)' };

/**
 * Gempa bumi terbaru (1 event tunggal, live paling akhir dari BMKG).
 */
async function fetchLatestEarthquake() {
  const res = await axios.get(AUTOGEMPA_URL, { timeout: TIMEOUT_MS, headers: HEADERS });
  const gempa = res.data?.Infogempa?.gempa;
  if (!gempa) throw new Error('Format data autogempa.json tidak dikenali');
  return normalizeGempa(gempa);
}

/**
 * Daftar 15 gempa bumi M 5.0+ terkini dari BMKG.
 * Dipakai untuk polling & deteksi event baru.
 */
async function fetchRecentEarthquakes() {
  const res = await axios.get(GEMPATERKINI_URL, { timeout: TIMEOUT_MS, headers: HEADERS });
  const list = res.data?.Infogempa?.gempa;
  if (!Array.isArray(list)) throw new Error('Format data gempaterkini.json tidak dikenali');
  return list.map(normalizeGempa);
}

/**
 * Normalisasi 1 object gempa mentah dari BMKG menjadi bentuk internal.
 * BMKG tidak menyediakan field "id" eksplisit, jadi DateTime (ISO, unik
 * per event) dipakai sebagai event_id untuk deduplikasi.
 */
function normalizeGempa(raw) {
  const [lonStr, latStr] = (raw.Coordinates || '').split(',').map((s) => s.trim());
  return {
    eventId: raw.DateTime || `${raw.Tanggal}-${raw.Jam}`,
    tanggal: raw.Tanggal,
    jam: raw.Jam,
    dateTime: raw.DateTime,
    magnitude: parseFloat(raw.Magnitude),
    depth: raw.Kedalaman,
    location: raw.Wilayah,
    latitude: latStr ? parseFloat(latStr) : parseFloat(raw.Lintang),
    longitude: lonStr ? parseFloat(lonStr) : parseFloat(raw.Bujur),
    lintangRaw: raw.Lintang,
    bujurRaw: raw.Bujur,
    potensi: raw.Potensi || null,
    dirasakan: raw.Dirasakan || null,
    source: 'BMKG'
  };
}

/**
 * Turunkan status tsunami dari field "Potensi" BMKG - satu-satunya sinyal
 * resmi yang tersedia pada feed data terbuka BMKG per-event gempa.
 * Bot TIDAK PERNAH menyimpulkan status tsunami dari magnitudo sendiri.
 *
 * BMKG hanya mempublikasikan dua kondisi lewat field ini:
 *   "Tidak berpotensi tsunami"  -> NORMAL (tidak ada peringatan)
 *   "Berpotensi tsunami ..."    -> WARNING (ada peringatan resmi)
 *
 * Status ADVISORY tidak dapat diturunkan dari feed publik ini, sehingga
 * bot tidak pernah mengarangnya - hanya WARNING/NORMAL yang dipakai.
 */
function deriveTsunamiStatus(potensiText) {
  if (!potensiText) return null;
  const normalized = potensiText.toLowerCase();
  if (normalized.includes('tidak berpotensi')) return 'NORMAL';
  if (normalized.includes('berpotensi')) return 'WARNING';
  return null;
}

module.exports = { fetchLatestEarthquake, fetchRecentEarthquakes, deriveTsunamiStatus };
