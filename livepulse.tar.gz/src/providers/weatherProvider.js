'use strict';

const axios = require('axios');
const logger = require('../utils/logger');
const { getAllCitiesFlat } = require('../utils/location');

// Provider cuaca: Open-Meteo (https://open-meteo.com) - gratis, tanpa API key,
// mendukung koordinat lintang/bujur kota-kota Indonesia secara langsung.
const BASE_URL = 'https://api.open-meteo.com/v1/forecast';
const TIMEOUT_MS = 10000;

/**
 * Ambil cuaca terkini untuk seluruh kota sekaligus (1 request HTTP,
 * memakai parameter latitude/longitude yang dipisah koma - fitur
 * multi-location resmi dari Open-Meteo).
 * @returns {Promise<Map<string, {temperature:number, weatherCode:number}>>}
 */
async function fetchAllCitiesWeather() {
  const cities = getAllCitiesFlat();
  const latitudes = cities.map((c) => c.lat).join(',');
  const longitudes = cities.map((c) => c.lon).join(',');

  const response = await axios.get(BASE_URL, {
    params: {
      latitude: latitudes,
      longitude: longitudes,
      current_weather: true,
      timezone: 'Asia/Jakarta'
    },
    timeout: TIMEOUT_MS
  });

  const data = response.data;
  const results = Array.isArray(data) ? data : [data];

  if (results.length !== cities.length) {
    throw new Error(
      `Jumlah hasil cuaca (${results.length}) tidak sesuai jumlah kota (${cities.length})`
    );
  }

  const weatherByCity = new Map();
  results.forEach((entry, index) => {
    const city = cities[index];
    const current = entry.current_weather;
    if (!current) {
      logger.warn(`Data cuaca tidak lengkap untuk kota ${city.name}`);
      return;
    }
    weatherByCity.set(city.name, {
      temperature: current.temperature,
      weatherCode: current.weathercode
    });
  });

  return weatherByCity;
}

module.exports = { fetchAllCitiesWeather };
