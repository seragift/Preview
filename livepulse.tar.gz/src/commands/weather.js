'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { getWeatherSnapshot } = require('../services/weather/weatherService');
const { buildWeatherEmbed } = require('../embeds/weatherEmbed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('weather')
    .setDescription('Menampilkan dashboard cuaca Indonesia terbaru'),

  async execute(interaction) {
    await interaction.deferReply();
    const { data, isStale } = await getWeatherSnapshot();
    const embed = buildWeatherEmbed(data, isStale);
    await interaction.editReply({ embeds: [embed] });
  }
};
