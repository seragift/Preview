'use strict';

const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { getConnection } = require('../../database/connection');

function ensureGuildRow(db, guildId) {
  db.prepare('INSERT OR IGNORE INTO guild_settings (guild_id) VALUES (?)').run(guildId);
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setup')
    .setDescription('Konfigurasi LivePulse Indonesia (khusus admin)')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand((sub) =>
      sub
        .setName('weather')
        .setDescription('Atur channel dashboard cuaca')
        .addChannelOption((opt) =>
          opt.setName('channel').setDescription('Channel dashboard cuaca').addChannelTypes(ChannelType.GuildText).setRequired(true)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName('earthquake')
        .setDescription('Atur channel info gempa')
        .addChannelOption((opt) =>
          opt.setName('channel').setDescription('Channel info gempa').addChannelTypes(ChannelType.GuildText).setRequired(true)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName('tsunami')
        .setDescription('Atur channel peringatan tsunami')
        .addChannelOption((opt) =>
          opt.setName('channel').setDescription('Channel peringatan tsunami').addChannelTypes(ChannelType.GuildText).setRequired(true)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName('interval')
        .setDescription('Atur interval update (menit)')
        .addStringOption((opt) =>
          opt
            .setName('tipe')
            .setDescription('Jenis interval')
            .setRequired(true)
            .addChoices(
              { name: 'Weather', value: 'weather' },
              { name: 'Earthquake', value: 'earthquake' },
              { name: 'Tsunami', value: 'tsunami' }
            )
        )
        .addIntegerOption((opt) =>
          opt.setName('menit').setDescription('Interval dalam menit').setRequired(true).setMinValue(1)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName('mention')
        .setDescription('Aktifkan/nonaktifkan @everyone untuk tsunami WARNING')
        .addBooleanOption((opt) => opt.setName('aktif').setDescription('true/false').setRequired(true))
    )
    .addSubcommand((sub) =>
      sub
        .setName('toggle')
        .setDescription('Aktifkan/nonaktifkan bot untuk server ini')
        .addBooleanOption((opt) => opt.setName('aktif').setDescription('true/false').setRequired(true))
    ),

  async execute(interaction) {
    const db = getConnection();
    const guildId = interaction.guildId;
    ensureGuildRow(db, guildId);

    const sub = interaction.options.getSubcommand();

    if (sub === 'weather') {
      const channel = interaction.options.getChannel('channel');
      db.prepare(
        "UPDATE guild_settings SET weather_channel_id = ?, weather_message_id = NULL, updated_at = datetime('now') WHERE guild_id = ?"
      ).run(channel.id, guildId);

      const { scheduleGuildWeather } = require('../services/weather/weatherUpdater');
      const { updateWeatherDashboard } = require('../services/weather/weatherService');
      const settings = db.prepare('SELECT weather_interval FROM guild_settings WHERE guild_id = ?').get(guildId);
      await updateWeatherDashboard(interaction.client, guildId);
      scheduleGuildWeather(interaction.client, guildId, settings.weather_interval);

      return interaction.reply({ content: `✅ Channel cuaca diatur ke <#${channel.id}>`, ephemeral: true });
    }

    if (sub === 'earthquake') {
      const channel = interaction.options.getChannel('channel');
      db.prepare("UPDATE guild_settings SET earthquake_channel_id = ?, updated_at = datetime('now') WHERE guild_id = ?").run(channel.id, guildId);
      return interaction.reply({ content: `✅ Channel gempa diatur ke <#${channel.id}>`, ephemeral: true });
    }

    if (sub === 'tsunami') {
      const channel = interaction.options.getChannel('channel');
      db.prepare("UPDATE guild_settings SET tsunami_channel_id = ?, updated_at = datetime('now') WHERE guild_id = ?").run(channel.id, guildId);
      return interaction.reply({ content: `✅ Channel tsunami diatur ke <#${channel.id}>`, ephemeral: true });
    }

    if (sub === 'interval') {
      const tipe = interaction.options.getString('tipe');
      const menit = interaction.options.getInteger('menit');
      const ms = menit * 60000;
      const column = `${tipe}_interval`;
      db.prepare(`UPDATE guild_settings SET ${column} = ?, updated_at = datetime('now') WHERE guild_id = ?`).run(ms, guildId);

      if (tipe === 'weather') {
        const { scheduleGuildWeather } = require('../services/weather/weatherUpdater');
        scheduleGuildWeather(interaction.client, guildId, ms);
      }

      return interaction.reply({ content: `✅ Interval ${tipe} diatur menjadi ${menit} menit`, ephemeral: true });
    }

    if (sub === 'mention') {
      const aktif = interaction.options.getBoolean('aktif');
      db.prepare("UPDATE guild_settings SET mention_enabled = ?, updated_at = datetime('now') WHERE guild_id = ?").run(aktif ? 1 : 0, guildId);
      return interaction.reply({ content: `✅ Mention @everyone untuk tsunami WARNING: ${aktif ? 'aktif' : 'nonaktif'}`, ephemeral: true });
    }

    if (sub === 'toggle') {
      const aktif = interaction.options.getBoolean('aktif');
      db.prepare("UPDATE guild_settings SET enabled = ?, updated_at = datetime('now') WHERE guild_id = ?").run(aktif ? 1 : 0, guildId);

      if (!aktif) {
        const { unscheduleGuildWeather } = require('../services/weather/weatherUpdater');
        unscheduleGuildWeather(guildId);
      }

      return interaction.reply({ content: `✅ LivePulse Indonesia untuk server ini: ${aktif ? 'aktif' : 'nonaktif'}`, ephemeral: true });
    }
  }
};
