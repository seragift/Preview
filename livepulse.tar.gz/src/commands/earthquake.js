'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { fetchLatestEarthquake, deriveTsunamiStatus } = require('../providers/bmkgProvider');
const { buildEarthquakeEmbed } = require('../embeds/earthquakeEmbed');
const logger = require('../utils/logger');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('earthquake')
    .setDescription('Menampilkan informasi gempa bumi terbaru dari BMKG'),

  async execute(interaction) {
    await interaction.deferReply();
    try {
      const gempa = await fetchLatestEarthquake();
      const embed = buildEarthquakeEmbed(gempa);
      const status = deriveTsunamiStatus(gempa.potensi);
      if (status === 'WARNING') {
        embed.setDescription('🌊 **Berpotensi tsunami** menurut BMKG.');
      }
      await interaction.editReply({ embeds: [embed] });
    } catch (err) {
      logger.error(`/earthquake gagal: ${err.message}`);
      await interaction.editReply('⚠️ Gagal mengambil data gempa dari BMKG saat ini. Coba lagi sebentar.');
    }
  }
};
