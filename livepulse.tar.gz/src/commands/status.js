'use strict';

const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getConnection } = require('../../database/connection');
const { formatUptime, formatShortTimeWIB } = require('../utils/time');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('status')
    .setDescription('Menampilkan status LivePulse Indonesia'),

  async execute(interaction) {
    const db = getConnection();
    const settings = db.prepare('SELECT * FROM guild_settings WHERE guild_id = ?').get(interaction.guildId);

    const weatherOnline = settings?.weather_channel_id ? '🟢 Online' : '⚪ Belum diatur';
    const earthquakeOnline = settings?.earthquake_channel_id ? '🟢 Online' : '⚪ Belum diatur';
    const tsunamiOnline = settings?.tsunami_channel_id ? '🟢 Online' : '⚪ Belum diatur';

    const embed = new EmbedBuilder()
      .setTitle('🟢 LivePulse Indonesia')
      .setColor(0x2ecc71)
      .addFields(
        { name: 'Weather', value: weatherOnline, inline: true },
        { name: 'Earthquake', value: earthquakeOnline, inline: true },
        { name: 'Tsunami', value: tsunamiOnline, inline: true },
        { name: 'Last Weather Update', value: settings?.last_weather_update ? `${settings.last_weather_update} UTC` : 'N/A', inline: false },
        { name: 'Last Earthquake Check', value: settings?.last_earthquake_check ? `${settings.last_earthquake_check} UTC` : 'N/A', inline: false },
        { name: 'Last Tsunami Check', value: settings?.last_tsunami_check ? `${settings.last_tsunami_check} UTC` : 'N/A', inline: false },
        { name: 'Uptime', value: formatUptime(process.uptime() * 1000), inline: true },
        { name: 'Database', value: 'SQLite', inline: true }
      )
      .setFooter({ text: `Sekarang: ${formatShortTimeWIB()}` });

    await interaction.reply({ embeds: [embed] });
  }
};
