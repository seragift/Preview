-- ==========================================================
-- LivePulse Indonesia - Database Schema (SQLite)
-- ==========================================================

CREATE TABLE IF NOT EXISTS guild_settings (
  guild_id             TEXT PRIMARY KEY,
  weather_channel_id   TEXT,
  weather_message_id   TEXT,
  earthquake_channel_id TEXT,
  tsunami_channel_id   TEXT,
  weather_interval     INTEGER NOT NULL DEFAULT 1800000,
  earthquake_interval  INTEGER NOT NULL DEFAULT 60000,
  tsunami_interval     INTEGER NOT NULL DEFAULT 60000,
  mention_enabled      INTEGER NOT NULL DEFAULT 0,
  enabled              INTEGER NOT NULL DEFAULT 1,
  weather_status       TEXT NOT NULL DEFAULT 'idle',
  last_weather_update  TEXT,
  last_earthquake_check TEXT,
  last_tsunami_check   TEXT,
  created_at           TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at           TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS earthquake_events (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  event_id       TEXT NOT NULL UNIQUE,
  magnitude      REAL,
  location       TEXT,
  depth          TEXT,
  latitude       REAL,
  longitude      REAL,
  event_time     TEXT,
  tsunami_status TEXT,
  source         TEXT NOT NULL DEFAULT 'BMKG',
  sent_at        TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS tsunami_alerts (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  alert_id   TEXT NOT NULL UNIQUE,
  status     TEXT NOT NULL,
  region     TEXT,
  event_time TEXT,
  source     TEXT NOT NULL DEFAULT 'BMKG',
  sent_at    TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_earthquake_events_time ON earthquake_events(event_time);
CREATE INDEX IF NOT EXISTS idx_tsunami_alerts_time ON tsunami_alerts(event_time);
