'use strict';

const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');
const logger = require('../src/utils/logger');

const DB_PATH = path.join(__dirname, 'database.sqlite');
const SCHEMA_PATH = path.join(__dirname, 'schema.sql');

let db;

function getConnection() {
  if (db) return db;

  const isNewDb = !fs.existsSync(DB_PATH);
  db = new Database(DB_PATH);
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');

  const schema = fs.readFileSync(SCHEMA_PATH, 'utf8');
  db.exec(schema);

  if (isNewDb) {
    logger.success('Database SQLite baru berhasil dibuat');
  } else {
    logger.info('Database SQLite terhubung');
  }

  return db;
}

module.exports = { getConnection, DB_PATH };
