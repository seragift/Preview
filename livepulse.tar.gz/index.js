'use strict';

require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { Client, GatewayIntentBits, Collection } = require('discord.js');
const logger = require('./src/utils/logger');
const { getConnection } = require('./database/connection');

// Validasi env wajib sebelum start (tidak pernah hardcode token).
const REQUIRED_ENV = ['DISCORD_TOKEN', 'CLIENT_ID'];
for (const key of REQUIRED_ENV) {
  if (!process.env[key]) {
    logger.error(`Environment variable ${key} belum diatur di .env`);
    process.exit(1);
  }
}

// Inisialisasi database sejak awal supaya schema selalu siap.
getConnection();

const client = new Client({
  intents: [GatewayIntentBits.Guilds]
});

client.commands = new Collection();

// Load semua command dari src/commands
const commandsPath = path.join(__dirname, 'src', 'commands');
for (const file of fs.readdirSync(commandsPath).filter((f) => f.endsWith('.js'))) {
  const command = require(path.join(commandsPath, file));
  if (command?.data?.name) {
    client.commands.set(command.data.name, command);
  }
}

// Load semua event dari src/events
const eventsPath = path.join(__dirname, 'src', 'events');
for (const file of fs.readdirSync(eventsPath).filter((f) => f.endsWith('.js'))) {
  const event = require(path.join(eventsPath, file));
  if (event.once) {
    client.once(event.name, (...args) => event.execute(...args));
  } else {
    client.on(event.name, (...args) => event.execute(...args));
  }
}

process.on('unhandledRejection', (err) => {
  logger.error(`Unhandled rejection: ${err?.message || err}`);
});

process.on('uncaughtException', (err) => {
  logger.error(`Uncaught exception: ${err?.message || err}`);
});

client.login(process.env.DISCORD_TOKEN).catch((err) => {
  logger.error(`Gagal login ke Discord: ${err.message}`);
  process.exit(1);
});
