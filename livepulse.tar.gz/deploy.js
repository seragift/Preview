'use strict';

require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { REST, Routes } = require('discord.js');
const logger = require('./src/utils/logger');

const REQUIRED_ENV = ['DISCORD_TOKEN', 'CLIENT_ID'];
for (const key of REQUIRED_ENV) {
  if (!process.env[key]) {
    logger.error(`Environment variable ${key} belum diatur di .env`);
    process.exit(1);
  }
}

const commandsPath = path.join(__dirname, 'src', 'commands');
const commands = fs
  .readdirSync(commandsPath)
  .filter((f) => f.endsWith('.js'))
  .map((f) => require(path.join(commandsPath, f)).data.toJSON());

const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);

(async () => {
  try {
    logger.info(`Mendeploy ${commands.length} slash command...`);

    if (process.env.GUILD_ID) {
      // Deploy per-guild: instan, cocok untuk development.
      await rest.put(Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID), {
        body: commands
      });
      logger.success(`Slash command berhasil di-deploy ke guild ${process.env.GUILD_ID}`);
    } else {
      // Deploy global: butuh waktu propagasi hingga ~1 jam.
      await rest.put(Routes.applicationCommands(process.env.CLIENT_ID), { body: commands });
      logger.success('Slash command berhasil di-deploy secara global');
    }
  } catch (err) {
    logger.error(`Gagal deploy slash command: ${err.message}`);
    process.exit(1);
  }
})();
