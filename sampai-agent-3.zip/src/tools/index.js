'use strict';
const filesTool = require('./files');
const shellTool = require('./shell');
const compilerTool = require('./compiler');
const serverTool = require('./server');
const networkInfoTool = require('./network_info');
const dbTool = require('./db');
const tasksMem = require('../memory/tasks');
const projectMem = require('../memory/project');
const changesMem = require('../memory/changes');
const errorsMem = require('../memory/errors');

const STATUS_ENUM = ['pending', 'in_progress', 'blocked', 'failed', 'completed', 'verified'];

const toolDefinitions = [
  {
    type: 'function',
    function: {
      name: 'list_files',
      description: 'Melihat daftar file dan folder di dalam workspace (relatif terhadap workspace root).',
      parameters: {
        type: 'object',
        properties: {
          path: { type: 'string', description: 'Folder relatif, default "." (root workspace).' },
          max_depth: { type: 'integer', description: 'Kedalaman folder maksimum yang ditelusuri, default 3.' },
        },
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'read_file',
      description: 'Membaca isi sebuah file di dalam workspace.',
      parameters: {
        type: 'object',
        properties: { path: { type: 'string', description: 'Path file relatif terhadap workspace.' } },
        required: ['path'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'write_file',
      description: 'Membuat file baru atau menimpa (overwrite) seluruh isi file yang sudah ada.',
      parameters: {
        type: 'object',
        properties: {
          path: { type: 'string' },
          content: { type: 'string' },
          task_id: { type: 'string', description: 'ID task yang sedang dikerjakan, jika ada.' },
          description: { type: 'string', description: 'Deskripsi singkat perubahan, untuk change log.' },
        },
        required: ['path', 'content'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'edit_file',
      description: 'Mengubah sebagian isi file dengan mengganti old_str (harus unik/hanya muncul sekali di file) dengan new_str.',
      parameters: {
        type: 'object',
        properties: {
          path: { type: 'string' },
          old_str: { type: 'string', description: 'Teks persis yang mau diganti, harus unik dalam file.' },
          new_str: { type: 'string' },
          task_id: { type: 'string' },
          description: { type: 'string' },
        },
        required: ['path', 'old_str', 'new_str'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'delete_file',
      description: 'Menghapus file. File penting (server.cfg, gamemodes/*.pwn, .env) butuh confirm=true.',
      parameters: {
        type: 'object',
        properties: {
          path: { type: 'string' },
          confirm: { type: 'boolean', description: 'Set true untuk mengonfirmasi hapus file penting/protected.' },
          task_id: { type: 'string' },
        },
        required: ['path'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'run_command',
      description: 'Menjalankan command Linux (dibatasi allowlist) untuk keperluan development/verifikasi, misalnya compile dengan pawncc atau menjalankan script node.',
      parameters: {
        type: 'object',
        properties: {
          command: { type: 'string' },
          cwd: { type: 'string', description: 'Working directory relatif terhadap workspace, default ".".' },
        },
        required: ['command'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'compile_pawn',
      description: 'Compile file .pwn dengan pawncc. Hasilnya sudah otomatis diparse jadi diagnostics terstruktur (file, line, code, severity, message), dan setiap error/fatal error otomatis tercatat ke error memory. Pakai ini (bukan run_command) setiap kali perlu compile/verify perubahan pada file .pwn.',
      parameters: {
        type: 'object',
        properties: {
          path: { type: 'string', description: 'Path file .pwn relatif workspace, misal gamemodes/main.pwn' },
          include_dirs: { type: 'array', items: { type: 'string' }, description: 'Folder include tambahan, relatif workspace, misal ["includes"].' },
          args: { type: 'string', description: 'Argumen tambahan mentah untuk pawncc (opsional), misal "-d3".' },
          task_id: { type: 'string' },
        },
        required: ['path'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'install_server',
      description: 'Install file server SA-MP/open.mp ke workspace: ekstrak dari arsip yang SUDAH diupload user ke workspace (source_archive) ATAU download dari URL yang ada di allowlist lalu ekstrak otomatis (.zip/.tar.gz/.tgz/.tar). Isi salah satu dari source_archive atau download_url.',
      parameters: {
        type: 'object',
        properties: {
          source_archive: { type: 'string', description: 'Path arsip yang sudah ada di workspace (mis. diupload user lewat SFTP), relatif workspace.' },
          download_url: { type: 'string', description: 'URL https untuk download arsip server. Host harus ada di allowlist: github.com, raw.githubusercontent.com, codeload.github.com, objects.githubusercontent.com, files.sa-mp.com.' },
          install_dir: { type: 'string', description: 'Folder tujuan instalasi, relatif workspace, mis. "samp-server".' },
          binary: { type: 'string', description: 'Nama file binary server relatif terhadap install_dir setelah ekstrak (mis. "samp03svr" atau "omp-server"), kalau sudah diketahui.' },
        },
        required: ['install_dir'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'start_server',
      description: 'Menjalankan binary server SA-MP/open.mp sebagai proses background yang tetap hidup walau agent sudah selesai merespons. Port yang beneran dipakai otomatis dibaca dari server.cfg di cwd (bukan dari parameter port) - hasilnya dikembalikan sebagai field "port" beserta "port_source". PID & konfigurasi disimpan ke memory supaya bisa dicek/dihentikan/di-restart nanti.',
      parameters: {
        type: 'object',
        properties: {
          binary: { type: 'string', description: 'Path binary server relatif workspace, mis. "samp-server/samp03svr".' },
          cwd: { type: 'string', description: 'Working directory relatif workspace (default: folder tempat binary berada). server.cfg harus ada di sini.' },
          args: { type: 'array', items: { type: 'string' }, description: 'Argumen tambahan untuk binary, opsional.' },
          port: { type: 'integer', description: 'Fallback kalau server.cfg tidak ditemukan/tidak ada baris port - kalau server.cfg ada, nilai di server.cfg yang menang.' },
        },
        required: ['binary'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'stop_server',
      description: 'Menghentikan proses server yang sedang berjalan (kirim SIGTERM, lalu SIGKILL kalau dalam beberapa detik belum berhenti).',
      parameters: { type: 'object', properties: {} },
    },
  },
  {
    type: 'function',
    function: {
      name: 'restart_server',
      description: 'Restart server: stop proses yang sedang jalan (kalau ada) lalu start lagi memakai konfigurasi (binary/cwd/args) terakhir yang tersimpan di memory.',
      parameters: { type: 'object', properties: {} },
    },
  },
  {
    type: 'function',
    function: {
      name: 'server_status',
      description: 'Cek status server saat ini: apakah proses masih hidup (PID), sejak kapan jalan, binary & port yang dipakai (field "configured_port"/"configured_bind" dibaca langsung dari server.cfg saat ini, bisa beda dari "port" hasil start_server terakhir kalau server.cfg diedit sesudahnya). Ini cek proses OS, BUKAN query protokol game penuh. Untuk IP yang dipakai player connect, itu IP publik VPS (bukan dari server.cfg kecuali ada baris "bind") - kalau user tanya, jalankan run_command "hostname -I" untuk melihatnya.',
      parameters: { type: 'object', properties: {} },
    },
  },
  {
    type: 'function',
    function: {
      name: 'find_free_port',
      description: 'Mencari port UDP yang benar-benar kosong di VPS (dites dengan bind sungguhan, bukan nebak), mulai dari preferred_port dan naik kalau bentrok. Pakai ini sebelum menulis port baru ke server.cfg supaya tidak bentrok dengan server/proses lain.',
      parameters: {
        type: 'object',
        properties: {
          preferred_port: { type: 'integer', description: 'Port yang mau dicoba duluan, mis. port yang sekarang ada di server.cfg. Default 7777.' },
          max_attempts: { type: 'integer', description: 'Berapa port berurutan yang dicoba sebelum menyerah. Default 50.' },
        },
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'detect_local_ips',
      description: 'Melihat alamat IPv4 yang benar-benar terpasang di network interface VPS (bukan tebakan). Pakai ini kalau user minta isi baris "bind" di server.cfg dengan IP VPS - JANGAN pernah mengarang IP sendiri.',
      parameters: { type: 'object', properties: {} },
    },
  },
  {
    type: 'function',
    function: {
      name: 'db_query',
      description: 'Jalankan SATU query SQL ke database MySQL/MariaDB (pakai kredensial admin dari .env) dan lihat hasilnya sebagai teks tabel. Ini alternatif ringan buat "lihat/kelola database lewat browser" tanpa perlu install phpMyAdmin/web server sama sekali - cocok buat SHOW TABLES, SELECT, DESCRIBE, atau perintah manage data lain. DROP DATABASE/SCHEMA ditolak (terlalu destruktif untuk dijalankan otomatis), dan cuma satu statement per panggilan (tidak boleh digabung pakai ";").',
      parameters: {
        type: 'object',
        properties: {
          sql: { type: 'string', description: 'Satu statement SQL, mis. "SHOW TABLES" atau "SELECT * FROM players LIMIT 10".' },
          database: { type: 'string', description: 'Nama database yang dituju, opsional kalau sql sudah include database (mis. "SHOW DATABASES").' },
          limit: { type: 'integer', description: 'Maksimum baris output yang ditampilkan, default 50, maksimum 200 (hasil query sendiri tetap sesuai SQL-nya, ini cuma batas tampilan).' },
        },
        required: ['sql'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'db_setup',
      description: 'Membuat database + user MySQL/MariaDB baru (dan opsional jalankan file .sql schema), lalu kembalikan kredensialnya. HANYA bisa dipakai kalau MySQL/MariaDB sudah terinstall & jalan di VPS, dan kredensial admin-nya sudah diisi user di .env (DB_ADMIN_USER/DB_ADMIN_PASSWORD) - tool ini TIDAK menginstall MySQL/MariaDB itu sendiri.',
      parameters: {
        type: 'object',
        properties: {
          database_name: { type: 'string', description: 'Nama database baru, huruf/angka/underscore saja.' },
          app_user: { type: 'string', description: 'Nama user MySQL baru khusus untuk aplikasi ini (jangan pakai user admin), huruf/angka/underscore saja.' },
          app_password: { type: 'string', description: 'Password untuk app_user. Kalau dikosongkan, sistem generate password acak yang aman otomatis.' },
          schema_file: { type: 'string', description: 'Path file .sql di workspace yang mau dijalankan ke database baru ini setelah dibuat, opsional.' },
        },
        required: ['database_name', 'app_user'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'read_server_log',
      description: 'Membaca beberapa baris terakhir log server (stdout/stderr) setelah start_server, untuk memverifikasi server beneran online dan tidak crash saat startup - PID yang masih hidup saja tidak cukup untuk membuktikan itu.',
      parameters: {
        type: 'object',
        properties: {
          stream: { type: 'string', enum: ['stdout', 'stderr'], description: 'Log mana yang mau dibaca, default stdout.' },
          lines: { type: 'integer', description: 'Berapa baris terakhir, default 50, maksimum 500.' },
        },
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'create_task',
      description: 'Membuat task baru di memory untuk melacak permintaan user saat ini. Panggil ini di awal pekerjaan baru (bukan continuation).',
      parameters: {
        type: 'object',
        properties: {
          title: { type: 'string' },
          steps: { type: 'array', items: { type: 'string' }, description: 'Daftar judul step awal yang direncanakan.' },
        },
        required: ['title'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'update_task',
      description: `Mengubah status task dan/atau salah satu step-nya. Status valid: ${STATUS_ENUM.join(', ')}.`,
      parameters: {
        type: 'object',
        properties: {
          task_id: { type: 'string' },
          status: { type: 'string', enum: STATUS_ENUM, description: 'Status baru untuk keseluruhan task.' },
          step_title: { type: 'string', description: 'Judul step yang mau diupdate (opsional).' },
          step_status: { type: 'string', enum: STATUS_ENUM, description: 'Status baru untuk step tersebut.' },
          note: { type: 'string', description: 'Catatan tambahan, misal alasan blocked/failed.' },
        },
        required: ['task_id'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'update_project_state',
      description: 'Update project.json: nama/deskripsi project, current_state, structure, completed/in_progress/todo/failed, dan next_task.',
      parameters: {
        type: 'object',
        properties: {
          project: { type: 'object', description: '{ name, path, type, description }' },
          current_state: { type: 'object', description: '{ status, version, last_action }' },
          structure: {
            type: 'object',
            description: '{ important_files, entry_points, gamemodes, filterscripts, includes, plugins, configs } (masing-masing array string)',
          },
          completed: { type: 'array', items: { type: 'string' } },
          in_progress: { type: 'array', items: { type: 'string' } },
          todo: { type: 'array', items: { type: 'string' } },
          failed: { type: 'array', items: { type: 'string' } },
          next_task: { type: 'string' },
        },
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'record_decision',
      description: 'Mencatat keputusan teknis penting beserta alasannya ke memory (mis. "pakai MySQL bukan SQLite karena ...").',
      parameters: {
        type: 'object',
        properties: { decision: { type: 'string' }, reason: { type: 'string' } },
        required: ['decision'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'update_error',
      description: 'Update status/solusi sebuah error yang sudah tercatat di error memory (pakai error_id dari hasil run_command yang gagal atau dari search_errors).',
      parameters: {
        type: 'object',
        properties: {
          error_id: { type: 'string' },
          status: { type: 'string', enum: ['open', 'investigating', 'resolved'] },
          solution: { type: 'string' },
        },
        required: ['error_id', 'status'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'search_errors',
      description: 'Mencari error serupa di error memory berdasarkan keyword, sebelum mencoba fix error yang mirip dari nol.',
      parameters: {
        type: 'object',
        properties: { query: { type: 'string' } },
        required: ['query'],
      },
    },
  },
];

async function executeTool(name, args, ctx) {
  const { workspace, memoryDir, logger } = ctx;
  const taskId = args.task_id || ctx.taskId;
  try {
    switch (name) {
      case 'list_files':
        return filesTool.listFiles(workspace, args.path || '.', { maxDepth: args.max_depth });

      case 'read_file':
        return filesTool.readFile(workspace, args.path);

      case 'write_file': {
        const res = filesTool.writeFile(workspace, args.path, args.content);
        if (res.success) {
          await changesMem.record(memoryDir, { file: args.path, action: res.action, description: args.description, task_id: taskId });
        }
        return res;
      }

      case 'edit_file': {
        const res = filesTool.editFile(workspace, args.path, args.old_str, args.new_str);
        if (res.success) {
          await changesMem.record(memoryDir, { file: args.path, action: 'edit', description: args.description, task_id: taskId });
        }
        return res;
      }

      case 'delete_file': {
        const res = filesTool.deleteFile(workspace, args.path, args.confirm);
        if (res.success) {
          await changesMem.record(memoryDir, { file: args.path, action: 'delete', description: 'File dihapus', task_id: taskId });
        }
        return res;
      }

      case 'run_command': {
        const res = shellTool.runCommand(workspace, args.command, args.cwd || '.');
        if (!res.success) {
          const errEntry = await errorsMem.record(memoryDir, {
            error: `${res.error}${res.output ? ' | output: ' + res.output.slice(0, 300) : ''}`,
            file: null,
            cause: null,
            solution: null,
            status: 'open',
            task_id: taskId,
          });
          return { ...res, error_id: errEntry.id };
        }
        return res;
      }

      case 'compile_pawn': {
        const res = compilerTool.compilePawn(workspace, args.path, {
          include_dirs: args.include_dirs,
          args: args.args,
        });
        if (Array.isArray(res.diagnostics) && res.diagnostics.length) {
          const recordedErrors = [];
          for (const d of res.diagnostics) {
            if (d.severity === 'warning') continue;
            const existing = errorsMem
              .search(memoryDir, d.message)
              .find((e) => e.file === d.file && e.line === d.line && e.status !== 'resolved');
            if (existing) { recordedErrors.push(existing); continue; }
            const entry = await errorsMem.record(memoryDir, {
              error: `[pawncc ${d.severity} ${d.code}] ${d.message}`,
              file: d.file,
              line: d.line,
              cause: null,
              solution: null,
              status: 'open',
              task_id: taskId,
            });
            recordedErrors.push(entry);
          }
          res.recorded_errors = recordedErrors.map((e) => ({ id: e.id, file: e.file, line: e.line, error: e.error }));
        }
        return res;
      }

      case 'install_server': {
        const res = await serverTool.installServer(workspace, args);
        if (res.success) {
          await serverTool.saveState(memoryDir, {
            installed: true,
            install_dir: args.install_dir,
            binary: res.binary || null,
          });
          await projectMem.patch(memoryDir, { current_state: { last_action: `install_server -> ${args.install_dir}` } });
        }
        return res;
      }

      case 'start_server': {
        const res = serverTool.startServer(workspace, memoryDir, args);
        if (res.success) {
          await serverTool.saveState(memoryDir, {
            installed: true,
            pid: res.pid,
            status: 'running',
            binary: args.binary,
            cwd: res.cwd || args.cwd || null, // pakai cwd hasil resolve (selalu terisi), bukan cwd mentah dari args (bisa undefined)
            args: Array.isArray(args.args) ? args.args : [],
            port: res.port || args.port || null,
            started_at: new Date().toISOString(),
            stopped_at: null,
          });
        }
        return res;
      }

      case 'stop_server': {
        const state = serverTool.getState(memoryDir);
        const res = await serverTool.stopServer(state.pid);
        if (res.success) {
          await serverTool.saveState(memoryDir, { pid: null, status: 'stopped', stopped_at: new Date().toISOString() });
        }
        return res;
      }

      case 'restart_server': {
        const state = serverTool.getState(memoryDir);
        if (!state.binary) {
          return { success: false, error: 'Belum ada konfigurasi server tersimpan (binary tidak diketahui). Pakai start_server dulu minimal sekali.' };
        }
        const stopRes = state.pid ? await serverTool.stopServer(state.pid) : { success: true, already_stopped: true };
        const startRes = serverTool.startServer(workspace, memoryDir, {
          binary: state.binary, cwd: state.cwd, args: state.args, port: state.port,
        });
        if (startRes.success) {
          await serverTool.saveState(memoryDir, {
            pid: startRes.pid, status: 'running', started_at: new Date().toISOString(), stopped_at: null,
          });
        }
        return { success: startRes.success, stop: stopRes, start: startRes };
      }

      case 'server_status':
        return { success: true, ...serverTool.serverStatus(memoryDir, workspace) };

      case 'find_free_port':
        return await networkInfoTool.findFreePort(args);

      case 'detect_local_ips':
        return networkInfoTool.detectLocalIPs();

      case 'db_query':
        return await dbTool.queryDatabase(workspace, args);

      case 'db_setup':
        return await dbTool.setupDatabase(workspace, args);

      case 'read_server_log':
        return serverTool.readServerLog(memoryDir, args.stream, args.lines);

      case 'create_task':
        return await tasksMem.create(memoryDir, args.title, args.steps || []);

      case 'update_task': {
        if (args.step_title) {
          await tasksMem.updateStep(memoryDir, args.task_id, args.step_title, args.step_status || 'completed');
        }
        let task = tasksMem.getById(memoryDir, args.task_id);
        if (args.status) {
          task = await tasksMem.updateStatus(memoryDir, args.task_id, args.status, { note: args.note });
        }
        return { success: true, task };
      }

      case 'update_project_state':
        return { success: true, project: await projectMem.patch(memoryDir, args) };

      case 'record_decision':
        return { success: true, recorded: await projectMem.addDecision(memoryDir, args.decision, args.reason) };

      case 'update_error':
        return { success: true, error: await errorsMem.updateStatus(memoryDir, args.error_id, args.status, args.solution) };

      case 'search_errors':
        return { success: true, results: errorsMem.search(memoryDir, args.query) };

      default:
        return { success: false, error: `Tool tidak dikenal: ${name}` };
    }
  } catch (err) {
    return { success: false, error: err.message };
  } finally {
    if (logger) {
      try {
        // Redact field apa pun yang namanya mengandung "password" sebelum ditulis ke tool.log,
        // supaya kredensial DB (app_password/schema, dst) tidak nyangkut di file log mentah.
        const safeArgs = { ...args };
        for (const k of Object.keys(safeArgs)) {
          if (/password/i.test(k)) safeArgs[k] = '[REDACTED]';
        }
        logger.tool({ tool: name, args: safeArgs, task_id: taskId });
      } catch (_) {}
    }
  }
}

module.exports = { toolDefinitions, executeTool };
