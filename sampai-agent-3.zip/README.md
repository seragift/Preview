# SAMPAI Agent (V2)

AI coding agent berbasis Node.js yang jalan di VPS, khusus untuk membantu development project **SA-MP (San Andreas Multiplayer)**.

**Bisa dilakukan:**
- Baca/tulis/edit/hapus file source code
- Compile `.pwn` dengan parsing error/warning terstruktur (`compile_pawn`)
- Install, start, stop, restart, dan cek status server SA-MP/open.mp (`install_server`, `start_server`, `stop_server`, `restart_server`, `server_status`)
- Memory yang tersimpan permanen di filesystem, sehingga agent tetap ingat kondisi project & server walau Node.js/VPS restart

**Belum dilakukan (roadmap berikutnya):** manajemen plugin/dependency otomatis, monitoring player real-time, automated deployment. Lihat bagian [Roadmap](#9-roadmap-selanjutnya).

---

## 1. Struktur Folder

```
sampai-agent/
├── agent.js                  # entry point CLI (REPL)
├── package.json
├── .env.example
├── .gitignore
├── README.md
│
├── src/
│   ├── agent/
│   │   ├── loop.js           # loop utama: kirim ke LLM, jalankan tool calls, sampai selesai
│   │   ├── planner.js        # system prompt / aturan kerja agent
│   │   └── context.js        # bangun ringkasan context dari memory (bukan dari chat history)
│   │
│   ├── tools/
│   │   ├── files.js          # list_files, read_file, write_file, edit_file, delete_file
│   │   ├── shell.js          # run_command
│   │   ├── compiler.js       # compile_pawn - compile .pwn + parse error/warning terstruktur
│   │   ├── server.js         # install_server, start_server, stop_server, restart_server, server_status, read_server_log
│   │   ├── network_info.js   # find_free_port, detect_local_ips
│   │   ├── db.js             # db_setup - buat database/user MySQL + jalankan schema.sql
│   │   └── index.js          # tool schema (function calling) + dispatcher
│   │
│   ├── memory/
│   │   ├── manager.js        # generic read/write JSON yang aman & atomik
│   │   ├── project.js        # project.json + decisions.json
│   │   ├── tasks.js          # tasks.json
│   │   ├── changes.js        # changes.json
│   │   └── errors.js         # errors.json
│   │
│   ├── security/
│   │   ├── sandbox.js        # path validation, command allowlist/blocklist, file size limit
│   │   └── network.js        # allowlist host untuk download_url (install_server)
│   │
│   └── utils/
│       └── logger.js
│
├── memory/                   # DISIMPAN DI FILESYSTEM, bertahan lintas restart
│   ├── project.json
│   ├── tasks.json
│   ├── changes.json
│   ├── errors.json
│   └── decisions.json
│
├── logs/
│   ├── agent.log
│   ├── tool.log
│   ├── task.log
│   └── error.log
│
├── workspace/
│   └── samp-project/         # contoh project SA-MP (ganti dengan project asli kamu)
│
└── test/
    └── run-tests.js
```

## 2. Instalasi

Di VPS (Ubuntu/Debian, Node.js >= 18):

```bash
cd sampai-agent
npm install
cp .env.example .env
nano .env   # isi API key & endpoint
```

## 3. Konfigurasi API (`.env`)

Agent memakai API OpenAI-compatible, jadi bisa dipakai dengan provider apa pun yang kompatibel — termasuk **NaraRouter**:

```env
OPENAI_API_KEY=sk-xxxxxxxxxxxxxxxxxxxxxxxxxx
OPENAI_BASE_URL=https://router.bynara.id/v1
OPENAI_MODEL=agnes-2.5-flash

WORKSPACE=./workspace
MAX_TOOL_ITERATIONS=25
COMMAND_TIMEOUT_MS=30000
MAX_FILE_SIZE_KB=1024
MAX_COMMAND_OUTPUT_KB=64
```

Ganti `OPENAI_API_KEY` dengan API key asli dari dashboard NaraRouter kamu (jangan pernah commit `.env` ke git — sudah di-`.gitignore`). Model yang dipakai harus mendukung **function calling / tool use**; `agnes-2.5-flash` di screenshot dashboard kamu kompatibel dengan endpoint `/v1/chat/completions` ala OpenAI, jadi tinggal pakai konfigurasi di atas.

## 4. Menjalankan Agent

```bash
npm start
```

Lalu ketik perintah, misalnya:

```
> Baca source gamemode ini dan pahami strukturnya.
> Buatkan sistem login.
> Tambahkan command /veh.
> Apa yang belum selesai?
> Lanjutkan.
```

Ketik `exit` untuk keluar.

## 5. Cara Kerja Memory

Semua state project disimpan sebagai file JSON di folder `memory/`, **bukan** di memori percakapan — jadi tetap ada walau proses Node.js/VPS restart.

| File | Isi |
|---|---|
| `project.json` | nama/tipe project, status saat ini, struktur file penting, completed/in_progress/todo/failed, next_task |
| `tasks.json` | daftar task + step-nya (status: `pending`, `in_progress`, `blocked`, `failed`, `completed`, `verified`) |
| `changes.json` | log setiap file yang ditulis/diedit/dihapus (otomatis tercatat oleh tools) |
| `errors.json` | log error dari command/compile yang gagal, beserta solusi kalau sudah ditemukan |
| `decisions.json` | keputusan teknis penting beserta alasannya |
| `server.json` | status server (installed, install_dir, binary, cwd, args, pid, status, port, started_at/stopped_at) |

Setiap kali kamu kirim perintah, agent membaca ulang semua file ini dan meringkasnya jadi konteks untuk system prompt — termasuk saat kamu bilang **"Lanjutkan"**: agent akan cek `IN_PROGRESS`, `LAST_TASK`, dan `NEXT_TASK`, lalu melanjutkan dari step yang belum selesai (bukan mengulang dari awal).

Prioritas kebenaran kalau ada konflik: **kondisi file aktual > hasil command/test > hasil tool > memory lama > asumsi AI**. Kalau memory bilang sudah selesai tapi filenya belum ada, agent akan percaya file dan memperbaiki memory-nya.

## 6. Tools yang Tersedia untuk Agent

**Wajib (file & shell):**
- `list_files`, `read_file`, `write_file`, `edit_file`, `delete_file`
- `run_command` (dibatasi allowlist binary + blocklist pola berbahaya, lihat `src/security/sandbox.js`)

**Compiler:**
- `compile_pawn` - compile file `.pwn` pakai pawncc, hasilnya otomatis diparse jadi diagnostics terstruktur (file, line, code, severity, message). Setiap error/fatal error otomatis tercatat ke error memory (dengan dedupe - error yang sama di file+line yang sama tidak dicatat dobel). Agent dipandu lewat system prompt untuk selalu pakai tool ini (bukan `run_command`) setiap kali perlu compile/verify perubahan pada `.pwn`.

**Server management:**
- `install_server` - ekstrak arsip server (`.zip`/`.tar.gz`/`.tgz`/`.tar`) ke workspace. Sumbernya HARUS salah satu dari: (a) file yang sudah kamu upload sendiri ke workspace (`source_archive`), atau (b) URL `https://` dari host yang ada di allowlist (`src/security/network.js`) — default: GitHub (untuk open.mp) dan `files.sa-mp.com`. Host lain otomatis ditolak.
- `start_server` - jalankan binary server sebagai proses background yang tetap hidup walau sesi chat/agent sudah selesai. PID & konfigurasi (binary/cwd/args/port) disimpan ke `server.json`.
- `stop_server` - kirim `SIGTERM`, tunggu sampai `SERVER_STOP_TIMEOUT_MS` (default 8 detik), kalau belum berhenti baru `SIGKILL`.
- `restart_server` - stop lalu start lagi otomatis pakai konfigurasi terakhir yang tersimpan (tidak perlu sebut ulang binary/cwd/args).
- `server_status` - cek apakah proses (PID) masih hidup, sejak kapan jalan, binary & port yang dipakai. **Catatan:** ini cek proses OS, bukan query protokol game SA-MP penuh (jumlah player online real-time, dsb).
- `read_server_log` - baca N baris terakhir `logs/server-stdout.log`/`server-stderr.log`. Dipakai agent buat verifikasi server BENERAN online (PID hidup doang nggak cukup, bisa aja proses hidup tapi stuck di error startup).

**Database:**
- `db_setup` - bikin database + user MySQL/MariaDB baru (opsional jalankan `.sql` schema), balikin kredensialnya.
- `db_query` - jalankan satu query SQL (pakai kredensial admin dari `.env`) dan lihat hasilnya sebagai teks tabel langsung di chat. **Alternatif phpMyAdmin tanpa perlu install PHP/web server sama sekali** — cocok buat `SHOW TABLES`, `SELECT`, `DESCRIBE`, atau operasi kelola data lain. `DROP DATABASE`/`DROP SCHEMA` ditolak (terlalu destruktif buat dijalankan otomatis), dan cuma boleh satu statement per panggilan.

Lihat bagian [Database](#database-mysqlmariadb) di bawah untuk batasannya.

Output & error server berjalan disimpan di `logs/server-stdout.log` dan `logs/server-stderr.log`.

### IP & Port - cara tahu alamat buat connect

- **Port**: `start_server` **otomatis membaca baris `port` dari `server.cfg`** di folder tempat server dijalankan — bukan dari parameter `port` yang kamu kasih (itu cuma fallback kalau `server.cfg` tidak ada/tidak ketemu). Hasilnya dikembalikan sebagai field `port` + `port_source` (`"server.cfg"` atau `"parameter"`).
- `server_status` juga menampilkan `configured_port` (dibaca ulang dari `server.cfg` saat itu juga) terpisah dari `port` (port yang dipakai proses yang SEDANG jalan). Kalau kamu edit `server.cfg` tanpa restart server, dua angka ini bisa beda — itu tandanya server perlu di-`restart_server` biar port barunya kepakai.
- **IP**: SA-MP/open.mp defaultnya listen di semua network interface (`0.0.0.0`), jadi yang dipakai player untuk connect adalah **IP publik VPS kamu** — bukan sesuatu yang diatur lewat `server.cfg` (kecuali kamu isi baris `bind` ke IP tertentu). Agent bisa lihat IP VPS lewat `run_command` dengan `hostname -I` kalau kamu tanya.

### Auto-setting port kosong & IP di server.cfg

Kalau kamu minta agent "pasang port yang tersedia" atau "bentrok port, cariin yang kosong", agent akan:
1. Panggil `find_free_port` — ini **beneran nyoba bind ke port UDP** (bukan nebak), mulai dari port yang ada di `server.cfg` sekarang, naik terus sampai ketemu yang kosong.
2. Tulis hasilnya ke `server.cfg` pakai `edit_file`.
3. `start_server` otomatis baca ulang port yang baru itu dari `server.cfg`.

Kalau kamu minta isi baris `bind` dengan IP VPS, agent akan panggil `detect_local_ips` dulu (baca langsung dari network interface OS, bukan nebak) dan pakai salah satu IP yang `internal: false` dari situ. **Catatan:** kalau VPS-mu di belakang NAT/load balancer, IP yang nempel di interface OS bisa beda dari IP publik yang dikasih provider — kalau ragu, cek dashboard VPS kamu. Dan sebenarnya `bind` ini opsional: server SA-MP/open.mp defaultnya sudah bisa diakses lewat IP publik VPS tanpa perlu diisi sama sekali, kecuali VPS kamu punya banyak IP dan mau dipaksa pakai salah satu spesifik.

### Database (MySQL/MariaDB)

**Penting:** agent **TIDAK menginstall MySQL/MariaDB, PHP, web server, atau phpMyAdmin**. Itu semua instalasi software level sistem (`apt install`, `systemctl`, akses root, edit file di `/etc/`) yang memang sengaja di luar sandbox agent ini — command seperti `sudo`, `apt-get install`, `systemctl` diblokir permanen (lihat bagian Keamanan). Install MySQL/MariaDB sendiri dulu (manual, atau lewat one-click installer dari provider VPS kamu), baru agent bisa bantu bagian berikutnya:

1. Isi `DB_HOST`, `DB_PORT`, `DB_ADMIN_USER`, `DB_ADMIN_PASSWORD` di `.env` dengan kredensial admin MySQL yang sudah kamu install.
2. Minta agent bikin database + user baru buat project SA-MP kamu — dia akan pakai tool **`db_setup`**: bikin database & user MySQL baru (bukan pakai user admin), opsional langsung jalankan file `.sql` schema kalau kamu punya, lalu balikin kredensialnya. Kalau kamu nggak kasih password, sistem generate password acak yang aman dan agent **wajib menampilkannya** ke kamu di jawabannya (dicatat sekali saja, tidak diulang-ulang).
3. **Mau lihat/kelola isi database tanpa install phpMyAdmin?** Tinggal minta di chat, mis. *"tampilkan isi tabel players"* atau *"database apa aja yang ada"* — agent pakai **`db_query`** buat jalanin SQL-nya langsung dan tunjukkin hasilnya. Ini jauh lebih ringan daripada install PHP+Apache+phpMyAdmin cuma buat ngintip data. Kalau kamu tetap mau phpMyAdmin beneran (versi web GUI-nya), itu tetap instalasi manual seperti disebut di atas.
4. Password kredensial **tidak pernah tersimpan di `logs/tool.log`** — field apa pun yang namanya mengandung "password" otomatis di-redact sebelum ditulis ke log.
5. Kredensial connection MySQL yang di-generate itu masih perlu ditulis manual ke config project kamu (via `edit_file`) — formatnya beda-beda tergantung plugin MySQL yang dipakai gamemode kamu (mis. `#define` di `.pwn`, atau file `.ini` terpisah untuk plugin sscanf/mysql), jadi agent akan tanya/cek dulu formatnya sebelum nulis.

### Perintah "jalankan &lt;folder&gt;" / online-kan server end-to-end

Kalau kamu minta agent nge-online-kan satu project sampai bener-bener jalan, dia akan urut: pahami struktur project → setup database kalau perlu (lihat batasan di atas) → `compile_pawn` (perbaiki error kalau ada) → cek/atur port → `start_server`/`restart_server` → cek `server_status` **dan** `read_server_log` buat mastiin beneran online (bukan cuma PID hidup) → lapor status akhir + IP:port buat connect. Kalau ada langkah yang gagal/butuh sesuatu darimu (mis. MySQL belum di-install), agent akan berhenti di situ dan bilang jujur apa yang masih kurang — bukan mengarang bahwa semuanya sudah beres.

**Tambahan (memory/task management, dipakai agent secara otonom):**
- `create_task`, `update_task`
- `update_project_state`, `record_decision`
- `update_error`, `search_errors`

### Konfigurasi compiler

Set `PAWNCC_PATH` di `.env`:

```env
PAWNCC_PATH=pawncc          # kalau pawncc sudah ada di $PATH
# atau
PAWNCC_PATH=/opt/pawncc/pawncc   # path absolut ke binary
```

`compile_pawn` menjalankan compiler di folder tempat file `.pwn` berada, lalu hasil `.amx` dibuat di folder yang sama. Task/step baru dianggap **`verified`** oleh agent hanya kalau `compile_pawn` benar-benar berhasil (tidak ada error/fatal error) - bukan cuma karena file berhasil ditulis.

## 7. Keamanan

- Semua path dibatasi (sandbox) ke dalam `WORKSPACE` — path traversal (`../..`) ditolak.
- `run_command` cuma boleh menjalankan binary yang ada di allowlist (`ls`, `cat`, `grep`, `node`, `pawncc`, `unzip`, `tar`, dst — edit `ALLOWED_BINARIES` di `src/security/sandbox.js` kalau perlu tambah).
- Pola command berbahaya (`rm -rf`, `sudo`, `curl`, `wget`, `chmod 777`, fork bomb, dst) diblokir walau binary-nya diizinkan.
- Command punya timeout (`COMMAND_TIMEOUT_MS`) dan batas ukuran output (`MAX_COMMAND_OUTPUT_KB`).
- File punya batas ukuran (`MAX_FILE_SIZE_KB`).
- Menghapus file penting (`server.cfg`, `gamemodes/*.pwn`, `.env`) butuh `confirm=true` eksplisit.
- `install_server` cuma boleh download dari host di allowlist (`src/security/network.js`) lewat `https://` — bukan lewat `curl`/`wget` shell yang memang sengaja diblokir. Ekstraksi arsip & argumen `start_server`/`compile_pawn` dieksekusi lewat `spawn`/`spawnSync` dengan argv array (bukan string shell), jadi nama file atau argumen aneh-aneh tidak bisa dipakai untuk command injection.
- `start_server` menjalankan binary langsung (bukan lewat shell) dan wajib berada di dalam `WORKSPACE`.
- `stop_server` mengirim `SIGTERM` dulu (graceful shutdown), baru `SIGKILL` kalau proses tidak berhenti dalam `SERVER_STOP_TIMEOUT_MS`.

## 8. Testing

```bash
npm test
```

Menjalankan 7 test otomatis (list/read/write/edit file, run command, memory persistence, task continuation). Test ke-8 versi end-to-end lewat LLM (user bilang "lanjutkan" dan agent benar-benar nyambung) butuh `OPENAI_API_KEY` aktif — coba manual lewat `npm start`.

Fitur compiler & server management sudah diuji manual (parsing diagnostics pawncc, dedupe error, install/start/status/stop/restart pakai binary dummy, dan penolakan host yang tidak di-allowlist) — tapi belum ada test otomatis untuk ini di `npm test` karena butuh binary pawncc/server SA-MP asli. Kalau mau, tambahkan test terpisah yang jalan hanya kalau binary-binary itu tersedia di environment kamu.

## 9. Roadmap Selanjutnya

Sudah selesai: coding + memory (V1), compiler integration, server install/start/stop/restart/status.

Belum ada, direncanakan berikutnya:
- Deteksi dependency/include otomatis
- Manajemen plugin & `server.cfg` yang lebih terstruktur (bukan cuma read_file/edit_file manual)
- Monitoring server & player
- Automated deployment
