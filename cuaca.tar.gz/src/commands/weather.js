'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { getWeatherSnapshot } = require('../services/weather/weatherService');
const { buildWeatherEmbed, buildCityWeatherDetailEmbed } = require('../embeds/weatherEmbed');
const { fetchCityWeatherDetail } = require('../providers/weatherProvider');
const { getAllCitiesFlat, findCityByName } = require('../utils/location');
const logger = require('../utils/logger');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('weather')
    .setDescription('Menampilkan dashboard cuaca Indonesia, atau cuaca detail 1 kota')
    .addStringOption((opt) =>
      opt.setName('kota').setDescription('Nama kota (opsional, kosongkan untuk dashboard lengkap)').setRequired(false).setAutocomplete(true)
    ),

  async autocomplete(interaction) {
    const focused = interaction.options.getFocused().toLowerCase();
    const cities = getAllCitiesFlat();
    const filtered = cities.filter((c) => c.name.toLowerCase().includes(focused)).slice(0, 25);
    await interaction.respond(filtered.map((c) => ({ name: `${c.name} (${c.region})`, value: c.name })));
  },

  async execute(interaction) {
    const kota = interaction.options.getString('kota');

    if (kota) {
      const city = findCityByName(kota);
      if (!city) {
        return interaction.reply({ content: `⚠️ Kota "${kota}" tidak ditemukan dalam daftar kota yang didukung.`, ephemeral: true });
      }

      await interaction.deferReply();
      try {
        const detail = await fetchCityWeatherDetail(city);
        const embed = buildCityWeatherDetailEmbed(city, detail);
        return interaction.editReply({ embeds: [embed] });
      } catch (err) {
        logger.error(`/weather kota:${kota} gagal: ${err.message}`);
        return interaction.editReply(`⚠️ Gagal mengambil data cuaca untuk ${city.name} saat ini. Coba lagi sebentar.`);
      }
    }

    await interaction.deferReply();
    const { data, isStale } = await getWeatherSnapshot();
    const embed = buildWeatherEmbed(data, isStale);
    await interaction.editReply({ embeds: [embed] });
  }
};
