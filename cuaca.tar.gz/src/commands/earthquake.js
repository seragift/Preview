'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { fetchLatestEarthquake, fetchFeltEarthquakes, deriveTsunamiStatus } = require('../providers/bmkgProvider');
const {
  buildEarthquakeEmbed,
  buildFeltEarthquakeListEmbed,
  buildEarthquakeHistoryEmbed,
  buildEarthquakeStatsEmbed
} = require('../embeds/earthquakeEmbed');
const { getEarthquakeHistory, getDailyEarthquakeStats } = require('../services/earthquake/earthquakeService');
const logger = require('../utils/logger');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('earthquake')
    .setDescription('Informasi gempa bumi dari BMKG')
    .addSubcommand((sub) => sub.setName('terbaru').setDescription('Gempa bumi terbaru dari BMKG'))
    .addSubcommand((sub) =>
      sub
        .setName('riwayat')
        .setDescription('Riwayat gempa yang tercatat bot')
        .addIntegerOption((opt) => opt.setName('jumlah').setDescription('Jumlah data (default 10, maks 25)').setMinValue(1).setMaxValue(25))
    )
    .addSubcommand((sub) => sub.setName('dirasakan').setDescription('Daftar gempa yang dirasakan warga (BMKG)'))
    .addSubcommand((sub) => sub.setName('statistik').setDescription('Statistik gempa harian & mingguan')),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    await interaction.deferReply();

    if (sub === 'terbaru') {
      try {
        const gempa = await fetchLatestEarthquake();
        const embed = buildEarthquakeEmbed(gempa);
        const status = deriveTsunamiStatus(gempa.potensi);
        if (status === 'WARNING') embed.setDescription('🌊 **Berpotensi tsunami** menurut BMKG.');
        return interaction.editReply({ embeds: [embed] });
      } catch (err) {
        logger.error(`/earthquake terbaru gagal: ${err.message}`);
        return interaction.editReply('⚠️ Gagal mengambil data gempa dari BMKG saat ini. Coba lagi sebentar.');
      }
    }

    if (sub === 'riwayat') {
      const jumlah = interaction.options.getInteger('jumlah') || 10;
      const rows = getEarthquakeHistory(jumlah);
      if (rows.length === 0) return interaction.editReply('Belum ada riwayat gempa yang tercatat oleh bot.');
      return interaction.editReply({ embeds: [buildEarthquakeHistoryEmbed(rows)] });
    }

    if (sub === 'dirasakan') {
      try {
        const list = await fetchFeltEarthquakes();
        return interaction.editReply({ embeds: [buildFeltEarthquakeListEmbed(list.slice(0, 10))] });
      } catch (err) {
        logger.error(`/earthquake dirasakan gagal: ${err.message}`);
        return interaction.editReply('⚠️ Gagal mengambil data gempa dirasakan dari BMKG saat ini.');
      }
    }

    if (sub === 'statistik') {
      const stats = getDailyEarthquakeStats();
      return interaction.editReply({ embeds: [buildEarthquakeStatsEmbed(stats)] });
    }
  }
};
