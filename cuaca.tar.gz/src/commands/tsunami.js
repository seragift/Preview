'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { getLatestTsunamiAlert, getTsunamiHistory } = require('../services/earthquake/tsunamiService');
const { buildTsunamiStatusEmbed } = require('../embeds/tsunamiEmbed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('tsunami')
    .setDescription('Status & riwayat peringatan tsunami resmi BMKG')
    .addBooleanOption((opt) => opt.setName('riwayat').setDescription('Tampilkan riwayat peringatan sebelumnya').setRequired(false)),

  async execute(interaction) {
    const showHistory = interaction.options.getBoolean('riwayat') || false;
    const latest = getLatestTsunamiAlert();
    const history = showHistory ? getTsunamiHistory(5) : [];
    const embed = buildTsunamiStatusEmbed(latest, history);
    await interaction.reply({ embeds: [embed] });
  }
};
