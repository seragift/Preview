'use strict';

// Peta kode cuaca WMO (dipakai Open-Meteo) -> deskripsi & emoji Bahasa Indonesia.
// Referensi kode: https://open-meteo.com/en/docs (WMO Weather interpretation codes)
const WEATHER_CODE_MAP = {
  0: { text: 'Cerah', emoji: '☀️' },
  1: { text: 'Cerah Berawan', emoji: '🌤️' },
  2: { text: 'Cerah Berawan', emoji: '🌤️' },
  3: { text: 'Berawan', emoji: '☁️' },
  45: { text: 'Berkabut', emoji: '🌫️' },
  48: { text: 'Berkabut', emoji: '🌫️' },
  51: { text: 'Hujan Lokal', emoji: '🌦️' },
  53: { text: 'Hujan Lokal', emoji: '🌦️' },
  55: { text: 'Hujan Lokal', emoji: '🌦️' },
  56: { text: 'Hujan Lokal', emoji: '🌦️' },
  57: { text: 'Hujan Lokal', emoji: '🌦️' },
  61: { text: 'Hujan', emoji: '🌧️' },
  63: { text: 'Hujan', emoji: '🌧️' },
  65: { text: 'Hujan', emoji: '🌧️' },
  66: { text: 'Hujan', emoji: '🌧️' },
  67: { text: 'Hujan', emoji: '🌧️' },
  71: { text: 'Hujan', emoji: '🌧️' },
  73: { text: 'Hujan', emoji: '🌧️' },
  75: { text: 'Hujan', emoji: '🌧️' },
  77: { text: 'Hujan', emoji: '🌧️' },
  80: { text: 'Hujan Lokal', emoji: '🌦️' },
  81: { text: 'Hujan', emoji: '🌧️' },
  82: { text: 'Hujan', emoji: '🌧️' },
  95: { text: 'Hujan Petir', emoji: '⛈️' },
  96: { text: 'Hujan Petir', emoji: '⛈️' },
  99: { text: 'Hujan Petir', emoji: '⛈️' }
};

function describeWeatherCode(code) {
  return WEATHER_CODE_MAP[code] || { text: 'Tidak Diketahui', emoji: '❔' };
}

function formatTemperature(celsius) {
  if (celsius === null || celsius === undefined || Number.isNaN(celsius)) return 'N/A';
  return `${Math.round(celsius)}°C`;
}

function formatHumidity(percent) {
  if (percent === null || percent === undefined || Number.isNaN(percent)) return 'N/A';
  return `${Math.round(percent)}%`;
}

const COMPASS_POINTS = ['Utara', 'Timur Laut', 'Timur', 'Tenggara', 'Selatan', 'Barat Daya', 'Barat', 'Barat Laut'];

function degreesToCompass(deg) {
  if (deg === null || deg === undefined || Number.isNaN(deg)) return null;
  const index = Math.round(deg / 45) % 8;
  return COMPASS_POINTS[index];
}

// Angin -> "12 km/j (Tenggara)"
function formatWind(speedKmh, directionDeg) {
  if (speedKmh === null || speedKmh === undefined || Number.isNaN(speedKmh)) return 'N/A';
  const dir = degreesToCompass(directionDeg);
  return `${Math.round(speedKmh)} km/j${dir ? ` (${dir})` : ''}`;
}

// "5.7" -> "5.7"
function formatMagnitude(mag) {
  if (mag === null || mag === undefined || Number.isNaN(mag)) return 'N/A';
  return `${mag}`;
}

// Klasifikasi magnitudo gempa (skala umum seismologi, label Bahasa Indonesia).
function classifyMagnitude(mag) {
  if (mag === null || mag === undefined || Number.isNaN(mag)) return 'N/A';
  if (mag < 3) return 'Mikro';
  if (mag < 4) return 'Kecil';
  if (mag < 5) return 'Ringan';
  if (mag < 6) return 'Sedang';
  if (mag < 7) return 'Kuat';
  if (mag < 8) return 'Besar';
  return 'Dahsyat';
}

function buildMapsLink(lat, lon) {
  if (lat === null || lat === undefined || lon === null || lon === undefined) return null;
  if (Number.isNaN(lat) || Number.isNaN(lon)) return null;
  return `https://www.google.com/maps?q=${lat},${lon}`;
}

module.exports = {
  describeWeatherCode,
  formatTemperature,
  formatHumidity,
  formatWind,
  degreesToCompass,
  formatMagnitude,
  classifyMagnitude,
  buildMapsLink
};
