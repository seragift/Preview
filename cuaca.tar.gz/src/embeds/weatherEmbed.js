'use strict';

const { EmbedBuilder } = require('discord.js');
const { getRegions } = require('../utils/location');
const { describeWeatherCode, formatTemperature, formatHumidity, formatWind } = require('../utils/formatter');
const { formatFooterWIB } = require('../utils/time');

/**
 * Bangun 1 embed dashboard cuaca Indonesia berisi seluruh region/kota,
 * termasuk kelembaban dan kecepatan angin setiap kota.
 * @param {Map<string,object>|null} weatherByCity
 * @param {boolean} isStale - true jika data terakhir gagal diperbarui (API down)
 */
function buildWeatherEmbed(weatherByCity, isStale = false) {
  const regions = getRegions();

  const embed = new EmbedBuilder()
    .setTitle('🇮🇩 CUACA INDONESIA')
    .setColor(isStale ? 0xe67e22 : 0x2ecc71)
    .setFooter({ text: `🔄 Diperbarui: ${formatFooterWIB()}` });

  for (const region of regions) {
    const lines = region.cities.map((city) => {
      const data = weatherByCity?.get(city.name);
      if (!data) {
        return `📍 ${city.name.padEnd(12, ' ')} ❔ N/A`;
      }
      const { text, emoji } = describeWeatherCode(data.weatherCode);
      const temp = formatTemperature(data.temperature);
      const hum = formatHumidity(data.humidity);
      const wind = data.windSpeed !== undefined && data.windSpeed !== null ? `${Math.round(data.windSpeed)}km/j` : 'N/A';
      return `📍 ${city.name.padEnd(12, ' ')} ${emoji} ${temp} 💧${hum} 💨${wind}`;
    });
    embed.addFields({
      name: `${region.emoji} ${region.name}`,
      value: lines.join('\n'),
      inline: false
    });
  }

  if (isStale) {
    embed.setDescription('⚠️ Data cuaca sedang tidak tersedia. Menampilkan data terakhir yang berhasil diambil.');
  }

  return embed;
}

/**
 * Embed detail cuaca 1 kota: kondisi saat ini, terasa seperti, kelembaban,
 * angin, dan prakiraan 3 hari ke depan.
 * @param {{name:string, region:string}} city
 * @param {{current:object, daily:object[]}} detail
 */
function buildCityWeatherDetailEmbed(city, detail) {
  const { text, emoji } = describeWeatherCode(detail.current.weatherCode);

  const embed = new EmbedBuilder()
    .setTitle(`🇮🇩 Cuaca ${city.name}`)
    .setDescription(`${emoji} **${text}** — ${formatTemperature(detail.current.temperature)}`)
    .setColor(0x3498db)
    .addFields(
      { name: 'Terasa Seperti', value: formatTemperature(detail.current.apparentTemperature), inline: true },
      { name: 'Kelembaban', value: formatHumidity(detail.current.humidity), inline: true },
      { name: 'Angin', value: formatWind(detail.current.windSpeed, detail.current.windDirection), inline: true }
    )
    .setFooter({ text: `${city.region} • Diperbarui: ${formatFooterWIB()}` });

  if (detail.daily?.length) {
    const lines = detail.daily.map((d) => {
      const dw = describeWeatherCode(d.weatherCode);
      const dateLabel = new Intl.DateTimeFormat('id-ID', {
        weekday: 'long',
        day: '2-digit',
        month: 'short',
        timeZone: 'Asia/Jakarta'
      }).format(new Date(d.date));
      return `**${dateLabel}** — ${dw.emoji} ${dw.text} • ${formatTemperature(d.tempMin)} - ${formatTemperature(d.tempMax)}`;
    });
    embed.addFields({ name: '📅 Prakiraan 3 Hari', value: lines.join('\n'), inline: false });
  }

  return embed;
}

module.exports = { buildWeatherEmbed, buildCityWeatherDetailEmbed };
