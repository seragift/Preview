'use strict';

const { EmbedBuilder } = require('discord.js');

const STATUS_LABEL = {
  WARNING: '⚠️ WARNING',
  ADVISORY: '🟠 ADVISORY',
  NORMAL: '🟢 NORMAL / BERAKHIR'
};

const STATUS_COLOR = {
  WARNING: 0xe74c3c,
  ADVISORY: 0xf39c12,
  NORMAL: 0x2ecc71
};

/**
 * Bangun embed peringatan/status tsunami (dipakai saat broadcast alert baru).
 * @param {object} alert - { status, region, jam, tanggal, source }
 */
function buildTsunamiEmbed(alert) {
  const isWarning = alert.status === 'WARNING';

  const embed = new EmbedBuilder()
    .setTitle(isWarning ? '🌊🚨 PERINGATAN TSUNAMI' : '🌊 STATUS TSUNAMI')
    .setColor(STATUS_COLOR[alert.status] || 0x95a5a6)
    .addFields(
      { name: 'Wilayah', value: alert.region || 'N/A', inline: false },
      { name: 'Status', value: STATUS_LABEL[alert.status] || alert.status, inline: true },
      { name: 'Waktu', value: alert.jam || 'N/A', inline: true }
    )
    .setFooter({ text: `Sumber: ${alert.source || 'BMKG'}` });

  if (isWarning) {
    embed.setDescription('**TERDAPAT PERINGATAN TSUNAMI**');
  }

  return embed;
}

/**
 * Embed untuk command /tsunami: status terakhir + opsional riwayat.
 * @param {object|undefined} latest - baris terbaru dari tabel tsunami_alerts
 * @param {object[]} history - baris riwayat sebelumnya (opsional)
 */
function buildTsunamiStatusEmbed(latest, history = []) {
  if (!latest) {
    return new EmbedBuilder()
      .setTitle('🌊 Status Tsunami')
      .setColor(0x95a5a6)
      .setDescription('Belum ada data status tsunami yang tercatat dari BMKG.');
  }

  const isWarning = latest.status === 'WARNING';

  const embed = new EmbedBuilder()
    .setTitle(isWarning ? '🌊🚨 PERINGATAN TSUNAMI AKTIF' : '🌊 Status Tsunami Terakhir')
    .setColor(STATUS_COLOR[latest.status] || 0x95a5a6)
    .addFields(
      { name: 'Wilayah', value: latest.region || 'N/A', inline: false },
      { name: 'Status', value: STATUS_LABEL[latest.status] || latest.status, inline: true },
      { name: 'Waktu Event', value: latest.event_time || 'N/A', inline: true },
      { name: 'Terakhir Diperbarui', value: latest.updated_at || latest.sent_at || 'N/A', inline: true }
    )
    .setFooter({ text: `Sumber: ${latest.source || 'BMKG'}` });

  if (history.length) {
    const lines = history
      .filter((h) => h.alert_id !== latest.alert_id)
      .map((h) => `${STATUS_LABEL[h.status] || h.status} — ${h.region} (${h.event_time || 'N/A'})`);
    if (lines.length) {
      embed.addFields({ name: '🗂️ Riwayat Sebelumnya', value: lines.join('\n').slice(0, 1024), inline: false });
    }
  }

  return embed;
}

module.exports = { buildTsunamiEmbed, buildTsunamiStatusEmbed };
