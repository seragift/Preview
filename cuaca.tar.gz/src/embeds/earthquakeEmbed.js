'use strict';

const { EmbedBuilder } = require('discord.js');
const { formatMagnitude, classifyMagnitude, buildMapsLink } = require('../utils/formatter');

/**
 * Bangun embed peringatan gempa dari 1 event gempa BMKG ternormalisasi.
 * @param {object} gempa - hasil normalizeGempa() dari bmkgProvider
 */
function buildEarthquakeEmbed(gempa) {
  const coordText = `${gempa.lintangRaw || gempa.latitude}, ${gempa.bujurRaw || gempa.longitude}`;
  const mapsLink = buildMapsLink(gempa.latitude, gempa.longitude);

  const embed = new EmbedBuilder()
    .setTitle('🚨 PERINGATAN GEMPA')
    .setColor(0xe74c3c)
    .addFields(
      { name: 'Magnitudo', value: `${formatMagnitude(gempa.magnitude)} (${classifyMagnitude(gempa.magnitude)})`, inline: true },
      { name: 'Kedalaman', value: gempa.depth || 'N/A', inline: true },
      { name: '\u200b', value: '\u200b', inline: true },
      { name: 'Lokasi', value: gempa.location || 'N/A', inline: false },
      { name: 'Waktu', value: `${gempa.tanggal || ''}\n${gempa.jam || ''}`, inline: true },
      { name: '📍 Koordinat', value: coordText, inline: true }
    )
    .setFooter({ text: `Sumber: ${gempa.source}` });

  if (mapsLink) {
    embed.addFields({ name: '🗺️ Peta Lokasi', value: `[Buka di Google Maps](${mapsLink})`, inline: false });
  }

  if (gempa.dirasakan) {
    embed.addFields({ name: 'Dirasakan', value: gempa.dirasakan, inline: false });
  }

  return embed;
}

/**
 * Embed daftar gempa yang dirasakan warga (skala MMI per wilayah, dari BMKG).
 * @param {object[]} list - hasil fetchFeltEarthquakes()
 */
function buildFeltEarthquakeListEmbed(list) {
  const embed = new EmbedBuilder().setTitle('📡 Gempa Dirasakan Warga (BMKG)').setColor(0xf39c12);

  if (!list || list.length === 0) {
    embed.setDescription('Tidak ada data gempa dirasakan saat ini.');
    return embed;
  }

  const lines = list.map(
    (g) =>
      `**M${formatMagnitude(g.magnitude)}** (${classifyMagnitude(g.magnitude)}) — ${g.location}\n` +
      `${g.tanggal} ${g.jam}\nDirasakan: ${g.dirasakan || 'N/A'}`
  );

  embed.setDescription(lines.join('\n\n').slice(0, 4000));
  embed.setFooter({ text: 'Sumber: BMKG' });
  return embed;
}

/**
 * Embed riwayat gempa yang pernah dikirim bot (dari SQLite).
 * @param {object[]} rows - baris dari tabel earthquake_events
 */
function buildEarthquakeHistoryEmbed(rows) {
  const embed = new EmbedBuilder().setTitle('🗂️ Riwayat Gempa Tercatat').setColor(0x3498db);

  const lines = rows.map((r) => {
    const tsunamiTag = r.tsunami_status === 'WARNING' ? ' 🌊 berpotensi tsunami' : '';
    return `**M${formatMagnitude(r.magnitude)}** (${classifyMagnitude(r.magnitude)}) — ${r.location}${tsunamiTag}\n${r.event_time || r.sent_at}`;
  });

  embed.setDescription(lines.join('\n\n').slice(0, 4000));
  embed.setFooter({ text: `Menampilkan ${rows.length} data terakhir • Sumber: BMKG` });
  return embed;
}

/**
 * Embed statistik gempa harian & mingguan (dihitung dari SQLite).
 * @param {{today:object, weekly:object, strongestToday:object|undefined}} stats
 */
function buildEarthquakeStatsEmbed(stats) {
  const embed = new EmbedBuilder().setTitle('📊 Statistik Gempa').setColor(0x9b59b6);

  embed.addFields(
    { name: 'Hari Ini', value: `${stats.today?.count || 0} gempa`, inline: true },
    { name: 'Rata-rata Magnitudo', value: stats.today?.avgMag ? stats.today.avgMag.toFixed(1) : 'N/A', inline: true },
    { name: 'Magnitudo Tertinggi', value: stats.today?.maxMag ? `${stats.today.maxMag}` : 'N/A', inline: true },
    { name: '7 Hari Terakhir', value: `${stats.weekly?.count || 0} gempa`, inline: true }
  );

  if (stats.strongestToday) {
    embed.addFields({
      name: 'Gempa Terkuat Hari Ini',
      value: `M${formatMagnitude(stats.strongestToday.magnitude)} — ${stats.strongestToday.location}`,
      inline: false
    });
  }

  embed.setFooter({ text: 'Dihitung dari data yang tercatat bot • Sumber: BMKG' });
  return embed;
}

module.exports = {
  buildEarthquakeEmbed,
  buildFeltEarthquakeListEmbed,
  buildEarthquakeHistoryEmbed,
  buildEarthquakeStatsEmbed
};
