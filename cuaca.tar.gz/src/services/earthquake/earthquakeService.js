'use strict';

const { getConnection } = require('../../../database/connection');
const logger = require('../../utils/logger');
const { buildEarthquakeEmbed } = require('../../embeds/earthquakeEmbed');

/**
 * Kirim embed gempa ke seluruh guild yang mengaktifkan earthquake_channel_id.
 * Gempa biasa TIDAK PERNAH memakai @everyone secara otomatis.
 */
async function broadcastEarthquake(client, gempa) {
  const db = getConnection();
  const guilds = db
    .prepare('SELECT guild_id, earthquake_channel_id FROM guild_settings WHERE earthquake_channel_id IS NOT NULL AND enabled = 1')
    .all();

  const embed = buildEarthquakeEmbed(gempa);

  for (const g of guilds) {
    const channel = await client.channels.fetch(g.earthquake_channel_id).catch(() => null);
    if (!channel) {
      logger.warn(`Channel gempa tidak ditemukan (guild ${g.guild_id}), menonaktifkan`);
      db.prepare("UPDATE guild_settings SET earthquake_channel_id = NULL, updated_at = datetime('now') WHERE guild_id = ?").run(g.guild_id);
      continue;
    }
    await channel.send({ embeds: [embed] }).catch((err) =>
      logger.error(`Gagal mengirim alert gempa ke guild ${g.guild_id}: ${err.message}`)
    );
  }

  db.prepare("UPDATE guild_settings SET last_earthquake_check = datetime('now')").run();
  logger.success(`Alert gempa terkirim: M${gempa.magnitude} - ${gempa.location}`);
}

function isEarthquakeAlreadySent(eventId) {
  const db = getConnection();
  const row = db.prepare('SELECT 1 FROM earthquake_events WHERE event_id = ?').get(eventId);
  return !!row;
}

function saveEarthquakeEvent(gempa, tsunamiStatus) {
  const db = getConnection();
  db.prepare(
    `INSERT OR IGNORE INTO earthquake_events
     (event_id, magnitude, location, depth, latitude, longitude, event_time, tsunami_status, source)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(
    gempa.eventId,
    gempa.magnitude,
    gempa.location,
    gempa.depth,
    gempa.latitude,
    gempa.longitude,
    gempa.dateTime,
    tsunamiStatus,
    gempa.source
  );
}

function getLatestSavedEarthquake() {
  const db = getConnection();
  return db.prepare('SELECT * FROM earthquake_events ORDER BY sent_at DESC LIMIT 1').get();
}

/**
 * Riwayat N gempa terakhir yang pernah dikirim/disimpan bot.
 */
function getEarthquakeHistory(limit = 10) {
  const db = getConnection();
  return db.prepare('SELECT * FROM earthquake_events ORDER BY sent_at DESC LIMIT ?').all(limit);
}

/**
 * Statistik gempa harian (WIB) & mingguan dari data yang tersimpan di SQLite.
 * Batas hari dihitung dengan offset +7 jam agar sesuai zona waktu WIB.
 */
function getDailyEarthquakeStats() {
  const db = getConnection();

  const today = db
    .prepare(
      `SELECT COUNT(*) as count, AVG(magnitude) as avgMag, MAX(magnitude) as maxMag
       FROM earthquake_events
       WHERE date(sent_at, '+7 hours') = date('now', '+7 hours')`
    )
    .get();

  const weekly = db
    .prepare("SELECT COUNT(*) as count FROM earthquake_events WHERE sent_at >= datetime('now', '-7 days')")
    .get();

  const strongestToday = db
    .prepare(
      `SELECT * FROM earthquake_events
       WHERE date(sent_at, '+7 hours') = date('now', '+7 hours')
       ORDER BY magnitude DESC LIMIT 1`
    )
    .get();

  return { today, weekly, strongestToday };
}

module.exports = {
  broadcastEarthquake,
  isEarthquakeAlreadySent,
  saveEarthquakeEvent,
  getLatestSavedEarthquake,
  getEarthquakeHistory,
  getDailyEarthquakeStats
};
