'use strict';

const { getConnection } = require('../../../database/connection');
const logger = require('../../utils/logger');
const { buildTsunamiEmbed } = require('../../embeds/tsunamiEmbed');

function getExistingAlert(alertId) {
  const db = getConnection();
  return db.prepare('SELECT * FROM tsunami_alerts WHERE alert_id = ?').get(alertId);
}

/**
 * Simpan alert baru, atau perbarui status jika event sudah ada tapi
 * statusnya berubah (mis. dari WARNING menjadi NORMAL/berakhir).
 * @returns {'created'|'updated'|'unchanged'}
 */
function upsertAlert(alertId, status, region, eventTime) {
  const db = getConnection();
  const existing = getExistingAlert(alertId);

  if (existing) {
    if (existing.status !== status) {
      db.prepare("UPDATE tsunami_alerts SET status = ?, updated_at = datetime('now') WHERE alert_id = ?").run(status, alertId);
      return 'updated';
    }
    return 'unchanged';
  }

  db.prepare(
    `INSERT INTO tsunami_alerts (alert_id, status, region, event_time, source)
     VALUES (?, ?, ?, ?, 'BMKG')`
  ).run(alertId, status, region, eventTime);
  return 'created';
}

/**
 * Kirim embed tsunami ke seluruh guild yang mengaktifkan tsunami_channel_id.
 * @everyone hanya dipakai untuk status WARNING resmi DAN admin mengaktifkan mention.
 */
async function broadcastTsunami(client, alert) {
  const db = getConnection();
  const guilds = db
    .prepare('SELECT guild_id, tsunami_channel_id, mention_enabled FROM guild_settings WHERE tsunami_channel_id IS NOT NULL AND enabled = 1')
    .all();

  const embed = buildTsunamiEmbed(alert);
  const isWarning = alert.status === 'WARNING';

  for (const g of guilds) {
    const channel = await client.channels.fetch(g.tsunami_channel_id).catch(() => null);
    if (!channel) {
      logger.warn(`Channel tsunami tidak ditemukan (guild ${g.guild_id}), menonaktifkan`);
      db.prepare("UPDATE guild_settings SET tsunami_channel_id = NULL, updated_at = datetime('now') WHERE guild_id = ?").run(g.guild_id);
      continue;
    }
    const content = isWarning && g.mention_enabled ? '@everyone' : undefined;
    await channel
      .send({ content, embeds: [embed] })
      .catch((err) => logger.error(`Gagal mengirim alert tsunami ke guild ${g.guild_id}: ${err.message}`));
  }

  db.prepare("UPDATE guild_settings SET last_tsunami_check = datetime('now')").run();
}

function getLatestTsunamiAlert() {
  const db = getConnection();
  return db.prepare('SELECT * FROM tsunami_alerts ORDER BY sent_at DESC LIMIT 1').get();
}

function getTsunamiHistory(limit = 5) {
  const db = getConnection();
  return db.prepare('SELECT * FROM tsunami_alerts ORDER BY sent_at DESC LIMIT ?').all(limit);
}

module.exports = {
  getExistingAlert,
  upsertAlert,
  broadcastTsunami,
  getLatestTsunamiAlert,
  getTsunamiHistory
};
