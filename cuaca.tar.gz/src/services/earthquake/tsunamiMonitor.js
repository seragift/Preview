'use strict';

const logger = require('../../utils/logger');
const { fetchRecentEarthquakes, deriveTsunamiStatus } = require('../../providers/bmkgProvider');
const { upsertAlert, broadcastTsunami } = require('./tsunamiService');

let pollTimer = null;
let isPolling = false;

async function pollOnce(client) {
  if (isPolling) return;
  isPolling = true;
  try {
    const quakes = await fetchRecentEarthquakes();
    const chronological = [...quakes].reverse();

    for (const gempa of chronological) {
      const status = deriveTsunamiStatus(gempa.potensi);
      // Hanya proses jika BMKG secara eksplisit menyatakan status (WARNING/NORMAL).
      // Tidak pernah menyimpulkan dari magnitudo semata.
      if (!status) continue;

      const alertId = gempa.eventId;
      const result = upsertAlert(alertId, status, gempa.location, gempa.dateTime);

      if (result === 'created' && status === 'WARNING') {
        logger.warn(`Peringatan tsunami baru terdeteksi: ${gempa.location}`);
        await broadcastTsunami(client, { status, region: gempa.location, jam: gempa.jam, source: 'BMKG' });
      } else if (result === 'updated') {
        logger.info(`Status tsunami diperbarui menjadi ${status}: ${gempa.location}`);
        await broadcastTsunami(client, { status, region: gempa.location, jam: gempa.jam, source: 'BMKG' });
      }
    }
  } catch (err) {
    logger.error(`Gagal polling status tsunami BMKG: ${err.message}`);
  } finally {
    isPolling = false;
  }
}

function startTsunamiMonitor(client) {
  const baseInterval = parseInt(process.env.TSUNAMI_INTERVAL, 10) || 60000;

  if (pollTimer) clearInterval(pollTimer);
  pollOnce(client);
  pollTimer = setInterval(() => pollOnce(client), baseInterval);

  logger.success(`Tsunami monitor berjalan (interval ${baseInterval}ms)`);
}

function stopTsunamiMonitor() {
  if (pollTimer) clearInterval(pollTimer);
  pollTimer = null;
}

module.exports = { startTsunamiMonitor, stopTsunamiMonitor, pollOnce };
