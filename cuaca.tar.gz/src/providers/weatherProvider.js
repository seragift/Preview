'use strict';

const axios = require('axios');
const logger = require('../utils/logger');
const { getAllCitiesFlat } = require('../utils/location');

// Provider cuaca: Open-Meteo (https://open-meteo.com) - gratis, tanpa API key,
// mendukung koordinat lintang/bujur kota-kota Indonesia secara langsung.
const BASE_URL = 'https://api.open-meteo.com/v1/forecast';
const TIMEOUT_MS = 10000;

const CURRENT_PARAMS = [
  'temperature_2m',
  'relative_humidity_2m',
  'apparent_temperature',
  'weathercode',
  'wind_speed_10m',
  'wind_direction_10m'
].join(',');

const DAILY_PARAMS = ['weathercode', 'temperature_2m_max', 'temperature_2m_min'].join(',');

function mapCurrent(current) {
  if (!current) return null;
  return {
    temperature: current.temperature_2m,
    apparentTemperature: current.apparent_temperature,
    humidity: current.relative_humidity_2m,
    windSpeed: current.wind_speed_10m,
    windDirection: current.wind_direction_10m,
    weatherCode: current.weathercode
  };
}

/**
 * Ambil cuaca terkini (suhu, kelembaban, angin, kondisi) untuk seluruh kota
 * sekaligus (1 request HTTP, memakai parameter latitude/longitude yang
 * dipisah koma - fitur multi-location resmi dari Open-Meteo).
 * @returns {Promise<Map<string, object>>}
 */
async function fetchAllCitiesWeather() {
  const cities = getAllCitiesFlat();
  const latitudes = cities.map((c) => c.lat).join(',');
  const longitudes = cities.map((c) => c.lon).join(',');

  const response = await axios.get(BASE_URL, {
    params: {
      latitude: latitudes,
      longitude: longitudes,
      current: CURRENT_PARAMS,
      timezone: 'Asia/Jakarta'
    },
    timeout: TIMEOUT_MS
  });

  const data = response.data;
  const results = Array.isArray(data) ? data : [data];

  if (results.length !== cities.length) {
    throw new Error(
      `Jumlah hasil cuaca (${results.length}) tidak sesuai jumlah kota (${cities.length})`
    );
  }

  const weatherByCity = new Map();
  results.forEach((entry, index) => {
    const city = cities[index];
    const current = mapCurrent(entry.current);
    if (!current) {
      logger.warn(`Data cuaca tidak lengkap untuk kota ${city.name}`);
      return;
    }
    weatherByCity.set(city.name, current);
  });

  return weatherByCity;
}

/**
 * Ambil cuaca terkini + prakiraan 3 hari untuk 1 kota spesifik.
 * @param {{name:string, lat:number, lon:number}} city
 */
async function fetchCityWeatherDetail(city) {
  const response = await axios.get(BASE_URL, {
    params: {
      latitude: city.lat,
      longitude: city.lon,
      current: CURRENT_PARAMS,
      daily: DAILY_PARAMS,
      forecast_days: 3,
      timezone: 'Asia/Jakarta'
    },
    timeout: TIMEOUT_MS
  });

  const data = response.data;
  const current = mapCurrent(data.current);
  if (!current) throw new Error('Data cuaca kota tidak lengkap dari Open-Meteo');

  const daily = (data.daily?.time || []).map((date, i) => ({
    date,
    weatherCode: data.daily.weathercode[i],
    tempMax: data.daily.temperature_2m_max[i],
    tempMin: data.daily.temperature_2m_min[i]
  }));

  return { current, daily };
}

module.exports = { fetchAllCitiesWeather, fetchCityWeatherDetail };
