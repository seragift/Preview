# 🌏 LivePulse Indonesia

Discord Bot informasi **Cuaca**, **Gempa Bumi**, dan **Tsunami** untuk Indonesia.

- Cuaca: [Open-Meteo](https://open-meteo.com) (gratis, tanpa API key)
- Gempa & Tsunami: [Data Gempabumi Terbuka BMKG](https://data.bmkg.go.id/gempabumi)

## Catatan penting soal data

- **Gempa** memakai endpoint resmi BMKG `autogempa.json` (event terbaru) dan
  `gempaterkini.json` (15 gempa M5.0+ terakhir) untuk polling & deduplikasi.
  BMKG tidak menyediakan field `id` eksplisit, jadi bot memakai `DateTime`
  (unik per event) sebagai `event_id`.
- **Tsunami**: data terbuka BMKG hanya menyediakan field `Potensi` per event
  gempa, berisi `"Tidak berpotensi tsunami"` atau `"Berpotensi tsunami ..."`.
  Bot memetakan ini menjadi status `NORMAL` / `WARNING`. Status `ADVISORY`
  **tidak dikarang** oleh bot karena tidak tersedia pada feed publik BMKG —
  slot ini disediakan pada embed/enum untuk kompatibilitas masa depan jika
  BMKG merilis feed yang lebih detail.
- **Cuaca** memakai Open-Meteo karena mendukung koordinat kota Indonesia
  langsung tanpa perlu API key/pendaftaran. Kolom `WEATHER_API_KEY` di `.env`
  tetap disediakan untuk kompatibilitas jika kamu ingin mengganti provider.
- **Gempa Dirasakan** (`/earthquake dirasakan`) memakai endpoint resmi BMKG
  `gempadirasakan.json`, berisi intensitas guncangan dalam skala MMI per
  wilayah persis seperti yang dirilis BMKG.
- **Klasifikasi magnitudo** (Mikro/Kecil/Ringan/Sedang/Kuat/Besar/Dahsyat)
  adalah label deskriptif berdasarkan skala magnitudo umum — bukan data dari
  BMKG, murni bantu pembacaan cepat di embed.

## Fitur

1. 🇮🇩 Dashboard cuaca 1 embed (auto-edit, tidak spam pesan baru) — suhu, kondisi, **kelembaban, dan kecepatan/arah angin** tiap kota
2. 🌤️ `/weather kota:<nama>` — cuaca detail 1 kota: suhu terasa, kelembaban, angin, **prakiraan 3 hari** (dengan autocomplete nama kota)
3. 🚨 Alert gempa bumi real-time dari BMKG dengan deduplikasi SQLite, **klasifikasi magnitudo**, dan **link Google Maps** lokasi
4. 📡 `/earthquake dirasakan` — daftar gempa yang dirasakan warga (skala MMI, sumber BMKG)
5. 🗂️ `/earthquake riwayat` — riwayat gempa yang pernah dikirim bot
6. 📊 `/earthquake statistik` — jumlah gempa hari ini, rata-rata & magnitudo tertinggi, total 7 hari terakhir
7. 🌊 `/tsunami [riwayat:true]` — status tsunami terakhir + riwayat peringatan sebelumnya, resmi dari BMKG (tidak pernah disimpulkan dari magnitudo)
8. Konfigurasi channel & interval per server (multi-guild) via `/setup`
9. `/status` menampilkan uptime, status tiap sistem, dan jumlah gempa hari ini
10. PM2 ready untuk production, auto-restart saat crash

## Struktur Project

```
livepulse/
├── index.js                 # Entry point bot
├── deploy.js                 # Deploy slash command
├── ecosystem.config.js       # Konfigurasi PM2
├── package.json
├── .env.example
├── database/
│   ├── database.sqlite        # dibuat otomatis saat pertama jalan
│   ├── connection.js
│   └── schema.sql
├── data/
│   └── indonesia-cities.json
└── src/
    ├── commands/     (weather, earthquake, setup, status)
    ├── services/
    │   ├── weather/  (weatherService, weatherUpdater)
    │   └── earthquake/ (earthquakeService, earthquakeMonitor, tsunamiMonitor)
    ├── providers/    (weatherProvider = Open-Meteo, bmkgProvider = BMKG)
    ├── embeds/       (weatherEmbed, earthquakeEmbed, tsunamiEmbed)
    ├── events/       (ready, interactionCreate)
    └── utils/        (logger, time, formatter, location)
```

## 1. Instalasi

```bash
git clone <repo-kamu> livepulse
cd livepulse
npm install
```

> Catatan: `better-sqlite3` memakai native binding, pastikan Node.js 20+ dan
> toolchain build (`python3`, `make`, `g++`) tersedia di server jika perlu
> compile dari source (biasanya sudah tersedia prebuilt binary).

## 2. Konfigurasi Bot Discord

1. Buka [Discord Developer Portal](https://discord.com/developers/applications) → **New Application**.
2. Masuk ke tab **Bot** → **Reset Token** → salin token.
3. Di tab **OAuth2 → General**, salin **Application (Client) ID**.
4. Undang bot ke server dengan scope `bot applications.commands` dan permission
   minimal: `Send Messages`, `Embed Links`, `Read Message History`, `Mention Everyone` (jika ingin memakai fitur mention tsunami).
5. Salin `.env.example` menjadi `.env` dan isi:

```bash
cp .env.example .env
```

```env
DISCORD_TOKEN=isi_token_bot_kamu
CLIENT_ID=isi_application_id
GUILD_ID=isi_id_server_untuk_development   # kosongkan untuk deploy global

WEATHER_API_KEY=

WEATHER_INTERVAL=1800000
EARTHQUAKE_INTERVAL=60000
TSUNAMI_INTERVAL=60000

TIMEZONE=Asia/Jakarta
```

> **Jangan pernah** commit file `.env` ke Git — sudah termasuk di `.gitignore`.

## 3. Deploy Slash Command

```bash
node deploy.js
```

- Jika `GUILD_ID` diisi → command langsung aktif di server tersebut (instan, cocok untuk development).
- Jika `GUILD_ID` dikosongkan → command di-deploy global (propagasi hingga ~1 jam).

## 4. Menjalankan dengan PM2 (Production)

```bash
npm install -g pm2      # jika belum terpasang
pm2 start ecosystem.config.js
pm2 save
pm2 startup             # opsional: auto-start saat server reboot
```

Perintah PM2 lainnya:

```bash
pm2 logs livepulse-indonesia   # lihat log real-time
pm2 restart livepulse-indonesia
pm2 stop livepulse-indonesia
```

## 5. Menjalankan Manual (Development)

```bash
node index.js
```

## 6. Konfigurasi di Discord (setelah bot online)

Jalankan sebagai admin server (butuh permission **Manage Server**):

```
/setup weather channel:#cuaca-indonesia
/setup earthquake channel:#info-gempa
/setup tsunami channel:#peringatan-tsunami
/setup interval tipe:weather menit:30
/setup interval tipe:earthquake menit:1
/setup interval tipe:tsunami menit:1
/setup mention aktif:true
/setup toggle aktif:true
```

Setelah channel weather diatur, dashboard cuaca otomatis dibuat dan akan
di-edit secara berkala (bukan mengirim pesan baru).

## 7. Daftar Command

| Command                        | Deskripsi                                              |
|---------------------------------|---------------------------------------------------------|
| `/weather`                      | Dashboard cuaca lengkap semua kota                       |
| `/weather kota:<nama>`          | Cuaca detail 1 kota + prakiraan 3 hari (autocomplete)    |
| `/earthquake terbaru`           | Gempa terbaru dari BMKG                                  |
| `/earthquake riwayat [jumlah]`  | Riwayat gempa yang pernah dikirim bot (maks 25)          |
| `/earthquake dirasakan`         | Daftar gempa yang dirasakan warga (BMKG)                 |
| `/earthquake statistik`         | Statistik gempa harian & mingguan                        |
| `/tsunami [riwayat:true]`       | Status tsunami terakhir, opsional riwayat sebelumnya     |
| `/setup ...`                    | Konfigurasi channel/interval/mention (khusus admin)      |
| `/status`                       | Status bot, uptime, dan jumlah gempa hari ini            |

> Catatan: `/earthquake` sekarang memakai subcommand (`terbaru`, `riwayat`,
> `dirasakan`, `statistik`) — jalankan `node deploy.js` ulang setelah update
> agar Discord memuat ulang struktur command yang baru.

## Troubleshooting

- **Dashboard cuaca hilang/terhapus** → bot otomatis membuat dashboard baru
  dan menyimpan `message_id` baru ke database saat interval berikutnya berjalan.
- **Channel dihapus** → bot menonaktifkan konfigurasi channel terkait secara
  otomatis tanpa crash (dicatat di log `[WARN]`).
- **API BMKG/Open-Meteo down** → bot mempertahankan data terakhir yang berhasil
  diambil dan menandai dashboard sebagai data lama (warna oranye + keterangan).
- Semua error dicetak dengan prefix `[ERROR]` di log PM2 (`pm2 logs`), token/API key tidak pernah dicetak.
