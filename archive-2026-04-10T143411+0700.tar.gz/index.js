const { Client, GatewayIntentBits, Collection, REST, Routes } = require('discord.js');

const fs = require('fs');

const config = require('./config.json');

const client = new Client({

  intents: [

    GatewayIntentBits.Guilds,
      
      GatewayIntentBits.GuildMembers,

    GatewayIntentBits.GuildMessages,

    GatewayIntentBits.MessageContent

  ]

});

client.commands = new Collection();

const commands = [];

// Load Commands

const commandFiles = fs.readdirSync('./command').filter(file => file.endsWith('.js'));

for (const file of commandFiles) {

  const command = require(`./command/${file}`);

  client.commands.set(command.data.name, command);

  commands.push(command.data.toJSON());

}

// Register Slash Commands

const rest = new REST({ version: '10' }).setToken(config.token);

(async () => {

  try {

    await rest.put(Routes.applicationGuildCommands(config.clientId, config.guildId), { body: commands });

    console.log('Slash Commands Berhasil didaftarkan.');

  } catch (error) {

    console.error(error);

  }

})();

// Load Events

const eventFiles = fs.readdirSync('./events').filter(file => file.endsWith('.js'));

for (const file of eventFiles) {

  const event = require(`./events/${file}`);

  if (event.once) {

    client.once(event.name, (...args) => event.execute(...args));

  } else {

    client.on(event.name, (...args) => event.execute(...args));

  }

}

client.login(config.token);