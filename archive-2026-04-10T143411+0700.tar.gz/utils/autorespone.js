const { EmbedBuilder } = require('discord.js');

const config = require('../config.json');

module.exports = async (message) => {

    // 1. Cek apakah pesan menyebutkan Owner (tag)

    // 2. Cek apakah pesan tersebut BUKAN merupakan reply (message.reference == null)

    if (message.mentions.users.has(config.ownerId) && !message.reference) {

        

        const guildMember = await message.guild.members.fetch(config.ownerId).catch(() => null);

        // Cek status owner (Offline atau Invisible)

        if (!guildMember || !guildMember.presence || guildMember.presence.status === 'offline') {

            

            const embed = new EmbedBuilder()

                .setTitle('Auto Response | Status Owner')

                .setDescription('Saat ini Tuan saya sedang offline atau beristirahat. Silakan tunggu hingga tuan kembali online.')

                .setColor('Blue')

                .setThumbnail(message.client.user.displayAvatarURL())

                .setFooter({ 

                    text: message.client.user.username, 

                    iconURL: message.client.user.displayAvatarURL() 

                })

                .setTimestamp();

            return message.reply({ embeds: [embed] });

        }

    }

};