const db = require('../database/database');

const isLink = require('./antiLink');

const isToxic = require('./antiToxic');

const autoResponse = require('./autorespone');

const translate = require('google-translate-api-x');

const sendLog = require('./logger');

module.exports = async (message) => {

  if (message.author.bot || !message.guild) return;

  // --- 1. FITUR TRANSLATE ID & EN VIA REPLY ---

  const input = message.content.toLowerCase();

  

  if ((input === 'id' || input === 'en') && message.reference) {

    try {

      const referencedMessage = await message.channel.messages.fetch(message.reference.messageId);

      

      if (referencedMessage.content) {

        const res = await translate(referencedMessage.content, { to: input });

        

        await message.delete().catch(() => {});

        const langName = input === 'id' ? 'Indonesia' : 'Inggris';

        

        return message.channel.send({

          content: `**Terjemahan (${langName}):**\n${res.text}\n*- Oleh: ${message.author}*`,

          allowedMentions: { parse: [] } 

        });

      }

    } catch (err) {

      console.error('Translate Error:', err);

    }

  }

  // --- 2. AUTO RESPONSE OWNER ---

  await autoResponse(message);

  // --- 3. LOGIKA MODERASI ---

  const whitelisted = db.prepare('SELECT channelId FROM whitelist WHERE channelId = ?').get(message.channel.id);

  if (whitelisted) return;

  const settings = db.prepare('SELECT * FROM settings WHERE guildId = ?').get(message.guild.id);

  if (!settings) return;

  // Anti-Link

  if (settings.antiLink === 1 && isLink(message)) {

    if (message.deletable) {

      await sendLog(message, 'LINK', 'Mengirim link terlarang');

      await message.delete().catch(() => {});

      return message.channel.send(`⚠️ ${message.author}, dilarang mengirim link!`)

        .then(m => setTimeout(() => m.delete(), 3000));

    }

  }

  // Anti-Toxic

  if (settings.antiToxic === 1 && isToxic(message)) {

    if (message.deletable) {

      await sendLog(message, 'TOXIC', 'Berkata kasar');

      await message.delete().catch(() => {});

      return message.channel.send(`🤬 ${message.author}, jaga ketikan anda!`)

        .then(m => setTimeout(() => m.delete(), 3000));

    }

  }

};