const { EmbedBuilder } = require('discord.js');

const db = require('../database/database');

module.exports = async (message, type, reason) => {

  const settings = db.prepare('SELECT logChannel FROM settings WHERE guildId = ?').get(message.guild.id);

  if (!settings || !settings.logChannel) return;

  const logChannel = message.guild.channels.cache.get(settings.logChannel);

  if (!logChannel) return;

  const embed = new EmbedBuilder()

    .setTitle('🛡️ Moderasi Log')

    .setColor(type === 'LINK' ? 'Yellow' : 'Red')

    .addFields(

      { name: '👤 User', value: `${message.author.tag} (${message.author.id})`, inline: true },

      { name: '📍 Channel', value: `<#${message.channel.id}>`, inline: true },

      { name: '📝 Pelanggaran', value: type, inline: true },

      { name: '💬 Isi Pesan', value: `\`\`\`${message.content.slice(0, 1024)}\`\`\`` }

    )

    .setTimestamp()

    .setFooter({ text: 'Sistem Keamanan Bot' });

  logChannel.send({ embeds: [embed] }).catch(() => {});

};