const badWords = ['anjing', 'bangsat', 'tolol', 'goblok', 'memek', 'kontol', 'babi', 'anying', 'bego', 'monyet', 'bokep', 'okep', 'setan', 'ngtd', 'peler', 'yatim', 'ytim', 'cipok', 'bajingan', 'mek', 'kntl', 'peler', 'plr', 'memeq', 'meq']; // Tambahkan list kata kasar di sini

module.exports = (message) => {

  return badWords.some(word => message.content.toLowerCase().includes(word));

};