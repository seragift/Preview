const db = require('../database/database');

module.exports = {

  recordMessage: (message) => {

    const date = new Date().toISOString().split('T')[0];

    const hour = new Date().getHours();

    try {

      db.prepare(`

        INSERT INTO daily_stats (guildId, userId, channelId, messageCount, hour, date)

        VALUES (?, ?, ?, 1, ?, ?)

        ON CONFLICT(guildId, userId, channelId, hour, date) 

        DO UPDATE SET messageCount = daily_stats.messageCount + 1

      `).run(message.guild.id, message.author.id, message.channel.id, hour, date);

    } catch (err) {

      console.error('Error recording message stats:', err);

    }

  }

};