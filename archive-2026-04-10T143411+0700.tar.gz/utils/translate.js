const translate = require('google-translate-api-x');

module.exports = async (message) => {

  const input = message.content.toLowerCase();

  // Hanya proses jika input adalah 'id' atau 'en' dan membalas (reply) pesan

  if ((input === 'id' || input === 'en') && message.reference) {

    try {

      const referencedMessage = await message.channel.messages.fetch(message.reference.messageId);

      

      if (referencedMessage.content) {

        const res = await translate(referencedMessage.content, { to: input });

        

        // Hapus pesan pemicu (id/en) agar chat tetap bersih

        await message.delete().catch(() => {});

        const langName = input === 'id' ? 'Indonesia' : 'Inggris';

        return message.channel.send({

          content: `**Terjemahan (${langName}):**\n${res.text}\n*- Oleh: ${message.author}*`,

          allowedMentions: { parse: [] } 

        });

      }

    } catch (err) {

      console.error('Translate Error:', err);

    }

  }

};