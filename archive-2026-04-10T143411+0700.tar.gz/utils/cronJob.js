const cron = require('node-cron');

const { EmbedBuilder } = require('discord.js');

const db = require('../database/database');

module.exports = (client) => {

  // =============================

  // 1. LAPORAN STATISTIK HARIAN

  // =============================

  cron.schedule('0 0 * * *', async () => {

    try {

      const jakartaTime = new Date().toLocaleString("en-US", { timeZone: "Asia/Jakarta" });

      const yesterday = new Date(jakartaTime);

      yesterday.setDate(yesterday.getDate() - 1);

      const dateStr = yesterday.toLocaleDateString('en-CA');

      const guilds = client.guilds.cache;

      for (const [guildId, guild] of guilds) {

        const settings = db.prepare('SELECT logChannel FROM settings WHERE guildId = ?').get(guildId);

        if (!settings || !settings.logChannel) continue;

        const logChannel = await guild.channels.fetch(settings.logChannel).catch(() => null);

        if (!logChannel) continue;

        const joins = db.prepare(

          "SELECT COUNT(*) as count FROM server_events WHERE guildId = ? AND type = 'JOIN' AND date = ?"

        ).get(guildId, dateStr)?.count || 0;

        const outs = db.prepare(

          "SELECT COUNT(*) as count FROM server_events WHERE guildId = ? AND type = 'OUT' AND date = ?"

        ).get(guildId, dateStr)?.count || 0;

        const totalMsgs = db.prepare(

          'SELECT SUM(messageCount) as total FROM daily_stats WHERE guildId = ? AND date = ?'

        ).get(guildId, dateStr)?.total || 0;

        const topMembers = db.prepare(`

          SELECT userId, SUM(messageCount) as count 

          FROM daily_stats 

          WHERE guildId = ? AND date = ? 

          GROUP BY userId 

          ORDER BY count DESC 

          LIMIT 3

        `).all(guildId, dateStr);

        const topChannel = db.prepare(`

          SELECT channelId, SUM(messageCount) as count 

          FROM daily_stats 

          WHERE guildId = ? AND date = ? 

          GROUP BY channelId 

          ORDER BY count DESC 

          LIMIT 1

        `).get(guildId, dateStr);

        const topHour = db.prepare(`

          SELECT hour, SUM(messageCount) as count 

          FROM daily_stats 

          WHERE guildId = ? AND date = ? 

          GROUP BY hour 

          ORDER BY count DESC 

          LIMIT 1

        `).get(guildId, dateStr);

        const embed = new EmbedBuilder()

          .setTitle(`📊 Laporan Statistik Harian (${dateStr})`)

          .setColor('#2ecc71')

          .setThumbnail(guild.iconURL())

          .addFields(

            {

              name: '👥 Update Member',

              value: `📈 Join: **${joins}**\n📉 Out: **${outs}**\n📊 Net: **${joins - outs}**`,

              inline: true

            },

            {

              name: '💬 Total Aktivitas',

              value: `**${totalMsgs.toLocaleString()}** Pesan`,

              inline: true

            },

            {

              name: '📢 Channel Teraktif',

              value: topChannel ? `<#${topChannel.channelId}> (${topChannel.count} chat)` : '`-`',

              inline: true

            },

            {

              name: '🏆 Top 3 Member Aktif',

              value: topMembers.length > 0

                ? topMembers.map((m, i) => `**${i+1}.** <@${m.userId}> — ${m.count} chat`).join('\n')

                : '*Tidak ada aktivitas chat*',

              inline: false

            },

            {

              name: '⏰ Jam Teraktif',

              value: topHour ? `Pukul ${topHour.hour}:00 (${topHour.count} pesan)` : '`-`',

              inline: false

            }

          )

          .setFooter({ text: 'Laporan Otomatis 00:00 WIB • Echo Lounge' })

          .setTimestamp();

        await logChannel.send({ embeds: [embed] }).catch(() => {});

      }

    } catch (error) {

      console.error('❌ Error Laporan Harian:', error);

    }

  }, {

    scheduled: true,

    timezone: "Asia/Jakarta"

  });

  // =============================

  // 2. LAPORAN STATISTIK MINGGUAN

  // =============================

  cron.schedule('0 0 * * 0', async () => {

    try {

      const jakartaTime = new Date().toLocaleString("en-US", { timeZone: "Asia/Jakarta" });

      const endDate = new Date(jakartaTime);

      const startDate = new Date(jakartaTime);

      startDate.setDate(startDate.getDate() - 7);

      const endStr = endDate.toLocaleDateString('en-CA');

      const startStr = startDate.toLocaleDateString('en-CA');

      const guilds = client.guilds.cache;

      for (const [guildId, guild] of guilds) {

        const settings = db.prepare('SELECT logChannel FROM settings WHERE guildId = ?').get(guildId);

        if (!settings || !settings.logChannel) continue;

        const logChannel = await guild.channels.fetch(settings.logChannel).catch(() => null);

        if (!logChannel) continue;

        const joins = db.prepare(`

          SELECT COUNT(*) as count 

          FROM server_events 

          WHERE guildId = ? 

          AND type = 'JOIN'

          AND date BETWEEN ? AND ?

        `).get(guildId, startStr, endStr)?.count || 0;

        const outs = db.prepare(`

          SELECT COUNT(*) as count 

          FROM server_events 

          WHERE guildId = ? 

          AND type = 'OUT'

          AND date BETWEEN ? AND ?

        `).get(guildId, startStr, endStr)?.count || 0;

        const totalMsgs = db.prepare(`

          SELECT SUM(messageCount) as total 

          FROM daily_stats 

          WHERE guildId = ?

          AND date BETWEEN ? AND ?

        `).get(guildId, startStr, endStr)?.total || 0;

        const topMembers = db.prepare(`

          SELECT userId, SUM(messageCount) as count

          FROM daily_stats

          WHERE guildId = ?

          AND date BETWEEN ? AND ?

          GROUP BY userId

          ORDER BY count DESC

          LIMIT 3

        `).all(guildId, startStr, endStr);

        const topChannel = db.prepare(`

          SELECT channelId, SUM(messageCount) as count

          FROM daily_stats

          WHERE guildId = ?

          AND date BETWEEN ? AND ?

          GROUP BY channelId

          ORDER BY count DESC

          LIMIT 1

        `).get(guildId, startStr, endStr);

        const topHour = db.prepare(`

          SELECT hour, SUM(messageCount) as count

          FROM daily_stats

          WHERE guildId = ?

          AND date BETWEEN ? AND ?

          GROUP BY hour

          ORDER BY count DESC

          LIMIT 1

        `).get(guildId, startStr, endStr);

        const embed = new EmbedBuilder()

          .setTitle(`📊 Laporan Statistik Mingguan (${startStr} - ${endStr})`)

          .setColor('#2ecc71')

          .setThumbnail(guild.iconURL())

          .addFields(

            {

              name: '👥 Update Member',

              value: `📈 Join: **${joins}**\n📉 Out: **${outs}**\n📊 Net: **${joins - outs}**`,

              inline: true

            },

            {

              name: '💬 Total Aktivitas',

              value: `**${(totalMsgs || 0).toLocaleString()}** Pesan`,

              inline: true

            },

            {

              name: '📢 Channel Teraktif',

              value: topChannel ? `<#${topChannel.channelId}> (${topChannel.count} chat)` : '`-`',

              inline: true

            },

            {

              name: '🏆 Top 3 Member Aktif',

              value: topMembers.length > 0

                ? topMembers.map((m, i) => `**${i+1}.** <@${m.userId}> — ${m.count} chat`).join('\n')

                : '*Tidak ada aktivitas chat*',

              inline: false

            },

            {

              name: '⏰ Jam Teraktif',

              value: topHour ? `Pukul ${topHour.hour}:00 (${topHour.count} pesan)` : '`-`',

              inline: false

            }

          )

          .setFooter({ text: 'Laporan Mingguan Otomatis • Echo Lounge' })

          .setTimestamp();

        await logChannel.send({ embeds: [embed] }).catch(() => {});

      }

    } catch (error) {

      console.error('❌ Error Laporan Mingguan:', error);

    }

  }, {

    scheduled: true,

    timezone: "Asia/Jakarta"

  });

  // =============================

  // 3. ROLE TIMER CHECK

  // =============================

  cron.schedule('0 * * * *', async () => {

    try {

      const now = Date.now();

      const expiredRoles = db.prepare('SELECT * FROM role_timer WHERE endTime <= ?').all(now);

      for (const data of expiredRoles) {

        const guild = client.guilds.cache.get(data.guildId);

        if (!guild) continue;

        try {

          const member = await guild.members.fetch(data.userId).catch(() => null);

          if (member) {

            await member.roles.remove(data.roleId).catch(() => null);

          }

          db.prepare(`

            DELETE FROM role_timer 

            WHERE guildId = ? 

            AND userId = ? 

            AND roleId = ?

          `).run(data.guildId, data.userId, data.roleId);

        } catch (err) {

          console.error('Gagal mencabut role:', err);

        }

      }

    } catch (error) {

      console.error('❌ Error Role Timer Job:', error);

    }

  }, {

    scheduled: true,

    timezone: "Asia/Jakarta"

  });

};