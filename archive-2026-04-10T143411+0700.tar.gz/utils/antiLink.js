module.exports = (message) => {

  const linkRegex = /(https?:\/\/[^\s]+)/g;

  return linkRegex.test(message.content);

};