const {
  SlashCommandBuilder,
  PermissionFlagsBits
} = require('discord.js');

// 🎨 FULL COLOR MAPPING (bisa lu tambah sendiri nanti)
const colorMap = {
  RED: '#ff0000',
  DARK_RED: '#8b0000',

  BLUE: '#0000ff',
  DARK_BLUE: '#00008b',

  GREEN: '#00ff00',
  DARK_GREEN: '#006400',

  YELLOW: '#ffff00',
  GOLD: '#ffd700',

  ORANGE: '#ffa500',

  PURPLE: '#800080',
  DARK_PURPLE: '#4b0082',

  FUCHSIA: '#ff00ff',
  PINK: '#ffc0cb',

  WHITE: '#ffffff',
  BLACK: '#000000',

  GREY: '#808080',
  DARK_GREY: '#2f2f2f',

  AQUA: '#00ffff',
  NAVY: '#000080'
};

module.exports = {
  data: new SlashCommandBuilder()
    .setName('createrole')
    .setDescription('Membuat role dengan warna preset')
    
    .addStringOption(option =>
      option.setName('nama')
        .setDescription('Nama role')
        .setRequired(true))

    .addStringOption(option =>
      option.setName('warna')
        .setDescription('Pilih warna role')
        .setRequired(true)
        .addChoices(
          { name: 'Merah', value: 'RED' },
          { name: 'Merah Tua', value: 'DARK_RED' },

          { name: 'Biru', value: 'BLUE' },
          { name: 'Biru Tua', value: 'DARK_BLUE' },

          { name: 'Hijau', value: 'GREEN' },
          { name: 'Hijau Tua', value: 'DARK_GREEN' },

          { name: 'Kuning', value: 'YELLOW' },
          { name: 'Emas', value: 'GOLD' },

          { name: 'Oranye', value: 'ORANGE' },

          { name: 'Ungu', value: 'PURPLE' },
          { name: 'Ungu Tua', value: 'DARK_PURPLE' },

          { name: 'Pink', value: 'PINK' },
          { name: 'Fuchsia', value: 'FUCHSIA' },

          { name: 'Putih', value: 'WHITE' },
          { name: 'Hitam', value: 'BLACK' },

          { name: 'Abu-abu', value: 'GREY' },
          { name: 'Abu-abu Tua', value: 'DARK_GREY' },

          { name: 'Aqua', value: 'AQUA' },
          { name: 'Navy', value: 'NAVY' }
        ))

    .addStringOption(option =>
      option.setName('emoji')
        .setDescription('Emoji role (opsional)')
        .setRequired(false))

    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    const nama = interaction.options.getString('nama');
    const warna = interaction.options.getString('warna');
    const emoji = interaction.options.getString('emoji');

    // 🔒 Double check admin
    if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
      return interaction.reply({
        content: '❌ Hanya Administrator yang bisa pakai command ini!',
        ephemeral: true
      });
    }

    // 🎨 Ambil warna dari mapping
    const colorFinal = colorMap[warna];

    if (!colorFinal) {
      return interaction.reply({
        content: '❌ Warna tidak valid!',
        ephemeral: true
      });
    }

    try {
      const role = await interaction.guild.roles.create({
        name: nama,
        color: colorFinal,
        reason: `Role dibuat oleh ${interaction.user.tag}`
      });

      // 🎭 Set icon kalau ada
      if (emoji) {
        try {
          await role.setIcon(emoji);
        } catch {
          console.log('Server tidak support role icon');
        }
      }

      return interaction.reply({
        content: `✅ Role berhasil dibuat: <@&${role.id}> (${colorFinal})`,
      });

    } catch (err) {
      console.error(err);
      return interaction.reply({
        content: '❌ Gagal membuat role!',
        ephemeral: true
      });
    }
  }
};