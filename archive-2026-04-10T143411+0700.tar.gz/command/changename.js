const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {

  data: new SlashCommandBuilder()

    .setName('changename')

    .setDescription('Mengganti nama panggilan (nickname) member')

    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)

    .addUserOption(option => 

      option.setName('target')

        .setDescription('Member yang ingin diganti namanya')

        .setRequired(true))

    .addStringOption(option => 

      option.setName('nama_baru')

        .setDescription('Nama panggilan baru (maksimal 32 karakter)')

        .setRequired(true)

        .setMaxLength(32)),

  async execute(interaction) {

    const target = interaction.options.getMember('target');

    const newName = interaction.options.getString('nama_baru');

    // Cek apakah target ada di server

    if (!target) {

      return interaction.reply({ content: '❌ Member tidak ditemukan di server ini.', ephemeral: true });

    }

    // Cek apakah posisi role bot cukup tinggi untuk mengganti nama target

    if (!target.manageable) {

      return interaction.reply({ 

        content: '❌ Saya tidak bisa mengganti nama member ini. Pastikan posisi role bot lebih tinggi dari member tersebut dan saya memiliki izin `Manage Nicknames`.', 

        ephemeral: true 

      });

    }

    try {

      const oldName = target.displayName;

      await target.setNickname(newName);

      return interaction.reply({ 

        content: `✅ Berhasil mengganti nama **${oldName}** menjadi **${newName}**.`, 

        ephemeral: false 

      });

    } catch (error) {

      console.error('Error executing changename:', error);

      return interaction.reply({ 

        content: '❌ Terjadi kesalahan saat mencoba mengganti nama.', 

        ephemeral: true 

      });

    }

  },

};