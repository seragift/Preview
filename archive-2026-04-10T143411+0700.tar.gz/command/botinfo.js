const {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle
} = require('discord.js');

const config = require('../config.json');

// ⏳ FORMAT UPTIME
function formatUptime(uptime) {
  const d = Math.floor(uptime / 86400);
  const h = Math.floor(uptime / 3600) % 24;
  const m = Math.floor(uptime / 60) % 60;
  const s = Math.floor(uptime % 60);
  return `${d}d ${h}h ${m}m ${s}s`;
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('botinfo')
    .setDescription('Informasi bot (Owner only)'),

  async execute(interaction) {

    const client = interaction.client;

    // 🔒 OWNER ONLY
    if (interaction.user.id !== config.ownerId) {
      return interaction.reply({
        content: '❌ Owner only!',
        flags: 64
      });
    }

    const buildEmbed = () => {
      const totalUsers = client.guilds.cache.reduce((a, g) => a + g.memberCount, 0);
      const memory = (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2);

      const usage = client.commandUsage
        ? [...client.commandUsage.entries()]
            .sort((a, b) => b[1] - a[1])
            .slice(0, 5)
            .map(([cmd, count]) => `/${cmd}: ${count}`)
            .join('\n')
        : 'No data';

      return new EmbedBuilder()
        .setColor('#2f3136')
        .setTitle('📊 Bot Info')
        .setThumbnail(client.user.displayAvatarURL())
        .addFields(
          { name: '🤖 Bot', value: client.user.tag, inline: true },
          { name: '🆔 ID', value: client.user.id, inline: true },
          { name: '👑 Owner', value: config.ownerId, inline: true },

          { name: '📡 Ping', value: `${client.ws.ping} ms`, inline: true },
          { name: '⏳ Uptime', value: formatUptime(process.uptime()), inline: true },
          { name: '🧠 RAM', value: `${memory} MB`, inline: true },

          { name: '🏠 Servers', value: `${client.guilds.cache.size}`, inline: true },
          { name: '👥 Users', value: `${totalUsers}`, inline: true },
          { name: '📁 Commands', value: `${client.commands.size}`, inline: true },

          { name: '📊 Top Commands', value: usage, inline: false },

          { name: '⚙️ Node.js', value: process.version, inline: true },
          { name: '📦 Discord.js', value: require('discord.js').version, inline: true },
          { name: '🖥️ Platform', value: process.platform, inline: true }
        )
        .setTimestamp();
    };

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('refresh_botinfo')
        .setLabel('Refresh')
        .setStyle(ButtonStyle.Secondary)
    );

    const msg = await interaction.reply({
      embeds: [buildEmbed()],
      components: [row],
      fetchReply: true
    });

    const collector = msg.createMessageComponentCollector({ time: 60000 });

    collector.on('collect', async (i) => {
      if (i.user.id !== config.ownerId) {
        return i.reply({ content: '❌ Owner only!', flags: 64 });
      }

      if (i.customId === 'refresh_botinfo') {
        await i.update({
          embeds: [buildEmbed()],
          components: [row]
        });
      }
    });
  }
};