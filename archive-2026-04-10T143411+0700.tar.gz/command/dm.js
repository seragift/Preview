const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {

  data: new SlashCommandBuilder()

    .setName('dm')

    .setDescription('Mengirim pesan pribadi (DM) ke member tertentu (Admin Only)')

    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator) // Hanya Admin yang bisa melihat command ini

    .addUserOption(option =>

      option.setName('target')

        .setDescription('Member yang ingin dikirimi DM')

        .setRequired(true)

    )

    .addStringOption(option =>

      option.setName('pesan')

        .setDescription('Isi pesan yang ingin dikirim')

        .setRequired(true)

    ),

  async execute(interaction) {

    const targetUser = interaction.options.getUser('target');

    const messageContent = interaction.options.getString('pesan');

    // Mencegah mengirim DM ke diri sendiri atau bot

    if (targetUser.id === interaction.user.id) {

      return interaction.reply({ content: '❌ Kamu tidak bisa mengirim DM ke diri sendiri.', ephemeral: true });

    }

    if (targetUser.bot) {

      return interaction.reply({ content: '❌ Kamu tidak bisa mengirim DM ke bot.', ephemeral: true });

    }

    const dmEmbed = new EmbedBuilder()

      .setTitle(`📩 Pesan dari Official ${interaction.guild.name}`)

      .setColor('#ffcc00')

      .setDescription(messageContent)

      .addFields({ name: 'Moderator Pengirim', value: `${interaction.user.tag}`, inline: true })

      .setFooter({ text: 'Harap patuhi aturan server kami. Terima kasih.' })

      .setTimestamp();

    try {

      // Mengirim DM ke target

      await targetUser.send({ embeds: [dmEmbed] });

      // Memberi konfirmasi ke Admin (ephemeral agar tidak mengotori channel)

      await interaction.reply({

        content: `✅ Berhasil mengirim DM ke **${targetUser.tag}**.`,

        ephemeral: true

      });

    } catch (error) {

      console.error(`Gagal mengirim DM ke ${targetUser.tag}:`, error);

      

      // Jika member menutup DM (Privacy Settings)

      await interaction.reply({

        content: `❌ Gagal mengirim DM ke **${targetUser.tag}**. Mungkin mereka menutup fitur DM atau memblokir bot.`,

        ephemeral: true

      });

    }

  },

};