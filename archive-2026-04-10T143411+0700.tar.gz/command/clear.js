const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {

  data: new SlashCommandBuilder()

    .setName('clear')

    .setDescription('Menghapus sejumlah pesan di channel ini')

    .addIntegerOption(option => 

      option.setName('jumlah')

        .setDescription('Jumlah pesan yang ingin dihapus (1-100)')

        .setMinValue(1)

        .setMaxValue(100)

        .setRequired(true))

    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {

    const amount = interaction.options.getInteger('jumlah');

    try {

      // Melakukan bulk delete

      const deletedMessages = await interaction.channel.bulkDelete(amount, true);

      await interaction.reply({ 

        content: `✅ Berhasil menghapus **${deletedMessages.size}** pesan.`, 

        ephemeral: true 

      });

    } catch (error) {

      console.error(error);

      

      // Penanganan error khusus jika pesan sudah lebih dari 14 hari

      if (error.code === 50034) {

        return interaction.reply({ 

          content: '❌ Saya tidak dapat menghapus pesan yang sudah lebih tua dari 14 hari karena batasan Discord.', 

          ephemeral: true 

        });

      }

      await interaction.reply({ 

        content: '❌ Terjadi kesalahan saat mencoba menghapus pesan.', 

        ephemeral: true 

      });

    }

  },

};