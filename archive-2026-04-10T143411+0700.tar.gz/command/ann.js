const { 

  SlashCommandBuilder, 

  EmbedBuilder, 

  PermissionFlagsBits, 

  ActionRowBuilder, 

  ButtonBuilder, 

  ButtonStyle 

} = require('discord.js');

module.exports = {

  data: new SlashCommandBuilder()

    .setName('ann')

    .setDescription('Mengirimkan pengumuman resmi ke channel tertentu')

    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)

    .addChannelOption(option => 

      option.setName('channel')

        .setDescription('Channel tujuan pengumuman')

        .setRequired(true))

    .addStringOption(option => 

      option.setName('title')

        .setDescription('Judul pengumuman')

        .setRequired(true))

    .addStringOption(option => 

      option.setName('deskripsi')

        .setDescription('Isi atau deskripsi pengumuman')

        .setRequired(true))

    .addRoleOption(option => 

      option.setName('mention')

        .setDescription('Role yang akan di-mention (opsional)'))

    .addAttachmentOption(option => 

      option.setName('image')

        .setDescription('Gambar besar di bawah embed (opsional)'))

    .addAttachmentOption(option => 

      option.setName('icon')

        .setDescription('Gambar kecil di pojok kanan atas (opsional)'))

    .addStringOption(option => 

      option.setName('button_label')

        .setDescription('Teks pada tombol link (opsional)'))

    .addStringOption(option => 

      option.setName('button_link')

        .setDescription('URL tujuan tombol (opsional)')),

  async execute(interaction) {

    const channel = interaction.options.getChannel('channel');

    const title = interaction.options.getString('title');

    const description = interaction.options.getString('deskripsi');

    const role = interaction.options.getRole('mention');

    const image = interaction.options.getAttachment('image');

    const icon = interaction.options.getAttachment('icon');

    const btnLabel = interaction.options.getString('button_label');

    const btnLink = interaction.options.getString('button_link');

    // Membuat Embed

    const embed = new EmbedBuilder()

      .setTitle(title)

      .setDescription(description.replace(/\\n/g, '\n')) // Mendukung baris baru

      .setColor('Blue')

      .setTimestamp()

      .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL() });

    if (image) embed.setImage(image.url);

    if (icon) embed.setThumbnail(icon.url);

    // Membuat Button jika ada link

    const components = [];

    if (btnLabel && btnLink) {

      const row = new ActionRowBuilder().addComponents(

        new ButtonBuilder()

          .setLabel(btnLabel)

          .setURL(btnLink.startsWith('http') ? btnLink : `https://${btnLink}`)

          .setStyle(ButtonStyle.Link)

      );

      components.push(row);

    }

    try {

      // Mengirim pengumuman

      const messageContent = role ? `<@&${role.id}>` : null;

      await channel.send({ 

        content: messageContent, 

        embeds: [embed], 

        components: components 

      });

      await interaction.reply({ content: `✅ Pengumuman berhasil dikirim ke ${channel}`, ephemeral: true });

    } catch (error) {

      console.error(error);

      await interaction.reply({ content: '❌ Gagal mengirim pengumuman. Pastikan bot memiliki izin di channel tersebut.', ephemeral: true });

    }

  },

};