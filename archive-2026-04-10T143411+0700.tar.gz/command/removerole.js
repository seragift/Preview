const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {

  data: new SlashCommandBuilder()

    .setName('removerole')

    .setDescription('Menghapus role dari seorang member')

    .addUserOption(option => 

      option.setName('target')

        .setDescription('Member yang rolenya akan dihapus')

        .setRequired(true))

    .addRoleOption(option => 

      option.setName('role')

        .setDescription('Role yang ingin dihapus')

        .setRequired(true))

    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {

    const target = interaction.options.getMember('target');

    const role = interaction.options.getRole('role');

    // Validasi apakah target ada di server

    if (!target) {

      return interaction.reply({ 

        content: '❌ Member tidak ditemukan di server ini.', 

        ephemeral: true 

      });

    }

    // Validasi apakah target memiliki role tersebut

    if (!target.roles.cache.has(role.id)) {

      return interaction.reply({ 

        content: `❌ **${target.user.tag}** tidak memiliki role **${role.name}**.`, 

        ephemeral: true 

      });

    }

    try {

      await target.roles.remove(role);

      await interaction.reply({ 

        content: `✅ Berhasil menghapus role **${role.name}** dari **${target.user.tag}**.` 

      });

    } catch (error) {

      console.error(error);

      await interaction.reply({ 

        content: '❌ Gagal menghapus role. Pastikan posisi role bot lebih tinggi dari role yang ingin dihapus.', 

        ephemeral: true 

      });

    }

  },

};