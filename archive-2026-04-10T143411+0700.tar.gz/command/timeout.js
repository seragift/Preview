const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {

  data: new SlashCommandBuilder()

    .setName('timeout')

    .setDescription('Memberikan timeout kepada member agar tidak bisa chat/masuk voice')

    .addUserOption(option => 

      option.setName('target')

        .setDescription('Member yang akan di-timeout')

        .setRequired(true))

    .addIntegerOption(option => 

      option.setName('durasi')

        .setDescription('Pilih durasi timeout')

        .setRequired(true)

        .addChoices(

          { name: '1 Jam', value: 3600 * 1000 },

          { name: '1 Hari', value: 86400 * 1000 },

          { name: '2 Hari', value: 86400 * 2 * 1000 },

          { name: '3 Hari', value: 86400 * 3 * 1000 },

          { name: '4 Hari', value: 86400 * 4 * 1000 },

          { name: '5 Hari', value: 86400 * 5 * 1000 },

          { name: '6 Hari', value: 86400 * 6 * 1000 },

          { name: '7 Hari', value: 86400 * 7 * 1000 },

        ))

    .addStringOption(option => 

      option.setName('alasan')

        .setDescription('Alasan timeout'))

    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {

    const target = interaction.options.getMember('target');

    const duration = interaction.options.getInteger('durasi');

    const reason = interaction.options.getString('alasan') || 'Tidak ada alasan.';

    if (!target) {

      return interaction.reply({ content: '❌ Member tidak ditemukan!', ephemeral: true });

    }

    if (!target.moderatable) {

      return interaction.reply({ 

        content: '❌ Saya tidak bisa memberikan timeout kepada member ini (Role mereka mungkin lebih tinggi).', 

        ephemeral: true 

      });

    }

    try {

      await target.timeout(duration, reason);

      

      const durationText = interaction.options.get('durasi').name; // Mengambil label (misal: "1 Hari")

      await interaction.reply({ 

        content: `⏳ **${target.user.tag}** telah di-timeout selama **${durationText}**. \n**Alasan:** ${reason}` 

      });

    } catch (error) {

      console.error(error);

      await interaction.reply({ 

        content: '❌ Terjadi kesalahan saat mencoba memberikan timeout.', 

        ephemeral: true 

      });

    }

  },

};