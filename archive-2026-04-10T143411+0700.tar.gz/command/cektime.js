const { 

  SlashCommandBuilder, 

  EmbedBuilder, 

  ActionRowBuilder, 

  ButtonBuilder, 

  ButtonStyle 

} = require('discord.js');

const db = require('../database/database');

module.exports = {

  data: new SlashCommandBuilder()

    .setName('cektime')

    .setDescription('Mengecek sisa waktu role sementara')

    .addSubcommand(sub =>

      sub.setName('user')

        .setDescription('Cek sisa waktu role user tertentu')

        .addUserOption(opt => opt.setName('target').setDescription('Pilih user (kosongkan untuk diri sendiri)')))

    .addSubcommand(sub =>

      sub.setName('list')

        .setDescription('Menampilkan semua user yang memiliki role sementara')),

  async execute(interaction) {

    const sub = interaction.options.getSubcommand();

    const guildId = interaction.guild.id;

    if (sub === 'user') {

      const target = interaction.options.getUser('target') || interaction.user;

      const data = db.prepare('SELECT * FROM role_timer WHERE guildId = ? AND userId = ?').all(guildId, target.id);

      if (data.length === 0) {

        return interaction.reply({ content: `❌ **${target.tag}** tidak memiliki role sementara.`, ephemeral: true });

      }

      const embed = new EmbedBuilder()

        .setTitle(`⏳ Sisa Waktu: ${target.username}`)

        .setColor('Yellow')

        .setDescription(formatRoleList(data));

      return interaction.reply({ embeds: [embed] });

    }

    if (sub === 'list') {

      const allData = db.prepare('SELECT * FROM role_timer WHERE guildId = ? ORDER BY endTime ASC').all(guildId);

      if (allData.length === 0) {

        return interaction.reply({ content: '❌ Tidak ada user dengan role sementara.', ephemeral: true });

      }

      // --- Logika Pagination ---

      const itemsPerPage = 5;

      const totalPages = Math.ceil(allData.length / itemsPerPage);

      let currentPage = 0;

      const generateEmbed = (page) => {

        const start = page * itemsPerPage;

        const end = start + itemsPerPage;

        const currentItems = allData.slice(start, end);

        const embed = new EmbedBuilder()

          .setTitle('📋 Daftar Semua Role Sementara')

          .setColor('Blue')

          .setFooter({ text: `Halaman ${page + 1} dari ${totalPages}` })

          .setTimestamp();

        let listContent = '';

        currentItems.forEach((row, i) => {

          const timeLeft = row.endTime - Date.now();

          const days = Math.floor(timeLeft / (24 * 60 * 60 * 1000));

          listContent += `**${start + i + 1}.** <@${row.userId}> — <@&${row.roleId}>\n└ ⏳ Sisa: \`${days} hari\`\n\n`;

        });

        embed.setDescription(listContent || 'Data kosong.');

        return embed;

      };

      const row = new ActionRowBuilder().addComponents(

        new ButtonBuilder()

          .setCustomId('prev')

          .setLabel('⬅️')

          .setStyle(ButtonStyle.Primary)

          .setDisabled(true),

        new ButtonBuilder()

          .setCustomId('next')

          .setLabel('➡️')

          .setStyle(ButtonStyle.Primary)

          .setDisabled(totalPages <= 1)

      );

      const response = await interaction.reply({

        embeds: [generateEmbed(0)],

        components: totalPages > 1 ? [row] : [],

        fetchReply: true

      });

      // Collector untuk tombol

      const collector = response.createMessageComponentCollector({ time: 60000 });

      collector.on('collect', async (i) => {

        if (i.user.id !== interaction.user.id) {

          return i.reply({ content: 'Hanya pengirim perintah yang bisa menekan tombol ini.', ephemeral: true });

        }

        if (i.customId === 'prev') currentPage--;

        if (i.customId === 'next') currentPage++;

        const updateRow = new ActionRowBuilder().addComponents(

          new ButtonBuilder()

            .setCustomId('prev')

            .setLabel('⬅️')

            .setStyle(ButtonStyle.Primary)

            .setDisabled(currentPage === 0),

          new ButtonBuilder()

            .setCustomId('next')

            .setLabel('➡️')

            .setStyle(ButtonStyle.Primary)

            .setDisabled(currentPage === totalPages - 1)

        );

        await i.update({

          embeds: [generateEmbed(currentPage)],

          components: [updateRow]

        });

      });

      collector.on('end', () => {

        response.edit({ components: [] }).catch(() => {});

      });

    }

  }

};

function formatRoleList(data) {

  const now = Date.now();

  return data.map(row => {

    const timeLeft = row.endTime - now;

    const days = Math.floor(timeLeft / (24 * 60 * 60 * 1000));

    return `**<@&${row.roleId}>**\n└ ⏳ \`${days} hari sisa\``;

  }).join('\n\n');

}