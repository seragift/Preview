const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {

  data: new SlashCommandBuilder()

    .setName('kick')

    .setDescription('Mengeluarkan member dari server')

    .addUserOption(option => option.setName('target').setDescription('Member yang akan di-kick').setRequired(true))

    .addStringOption(option => option.setName('reason').setDescription('Alasan kick'))

    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {

    const target = interaction.options.getMember('target');

    const reason = interaction.options.getString('reason') || 'Tidak ada alasan.';

    if (!target) return interaction.reply({ content: 'Member tidak ditemukan!', ephemeral: true });

    if (!target.kickable) return interaction.reply({ content: '❌ Saya tidak bisa menendang member ini (Role mereka mungkin lebih tinggi).', ephemeral: true });

    await target.kick(reason);

    await interaction.reply({ content: `👢 **${target.user.tag}** telah dikeluarkan. Alasan: ${reason}` });

  },

};