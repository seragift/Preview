const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

const db = require('../database/intro');

module.exports = {

  data: new SlashCommandBuilder()

    .setName('removeintro')

    .setDescription('Hapus intro user')

    .addUserOption(option =>

      option.setName('target')

        .setDescription('User yang ingin dihapus intronya')

        .setRequired(true)

    )

    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {

    const target = interaction.options.getUser('target');

    const guildId = interaction.guild.id;

    const data = db.prepare(

      "SELECT * FROM intro_users WHERE userId = ? AND guildId = ?"

    ).get(target.id, guildId);

    if (!data) {

      return interaction.reply({

        content: '❌ User belum pernah isi intro!',

        ephemeral: true

      });

    }

    db.prepare(

      "DELETE FROM intro_users WHERE userId = ? AND guildId = ?"

    ).run(target.id, guildId);

    await interaction.reply({

      content: `✅ Intro <@${target.id}> berhasil dihapus!`,

      ephemeral: true

    });

  }

};