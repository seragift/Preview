const {
  SlashCommandBuilder,
  PermissionFlagsBits
} = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('deleterole')
    .setDescription('Menghapus role dari server')
    
    .addRoleOption(option =>
      option.setName('role')
        .setDescription('Pilih role yang mau dihapus')
        .setRequired(true))

    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    const role = interaction.options.getRole('role');

    // Double check admin
    if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
      return interaction.reply({
        content: '❌ Hanya Administrator yang bisa pakai command ini!',
        ephemeral: true
      });
    }

    // Cegah hapus role penting
    if (role.managed) {
      return interaction.reply({
        content: '❌ Role ini milik bot / integrasi, tidak bisa dihapus!',
        ephemeral: true
      });
    }

    if (role.position >= interaction.guild.members.me.roles.highest.position) {
      return interaction.reply({
        content: '❌ Role ini lebih tinggi dari bot!',
        ephemeral: true
      });
    }

    try {
      const roleName = role.name;

      await role.delete(`Dihapus oleh ${interaction.user.tag}`);

      return interaction.reply({
        content: `🗑️ Role **${roleName}** berhasil dihapus!`,
      });

    } catch (err) {
      console.error(err);
      return interaction.reply({
        content: '❌ Gagal menghapus role!',
        ephemeral: true
      });
    }
  }
};