const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

const db = require('../database/database');

module.exports = {

  data: new SlashCommandBuilder()

    .setName('removetime')

    .setDescription('Menghapus durasi role sementara dan mencabut rolenya')

    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)

    .addUserOption(option => 

      option.setName('target')

        .setDescription('Member yang ingin dicabut rolenya')

        .setRequired(true))

    .addRoleOption(option => 

      option.setName('role')

        .setDescription('Role yang ingin dicabut durasinya')

        .setRequired(true)),

  async execute(interaction) {

    const target = interaction.options.getMember('target');

    const role = interaction.options.getRole('role');

    const guildId = interaction.guild.id;

    try {

      // 1. Cek apakah data ada di database

      const data = db.prepare('SELECT * FROM role_timer WHERE guildId = ? AND userId = ? AND roleId = ?')

        .get(guildId, target.id, role.id);

      if (!data) {

        return interaction.reply({ 

          content: `❌ **${target.user.tag}** tidak memiliki catatan durasi untuk role **${role.name}**.`, 

          ephemeral: true 

        });

      }

      // 2. Cabut role dari member

      await target.roles.remove(role).catch(() => null);

      // 3. Hapus data dari database

      db.prepare('DELETE FROM role_timer WHERE guildId = ? AND userId = ? AND roleId = ?')

        .run(guildId, target.id, role.id);

      return interaction.reply({ 

        content: `✅ Berhasil menghapus durasi dan mencabut role **${role.name}** dari **${target.user.tag}**.`, 

        ephemeral: false 

      });

    } catch (error) {

      console.error('Error executing removetime:', error);

      return interaction.reply({ 

        content: '❌ Terjadi kesalahan saat memproses permintaan.', 

        ephemeral: true 

      });

    }

  },

};