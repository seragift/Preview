const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {

  data: new SlashCommandBuilder()

    .setName('untimeout')

    .setDescription('Menghapus status timeout dari seorang member')

    .addUserOption(option => 

      option.setName('target')

        .setDescription('Member yang akan dibatalkan timeout-nya')

        .setRequired(true))

    .addStringOption(option => 

      option.setName('alasan')

        .setDescription('Alasan pembatalan timeout'))

    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {

    const target = interaction.options.getMember('target');

    const reason = interaction.options.getString('alasan') || 'Tidak ada alasan.';

    if (!target) {

      return interaction.reply({ content: '❌ Member tidak ditemukan!', ephemeral: true });

    }

    // Periksa apakah member sedang dalam masa timeout

    if (!target.communicationDisabledUntilTimestamp || target.communicationDisabledUntilTimestamp < Date.now()) {

      return interaction.reply({ 

        content: `❌ **${target.user.tag}** saat ini tidak sedang dalam masa timeout.`, 

        ephemeral: true 

      });

    }

    try {

      // Mengatur timeout ke null akan menghapus hukuman seketika

      await target.timeout(null, reason);

      

      await interaction.reply({ 

        content: `✅ Status timeout untuk **${target.user.tag}** telah dihapus.\n**Alasan:** ${reason}` 

      });

    } catch (error) {

      console.error(error);

      await interaction.reply({ 

        content: '❌ Terjadi kesalahan saat mencoba menghapus timeout. Pastikan role bot cukup tinggi.', 

        ephemeral: true 

      });

    }

  },

};