const {

  SlashCommandBuilder,

  EmbedBuilder,

  ActionRowBuilder,

  ButtonBuilder,

  ButtonStyle

} = require('discord.js');

const polls = new Map();

function createBar(percent){

  const total = 10;

  const filled = Math.round(percent / 10);

  return "█".repeat(filled) + "░".repeat(total - filled);

}

function parseTime(input){

  if(!input) return { ms:60000, text:"1m" };

  const match = input.match(/^(\d+)(s|m|h|d)$/i);

  if(!match) return null;

  const value = parseInt(match[1]);

  const unit = match[2].toLowerCase();

  const map = {

    s: 1000,

    m: 60000,

    h: 3600000,

    d: 86400000

  };

  return {

    ms: value * map[unit],

    text: input

  };

}

function formatTime(ms){

  const totalSec = Math.floor(ms / 1000);

  const m = Math.floor(totalSec / 60);

  const s = totalSec % 60;

  return `${m}m ${s}s`;

}

function createChart(options, votes){

  return "https://quickchart.io/chart?c=" + encodeURIComponent(JSON.stringify({

    type: 'bar',

    data: {

      labels: options,

      datasets: [{

        label: 'Votes',

        data: votes

      }]

    }

  }));

}

module.exports = {

  data: new SlashCommandBuilder()

    .setName('poll')

    .setDescription('Create polling')

    .addStringOption(o =>

      o.setName('pertanyaan')

        .setDescription('Pertanyaan polling')

        .setRequired(true))

    .addStringOption(o =>

      o.setName('opsi1').setDescription('Opsi 1').setRequired(true))

    .addStringOption(o =>

      o.setName('opsi2').setDescription('Opsi 2').setRequired(true))

    .addStringOption(o =>

      o.setName('opsi3').setDescription('Opsi 3'))

    .addStringOption(o =>

      o.setName('opsi4').setDescription('Opsi 4'))

    .addStringOption(o =>

      o.setName('waktu')

        .setDescription('Contoh: 10s, 1m, 1h, 1d')),

  async execute(interaction){

    const q = interaction.options.getString('pertanyaan');

    const parsed = parseTime(interaction.options.getString('waktu'));

    if(!parsed){

      return interaction.reply({

        content:"Format waktu salah 😤 (contoh: 10s, 1m, 1h)",

        ephemeral:true

      });

    }

    const options = [

      interaction.options.getString('opsi1'),

      interaction.options.getString('opsi2'),

      interaction.options.getString('opsi3'),

      interaction.options.getString('opsi4')

    ].filter(Boolean);

    if(options.length < 2){

      return interaction.reply({

        content:"Minimal 2 opsi goblok 😤",

        ephemeral:true

      });

    }

    const votes = Array(options.length).fill(0);

    const voters = new Map();

    const endTime = Date.now() + parsed.ms;

    const row = new ActionRowBuilder();

    options.forEach((o,i)=>{

      row.addComponents(

        new ButtonBuilder()

          .setCustomId(`vote_${i}`)

          .setLabel(`${i+1}`)

          .setStyle(ButtonStyle.Primary)

      );

    });

    function buildEmbed(){

      const totalVotes = votes.reduce((a,b)=>a+b,0) || 1;

      const desc = options.map((o,i)=>{

        const percent = Math.round((votes[i]/totalVotes)*100);

        return `**${i+1}. ${o}**\n${createBar(percent)} **${percent}%** (${votes[i]} vote)`;

      }).join("\n\n");

      const timeLeft = Math.max(0, endTime - Date.now());

      return new EmbedBuilder()

        .setColor(0x5865F2)

        .setTitle("📊 Poll Aktif")

        .setDescription(`**${q}**\n\n${desc}`)

        .setFooter({ text:`⏳ Sisa waktu: ${formatTime(timeLeft)}` })

        .setTimestamp();

    }

    await interaction.reply({ embeds:[buildEmbed()], components:[row] });

    const msg = await interaction.fetchReply();

    polls.set(msg.id, { votes, voters, options });

    // 🔥 live update (smooth & aman)

    const interval = setInterval(async ()=>{

      if(!polls.has(msg.id)){

        clearInterval(interval);

        return;

      }

      try{

        await msg.edit({ embeds:[buildEmbed()] });

      }catch{

        clearInterval(interval);

      }

    }, 4000);

    const collector = msg.createMessageComponentCollector({ time: parsed.ms });

    collector.on('collect', async i => {

      const data = polls.get(msg.id);

      if(!data) return;

      const index = parseInt(i.customId.split("_")[1]);

      // 🔁 ubah vote

      if(data.voters.has(i.user.id)){

        const old = data.voters.get(i.user.id);

        data.votes[old]--;

      }

      data.votes[index]++;

      data.voters.set(i.user.id, index);

      await i.update({ embeds:[buildEmbed()] });

    });

    collector.on('end', async () => {

      clearInterval(interval);

      const data = polls.get(msg.id);

      if(!data) return;

      const max = Math.max(...data.votes);

      const winners = data.options.filter((_,i)=>data.votes[i] === max);

      const chart = createChart(data.options, data.votes);

      const resultEmbed = new EmbedBuilder()

        .setColor(0x00ffcc)

        .setTitle("🏆 Hasil Poll")

        .setDescription(`**${q}**\n\nPemenang:\n${winners.map(w=>`👉 ${w}`).join("\n")}`)

        .setImage(chart)

        .addFields({

          name:"Total Vote",

          value: data.votes.reduce((a,b)=>a+b,0).toString()

        })

        .setFooter({ text:"Poll selesai 🎉" })

        .setTimestamp();

      await msg.edit({ embeds:[resultEmbed], components:[] });

      polls.delete(msg.id);

    });

  }

};