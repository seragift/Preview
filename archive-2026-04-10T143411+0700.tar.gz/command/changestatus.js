const { SlashCommandBuilder, ActivityType } = require('discord.js');

const config = require('../config.json');

module.exports = {

data: new SlashCommandBuilder()

.setName('changestatus')

.setDescription('Mengubah status dan activity bot (Owner Only)')

.addStringOption(option =>

option.setName('status')

.setDescription('Status bot')

.setRequired(true)

.addChoices(

{ name: 'Online', value: 'online' },

{ name: 'Idle', value: 'idle' },

{ name: 'Do Not Disturb', value: 'dnd' }

))

.addStringOption(option =>

option.setName('activity')

.setDescription('Jenis activity')

.setRequired(false)

.addChoices(

{ name: 'Playing', value: 'playing' },

{ name: 'Watching', value: 'watching' },

{ name: 'Listening', value: 'listening' },

{ name: 'Disable Activity', value: 'none' }

))

.addStringOption(option =>

option.setName('text')

.setDescription('Teks activity')

.setRequired(false)

),

async execute(interaction) {

if (interaction.user.id !== config.ownerId)

return interaction.reply({ content: "❌ Owner only.", ephemeral: true });

const status = interaction.options.getString('status');

const activity = interaction.options.getString('activity');

const text = interaction.options.getString('text');

let activityType;

if (activity === 'playing') activityType = ActivityType.Playing;

if (activity === 'watching') activityType = ActivityType.Watching;

if (activity === 'listening') activityType = ActivityType.Listening;

if (activity === 'none') {

interaction.client.user.setPresence({

status: status,

activities: []

});

return interaction.reply(`✅ Status bot diubah ke **${status}** tanpa activity.`);

}

interaction.client.user.setPresence({

status: status,

activities: [{

name: text || "Bot Active",

type: activityType

}]

});

interaction.reply(`✅ Status bot diubah ke **${status}** dengan activity **${text}**`);

}

};