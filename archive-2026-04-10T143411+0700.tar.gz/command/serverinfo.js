const { SlashCommandBuilder, EmbedBuilder, ChannelType } = require('discord.js');

module.exports = {

    data: new SlashCommandBuilder()

        .setName('serverinfo')

        .setDescription('Menampilkan informasi detail tentang server ini'),

    async execute(interaction) {

        const { guild } = interaction;

        

        // Mengambil semua data yang diperlukan

        const owner = await guild.fetchOwner();

        const members = guild.memberCount;

        const bots = guild.members.cache.filter(member => member.user.bot).size;

        const humans = members - bots;

        

        const channels = guild.channels.cache;

        const textChannels = channels.filter(c => c.type === ChannelType.GuildText).size;

        const voiceChannels = channels.filter(c => c.type === ChannelType.GuildVoice).size;

        const categories = channels.filter(c => c.type === ChannelType.GuildCategory).size;

        const roles = guild.roles.cache.size;

        

        const boostCount = guild.premiumSubscriptionCount || 0;

        const boostLevel = guild.premiumTier;

        const embed = new EmbedBuilder()

            .setTitle(`Information for ${guild.name}`)

            .setColor('#5865F2')

            .addFields(

                { name: '🆔 Server ID', value: `${guild.id}`, inline: true },

                { name: '👑 Owner', value: `${owner.user.tag}`, inline: true },

                { name: '📅 Created At', value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:R>`, inline: true },

                

                { name: '👥 Members', value: `Total: **${members}**\nHumans: **${humans}**\nBots: **${bots}**`, inline: true },

                { name: '📂 Channels', value: `Categories: **${categories}**\nText: **${textChannels}**\nVoice: **${voiceChannels}**`, inline: true },

                { name: '🛡️ Roles', value: `**${roles}** Roles`, inline: true },

                

                { name: '🚀 Boost Status', value: `Level: **${boostLevel}**\nBoosters: **${boostCount}**`, inline: true },

                { name: '🌍 Region / Locale', value: `${guild.preferredLocale}`, inline: true },

                { name: '✨ Verification', value: `${guild.verificationLevel}`, inline: true }

            )

            .setTimestamp();

        // Jika server punya icon, tambahkan ke embed

        if (guild.iconURL()) {

            embed.setThumbnail(guild.iconURL({ dynamic: true }));

        }

        // Jika server punya banner, tambahkan ke embed

        if (guild.bannerURL()) {

            embed.setImage(guild.bannerURL({ size: 1024 }));

        }

        await interaction.reply({ embeds: [embed] });

    }

};