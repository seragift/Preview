const {

  SlashCommandBuilder,

  EmbedBuilder

} = require('discord.js');

const { couples } = require('./couple'); // pastikan export kalau dipisah

module.exports = {

  data: new SlashCommandBuilder()

    .setName('breakup')

    .setDescription('untuk hapus role couple'),

  async execute(interaction){

    const userId = interaction.user.id;

    const roleId = couples.get(userId);

    if(!roleId){

      return interaction.reply({ content:"Lu ga punya couple 😤", ephemeral:true });

    }

    const guild = interaction.guild;

    const role = guild.roles.cache.get(roleId);

    if(role){

      await role.delete().catch(()=>{});

    }

    // hapus semua user yang punya role itu

    for(const [k,v] of couples){

      if(v === roleId) couples.delete(k);

    }

    await interaction.reply({

      embeds:[

        new EmbedBuilder()

          .setColor(0xff0000)

          .setTitle("💔 Breakup")

          .setDescription("Udah putus... sad 😭")

      ]

    });

  }

};