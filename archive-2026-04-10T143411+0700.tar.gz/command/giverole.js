const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {

  data: new SlashCommandBuilder()

    .setName('giverole')

    .setDescription('Memberikan role kepada member')

    .addUserOption(option => option.setName('target').setDescription('Member yang akan diberi role').setRequired(true))

    .addRoleOption(option => option.setName('role').setDescription('Role yang akan diberikan').setRequired(true))

    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {

    const target = interaction.options.getMember('target');

    const role = interaction.options.getRole('role');

    if (!target) return interaction.reply({ content: 'Member tidak ditemukan!', ephemeral: true });

    try {

      await target.roles.add(role);

      await interaction.reply({ content: `✅ Berhasil memberikan role **${role.name}** kepada **${target.user.tag}**.` });

    } catch (error) {

      await interaction.reply({ content: '❌ Gagal memberikan role. Pastikan posisi role bot lebih tinggi dari role tersebut.', ephemeral: true });

    }

  },

};