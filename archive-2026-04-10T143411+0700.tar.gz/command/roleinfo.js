const {
  SlashCommandBuilder,
  EmbedBuilder,
  PermissionFlagsBits
} = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('roleinfo')
    .setDescription('Melihat informasi detail role')
    
    .addRoleOption(option =>
      option.setName('role')
        .setDescription('Pilih role')
        .setRequired(true)
    )

    // 🔒 Admin only (hide dari non-admin)
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {

    // 🔒 Double check (anti bypass)
    if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
      return interaction.reply({
        content: '❌ Hanya Administrator yang bisa pakai command ini!',
        flags: 64
      });
    }

    const role = interaction.options.getRole('role');

    const membersWithRole = interaction.guild.members.cache.filter(member =>
      member.roles.cache.has(role.id)
    ).size;

    const createdAt = `<t:${Math.floor(role.createdTimestamp / 1000)}:F>`;

    const embed = new EmbedBuilder()
      .setColor(role.color || '#2f3136')
      .setTitle(`📌 Role Info: ${role.name}`)
      .addFields(
        { name: '🆔 ID', value: role.id, inline: true },
        { name: '🎨 Warna', value: role.hexColor || 'None', inline: true },
        { name: '👥 Members', value: `${membersWithRole}`, inline: true },

        { name: '📍 Posisi', value: `${role.position}`, inline: true },
        { name: '🔒 Hoisted', value: role.hoist ? 'Yes' : 'No', inline: true },
        { name: '🔗 Mentionable', value: role.mentionable ? 'Yes' : 'No', inline: true },

        { name: '🤖 Managed', value: role.managed ? 'Yes (Bot/Integration)' : 'No', inline: true },
        { name: '📅 Dibuat', value: createdAt }
      )
      .setFooter({ text: `Server: ${interaction.guild.name}` })
      .setTimestamp();

    return interaction.reply({ embeds: [embed] });
  }
};