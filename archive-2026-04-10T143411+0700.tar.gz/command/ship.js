const { SlashCommandBuilder, EmbedBuilder } = require('discord.js')

const quotes = [

"Cinta sejati tidak melihat kekurangan.",

"Hubungan kuat dibangun dari kepercayaan.",

"Cinta kadang random seperti command ini.",

"Jika cocok ya cocok, kalau tidak ya move on.",

"Love is in the air.",

"Kadang cinta hanya ilusi.",

"Cinta butuh usaha dua pihak."

]

const gifs = [

"https://media.giphy.com/media/MDJ9IbxxvDUQM/giphy.gif",

"https://media.giphy.com/media/l0MYt5jPR6QX5pnqM/giphy.gif",

"https://media.giphy.com/media/3oriO0OEd9QIDdllqo/giphy.gif",

"https://media.giphy.com/media/26BRv0ThflsHCqDrG/giphy.gif"

]

module.exports = {

data: new SlashCommandBuilder()

.setName('lovemeter')

.setDescription('Cek kecocokan cinta dua nama')

.addStringOption(o =>

o.setName('name1')

.setDescription('Nama pertama')

.setRequired(true))

.addStringOption(o =>

o.setName('name2')

.setDescription('Nama kedua')

.setRequired(true)),

async execute(interaction){

const name1 = interaction.options.getString('name1')

const name2 = interaction.options.getString('name2')

const percent = Math.floor(Math.random()*101)

let status = ""

let color = 0xff4d6d

if(percent === 0){

status = "☠️ Toxic Relationship"

color = 0x2f3136

}

else if(percent < 30){

status = "💔 Tidak cocok"

color = 0xff0000

}

else if(percent < 50){

status = "😐 Kurang cocok"

color = 0xff9900

}

else if(percent < 70){

status = "🙂 Lumayan cocok"

color = 0xffff00

}

else if(percent < 90){

status = "❤️ Cocok"

color = 0xff66aa

}

else if(percent < 100){

status = "💖 Cocok banget"

color = 0xff1493

}

else{

status = "💍 Soulmate! Saatnya menikah!"

color = 0x00ffcc

}

const barLength = 10

const filled = Math.round(percent / 10)

const empty = barLength - filled

const bar = "█".repeat(filled) + "░".repeat(empty)

const shipName =

name1.slice(0, Math.ceil(name1.length/2)) +

name2.slice(Math.floor(name2.length/2))

const quote = quotes[Math.floor(Math.random()*quotes.length)]

const gif = gifs[Math.floor(Math.random()*gifs.length)]

const embed = new EmbedBuilder()

.setColor(color)

.setTitle("💘 Love Calculator")

.setDescription(`**${name1} ❤️ ${name2}**`)

.setImage(gif)

.addFields(

{ name:"Ship Name", value:`💞 **${shipName}**` },

{ name:"Love Meter", value:`${bar} **${percent}%**` },

{ name:"Relationship", value:status },

{ name:"Love Quote", value:`"${quote}"` }

)

.setFooter({ text:`Diminta oleh ${interaction.user.username}` })

.setTimestamp()

interaction.reply({ embeds:[embed] })

}

}