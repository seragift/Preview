const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {

  data: new SlashCommandBuilder()

    .setName('ban')

    .setDescription('Memblokir member dari server')

    .addUserOption(option => option.setName('target').setDescription('Member yang akan di-ban').setRequired(true))

    .addStringOption(option => option.setName('reason').setDescription('Alasan ban'))

    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {

    const target = interaction.options.getMember('target');

    const reason = interaction.options.getString('reason') || 'Tidak ada alasan.';

    if (!target) return interaction.reply({ content: 'Member tidak ditemukan!', ephemeral: true });

    if (!target.bannable) return interaction.reply({ content: '❌ Saya tidak bisa memblokir member ini.', ephemeral: true });

    await target.ban({ reason });

    await interaction.reply({ content: `🔨 **${target.user.tag}** telah diblokir permanen. Alasan: ${reason}` });

  },

};