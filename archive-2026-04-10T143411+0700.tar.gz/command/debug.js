const { SlashCommandBuilder, EmbedBuilder, version } = require('discord.js');

const os = require('os');

const { ownerId } = require('../config.json');

module.exports = {

  data: new SlashCommandBuilder()

    .setName('debug')

    .setDescription('Ultimate System Debug & Performance Monitor (Owner Only)'),

  async execute(interaction) {

    // 1. Keamanan: Cek Owner ID

    if (interaction.user.id !== ownerId) {

      return interaction.reply({ 

        content: '⚠️ **Akses Ditolak.** Informasi ini hanya tersedia untuk pengembang bot.', 

        ephemeral: true 

      });

    }

    // 2. Kalkulasi Uptime (Sistem & Bot)

    const botUptime = formatUptime(interaction.client.uptime);

    const osUptime = formatUptime(os.uptime() * 1000);

    // 3. Statistik Memori Mendalam (MB)

    const memUsage = process.memoryUsage();

    const rss = (memUsage.rss / 1024 / 1024).toFixed(2); // Total memori yang dialokasikan

    const heapUsed = (memUsage.heapUsed / 1024 / 1024).toFixed(2); // Memori yang sedang digunakan

    const heapTotal = (memUsage.heapTotal / 1024 / 1024).toFixed(2);

    const external = (memUsage.external / 1024 / 1024).toFixed(2); // Memori C++ yang terikat ke JS

    // 4. Informasi CPU Load & Speed

    const cpus = os.cpus();

    const cpuModel = cpus[0].model;

    const cpuSpeed = cpus[0].speed;

    const cpuCores = cpus.length;

    const loadAvg = os.loadavg().map(l => l.toFixed(2)).join(' | '); // 1, 5, 15 menit load

    const embed = new EmbedBuilder()

      .setTitle('🚀 ULTIMATE DEBUG DASHBOARD')

      .setColor('#00ffea')

      .setThumbnail(interaction.client.user.displayAvatarURL())

      .addFields(

        { 

          name: '🤖 BOT INSTANCE', 

          value: `**Tag:** ${interaction.client.user.tag}\n**ID:** \`${interaction.client.user.id}\`\n**Uptime:** \`${botUptime}\`\n**Ping:** \`${interaction.client.ws.ping}ms\``, 

          inline: true 

        },

        { 

          name: '💻 HOST MACHINE', 

          value: `**OS:** \`${os.type()} ${os.arch()}\`\n**Release:** \`${os.release()}\`\n**Uptime:** \`${osUptime}\`\n**Node.js:** \`${process.version}\``, 

          inline: true 

        },

        { 

          name: '🧠 MEMORY ANALYSIS', 

          value: `**RSS:** \`${rss} MB\`\n**Heap Used:** \`${heapUsed} / ${heapTotal} MB\`\n**External:** \`${external} MB\``, 

          inline: false 

        },

        { 

          name: '⚡ CPU & PERFORMANCE', 

          value: `**Model:** \`${cpuModel}\`\n**Cores:** \`${cpuCores} Threads\` @ \`${cpuSpeed}MHz\`\n**Load Avg:** \`${loadAvg}\``, 

          inline: false 

        },

        { 

          name: '📊 DISCORD STATS', 

          value: `**Servers:** \`${interaction.client.guilds.cache.size.toLocaleString()}\`\n**Users:** \`${interaction.client.users.cache.size.toLocaleString()}\`\n**Channels:** \`${interaction.client.channels.cache.size.toLocaleString()}\``, 

          inline: true 

        },

        { 

          name: '📂 DIRECTORY INFO', 

          value: `**Path:** \`${process.cwd()}\`\n**Platform:** \`${process.platform}\``, 

          inline: true 

        }

      )

      .setFooter({ text: `Authorized: ${interaction.user.username} | Data refreshes on command` })

      .setTimestamp();

    await interaction.reply({ embeds: [embed] });

  },

};

// Helper Function untuk merapikan waktu

function formatUptime(ms) {

  let s = Math.floor(ms / 1000);

  let m = Math.floor(s / 60);

  let h = Math.floor(m / 60);

  let d = Math.floor(h / 24);

  s %= 60; m %= 60; h %= 24;

  return `${d}d ${h}h ${m}m ${s}s`;

}