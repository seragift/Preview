const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');

module.exports = {

  data: new SlashCommandBuilder()

    .setName('slowmode')

    .setDescription('Mengatur jeda waktu (slowmode) pada channel tertentu')

    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels) // Hanya user dengan izin Kelola Channel

    .addChannelOption(option => 

      option.setName('channel')

        .setDescription('Channel yang ingin diatur slowmode-nya')

        .addChannelTypes(ChannelType.GuildText) // Hanya channel teks

        .setRequired(true))

    .addIntegerOption(option => 

      option.setName('durasi')

        .setDescription('Durasi jeda dalam detik (0 untuk mematikan)')

        .setRequired(true)

        .setMinValue(0)

        .setMaxValue(21600)), // Maksimal 6 jam sesuai batas Discord

  async execute(interaction) {

    const channel = interaction.options.getChannel('channel');

    const seconds = interaction.options.getInteger('durasi');

    try {

      await channel.setRateLimitPerUser(seconds);

      if (seconds === 0) {

        return interaction.reply({ 

          content: `✅ Slowmode di channel ${channel} telah **dimatikan**.`, 

          ephemeral: false 

        });

      }

      return interaction.reply({ 

        content: `✅ Berhasil mengatur slowmode di channel ${channel} menjadi **${seconds} detik**.`, 

        ephemeral: false 

      });

    } catch (error) {

      console.error(error);

      return interaction.reply({ 

        content: '❌ Gagal mengatur slowmode. Pastikan bot memiliki izin `Manage Channels`.', 

        ephemeral: true 

      });

    }

  },

};