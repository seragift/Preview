const {

  SlashCommandBuilder,

  EmbedBuilder

} = require('discord.js');

// 🔥 GLOBAL STORE (bisa dipakai file lain)

const couples = new Map(); // userId -> roleId

const blacklist = ['kontol','anjing','babi','ngentot'];

module.exports = {

  data: new SlashCommandBuilder()

    .setName('couple')

    .setDescription('Buat role couple 💖')

    .addUserOption(o =>

      o.setName('user1').setDescription('Orang pertama').setRequired(true))

    .addUserOption(o =>

      o.setName('user2').setDescription('Orang kedua').setRequired(true))

    .addStringOption(o =>

      o.setName('nama_role').setDescription('Nama role').setRequired(true)),

  async execute(interaction){

    const u1 = interaction.options.getUser('user1');

    const u2 = interaction.options.getUser('user2');

    const roleName = interaction.options.getString('nama_role');

    if(u1.bot || u2.bot)

      return interaction.reply({ content:"Ga bisa sama bot 😤", ephemeral:true });

    if(u1.id === u2.id)

      return interaction.reply({ content:"Ngapain sama diri sendiri 💀", ephemeral:true });

    // 🔥 blacklist

    const lower = roleName.toLowerCase();

    if(blacklist.some(w => lower.includes(w))){

      return interaction.reply({ content:"Nama role kotor 😤", ephemeral:true });

    }

    const guild = interaction.guild;

    try {

      // 🔥 hapus couple lama

      for(const userId of [u1.id, u2.id]){

        if(couples.has(userId)){

          const oldRoleId = couples.get(userId);

          const oldRole = guild.roles.cache.get(oldRoleId);

          if(oldRole){

            await oldRole.delete().catch(()=>{});

          }

          // hapus semua user yg punya role ini

          for(const [k,v] of couples){

            if(v === oldRoleId) couples.delete(k);

          }

        }

      }

      // 🔥 buat role baru

      const role = await guild.roles.create({

        name: `💖 ${roleName}`,

        color: 0xFF69B4,

        reason: 'Couple System'

      });

      const m1 = await guild.members.fetch(u1.id);

      const m2 = await guild.members.fetch(u2.id);

      await m1.roles.add(role);

      await m2.roles.add(role);

      // 🔥 simpan mapping

      couples.set(u1.id, role.id);

      couples.set(u2.id, role.id);

      await interaction.reply({

        embeds:[

          new EmbedBuilder()

            .setColor(0xFF69B4)

            .setTitle("💖 Couple Created")

            .setDescription(`${u1} ❤️ ${u2}\n\nRole: ${role}`)

        ]

      });

    } catch(err){

      console.error(err);

      return interaction.reply({ content:"Error bikin couple 😤", ephemeral:true });

    }

  }

};

// 🔥 PENTING BANGET (INI YANG LU KURANG)

module.exports.couples = couples;