const {

  SlashCommandBuilder,

  ActionRowBuilder,

  ButtonBuilder,

  ButtonStyle,

  PermissionFlagsBits

} = require('discord.js');

const db = require('../database/intro');

module.exports = {

  data: new SlashCommandBuilder()

    .setName('setintro')

    .setDescription('Setup intro panel')

    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {

    const guildId = interaction.guild.id;

    const channelId = interaction.channel.id;

    // 🔥 Cek data

    const data = db.prepare("SELECT * FROM intro WHERE guildId = ?")

      .get(guildId);

    if (!data) {

      db.prepare("INSERT INTO intro (guildId, channelId) VALUES (?, ?)")

        .run(guildId, channelId);

    } else {

      db.prepare("UPDATE intro SET channelId = ? WHERE guildId = ?")

        .run(channelId, guildId);

    }

    // 🎯 Button

    const row = new ActionRowBuilder().addComponents(

      new ButtonBuilder()

        .setCustomId('intro_start')

        .setLabel('Intro')

        .setStyle(ButtonStyle.Primary)

    );

    await interaction.reply({

      content: '✅ Panel intro berhasil diset!',

      ephemeral: true

    });

    await interaction.channel.send({

      content: '👋 Klik tombol di bawah untuk intro!',

      components: [row]

    });

  }

};