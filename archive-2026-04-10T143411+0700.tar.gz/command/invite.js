const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {

  data: new SlashCommandBuilder()

    .setName('invite')

    .setDescription('Membuat link undangan (invite) untuk server ini')

    .setDefaultMemberPermissions(PermissionFlagsBits.CreateInstantInvite)

    .addChannelOption(option => 

      option.setName('target_channel')

        .setDescription('Channel tujuan link invite (Default: channel ini)')

        .setRequired(false)

    )

    .addStringOption(option =>

      option.setName('durasi')

        .setDescription('Berapa lama link ini berlaku?')

        .setRequired(false)

        .addChoices(

          { name: '30 Menit', value: '1800' },

          { name: '1 Jam', value: '3600' },

          { name: '6 Jam', value: '21600' },

          { name: '12 Jam', value: '43200' },

          { name: '1 Hari', value: '86400' },

          { name: '7 Hari', value: '604800' },

          { name: 'Tanpa Batas (Never)', value: '0' },

        )

    )

    .addIntegerOption(option =>

      option.setName('max_user')

        .setDescription('Maksimal berapa kali link bisa digunakan?')

        .setRequired(false)

        .addChoices(

          { name: '1 Kali', value: 1 },

          { name: '5 Kali', value: 5 },

          { name: '10 Kali', value: 10 },

          { name: '25 Kali', value: 25 },

          { name: '50 Kali', value: 50 },

          { name: '100 Kali', value: 100 },

          { name: 'Tanpa Batas (Unlimited)', value: 0 },

        )

    ),

  async execute(interaction) {

    // Ambil input atau gunakan nilai default

    const channel = interaction.options.getChannel('target_channel') || interaction.channel;

    const maxAge = parseInt(interaction.options.getString('durasi') || '86400'); // Default 1 hari

    const maxUses = interaction.options.getInteger('max_user') || 0; // Default unlimited

    try {

      // Pastikan channel adalah TextChannel atau NewsChannel (bisa dibuat invite)

      if (!channel.isTextBased()) {

        return interaction.reply({ content: '❌ Link invite hanya bisa dibuat untuk channel teks!', ephemeral: true });

      }

      const invite = await channel.createInvite({

        maxAge: maxAge,

        maxUses: maxUses,

        unique: true,

        reason: `Dibuat oleh ${interaction.user.tag} via command /invite`

      });

      const embed = new EmbedBuilder()

        .setTitle('🎫 Link Undangan Berhasil Dibuat')

        .setColor('#5865F2')

        .setThumbnail(interaction.guild.iconURL())

        .addFields(

          { name: '🔗 Link Invite', value: `**${invite.url}**`, inline: false },

          { name: '📍 Channel Tujuan', value: `${channel}`, inline: true },

          { name: '⏳ Masa Berlaku', value: maxAge === 0 ? 'Selamanya' : `<t:${Math.floor(Date.now() / 1000) + maxAge}:R>`, inline: true },

          { name: '👥 Batas User', value: maxUses === 0 ? 'Tanpa Batas' : `${maxUses} Orang`, inline: true }

        )

        .setFooter({ text: `Dibuat oleh ${interaction.user.username}`, iconURL: interaction.user.displayAvatarURL() })

        .setTimestamp();

      await interaction.reply({ embeds: [embed] });

    } catch (error) {

      console.error('Error creating invite:', error);

      await interaction.reply({ content: '❌ Bot tidak memiliki izin untuk membuat link invite di channel tersebut.', ephemeral: true });

    }

  },

};