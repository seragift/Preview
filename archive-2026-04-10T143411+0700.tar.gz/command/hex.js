const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

const presetColors = [
    { name: 'Blurple', hex: '#5865F2' },
    { name: 'Greyple', hex: '#99AAB5' },
    { name: 'DarkButNotBlack', hex: '#2C2F33' },
    { name: 'NotQuiteBlack', hex: '#23272A' },
    { name: 'White', hex: '#FFFFFF' },
    { name: 'Green', hex: '#57F287' },
    { name: 'Yellow', hex: '#FEE75C' },
    { name: 'Fuchsia', hex: '#EB459E' },
    { name: 'Red', hex: '#ED4245' },
    { name: 'Orange', hex: '#FFA500' },
];

module.exports = {
    data: new SlashCommandBuilder()
        .setName('hex')
        .setDescription('Menampilkan semua warna Discord (preset + role server)'),

    async execute(interaction) {
        // Ambil semua warna role di server
        const serverRoles = interaction.guild.roles.cache
            .filter(r => r.color !== 0) // hanya yang punya warna
            .map(r => ({ name: r.name, hex: `#${r.color.toString(16).padStart(6, '0')}` }));

        // Gabungkan preset + role
        const allColors = [...presetColors, ...serverRoles];

        // Pagination sederhana (10 warna per halaman)
        let page = 0;
        const totalPages = Math.ceil(allColors.length / 10);

        const generateEmbed = (page) => {
            const start = page * 10;
            const end = start + 10;
            const colors = allColors.slice(start, end);

            return new EmbedBuilder()
                .setTitle(`Daftar Warna Discord (${page + 1}/${totalPages})`)
                .setDescription(colors.map(c => `**${c.name}**: \`${c.hex}\``).join('\n'))
                .setColor(colors[0] ? colors[0].hex : '#5865F2');
        };

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('prev')
                    .setLabel('◀️ Sebelumnya')
                    .setStyle(ButtonStyle.Primary)
                    .setDisabled(page === 0),
                new ButtonBuilder()
                    .setCustomId('next')
                    .setLabel('▶️ Berikutnya')
                    .setStyle(ButtonStyle.Primary)
                    .setDisabled(page === totalPages - 1)
            );

        const message = await interaction.reply({ embeds: [generateEmbed(page)], components: [row], fetchReply: true });

        const collector = message.createMessageComponentCollector({ time: 60000 });

        collector.on('collect', i => {
            if (i.user.id !== interaction.user.id) return i.reply({ content: 'Ini bukan untukmu!', ephemeral: true });

            if (i.customId === 'prev') page--;
            if (i.customId === 'next') page++;

            i.update({ embeds: [generateEmbed(page)], components: [new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('prev')
                        .setLabel('◀️ Sebelumnya')
                        .setStyle(ButtonStyle.Primary)
                        .setDisabled(page === 0),
                    new ButtonBuilder()
                        .setCustomId('next')
                        .setLabel('▶️ Berikutnya')
                        .setStyle(ButtonStyle.Primary)
                        .setDisabled(page === totalPages - 1)
                )
            ] });
        });
    },
};