const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

const db = require('../database/database');

module.exports = {

  data: new SlashCommandBuilder()

    .setName('whitelist')

    .setDescription('Kelola whitelist channel')

    .addChannelOption(option => option.setName('channel').setDescription('Pilih channel').setRequired(true))

    .addStringOption(option => option.setName('action').setDescription('Add atau Remove').addChoices(

        { name: 'Add', value: 'add' },

        { name: 'Remove', value: 'remove' }

    ).setRequired(true))

    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {

    const channel = interaction.options.getChannel('channel');

    const action = interaction.options.getString('action');

    if (action === 'add') {

      db.prepare('INSERT OR IGNORE INTO whitelist (channelId, guildId) VALUES (?, ?)')

        .run(channel.id, interaction.guild.id);

      await interaction.reply(`Channel ${channel} ditambahkan ke whitelist.`);

    } else {

      db.prepare('DELETE FROM whitelist WHERE channelId = ?').run(channel.id);

      await interaction.reply(`Channel ${channel} dihapus dari whitelist.`);

    }

  },

};