const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

const db = require('../database/database');

module.exports = {

  data: new SlashCommandBuilder()

    .setName('setlog')

    .setDescription('Mengatur channel untuk log moderasi')

    .addChannelOption(option => 

      option.setName('channel')

        .setDescription('Pilih channel log')

        .setRequired(true))

    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {

    const channel = interaction.options.getChannel('channel');

    const guildId = interaction.guild.id;

    try {

      // Cek apakah data guild sudah ada di settings

      const row = db.prepare('SELECT guildId FROM settings WHERE guildId = ?').get(guildId);

      

      if (!row) {

        // Jika belum ada, buat baris baru

        db.prepare('INSERT INTO settings (guildId, logChannel) VALUES (?, ?)').run(guildId, channel.id);

      } else {

        // Jika sudah ada, update saja

        db.prepare('UPDATE settings SET logChannel = ? WHERE guildId = ?').run(channel.id, guildId);

      }

      await interaction.reply({ content: `✅ Channel log moderasi berhasil diatur ke <#${channel.id}>`, ephemeral: true });

    } catch (error) {

      console.error(error);

      await interaction.reply({ content: '❌ Terjadi kesalahan database saat mengatur log.', ephemeral: true });

    }

  },

};