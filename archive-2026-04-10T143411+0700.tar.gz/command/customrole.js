const {
  SlashCommandBuilder
} = require('discord.js');

const db = require('../database/customrole');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('customrole')
    .setDescription('Buat custom role (booster only)')

    // 🏷️ Nama
    .addStringOption(o =>
      o.setName('nama')
        .setDescription('Nama role')
        .setRequired(true))

    // 🎨 HEX
    .addStringOption(o =>
      o.setName('hex')
        .setDescription('Warna HEX (#ff0000)')
        .setRequired(true))

    // 🎭 STYLE
    .addStringOption(o =>
      o.setName('style')
        .setDescription('Style role')
        .setRequired(true)
        .addChoices(
          { name: 'Solid', value: 'solid' },
          { name: 'Gradient', value: 'gradient' },
          { name: 'Holographic', value: 'holo' }
        )),

  async execute(interaction) {
    const member = interaction.member;
    const nama = interaction.options.getString('nama');
    const hexInput = interaction.options.getString('hex');
    const style = interaction.options.getString('style');

    // ❌ bukan booster
    if (!member.premiumSince) {
      return interaction.reply({
        content: '❌ Hanya untuk booster!',
        flags: 64
      });
    }

    // 📊 ambil boost
    const row = db.prepare(`
      SELECT boosts FROM custom_roles WHERE user_id = ?
    `).get(member.id);

    const boostCount = row?.boosts || 0;

    if (boostCount <= 0) {
      return interaction.reply({
        content: '❌ Boost tidak terdeteksi!',
        flags: 64
      });
    }

    // 📊 limit role
    const used = db.prepare(`
      SELECT COUNT(*) as total FROM custom_roles 
      WHERE user_id = ? AND role_id IS NOT NULL
    `).get(member.id).total;

    if (used >= boostCount) {
      return interaction.reply({
        content: `❌ Limit habis! (${used}/${boostCount})`,
        flags: 64
      });
    }

    // 🎨 VALIDASI HEX
    if (!/^#?[0-9A-Fa-f]{6}$/.test(hexInput)) {
      return interaction.reply({
        content: '❌ HEX tidak valid! Contoh: #ff0000',
        flags: 64
      });
    }

    const colorFinal = hexInput.startsWith('#') ? hexInput : `#${hexInput}`;

    // 🎭 STYLE LOGIC
    let finalName = nama;

    if (style === 'gradient') {
      if (boostCount < w) {
        return interaction.reply({
          content: '❌ Gradient butuh 2 boost!',
          flags: 64
        });
      }
      finalName = `✦ ${nama} ✦`;
    }

    if (style === 'holo') {
      if (boostCount < 2) {
        return interaction.reply({
          content: '❌ Holographic butuh 2 boost!',
          flags: 64
        });
      }
      finalName = `🌈 ${nama} ✨`;
    }

    // 🚀 CREATE ROLE
    try {
      const role = await interaction.guild.roles.create({
        name: finalName,
        color: colorFinal,
        reason: `Custom role by ${interaction.user.tag}`
      });

      await member.roles.add(role);

      db.prepare(`
        INSERT INTO custom_roles (user_id, role_id, boosts)
        VALUES (?, ?, ?)
      `).run(member.id, role.id, boostCount);

      return interaction.reply({
        content: `✅ Role dibuat: <@&${role.id}>
🎨 HEX: ${colorFinal}
🎭 Style: ${style}
📊 (${used + 1}/${boostCount})`
      });

    } catch (e) {
      console.error(e);
      return interaction.reply({
        content: '❌ Gagal membuat role!',
        flags: 64
      });
    }
  }
};