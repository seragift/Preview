const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

const db = require('../database/database');

module.exports = {

  data: new SlashCommandBuilder()

    .setName('antitoxic')

    .setDescription('Aktifkan atau matikan sistem Anti-Toxic')

    .addBooleanOption(option => 

      option.setName('status')

        .setDescription('True untuk ON, False untuk OFF')

        .setRequired(true))

    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  

  async execute(interaction) {

    const status = interaction.options.getBoolean('status') ? 1 : 0;

    const guildId = interaction.guild.id;

    // Cek apakah data guild sudah ada

    const row = db.prepare('SELECT * FROM settings WHERE guildId = ?').get(guildId);

    if (!row) {

      db.prepare('INSERT INTO settings (guildId, antiToxic) VALUES (?, ?)').run(guildId, status);

    } else {

      db.prepare('UPDATE settings SET antiToxic = ? WHERE guildId = ?').run(status, guildId);

    }

    await interaction.reply({

      content: `✅ **Anti-Toxic** telah di**${status === 1 ? 'aktifkan' : 'matikan'}**.`,

      ephemeral: true

    });

  },

};