const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

const db = require('../database/database');

module.exports = {

  data: new SlashCommandBuilder()

    .setName('roletime')

    .setDescription('Memberikan role sementara kepada member')

    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)

    .addUserOption(opt => opt.setName('target').setDescription('Member tujuan').setRequired(true))

    .addRoleOption(opt => opt.setName('role').setDescription('Role yang diberikan').setRequired(true))

    .addIntegerOption(opt => 

      opt.setName('durasi')

        .setDescription('Durasi dalam hari (1-30)')

        .setRequired(true)

        .setMinValue(1)

        .setMaxValue(30)),

  async execute(interaction) {

    const target = interaction.options.getMember('target');

    const role = interaction.options.getRole('role');

    const days = interaction.options.getInteger('durasi');

    const guildId = interaction.guild.id;

    // Hitung waktu berakhir (Timestamp milidetik)

    const endTime = Date.now() + (days * 24 * 60 * 60 * 1000);

    try {

      // Berikan Role

      await target.roles.add(role);

      // Simpan ke Database

      db.prepare('INSERT OR REPLACE INTO role_timer (guildId, userId, roleId, endTime) VALUES (?, ?, ?, ?)')

        .run(guildId, target.id, role.id, endTime);

      return interaction.reply({ 

        content: `✅ Berhasil memberikan role **${role.name}** kepada **${target.user.tag}** selama **${days} hari**.`, 

        ephemeral: false 

      });

    } catch (error) {

      console.error(error);

      return interaction.reply({ content: '❌ Gagal memberikan role. Pastikan posisi role bot lebih tinggi dari role tersebut.', ephemeral: true });

    }

  },

};