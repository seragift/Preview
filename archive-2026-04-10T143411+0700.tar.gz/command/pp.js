const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {

  data: new SlashCommandBuilder()

    .setName('pp')

    .setDescription('Menampilkan foto profil user (Tag atau Tempel ID)')

    .addUserOption(option => 

      option.setName('target')

        .setDescription('Tag user atau tempel ID User di sini')

        .setRequired(false)),

  async execute(interaction) {

    // Ambil user dari opsi target, jika kosong ambil user yang mengetik command

    const user = interaction.options.getUser('target') || interaction.user;

    // Membuat Embed untuk menampilkan foto

    const embed = new EmbedBuilder()

      .setTitle(`Foto Profil: ${user.tag}`)

      .setDescription(`[Klik di sini untuk Link Gambar](${user.displayAvatarURL({ dynamic: true, size: 2048 })})`)

      .setImage(user.displayAvatarURL({ dynamic: true, size: 1024 })) // Menampilkan foto

      .setColor('Blue')

      .setFooter({ 

          text: `Request oleh: ${interaction.user.username}`, 

          iconURL: interaction.user.displayAvatarURL() 

      })

      .setTimestamp();

    try {

      await interaction.reply({ embeds: [embed] });

    } catch (error) {

      console.error(error);

      await interaction.reply({ 

        content: '❌ Gagal mengambil foto profil user tersebut.', 

        ephemeral: true 

      });

    }

  },

};