const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

const db = require('../database/database');

module.exports = {

  data: new SlashCommandBuilder()

    .setName('antilink')

    .setDescription('Aktifkan/Matikan Anti-Link')

    .addBooleanOption(option => option.setName('status').setDescription('True = On, False = Off').setRequired(true))

    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {

    const status = interaction.options.getBoolean('status') ? 1 : 0;

    

    db.prepare('INSERT OR REPLACE INTO settings (guildId, antiLink) VALUES (?, ?)')

      .run(interaction.guild.id, status);

    await interaction.reply(`Anti-Link berhasil di ${status === 1 ? 'Aktifkan' : 'Matikan'}.`);

  },

};