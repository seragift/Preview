const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {

  data: new SlashCommandBuilder()

    .setName('chat')

    .setDescription('Mengirim pesan melalui bot ke channel tertentu')

    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)

    .addChannelOption(option => 

      option.setName('channel')

        .setDescription('Channel tujuan')

        .setRequired(true))

    .addStringOption(option => 

      option.setName('pesan')

        .setDescription('Isi pesan yang akan dikirim')

        .setRequired(true))

    .addAttachmentOption(option => 

      option.setName('gambar')

        .setDescription('Lampirkan gambar (opsional)')

        .setRequired(false)),

  async execute(interaction) {

    const channel = interaction.options.getChannel('channel');

    const content = interaction.options.getString('pesan');

    const attachment = interaction.options.getAttachment('gambar');

    // Pastikan channel adalah channel teks

    if (!channel.isTextBased()) {

      return interaction.reply({ 

        content: '❌ Silakan pilih channel teks!', 

        ephemeral: true 

      });

    }

    try {

      // Menyiapkan data kiriman

      const payload = {

        content: content.replace(/\\n/g, '\n'), // Mendukung baris baru

      };

      if (attachment) {

        payload.files = [attachment.url];

      }

      // Kirim pesan ke channel target

      await channel.send(payload);

      return interaction.reply({ 

        content: `✅ Pesan berhasil dikirim ke ${channel}`, 

        ephemeral: true 

      });

    } catch (error) {

      console.error('Error executing chat command:', error);

      return interaction.reply({ 

        content: '❌ Gagal mengirim pesan. Pastikan bot memiliki izin untuk melihat dan mengirim pesan di channel tersebut.', 

        ephemeral: true 

      });

    }

  },

};