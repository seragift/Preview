const { SlashCommandBuilder, EmbedBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {

  data: new SlashCommandBuilder()

    .setName('setpanelinvite')

    .setDescription('Mengirim panel tombol untuk membuat link invite')

    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)

    .addChannelOption(option => 

      option.setName('channel')

        .setDescription('Channel tempat panel akan dikirim')

        .setRequired(true)

    ),

  async execute(interaction) {

    const targetChannel = interaction.options.getChannel('channel');

    const embed = new EmbedBuilder()

      .setTitle('🎫 Buat Link Undangan Server')

      .setDescription(

        'Klik tombol di bawah ini untuk mendapatkan link invite pribadi kamu!\n\n' +

        '🔹 **Durasi:** Selamanya (Never)\n' +

        '🔹 **Penggunaan:** Tanpa Batas (Unlimited)'

      )

      .setColor('#5865F2')

      .setThumbnail(interaction.guild.iconURL())

      .setFooter({ text: 'Gunakan link ini untuk mengajak temanmu bergabung!' });

    const btn = new ButtonBuilder()

      .setCustomId('generate_invite')

      .setLabel('Buat Link Invite')

      .setEmoji('🔗')

      .setStyle(ButtonStyle.Primary);

    const row = new ActionRowBuilder().addComponents(btn);

    try {

      await targetChannel.send({ embeds: [embed], components: [row] });

      return interaction.reply({ content: `✅ Panel invite berhasil dikirim ke ${targetChannel}`, ephemeral: true });

    } catch (error) {

      console.error(error);

      return interaction.reply({ content: '❌ Gagal mengirim panel. Pastikan bot memiliki izin kirim pesan di channel tersebut.', ephemeral: true });

    }

  },

};