const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

const db = require('../database/database');

module.exports = {

  data: new SlashCommandBuilder()

    .setName('stats')

    .setDescription('Melihat statistik aktivitas server hari ini')

    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {

    const guildId = interaction.guild.id;

    const dateStr = new Date().toLocaleDateString('en-CA', {

      timeZone: 'Asia/Jakarta'

    });

    try {

      const joins = db.prepare(

        "SELECT COUNT(*) as count FROM server_events WHERE guildId = ? AND type = 'JOIN' AND date = ?"

      ).get(guildId, dateStr)?.count || 0;

      const outs = db.prepare(

        "SELECT COUNT(*) as count FROM server_events WHERE guildId = ? AND type = 'LEAVE' AND date = ?"

      ).get(guildId, dateStr)?.count || 0;

      const net = joins - outs;

      const msgData = db.prepare(

        'SELECT SUM(messageCount) as total FROM daily_stats WHERE guildId = ? AND date = ?'

      ).get(guildId, dateStr);

      const totalMsgs = msgData?.total || 0;

      const topMembers = db.prepare(`

        SELECT userId, SUM(messageCount) as count

        FROM daily_stats

        WHERE guildId = ? AND date = ?

        GROUP BY userId

        ORDER BY count DESC

        LIMIT 3

      `).all(guildId, dateStr);

      const topChannel = db.prepare(`

        SELECT channelId, SUM(messageCount) as count

        FROM daily_stats

        WHERE guildId = ? AND date = ?

        GROUP BY channelId

        ORDER BY count DESC

        LIMIT 1

      `).get(guildId, dateStr);

      const topHour = db.prepare(`

        SELECT hour, SUM(messageCount) as count

        FROM daily_stats

        WHERE guildId = ? AND date = ?

        GROUP BY hour

        ORDER BY count DESC

        LIMIT 1

      `).get(guildId, dateStr);

      const embed = new EmbedBuilder()

        .setTitle(`📈 Statistik Server (${dateStr})`)

        .setColor('Blue')

        .setThumbnail(interaction.guild.iconURL())

        .addFields(

          {

            name: '👥 Update Member',

            value: `📥 Join: **${joins}**\n📤 Out: **${outs}**\n📊 Net: **${net}**`,

            inline: true

          },

          {

            name: '💬 Total Pesan',

            value: `**${totalMsgs.toLocaleString()}** Pesan`,

            inline: true

          },

          {

            name: '📢 Channel Teraktif',

            value: topChannel ? `<#${topChannel.channelId}> (${topChannel.count} chat)` : '`-`',

            inline: true

          },

          {

            name: '🏆 Top 3 Aktif',

            value: topMembers.length > 0

              ? topMembers.map((m, i) => `**${i + 1}.** <@${m.userId}> — ${m.count} chat`).join('\n')

              : '*Belum ada aktivitas chat*',

            inline: false

          },

          {

            name: '⏰ Jam Teraktif',

            value: topHour ? `Pukul ${topHour.hour}:00 dengan ${topHour.count} pesan` : '`-`',

            inline: false

          }

        )

        .setFooter({ text: 'Data diperbarui secara real-time' })

        .setTimestamp();

      await interaction.reply({ embeds: [embed] });

    } catch (error) {

      console.error('Error stats command:', error);

      await interaction.reply({

        content: '❌ Gagal mengambil data statistik.',

        ephemeral: true

      });

    }

  }

};