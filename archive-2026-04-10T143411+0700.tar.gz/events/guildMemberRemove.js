const db = require('../database/database');

module.exports = {

  name: 'guildMemberRemove',

  async execute(member) {

    const date = new Date().toLocaleDateString('en-CA', {

      timeZone: 'Asia/Jakarta'

    });

    try {

      db.prepare(`

        INSERT INTO server_events (guildId,type,date)

        VALUES (?,?,?)

      `).run(member.guild.id,'LEAVE',date);

    } catch (err) {

      console.error("LEAVE ERROR:", err);

    }

  }

};