const { Events, EmbedBuilder } = require('discord.js');

module.exports = {

  name: Events.InteractionCreate,

  async execute(interaction) {

    // --- 1. PENANGANAN SLASH COMMANDS ---

    if (interaction.isChatInputCommand()) {

      const command = interaction.client.commands.get(interaction.commandName);

      if (!command) {

        console.error(`Tidak ada command yang cocok dengan ${interaction.commandName}.`);

        return;

      }

      try {

        await command.execute(interaction);

      } catch (error) {

        console.error(`Error saat menjalankan command ${interaction.commandName}:`, error);

        

        const errorMessage = { content: 'Terjadi kesalahan saat menjalankan perintah ini!', ephemeral: true };

        if (interaction.replied || interaction.deferred) {

          await interaction.followUp(errorMessage);

        } else {

          await interaction.reply(errorMessage);

        }

      }

    }

    // --- 2. PENANGANAN BUTTONS (Panel Invite) ---

    else if (interaction.isButton()) {

      if (interaction.customId === 'generate_invite') {

        try {

          // Membuat invite: Selamanya & Tanpa Batas

          const invite = await interaction.channel.createInvite({

            maxAge: 0,

            maxUses: 0,

            unique: true,

            reason: `Dibuat oleh ${interaction.user.tag} melalui Panel Invite`

          });

          // Membuat Embed untuk hasil link

          const inviteEmbed = new EmbedBuilder()

            .setTitle('🎫 Link Undangan Pribadi')

            .setDescription(`Halo ${interaction.user}, ini adalah link invite khusus yang bisa kamu gunakan untuk mengajak temanmu bergabung!`)

            .setColor('#5865F2')

            .addFields(

              { name: '🔗 Link Invite', value: `**${invite.url}**`, inline: false },

              { name: '⏳ Masa Berlaku', value: 'Selamanya (Never)', inline: true },

              { name: '👥 Batas Pakai', value: 'Tanpa Batas', inline: true }

            )

            .setThumbnail(interaction.guild.iconURL({ dynamic: true }))

            .setFooter({ text: 'Terima kasih telah membantu mengembangkan komunitas!' })

            .setTimestamp();

          // Kirim balasan ephemeral dalam bentuk Embed

          await interaction.reply({

            embeds: [inviteEmbed],

            ephemeral: true

          });

        } catch (error) {

          console.error('Gagal membuat invite via tombol:', error);

          await interaction.reply({ 

            content: '❌ Bot tidak memiliki izin untuk membuat link invite di channel ini.', 

            ephemeral: true 

          });

        }

      }

    }

  },

};