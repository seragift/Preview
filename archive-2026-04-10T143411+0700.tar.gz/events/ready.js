const { Events } = require('discord.js');

const startCron = require('../utils/cronJob');

module.exports = {

  name: Events.ClientReady,

  once: true,

  execute(client) {

    console.log(`✅ Bot online sebagai ${client.user.tag}`);

    

    // Jalankan jadwal laporan otomatis jam 00.00

    startCron(client);

  },

};