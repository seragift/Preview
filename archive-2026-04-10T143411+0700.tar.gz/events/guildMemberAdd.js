const db = require('../database/database');

module.exports = {

  name: 'guildMemberAdd',

  async execute(member) {

    const date = new Date().toLocaleDateString('en-CA', {

      timeZone: 'Asia/Jakarta'

    });

    try {

      db.prepare(`

        INSERT INTO server_events (guildId,type,date)

        VALUES (?,?,?)

      `).run(member.guild.id,'JOIN',date);

    } catch (err) {

      console.error("JOIN ERROR:", err);

    }

  }

};