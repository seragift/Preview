const {

  Events,

  ModalBuilder,

  TextInputBuilder,

  TextInputStyle,

  ActionRowBuilder,

  ButtonBuilder,

  ButtonStyle,

  AttachmentBuilder,

  EmbedBuilder

} = require('discord.js');

const { createCanvas, loadImage } = require('canvas');

const db = require('../database/intro');

// 🔥 CONFIGURATION

const ROLE_CEWEK_ID = '1477244626963271710'; // GANTI PAKE ID ROLE CEWEK LU

module.exports = {

  name: Events.InteractionCreate,

  async execute(interaction) {

    if (interaction.isButton() && interaction.customId === 'intro_start') {

      const modal = new ModalBuilder()

        .setCustomId('intro_modal')

        .setTitle('IDENTITY CARD FORM');

      const inputs = [

        { id: 'nama', label: 'Name (Letters Only)', placeholder: 'Example: Rosanne Park' },

        { id: 'age', label: 'Age (Numbers Only)', placeholder: 'Example: 24' },

        { id: 'gender', label: 'Gender', placeholder: 'Example: Male / Female / Girls' },

        { id: 'origin', label: 'Origin (Letters Only)', placeholder: 'Example: South Korea' }

      ];

      const fields = inputs.map(i =>

        new ActionRowBuilder().addComponents(

          new TextInputBuilder()

            .setCustomId(i.id)

            .setLabel(i.label)

            .setPlaceholder(i.placeholder)

            .setStyle(TextInputStyle.Short)

            .setRequired(true)

        )

      );

      modal.addComponents(...fields);

      return interaction.showModal(modal);

    }

    if (interaction.isModalSubmit() && interaction.customId === 'intro_modal') {

      const { user, guild, fields, member } = interaction;

      await interaction.deferReply({ ephemeral: true });

      const nama = fields.getTextInputValue('nama');

      const age = fields.getTextInputValue('age');

      const genderRaw = fields.getTextInputValue('gender');

      const origin = fields.getTextInputValue('origin');

      // --- VALIDASI ---

      const alphaRegex = /^[a-zA-Z\s,]+$/;

      const numRegex = /^[0-9]+$/;

      if (!alphaRegex.test(nama)) return interaction.editReply({ content: '❌ Nama ga boleh ada angka/simbol!' });

      if (!numRegex.test(age)) return interaction.editReply({ content: '❌ Age harus angka doang!' });

      if (!alphaRegex.test(origin)) return interaction.editReply({ content: '❌ Origin ga boleh ada simbol aneh!' });

      const existing = db.prepare("SELECT * FROM intro_users WHERE userId = ? AND guildId = ?").get(user.id, guild.id);

      if (existing) return interaction.editReply({ content: '❌ Lu udah pernah bikin intro!' });

      // --- DETEKSI GENDER & TEMA ---

      const femaleKeywords = ['fem', 'perempuan', 'cewek', 'cewe', 'girl', 'girls', 'woman'];

      const isFemale = femaleKeywords.some(kw => genderRaw.toLowerCase().includes(kw));

      

      let themeColor = isFemale ? '#d81b60' : '#1e88e5'; 

      let embedColor = isFemale ? 0xd81b60 : 0x1e88e5; 

      let bgColor = isFemale ? '#fce4ec' : '#f0f7ff';

      // --- LOGIKA AUTO ROLE ---

      if (isFemale) {

        const role = guild.roles.cache.get(ROLE_CEWEK_ID);

        if (role) await member.roles.add(role).catch(e => console.error("Gagal add role:", e));

      }

      db.prepare(`INSERT INTO intro_users (userId, guildId, nama, gender, asal) VALUES (?, ?, ?, ?, ?)`).run(user.id, guild.id, nama, genderRaw, origin);

      const setting = db.prepare("SELECT * FROM intro WHERE guildId = ?").get(guild.id);

      const channel = guild.channels.cache.get(setting?.channelId);

      if (!channel) return;

      const canvas = createCanvas(1000, 600);

      const ctx = canvas.getContext('2d');

      // Base Canvas

      ctx.fillStyle = bgColor; 

      ctx.beginPath(); ctx.roundRect(0, 0, 1000, 600, 50); ctx.fill();

      ctx.fillStyle = themeColor;

      ctx.beginPath(); ctx.roundRect(0, 0, 1000, 110, [50, 50, 0, 0]); ctx.fill();

      // Header

      ctx.fillStyle = '#ffffff';

      ctx.font = 'italic bold 55px sans-serif'; 

      ctx.textAlign = 'left';

      ctx.fillText(nama.length > 15 ? nama.substring(0, 15) + '..' : nama, 70, 75); 

      ctx.textAlign = 'right';

      ctx.font = 'bold 22px sans-serif';

      ctx.fillText("MEMBER IDENTITY CARD", 930, 70);

      // Stars Decor

      const drawStar = (x, y, radius) => {

        ctx.fillStyle = themeColor; ctx.beginPath();

        for (let i = 0; i < 5; i++) {

          ctx.lineTo(Math.cos((18 + i * 72) / 180 * Math.PI) * radius + x, -Math.sin((18 + i * 72) / 180 * Math.PI) * radius + y);

          ctx.lineTo(Math.cos((54 + i * 72) / 180 * Math.PI) * radius / 2 + x, -Math.sin((54 + i * 72) / 180 * Math.PI) * radius / 2 + y);

        }

        ctx.closePath(); ctx.fill();

      };

      for (let i = 0; i < 7; i++) { drawStar(60, 160 + (i * 62), 14); drawStar(940, 160 + (i * 62), 14); }

      for (let i = 0; i < 15; i++) { drawStar(100 + (i * 57), 565, 14); }

      // Avatar Fix

      const avX = 110, avY = 150, avW = 280, avH = 380;

      const avatar = await loadImage(user.displayAvatarURL({ extension: 'png', size: 512 }));

      const aspectRatio = avatar.width / avatar.height;

      const targetRatio = avW / avH;

      let sw, sh, sx, sy;

      if (aspectRatio > targetRatio) { sw = avatar.height * targetRatio; sh = avatar.height; sx = (avatar.width - sw) / 2; sy = 0; }

      else { sw = avatar.width; sh = avatar.width / targetRatio; sx = 0; sy = (avatar.height - sh) / 2; }

      ctx.strokeStyle = themeColor; ctx.lineWidth = 8; ctx.strokeRect(avX, avY, avW, avH);

      ctx.drawImage(avatar, sx, sy, sw, sh, avX, avY, avW, avH);

      // --- Text Wrapping Logic ---

      const startX = 440, endX = 880, maxWidth = 350;

      let drawY = 200;

      const wrapText = (text, maxWidth) => {

        const words = text.split(' ');

        const lines = [];

        let currentLine = words[0];

        for (let i = 1; i < words.length; i++) {

          if (ctx.measureText(currentLine + " " + words[i]).width < maxWidth) {

            currentLine += " " + words[i];

          } else {

            lines.push(currentLine);

            currentLine = words[i];

          }

        }

        lines.push(currentLine);

        return lines;

      };

      const addRow = (label, value) => {

        ctx.textAlign = 'left';

        ctx.fillStyle = themeColor;

        ctx.font = 'bold 22px sans-serif';

        ctx.fillText(label, startX, drawY);

        ctx.textAlign = 'right';

        ctx.font = 'bold 28px sans-serif';

        const lines = wrapText(value.toUpperCase(), maxWidth);

        lines.forEach((line, index) => { ctx.fillText(line, endX, drawY + (index * 32)); });

        ctx.beginPath();

        ctx.strokeStyle = themeColor; ctx.lineWidth = 2;

        const lineOffset = lines.length > 1 ? (lines.length * 28) : 12;

        ctx.moveTo(startX, drawY + lineOffset); ctx.lineTo(endX, drawY + lineOffset);

        ctx.stroke();

        drawY += (lines.length > 1 ? (lines.length * 45) : 90);

      };

      addRow('Name', nama);

      addRow('Age', `${age}`);

      addRow('Gender', genderRaw);

      addRow('Origin', origin);

      // Finalize

      const attachment = new AttachmentBuilder(canvas.toBuffer(), { name: 'id-card.png' });

      const embed = new EmbedBuilder()

        .setTitle('✨ New Identity Card Verified')

        .setDescription(`Selamat <@${user.id}>! intro kamu telah berhasil dibuat.`)

        .setColor(embedColor)

        .setImage('attachment://id-card.png')

        .setFooter({ text: `${nama}`, iconURL: user.displayAvatarURL() });

      const btnRow = new ActionRowBuilder().addComponents(

        new ButtonBuilder().setCustomId('intro_start').setLabel('Intro').setStyle(ButtonStyle.Primary)

      );

      await interaction.editReply({ content: '✅ Intro telah berhasil dibuat!' });

      await channel.send({ embeds: [embed], files: [attachment], components: [btnRow] });

    }

  }

};