const db = require('../database/customrole');
const config = require('../config.json');

module.exports = {
  name: 'guildMemberUpdate',

  async execute(oldMember, newMember) {

    const before = oldMember.premiumSince;
    const after = newMember.premiumSince;

    const channel = newMember.guild.channels.cache.get(config.boostLogChannelId);

    // 🚀 BOOST MASUK
    if (!before && after) {

      const row = db.prepare(`
        SELECT boosts FROM custom_roles WHERE user_id = ?
      `).get(newMember.id);

      const boosts = row ? row.boosts + 1 : 1;

      db.prepare(`
        INSERT OR REPLACE INTO custom_roles (user_id, boosts)
        VALUES (?, ?)
      `).run(newMember.id, boosts);

      if (channel) {
        channel.send({
          embeds: [{
            color: 0x00ff00,
            title: '🚀 Boost Detected',
            description: `👤 User: <@${newMember.id}>
🔥 Total Boost: ${boosts}

💎 **Booster System**
Setiap 1x boost memberikan 1 custom role.
Semakin banyak boost yang kamu berikan, semakin banyak role yang bisa kamu buat.`,
            timestamp: new Date()
          }]
        });
      }
    }

    // ❌ UNBOOST
    if (before && !after) {

      db.prepare(`
        UPDATE custom_roles SET boosts = boosts - 1 WHERE user_id = ?
      `).run(newMember.id);

      if (channel) {
        channel.send({
          embeds: [{
            color: 0xff0000,
            title: '❌ Boost Removed',
            description: `👤 User: <@${newMember.id}>`,
            timestamp: new Date()
          }]
        });
      }
    }
  }
};