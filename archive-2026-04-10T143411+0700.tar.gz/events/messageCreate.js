const { Events } = require('discord.js');

const statsCollector = require('../utils/statsCollector');

const messageHandler = require('../utils/messageHandler');



module.exports = {

  name: Events.MessageCreate,

  async execute(message) {

    if (message.author.bot || !message.guild) return;

    // 1. Sistem AFK (cek mention + remove AFK)

    
    // 2. Catat statistik harian (pesan, jam aktif, dll)

    statsCollector.recordMessage(message);

    // 3. Jalankan handler moderasi (Anti-Link, Anti-Toxic, Translate)

    await messageHandler(message);

  },

};