const { SlashCommandBuilder, EmbedBuilder, AttachmentBuilder } = require('discord.js');

const { createCanvas, loadImage } = require('canvas');

const db = require('../database/intro');

module.exports = {

  data: new SlashCommandBuilder()

    .setName('intro')

    .setDescription('Lihat kartu intro kamu atau orang lain')

    .addUserOption(option =>

      option.setName('target')

        .setDescription('User yang ingin dicek introsunya')

        .setRequired(false)

    ),

  async execute(interaction) {

    const target = interaction.options.getUser('target') || interaction.user;

    const guildId = interaction.guild.id;

    const data = db.prepare(

      "SELECT * FROM intro_users WHERE userId = ? AND guildId = ?"

    ).get(target.id, guildId);

    if (!data) {

      return interaction.reply({

        content: `❌ ${target.id === interaction.user.id ? 'Kamu' : 'User tersebut'} belum membuat kartu intro!`,

        ephemeral: true

      });

    }

    await interaction.deferReply();

    const canvas = createCanvas(1000, 600);

    const ctx = canvas.getContext('2d');

    const femaleKeywords = ['fem', 'perempuan', 'cewek', 'cewe', 'girl', 'girls', 'woman'];

    const isFemale = femaleKeywords.some(kw => data.gender.toLowerCase().includes(kw));

    

    const themeColor = isFemale ? '#d81b60' : '#1e88e5'; 

    const embedColor = isFemale ? 0xd81b60 : 0x1e88e5; 

    const bgColor = isFemale ? '#fce4ec' : '#f0f7ff';

    // 1. Background

    ctx.fillStyle = bgColor; 

    ctx.beginPath(); ctx.roundRect(0, 0, 1000, 600, 50); ctx.fill();

    // 2. Header

    ctx.fillStyle = themeColor;

    ctx.beginPath(); ctx.roundRect(0, 0, 1000, 110, [50, 50, 0, 0]); ctx.fill();

    // 3. Nama di Header

    ctx.fillStyle = '#ffffff';

    ctx.font = 'italic bold 55px sans-serif'; 

    ctx.textAlign = 'left';

    ctx.fillText(data.nama.length > 15 ? data.nama.substring(0, 15) + '..' : data.nama, 70, 75); 

    

    ctx.textAlign = 'right';

    ctx.font = 'bold 22px sans-serif';

    ctx.fillText("MEMBER IDENTITY CARD", 930, 70);

    // 4. Bintang

    const drawStar = (x, y, radius) => {

      ctx.fillStyle = themeColor; ctx.beginPath();

      for (let i = 0; i < 5; i++) {

        ctx.lineTo(Math.cos((18 + i * 72) / 180 * Math.PI) * radius + x, -Math.sin((18 + i * 72) / 180 * Math.PI) * radius + y);

        ctx.lineTo(Math.cos((54 + i * 72) / 180 * Math.PI) * radius / 2 + x, -Math.sin((54 + i * 72) / 180 * Math.PI) * radius / 2 + y);

      }

      ctx.closePath(); ctx.fill();

    };

    for (let i = 0; i < 7; i++) { drawStar(60, 160 + (i * 62), 14); drawStar(940, 160 + (i * 62), 14); }

    for (let i = 0; i < 15; i++) { drawStar(100 + (i * 57), 565, 14); }

    // 5. Foto Profil

    const avX = 110, avY = 150, avW = 280, avH = 380;

    const avatar = await loadImage(target.displayAvatarURL({ extension: 'png', size: 512 }));

    const aspectRatio = avatar.width / avatar.height;

    const targetRatio = avW / avH;

    let sw, sh, sx, sy;

    if (aspectRatio > targetRatio) { sw = avatar.height * targetRatio; sh = avatar.height; sx = (avatar.width - sw) / 2; sy = 0; }

    else { sw = avatar.width; sh = avatar.width / targetRatio; sx = 0; sy = (avatar.height - sh) / 2; }

    

    ctx.strokeStyle = themeColor; ctx.lineWidth = 8; ctx.strokeRect(avX, avY, avW, avH);

    ctx.drawImage(avatar, sx, sy, sw, sh, avX, avY, avW, avH);

    // 6. Data Fields

    const startX = 440, endX = 880, maxWidth = 350;

    let drawY = 200;

    const wrapText = (text, maxWidth) => {

      const words = String(text).split(' ');

      const lines = [];

      let currentLine = words[0];

      for (let i = 1; i < words.length; i++) {

        if (ctx.measureText(currentLine + " " + words[i]).width < maxWidth) {

          currentLine += " " + words[i];

        } else {

          lines.push(currentLine);

          currentLine = words[i];

        }

      }

      lines.push(currentLine);

      return lines;

    };

    const addRow = (label, value) => {

      ctx.textAlign = 'left';

      ctx.fillStyle = themeColor;

      ctx.font = 'bold 22px sans-serif';

      ctx.fillText(label, startX, drawY);

      ctx.textAlign = 'right';

      ctx.font = 'bold 28px sans-serif';

      const lines = wrapText(value.toUpperCase(), maxWidth);

      lines.forEach((line, index) => { ctx.fillText(line, endX, drawY + (index * 32)); });

      ctx.beginPath();

      ctx.strokeStyle = themeColor; ctx.lineWidth = 2;

      const lineOffset = lines.length > 1 ? (lines.length * 28) : 12;

      ctx.moveTo(startX, drawY + lineOffset); ctx.lineTo(endX, drawY + lineOffset);

      ctx.stroke();

      drawY += (lines.length > 1 ? (lines.length * 45) : 90);

    };

    addRow('Name', data.nama);

    addRow('Age', data.umur || data.age || '??'); // Menghapus "YEARS OLD"

    addRow('Gender', data.gender);

    addRow('Origin', data.asal);

    const attachment = new AttachmentBuilder(canvas.toBuffer(), { name: 'intro-card.png' });

    const embed = new EmbedBuilder()

      .setColor(embedColor)

      .setImage('attachment://intro-card.png');

    await interaction.editReply({

      embeds: [embed],

      files: [attachment]

    });

  }

};