const Database = require('better-sqlite3');

const db = new Database('./database.sqlite');

// channel setting

db.prepare(`

  CREATE TABLE IF NOT EXISTS intro (

    guildId TEXT PRIMARY KEY,

    channelId TEXT

  )

`).run();

// user intro data

db.prepare(`

  CREATE TABLE IF NOT EXISTS intro_users (

    userId TEXT,

    guildId TEXT,

    nama TEXT,

    asal TEXT,

    umur TEXT,

    gender TEXT,

    PRIMARY KEY (userId, guildId)

  )

`).run();

module.exports = db;