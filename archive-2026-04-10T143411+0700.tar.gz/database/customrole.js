const Database = require('better-sqlite3');

const db = new Database('./database.sqlite');

db.prepare(`
CREATE TABLE IF NOT EXISTS custom_roles (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT,
  role_id TEXT,
  boosts INTEGER DEFAULT 0
)
`).run();

module.exports = db;