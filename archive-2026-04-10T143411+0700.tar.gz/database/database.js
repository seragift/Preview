const Database = require('better-sqlite3');

const db = new Database('database.sqlite');

// --- 1. Tabel Konfigurasi (Settings & Whitelist) ---

db.prepare(`

  CREATE TABLE IF NOT EXISTS settings (

    guildId TEXT PRIMARY KEY,

    antiLink INTEGER DEFAULT 0,

    antiToxic INTEGER DEFAULT 0,

    logChannel TEXT

  )

`).run();

// Pastikan kolom logChannel ada untuk database lama

try {

  db.prepare("ALTER TABLE settings ADD COLUMN logChannel TEXT").run();

} catch (e) {}

db.prepare(`

  CREATE TABLE IF NOT EXISTS whitelist (

    channelId TEXT PRIMARY KEY,

    guildId TEXT

  )

`).run();

// --- 2. Tabel Statistik Harian (Untuk Laporan 00.00) ---

// Mencatat jumlah pesan per user, per channel, per jam, per hari

db.prepare(`

  CREATE TABLE IF NOT EXISTS daily_stats (

    guildId TEXT,

    userId TEXT,

    channelId TEXT,

    messageCount INTEGER DEFAULT 0,

    hour INTEGER,

    date TEXT,

    PRIMARY KEY (guildId, userId, channelId, hour, date)

  )

`).run();

// Tambahkan ini di database.js

db.prepare(`

  CREATE TABLE IF NOT EXISTS role_timer (

    guildId TEXT,

    userId TEXT,

    roleId TEXT,

    endTime INTEGER,

    PRIMARY KEY (guildId, userId, roleId)

  )

`).run();

// Mencatat event Member Join dan Member Out

db.prepare(`

  CREATE TABLE IF NOT EXISTS server_events (

    guildId TEXT,

    type TEXT, -- 'JOIN' atau 'OUT'

    date TEXT

  )

`).run();

module.exports = db;