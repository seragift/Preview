'use strict';

const fs = require('fs');
const path = require('path');
const { runProcess } = require('../utils/process');
const { parseYtDlpProgress } = require('../utils/progress');

const TMP_DIR = path.join(__dirname, '..', '..', 'tmp', 'downloads');
if (!fs.existsSync(TMP_DIR)) fs.mkdirSync(TMP_DIR, { recursive: true });

/**
 * Engine untuk binary `yt-dlp`. Satu-satunya tempat di seluruh bot yang
 * benar-benar men-spawn proses `yt-dlp` — reusable, tidak nyatu dengan logic
 * event/command. Semua pemanggilan yt-dlp (metadata fallback, download audio
 * asli, download benchmark -N) lewat sini, supaya kalau ada perubahan
 * argumen/flag yt-dlp, cukup diubah di satu file.
 *
 * Dipakai oleh:
 *   - services/youtube.js   -> getMetadata() (fallback saat YOUTUBE_API_KEY kosong/gagal)
 *   - services/downloader.js -> download()   (download audio asli untuk pipeline)
 *   - services/benchmark.js  -> downloadRaw() (benchmark -N 1/4/8/16)
 */

/**
 * Bangun `--extractor-args youtube:...` untuk memilih player client yang
 * dipakai yt-dlp. Ini bagian dari mitigasi "Sign in to confirm you're not
 * a bot" TANPA cookie:
 *
 * - Default: `android_vr,web_embedded` — dua-duanya TIDAK butuh PO Token
 *   (lihat https://github.com/yt-dlp/yt-dlp/wiki/PO-Token-Guide) dan
 *   TIDAK butuh cookie. Trade-off: android_vr gak bisa akses video
 *   "Made for kids", web_embedded cuma bisa video yang embeddable — yt-dlp
 *   otomatis coba client berikutnya di list kalau salah satu gagal/kosong.
 * - Kalau di masa depan kamu setup PO Token Provider plugin (mis.
 *   bgutil-ytdlp-pot-provider, solusi resmi paling robust — lihat README),
 *   isi `YTDLP_PLAYER_CLIENT=mweb,web` dan konfigurasi plugin-nya sendiri
 *   sesuai dokumentasi plugin tsb (di luar bot ini).
 *
 * CATATAN: JANGAN dihapus/dikosongkan begitu saja — tanpa ini yt-dlp balik
 * ke client default-nya sendiri (biasanya `web`/`mweb`), yang JUSTRU butuh
 * PO Token dan akan memunculkan lagi "Sign in to confirm you're not a bot"
 * (lihat README bagian troubleshooting). Kalau mau ganti client, override
 * lewat env `YTDLP_PLAYER_CLIENT` (dipisah koma), bukan hapus flag ini.
 */
function buildExtractorArgs() {
  const clients = process.env.YTDLP_PLAYER_CLIENT || 'android_vr,web_embedded';
  return ['--extractor-args', `youtube:player_client=${clients}`];
}

// Pola error yang diketahui BERSIFAT SEMENTARA di sisi YouTube/yt-dlp —
// biasanya hilang sendiri kalau langsung dicoba ulang, bukan masalah di
// video/URL-nya. "The page needs to be reloaded" adalah bug YouTube yang
// cukup sering muncul random di semua jalur (metadata, search, download).
const TRANSIENT_ERROR_PATTERNS = [
  /the page needs to be reloaded/i,
  /unable to download webpage/i,
  /http error 5\d\d/i,
  /econnreset/i,
  /etimedout/i,
  /network is unreachable/i
];

function isTransientError(err) {
  const text = `${err?.message || ''}\n${err?.stderr || ''}`;
  return TRANSIENT_ERROR_PATTERNS.some((re) => re.test(text));
}

/**
 * Jalankan `fn` dengan retry otomatis KHUSUS untuk error yang dikenali
 * sementara (lihat TRANSIENT_ERROR_PATTERNS di atas). Error lain (video
 * privat, format tidak ditemukan, dll) langsung dilempar tanpa retry —
 * retry di kasus itu cuma buang waktu karena hasilnya pasti sama.
 */
async function withTransientRetry(fn, { retries = 2, delayMs = 1500, label = 'yt-dlp' } = {}) {
  let lastErr;
  for (let attempt = 1; attempt <= retries + 1; attempt++) {
    try {
      return await fn();
    } catch (err) {
      lastErr = err;
      if (attempt <= retries && isTransientError(err)) {
        console.warn(
          `[YTDLP] Bug sementara YouTube terdeteksi pada "${label}" (percobaan ${attempt}/${retries + 1}), retry...`
        );
        await new Promise((resolve) => setTimeout(resolve, delayMs));
        continue;
      }
      throw err;
    }
  }
  throw lastErr;
}

/**
 * Hapus file mentah (.webm/.m4a/dll) yang mungkin sempat setengah terbentuk
 * untuk video_id tertentu — dipanggil sebelum retry (supaya percobaan
 * berikutnya tidak salah pungut file lama) dan setelah download benar-benar
 * gagal total (supaya tidak ada file sampah nyangkut di tmp/downloads/).
 */
function cleanupPartial(videoId) {
  let leftover;
  try {
    leftover = fs.readdirSync(TMP_DIR).filter((f) => f.startsWith(`${videoId}.`));
  } catch (_) {
    return;
  }
  for (const f of leftover) {
    fs.promises.unlink(path.join(TMP_DIR, f)).catch(() => {});
  }
}

/**
 * Ambil metadata video via `yt-dlp --dump-single-json`.
 */
async function getMetadata(url) {
  return withTransientRetry(
    async () => {
      const { promise } = runProcess(
        'yt-dlp',
        ['--dump-single-json', '--no-playlist', '--skip-download', ...buildExtractorArgs(), url],
        { timeoutMs: 30_000 }
      );

      const { stdout } = await promise;

      let data;
      try {
        data = JSON.parse(stdout);
      } catch (err) {
        throw new Error('Gagal parse metadata dari yt-dlp (output bukan JSON valid).');
      }

      return {
        videoId: data.id,
        title: data.title,
        channel: data.uploader || data.channel || 'Unknown',
        duration: Math.round(data.duration || 0),
        thumbnail: data.thumbnail,
        webpageUrl: data.webpage_url || url
      };
    },
    { label: `metadata ${url}` }
  );
}

/**
 * Download audio (format terbaik / sesuai config) via `yt-dlp` langsung
 * lewat spawn() — bukan exec() — supaya URL user tidak pernah masuk ke shell
 * string interpolation. File hasil disimpan sebagai `<videoId>.<ext asli>`
 * di tmp/downloads/. Retry otomatis kalau kena bug transient YouTube, dan
 * file mentah yang sempat kebentuk selalu dibersihkan kalau gagal (baik di
 * antara percobaan retry maupun setelah gagal total).
 *
 * @param {string} url
 * @param {string} videoId
 * @param {{format?:string, noPlaylist?:boolean, concurrentFragments?:number}} options
 * @param {(p: {percent:number, totalSize:string, speed:string, eta:string}) => void} [onProgress]
 */
async function download(url, videoId, options = {}, onProgress) {
  const { format = 'ba', noPlaylist = true, concurrentFragments = 1 } = options;
  const outputTemplate = path.join(TMP_DIR, '%(id)s.%(ext)s');

  const args = ['-f', format, '--no-part', '--newline', ...buildExtractorArgs()];
  if (noPlaylist) args.push('--no-playlist');
  if (concurrentFragments > 1) args.push('-N', String(concurrentFragments));
  args.push('-o', outputTemplate, url);

  try {
    return await withTransientRetry(
      async () => {
        cleanupPartial(videoId); // bersihkan sisa percobaan sebelumnya (kalau ini retry)

        const { promise } = runProcess('yt-dlp', args, {
          timeoutMs: 15 * 60 * 1000, // 15 menit safety timeout untuk download
          onStdout: (chunk) => {
            if (!onProgress) return;
            for (const line of chunk.split('\n')) {
              const parsed = parseYtDlpProgress(line);
              if (parsed) onProgress(parsed);
            }
          }
        });

        await promise;

        // yt-dlp menentukan ekstensi sendiri (webm/m4a/opus/dll) tergantung
        // format sumber, jadi cari file yang benar-benar dihasilkan
        // berdasarkan prefix ID.
        const files = fs
          .readdirSync(TMP_DIR)
          .filter((f) => f.startsWith(`${videoId}.`) && !f.endsWith('.part'));

        if (files.length === 0) {
          throw new Error('File hasil download tidak ditemukan setelah yt-dlp selesai.');
        }

        const filePath = path.join(TMP_DIR, files[0]);
        const size = fs.statSync(filePath).size;

        return { filePath, size };
      },
      { label: `download ${videoId}` }
    );
  } catch (err) {
    // Gagal total (bukan cuma antar-retry) -> pastikan tidak ada file
    // mentah nyangkut di tmp/downloads/ untuk video ini.
    cleanupPartial(videoId);
    throw err;
  }
}

/**
 * Download "mentah" khusus untuk benchmark -N (services/benchmark.js) —
 * output template & concurrency-nya diatur bebas oleh caller, tidak ikut
 * mengecek/menamai file hasil seperti download() biasa (file benchmark
 * dihapus lagi begitu selesai diukur, bukan diproses lebih lanjut).
 */
async function downloadRaw(url, outputTemplate, options = {}) {
  const { format = 'ba', concurrentFragments = 1, timeoutMs = 5 * 60 * 1000 } = options;

  const args = [
    '-f', format,
    '--no-playlist',
    '--no-part',
    '-N', String(concurrentFragments),
    ...buildExtractorArgs(),
    '-o', outputTemplate,
    url
  ];

  return withTransientRetry(
    async () => {
      const { promise } = runProcess('yt-dlp', args, { timeoutMs });
      await promise;
    },
    { retries: 1, label: `benchmark ${url}` } // benchmark: retry lebih dikit, biar hasil ukur tetap representatif
  );
}

module.exports = { getMetadata, download, downloadRaw, buildExtractorArgs, TMP_DIR };
