// src/handlers/commandHandler.js
// Command handler otomatis: membaca seluruh file command di src/commands/**
// secara rekursif dan mendaftarkannya ke client.commands (Collection).
//
// Setiap file command WAJIB mengekspor default object:
// { data: SlashCommandBuilder, execute: async (interaction) => {} }

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { Collection } from 'discord.js';
import logger from '../utils/logger.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const COMMANDS_DIR = path.join(__dirname, '..', 'commands');

function getAllCommandFiles(dir) {
  let results = [];
  const entries = fs.readdirSync(dir, { withFileTypes: true });

  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      results = results.concat(getAllCommandFiles(fullPath));
    } else if (entry.isFile() && entry.name.endsWith('.js')) {
      results.push(fullPath);
    }
  }

  return results;
}

/**
 * Muat seluruh command ke dalam client.commands.
 * @param {import('discord.js').Client} client
 */
export async function loadCommands(client) {
  client.commands = new Collection();

  if (!fs.existsSync(COMMANDS_DIR)) {
    logger.warn('Folder src/commands tidak ditemukan, tidak ada command yang dimuat.');
    return;
  }

  const files = getAllCommandFiles(COMMANDS_DIR);
  let loaded = 0;

  for (const filePath of files) {
    try {
      const module = await import(pathToFileURL(filePath).href);
      const command = module.default;

      if (!command?.data || !command?.execute) {
        logger.warn(`Command di ${filePath} tidak valid (harus ada 'data' dan 'execute'), dilewati.`);
        continue;
      }

      client.commands.set(command.data.name, command);
      loaded += 1;
    } catch (err) {
      logger.error(`Gagal memuat command ${filePath}: ${err.stack || err.message}`);
    }
  }

  logger.success(`${loaded} command berhasil dimuat.`);
}

/** Ambil seluruh data command (JSON) untuk keperluan deploy ke Discord API. */
export function getCommandsJSON(client) {
  return [...client.commands.values()].map((cmd) => cmd.data.toJSON());
}

export default { loadCommands, getCommandsJSON };
