// src/handlers/deploy.js
// Logic inti untuk mendaftarkan slash command ke Discord API.
// Dipakai oleh:
// 1. index.js -> auto-deploy & refresh setiap kali bot start/online
// 2. (opsional) script manual lain yang butuh deploy tanpa menyalakan bot penuh
//
// Jika GUILD_ID diisi di .env -> command didaftarkan per-guild (instan, cocok untuk testing).
// Jika GUILD_ID kosong -> command didaftarkan global (butuh waktu hingga 1 jam untuk update).

import { REST, Routes } from 'discord.js';
import { config } from '../config/config.js';
import logger from '../utils/logger.js';

/**
 * Deploy (dan refresh) seluruh command ke Discord API.
 * @param {Array<object>} commandsJSON - hasil dari getCommandsJSON(client)
 */
export async function deployCommands(commandsJSON) {
  if (!config.discord.token || !config.discord.clientId) {
    logger.warn('DISCORD_TOKEN/CLIENT_ID belum lengkap, auto-deploy command dilewati.');
    return;
  }

  const rest = new REST({ version: '10' }).setToken(config.discord.token);

  try {
    logger.info(`Auto-deploy: mendaftarkan/refresh ${commandsJSON.length} slash command...`);

    if (config.discord.guildId) {
      await rest.put(
        Routes.applicationGuildCommands(config.discord.clientId, config.discord.guildId),
        { body: commandsJSON }
      );
      logger.success(`Command berhasil di-refresh ke guild ${config.discord.guildId}.`);
    } else {
      await rest.put(Routes.applicationCommands(config.discord.clientId), { body: commandsJSON });
      logger.success('Command berhasil di-refresh secara global.');
    }
  } catch (err) {
    logger.error(`Gagal auto-deploy command: ${err.stack || err.message}`);
  }
}

export default { deployCommands };
