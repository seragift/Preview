// src/handlers/buttonHandler.js
// Memuat seluruh handler tombol dari src/interactions/buttons/** secara otomatis
// dan mendaftarkannya ke client.buttonHandlers berdasarkan `prefix` customId.
//
// Setiap file WAJIB mengekspor default { prefix: string, execute: async (interaction) => {} }.
// Konvensi customId di seluruh bot: "<prefix>:<action>:<...>" — router hanya
// membaca bagian sebelum ':' pertama untuk menentukan modul tujuan.

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { Collection } from 'discord.js';
import logger from '../utils/logger.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const BUTTONS_DIR = path.join(__dirname, '..', 'interactions', 'buttons');

function getAllFiles(dir) {
  let results = [];
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      results = results.concat(getAllFiles(fullPath));
    } else if (entry.isFile() && entry.name.endsWith('.js')) {
      results.push(fullPath);
    }
  }
  return results;
}

/**
 * @param {import('discord.js').Client} client
 */
export async function loadButtonHandlers(client) {
  client.buttonHandlers = new Collection();

  if (!fs.existsSync(BUTTONS_DIR)) {
    logger.warn('Folder src/interactions/buttons tidak ditemukan, tidak ada button handler yang dimuat.');
    return;
  }

  const files = getAllFiles(BUTTONS_DIR);
  let loaded = 0;

  for (const filePath of files) {
    try {
      const module = await import(pathToFileURL(filePath).href);
      const handler = module.default;

      if (!handler?.prefix || !handler?.execute) {
        logger.warn(`Button handler di ${filePath} tidak valid (harus ada 'prefix' dan 'execute'), dilewati.`);
        continue;
      }

      client.buttonHandlers.set(handler.prefix, handler);
      loaded += 1;
    } catch (err) {
      logger.error(`Gagal memuat button handler ${filePath}: ${err.stack || err.message}`);
    }
  }

  logger.success(`${loaded} button handler berhasil dimuat.`);
}

export default { loadButtonHandlers };
