// src/handlers/deployCommands.js
// Script manual untuk mendaftarkan slash command TANPA menyalakan bot penuh.
// Jalankan dengan: npm run deploy
//
// Catatan: sejak update ini, index.js SUDAH otomatis melakukan deploy & refresh
// command setiap kali bot online. Script ini tetap disediakan sebagai opsi
// manual/CI (mis. deploy command duluan sebelum bot benar-benar start).

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { Collection } from 'discord.js';
import logger from '../utils/logger.js';
import { deployCommands } from './deploy.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const COMMANDS_DIR = path.join(__dirname, '..', 'commands');

function getAllCommandFiles(dir) {
  let results = [];
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      results = results.concat(getAllCommandFiles(fullPath));
    } else if (entry.isFile() && entry.name.endsWith('.js')) {
      results.push(fullPath);
    }
  }
  return results;
}

async function main() {
  const commands = new Collection();
  const files = getAllCommandFiles(COMMANDS_DIR);

  for (const filePath of files) {
    const module = await import(pathToFileURL(filePath).href);
    const command = module.default;
    if (command?.data && command?.execute) {
      commands.set(command.data.name, command.data.toJSON());
    }
  }

  await deployCommands([...commands.values()]);
}

main().catch((err) => {
  logger.error(`Gagal deploy command: ${err.stack || err.message}`);
  process.exit(1);
});
