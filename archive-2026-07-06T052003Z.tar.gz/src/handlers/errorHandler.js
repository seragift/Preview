// src/handlers/errorHandler.js
// Error handler global untuk process Node.js (uncaughtException, unhandledRejection)
// serta helper untuk membungkus eksekusi command agar error tidak pernah
// membuat bot crash ataupun membuat interaction menggantung tanpa balasan.

import logger from '../utils/logger.js';
import { errorEmbed } from '../utils/embeds.js';

export function registerGlobalErrorHandlers() {
  process.on('unhandledRejection', (reason) => {
    logger.error(`Unhandled Rejection: ${reason instanceof Error ? reason.stack : reason}`);
  });

  process.on('uncaughtException', (err) => {
    logger.error(`Uncaught Exception: ${err.stack || err.message}`);
  });

  process.on('SIGINT', () => {
    logger.warn('Menerima SIGINT, mematikan bot dengan aman...');
    process.exit(0);
  });

  process.on('SIGTERM', () => {
    logger.warn('Menerima SIGTERM, mematikan bot dengan aman...');
    process.exit(0);
  });
}

/**
 * Bungkus fungsi execute command agar error selalu tertangani dan
 * user tetap mendapat balasan (embed error biru tua / merah tema).
 * @param {Function} fn - fungsi execute(interaction) asli
 */
export function safeExecute(fn) {
  return async (interaction, ...rest) => {
    try {
      await fn(interaction, ...rest);
    } catch (err) {
      logger.error(`Error pada command '${interaction.commandName}': ${err.stack || err.message}`);

      const embed = errorEmbed(
        'Terjadi kesalahan saat memproses perintah ini. Silakan coba lagi beberapa saat lagi.'
      );

      try {
        if (interaction.deferred || interaction.replied) {
          await interaction.editReply({ embeds: [embed] });
        } else {
          await interaction.reply({ embeds: [embed], ephemeral: true });
        }
      } catch (replyErr) {
        logger.error(`Gagal mengirim pesan error ke user: ${replyErr.message}`);
      }
    }
  };
}

export default { registerGlobalErrorHandlers, safeExecute };
