// src/handlers/eventHandler.js
// Event handler otomatis: membaca seluruh file di src/events/ dan mem-bind
// ke client sebagai listener (once atau on).
//
// Setiap file event WAJIB mengekspor default object:
// { name: string, once?: boolean, execute: async (...args) => {} }

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import logger from '../utils/logger.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const EVENTS_DIR = path.join(__dirname, '..', 'events');

/**
 * @param {import('discord.js').Client} client
 */
export async function loadEvents(client) {
  if (!fs.existsSync(EVENTS_DIR)) {
    logger.warn('Folder src/events tidak ditemukan, tidak ada event yang dimuat.');
    return;
  }

  const files = fs.readdirSync(EVENTS_DIR).filter((f) => f.endsWith('.js'));
  let loaded = 0;

  for (const file of files) {
    const filePath = path.join(EVENTS_DIR, file);
    try {
      const module = await import(pathToFileURL(filePath).href);
      const event = module.default;

      if (!event?.name || !event?.execute) {
        logger.warn(`Event di ${filePath} tidak valid (harus ada 'name' dan 'execute'), dilewati.`);
        continue;
      }

      if (event.once) {
        client.once(event.name, (...args) => event.execute(...args, client));
      } else {
        client.on(event.name, (...args) => event.execute(...args, client));
      }

      loaded += 1;
    } catch (err) {
      logger.error(`Gagal memuat event ${filePath}: ${err.stack || err.message}`);
    }
  }

  logger.success(`${loaded} event berhasil dimuat.`);
}

export default { loadEvents };
