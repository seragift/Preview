// src/database/categoryPerformanceRepository.js
// Repository untuk tabel category_performance — dipakai oleh fitur Latihan
// untuk Adaptive Learning, dan akan dipakai ulang oleh Prediksi Skor &
// Rekomendasi PTN pada tahap lanjutan.

import db from './database.js';

const ensureRowStmt = db.prepare(`
  INSERT OR IGNORE INTO category_performance (guild_id, user_id, category)
  VALUES (?, ?, ?)
`);

const getStmt = db.prepare(`
  SELECT * FROM category_performance WHERE guild_id = ? AND user_id = ? AND category = ?
`);

const getAllForUserStmt = db.prepare(`
  SELECT * FROM category_performance WHERE guild_id = ? AND user_id = ?
`);

const recordAttemptStmt = db.prepare(`
  UPDATE category_performance
  SET total_attempted = total_attempted + 1,
      total_correct = total_correct + ?,
      last_difficulty = ?,
      updated_at = datetime('now')
  WHERE guild_id = ? AND user_id = ? AND category = ?
`);

export const categoryPerformanceRepository = {
  get(guildId, userId, category) {
    ensureRowStmt.run(guildId, userId, category);
    return getStmt.get(guildId, userId, category);
  },

  getAllForUser(guildId, userId) {
    return getAllForUserStmt.all(guildId, userId);
  },

  /** Catat satu percobaan soal (benar/salah) untuk kategori tertentu. */
  recordAttempt(guildId, userId, category, isCorrect, difficulty) {
    ensureRowStmt.run(guildId, userId, category);
    recordAttemptStmt.run(isCorrect ? 1 : 0, difficulty, guildId, userId, category);
  },

  /**
   * Hitung akurasi (0-100) untuk menentukan tingkat kesulitan adaptif.
   * Mengembalikan null jika belum ada data (user baru di kategori ini).
   */
  getAccuracy(guildId, userId, category) {
    const row = this.get(guildId, userId, category);
    if (!row || row.total_attempted === 0) return null;
    return Math.round((row.total_correct / row.total_attempted) * 100);
  },
};

export default categoryPerformanceRepository;
