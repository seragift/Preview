// src/database/leaderboardRepository.js
// Query agregat untuk fitur Leaderboard. Semua query di-scope per guild dan
// hanya menghitung peserta yang benar-benar menyelesaikan tryout (status
// 'finished') agar leaderboard tidak bias oleh sesi yang belum kelar.
//
// Catatan: TIDAK ada sistem level/XP sama sekali, murni statistik dari data
// tryout yang sudah tercatat (skor, akurasi, jumlah soal diselesaikan).
// Default limit dibuat besar (bukan top-10) karena leaderboard dimaksudkan
// untuk menampilkan SEMUA member yang pernah berpartisipasi.

import db from './database.js';

const DEFAULT_LIMIT = 500;

const topBestScoreStmt = db.prepare(`
  SELECT tp.user_id, MAX(tp.score) as best_score
  FROM tryout_participants tp
  JOIN tryout_sessions ts ON tp.tryout_id = ts.id
  WHERE ts.guild_id = ? AND tp.status = 'finished'
  GROUP BY tp.user_id
  ORDER BY best_score DESC
  LIMIT ?
`);

const topTotalScoreStmt = db.prepare(`
  SELECT tp.user_id, SUM(tp.score) as total_score, COUNT(*) as tryout_count
  FROM tryout_participants tp
  JOIN tryout_sessions ts ON tp.tryout_id = ts.id
  WHERE ts.guild_id = ? AND tp.status = 'finished'
  GROUP BY tp.user_id
  ORDER BY total_score DESC
  LIMIT ?
`);

const topAccuracyStmt = db.prepare(`
  SELECT tp.user_id,
         SUM(tp.correct_count) as total_correct,
         SUM(ts.question_count) as total_questions
  FROM tryout_participants tp
  JOIN tryout_sessions ts ON tp.tryout_id = ts.id
  WHERE ts.guild_id = ? AND tp.status = 'finished'
  GROUP BY tp.user_id
  HAVING total_questions > 0
  ORDER BY (1.0 * total_correct / total_questions) DESC
  LIMIT ?
`);

const topAnsweredCountStmt = db.prepare(`
  SELECT ta.user_id, COUNT(*) as total_answered
  FROM tryout_answers ta
  JOIN tryout_sessions ts ON ta.tryout_id = ts.id
  WHERE ts.guild_id = ?
  GROUP BY ta.user_id
  ORDER BY total_answered DESC
  LIMIT ?
`);

export const leaderboardRepository = {
  /** Skor tryout tertinggi (skor terbaik dari satu sesi tryout) per user — SEMUA member. */
  getTopBestScore(guildId, limit = DEFAULT_LIMIT) {
    return topBestScoreStmt.all(guildId, limit);
  },

  /** Ranking server: total akumulasi skor dari seluruh tryout yang diselesaikan — SEMUA member. */
  getTopTotalScore(guildId, limit = DEFAULT_LIMIT) {
    return topTotalScoreStmt.all(guildId, limit);
  },

  /** Akurasi tertinggi (tertimbang: total benar / total soal) — SEMUA member. */
  getTopAccuracy(guildId, limit = DEFAULT_LIMIT) {
    return topAccuracyStmt.all(guildId, limit);
  },

  /** Jumlah soal terbanyak yang pernah dijawab — SEMUA member. */
  getTopAnsweredCount(guildId, limit = DEFAULT_LIMIT) {
    return topAnsweredCountStmt.all(guildId, limit);
  },
};

export default leaderboardRepository;
