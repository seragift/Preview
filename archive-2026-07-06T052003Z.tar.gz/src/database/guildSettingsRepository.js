// src/database/guildSettingsRepository.js
// Repository pattern untuk tabel guild_settings.
// Semua query terkait pengaturan server (channel AI, log, announcement) ada di sini
// agar handler/command tidak menulis SQL langsung.

import db from './database.js';

const upsertStmt = db.prepare(`
  INSERT INTO guild_settings (guild_id, ai_channel_id, updated_at)
  VALUES (@guildId, @aiChannelId, datetime('now'))
  ON CONFLICT(guild_id) DO UPDATE SET
    ai_channel_id = @aiChannelId,
    updated_at = datetime('now')
`);

const getStmt = db.prepare(`SELECT * FROM guild_settings WHERE guild_id = ?`);

const ensureRowStmt = db.prepare(`
  INSERT OR IGNORE INTO guild_settings (guild_id) VALUES (?)
`);

export const guildSettingsRepository = {
  /** Ambil pengaturan lengkap untuk sebuah guild. Selalu mengembalikan row (auto-create). */
  get(guildId) {
    ensureRowStmt.run(guildId);
    return getStmt.get(guildId);
  },

  /** Set channel yang dipakai untuk chat AI Tutor. */
  setAiChannel(guildId, channelId) {
    ensureRowStmt.run(guildId);
    upsertStmt.run({ guildId, aiChannelId: channelId });
  },

  /** Hapus channel AI Tutor (nonaktifkan fitur chat AI di guild ini). */
  removeAiChannel(guildId) {
    ensureRowStmt.run(guildId);
    db.prepare(`
      UPDATE guild_settings SET ai_channel_id = NULL, updated_at = datetime('now')
      WHERE guild_id = ?
    `).run(guildId);
  },

  setLogChannel(guildId, channelId) {
    ensureRowStmt.run(guildId);
    db.prepare(`
      UPDATE guild_settings SET log_channel_id = ?, updated_at = datetime('now')
      WHERE guild_id = ?
    `).run(channelId, guildId);
  },

  setAnnouncementChannel(guildId, channelId) {
    ensureRowStmt.run(guildId);
    db.prepare(`
      UPDATE guild_settings SET announcement_channel_id = ?, updated_at = datetime('now')
      WHERE guild_id = ?
    `).run(channelId, guildId);
  },

  /** Set channel tempat transcript lengkap tryout dikirim setelah peserta selesai. */
  setTranscriptChannel(guildId, channelId) {
    ensureRowStmt.run(guildId);
    db.prepare(`
      UPDATE guild_settings SET transcript_channel_id = ?, updated_at = datetime('now')
      WHERE guild_id = ?
    `).run(channelId, guildId);
  },
};

export default guildSettingsRepository;
