// src/database/database.js
// Koneksi database SQLite (better-sqlite3) dan inisialisasi schema.
//
// CATATAN ARSITEKTUR:
// Schema dibangun secara bertahap mengikuti tahap pengembangan bot.
// Tahap 1 hanya membuat tabel yang benar-benar dipakai oleh Core & AI Tutor.
// Tabel untuk Tryout, Battle, Leaderboard, dll akan ditambahkan pada modul
// migrasi terpisah di tahap-tahap berikutnya (lihat src/database/migrations/),
// sehingga tidak ada kolom/tabel placeholder yang menganggur.

import Database from 'better-sqlite3';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { config } from '../config/config.js';
import logger from '../utils/logger.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

function resolveDbPath() {
  const dbPath = path.isAbsolute(config.database.path)
    ? config.database.path
    : path.join(process.cwd(), config.database.path);

  const dir = path.dirname(dbPath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  return dbPath;
}

export const db = new Database(resolveDbPath());
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

/**
 * TAHAP 1 SCHEMA
 * - guild_settings   : pengaturan umum per server (mis. channel AI tutor)
 * - ai_conversations : riwayat percakapan AI per user (memory jangka panjang)
 * - ai_user_state    : ringkasan kondisi belajar user (dipakai lintas fitur AI)
 */
function initSchema() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS guild_settings (
      guild_id            TEXT PRIMARY KEY,
      ai_channel_id       TEXT,
      log_channel_id      TEXT,
      announcement_channel_id TEXT,
      transcript_channel_id TEXT,
      created_at          TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at          TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS ai_conversations (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      guild_id    TEXT NOT NULL,
      user_id     TEXT NOT NULL,
      role        TEXT NOT NULL CHECK (role IN ('user', 'assistant', 'system')),
      content     TEXT NOT NULL,
      has_image   INTEGER NOT NULL DEFAULT 0,
      created_at  TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE INDEX IF NOT EXISTS idx_ai_conversations_user
      ON ai_conversations (guild_id, user_id, created_at);

    CREATE TABLE IF NOT EXISTS ai_user_state (
      guild_id            TEXT NOT NULL,
      user_id             TEXT NOT NULL,
      weak_topics         TEXT,        -- JSON array kelemahan materi hasil analisis AI
      last_summary        TEXT,        -- ringkasan jangka panjang percakapan AI Tutor
      last_summarized_id  INTEGER NOT NULL DEFAULT 0, -- id pesan terakhir yang sudah masuk ringkasan
      updated_at          TEXT NOT NULL DEFAULT (datetime('now')),
      PRIMARY KEY (guild_id, user_id)
    );

    CREATE TABLE IF NOT EXISTS blacklist (
      guild_id    TEXT NOT NULL,
      user_id     TEXT NOT NULL,
      reason      TEXT,
      created_at  TEXT NOT NULL DEFAULT (datetime('now')),
      PRIMARY KEY (guild_id, user_id)
    );

    -- ===== TAHAP 2: Materi & Latihan =====
    -- Menyimpan statistik performa user per kategori SNBT, dipakai untuk
    -- Adaptive Learning (menentukan kesulitan soal berikutnya) dan menjadi
    -- basis data untuk fitur Prediksi Skor & Rekomendasi PTN di tahap lanjutan.
    CREATE TABLE IF NOT EXISTS category_performance (
      guild_id        TEXT NOT NULL,
      user_id         TEXT NOT NULL,
      category        TEXT NOT NULL,
      total_attempted INTEGER NOT NULL DEFAULT 0,
      total_correct   INTEGER NOT NULL DEFAULT 0,
      last_difficulty TEXT,
      updated_at      TEXT NOT NULL DEFAULT (datetime('now')),
      PRIMARY KEY (guild_id, user_id, category)
    );

    -- ===== TAHAP 3a: Tryout - Panel & Ticket System =====
    CREATE TABLE IF NOT EXISTS tryout_sessions (
      id               INTEGER PRIMARY KEY AUTOINCREMENT,
      guild_id         TEXT NOT NULL,
      creator_id       TEXT NOT NULL,
      category         TEXT NOT NULL,             -- salah satu CATEGORIES atau 'campuran'
      difficulty       TEXT NOT NULL,
      question_count   INTEGER NOT NULL,
      duration_minutes INTEGER NOT NULL,
      status           TEXT NOT NULL DEFAULT 'joining', -- joining, ongoing, finished, cancelled
      question_status  TEXT NOT NULL DEFAULT 'generating', -- generating, ready, failed
      panel_channel_id TEXT,
      panel_message_id TEXT,
      created_at       TEXT NOT NULL DEFAULT (datetime('now')),
      started_at       TEXT,
      ended_at         TEXT
    );

    CREATE TABLE IF NOT EXISTS tryout_participants (
      id                     INTEGER PRIMARY KEY AUTOINCREMENT,
      tryout_id              INTEGER NOT NULL REFERENCES tryout_sessions(id),
      user_id                TEXT NOT NULL,
      ticket_channel_id      TEXT,
      status                 TEXT NOT NULL DEFAULT 'joined', -- joined, in_progress, finished
      score                  INTEGER NOT NULL DEFAULT 0,
      correct_count          INTEGER NOT NULL DEFAULT 0,
      current_question_index INTEGER NOT NULL DEFAULT 0,
      joined_at              TEXT NOT NULL DEFAULT (datetime('now')),
      started_at             TEXT,
      finished_at            TEXT,
      UNIQUE (tryout_id, user_id)
    );

    CREATE INDEX IF NOT EXISTS idx_tryout_participants_tryout
      ON tryout_participants (tryout_id);

    -- Tabel ticket generik: dipakai oleh Tryout sekarang, dan bisa dipakai
    -- ulang oleh fitur Ticket System umum (mis. support ticket) di tahap lanjutan.
    CREATE TABLE IF NOT EXISTS ticket_channels (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      guild_id     TEXT NOT NULL,
      channel_id   TEXT NOT NULL UNIQUE,
      owner_id     TEXT NOT NULL,
      type         TEXT NOT NULL,               -- 'tryout', dst pada tahap berikutnya
      reference_id TEXT,
      status       TEXT NOT NULL DEFAULT 'open', -- open, closed
      created_at   TEXT NOT NULL DEFAULT (datetime('now')),
      closed_at    TEXT
    );

    -- ===== TAHAP 3b (revisi): Tryout - Bank Soal & Timer =====
    -- Soal di-generate SEKALIGUS untuk seluruh tryout begitu /tryout create
    -- dijalankan (bukan real-time saat ujian berlangsung), disimpan sebagai
    -- bank soal BERSAMA (satu set soal untuk semua peserta di tryout yang sama,
    -- persis seperti ujian SNBT asli). hash dipakai untuk memastikan tidak ada
    -- soal duplikat dalam satu bank.
    CREATE TABLE IF NOT EXISTS tryout_questions (
      id             INTEGER PRIMARY KEY AUTOINCREMENT,
      tryout_id      INTEGER NOT NULL REFERENCES tryout_sessions(id),
      question_index INTEGER NOT NULL,       -- 0-based urutan soal dalam tryout ini
      category       TEXT NOT NULL,          -- kategori aktual soal ini (relevan jika tryout 'campuran')
      hash           TEXT NOT NULL,          -- sha256 dari teks soal (dinormalisasi), untuk cek duplikat
      question_json  TEXT NOT NULL,          -- JSON lengkap: question, options, correct, explanation, dst
      created_at     TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE (tryout_id, question_index)
    );

    CREATE INDEX IF NOT EXISTS idx_tryout_questions_hash
      ON tryout_questions (tryout_id, hash);

    -- Jawaban tiap peserta dipisah dari bank soal karena satu soal yang sama
    -- dijawab oleh banyak peserta berbeda.
    CREATE TABLE IF NOT EXISTS tryout_answers (
      id             INTEGER PRIMARY KEY AUTOINCREMENT,
      tryout_id      INTEGER NOT NULL REFERENCES tryout_sessions(id),
      user_id        TEXT NOT NULL,
      question_index INTEGER NOT NULL,
      user_answer    TEXT NOT NULL,          -- A/B/C/D
      is_correct     INTEGER NOT NULL,       -- 0/1
      answered_at    TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE (tryout_id, user_id, question_index)
    );
  `);

  logger.success('Database schema (Tahap 1-3c + memory summarization) siap digunakan.');
}

initSchema();

export default db;
