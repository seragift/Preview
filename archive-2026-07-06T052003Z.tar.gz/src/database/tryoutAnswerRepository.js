// src/database/tryoutAnswerRepository.js
// Repository untuk tabel tryout_answers — mencatat jawaban tiap peserta
// terhadap bank soal bersama (tryout_questions). Dipisah dari bank soal
// karena satu soal yang sama dijawab oleh banyak peserta berbeda.

import db from './database.js';

const insertStmt = db.prepare(`
  INSERT INTO tryout_answers (tryout_id, user_id, question_index, user_answer, is_correct)
  VALUES (?, ?, ?, ?, ?)
`);

const getAnswerStmt = db.prepare(`
  SELECT * FROM tryout_answers WHERE tryout_id = ? AND user_id = ? AND question_index = ?
`);

const listForParticipantStmt = db.prepare(`
  SELECT * FROM tryout_answers WHERE tryout_id = ? AND user_id = ? ORDER BY question_index ASC
`);

export const tryoutAnswerRepository = {
  recordAnswer(tryoutId, userId, questionIndex, userAnswer, isCorrect) {
    insertStmt.run(tryoutId, userId, questionIndex, userAnswer, isCorrect ? 1 : 0);
  },

  getAnswer(tryoutId, userId, questionIndex) {
    return getAnswerStmt.get(tryoutId, userId, questionIndex);
  },

  /** Ambil seluruh jawaban seorang peserta (dipakai nanti oleh Transcript System). */
  listForParticipant(tryoutId, userId) {
    return listForParticipantStmt.all(tryoutId, userId);
  },
};

export default tryoutAnswerRepository;
