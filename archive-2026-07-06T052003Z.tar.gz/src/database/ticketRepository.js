// src/database/ticketRepository.js
// Repository untuk tabel ticket_channels — dipakai oleh Tryout sekarang,
// dan generik agar bisa dipakai ulang oleh fitur Ticket System lain nantinya.

import db from './database.js';

const insertStmt = db.prepare(`
  INSERT INTO ticket_channels (guild_id, channel_id, owner_id, type, reference_id)
  VALUES (@guildId, @channelId, @ownerId, @type, @referenceId)
`);

const getByChannelStmt = db.prepare(`SELECT * FROM ticket_channels WHERE channel_id = ?`);

const closeByChannelStmt = db.prepare(`
  UPDATE ticket_channels SET status = 'closed', closed_at = datetime('now') WHERE channel_id = ?
`);

const listOpenByReferenceStmt = db.prepare(`
  SELECT * FROM ticket_channels WHERE type = ? AND reference_id = ? AND status = 'open'
`);

export const ticketRepository = {
  create({ guildId, channelId, ownerId, type, referenceId }) {
    insertStmt.run({ guildId, channelId, ownerId, type, referenceId: String(referenceId ?? '') });
  },

  getByChannelId(channelId) {
    return getByChannelStmt.get(channelId);
  },

  closeByChannelId(channelId) {
    closeByChannelStmt.run(channelId);
  },

  listOpenByReference(type, referenceId) {
    return listOpenByReferenceStmt.all(type, String(referenceId));
  },
};

export default ticketRepository;
