// src/database/tryoutQuestionRepository.js
// Repository untuk tabel tryout_questions — bank soal BERSAMA untuk satu tryout
// (satu set soal yang sama dipakai oleh seluruh peserta, di-generate sekaligus
// saat /tryout create dijalankan). Data ini juga menjadi sumber data untuk
// Transcript System (Tahap 3c).

import db from './database.js';

const insertStmt = db.prepare(`
  INSERT INTO tryout_questions (tryout_id, question_index, category, hash, question_json)
  VALUES (@tryoutId, @questionIndex, @category, @hash, @questionJson)
`);

const getQuestionStmt = db.prepare(`
  SELECT * FROM tryout_questions WHERE tryout_id = ? AND question_index = ?
`);

const hashExistsStmt = db.prepare(`
  SELECT 1 FROM tryout_questions WHERE tryout_id = ? AND hash = ? LIMIT 1
`);

const countForTryoutStmt = db.prepare(`
  SELECT COUNT(*) as count FROM tryout_questions WHERE tryout_id = ?
`);

const listForTryoutStmt = db.prepare(`
  SELECT * FROM tryout_questions WHERE tryout_id = ? ORDER BY question_index ASC
`);

export const tryoutQuestionRepository = {
  insertQuestion({ tryoutId, questionIndex, category, hash, questionJson }) {
    insertStmt.run({ tryoutId, questionIndex, category, hash, questionJson });
  },

  getQuestion(tryoutId, questionIndex) {
    return getQuestionStmt.get(tryoutId, questionIndex);
  },

  /** Cek apakah teks soal (hash) sudah ada di bank soal tryout ini. */
  hashExists(tryoutId, hash) {
    return !!hashExistsStmt.get(tryoutId, hash);
  },

  countForTryout(tryoutId) {
    return countForTryoutStmt.get(tryoutId).count;
  },

  /** Ambil seluruh bank soal (dipakai nanti oleh Transcript System). */
  listForTryout(tryoutId) {
    return listForTryoutStmt.all(tryoutId);
  },
};

export default tryoutQuestionRepository;
