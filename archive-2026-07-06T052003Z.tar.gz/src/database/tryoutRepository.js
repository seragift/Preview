// src/database/tryoutRepository.js
// Repository untuk tabel tryout_sessions & tryout_participants.

import db from './database.js';

const insertStmt = db.prepare(`
  INSERT INTO tryout_sessions (guild_id, creator_id, category, difficulty, question_count, duration_minutes, status)
  VALUES (@guildId, @creatorId, @category, @difficulty, @questionCount, @durationMinutes, 'joining')
`);

const getByIdStmt = db.prepare(`SELECT * FROM tryout_sessions WHERE id = ?`);

const getLatestByStatusStmt = db.prepare(`
  SELECT * FROM tryout_sessions WHERE guild_id = ? AND status = ? ORDER BY id DESC LIMIT 1
`);

const setPanelStmt = db.prepare(`
  UPDATE tryout_sessions SET panel_channel_id = ?, panel_message_id = ? WHERE id = ?
`);

const markStartedStmt = db.prepare(`
  UPDATE tryout_sessions SET status = 'ongoing', started_at = datetime('now') WHERE id = ?
`);

const markEndedStmt = db.prepare(`
  UPDATE tryout_sessions SET status = ?, ended_at = datetime('now') WHERE id = ?
`);

const addParticipantStmt = db.prepare(`
  INSERT OR IGNORE INTO tryout_participants (tryout_id, user_id) VALUES (?, ?)
`);

const removeParticipantStmt = db.prepare(`
  DELETE FROM tryout_participants WHERE tryout_id = ? AND user_id = ? AND status = 'joined'
`);

const getParticipantStmt = db.prepare(`
  SELECT * FROM tryout_participants WHERE tryout_id = ? AND user_id = ?
`);

const listParticipantsStmt = db.prepare(`
  SELECT * FROM tryout_participants WHERE tryout_id = ? ORDER BY joined_at ASC
`);

const countParticipantsStmt = db.prepare(`
  SELECT COUNT(*) as count FROM tryout_participants WHERE tryout_id = ?
`);

const setParticipantTicketStmt = db.prepare(`
  UPDATE tryout_participants
  SET ticket_channel_id = ?, status = 'in_progress', started_at = datetime('now')
  WHERE tryout_id = ? AND user_id = ?
`);

const recordAnswerProgressStmt = db.prepare(`
  UPDATE tryout_participants
  SET score = score + ?, correct_count = correct_count + ?, current_question_index = current_question_index + 1
  WHERE tryout_id = ? AND user_id = ?
`);

const markParticipantFinishedStmt = db.prepare(`
  UPDATE tryout_participants SET status = 'finished', finished_at = datetime('now')
  WHERE tryout_id = ? AND user_id = ?
`);

const markQuestionsReadyStmt = db.prepare(`
  UPDATE tryout_sessions SET question_status = 'ready' WHERE id = ?
`);

const markQuestionGenerationFailedStmt = db.prepare(`
  UPDATE tryout_sessions SET question_status = 'failed' WHERE id = ?
`);

export const tryoutRepository = {
  create({ guildId, creatorId, category, difficulty, questionCount, durationMinutes }) {
    const info = insertStmt.run({ guildId, creatorId, category, difficulty, questionCount, durationMinutes });
    return info.lastInsertRowid;
  },

  getById(id) {
    return getByIdStmt.get(id);
  },

  /** Ambil tryout terbaru di guild dengan status tertentu ('joining' | 'ongoing' | dst). */
  getLatestByStatus(guildId, status) {
    return getLatestByStatusStmt.get(guildId, status);
  },

  setPanelMessage(id, channelId, messageId) {
    setPanelStmt.run(channelId, messageId, id);
  },

  markStarted(id) {
    markStartedStmt.run(id);
  },

  markEnded(id, status = 'finished') {
    markEndedStmt.run(status, id);
  },

  /** @returns {boolean} true jika berhasil ditambahkan (false jika sudah terdaftar) */
  addParticipant(tryoutId, userId) {
    const info = addParticipantStmt.run(tryoutId, userId);
    return info.changes > 0;
  },

  /** @returns {boolean} true jika berhasil dihapus (false jika tidak terdaftar/sudah mulai) */
  removeParticipant(tryoutId, userId) {
    const info = removeParticipantStmt.run(tryoutId, userId);
    return info.changes > 0;
  },

  getParticipant(tryoutId, userId) {
    return getParticipantStmt.get(tryoutId, userId);
  },

  listParticipants(tryoutId) {
    return listParticipantsStmt.all(tryoutId);
  },

  countParticipants(tryoutId) {
    return countParticipantsStmt.get(tryoutId).count;
  },

  setParticipantTicket(tryoutId, userId, channelId) {
    setParticipantTicketStmt.run(channelId, tryoutId, userId);
  },

  /** Tambahkan skor & kemajuan setelah peserta menjawab satu soal (dipanggil dari alur ujian Tryout). */
  recordAnswerProgress(tryoutId, userId, isCorrect) {
    recordAnswerProgressStmt.run(isCorrect ? 1 : 0, isCorrect ? 1 : 0, tryoutId, userId);
  },

  /** Tandai peserta selesai (baik menyelesaikan semua soal maupun auto-submit karena waktu habis). */
  markParticipantFinished(tryoutId, userId) {
    markParticipantFinishedStmt.run(tryoutId, userId);
  },

  /** Tandai bank soal tryout sudah selesai di-generate & siap dipakai untuk ujian. */
  markQuestionsReady(id) {
    markQuestionsReadyStmt.run(id);
  },

  /** Tandai proses generate bank soal gagal (perlu diketahui admin sebelum Start). */
  markQuestionGenerationFailed(id) {
    markQuestionGenerationFailedStmt.run(id);
  },
};

export default tryoutRepository;
