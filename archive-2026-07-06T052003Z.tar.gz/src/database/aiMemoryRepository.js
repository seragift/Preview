// src/database/aiMemoryRepository.js
// Repository untuk memory percakapan AI per user (tabel ai_conversations & ai_user_state).

import db from './database.js';
import { config } from '../config/config.js';

const insertMessageStmt = db.prepare(`
  INSERT INTO ai_conversations (guild_id, user_id, role, content, has_image)
  VALUES (@guildId, @userId, @role, @content, @hasImage)
`);

const getHistoryStmt = db.prepare(`
  SELECT role, content FROM ai_conversations
  WHERE guild_id = ? AND user_id = ?
  ORDER BY id DESC
  LIMIT ?
`);

const clearHistoryStmt = db.prepare(`
  DELETE FROM ai_conversations WHERE guild_id = ? AND user_id = ?
`);

const getStateStmt = db.prepare(`
  SELECT * FROM ai_user_state WHERE guild_id = ? AND user_id = ?
`);

const getMessagesBeyondWindowStmt = db.prepare(`
  WITH recent AS (
    SELECT id FROM ai_conversations WHERE guild_id = ? AND user_id = ? ORDER BY id DESC LIMIT ?
  )
  SELECT * FROM ai_conversations
  WHERE guild_id = ? AND user_id = ? AND id > ? AND id NOT IN (SELECT id FROM recent)
  ORDER BY id ASC
`);

const markSummarizedStmt = db.prepare(`
  INSERT INTO ai_user_state (guild_id, user_id, last_summarized_id, updated_at)
  VALUES (@guildId, @userId, @lastSummarizedId, datetime('now'))
  ON CONFLICT(guild_id, user_id) DO UPDATE SET
    last_summarized_id = @lastSummarizedId,
    updated_at = datetime('now')
`);

const upsertStateStmt = db.prepare(`
  INSERT INTO ai_user_state (guild_id, user_id, weak_topics, last_summary, updated_at)
  VALUES (@guildId, @userId, @weakTopics, @lastSummary, datetime('now'))
  ON CONFLICT(guild_id, user_id) DO UPDATE SET
    weak_topics = COALESCE(@weakTopics, weak_topics),
    last_summary = COALESCE(@lastSummary, last_summary),
    updated_at = datetime('now')
`);

export const aiMemoryRepository = {
  /** Simpan satu pesan (user atau assistant) ke riwayat percakapan. */
  addMessage(guildId, userId, role, content, hasImage = false) {
    insertMessageStmt.run({
      guildId,
      userId,
      role,
      content,
      hasImage: hasImage ? 1 : 0,
    });
  },

  /**
   * Ambil riwayat percakapan terbaru untuk dijadikan konteks AI.
   * Dikembalikan dalam urutan kronologis (lama -> baru).
   */
  getRecentHistory(guildId, userId, limit = config.ai.maxHistoryMessages) {
    const rows = getHistoryStmt.all(guildId, userId, limit);
    return rows.reverse().map((r) => ({ role: r.role, content: r.content }));
  },

  /** Hapus seluruh riwayat percakapan user (reset memory). */
  clearHistory(guildId, userId) {
    clearHistoryStmt.run(guildId, userId);
  },

  getState(guildId, userId) {
    return getStateStmt.get(guildId, userId);
  },

  /**
   * Ambil pesan-pesan yang berada DI LUAR jendela konteks aktif (windowSize
   * pesan terbaru) dan BELUM pernah masuk ke ringkasan jangka panjang.
   * Dipakai oleh memorySummarizer untuk menjaga "ingatan" percakapan panjang
   * tanpa harus mengirim seluruh riwayat mentah ke AI setiap kali.
   */
  getMessagesBeyondWindow(guildId, userId, windowSize, afterId = 0) {
    return getMessagesBeyondWindowStmt.all(guildId, userId, windowSize, guildId, userId, afterId);
  },

  /** Tandai bahwa pesan hingga id tertentu sudah masuk ke ringkasan jangka panjang. */
  markSummarized(guildId, userId, lastId) {
    markSummarizedStmt.run({ guildId, userId, lastSummarizedId: lastId });
  },

  /** Perbarui kelemahan materi & ringkasan belajar user (dipakai oleh fitur analisis AI). */
  updateState(guildId, userId, { weakTopics, lastSummary } = {}) {
    upsertStateStmt.run({
      guildId,
      userId,
      weakTopics: weakTopics ? JSON.stringify(weakTopics) : null,
      lastSummary: lastSummary ?? null,
    });
  },
};

export default aiMemoryRepository;
