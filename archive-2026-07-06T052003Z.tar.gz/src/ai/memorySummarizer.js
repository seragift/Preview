// src/ai/memorySummarizer.js
// Menjaga "ingatan jangka panjang" AI Tutor.
//
// SEMUA pesan asli tetap disimpan SELAMANYA di database (ai_conversations) —
// tidak ada yang dihapus. Yang dilakukan di sini hanyalah: begitu ada cukup
// banyak pesan lama yang sudah keluar dari jendela konteks aktif (dan belum
// pernah diringkas), AI diminta merangkumnya menjadi satu ringkasan singkat
// yang digabung dengan ringkasan sebelumnya. Ringkasan inilah yang disisipkan
// ke setiap percakapan berikutnya (lihat aiService.askTutor), sehingga bot
// tetap "ingat" konteks lama tanpa harus mengirim ratusan pesan mentah ke API
// setiap kali (mahal & lambat).

import aiMemoryRepository from '../database/aiMemoryRepository.js';
import { chatCompletion } from '../services/aiService.js';
import { config } from '../config/config.js';
import logger from '../utils/logger.js';

// Baru diringkas begitu ada lebih dari N pesan lama yang menumpuk & belum
// diringkas, supaya tidak memicu pemanggilan AI tambahan di setiap pesan.
const SUMMARY_TRIGGER_THRESHOLD = 10;

export async function maintainSummary(guildId, userId) {
  const state = aiMemoryRepository.getState(guildId, userId);
  const afterId = state?.last_summarized_id ?? 0;

  const pending = aiMemoryRepository.getMessagesBeyondWindow(
    guildId,
    userId,
    config.ai.maxHistoryMessages,
    afterId
  );

  if (pending.length < SUMMARY_TRIGGER_THRESHOLD) return;

  const previousSummary = state?.last_summary ?? '(belum ada ringkasan sebelumnya)';
  const transcriptText = pending.map((m) => `${m.role === 'user' ? 'User' : 'AI'}: ${m.content}`).join('\n');

  const prompt = `Ringkasan percakapan sebelumnya:
${previousSummary}

Percakapan tambahan yang perlu digabungkan ke ringkasan:
${transcriptText}

Buat SATU ringkasan baru (maksimal 200 kata, Bahasa Indonesia) yang menggabungkan
ringkasan sebelumnya dengan percakapan tambahan ini. Fokus pada: topik yang sudah
dibahas, kelemahan/kekuatan belajar yang teridentifikasi, dan jenis bantuan yang
sering diminta user. Langsung tulis isi ringkasannya saja, tanpa basa-basi.`;

  try {
    const summary = await chatCompletion(
      [
        { role: 'system', content: 'Kamu adalah asisten yang meringkas riwayat percakapan secara akurat dan ringkas.' },
        { role: 'user', content: prompt },
      ],
      { maxTokens: 400, temperature: 0.3 }
    );

    aiMemoryRepository.updateState(guildId, userId, { lastSummary: summary });
    aiMemoryRepository.markSummarized(guildId, userId, pending[pending.length - 1].id);

    logger.debug(`Ringkasan memory AI Tutor diperbarui untuk user ${userId} di guild ${guildId}.`);
  } catch (err) {
    logger.error(`Gagal memperbarui ringkasan memory AI Tutor untuk user ${userId}: ${err.message}`);
  }
}

export default { maintainSummary };
