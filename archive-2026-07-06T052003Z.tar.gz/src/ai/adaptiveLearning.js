// src/ai/adaptiveLearning.js
// Logika Adaptive Learning: menentukan tingkat kesulitan soal berikutnya
// berdasarkan akurasi historis user pada kategori terkait.

import categoryPerformanceRepository from '../database/categoryPerformanceRepository.js';

/**
 * Tentukan kesulitan adaptif berdasarkan akurasi historis.
 * - Belum ada data sama sekali -> 'sedang' (titik awal netral)
 * - Akurasi < 50%  -> 'mudah'
 * - Akurasi 50-80% -> 'sedang'
 * - Akurasi > 80%  -> 'sulit'
 */
export function determineAdaptiveDifficulty(guildId, userId, category) {
  const accuracy = categoryPerformanceRepository.getAccuracy(guildId, userId, category);

  if (accuracy === null) return 'sedang';
  if (accuracy < 50) return 'mudah';
  if (accuracy <= 80) return 'sedang';
  return 'sulit';
}

/**
 * Ambil ringkasan kelemahan user (kategori dengan akurasi terendah) untuk
 * dipakai sebagai konteks personalisasi pada /materi atau AI Tutor.
 */
export function getWeakestCategory(guildId, userId) {
  const rows = categoryPerformanceRepository.getAllForUser(guildId, userId);
  const withData = rows.filter((r) => r.total_attempted > 0);

  if (withData.length === 0) return null;

  withData.sort((a, b) => a.total_correct / a.total_attempted - b.total_correct / b.total_attempted);
  const weakest = withData[0];

  return {
    category: weakest.category,
    accuracy: Math.round((weakest.total_correct / weakest.total_attempted) * 100),
  };
}

export default { determineAdaptiveDifficulty, getWeakestCategory };
