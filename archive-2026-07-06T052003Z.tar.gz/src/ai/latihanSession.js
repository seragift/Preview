// src/ai/latihanSession.js
// Mengelola state sesi latihan interaktif (Soal -> Jawab -> Hasil -> Soal Berikutnya).
//
// Session bersifat in-memory (bukan di database) karena sifatnya transient —
// hanya relevan selama user sedang aktif mengerjakan latihan pada satu waktu.
// Kunci session: `${guildId}:${userId}` sehingga tiap user hanya bisa punya
// 1 sesi latihan aktif dalam satu waktu (per server).

const sessions = new Map();

function sessionKey(guildId, userId) {
  return `${guildId}:${userId}`;
}

/**
 * Mulai sesi latihan baru untuk user (menimpa sesi lama jika ada).
 */
export function startSession(guildId, userId, { category, difficulty }) {
  const key = sessionKey(guildId, userId);
  const session = {
    guildId,
    userId,
    category,
    difficulty,
    currentQuestion: null,
    recentQuestionTexts: [], // untuk menghindari soal mirip berulang dalam 1 sesi
    stats: { attempted: 0, correct: 0 },
    answered: false,
    createdAt: Date.now(),
  };
  sessions.set(key, session);
  return session;
}

export function getSession(guildId, userId) {
  return sessions.get(sessionKey(guildId, userId)) ?? null;
}

export function setCurrentQuestion(guildId, userId, question) {
  const session = getSession(guildId, userId);
  if (!session) return null;

  session.currentQuestion = question;
  session.answered = false;
  session.recentQuestionTexts.push(question.question);
  if (session.recentQuestionTexts.length > 5) session.recentQuestionTexts.shift();

  return session;
}

/**
 * Catat jawaban user pada soal aktif. Mengembalikan { isCorrect, session }.
 */
export function recordAnswer(guildId, userId, letter) {
  const session = getSession(guildId, userId);
  if (!session || !session.currentQuestion || session.answered) return null;

  session.answered = true;
  const isCorrect = session.currentQuestion.correct === letter;
  session.stats.attempted += 1;
  if (isCorrect) session.stats.correct += 1;

  return { isCorrect, session };
}

export function updateDifficulty(guildId, userId, difficulty) {
  const session = getSession(guildId, userId);
  if (session) session.difficulty = difficulty;
}

export function endSession(guildId, userId) {
  const key = sessionKey(guildId, userId);
  const session = sessions.get(key) ?? null;
  sessions.delete(key);
  return session;
}

export default {
  startSession,
  getSession,
  setCurrentQuestion,
  recordAnswer,
  updateDifficulty,
  endSession,
};
