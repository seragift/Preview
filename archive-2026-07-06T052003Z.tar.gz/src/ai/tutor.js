// src/ai/tutor.js
// Orkestrasi AI Tutor: menggabungkan memory (database) dengan pemanggilan
// AI service, sehingga command & event tinggal memanggil fungsi di sini.

import aiMemoryRepository from '../database/aiMemoryRepository.js';
import { askTutor, DEFAULT_SYSTEM_PROMPT } from '../services/aiService.js';
import { maintainSummary } from './memorySummarizer.js';
import logger from '../utils/logger.js';

/**
 * Proses pesan teks biasa dari user di channel AI Tutor.
 * Menyimpan pesan user & jawaban AI ke memory, lalu mengembalikan jawaban.
 *
 * Memory bekerja dalam 2 lapis:
 * 1. Jendela konteks aktif: N pesan terakhir (config.ai.maxHistoryMessages)
 *    dikirim mentah sebagai riwayat percakapan ke AI setiap kali.
 * 2. Ringkasan jangka panjang: begitu ada percakapan lama yang keluar dari
 *    jendela aktif, otomatis diringkas (lihat memorySummarizer.js) dan
 *    disisipkan sebagai konteks tambahan — sehingga bot tetap "ingat" topik
 *    dan kelemahan/kekuatan user meski percakapan sudah sangat panjang.
 * Seluruh pesan asli tetap tersimpan permanen di database, tidak ada yang hilang.
 */
export async function handleTextMessage(guildId, userId, text) {
  const history = aiMemoryRepository.getRecentHistory(guildId, userId);
  const state = aiMemoryRepository.getState(guildId, userId);

  const reply = await askTutor(history, text, DEFAULT_SYSTEM_PROMPT, { summary: state?.last_summary });

  aiMemoryRepository.addMessage(guildId, userId, 'user', text, false);
  aiMemoryRepository.addMessage(guildId, userId, 'assistant', reply, false);

  // Perbarui ringkasan jangka panjang di background (tidak memblokir balasan ke user).
  maintainSummary(guildId, userId).catch((err) =>
    logger.error(`Gagal menjalankan maintainSummary untuk user ${userId}: ${err.message}`)
  );

  return reply;
}

/**
 * Reset memory percakapan user (dipakai command admin / user sendiri di tahap lanjutan).
 */
export function resetMemory(guildId, userId) {
  aiMemoryRepository.clearHistory(guildId, userId);
  logger.info(`Memory AI untuk user ${userId} di guild ${guildId} telah direset.`);
}

export default { handleTextMessage, resetMemory, DEFAULT_SYSTEM_PROMPT };
