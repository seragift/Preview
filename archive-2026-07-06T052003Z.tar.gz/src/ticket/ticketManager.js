// src/ticket/ticketManager.js
// Modul Ticket System generik: membuat & menutup channel privat.
// Dipakai oleh fitur Tryout (ruang ujian per peserta) sekarang, dan didesain
// agar bisa dipakai ulang oleh fitur ticket lain (mis. support ticket) nanti
// tanpa perlu menulis ulang logika permission/kategori.

import { ChannelType, PermissionFlagsBits } from 'discord.js';
import ticketRepository from '../database/ticketRepository.js';
import logger from '../utils/logger.js';

/** Cari atau buat category channel dengan nama tertentu. */
async function ensureCategory(guild, categoryName) {
  let category = guild.channels.cache.find(
    (c) => c.type === ChannelType.GuildCategory && c.name === categoryName
  );

  if (!category) {
    category = await guild.channels.create({
      name: categoryName,
      type: ChannelType.GuildCategory,
    });
    logger.info(`Category ticket '${categoryName}' dibuat di guild ${guild.id}.`);
  }

  return category;
}

/**
 * Buat channel ticket privat untuk satu user.
 * @param {import('discord.js').Guild} guild
 * @param {object} opts
 * @param {string} opts.ownerId - user yang berhak melihat ticket ini
 * @param {string} opts.type - jenis ticket, mis. 'tryout'
 * @param {string|number} opts.referenceId - id referensi (mis. tryout_id)
 * @param {string} opts.categoryName - nama kategori channel tempat ticket dikelompokkan
 * @param {string} opts.channelName - nama channel (akan disanitasi otomatis oleh Discord)
 * @param {string} [opts.topic]
 */
export async function createTicketChannel(guild, opts) {
  const { ownerId, type, referenceId, categoryName, channelName, topic } = opts;

  const category = await ensureCategory(guild, categoryName);

  const channel = await guild.channels.create({
    name: channelName,
    type: ChannelType.GuildText,
    parent: category.id,
    topic,
    permissionOverwrites: [
      {
        id: guild.roles.everyone.id,
        deny: [PermissionFlagsBits.ViewChannel],
      },
      {
        id: ownerId,
        allow: [
          PermissionFlagsBits.ViewChannel,
          PermissionFlagsBits.SendMessages,
          PermissionFlagsBits.ReadMessageHistory,
          PermissionFlagsBits.AttachFiles,
        ],
      },
      {
        id: guild.members.me.id,
        allow: [
          PermissionFlagsBits.ViewChannel,
          PermissionFlagsBits.SendMessages,
          PermissionFlagsBits.ManageChannels,
          PermissionFlagsBits.ReadMessageHistory,
        ],
      },
    ],
  });

  ticketRepository.create({
    guildId: guild.id,
    channelId: channel.id,
    ownerId,
    type,
    referenceId,
  });

  logger.info(`Ticket channel '${channel.name}' (${channel.id}) dibuat untuk user ${ownerId} [type=${type}].`);

  return channel;
}

/**
 * Tutup & hapus channel ticket.
 * Catatan: pembuatan transcript sebelum penutupan akan ditambahkan pada
 * tahap Transcript System (Tahap 3c) — di sini fungsi hanya menutup channel.
 */
export async function closeTicketChannel(channel) {
  ticketRepository.closeByChannelId(channel.id);

  try {
    await channel.delete('Ticket ditutup');
  } catch (err) {
    logger.error(`Gagal menghapus ticket channel ${channel.id}: ${err.message}`);
    throw err;
  }
}

export default { createTicketChannel, closeTicketChannel };
