// src/events/interactionCreate.js
// Menangani seluruh interaksi (slash command, button, dsb).
// Tahap 1 fokus pada slash command; handler button/select menu untuk fitur
// Tryout/Battle akan ditambahkan pada tahap berikutnya sebagai file terpisah
// yang di-dispatch dari sini berdasarkan customId prefix.

import logger from '../utils/logger.js';
import { errorEmbed } from '../utils/embeds.js';
import db from '../database/database.js';

const isBlacklistedStmt = db.prepare(
  `SELECT 1 FROM blacklist WHERE guild_id = ? AND user_id = ?`
);

export default {
  name: 'interactionCreate',
  async execute(interaction) {
    if (interaction.isChatInputCommand()) {
      const command = interaction.client.commands.get(interaction.commandName);

      if (!command) {
        logger.warn(`Command '${interaction.commandName}' dipanggil tapi tidak ditemukan di handler.`);
        return;
      }

      if (interaction.guildId) {
        const blacklisted = isBlacklistedStmt.get(interaction.guildId, interaction.user.id);
        if (blacklisted) {
          await interaction.reply({
            embeds: [errorEmbed('Kamu sedang di-blacklist dan tidak dapat menggunakan bot ini.')],
            ephemeral: true,
          });
          return;
        }
      }

      await command.execute(interaction);
      return;
    }

    if (interaction.isButton()) {
      const prefix = interaction.customId.split(':')[0];
      const handler = interaction.client.buttonHandlers?.get(prefix);

      if (!handler) {
        logger.warn(`Tidak ada button handler untuk prefix '${prefix}' (customId: ${interaction.customId}).`);
        return;
      }

      if (interaction.guildId) {
        const blacklisted = isBlacklistedStmt.get(interaction.guildId, interaction.user.id);
        if (blacklisted) {
          await interaction.reply({
            embeds: [errorEmbed('Kamu sedang di-blacklist dan tidak dapat menggunakan bot ini.')],
            ephemeral: true,
          });
          return;
        }
      }

      try {
        await handler.execute(interaction);
      } catch (err) {
        logger.error(`Error pada button handler '${prefix}': ${err.stack || err.message}`);
      }
      return;
    }

    // Placeholder dispatch untuk select menu/modal (Tryout, Ticket) akan diisi
    // di tahap-tahap berikutnya, mengikuti pola router prefix yang sama.
  },
};
