// src/events/ready.js
import { ActivityType } from 'discord.js';
import logger from '../utils/logger.js';

export default {
  name: 'ready',
  once: true,
  execute(client) {
    logger.success(`Bot login sebagai ${client.user.tag} (${client.guilds.cache.size} server).`);

    client.user.setPresence({
      activities: [{ name: 'Dream Space Ai', type: ActivityType.Watching }],
      status: 'idle',
    });
  },
};
