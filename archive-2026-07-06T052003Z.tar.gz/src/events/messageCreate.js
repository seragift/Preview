// src/events/messageCreate.js
// Menangani chat AI Tutor (teks): hanya aktif di channel yang sudah diatur
// lewat /setchannel.

import guildSettingsRepository from '../database/guildSettingsRepository.js';
import { handleTextMessage } from '../ai/tutor.js';
import { splitIntoEmbeds, errorEmbed } from '../utils/embeds.js';
import logger from '../utils/logger.js';
import db from '../database/database.js';

const isBlacklistedStmt = db.prepare(
  `SELECT 1 FROM blacklist WHERE guild_id = ? AND user_id = ?`
);

export default {
  name: 'messageCreate',
  async execute(message) {
    if (message.author.bot || !message.guildId) return;

    const settings = guildSettingsRepository.get(message.guildId);
    if (!settings.ai_channel_id || message.channelId !== settings.ai_channel_id) return;

    if (isBlacklistedStmt.get(message.guildId, message.author.id)) return;

    const text = message.content?.trim();
    if (!text) return;

    await message.channel.sendTyping();

    try {
      const reply = await handleTextMessage(message.guildId, message.author.id, text);
      const embeds = splitIntoEmbeds(reply, { title: 'Dream Space Ai' });

      // Discord membatasi maksimal 10 embed per pesan; balasan AI Tutor
      // secara wajar tidak akan sepanjang itu, tapi tetap dijaga amannya.
      for (let i = 0; i < embeds.length; i += 10) {
        // eslint-disable-next-line no-await-in-loop
        await message.reply({ embeds: embeds.slice(i, i + 10) });
      }
    } catch (err) {
      logger.error(`Gagal memproses chat AI Tutor: ${err.stack || err.message}`);
      await message.reply({
        embeds: [errorEmbed('Maaf, AI sedang mengalami gangguan. Coba lagi sebentar lagi.')],
      });
    }
  },
};
