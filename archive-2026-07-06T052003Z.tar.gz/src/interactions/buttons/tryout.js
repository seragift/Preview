// src/interactions/buttons/tryout.js
// Handler untuk tombol prefix "tryout:" di panel Tryout.
// Format customId: tryout:<action>:<tryoutId>
//   - tryout:join:<id>
//   - tryout:leave:<id>
//   - tryout:startbtn:<id>  (khusus Administrator)

import { PermissionFlagsBits } from 'discord.js';
import tryoutRepository from '../../database/tryoutRepository.js';
import { startTryout } from '../../tryout/tryoutManager.js';
import { renderPanelEmbed, renderPanelButtons } from '../../utils/tryoutRenderer.js';
import { errorEmbed, successEmbed } from '../../utils/embeds.js';

export const prefix = 'tryout';

export async function execute(interaction) {
  const [, action, tryoutIdRaw] = interaction.customId.split(':');
  const tryoutId = Number(tryoutIdRaw);
  const tryout = tryoutRepository.getById(tryoutId);

  if (!tryout) {
    await interaction.reply({ embeds: [errorEmbed('Tryout ini sudah tidak tersedia.')], ephemeral: true });
    return;
  }

  if (action === 'join') {
    await handleJoin(interaction, tryout);
  } else if (action === 'leave') {
    await handleLeave(interaction, tryout);
  } else if (action === 'startbtn') {
    await handleStartButton(interaction, tryout);
  }
}

async function handleJoin(interaction, tryout) {
  if (tryout.status !== 'joining') {
    await interaction.reply({
      embeds: [errorEmbed('Tryout ini sudah tidak menerima peserta baru.')],
      ephemeral: true,
    });
    return;
  }

  const added = tryoutRepository.addParticipant(tryout.id, interaction.user.id);
  if (!added) {
    await interaction.reply({ embeds: [errorEmbed('Kamu sudah terdaftar di tryout ini.')], ephemeral: true });
    return;
  }

  const count = tryoutRepository.countParticipants(tryout.id);
  await interaction.update({
    embeds: [renderPanelEmbed(tryout, count)],
    components: [renderPanelButtons(tryout.id)],
  });
}

async function handleLeave(interaction, tryout) {
  if (tryout.status !== 'joining') {
    await interaction.reply({
      embeds: [errorEmbed('Tryout sudah dimulai, kamu tidak bisa keluar sekarang.')],
      ephemeral: true,
    });
    return;
  }

  const removed = tryoutRepository.removeParticipant(tryout.id, interaction.user.id);
  if (!removed) {
    await interaction.reply({ embeds: [errorEmbed('Kamu belum terdaftar di tryout ini.')], ephemeral: true });
    return;
  }

  const count = tryoutRepository.countParticipants(tryout.id);
  await interaction.update({
    embeds: [renderPanelEmbed(tryout, count)],
    components: [renderPanelButtons(tryout.id)],
  });
}

async function handleStartButton(interaction, tryout) {
  if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild)) {
    await interaction.reply({
      embeds: [errorEmbed('Hanya Administrator yang dapat memulai tryout.')],
      ephemeral: true,
    });
    return;
  }

  await interaction.deferUpdate();

  const result = await startTryout(interaction.guild, tryout.id);

  if (!result.ok) {
    await interaction.followUp({ embeds: [errorEmbed(result.reason)], ephemeral: true });
    return;
  }

  const count = tryoutRepository.countParticipants(tryout.id);
  await interaction.editReply({
    embeds: [renderPanelEmbed(result.tryout, count)],
    components: [renderPanelButtons(tryout.id, true)],
  });

  await interaction.followUp({
    embeds: [
      successEmbed(`Tryout dimulai! ${result.createdCount}/${result.participantCount} ruang ujian berhasil dibuat.`),
    ],
    ephemeral: true,
  });
}

export default { prefix, execute };
