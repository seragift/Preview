// src/interactions/buttons/tryoutExam.js
// Handler untuk tombol prefix "tryoutexam:" di dalam ticket ujian Tryout.
// Format customId: tryoutexam:answer:<tryoutId>:<userId>:<A|B|C|D>
//
// Catatan: soal berikutnya sekarang dikirim otomatis setelah menjawab
// (lihat tryoutExamEngine.js), jadi tidak ada lagi aksi "next" di sini.

import { handleAnswer } from '../../tryout/tryoutExamEngine.js';
import { errorEmbed } from '../../utils/embeds.js';

export const prefix = 'tryoutexam';

export async function execute(interaction) {
  const [, action, tryoutIdRaw, ownerId, letter] = interaction.customId.split(':');
  const tryoutId = Number(tryoutIdRaw);

  if (interaction.user.id !== ownerId) {
    await interaction.reply({
      embeds: [errorEmbed('Ini bukan ruang ujianmu. Setiap peserta hanya bisa mengerjakan ujiannya sendiri.')],
      ephemeral: true,
    });
    return;
  }

  if (action === 'answer') {
    await handleAnswer(interaction, tryoutId, ownerId, letter);
  }
}

export default { prefix, execute };
