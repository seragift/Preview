// src/interactions/buttons/latihan.js
// Handler untuk semua tombol dengan prefix customId "latihan:".
// Format customId: latihan:<action>:<ownerId>[:<extra>]
//   - latihan:answer:<ownerId>:<A|B|C|D>
//   - latihan:next:<ownerId>
//   - latihan:stop:<ownerId>

import {
  getSession,
  recordAnswer,
  setCurrentQuestion,
  endSession,
} from '../../ai/latihanSession.js';
import { generateQuestion } from '../../services/questionGenerator.js';
import { determineAdaptiveDifficulty } from '../../ai/adaptiveLearning.js';
import categoryPerformanceRepository from '../../database/categoryPerformanceRepository.js';
import {
  renderQuestionEmbed,
  renderAnswerButtons,
  renderResultEmbed,
  renderNextButtons,
  renderSummaryEmbed,
} from '../../utils/latihanRenderer.js';
import { errorEmbed } from '../../utils/embeds.js';
import logger from '../../utils/logger.js';

export const prefix = 'latihan';

export async function execute(interaction) {
  const [, action, ownerId, extra] = interaction.customId.split(':');

  if (interaction.user.id !== ownerId) {
    await interaction.reply({
      embeds: [errorEmbed('Ini bukan sesi latihan kamu. Gunakan `/latihan` untuk memulai sesi sendiri.')],
      ephemeral: true,
    });
    return;
  }

  const { guildId, user } = interaction;
  const session = getSession(guildId, user.id);

  if (!session) {
    await interaction.update({
      embeds: [errorEmbed('Sesi latihan sudah berakhir atau tidak ditemukan. Gunakan `/latihan` untuk memulai lagi.')],
      components: [],
    });
    return;
  }

  if (action === 'answer') {
    await handleAnswer(interaction, session, extra);
  } else if (action === 'next') {
    await handleNext(interaction, session);
  } else if (action === 'stop') {
    await handleStop(interaction, session);
  }
}

async function handleAnswer(interaction, session, letter) {
  const result = recordAnswer(session.guildId, session.userId, letter);

  if (!result) {
    await interaction.reply({
      embeds: [errorEmbed('Soal ini sudah dijawab sebelumnya.')],
      ephemeral: true,
    });
    return;
  }

  const { isCorrect } = result;
  const question = session.currentQuestion;

  categoryPerformanceRepository.recordAttempt(
    session.guildId,
    session.userId,
    session.category,
    isCorrect,
    session.difficulty
  );

  await interaction.update({
    embeds: [
      renderResultEmbed({
        question,
        userAnswer: letter,
        isCorrect,
        stats: session.stats,
      }),
    ],
    components: [renderNextButtons(session.userId)],
  });
}

async function handleNext(interaction, session) {
  await interaction.deferUpdate();

  // Re-adaptasi kesulitan berdasarkan performa terbaru sebelum soal berikutnya
  const nextDifficulty = determineAdaptiveDifficulty(session.guildId, session.userId, session.category);
  session.difficulty = nextDifficulty;

  let question;
  try {
    question = await generateQuestion(session.category, nextDifficulty, session.recentQuestionTexts);
  } catch (err) {
    logger.error(`Gagal generate soal berikutnya: ${err.message}`);
    await interaction.editReply({ embeds: [errorEmbed(err.message)], components: [] });
    return;
  }

  setCurrentQuestion(session.guildId, session.userId, question);

  await interaction.editReply({
    embeds: [
      renderQuestionEmbed({
        category: session.category,
        difficulty: session.difficulty,
        question,
        stats: session.stats,
      }),
    ],
    components: [renderAnswerButtons(session.userId)],
  });
}

async function handleStop(interaction, session) {
  const finished = endSession(session.guildId, session.userId);

  await interaction.update({
    embeds: [renderSummaryEmbed({ category: finished.category, stats: finished.stats })],
    components: [],
  });
}

export default { prefix, execute };
