// src/config/config.js
// Konfigurasi terpusat untuk seluruh bot. Semua modul WAJIB mengambil
// konfigurasi dari sini, jangan langsung memanggil process.env di tempat lain.

import 'dotenv/config';

function required(name, fallback = undefined) {
  const value = process.env[name] ?? fallback;
  if (value === undefined || value === '') {
    // Hanya warning saat startup, validasi keras dilakukan di index.js
    return '';
  }
  return value;
}

export const config = {
  discord: {
    token: required('DISCORD_TOKEN'),
    clientId: required('CLIENT_ID'),
    guildId: required('GUILD_ID'), // opsional, untuk deploy command per-guild (testing)
  },

  ai: {
    provider: 'NaraRouter',
    apiKey: required('NARAROUTER_API_KEY'),
    baseUrl: required('NARAROUTER_BASE_URL', 'https://router.bynara.id/v1'),
    model: required('NARAROUTER_MODEL', 'mistral-large'),
    // Batas token & memory percakapan
    maxHistoryMessages: 20, // jumlah pesan terakhir yang disimpan sebagai konteks per user
    maxOutputTokens: 2048,
    temperature: 0.4,
  },

  database: {
    path: required('DATABASE_PATH', './src/database/bot.sqlite'),
  },

  educationHub: {
    educationChannelId: required('EDUCATION_CHANNEL_ID'),
    scholarshipChannelId: required('SCHOLARSHIP_CHANNEL_ID'),
    snpmbChannelId: required('SNPMB_CHANNEL_ID'),
    techChannelId: required('TECH_CHANNEL_ID'),
    dailyQuestionChannelId: required('DAILY_QUESTION_CHANNEL_ID'),
  },

  logging: {
    level: required('LOG_LEVEL', 'info'),
  },

  // Identitas visual bot: SEMUA embed wajib memakai warna ini (biru tua / navy).
  theme: {
    embedColor: 0x00008B, // Dark Blue / Navy
    embedColorError: 0x8B0000, // tetap dipakai untuk error, tapi tetap nuansa gelap agar konsisten
    footerText: 'Dream Space Ai',
  },
};

export default config;
