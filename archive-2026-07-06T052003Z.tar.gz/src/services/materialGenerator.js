// src/services/materialGenerator.js
// Men-generate ringkasan materi belajar SNBT secara real-time via AI.

import { chatCompletion } from './aiService.js';
import { getCategoryLabel } from '../utils/constants.js';
import { MATH_FORMATTING_RULE } from '../utils/aiFormattingRules.js';

const SYSTEM_PROMPT = `Kamu adalah tutor SNBT yang menyusun materi belajar terstruktur.
Jawab dalam Bahasa Indonesia yang jelas, ringkas, dan mudah dipahami siswa SMA.
Format jawaban WAJIB memakai heading berikut (gunakan tebal markdown Discord **judul**):

**📘 Konsep Dasar**
(penjelasan inti konsep)

**📝 Penjelasan Lengkap**
(penjelasan lebih dalam beserta contoh)

**⚡ Cara Cepat SNBT**
(trik/shortcut mengerjakan soal jenis ini saat ujian)

**💡 Tips Pengerjaan**
(tips praktis agar tidak terjebak kesalahan umum)

Jangan gunakan heading markdown (#), cukup bold biasa. Jangan terlalu panjang bertele-tele.

${MATH_FORMATTING_RULE}`;

/**
 * Generate materi belajar untuk kategori tertentu, opsional fokus ke topik spesifik,
 * dan bisa mempertimbangkan kelemahan user (untuk personalisasi ringan).
 */
export async function generateMaterial(category, topic, weakContext) {
  const categoryLabel = getCategoryLabel(category);

  let userPrompt = `Jelaskan materi untuk kategori SNBT "${categoryLabel}"`;
  userPrompt += topic ? ` dengan fokus topik: "${topic}".` : ' secara umum (topik-topik penting yang sering keluar).';

  if (weakContext) {
    userPrompt += `\n\nCatatan: siswa ini memiliki kecenderungan lemah pada: ${weakContext}. Beri penekanan tambahan pada bagian yang relevan.`;
  }

  const messages = [
    { role: 'system', content: SYSTEM_PROMPT },
    { role: 'user', content: userPrompt },
  ];

  return chatCompletion(messages, { temperature: 0.5, maxTokens: 1600 });
}

export default { generateMaterial };
