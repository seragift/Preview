// src/services/questionGenerator.js
// Men-generate soal SNBT secara real-time via AI (NaraRouter), dengan output
// terstruktur (JSON) sehingga bisa dirender sebagai embed + tombol A/B/C/D.

import { chatCompletion } from './aiService.js';
import { getCategoryLabel } from '../utils/constants.js';
import { MATH_FORMATTING_RULE } from '../utils/aiFormattingRules.js';
import logger from '../utils/logger.js';

const SYSTEM_PROMPT = `Kamu adalah pembuat soal SNBT (Seleksi Nasional Berdasarkan Tes) profesional.
Tugasmu membuat SATU soal pilihan ganda (A, B, C, D) sesuai kategori & tingkat kesulitan yang diminta.
Soal harus orisinal, relevan dengan format SNBT terbaru, dan tidak ambigu.

WAJIB balas HANYA dengan JSON valid (tanpa markdown code fence, tanpa teks lain di luar JSON),
dengan struktur PERSIS seperti ini:

{
  "question": "teks soal lengkap",
  "options": { "A": "pilihan A", "B": "pilihan B", "C": "pilihan C", "D": "pilihan D" },
  "correct": "A",
  "explanation": "pembahasan lengkap kenapa jawaban tersebut benar",
  "concept": "konsep dasar yang mendasari soal ini",
  "quickTrick": "cara cepat mengerjakan soal sejenis saat SNBT",
  "tips": "tips singkat agar tidak terjebak soal sejenis"
}

Semua isi wajib dalam Bahasa Indonesia yang jelas.

${MATH_FORMATTING_RULE}`;

function buildUserPrompt(categoryLabel, difficulty, avoidList) {
  let prompt = `Buat 1 soal SNBT kategori "${categoryLabel}" dengan tingkat kesulitan "${difficulty}".`;

  if (avoidList?.length) {
    prompt += `\n\nJangan membuat soal dengan topik/isi yang mirip dengan soal-soal berikut (yang sudah pernah diberikan sebelumnya di sesi ini):\n`;
    prompt += avoidList.map((q, i) => `${i + 1}. ${q}`).join('\n');
  }

  return prompt;
}

function extractJson(raw) {
  // Buang kemungkinan code fence markdown jika AI tetap membungkusnya
  const cleaned = raw
    .trim()
    .replace(/^```json\s*/i, '')
    .replace(/^```\s*/i, '')
    .replace(/```$/i, '')
    .trim();

  const start = cleaned.indexOf('{');
  const end = cleaned.lastIndexOf('}');
  if (start === -1 || end === -1) {
    throw new Error('AI tidak mengembalikan format JSON yang valid.');
  }

  return JSON.parse(cleaned.slice(start, end + 1));
}

function validateQuestion(data) {
  const requiredFields = ['question', 'options', 'correct', 'explanation', 'concept', 'quickTrick', 'tips'];
  for (const field of requiredFields) {
    if (!data[field]) throw new Error(`Field '${field}' tidak ada pada soal yang dihasilkan AI.`);
  }

  const optionKeys = ['A', 'B', 'C', 'D'];
  for (const key of optionKeys) {
    if (!data.options[key]) throw new Error(`Pilihan jawaban '${key}' tidak lengkap.`);
  }

  if (!optionKeys.includes(data.correct)) {
    throw new Error(`Jawaban benar '${data.correct}' tidak valid (harus A/B/C/D).`);
  }

  return data;
}

/**
 * Generate satu soal baru untuk kategori & kesulitan tertentu.
 * @param {string} category - value dari CATEGORIES (mis. 'pu', 'ppu', 'pbm', dst)
 * @param {string} difficulty - 'mudah' | 'sedang' | 'sulit'
 * @param {string[]} [avoidList] - daftar teks soal sebelumnya (dalam sesi ini) untuk dihindari
 */
export async function generateQuestion(category, difficulty, avoidList = []) {
  const categoryLabel = getCategoryLabel(category);
  const userPrompt = buildUserPrompt(categoryLabel, difficulty, avoidList);

  const messages = [
    { role: 'system', content: SYSTEM_PROMPT },
    { role: 'user', content: userPrompt },
  ];

  const raw = await chatCompletion(messages, { temperature: 0.7, maxTokens: 1200 });

  try {
    const parsed = extractJson(raw);
    return validateQuestion(parsed);
  } catch (err) {
    logger.error(`Gagal parse soal dari AI: ${err.message} | raw: ${raw.slice(0, 200)}`);
    throw new Error('AI gagal menghasilkan soal yang valid. Silakan coba lagi.');
  }
}

export default { generateQuestion };
