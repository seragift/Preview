// src/services/aiService.js
// Wrapper untuk NaraRouter API (OpenAI-compatible /v1/chat/completions).
// Semua pemanggilan AI di seluruh bot WAJIB melalui service ini agar
// endpoint, API key, dan error handling tetap konsisten.

import axios from 'axios';
import { config } from '../config/config.js';
import logger from '../utils/logger.js';
import { MATH_FORMATTING_RULE } from '../utils/aiFormattingRules.js';

const client = axios.create({
  baseURL: config.ai.baseUrl,
  timeout: 60_000,
  headers: {
    Authorization: `Bearer ${config.ai.apiKey}`,
    'Content-Type': 'application/json',
  },
});

/**
 * System prompt dasar untuk AI Tutor SNBT. Dipakai sebagai fallback bila
 * pemanggil tidak menyediakan system prompt kustom.
 */
export const DEFAULT_SYSTEM_PROMPT = `Kamu adalah Dream Space AI SNBT/SNBP/UTBK yang ramah, sabar, dan sangat kompeten.
Selalu jawab dalam Bahasa Indonesia yang jelas dan mudah dipahami.
Jelaskan konsep langkah demi langkah, gunakan contoh soal bila relevan,
dan sesuaikan penjelasan dengan tingkat pemahaman siswa SMA yang sedang
mempersiapkan diri untuk SNBT, yang terdiri dari 7 subtes:
1. Penalaran Umum (PU)
2. Pengetahuan dan Pemahaman Umum (PPU)
3. Kemampuan Memahami Bacaan dan Menulis (PBM)
4. Pengetahuan Kuantitatif (PK)
5. Literasi Bahasa Indonesia
6. Literasi Bahasa Inggris
7. Penalaran Matematika (PM)
Jika diminta membuat ringkasan, jadwal belajar, atau analisis kelemahan,
sajikan dalam format terstruktur (poin-poin) agar mudah dibaca di Discord embed.

${MATH_FORMATTING_RULE}`;

/**
 * Kirim permintaan chat completion ke NaraRouter.
 * @param {Array<{role: string, content: any}>} messages
 * @param {object} [options]
 * @returns {Promise<string>} isi jawaban AI (teks)
 */
export async function chatCompletion(messages, options = {}) {
  try {
    const response = await client.post('/chat/completions', {
      model: options.model ?? config.ai.model,
      messages,
      max_tokens: options.maxTokens ?? config.ai.maxOutputTokens,
      temperature: options.temperature ?? config.ai.temperature,
    });

    const choice = response.data?.choices?.[0];
    const content = choice?.message?.content;

    if (!content) {
      throw new Error('Respons AI kosong atau format tidak dikenali.');
    }

    return content.trim();
  } catch (err) {
    const detail = err.response?.data?.error?.message ?? err.message;
    logger.error(`Ai error: ${detail}`);
    throw new Error(`Gagal menghubungi layanan AI (NaraRouter): ${detail}`);
  }
}

/**
 * Fungsi tingkat tinggi: tanya AI dengan riwayat percakapan + system prompt.
 * @param {Array} history - riwayat percakapan dari database
 * @param {string|object} userInput - teks biasa, atau pesan user siap-pakai dalam format content array
 * @param {string} [systemPrompt]
 * @param {object} [options] - diteruskan ke chatCompletion (mis. { model: 'pixtral-large-latest' })
 */
export async function askTutor(history, userInput, systemPrompt = DEFAULT_SYSTEM_PROMPT, options = {}) {
  const userMessage = typeof userInput === 'string' ? { role: 'user', content: userInput } : userInput;

  const messages = [{ role: 'system', content: systemPrompt }];

  if (options.summary) {
    messages.push({
      role: 'system',
      content: `Ringkasan percakapan sebelumnya dengan user ini (konteks tambahan, tidak perlu disebutkan ulang ke user kecuali relevan):\n${options.summary}`,
    });
  }

  messages.push(...history, userMessage);

  return chatCompletion(messages, options);
}

export default { chatCompletion, askTutor, DEFAULT_SYSTEM_PROMPT };
