// src/utils/tryoutRenderer.js
// Fungsi render embed & komponen untuk Panel Tryout dan hasil/leaderboard.

import { ActionRowBuilder, ButtonBuilder, ButtonStyle } from 'discord.js';
import { createEmbed } from './embeds.js';
import { getCategoryLabel, getDifficultyLabel } from './constants.js';

function tryoutStatusLabel(status) {
  return (
    {
      joining: '🟢 Menunggu Peserta',
      ongoing: '🟡 Sedang Berlangsung',
      finished: '⚪ Selesai',
      cancelled: '🔴 Dibatalkan',
    }[status] ?? status
  );
}

function participantStatusLabel(status) {
  return (
    {
      joined: 'Terdaftar',
      in_progress: 'Sedang Mengerjakan',
      finished: 'Selesai',
    }[status] ?? status
  );
}

function questionStatusLabel(status) {
  return (
    {
      generating: '⏳ Sedang Disiapkan AI',
      ready: '✅ Siap',
      failed: '❌ Gagal Dibuat',
    }[status] ?? status
  );
}

const DIFFICULTY_EMOJI = { mudah: '🟢', sedang: '🟡', sulit: '🔴' };

export function renderPanelEmbed(tryout, participantCount) {
  const difficultyEmoji = DIFFICULTY_EMOJI[tryout.difficulty] ?? '⚙️';

  return createEmbed({
    title: `📋 TRYOUT SNBT — Sesi #${tryout.id}`,
    description:
      '**Uji kemampuanmu sebelum hari-H!** Tekan tombol di bawah untuk ikut serta.\n\n' +
      '✅ **Join** — daftar sebagai peserta\n' +
      '🚪 **Leave** — batalkan pendaftaran *(sebelum tryout dimulai)*\n' +
      '▶️ **Start** — *khusus Administrator*, memulai ujian untuk semua peserta terdaftar\n\n' +
      'Begitu dimulai, setiap peserta otomatis mendapat **ruang ujian pribadi** lengkap dengan soal & timer.',
    fields: [
      { name: '📚 Kategori', value: getCategoryLabel(tryout.category), inline: true },
      { name: `${difficultyEmoji} Kesulitan`, value: getDifficultyLabel(tryout.difficulty), inline: true },
      { name: '📝 Jumlah Soal', value: `${tryout.question_count}`, inline: true },
      { name: '⏱️ Durasi Ujian', value: `${tryout.duration_minutes} menit`, inline: true },
      { name: '👥 Peserta Terdaftar', value: `${participantCount} orang`, inline: true },
      { name: '🧠 Soal', value: questionStatusLabel(tryout.question_status), inline: true },
      { name: '\u200B', value: '\u200B', inline: false },
      { name: '📌 Status Sesi', value: tryoutStatusLabel(tryout.status), inline: true },
      { name: '👤 Dibuat oleh', value: `<@${tryout.creator_id}>`, inline: true },
    ],
  });
}

export function renderPanelButtons(tryoutId, disabled = false) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`tryout:join:${tryoutId}`)
      .setLabel('Join')
      .setEmoji('✅')
      .setStyle(ButtonStyle.Success)
      .setDisabled(disabled),
    new ButtonBuilder()
      .setCustomId(`tryout:leave:${tryoutId}`)
      .setLabel('Leave')
      .setEmoji('🚪')
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(disabled),
    new ButtonBuilder()
      .setCustomId(`tryout:startbtn:${tryoutId}`)
      .setLabel('Start')
      .setEmoji('▶️')
      .setStyle(ButtonStyle.Primary)
      .setDisabled(disabled)
  );
}

export function renderResultEmbed(tryout, participants) {
  const sorted = [...participants].sort((a, b) => b.score - a.score);

  const lines = sorted.length
    ? sorted
        .map(
          (p, i) =>
            `${i + 1}. <@${p.user_id}> — Skor: **${p.score}** (${p.correct_count}/${tryout.question_count} benar) • ${participantStatusLabel(p.status)}`
        )
        .join('\n')
    : 'Belum ada peserta yang bergabung.';

  return createEmbed({
    title: `🏆 Hasil Tryout #${tryout.id}`,
    description:
      `Kategori: **${getCategoryLabel(tryout.category)}** • Kesulitan: **${getDifficultyLabel(tryout.difficulty)}** • Status: ${tryoutStatusLabel(tryout.status)}\n\n` +
      lines,
  });
}

export default { renderPanelEmbed, renderPanelButtons, renderResultEmbed };
