// src/utils/aiFormattingRules.js
// Aturan format matematika yang WAJIB disisipkan ke semua system prompt AI
// yang berpotensi menghasilkan rumus (soal, materi, pembahasan, AI Tutor).
//
// Discord TIDAK bisa merender LaTeX (\frac, \sqrt, \text, dsb) — kalau AI
// memakainya, hasilnya tampil sebagai teks mentah yang berantakan di embed.
// Karena itu AI wajib memakai simbol Unicode/teks biasa saja.

export const MATH_FORMATTING_RULE = `ATURAN FORMAT MATEMATIKA (WAJIB DIPATUHI):
Discord TIDAK bisa menampilkan LaTeX. JANGAN PERNAH menggunakan notasi LaTeX
seperti \\frac{}{}, \\sqrt{}, \\text{}, \\times, \\div, tanda kurung siku [ ] untuk
rumus, atau simbol backslash apa pun. Sebagai gantinya, tulis semua rumus dan
perhitungan dengan teks biasa dan simbol Unicode berikut:
- Perkalian: × (bukan \\times atau *)
- Pembagian/pecahan: tulis sebagai "a/b" biasa, atau gunakan ÷
- Akar kuadrat: √ diikuti angka/ekspresi dalam kurung biasa, contoh: √(64 + 225)
- Pangkat: gunakan superscript unicode (², ³) atau tulis "^2" jika superscript tidak tersedia
- Contoh penulisan yang BENAR: "Luas = 1/2 × 10 × 6 = 30 cm²"
- Contoh penulisan yang SALAH (jangan lakukan): "\\text{Luas} = \\frac{1}{2} \\times 10 \\times 6 = 30 \\text{ cm}^2"`;

export default { MATH_FORMATTING_RULE };
