// src/utils/embeds.js
// Utility WAJIB dipakai untuk membuat embed di seluruh fitur bot.
// Jangan pernah membuat `new EmbedBuilder()` langsung di command/event lain —
// selalu gunakan fungsi di file ini agar warna & format selalu konsisten (biru tua).

import { EmbedBuilder } from 'discord.js';
import { config } from '../config/config.js';

/**
 * Buat embed dasar berwarna biru tua dengan footer & timestamp standar.
 * @param {object} opts
 * @param {string} [opts.title]
 * @param {string} [opts.description]
 * @param {Array}  [opts.fields]
 * @param {string} [opts.thumbnail]
 * @param {string} [opts.image]
 * @param {string} [opts.footer] - override footer text default
 * @param {string} [opts.author]
 * @param {string} [opts.authorIcon]
 * @param {boolean} [opts.timestamp=true]
 */
export function createEmbed(opts = {}) {
  const embed = new EmbedBuilder().setColor(config.theme.embedColor);

  if (opts.title) embed.setTitle(opts.title);
  if (opts.description) embed.setDescription(opts.description);
  if (opts.fields) embed.addFields(opts.fields);
  if (opts.thumbnail) embed.setThumbnail(opts.thumbnail);
  if (opts.image) embed.setImage(opts.image);
  if (opts.author) embed.setAuthor({ name: opts.author, iconURL: opts.authorIcon });
  if (opts.timestamp !== false) embed.setTimestamp();

  embed.setFooter({ text: opts.footer ?? config.theme.footerText });

  return embed;
}

/** Embed khusus untuk pesan sukses. Tetap memakai warna tema (biru tua). */
export function successEmbed(description, opts = {}) {
  return createEmbed({ title: '✅ Berhasil', description, ...opts });
}

/** Embed khusus untuk pesan error/gagal. */
export function errorEmbed(description, opts = {}) {
  return createEmbed({ title: '⚠️ Terjadi Kesalahan', description, ...opts });
}

/** Embed untuk jawaban / balasan AI Tutor. */
export function aiReplyEmbed(description, opts = {}) {
  return createEmbed({
    title: opts.title ?? '🤖 AI Tutor SNBT',
    description,
    ...opts,
  });
}

/**
 * Memecah teks panjang menjadi beberapa embed (batas Discord: 4096 karakter
 * per description). Berguna untuk balasan AI yang panjang.
 */
export function splitIntoEmbeds(text, opts = {}) {
  const MAX = 4000; // beri sedikit ruang aman dari limit 4096
  const chunks = [];
  let remaining = text;

  while (remaining.length > 0) {
    if (remaining.length <= MAX) {
      chunks.push(remaining);
      break;
    }
    // Coba potong di batas baris baru terdekat agar tidak memotong kalimat
    let cutAt = remaining.lastIndexOf('\n', MAX);
    if (cutAt <= 0) cutAt = MAX;
    chunks.push(remaining.slice(0, cutAt));
    remaining = remaining.slice(cutAt).trimStart();
  }

  return chunks.map((chunk, i) =>
    createEmbed({
      title: i === 0 ? opts.title ?? '🤖 AI Tutor SNBT' : undefined,
      description: chunk,
      footer: opts.footer,
    })
  );
}

export default { createEmbed, successEmbed, errorEmbed, aiReplyEmbed, splitIntoEmbeds };
