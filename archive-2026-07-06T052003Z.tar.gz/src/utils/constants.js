// src/utils/constants.js
// Konstanta yang dipakai lintas fitur (Materi, Latihan, Tryout, Battle di tahap berikutnya)
// agar penamaan kategori & kesulitan selalu konsisten di seluruh bot.

// Struktur 7 subtes SNBT terbaru.
export const CATEGORIES = [
  { name: 'Penalaran Umum (PU)', value: 'pu' },
  { name: 'Pengetahuan dan Pemahaman Umum (PPU)', value: 'ppu' },
  { name: 'Kemampuan Memahami Bacaan dan Menulis (PBM)', value: 'pbm' },
  { name: 'Pengetahuan Kuantitatif (PK)', value: 'pk' },
  { name: 'Literasi Bahasa Indonesia', value: 'literasi_bahasa_indonesia' },
  { name: 'Literasi Bahasa Inggris', value: 'literasi_bahasa_inggris' },
  { name: 'Penalaran Matematika (PM)', value: 'penalaran_matematika' },
];

// Dipakai khusus oleh Tryout: menambahkan opsi "Campuran" yang mengacak soal
// dari seluruh kategori, meniru struktur ujian SNBT asli yang mencakup semua subtes.
export const TRYOUT_CATEGORIES = [...CATEGORIES, { name: 'Campuran (Semua Kategori)', value: 'campuran' }];

export const DIFFICULTIES = [
  { name: 'Mudah', value: 'mudah' },
  { name: 'Sedang', value: 'sedang' },
  { name: 'Sulit', value: 'sulit' },
];

export function getCategoryLabel(value) {
  return (
    CATEGORIES.find((c) => c.value === value)?.name ??
    TRYOUT_CATEGORIES.find((c) => c.value === value)?.name ??
    value
  );
}

export function getDifficultyLabel(value) {
  return DIFFICULTIES.find((d) => d.value === value)?.name ?? value;
}

export const ANSWER_LETTERS = ['A', 'B', 'C', 'D'];

export default { CATEGORIES, TRYOUT_CATEGORIES, DIFFICULTIES, getCategoryLabel, getDifficultyLabel, ANSWER_LETTERS };
