// src/utils/tryoutExamRenderer.js
// Render embed & komponen untuk alur ujian di dalam ticket Tryout
// (berbeda dari latihanRenderer yang dipakai untuk /latihan biasa).

import { ActionRowBuilder, ButtonBuilder, ButtonStyle } from 'discord.js';
import { createEmbed } from './embeds.js';
import { ANSWER_LETTERS } from './constants.js';

export function renderExamQuestionEmbed({ tryout, question, questionNumber }) {
  const optionsText = ANSWER_LETTERS.map((l) => `**${l}.** ${question.options[l]}`).join('\n');

  return createEmbed({
    title: `📝 Soal ${questionNumber}/${tryout.question_count}`,
    description: `${question.question}\n\n${optionsText}`,
  });
}

export function renderExamAnswerButtons(tryoutId, userId) {
  const row = new ActionRowBuilder();
  for (const letter of ANSWER_LETTERS) {
    row.addComponents(
      new ButtonBuilder()
        .setCustomId(`tryoutexam:answer:${tryoutId}:${userId}:${letter}`)
        .setLabel(letter)
        .setStyle(ButtonStyle.Primary)
    );
  }
  return row;
}

export function renderExamResultEmbed({ question, isCorrect, questionNumber, tryout }) {
  const statusText = isCorrect ? '✅ Jawaban Benar!' : '❌ Jawaban Salah';

  return createEmbed({
    title: `${statusText} — Soal ${questionNumber}/${tryout.question_count}`,
    description: question.explanation,
  });
}

export function renderExamFinalEmbed({ tryout, participant, reason }) {
  const accuracy =
    tryout.question_count > 0 ? Math.round((participant.correct_count / tryout.question_count) * 100) : 0;

  const reasonText =
    reason === 'waktu_habis'
      ? '⏰ Waktu ujian habis — jawaban yang sudah dikerjakan otomatis disubmit.'
      : '🏁 Kamu telah menyelesaikan seluruh soal.';

  return createEmbed({
    title: `Hasil Akhir — Tryout #${tryout.id}`,
    description: reasonText,
    fields: [
      { name: 'Skor', value: `${participant.score}`, inline: true },
      { name: 'Benar', value: `${participant.correct_count}/${tryout.question_count}`, inline: true },
      { name: 'Akurasi', value: `${accuracy}%`, inline: true },
    ],
  });
}

export default {
  renderExamQuestionEmbed,
  renderExamAnswerButtons,
  renderExamResultEmbed,
  renderExamFinalEmbed,
};
