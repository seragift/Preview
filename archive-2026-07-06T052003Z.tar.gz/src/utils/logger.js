// src/utils/logger.js
// Logger sederhana namun profesional, tanpa dependency eksternal.
// Menyediakan level: info, warn, error, debug, success.

const LEVELS = {
  error: 0,
  warn: 1,
  info: 2,
  debug: 3,
};

import { config } from '../config/config.js';

const currentLevel = LEVELS[config.logging.level] ?? LEVELS.info;

function timestamp() {
  return new Date().toISOString();
}

function format(level, label, message) {
  return `[${timestamp()}] [${label}] ${message}`;
}

function print(levelName, label, message, color) {
  if (LEVELS[levelName] > currentLevel) return;
  const text = format(levelName, label, message);
  // eslint-disable-next-line no-console
  console.log(color ? `\x1b[${color}m${text}\x1b[0m` : text);
}

export const logger = {
  info: (msg) => print('info', 'INFO', msg, '36'),
  warn: (msg) => print('warn', 'WARN', msg, '33'),
  error: (msg) => print('error', 'ERROR', msg, '31'),
  debug: (msg) => print('debug', 'DEBUG', msg, '90'),
  success: (msg) => print('info', 'OK', msg, '32'),
};

export default logger;
