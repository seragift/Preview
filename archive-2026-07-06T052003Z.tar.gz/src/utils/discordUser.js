// src/utils/discordUser.js
// Helper kecil untuk mengambil username Discord dari user ID, dipakai bersama
// oleh Transcript System dan Leaderboard agar tidak duplikasi logika.
//
// Dibungkus dengan timeout eksplisit: kalau client.users.fetch() lambat/macet
// (mis. karena rate limit atau masalah jaringan), pemanggil TIDAK ikut macet
// menunggu selamanya — setelah beberapa detik akan otomatis fallback ke
// placeholder "Unknown User (id)".

const FETCH_TIMEOUT_MS = 5000;

function withTimeout(promise, ms) {
  return Promise.race([
    promise,
    new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), ms)),
  ]);
}

export async function resolveUsername(client, userId) {
  try {
    const user = await withTimeout(client.users.fetch(userId), FETCH_TIMEOUT_MS);
    return user.username ?? user.tag ?? userId;
  } catch {
    return `Unknown User (${userId})`;
  }
}

export default { resolveUsername };
