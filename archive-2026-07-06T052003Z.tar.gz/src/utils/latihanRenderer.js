// src/utils/latihanRenderer.js
// Fungsi render embed & komponen (tombol) untuk alur Latihan interaktif.
// Dipisah agar command (/latihan) dan button handler (jawab/lanjut/selesai)
// tidak duplikasi logika tampilan.

import { ActionRowBuilder, ButtonBuilder, ButtonStyle } from 'discord.js';
import { createEmbed } from './embeds.js';
import { getCategoryLabel, getDifficultyLabel, ANSWER_LETTERS } from './constants.js';

/** Embed untuk menampilkan soal aktif beserta 4 pilihan jawaban. */
export function renderQuestionEmbed({ category, difficulty, question, stats }) {
  const optionsText = ANSWER_LETTERS.map((l) => `**${l}.** ${question.options[l]}`).join('\n');

  return createEmbed({
    title: '📝 Latihan SNBT',
    description: `${question.question}\n\n${optionsText}`,
    fields: [
      { name: 'Kategori', value: getCategoryLabel(category), inline: true },
      { name: 'Kesulitan', value: getDifficultyLabel(difficulty), inline: true },
      { name: 'Progres', value: `${stats.correct}/${stats.attempted} benar`, inline: true },
    ],
  });
}

/** Baris tombol A/B/C/D untuk menjawab soal. */
export function renderAnswerButtons(userId) {
  const row = new ActionRowBuilder();
  for (const letter of ANSWER_LETTERS) {
    row.addComponents(
      new ButtonBuilder()
        .setCustomId(`latihan:answer:${userId}:${letter}`)
        .setLabel(letter)
        .setStyle(ButtonStyle.Primary)
    );
  }
  return row;
}

/** Embed hasil setelah user menjawab (benar/salah + pembahasan lengkap). */
export function renderResultEmbed({ question, userAnswer, isCorrect, stats }) {
  const statusText = isCorrect ? '✅ Jawaban Benar!' : '❌ Jawaban Salah';

  return createEmbed({
    title: statusText,
    description: question.question,
    fields: [
      { name: 'Jawabanmu', value: `${userAnswer}. ${question.options[userAnswer]}`, inline: true },
      { name: 'Jawaban Benar', value: `${question.correct}. ${question.options[question.correct]}`, inline: true },
      { name: '\u200B', value: '\u200B', inline: true },
      { name: '📖 Pembahasan', value: question.explanation },
      { name: '📘 Konsep Dasar', value: question.concept },
      { name: '⚡ Cara Cepat SNBT', value: question.quickTrick },
      { name: '💡 Tips Pengerjaan', value: question.tips },
      { name: 'Progres Sesi', value: `${stats.correct}/${stats.attempted} benar`, inline: false },
    ],
  });
}

/** Tombol lanjut ke soal berikutnya / selesai sesi. */
export function renderNextButtons(userId) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`latihan:next:${userId}`)
      .setLabel('Soal Berikutnya')
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId(`latihan:stop:${userId}`)
      .setLabel('Selesai')
      .setStyle(ButtonStyle.Danger)
  );
}

/** Embed ringkasan akhir saat user mengakhiri sesi latihan. */
export function renderSummaryEmbed({ category, stats }) {
  const accuracy = stats.attempted > 0 ? Math.round((stats.correct / stats.attempted) * 100) : 0;

  return createEmbed({
    title: '🏁 Sesi Latihan Selesai',
    description: `Ringkasan hasil latihan kategori **${getCategoryLabel(category)}**.`,
    fields: [
      { name: 'Soal Dikerjakan', value: `${stats.attempted}`, inline: true },
      { name: 'Jawaban Benar', value: `${stats.correct}`, inline: true },
      { name: 'Akurasi', value: `${accuracy}%`, inline: true },
    ],
  });
}

export default {
  renderQuestionEmbed,
  renderAnswerButtons,
  renderResultEmbed,
  renderNextButtons,
  renderSummaryEmbed,
};
