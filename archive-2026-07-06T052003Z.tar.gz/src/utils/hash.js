// src/utils/hash.js
// Utility hashing untuk mekanisme anti-duplikat soal Tryout.

import crypto from 'node:crypto';

/**
 * Normalisasi teks soal (lowercase, rapikan spasi) lalu hash dengan SHA-256.
 * Dua soal dengan kata-kata identik tapi kapitalisasi/spasi berbeda akan
 * menghasilkan hash yang sama, sehingga tetap terdeteksi sebagai duplikat.
 */
export function hashQuestionText(text) {
  const normalized = text.toLowerCase().trim().replace(/\s+/g, ' ');
  return crypto.createHash('sha256').update(normalized).digest('hex');
}

export default { hashQuestionText };
