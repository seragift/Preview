// src/utils/leaderboardRenderer.js
// Render embed untuk berbagai jenis leaderboard (skor tertinggi, akurasi,
// soal terbanyak diselesaikan, ranking server). Menampilkan SEMUA member yang
// pernah berpartisipasi (bukan dibatasi top-10) — dipecah ke beberapa embed
// otomatis kalau daftarnya panjang (mengikuti batas 4096 karakter per embed).

import { splitIntoEmbeds } from './embeds.js';

const MEDAL = ['🥇', '🥈', '🥉'];

function rankPrefix(index) {
  return MEDAL[index] ?? `${index + 1}.`;
}

function renderList(title, rows, lineFn) {
  if (rows.length === 0) {
    return splitIntoEmbeds('Belum ada data. Selesaikan tryout untuk mulai muncul di leaderboard!', { title });
  }

  const text = rows.map((r, i) => `${rankPrefix(i)} ${lineFn(r, i)}`).join('\n');
  return splitIntoEmbeds(text, { title, footer: `Total ${rows.length} member` });
}

/** Leaderboard: skor tryout tertinggi (skor terbaik dari satu sesi) — semua member. */
export function renderBestScoreLeaderboard(rows, usernames) {
  return renderList('🏆 Leaderboard — Skor Tryout Tertinggi', rows, (r) => `**${usernames.get(r.user_id)}** — Skor ${r.best_score}`);
}

/** Leaderboard: ranking server (total akumulasi skor seluruh tryout) — semua member. */
export function renderTotalScoreLeaderboard(rows, usernames) {
  return renderList(
    '🏆 Leaderboard — Semua Member (Skor Tertinggi)',
    rows,
    (r) => `**${usernames.get(r.user_id)}** — Total Skor ${r.total_score} (${r.tryout_count} tryout)`
  );
}

/** Leaderboard: akurasi tertinggi (tertimbang: total benar / total soal) — semua member. */
export function renderAccuracyLeaderboard(rows, usernames) {
  return renderList('🏆 Leaderboard — Akurasi Tertinggi', rows, (r) => {
    const accuracy = Math.round((r.total_correct / r.total_questions) * 100);
    return `**${usernames.get(r.user_id)}** — Akurasi ${accuracy}% (${r.total_correct}/${r.total_questions} benar)`;
  });
}

/** Leaderboard: jumlah soal terbanyak yang pernah diselesaikan — semua member. */
export function renderAnsweredCountLeaderboard(rows, usernames) {
  return renderList(
    '🏆 Leaderboard — Soal Terbanyak Diselesaikan',
    rows,
    (r) => `**${usernames.get(r.user_id)}** — ${r.total_answered} soal dikerjakan`
  );
}

export default {
  renderBestScoreLeaderboard,
  renderTotalScoreLeaderboard,
  renderAccuracyLeaderboard,
  renderAnsweredCountLeaderboard,
};
