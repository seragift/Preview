// src/transcripts/transcriptService.js
// Mengirim transcript AGREGAT untuk satu tryout (mencakup SEMUA peserta yang
// mengikuti) ke channel yang sudah diatur lewat /settranscript, sebagai 2 file:
// - .xlsx -> ringkasan performa peserta (untuk sort/filter)
// - .pdf  -> bank soal, pembahasan lengkap, dan jawaban tiap peserta

import { AttachmentBuilder } from 'discord.js';
import guildSettingsRepository from '../database/guildSettingsRepository.js';
import tryoutRepository from '../database/tryoutRepository.js';
import tryoutQuestionRepository from '../database/tryoutQuestionRepository.js';
import tryoutAnswerRepository from '../database/tryoutAnswerRepository.js';
import { buildTryoutTranscriptExcel } from './transcriptExcelGenerator.js';
import { buildTryoutTranscriptPdf } from './transcriptPdfGenerator.js';
import { createEmbed } from '../utils/embeds.js';
import { getCategoryLabel, getDifficultyLabel } from '../utils/constants.js';
import { resolveUsername } from '../utils/discordUser.js';
import logger from '../utils/logger.js';


/**
 * Generate & kirim transcript agregat (Excel ringkasan + PDF detail lengkap)
 * untuk keseluruhan tryout. Tidak melempar error jika channel belum diatur —
 * hanya mencatat warning.
 */
export async function sendTryoutTranscript(client, guild, tryoutId) {
  const settings = guildSettingsRepository.get(guild.id);

  if (!settings.transcript_channel_id) {
    logger.warn(
      `Transcript channel belum diatur di guild ${guild.id} (gunakan /settranscript). Transcript tryout #${tryoutId} dilewati.`
    );
    return;
  }

  const tryout = tryoutRepository.getById(tryoutId);
  if (!tryout) return;

  const questions = tryoutQuestionRepository.listForTryout(tryoutId);
  // Hanya peserta yang benar-benar memulai ujian (punya ticket) yang masuk transcript.
  const participants = tryoutRepository.listParticipants(tryoutId).filter((p) => p.ticket_channel_id);

  if (participants.length === 0) {
    logger.warn(`Tryout #${tryoutId} tidak memiliki peserta yang memulai ujian, transcript dilewati.`);
    return;
  }

  const participantsData = [];
  for (const participant of participants) {
    // eslint-disable-next-line no-await-in-loop
    const username = await resolveUsername(client, participant.user_id);
    const answers = tryoutAnswerRepository.listForParticipant(tryoutId, participant.user_id);
    participantsData.push({ participant, username, answers });
  }

  const files = [];

  try {
    const excelBuffer = await buildTryoutTranscriptExcel({ tryout, questions, participantsData });
    files.push(new AttachmentBuilder(Buffer.from(excelBuffer), { name: `ringkasan-tryout-${tryoutId}.xlsx` }));
  } catch (err) {
    logger.error(`Gagal membuat file Excel ringkasan tryout #${tryoutId}: ${err.message}`);
  }

  try {
    const pdfBuffer = await buildTryoutTranscriptPdf({ tryout, questions, participantCount: participantsData.length });
    files.push(new AttachmentBuilder(pdfBuffer, { name: `transcript-tryout-${tryoutId}.pdf` }));
  } catch (err) {
    logger.error(`Gagal membuat file PDF transcript tryout #${tryoutId}: ${err.message}`);
  }

  if (files.length === 0) {
    logger.error(`Tidak ada file transcript yang berhasil dibuat untuk tryout #${tryoutId}, pengiriman dibatalkan.`);
    return;
  }

  const totalParticipants = participantsData.length;
  const avgAccuracy =
    totalParticipants > 0
      ? Math.round(
          participantsData.reduce((sum, p) => {
            const correct = p.answers.filter((a) => a.is_correct).length;
            const acc = tryout.question_count > 0 ? (correct / tryout.question_count) * 100 : 0;
            return sum + acc;
          }, 0) / totalParticipants
        )
      : 0;

  const summaryEmbed = createEmbed({
    title: `📄 Transcript Tryout #${tryoutId}`,
    description:
      'File **.xlsx** berisi ringkasan skor & catatan kelemahan/kekuatan per peserta. ' +
      'File **.pdf** berisi seluruh soal & pembahasan lengkap.',
    fields: [
      { name: 'Kategori', value: getCategoryLabel(tryout.category), inline: true },
      { name: 'Kesulitan', value: getDifficultyLabel(tryout.difficulty), inline: true },
      { name: 'Jumlah Peserta', value: `${totalParticipants}`, inline: true },
      { name: 'Rata-rata Akurasi', value: `${avgAccuracy}%`, inline: true },
    ],
  });

  try {
    const channel = await client.channels.fetch(settings.transcript_channel_id);
    await channel.send({ embeds: [summaryEmbed], files });
  } catch (err) {
    logger.error(`Gagal mengirim transcript tryout #${tryoutId}: ${err.message}`);
  }
}

export default { sendTryoutTranscript };
