// src/transcripts/transcriptPdfGenerator.js
// Membangun file PDF berisi bank soal lengkap: soal, pilihan jawaban, jawaban
// benar, dan pembahasan (konsep dasar, cara cepat SNBT, tips pengerjaan).
// Jawaban tiap peserta tidak lagi dimasukkan ke PDF — cukup dilihat lewat
// ringkasan skor per peserta di file Excel (transcriptExcelGenerator.js).

import PDFDocument from 'pdfkit';
import { getCategoryLabel, getDifficultyLabel } from '../utils/constants.js';

const NAVY = '#00008B';
const PAGE_BOTTOM_MARGIN = 700;

function ensureSpace(doc) {
  if (doc.y > PAGE_BOTTOM_MARGIN) {
    doc.addPage();
  }
}

/**
 * Bangun PDF berisi bank soal & pembahasan lengkap untuk satu tryout.
 * @param {object} params
 * @param {object} params.tryout
 * @param {Array} params.questions - bank soal (tryoutQuestionRepository.listForTryout)
 * @param {number} [params.participantCount] - jumlah peserta, hanya untuk info header
 * @returns {Promise<Buffer>}
 */
export function buildTryoutTranscriptPdf({ tryout, questions, participantCount = 0 }) {
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({ margin: 50, size: 'A4', bufferPages: true });
    const chunks = [];

    doc.on('data', (chunk) => chunks.push(chunk));
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    doc.on('error', reject);

    // ===== Header =====
    doc.fontSize(20).fillColor(NAVY).font('Helvetica-Bold').text(`Soal & Pembahasan — Tryout #${tryout.id}`, {
      align: 'center',
    });
    doc.moveDown(0.5);
    doc.fontSize(11).fillColor('black').font('Helvetica');
    doc.text(`Kategori       : ${getCategoryLabel(tryout.category)}`);
    doc.text(`Kesulitan      : ${getDifficultyLabel(tryout.difficulty)}`);
    doc.text(`Jumlah Soal    : ${tryout.question_count}`);
    doc.text(`Durasi         : ${tryout.duration_minutes} menit`);
    doc.text(`Jumlah Peserta : ${participantCount}`);
    doc.moveDown(1);

    // ===== Bank Soal & Pembahasan =====
    for (const q of questions) {
      const question = JSON.parse(q.question_json);
      ensureSpace(doc);

      doc.fontSize(12).fillColor(NAVY).font('Helvetica-Bold').text(`Soal ${q.question_index + 1} — ${getCategoryLabel(q.category)}`);
      doc.fillColor('black').font('Helvetica').fontSize(11);
      doc.text(question.question);
      doc.moveDown(0.2);
      doc.text(`A. ${question.options.A}`);
      doc.text(`B. ${question.options.B}`);
      doc.text(`C. ${question.options.C}`);
      doc.text(`D. ${question.options.D}`);
      doc.moveDown(0.2);
      doc.font('Helvetica-Bold').text(`Jawaban Benar: ${question.correct}`);
      doc.font('Helvetica');
      doc.moveDown(0.2);
      doc.text(`Pembahasan      : ${question.explanation}`);
      doc.text(`Konsep Dasar    : ${question.concept}`);
      doc.text(`Cara Cepat SNBT : ${question.quickTrick}`);
      doc.text(`Tips Pengerjaan : ${question.tips}`);
      doc.moveDown(0.4);
      doc.strokeColor('#cccccc').moveTo(doc.x, doc.y).lineTo(545, doc.y).stroke();
      doc.moveDown(0.4);
    }

    doc.end();
  });
}

export default { buildTryoutTranscriptPdf };

