// src/transcripts/transcriptExcelGenerator.js
// Membangun file Excel (.xlsx) berisi RINGKASAN performa seluruh peserta satu
// tryout: username Discord, soal diisi, benar, salah, persentase, dan catatan
// otomatis kategori yang perlu ditingkatkan.
//
// Detail soal, jawaban, dan pembahasan lengkap ada di file PDF terpisah
// (lihat transcriptPdfGenerator.js) — dipisah karena kontennya berupa teks
// naratif panjang yang lebih nyaman dibaca dalam format PDF, sementara data
// ringkasan ini lebih berguna dalam bentuk tabel yang bisa di-sort/filter.

import ExcelJS from 'exceljs';
import { getCategoryLabel } from '../utils/constants.js';

const HEADER_FILL = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF00008B' } };
const HEADER_FONT = { color: { argb: 'FFFFFFFF' }, bold: true };
const WEAK_THRESHOLD = 60; // akurasi di bawah ini pada suatu kategori dianggap "perlu ditingkatkan"

function styleHeaderRow(row) {
  row.eachCell((cell) => {
    cell.fill = HEADER_FILL;
    cell.font = HEADER_FONT;
    cell.alignment = { vertical: 'middle', horizontal: 'center', wrapText: true };
  });
  row.height = 22;
}

function computeCategoryBreakdown(questions, answerByIndex) {
  const stats = new Map();
  for (const q of questions) {
    if (!stats.has(q.category)) stats.set(q.category, { total: 0, correct: 0 });
    const stat = stats.get(q.category);
    stat.total += 1;
    if (answerByIndex.get(q.question_index)?.is_correct) stat.correct += 1;
  }
  return stats;
}

function buildImprovementNotes(categoryStats) {
  const weak = [];
  for (const [category, stat] of categoryStats.entries()) {
    if (stat.total === 0) continue;
    const acc = Math.round((stat.correct / stat.total) * 100);
    if (acc < WEAK_THRESHOLD) weak.push(`${getCategoryLabel(category)} (${acc}%)`);
  }
  return weak.length === 0 ? 'Semua kategori sudah baik.' : `Perlu ditingkatkan: ${weak.join(', ')}.`;
}

/**
 * Bangun workbook Excel ringkasan untuk satu tryout (semua peserta).
 * @param {object} params
 * @param {object} params.tryout
 * @param {Array} params.questions - bank soal (tryoutQuestionRepository.listForTryout)
 * @param {Array<{participant: object, username: string, answers: Array}>} params.participantsData
 * @returns {Promise<ArrayBuffer>}
 */
export async function buildTryoutTranscriptExcel({ tryout, questions, participantsData }) {
  const workbook = new ExcelJS.Workbook();
  workbook.creator = 'SNBT/SNBP/UTBK Assistant Bot';
  workbook.created = new Date();

  const summarySheet = workbook.addWorksheet('Ringkasan Peserta');
  summarySheet.columns = [
    { header: 'Username Discord', key: 'username', width: 26 },
    { header: 'Soal Diisi', key: 'answered', width: 12 },
    { header: 'Jawaban Benar', key: 'correct', width: 14 },
    { header: 'Jawaban Salah', key: 'wrong', width: 14 },
    { header: 'Persentase', key: 'accuracy', width: 12 },
    { header: 'Catatan yang Perlu Ditingkatkan', key: 'notes', width: 55 },
  ];
  styleHeaderRow(summarySheet.getRow(1));

  for (const { username, answers } of participantsData) {
    const answerByIndex = new Map(answers.map((a) => [a.question_index, a]));
    const answered = answers.length;
    const correct = answers.filter((a) => a.is_correct).length;
    const wrong = answered - correct;
    const accuracy = tryout.question_count > 0 ? Math.round((correct / tryout.question_count) * 100) : 0;
    const categoryStats = computeCategoryBreakdown(questions, answerByIndex);

    summarySheet.addRow({
      username,
      answered,
      correct,
      wrong,
      accuracy: `${accuracy}%`,
      notes: buildImprovementNotes(categoryStats),
    });
  }

  summarySheet.getColumn('notes').alignment = { wrapText: true, vertical: 'top' };

  return workbook.xlsx.writeBuffer();
}

export default { buildTryoutTranscriptExcel };
