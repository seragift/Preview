// src/commands/tryout/tryout.js
// /tryout create | start | stop | result
// Perintah manajemen Tryout untuk Administrator. Join/Leave hanya lewat tombol panel.

import { SlashCommandBuilder, PermissionFlagsBits } from 'discord.js';
import { TRYOUT_CATEGORIES, DIFFICULTIES } from '../../utils/constants.js';
import tryoutRepository from '../../database/tryoutRepository.js';
import { createTryoutPanel, startTryout, stopTryout, getResultData, syncPanelMessage } from '../../tryout/tryoutManager.js';
import { renderResultEmbed } from '../../utils/tryoutRenderer.js';
import { successEmbed, errorEmbed } from '../../utils/embeds.js';
import { safeExecute } from '../../handlers/errorHandler.js';

function resolveActiveId(interaction) {
  const explicit = interaction.options.getInteger('id');
  if (explicit) return explicit;

  return (
    tryoutRepository.getLatestByStatus(interaction.guildId, 'ongoing')?.id ??
    tryoutRepository.getLatestByStatus(interaction.guildId, 'joining')?.id ??
    null
  );
}

export default {
  data: new SlashCommandBuilder()
    .setName('tryout')
    .setDescription('Kelola sesi Tryout SNBT.')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand((sub) =>
      sub
        .setName('create')
        .setDescription('Buat panel tryout baru (Join/Leave/Start).')
        .addStringOption((o) =>
          o.setName('kategori').setDescription('Kategori soal').setRequired(true).addChoices(...TRYOUT_CATEGORIES)
        )
        .addStringOption((o) =>
          o.setName('kesulitan').setDescription('Tingkat kesulitan').setRequired(true).addChoices(...DIFFICULTIES)
        )
        .addIntegerOption((o) =>
          o.setName('jumlah_soal').setDescription('Jumlah soal (1-100)').setRequired(true).setMinValue(1).setMaxValue(100)
        )
        .addIntegerOption((o) =>
          o
            .setName('durasi_menit')
            .setDescription('Durasi ujian dalam menit')
            .setRequired(true)
            .setMinValue(1)
            .setMaxValue(300)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName('start')
        .setDescription('Mulai tryout: buat ruang ujian untuk semua peserta yang sudah join.')
        .addIntegerOption((o) => o.setName('id').setDescription('ID Tryout (kosongkan untuk yang terbaru)'))
    )
    .addSubcommand((sub) =>
      sub
        .setName('stop')
        .setDescription('Hentikan tryout yang sedang menunggu peserta/berlangsung.')
        .addIntegerOption((o) => o.setName('id').setDescription('ID Tryout (kosongkan untuk yang terbaru)'))
    )
    .addSubcommand((sub) =>
      sub
        .setName('result')
        .setDescription('Lihat hasil/leaderboard tryout.')
        .addIntegerOption((o) => o.setName('id').setDescription('ID Tryout (kosongkan untuk yang terbaru)'))
    ),

  execute: safeExecute(async (interaction) => {
    const sub = interaction.options.getSubcommand();
    await interaction.deferReply();

    if (sub === 'create') {
      const category = interaction.options.getString('kategori');
      const difficulty = interaction.options.getString('kesulitan');
      const questionCount = interaction.options.getInteger('jumlah_soal');
      const durationMinutes = interaction.options.getInteger('durasi_menit');

      const tryout = await createTryoutPanel(interaction, { category, difficulty, questionCount, durationMinutes });

      await interaction.editReply({
        embeds: [successEmbed(`Panel Tryout **#${tryout.id}** berhasil dibuat di channel ini.`)],
      });
      return;
    }

    if (sub === 'start') {
      const id = resolveActiveId(interaction);
      if (!id) {
        await interaction.editReply({
          embeds: [errorEmbed('Tidak ada tryout aktif yang ditemukan. Sebutkan ID secara spesifik atau buat tryout baru dengan `/tryout create`.')],
        });
        return;
      }

      const result = await startTryout(interaction.guild, id);
      if (!result.ok) {
        await interaction.editReply({ embeds: [errorEmbed(result.reason)] });
        return;
      }

      await syncPanelMessage(interaction.client, result.tryout, true);

      await interaction.editReply({
        embeds: [
          successEmbed(
            `Tryout **#${id}** dimulai. ${result.createdCount}/${result.participantCount} ruang ujian berhasil dibuat.`
          ),
        ],
      });
      return;
    }

    if (sub === 'stop') {
      const id = resolveActiveId(interaction);
      if (!id) {
        await interaction.editReply({ embeds: [errorEmbed('Tidak ada tryout yang bisa dihentikan.')] });
        return;
      }

      const result = await stopTryout(interaction.guild, id);
      if (!result.ok) {
        await interaction.editReply({ embeds: [errorEmbed(result.reason)] });
        return;
      }

      await interaction.editReply({
        embeds: [successEmbed(`Tryout **#${id}** dihentikan. ${result.closedCount} ruang ujian ditutup.`)],
      });
      return;
    }

    if (sub === 'result') {
      const id = resolveActiveId(interaction);
      if (!id) {
        await interaction.editReply({ embeds: [errorEmbed('Tidak ada tryout yang ditemukan di server ini.')] });
        return;
      }

      const data = getResultData(id);
      if (!data) {
        await interaction.editReply({ embeds: [errorEmbed('Tryout dengan ID tersebut tidak ditemukan.')] });
        return;
      }

      await interaction.editReply({ embeds: [renderResultEmbed(data.tryout, data.participants)] });
    }
  }),
};
