// src/commands/materi/materi.js
// /materi <kategori> [topik] - menampilkan ringkasan materi belajar SNBT.

import { SlashCommandBuilder } from 'discord.js';
import { CATEGORIES, getCategoryLabel } from '../../utils/constants.js';
import { generateMaterial } from '../../services/materialGenerator.js';
import { getWeakestCategory } from '../../ai/adaptiveLearning.js';
import { splitIntoEmbeds, errorEmbed } from '../../utils/embeds.js';
import { safeExecute } from '../../handlers/errorHandler.js';

export default {
  data: new SlashCommandBuilder()
    .setName('materi')
    .setDescription('Tampilkan materi belajar SNBT untuk kategori tertentu.')
    .addStringOption((option) =>
      option
        .setName('kategori')
        .setDescription('Kategori materi SNBT')
        .setRequired(true)
        .addChoices(...CATEGORIES)
    )
    .addStringOption((option) =>
      option
        .setName('topik')
        .setDescription('Topik spesifik yang ingin dipelajari (opsional)')
        .setRequired(false)
    ),

  execute: safeExecute(async (interaction) => {
    await interaction.deferReply();

    const category = interaction.options.getString('kategori');
    const topic = interaction.options.getString('topik');

    const weakest = getWeakestCategory(interaction.guildId, interaction.user.id);
    const weakContext =
      weakest && weakest.category === category
        ? `kategori ini (akurasi latihan sejauh ini ${weakest.accuracy}%)`
        : null;

    let material;
    try {
      material = await generateMaterial(category, topic, weakContext);
    } catch (err) {
      await interaction.editReply({ embeds: [errorEmbed(err.message)] });
      return;
    }

    const title = `📘 Materi: ${getCategoryLabel(category)}${topic ? ` — ${topic}` : ''}`;
    const embeds = splitIntoEmbeds(material, { title });

    await interaction.editReply({ embeds });
  }),
};
