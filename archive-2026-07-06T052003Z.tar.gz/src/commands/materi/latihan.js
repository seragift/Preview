// src/commands/materi/latihan.js
// /latihan <kategori> [kesulitan] - memulai sesi latihan soal interaktif.
// Alur: Soal -> Jawab (tombol A/B/C/D) -> Hasil & Pembahasan -> Soal Berikutnya.

import { SlashCommandBuilder } from 'discord.js';
import { CATEGORIES, DIFFICULTIES } from '../../utils/constants.js';
import { generateQuestion } from '../../services/questionGenerator.js';
import { determineAdaptiveDifficulty } from '../../ai/adaptiveLearning.js';
import { startSession, setCurrentQuestion } from '../../ai/latihanSession.js';
import { renderQuestionEmbed, renderAnswerButtons } from '../../utils/latihanRenderer.js';
import { errorEmbed } from '../../utils/embeds.js';
import { safeExecute } from '../../handlers/errorHandler.js';

export default {
  data: new SlashCommandBuilder()
    .setName('latihan')
    .setDescription('Mulai sesi latihan soal SNBT interaktif.')
    .addStringOption((option) =>
      option
        .setName('kategori')
        .setDescription('Kategori soal SNBT')
        .setRequired(true)
        .addChoices(...CATEGORIES)
    )
    .addStringOption((option) =>
      option
        .setName('kesulitan')
        .setDescription('Tingkat kesulitan (kosongkan untuk otomatis/adaptif)')
        .setRequired(false)
        .addChoices(...DIFFICULTIES)
    ),

  execute: safeExecute(async (interaction) => {
    await interaction.deferReply();

    const category = interaction.options.getString('kategori');
    const manualDifficulty = interaction.options.getString('kesulitan');
    const difficulty =
      manualDifficulty ?? determineAdaptiveDifficulty(interaction.guildId, interaction.user.id, category);

    let question;
    try {
      question = await generateQuestion(category, difficulty);
    } catch (err) {
      await interaction.editReply({ embeds: [errorEmbed(err.message)] });
      return;
    }

    const session = startSession(interaction.guildId, interaction.user.id, { category, difficulty });
    setCurrentQuestion(interaction.guildId, interaction.user.id, question);

    await interaction.editReply({
      embeds: [renderQuestionEmbed({ category, difficulty, question, stats: session.stats })],
      components: [renderAnswerButtons(interaction.user.id)],
    });
  }),
};
