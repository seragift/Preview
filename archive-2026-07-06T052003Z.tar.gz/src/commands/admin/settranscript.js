// src/commands/admin/settranscript.js
// /settranscript <channel> - tentukan channel tujuan pengiriman transcript
// lengkap tryout (dikirim otomatis setiap peserta selesai mengerjakan).

import { SlashCommandBuilder, ChannelType, PermissionFlagsBits } from 'discord.js';
import guildSettingsRepository from '../../database/guildSettingsRepository.js';
import { successEmbed } from '../../utils/embeds.js';
import { safeExecute } from '../../handlers/errorHandler.js';

export default {
  data: new SlashCommandBuilder()
    .setName('settranscript')
    .setDescription('Tentukan channel tujuan pengiriman transcript lengkap Tryout.')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addChannelOption((option) =>
      option
        .setName('channel')
        .setDescription('Channel tujuan transcript')
        .addChannelTypes(ChannelType.GuildText)
        .setRequired(true)
    ),

  execute: safeExecute(async (interaction) => {
    const channel = interaction.options.getChannel('channel');

    guildSettingsRepository.setTranscriptChannel(interaction.guildId, channel.id);

    await interaction.reply({
      embeds: [
        successEmbed(
          `Channel transcript berhasil diatur ke ${channel}.\n\nSetiap peserta yang selesai mengerjakan Tryout (baik menyelesaikan semua soal, waktu habis, maupun tryout dihentikan admin) akan otomatis mendapat transcript lengkap di channel ini.`
        ),
      ],
    });
  }),
};
