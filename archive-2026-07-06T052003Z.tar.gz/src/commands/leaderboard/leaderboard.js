// src/commands/leaderboard/leaderboard.js
// /leaderboard [tipe] [tryout_id]
// Menampilkan ranking berdasarkan data Tryout yang sudah diselesaikan.
// TIDAK ada sistem level/XP — murni statistik skor, akurasi, dan jumlah soal.

import { SlashCommandBuilder } from 'discord.js';
import leaderboardRepository from '../../database/leaderboardRepository.js';
import tryoutRepository from '../../database/tryoutRepository.js';
import { resolveUsername } from '../../utils/discordUser.js';
import { renderResultEmbed } from '../../utils/tryoutRenderer.js';
import {
  renderBestScoreLeaderboard,
  renderTotalScoreLeaderboard,
  renderAccuracyLeaderboard,
  renderAnsweredCountLeaderboard,
} from '../../utils/leaderboardRenderer.js';
import { errorEmbed } from '../../utils/embeds.js';
import { safeExecute } from '../../handlers/errorHandler.js';

const TYPE_CHOICES = [
  { name: 'Skor Tryout Tertinggi', value: 'skor_tertinggi' },
  { name: 'Akurasi Tertinggi', value: 'akurasi_tertinggi' },
  { name: 'Soal Terbanyak Diselesaikan', value: 'soal_terbanyak' },
  { name: 'Ranking Server (Total Skor)', value: 'ranking_server' },
  { name: 'Ranking Tryout Tertentu', value: 'ranking_tryout' },
];

async function resolveUsernameMap(client, userIds) {
  const uniqueIds = [...new Set(userIds)];
  const resolved = await Promise.all(uniqueIds.map((userId) => resolveUsername(client, userId)));

  const usernames = new Map();
  uniqueIds.forEach((userId, i) => usernames.set(userId, resolved[i]));
  return usernames;
}

export default {
  data: new SlashCommandBuilder()
    .setName('leaderboard')
    .setDescription('Lihat ranking berdasarkan data Tryout.')
    .addStringOption((option) =>
      option
        .setName('tipe')
        .setDescription('Jenis leaderboard (default: Ranking Server)')
        .setRequired(false)
        .addChoices(...TYPE_CHOICES)
    )
    .addIntegerOption((option) =>
      option
        .setName('tryout_id')
        .setDescription('ID Tryout (khusus tipe "Ranking Tryout Tertentu")')
        .setRequired(false)
    ),

  execute: safeExecute(async (interaction) => {
    await interaction.deferReply();

    const type = interaction.options.getString('tipe') ?? 'ranking_server';

    if (type === 'ranking_tryout') {
      const id =
        interaction.options.getInteger('tryout_id') ??
        tryoutRepository.getLatestByStatus(interaction.guildId, 'finished')?.id;

      if (!id) {
        await interaction.editReply({
          embeds: [errorEmbed('Tidak ada tryout yang selesai di server ini. Sebutkan ID tryout secara spesifik.')],
        });
        return;
      }

      const tryout = tryoutRepository.getById(id);
      if (!tryout) {
        await interaction.editReply({ embeds: [errorEmbed('Tryout dengan ID tersebut tidak ditemukan.')] });
        return;
      }

      const participants = tryoutRepository.listParticipants(id);
      await interaction.editReply({ embeds: [renderResultEmbed(tryout, participants)] });
      return;
    }

    let rows;
    let renderFn;

    if (type === 'skor_tertinggi') {
      rows = leaderboardRepository.getTopBestScore(interaction.guildId);
      renderFn = renderBestScoreLeaderboard;
    } else if (type === 'akurasi_tertinggi') {
      rows = leaderboardRepository.getTopAccuracy(interaction.guildId);
      renderFn = renderAccuracyLeaderboard;
    } else if (type === 'soal_terbanyak') {
      rows = leaderboardRepository.getTopAnsweredCount(interaction.guildId);
      renderFn = renderAnsweredCountLeaderboard;
    } else {
      rows = leaderboardRepository.getTopTotalScore(interaction.guildId);
      renderFn = renderTotalScoreLeaderboard;
    }

    const usernames = await resolveUsernameMap(interaction.client, rows.map((r) => r.user_id));
    const embeds = renderFn(rows, usernames);

    // Discord membatasi maksimal 10 embed per pesan; kirim per batch jika lebih
    // (batch pertama via editReply, sisanya via followUp agar jadi pesan baru).
    for (let i = 0; i < embeds.length; i += 10) {
      const batch = embeds.slice(i, i + 10);
      // eslint-disable-next-line no-await-in-loop
      if (i === 0) await interaction.editReply({ embeds: batch });
      // eslint-disable-next-line no-await-in-loop
      else await interaction.followUp({ embeds: batch });
    }
  }),
};
