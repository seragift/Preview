// src/commands/ai/removechannel.js
// /removechannel - menonaktifkan fitur chat AI Tutor di server ini.

import { SlashCommandBuilder, PermissionFlagsBits } from 'discord.js';
import guildSettingsRepository from '../../database/guildSettingsRepository.js';
import { successEmbed, errorEmbed } from '../../utils/embeds.js';
import { safeExecute } from '../../handlers/errorHandler.js';

export default {
  data: new SlashCommandBuilder()
    .setName('removechannel')
    .setDescription('Nonaktifkan fitur chat AI Tutor di server ini.')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  execute: safeExecute(async (interaction) => {
    const settings = guildSettingsRepository.get(interaction.guildId);

    if (!settings.ai_channel_id) {
      await interaction.reply({
        embeds: [errorEmbed('Belum ada channel AI Tutor yang diatur di server ini.')],
        ephemeral: true,
      });
      return;
    }

    guildSettingsRepository.removeAiChannel(interaction.guildId);

    await interaction.reply({
      embeds: [successEmbed('Fitur chat AI Tutor berhasil dinonaktifkan di server ini.')],
    });
  }),
};
