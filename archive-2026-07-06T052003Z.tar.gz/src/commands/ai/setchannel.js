// src/commands/ai/setchannel.js
// /setchannel <channel> - menentukan channel khusus untuk chat dengan AI Tutor SNBT.

import { SlashCommandBuilder, ChannelType, PermissionFlagsBits } from 'discord.js';
import guildSettingsRepository from '../../database/guildSettingsRepository.js';
import { successEmbed } from '../../utils/embeds.js';
import { safeExecute } from '../../handlers/errorHandler.js';

export default {
  data: new SlashCommandBuilder()
    .setName('setchannel')
    .setDescription('Tetapkan channel khusus untuk chat dengan AI Tutor SNBT.')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addChannelOption((option) =>
      option
        .setName('channel')
        .setDescription('Channel yang akan digunakan untuk chat AI Tutor')
        .addChannelTypes(ChannelType.GuildText)
        .setRequired(true)
    ),

  execute: safeExecute(async (interaction) => {
    const channel = interaction.options.getChannel('channel');

    guildSettingsRepository.setAiChannel(interaction.guildId, channel.id);

    await interaction.reply({
      embeds: [
        successEmbed(
          `Channel AI Tutor berhasil diatur ke ${channel}.\n\nMulai sekarang, member dapat bertanya seputar SNBT/SNBP/UTBK langsung di channel tersebut, termasuk mengirim foto soal untuk dianalisis.`
        ),
      ],
    });
  }),
};
