// src/tryout/tryoutExamEngine.js
// Mesin alur ujian Tryout di dalam ticket masing-masing peserta.
// Soal SUDAH di-generate sekaligus sebelumnya (lihat questionBankGenerator.js),
// jadi di sini bot hanya perlu MENGAMBIL soal dari bank & mencatat jawaban —
// tidak ada lagi pemanggilan AI real-time selama ujian berlangsung.
//
// Alur: kirim soal -> peserta jawab -> pesan yang sama diubah jadi pembahasan
// -> soal berikutnya otomatis dikirim (tanpa perlu tombol "Lanjut").

import tryoutRepository from '../database/tryoutRepository.js';
import tryoutQuestionRepository from '../database/tryoutQuestionRepository.js';
import tryoutAnswerRepository from '../database/tryoutAnswerRepository.js';
import { startTimer, clearTimer } from './examTimers.js';
import { closeTicketChannel } from '../ticket/ticketManager.js';
import { checkAndFinalizeTryout } from './tryoutFinalizer.js';
import {
  renderExamQuestionEmbed,
  renderExamAnswerButtons,
  renderExamResultEmbed,
  renderExamFinalEmbed,
} from '../utils/tryoutExamRenderer.js';
import { errorEmbed } from '../utils/embeds.js';
import logger from '../utils/logger.js';

/** Ambil soal dari bank (sesuai index) & kirim ke channel ticket peserta. */
async function sendQuestion(guild, tryout, participant, channelParam) {
  const channel = channelParam ?? (await guild.channels.fetch(participant.ticket_channel_id));
  const questionIndex = participant.current_question_index;

  const row = tryoutQuestionRepository.getQuestion(tryout.id, questionIndex);
  if (!row) {
    throw new Error(`Soal ke-${questionIndex + 1} tidak ditemukan di bank soal tryout ini.`);
  }

  const question = JSON.parse(row.question_json);

  await channel.send({
    embeds: [
      renderExamQuestionEmbed({ tryout, question, questionNumber: questionIndex + 1 }),
    ],
    components: [renderExamAnswerButtons(tryout.id, participant.user_id)],
  });
}

/** Mulai ujian untuk satu peserta: kirim soal pertama & nyalakan timer keseluruhan ujian. */
export async function startExamForParticipant(guild, tryout, participant, channel) {
  await sendQuestion(guild, tryout, participant, channel);

  const durationMs = tryout.duration_minutes * 60 * 1000;
  startTimer(tryout.id, participant.user_id, durationMs, () => {
    autoSubmitOnTimeout(guild.client, tryout.id, participant.user_id).catch((err) =>
      logger.error(`Gagal auto-submit timeout tryout #${tryout.id} user ${participant.user_id}: ${err.message}`)
    );
  });
}

/**
 * Proses jawaban A/B/C/D dari peserta: catat jawaban, ubah embed soal menjadi
 * pembahasan, lalu (jika belum soal terakhir) langsung kirim soal berikutnya.
 */
export async function handleAnswer(interaction, tryoutId, userId, letter) {
  const tryout = tryoutRepository.getById(tryoutId);
  const participant = tryoutRepository.getParticipant(tryoutId, userId);

  if (!tryout || !participant || participant.status !== 'in_progress' || tryout.status !== 'ongoing') {
    await interaction.reply({ embeds: [errorEmbed('Sesi ujian ini sudah tidak aktif.')], ephemeral: true });
    return;
  }

  const questionIndex = participant.current_question_index;
  const questionRow = tryoutQuestionRepository.getQuestion(tryoutId, questionIndex);

  if (!questionRow) {
    await interaction.reply({ embeds: [errorEmbed('Soal tidak ditemukan.')], ephemeral: true });
    return;
  }

  if (tryoutAnswerRepository.getAnswer(tryoutId, userId, questionIndex)) {
    await interaction.reply({ embeds: [errorEmbed('Soal ini sudah kamu jawab sebelumnya.')], ephemeral: true });
    return;
  }

  const question = JSON.parse(questionRow.question_json);
  const isCorrect = question.correct === letter;

  tryoutAnswerRepository.recordAnswer(tryoutId, userId, questionIndex, letter, isCorrect);
  tryoutRepository.recordAnswerProgress(tryoutId, userId, isCorrect);

  // Ubah embed soal menjadi pembahasan (edit pesan yang sama, tanpa tombol).
  await interaction.update({
    embeds: [
      renderExamResultEmbed({ question, isCorrect, questionNumber: questionIndex + 1, tryout }),
    ],
    components: [],
  });

  const updatedParticipant = tryoutRepository.getParticipant(tryoutId, userId);
  const isLastQuestion = updatedParticipant.current_question_index >= tryout.question_count;

  if (isLastQuestion) {
    clearTimer(tryoutId, userId);
    tryoutRepository.markParticipantFinished(tryoutId, userId);

    const finalParticipant = tryoutRepository.getParticipant(tryoutId, userId);

    await interaction.followUp({
      embeds: [renderExamFinalEmbed({ tryout, participant: finalParticipant, reason: 'selesai' })],
    });

    try {
      await closeTicketChannel(interaction.channel);
    } catch (err) {
      logger.error(`Gagal menutup ticket setelah peserta selesai (tryout #${tryoutId}, user ${userId}): ${err.message}`);
    }

    await checkAndFinalizeTryout(interaction.client, interaction.guild, tryoutId);
    return;
  }

  // Langsung kirim soal berikutnya (tanpa perlu tombol "Lanjut").
  try {
    await sendQuestion(interaction.guild, tryout, updatedParticipant, interaction.channel);
  } catch (err) {
    logger.error(`Gagal mengirim soal berikutnya tryout #${tryoutId} user ${userId}: ${err.message}`);
    await interaction.followUp({ embeds: [errorEmbed(err.message)], ephemeral: true });
  }
}

/** Dipanggil otomatis saat timer ujian seorang peserta habis. */
export async function autoSubmitOnTimeout(client, tryoutId, userId) {
  const participant = tryoutRepository.getParticipant(tryoutId, userId);
  if (!participant || participant.status === 'finished') return;

  const tryout = tryoutRepository.getById(tryoutId);
  tryoutRepository.markParticipantFinished(tryoutId, userId);

  const finalParticipant = tryoutRepository.getParticipant(tryoutId, userId);

  try {
    const channel = await client.channels.fetch(participant.ticket_channel_id);

    await channel.send({
      embeds: [renderExamFinalEmbed({ tryout, participant: finalParticipant, reason: 'waktu_habis' })],
    });

    await closeTicketChannel(channel);
    await checkAndFinalizeTryout(client, channel.guild, tryoutId);
  } catch (err) {
    logger.error(`Gagal memproses auto-submit tryout #${tryoutId} user ${userId}: ${err.message}`);
  }
}

export default { startExamForParticipant, handleAnswer, autoSubmitOnTimeout };
