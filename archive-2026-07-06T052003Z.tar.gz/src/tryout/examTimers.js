// src/tryout/examTimers.js
// Mengelola timer ujian per peserta secara in-memory. Saat waktu habis,
// callback onExpire dipanggil untuk memicu auto-submit.
//
// Sengaja in-memory (bukan disimpan di DB) karena timer Node.js tidak bisa
// diserialisasi; jika bot restart di tengah ujian, peserta yang sedang
// mengerjakan tidak akan auto-submit otomatis sampai admin menjalankan
// `/tryout stop` secara manual — ini adalah batasan yang wajar untuk arsitektur
// single-process seperti ini.

const timers = new Map();

function key(tryoutId, userId) {
  return `${tryoutId}:${userId}`;
}

/** Mulai (atau restart) timer ujian untuk seorang peserta. */
export function startTimer(tryoutId, userId, durationMs, onExpire) {
  clearTimer(tryoutId, userId);

  const handle = setTimeout(() => {
    timers.delete(key(tryoutId, userId));
    onExpire();
  }, durationMs);

  timers.set(key(tryoutId, userId), handle);
}

/** Hentikan timer (dipanggil saat peserta selesai lebih awal atau tryout dihentikan). */
export function clearTimer(tryoutId, userId) {
  const k = key(tryoutId, userId);
  const handle = timers.get(k);
  if (handle) {
    clearTimeout(handle);
    timers.delete(k);
  }
}

export default { startTimer, clearTimer };
