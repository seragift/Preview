// src/tryout/questionBankGenerator.js
// Men-generate SELURUH bank soal untuk satu tryout sekaligus, dipanggil segera
// setelah /tryout create (berjalan di background, tidak memblokir command).
// Dengan ini, soal sudah siap sebelum ujian dimulai — tidak perlu generate
// real-time saat peserta sedang mengerjakan.

import { CATEGORIES } from '../utils/constants.js';
import { generateQuestion } from '../services/questionGenerator.js';
import { hashQuestionText } from '../utils/hash.js';
import tryoutRepository from '../database/tryoutRepository.js';
import tryoutQuestionRepository from '../database/tryoutQuestionRepository.js';
import logger from '../utils/logger.js';

const MAX_ATTEMPTS_PER_QUESTION = 5;

/** Untuk tryout kategori 'campuran', pilih kategori acak setiap soal. */
function pickCategory(tryout) {
  if (tryout.category !== 'campuran') return tryout.category;
  const idx = Math.floor(Math.random() * CATEGORIES.length);
  return CATEGORIES[idx].value;
}

/**
 * Generate seluruh bank soal (sejumlah tryout.question_count) untuk satu tryout.
 * Menandai tryout sebagai 'ready' jika berhasil, atau 'failed' jika salah satu
 * soal gagal dibuat setelah beberapa kali percobaan.
 */
export async function generateQuestionBank(tryout) {
  logger.info(`Mulai membuat bank soal untuk tryout #${tryout.id} (${tryout.question_count} soal)...`);

  for (let index = 0; index < tryout.question_count; index += 1) {
    let inserted = false;
    const avoidList = [];

    for (let attempt = 0; attempt < MAX_ATTEMPTS_PER_QUESTION && !inserted; attempt += 1) {
      const category = pickCategory(tryout);

      try {
        // eslint-disable-next-line no-await-in-loop
        const question = await generateQuestion(category, tryout.difficulty, avoidList);
        const hash = hashQuestionText(question.question);

        if (tryoutQuestionRepository.hashExists(tryout.id, hash)) {
          avoidList.push(question.question);
          continue;
        }

        tryoutQuestionRepository.insertQuestion({
          tryoutId: tryout.id,
          questionIndex: index,
          category,
          hash,
          questionJson: JSON.stringify(question),
        });

        inserted = true;
      } catch (err) {
        logger.error(
          `Gagal generate soal #${index + 1} untuk tryout #${tryout.id} (percobaan ${attempt + 1}/${MAX_ATTEMPTS_PER_QUESTION}): ${err.message}`
        );
      }
    }

    if (!inserted) {
      logger.error(
        `Soal #${index + 1} untuk tryout #${tryout.id} gagal dibuat setelah ${MAX_ATTEMPTS_PER_QUESTION} percobaan. Bank soal ditandai gagal.`
      );
      tryoutRepository.markQuestionGenerationFailed(tryout.id);
      return { ok: false, generatedCount: index };
    }
  }

  tryoutRepository.markQuestionsReady(tryout.id);
  logger.success(`Bank soal untuk tryout #${tryout.id} selesai dibuat (${tryout.question_count} soal).`);

  return { ok: true, generatedCount: tryout.question_count };
}

export default { generateQuestionBank };
