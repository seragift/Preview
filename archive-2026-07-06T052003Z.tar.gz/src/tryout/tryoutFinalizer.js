// src/tryout/tryoutFinalizer.js
// Modul kecil yang dipakai BERSAMA oleh tryoutManager.js (admin actions) dan
// tryoutExamEngine.js (penyelesaian per peserta), sengaja dipisah agar tidak
// terjadi circular import antara keduanya (tryoutManager memanggil exam engine
// untuk mulai ujian, exam engine memanggil finalizer untuk cek penyelesaian).

import tryoutRepository from '../database/tryoutRepository.js';
import { sendTryoutTranscript } from '../transcripts/transcriptService.js';
import { renderPanelEmbed, renderPanelButtons } from '../utils/tryoutRenderer.js';
import logger from '../utils/logger.js';

/**
 * Sinkronkan tampilan panel (embed + tombol) setelah status tryout berubah.
 */
export async function syncPanelMessage(client, tryout, disabled) {
  if (!tryout.panel_channel_id || !tryout.panel_message_id) return;

  try {
    const channel = await client.channels.fetch(tryout.panel_channel_id);
    const message = await channel.messages.fetch(tryout.panel_message_id);
    const count = tryoutRepository.countParticipants(tryout.id);

    await message.edit({
      embeds: [renderPanelEmbed(tryout, count)],
      components: [renderPanelButtons(tryout.id, disabled)],
    });
  } catch (err) {
    logger.warn(`Gagal sinkronisasi panel tryout #${tryout.id}: ${err.message}`);
  }
}

/**
 * Cek apakah SELURUH peserta yang benar-benar memulai ujian (punya ticket)
 * sudah berstatus 'finished'. Jika ya dan tryout masih 'ongoing', tandai
 * tryout selesai secara otomatis dan kirim transcript agregat — tanpa perlu
 * admin menjalankan /tryout stop secara manual.
 */
export async function checkAndFinalizeTryout(client, guild, tryoutId) {
  const tryout = tryoutRepository.getById(tryoutId);
  if (!tryout || tryout.status !== 'ongoing') return;

  const participants = tryoutRepository.listParticipants(tryoutId).filter((p) => p.ticket_channel_id);
  if (participants.length === 0) return;

  const allFinished = participants.every((p) => p.status === 'finished');
  if (!allFinished) return;

  tryoutRepository.markEnded(tryoutId, 'finished');
  logger.info(`Tryout #${tryoutId} otomatis ditandai selesai (semua peserta telah menyelesaikan ujian).`);

  const finished = tryoutRepository.getById(tryoutId);
  await syncPanelMessage(client, finished, true);
  await sendTryoutTranscript(client, guild, tryoutId);
}

/**
 * Finalisasi paksa (dipanggil dari /tryout stop): tandai tryout berakhir
 * dengan status tertentu, lalu kirim transcript agregat mencakup semua
 * peserta yang sempat mengikuti (termasuk yang belum selesai saat dihentikan).
 */
export async function forceFinalizeTryout(client, guild, tryoutId, finalStatus) {
  tryoutRepository.markEnded(tryoutId, finalStatus);
  await sendTryoutTranscript(client, guild, tryoutId);
}

export default { syncPanelMessage, checkAndFinalizeTryout, forceFinalizeTryout };
