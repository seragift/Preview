// src/tryout/tryoutManager.js
// Orkestrasi inti fitur Tryout: membuat panel, memulai (spawn ticket per peserta),
// menghentikan, dan mengambil data hasil. Dipanggil bersama oleh slash command
// (/tryout ...) dan button handler (Join/Leave/Start di panel).

import tryoutRepository from '../database/tryoutRepository.js';
import { createTicketChannel, closeTicketChannel } from '../ticket/ticketManager.js';
import { startExamForParticipant } from './tryoutExamEngine.js';
import { generateQuestionBank } from './questionBankGenerator.js';
import { clearTimer } from './examTimers.js';
import { syncPanelMessage, forceFinalizeTryout } from './tryoutFinalizer.js';
import { renderPanelEmbed, renderPanelButtons } from '../utils/tryoutRenderer.js';
import { createEmbed, successEmbed, errorEmbed } from '../utils/embeds.js';
import { getCategoryLabel, getDifficultyLabel } from '../utils/constants.js';
import logger from '../utils/logger.js';

const TICKET_CATEGORY_NAME = 'TRYOUT SESSIONS';

/**
 * Buat sesi tryout baru sekaligus kirim panel Join/Leave/Start ke channel tempat
 * command dijalankan.
 */
export async function createTryoutPanel(interaction, { category, difficulty, questionCount, durationMinutes }) {
  const tryoutId = tryoutRepository.create({
    guildId: interaction.guildId,
    creatorId: interaction.user.id,
    category,
    difficulty,
    questionCount,
    durationMinutes,
  });

  const tryout = tryoutRepository.getById(tryoutId);

  const message = await interaction.channel.send({
    embeds: [renderPanelEmbed(tryout, 0)],
    components: [renderPanelButtons(tryoutId)],
  });

  tryoutRepository.setPanelMessage(tryoutId, message.channelId, message.id);

  // Generate seluruh bank soal di background (TIDAK memblokir balasan command),
  // sesuai permintaan: soal disiapkan sekaligus saat panel dibuat, bukan
  // real-time saat ujian sedang berlangsung.
  generateQuestionBank(tryout)
    .then(async (result) => {
      const refreshed = tryoutRepository.getById(tryoutId);
      await syncPanelMessage(interaction.client, refreshed, false);

      if (result.ok) {
        await interaction.channel.send({
          embeds: [
            successEmbed(
              `✅ soal untuk Tryout **#${tryoutId}** sudah siap (${tryout.question_count} soal). Tryout bisa di-**Start** kapan saja.`
            ),
          ],
        });
      } else {
        await interaction.channel.send({
          embeds: [
            errorEmbed(
              `⚠️ Gagal menyiapkan seluruh soal untuk Tryout **#${tryoutId}** (baru ${result.generatedCount}/${tryout.question_count} soal berhasil dibuat). Coba buat ulang tryout ini.`
            ),
          ],
        });
      }
    })
    .catch((err) => {
      logger.error(`Kesalahan tak terduga saat generate soal tryout #${tryoutId}: ${err.message}`);
    });

  return tryout;
}

/**
 * Mulai tryout: buat ruang ujian (ticket) privat untuk setiap peserta yang sudah join.
 * @returns {Promise<{ok: boolean, reason?: string, tryout?: object, createdCount?: number, participantCount?: number}>}
 */
export async function startTryout(guild, tryoutId) {
  const tryout = tryoutRepository.getById(tryoutId);

  if (!tryout) return { ok: false, reason: 'Tryout tidak ditemukan.' };
  if (tryout.status !== 'joining') {
    return { ok: false, reason: `Tryout ini sudah berstatus **${tryout.status}**, tidak bisa dimulai lagi.` };
  }
  if (tryout.question_status === 'generating') {
    return { ok: false, reason: 'soal masih diproses AI. Tunggu beberapa saat sampai muncul notifikasi "soal siap", lalu coba lagi.' };
  }
  if (tryout.question_status === 'failed') {
    return { ok: false, reason: 'soal gagal dibuat sepenuhnya. Buat tryout baru untuk mencoba lagi.' };
  }

  const participants = tryoutRepository.listParticipants(tryoutId);
  if (participants.length === 0) {
    return { ok: false, reason: 'Belum ada peserta yang bergabung. Tunggu peserta join terlebih dahulu.' };
  }

  let createdCount = 0;

  for (const participant of participants) {
    try {
      // eslint-disable-next-line no-await-in-loop
      const channel = await createTicketChannel(guild, {
        ownerId: participant.user_id,
        type: 'tryout',
        referenceId: tryoutId,
        categoryName: TICKET_CATEGORY_NAME,
        channelName: `tryout-${tryoutId}-${participant.user_id}`,
        topic: `Ruang ujian Tryout #${tryoutId} untuk peserta ${participant.user_id}`,
      });

      tryoutRepository.setParticipantTicket(tryoutId, participant.user_id, channel.id);

      // eslint-disable-next-line no-await-in-loop
      await channel.send({
        embeds: [
          createEmbed({
            title: '🧪 Ruang Ujian Tryout',
            description:
              `Halo <@${participant.user_id}>! Ini adalah ruang ujian pribadimu untuk **Tryout #${tryoutId}**.\n\n` +
              `**Kategori:** ${getCategoryLabel(tryout.category)}\n` +
              `**Kesulitan:** ${getDifficultyLabel(tryout.difficulty)}\n` +
              `**Jumlah Soal:** ${tryout.question_count}\n` +
              `**Durasi:** ${tryout.duration_minutes} menit\n\n` +
              'Soal pertama akan muncul di bawah ini. Timer ujian dimulai sekarang — jawab secepat dan setepat mungkin!',
          }),
        ],
      });

      try {
        // eslint-disable-next-line no-await-in-loop
        await startExamForParticipant(guild, tryout, tryoutRepository.getParticipant(tryoutId, participant.user_id), channel);
      } catch (err) {
        logger.error(`Gagal mengirim soal pertama untuk ${participant.user_id} (tryout #${tryoutId}): ${err.message}`);
        // eslint-disable-next-line no-await-in-loop
        await channel.send({
          embeds: [
            errorEmbed(
              `Gagal membuat soal pertama: ${err.message}. Admin dapat mencoba \`/tryout stop\` lalu membuat tryout baru.`
            ),
          ],
        });
      }

      createdCount += 1;
    } catch (err) {
      logger.error(`Gagal membuat ticket untuk peserta ${participant.user_id} (tryout #${tryoutId}): ${err.message}`);
    }
  }

  tryoutRepository.markStarted(tryoutId);

  return {
    ok: true,
    tryout: tryoutRepository.getById(tryoutId),
    createdCount,
    participantCount: participants.length,
  };
}

/**
 * Hentikan tryout: tutup semua ticket yang masih terbuka, tandai sesi berakhir,
 * dan kirim SATU transcript agregat mencakup seluruh peserta yang sempat ikut.
 * @returns {Promise<{ok: boolean, reason?: string, tryout?: object, closedCount?: number}>}
 */
export async function stopTryout(guild, tryoutId) {
  const tryout = tryoutRepository.getById(tryoutId);

  if (!tryout) return { ok: false, reason: 'Tryout tidak ditemukan.' };
  if (tryout.status === 'finished' || tryout.status === 'cancelled') {
    return { ok: false, reason: 'Tryout ini sudah berakhir sebelumnya.' };
  }

  const participants = tryoutRepository.listParticipants(tryoutId);
  let closedCount = 0;

  for (const participant of participants) {
    clearTimer(tryoutId, participant.user_id);

    if (!participant.ticket_channel_id) continue;

    const channel = guild.channels.cache.get(participant.ticket_channel_id);
    if (!channel) continue;

    try {
      if (participant.status !== 'finished') {
        tryoutRepository.markParticipantFinished(tryoutId, participant.user_id);
      }

      // eslint-disable-next-line no-await-in-loop
      await closeTicketChannel(channel);
      closedCount += 1;
    } catch (err) {
      logger.error(`Gagal menutup ticket ${participant.ticket_channel_id}: ${err.message}`);
    }
  }

  const finalStatus = tryout.status === 'joining' ? 'cancelled' : 'finished';
  await forceFinalizeTryout(guild.client, guild, tryoutId, finalStatus);
  await syncPanelMessage(guild.client, tryoutRepository.getById(tryoutId), true);

  return { ok: true, tryout: tryoutRepository.getById(tryoutId), closedCount };
}

/** Ambil data tryout + peserta untuk ditampilkan sebagai hasil/leaderboard. */
export function getResultData(tryoutId) {
  const tryout = tryoutRepository.getById(tryoutId);
  if (!tryout) return null;

  const participants = tryoutRepository.listParticipants(tryoutId);
  return { tryout, participants };
}

export { syncPanelMessage };

export default { createTryoutPanel, startTryout, stopTryout, getResultData, syncPanelMessage };
