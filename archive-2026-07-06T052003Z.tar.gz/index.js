// index.js
// Entry point utama bot. Bertugas:
// 1. Validasi konfigurasi wajib
// 2. Inisialisasi Discord Client dengan intents yang diperlukan
// 3. Memuat command & event handler secara otomatis
// 4. Login ke Discord

import { Client, GatewayIntentBits, Partials } from 'discord.js';
import { config } from './src/config/config.js';
import logger from './src/utils/logger.js';
import { loadCommands, getCommandsJSON } from './src/handlers/commandHandler.js';
import { loadEvents } from './src/handlers/eventHandler.js';
import { loadButtonHandlers } from './src/handlers/buttonHandler.js';
import { registerGlobalErrorHandlers } from './src/handlers/errorHandler.js';
import { deployCommands } from './src/handlers/deploy.js';

// Inisialisasi database lebih awal (memastikan schema siap sebelum bot online)
import './src/database/database.js';

registerGlobalErrorHandlers();

function validateConfig() {
  const missing = [];
  if (!config.discord.token) missing.push('DISCORD_TOKEN');
  if (!config.discord.clientId) missing.push('CLIENT_ID');
  if (!config.ai.apiKey) missing.push('NARAROUTER_API_KEY');

  if (missing.length > 0) {
    logger.error(`Konfigurasi wajib belum diisi di .env: ${missing.join(', ')}`);
    process.exit(1);
  }
}

async function main() {
  validateConfig();

  const client = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.MessageContent,
      GatewayIntentBits.GuildMembers,
    ],
    partials: [Partials.Channel, Partials.Message],
  });

  await loadCommands(client);
  await loadEvents(client);
  await loadButtonHandlers(client);

  // Auto-deploy & refresh slash command ke Discord API setiap kali bot start/online.
  // Dilakukan sebelum login karena REST deploy hanya butuh token, tidak butuh
  // koneksi gateway aktif. Dengan begini command selalu sinkron dengan kode terbaru
  // tanpa perlu menjalankan `npm run deploy` secara manual.
  await deployCommands(getCommandsJSON(client));

  await client.login(config.discord.token);
}

main().catch((err) => {
  logger.error(`Gagal menjalankan bot: ${err.stack || err.message}`);
  process.exit(1);
});
