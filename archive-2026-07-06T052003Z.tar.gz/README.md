# SNBT/SNBP/UTBK Discord Bot — Tahap 1: Core + AI Tutor

Tahap ini mencakup fondasi bot (struktur folder, database, command/event handler,
error handler, logger, embed biru tua) dan fitur **AI Assistant / AI Tutor** penuh:
`/setchannel`, `/removechannel`, dan chat AI dengan memory per user.

## Instalasi

```bash
npm install
cp .env.example .env
```

Isi `.env`:

```
DISCORD_TOKEN=isi_token_bot_kamu
CLIENT_ID=isi_application_id_bot
GUILD_ID=isi_id_server_untuk_testing   # kosongkan jika mau deploy global
NARAROUTER_API_KEY=sk-nry-xxxxxxxxxxxxxxxxxxxx
NARAROUTER_BASE_URL=https://router.bynara.id/v1
NARAROUTER_MODEL=mistral-large
```

## Deploy Slash Command

Command **otomatis di-deploy & di-refresh setiap kali bot start** (dilakukan di `index.js`
sebelum bot login ke gateway), jadi kamu tidak perlu menjalankan apa pun secara manual —
cukup `npm start`.

Script manual berikut tetap tersedia bila suatu saat dibutuhkan (mis. deploy command
tanpa menyalakan bot penuh):

```bash
npm run deploy
```

## Jalankan Bot

```bash
npm start
```

## Cara Pakai AI Tutor

1. Jalankan `/setchannel #channel-ai-tutor` (butuh izin Manage Server).
2. Member cukup mengetik pertanyaan di channel tersebut — bot akan otomatis membalas.
3. `/removechannel` untuk menonaktifkan fitur AI Tutor.

## Struktur Folder (Tahap 1)

```
index.js
package.json
src/
├── commands/ai/        → /setchannel, /removechannel
├── events/              → ready, interactionCreate, messageCreate
├── handlers/            → commandHandler, eventHandler, errorHandler, deployCommands
├── database/            → koneksi SQLite + repository (guildSettings, aiMemory)
├── services/aiService.js → koneksi ke NaraRouter (chat + vision)
├── ai/tutor.js          → orkestrasi memory + AI service
├── utils/               → logger, embeds (biru tua)
└── config/config.js     → konfigurasi terpusat
```

## Cara Pakai Materi & Latihan (Tahap 2)

- `/materi kategori:<pilih>` — tampilkan ringkasan materi (konsep dasar, penjelasan, cara cepat SNBT, tips). Opsi `topik` untuk fokus ke sub-materi tertentu.
- `/latihan kategori:<pilih>` — mulai sesi latihan interaktif. Soal & 4 pilihan (A/B/C/D) muncul sebagai tombol. Setelah dijawab, muncul pembahasan lengkap + tombol **Soal Berikutnya** / **Selesai**.
- Kesulitan otomatis menyesuaikan (Adaptive Learning) berdasarkan akurasi kamu di kategori tersebut, kecuali diisi manual lewat opsi `kesulitan`.

## Struktur Folder (update Tahap 2)

```
src/
├── commands/materi/     → /materi, /latihan
├── interactions/buttons/ → handler tombol (latihan: jawab/lanjut/selesai)
├── handlers/buttonHandler.js → auto-loader untuk seluruh button handler (prefix-based router)
├── services/questionGenerator.js → generate soal AI (JSON terstruktur)
├── services/materialGenerator.js → generate materi belajar AI
├── ai/latihanSession.js  → state sesi latihan interaktif (in-memory)
├── ai/adaptiveLearning.js → logika penentuan kesulitan otomatis
├── database/categoryPerformanceRepository.js → statistik performa per kategori
└── utils/latihanRenderer.js → render embed & tombol soal/hasil/ringkasan
```

**Catatan arsitektur tombol**: seluruh customId tombol di bot ini mengikuti pola
`<modul>:<aksi>:<...>` (mis. `latihan:answer:<userId>:A`). `buttonHandler.js` akan
otomatis me-load setiap file di `src/interactions/buttons/` berdasarkan `prefix`
yang diekspor, jadi fitur Tryout/Battle/Ticket di tahap berikutnya tinggal
menambah file baru tanpa mengubah router inti.

## Catatan Umum

- Semua balasan bot memakai embed biru tua (`0x00008B`) sesuai ketentuan.
- Tabel database untuk Tryout, Battle, Leaderboard, Education Hub, dsb akan
  ditambahkan pada tahap-tahap berikutnya agar tidak ada schema kosong/placeholder.
- Deployment ke Pterodactyl: cukup upload seluruh folder ini, set startup command
  `npm install && npm start` (deploy command sudah otomatis, lihat bagian di atas).

## Cara Pakai Tryout — Panel & Ticket (Tahap 3a)

- `/tryout create kategori kesulitan jumlah_soal durasi_menit` — buat panel tryout dengan tombol **Join / Leave / Start** di channel tempat command dijalankan.
- Member klik **Join**/**Leave** untuk mendaftar/batal sebelum tryout dimulai.
- Administrator klik **Start** (atau `/tryout start`) — bot otomatis membuat **ruang ujian privat (ticket)** untuk setiap peserta di kategori channel `TRYOUT SESSIONS`.
- `/tryout stop` — hentikan tryout & tutup semua ruang ujian yang masih terbuka.
- `/tryout result` — lihat leaderboard peserta (skor akan terisi setelah sistem soal & timer di Tahap 3b aktif).

**Catatan:** Tahap 3a fokus pada infrastruktur panel & ticket. Pengiriman soal otomatis, timer ujian, dan auto-submit akan ditambahkan di **Tahap 3b**; transcript otomatis setelah ticket ditutup akan ditambahkan di **Tahap 3c**.

## Struktur Folder (update Tahap 3a)

```
src/
├── commands/tryout/tryout.js  → /tryout create|start|stop|result
├── interactions/buttons/tryout.js → handler tombol Join/Leave/Start
├── tryout/tryoutManager.js    → logika inti create/start/stop/result
├── ticket/ticketManager.js    → modul ticket generik (create/close channel privat)
├── database/tryoutRepository.js, ticketRepository.js
└── utils/tryoutRenderer.js    → render embed panel & leaderboard
```

## Cara Kerja Sistem Soal & Timer (Tahap 3b — revisi)

- Begitu `/tryout create` dijalankan & panel terkirim, bot langsung **membuat seluruh bank soal di background** (sejumlah `jumlah_soal`, sekali jadi untuk semua peserta) — TIDAK generate real-time saat ujian berlangsung lagi.
- Panel menampilkan **Status Bank Soal**: ⏳ Sedang Disiapkan AI → ✅ Siap. Bot juga mengirim notifikasi ke channel begitu bank soal selesai.
- **Start** hanya bisa ditekan setelah bank soal berstatus **Siap**.
- Alur tiap soal: **Jawab (A/B/C/D)** → pesan yang sama otomatis berubah jadi **Hasil & Pembahasan Lengkap** → **soal berikutnya langsung dikirim otomatis** (tanpa tombol "Lanjut").
- **Anti-duplikat**: setiap soal di-hash (SHA-256) saat proses pembuatan bank soal; jika hash sudah ada di tryout yang sama, AI diminta membuat ulang (maks. 5 percobaan per soal).
- **Auto-submit**: jika waktu habis sebelum peserta menyelesaikan semua soal, hasil yang sudah dikerjakan otomatis di-submit dan hasil akhir dikirim ke ticket peserta tersebut.
- Kategori **Campuran** mengacak kategori untuk tiap soal saat bank soal dibuat (mensimulasikan struktur SNBT asli yang mencakup 5 subtes).
- Semua peserta dalam satu tryout mengerjakan **soal yang sama** (dari bank soal bersama), persis seperti ujian resmi.

**Batasan yang perlu diketahui:** timer ujian berjalan in-memory (bukan di database). Jika bot restart di tengah ujian, timer peserta yang sedang berjalan tidak otomatis lanjut — admin perlu `/tryout stop` secara manual untuk sesi yang terlanjur berjalan saat bot down.

## Struktur Folder (update Tahap 3b — revisi)

```
src/
├── tryout/questionBankGenerator.js → generate SELURUH bank soal sekaligus saat /tryout create
├── tryout/tryoutExamEngine.js      → ambil soal dari bank, proses jawaban, auto-submit
├── tryout/examTimers.js            → timer ujian in-memory per peserta
├── database/tryoutQuestionRepository.js → bank soal bersama per tryout (basis Transcript nanti)
├── database/tryoutAnswerRepository.js   → jawaban tiap peserta (terpisah dari bank soal)
├── utils/hash.js                  → hashing SHA-256 untuk anti-duplikat soal
└── utils/tryoutExamRenderer.js    → render embed soal/hasil/final di dalam ticket
```

**Catatan migrasi database:** karena struktur tabel `tryout_questions` berubah (dari per-peserta menjadi bank soal bersama) dan fitur analisis gambar AI Tutor dihapus, jika kamu sudah pernah menjalankan versi sebelumnya, **hapus file `bot.sqlite` lama** (lihat `DATABASE_PATH` di `.env`) sebelum menjalankan versi ini agar schema baru dibuat dari awal.

## Cara Pakai Transcript System (Tahap 3c)

- `/settranscript channel:<pilih>` — tentukan channel tujuan pengiriman transcript lengkap.
- Transcript **otomatis dikirim** setiap peserta selesai — baik karena:
  - menyelesaikan seluruh soal,
  - waktu ujian habis (auto-submit), atau
  - tryout dihentikan paksa oleh admin (`/tryout stop`).
- Begitu transcript terkirim, **ticket peserta tersebut otomatis ditutup & dihapus**.
- Isi transcript (dikirim sebagai file `.txt` + embed ringkasan): seluruh soal yang dikerjakan, jawaban peserta, jawaban benar, pembahasan lengkap, konsep dasar, cara cepat SNBT, tips pengerjaan, hasil akhir, dan statistik pengerjaan — bukan cuma daftar soal.
- Jika `/settranscript` belum diatur, ticket tetap ditutup normal tapi transcript dilewati (dicatat sebagai warning di log).

## Struktur Folder (update Tahap 3c)

```
src/
├── commands/admin/settranscript.js → /settranscript
├── transcripts/transcriptGenerator.js → bangun teks transcript lengkap
└── transcripts/transcriptService.js   → kirim transcript (file + embed) ke channel & trigger tutup ticket
```

---

# Ringkasan Status Fitur (per Tahap 3c)

✅ Core, AI Tutor (teks only — analisis gambar dihapus atas permintaan), Materi & Latihan, Tryout (Panel, Ticket, Bank Soal & Timer, Transcript).

Belum dibangun (mengikuti struktur spesifikasi awal): Prediksi Skor, Rekomendasi PTN, Jadwal Belajar AI, Leaderboard, Battle SNBT, Education Hub (cron), Admin System lanjutan (blacklist/backup/restore/log/announcement).

## Perbaikan & Peningkatan (Update)

### 1. Rumus matematika tidak lagi berantakan
Sebelumnya AI kadang menulis rumus pakai notasi LaTeX (`\frac{1}{2}`, `\sqrt{}`, `\text{}`)
yang tidak bisa dirender Discord sehingga tampil mentah. Sekarang semua system prompt
AI (soal, materi, AI Tutor) mewajibkan format teks biasa/simbol Unicode
(`×`, `÷`, `√`, `²`, `³`, dst) — lihat `src/utils/aiFormattingRules.js`.

### 2. Transcript sekarang juga dalam format Excel
Setiap peserta yang selesai tryout kini menerima **2 file** di channel transcript:
- **`.txt`** — transcript lengkap (soal, jawaban, pembahasan, konsep, cara cepat, tips).
- **`.xlsx`** — analisis performa dengan 3 sheet:
  - **Ringkasan** — skor, akurasi, status.
  - **Per Kategori** — breakdown benar/salah per kategori SNBT, lengkap dengan
    penilaian otomatis (💪 Kuat / ⚠️ Cukup / 🔴 Lemah) untuk melihat kelemahan & kekuatan.
  - **Detail Jawaban** — tabel semua soal, jawaban peserta vs jawaban benar, per baris.

Perlu `npm install` ulang karena menambahkan dependency baru: `exceljs`.

### 3. Memory AI Tutor — penjelasan & peningkatan
AI Tutor **sudah punya memory sejak Tahap 1** dan bekerja seperti ini:
- Setiap pesan (input user & output AI) **disimpan permanen** di tabel `ai_conversations` — tidak pernah dihapus otomatis.
- Setiap kali user chat, bot mengambil **riwayat terakhir** (default 20 pesan, `config.ai.maxHistoryMessages`) dan mengirimkannya sebagai konteks ke AI — sehingga bot paham permintaan lanjutan seperti "kasih soal tentang itu" yang merujuk ke pesan sebelumnya.
- **Baru ditambahkan:** begitu percakapan sudah sangat panjang (pesan lama mulai keluar dari jendela 20 pesan terakhir), bot otomatis meminta AI merangkumnya jadi satu **ringkasan jangka panjang** (`ai_user_state.last_summary`) yang terus digabung setiap kali ada pesan lama baru yang perlu diringkas. Ringkasan ini disisipkan sebagai konteks tambahan di setiap percakapan berikutnya — jadi bot tetap "ingat" topik, kelemahan, dan preferensi user meski sudah chat ratusan kali, tanpa harus mengirim seluruh riwayat mentah ke API (yang akan mahal & lambat).
- Ringkasan dibuat di background (tidak memperlambat balasan ke user) dan hanya dipicu setelah ada ≥10 pesan lama yang menumpuk belum diringkas.

## Struktur Folder (update)

```
src/
├── utils/aiFormattingRules.js       → aturan format matematika untuk semua prompt AI
├── ai/memorySummarizer.js           → menjaga ringkasan memory jangka panjang AI Tutor
└── transcripts/transcriptExcelGenerator.js → generate file .xlsx analisis performa tryout
```

## Perombakan Transcript System (Update 2)

Transcript sekarang **bukan per-peserta lagi**, tapi **satu file Excel per tryout**
yang mencakup SEMUA peserta yang ikut. File `.txt` sudah dihapus sepenuhnya — semua
(soal, jawaban, pembahasan) sekarang ada di dalam file Excel yang sama.

**Kapan transcript dikirim:**
- Otomatis begitu **seluruh peserta** yang memulai ujian sudah menyelesaikan sesi mereka (tidak perlu admin stop manual).
- Atau saat admin menjalankan `/tryout stop` (mencakup peserta yang belum selesai saat itu juga).

**Isi file Excel (`transcript-tryout-<ID>.xlsx`), 3 sheet:**
1. **Ringkasan Peserta** — Username Discord, Soal Diisi, Jawaban Benar, Jawaban Salah, Persentase, dan **Catatan yang Perlu Ditingkatkan** (otomatis menyebutkan kategori dengan akurasi di bawah 60%, atau "Semua kategori sudah baik" kalau tidak ada).
2. **Bank Soal & Pembahasan** — seluruh soal (sekali per soal, tidak diulang per peserta): pertanyaan, 4 pilihan, jawaban benar, pembahasan, konsep dasar, cara cepat SNBT, tips pengerjaan.
3. **Jawaban Semua Peserta** — jawaban tiap peserta untuk tiap nomor soal (cross-reference ke sheet Bank Soal lewat nomor soal), termasuk peserta yang tidak menjawab (ditandai "Kosong").

**Embed selama ujian disederhanakan:**
- Embed soal → hanya soal + pilihan A/B/C/D (tanpa info kategori/kesulitan/ID yang bikin ramai).
- Embed setelah jawab → hanya status (✅/❌) + pembahasan saja (tanpa jawaban benar/konsep/cara cepat/tips yang sekarang dipindah ke file Excel transcript).

## Struktur Folder (update 2)

```
src/
├── tryout/tryoutFinalizer.js → deteksi tryout selesai (semua peserta selesai) + trigger transcript agregat
└── transcripts/transcriptExcelGenerator.js → 1 workbook Excel per tryout (bukan per peserta)
```

## Update: Transcript Excel + PDF & Panel Diperbarui

**Transcript sekarang 2 file per tryout:**
- **`.xlsx`** (Ringkasan Peserta) — username Discord, soal diisi, benar, salah, persentase, catatan yang perlu ditingkatkan. Cocok untuk sort/filter.
- **`.pdf`** (Soal & Pembahasan) — seluruh bank soal beserta pembahasan lengkap (konsep dasar, cara cepat SNBT, tips). Fokus murni sebagai bahan review soal, tanpa data jawaban peserta (itu ada di Excel).

Perlu `npm install` ulang (dependency baru: `pdfkit`).

**Panel Tryout didesain ulang:**
- Instruksi Join/Leave/Start ditulis lebih jelas dengan emoji penanda.
- Field dikelompokkan lebih rapi: Kategori, Kesulitan (dengan indikator warna 🟢🟡🔴), Jumlah Soal, Durasi, Peserta Terdaftar, Status Bank Soal, Status Sesi, dan **Dibuat oleh** (menampilkan admin pembuat tryout).
- Tombol Join/Leave/Start sekarang punya ikon (✅/🚪/▶️).

## Struktur Folder (update 3)

```
src/
└── transcripts/transcriptPdfGenerator.js → PDF bank soal, pembahasan, dan jawaban semua peserta
```

## Leaderboard

`/leaderboard tipe:<pilih> tryout_id:<opsional>` — 5 jenis ranking, semua murni dari data Tryout, **tanpa sistem level/XP**:

- **Skor Tryout Tertinggi** — skor terbaik dari satu sesi tryout (peak performance) per user.
- **Akurasi Tertinggi** — total jawaban benar dibagi total soal, akumulasi seluruh tryout yang pernah diselesaikan user di server ini.
- **Soal Terbanyak Diselesaikan** — total soal yang pernah dijawab (di semua tryout).
- **Ranking Server (default)** — total akumulasi skor dari seluruh tryout yang diselesaikan; leaderboard utama server.
- **Ranking Tryout Tertentu** — leaderboard untuk satu sesi tryout spesifik (sama seperti `/tryout result`, bisa diakses lewat sini juga).

Hanya peserta berstatus **selesai** (finished) yang dihitung, supaya leaderboard tidak bias oleh sesi yang belum kelar.

## Struktur Folder (update 4)

```
src/
├── commands/leaderboard/leaderboard.js → /leaderboard
├── database/leaderboardRepository.js   → query agregat ranking
├── utils/leaderboardRenderer.js        → render embed tiap jenis leaderboard
└── utils/discordUser.js                → helper resolve username Discord (dipakai transcript & leaderboard)
```

## Update: 7 Subtes SNBT & Perbaikan Leaderboard

**Kategori diperbarui jadi 7 subtes** (struktur SNBT terbaru), dipakai otomatis di
`/materi`, `/latihan`, dan `/tryout create`:
1. Penalaran Umum (PU)
2. Pengetahuan dan Pemahaman Umum (PPU)
3. Kemampuan Memahami Bacaan dan Menulis (PBM)
4. Pengetahuan Kuantitatif (PK)
5. Literasi Bahasa Indonesia
6. Literasi Bahasa Inggris
7. Penalaran Matematika (PM)

System prompt AI Tutor juga diperbarui untuk menyebutkan ke-7 subtes ini.

**Perbaikan `/leaderboard`:** sebelumnya resolusi username Discord dilakukan
satu-per-satu secara berurutan (bisa lambat/berpotensi macet kalau salah satu
request ke Discord API lambat). Sekarang:
- Semua username diresolusi **paralel** (`Promise.all`), jauh lebih cepat.
- Setiap fetch dibungkus **timeout 5 detik** — kalau macet, otomatis fallback ke placeholder alih-alih membuat command menggantung selamanya.

⚠️ Catatan database: karena `category` disimpan sebagai TEXT bebas (bukan enum
terikat), tryout/materi/latihan LAMA yang dibuat dengan kategori versi 5-subtes
(`penalaran_umum`, `pengetahuan_kuantitatif`) tetap tersimpan apa adanya di
database, tapi label barunya (7 subtes) tidak akan otomatis cocok untuk data
lama tersebut. Ini hanya memengaruhi tampilan riwayat lama, bukan fitur yang
sedang berjalan.

## Update: Leaderboard Tampilkan Semua Member

`/leaderboard` sekarang menampilkan **SEMUA member** yang pernah menyelesaikan
tryout (bukan cuma top-10), diurutkan dari skor tertinggi ke terendah. Default
tampilan (tanpa pilih `tipe`) adalah **Ranking Server** — total skor tertinggi
seluruh member.

Kalau daftar member panjang (lebih dari yang muat di satu embed ~4000 karakter),
bot otomatis memecahnya jadi beberapa embed/pesan berurutan, jadi tidak ada
member yang terpotong dari daftar.
