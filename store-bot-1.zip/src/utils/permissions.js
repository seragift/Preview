'use strict';

/**
 * Mengecek apakah member memiliki role admin yang dikonfigurasi di config.json.
 * Sengaja TIDAK mengandalkan Discord Administrator permission bawaan,
 * sesuai requirement: hanya role admin dari config.json yang dihitung.
 */
function isAdmin(member, config) {
  const adminRoleId = config?.roles?.adminRoleId;
  if (!member || !adminRoleId) return false;
  return member.roles.cache.has(adminRoleId);
}

/**
 * Mengecek apakah user adalah owner bot (berdasarkan config.ownerId).
 * Kalau ownerId belum diisi di config.json, semua orang dianggap BUKAN owner
 * (fail-closed) supaya command tidak sengaja terbuka untuk semua orang.
 */
function isOwner(userId, config) {
  const ownerId = config?.ownerId;
  if (!userId || !ownerId) return false;
  return userId === ownerId;
}

module.exports = { isAdmin, isOwner };
