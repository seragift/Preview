'use strict';

/**
 * Format tanggal/waktu ke zona waktu Indonesia Barat (WIB / Asia-Jakarta),
 * terlepas dari timezone server/VPS tempat bot dijalankan.
 */
function formatWIB(input) {
  const date = input instanceof Date ? input : new Date(input);
  const formatted = date.toLocaleString('id-ID', {
    timeZone: 'Asia/Jakarta',
    dateStyle: 'long',
    timeStyle: 'short',
  });
  return `${formatted} WIB`;
}

module.exports = { formatWIB };
