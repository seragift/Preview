'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DATA_PATH = path.join(__dirname, '..', 'data', 'pending-testimoni.json');

function load() {
  try {
    const raw = fs.readFileSync(DATA_PATH, 'utf-8');
    return JSON.parse(raw || '{}');
  } catch (err) {
    if (err.code === 'ENOENT') {
      fs.writeFileSync(DATA_PATH, '{}', 'utf-8');
      return {};
    }
    throw err;
  }
}

function save(data) {
  fs.writeFileSync(DATA_PATH, JSON.stringify(data, null, 2), 'utf-8');
}

/**
 * Membuat sesi testimoni baru yang menunggu diisi oleh buyer.
 * Mengembalikan pendingId unik yang dipakai di customId tombol/modal.
 */
function createPending({ guildId, buyerId, sellerId, garansiHari, buktiUrl, createdBy }) {
  const data = load();
  let pendingId;
  do {
    pendingId = crypto.randomBytes(8).toString('hex');
  } while (data[pendingId]);

  data[pendingId] = {
    guildId,
    buyerId,
    sellerId,
    garansiHari,
    buktiUrl: buktiUrl || null,
    createdBy,
    channelId: null,
    messageId: null,
    createdAt: Date.now(),
  };

  save(data);
  return pendingId;
}

function getPending(pendingId) {
  const data = load();
  return data[pendingId] || null;
}

/**
 * Menyimpan referensi channel & message dari embed prompt,
 * supaya tombolnya bisa di-disable setelah testimoni diisi.
 */
function attachPromptMessage(pendingId, { channelId, messageId }) {
  const data = load();
  if (!data[pendingId]) return null;
  data[pendingId].channelId = channelId;
  data[pendingId].messageId = messageId;
  save(data);
  return data[pendingId];
}

function deletePending(pendingId) {
  const data = load();
  if (!data[pendingId]) return;
  delete data[pendingId];
  save(data);
}

module.exports = { createPending, getPending, attachPromptMessage, deletePending };
