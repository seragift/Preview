'use strict';

const {
  ChannelType,
  PermissionsBitField,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  AttachmentBuilder,
} = require('discord.js');
const { getConfig } = require('./configManager');
const { infoEmbed, errorEmbed, successEmbed } = require('./embedBuilder');
const { formatWIB } = require('./dateFormatter');

const CATEGORY_INFO = {
  ticket_order: { prefix: 'order', label: '🛒 Order' },
  ticket_ask_reward: { prefix: 'ask', label: '🎉 Ask/Reward' },
  ticket_warranty: { prefix: 'garansi', label: '✅ Claim Garansi' },
};

const AUTO_CLOSE_CHECK_INTERVAL_MS = 30 * 60 * 1000; // cek ticket tidak aktif tiap 30 menit
const TRANSCRIPT_MESSAGE_LIMIT = 500; // maksimal pesan yang diambil per transcript

function sanitizeUsername(username) {
  return username.toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 20) || 'user';
}

function findExistingTicket(guild, prefix, userId) {
  return guild.channels.cache.find((ch) => ch.topic === `ticket:${prefix}:${userId}`) || null;
}

/**
 * Membaca topic channel ticket (format "ticket:<kategori>:<buyerId>")
 * dan mengembalikan { prefix, buyerId }, atau null kalau bukan channel ticket.
 */
function parseTicketTopic(topic) {
  if (typeof topic !== 'string') return null;
  const parts = topic.split(':');
  if (parts[0] !== 'ticket') return null;
  return { prefix: parts[1], buyerId: parts[2] };
}

async function createTicket(interaction, customId) {
  const config = getConfig();
  const info = CATEGORY_INFO[customId];
  if (!info) return;

  const { guild, user } = interaction;
  const categoryId = config.channels?.ticketCategoryId;

  if (!categoryId) {
    return interaction.reply({
      embeds: [errorEmbed('Kategori ticket belum dikonfigurasi. Hubungi admin.')],
      ephemeral: true,
    });
  }

  await interaction.deferReply({ ephemeral: true });

  const existing = findExistingTicket(guild, info.prefix, user.id);
  if (existing) {
    return interaction.editReply({
      embeds: [errorEmbed(`Kamu sudah memiliki ticket kategori ini: <#${existing.id}>`)],
    });
  }

  const adminRoleId = config.roles?.adminRoleId;
  const channelName = `${info.prefix}-${sanitizeUsername(user.username)}`;

  const overwrites = [
    {
      id: guild.roles.everyone.id,
      deny: [PermissionsBitField.Flags.ViewChannel],
    },
    {
      id: user.id,
      allow: [
        PermissionsBitField.Flags.ViewChannel,
        PermissionsBitField.Flags.SendMessages,
        PermissionsBitField.Flags.ReadMessageHistory,
      ],
    },
    {
      id: guild.members.me.id,
      allow: [
        PermissionsBitField.Flags.ViewChannel,
        PermissionsBitField.Flags.SendMessages,
        PermissionsBitField.Flags.ManageChannels,
        PermissionsBitField.Flags.ManageMessages,
      ],
    },
  ];

  if (adminRoleId) {
    overwrites.push({
      id: adminRoleId,
      allow: [PermissionsBitField.Flags.ViewChannel],
    });
  }

  let channel;
  try {
    channel = await guild.channels.create({
      name: channelName,
      type: ChannelType.GuildText,
      parent: categoryId,
      topic: `ticket:${info.prefix}:${user.id}`,
      permissionOverwrites: overwrites,
    });
  } catch (err) {
    console.error('[TicketManager] Gagal membuat channel ticket:', err.message);
    return interaction.editReply({
      embeds: [errorEmbed('Gagal membuat ticket. Periksa permission bot atau category ID di config.json.')],
    });
  }

  const embed = infoEmbed({
    title: '🎫 Ticket Dibuat',
    description: 'Silakan jelaskan kebutuhan kamu dengan jelas.',
    fields: [
      { name: 'Kategori', value: info.label, inline: true },
      { name: 'Customer', value: `<@${user.id}>`, inline: true },
    ],
  });

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('ticket_close').setLabel('Tutup Ticket').setEmoji('🔒').setStyle(ButtonStyle.Danger),
  );

  await channel.send({ content: `<@${user.id}>`, embeds: [embed], components: [row] });

  await interaction.editReply({
    embeds: [successEmbed({ title: '✅ Ticket Dibuat', description: `Ticket kamu telah dibuat di <#${channel.id}>` })],
  });
}

async function requestCloseConfirmation(interaction) {
  const embed = infoEmbed({
    title: '🔒 Tutup Ticket',
    description: 'Apakah kamu yakin ingin menutup ticket ini?',
  });

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('ticket_close_confirm').setLabel('Tutup').setEmoji('✅').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId('ticket_close_cancel').setLabel('Batal').setEmoji('❌').setStyle(ButtonStyle.Secondary),
  );

  await interaction.reply({ embeds: [embed], components: [row], ephemeral: true });
}

/**
 * Mengambil riwayat pesan sebuah channel ticket dan menyusunnya jadi teks transcript.
 * Dibatasi TRANSCRIPT_MESSAGE_LIMIT pesan supaya tidak membebani API untuk ticket yang sangat panjang.
 */
async function generateTranscript(channel) {
  let allMessages = [];
  let beforeId;

  while (allMessages.length < TRANSCRIPT_MESSAGE_LIMIT) {
    const options = { limit: 100 };
    if (beforeId) options.before = beforeId;

    let batch;
    try {
      batch = await channel.messages.fetch(options);
    } catch (err) {
      break;
    }

    if (!batch || batch.size === 0) break;

    allMessages = allMessages.concat(Array.from(batch.values()));
    beforeId = batch.last().id;

    if (batch.size < 100) break;
  }

  allMessages.reverse(); // urutkan dari pesan terlama ke terbaru

  if (allMessages.length === 0) {
    return '(Tidak ada pesan di ticket ini.)';
  }

  const lines = allMessages.map((msg) => {
    const time = formatWIB(msg.createdTimestamp);
    const author = msg.author?.tag || msg.author?.username || 'Unknown';
    const content = msg.content || '';
    const attachmentNote = msg.attachments?.size ? ` [${msg.attachments.size} lampiran]` : '';
    return `[${time}] ${author}: ${content}${attachmentNote}`;
  });

  return lines.join('\n');
}

/**
 * Membuat file transcript (.txt) dari sebuah channel ticket, lalu mengirimkannya:
 * 1) ke channel transcript/log yang dikonfigurasi di config.json (kalau ada), dan
 * 2) ke DM buyer (kalau ticket.dmTranscriptToBuyer tidak di-set false dan buyerId diketahui).
 * Kegagalan salah satu tujuan tidak menggagalkan pengiriman ke tujuan lainnya.
 */
async function sendTranscriptLog(client, channel, { closedBy, reason, buyerId }) {
  const config = getConfig();

  let transcriptText;
  try {
    transcriptText = await generateTranscript(channel);
  } catch (err) {
    console.error('[TicketManager] Gagal membuat transcript:', err.message);
    return;
  }

  const transcriptChannelId = config.channels?.transcriptChannelId || config.channels?.logChannelId;

  if (transcriptChannelId) {
    try {
      const file = new AttachmentBuilder(Buffer.from(transcriptText, 'utf-8'), {
        name: `transcript-${channel.name}.txt`,
      });

      const logChannel = await client.channels.fetch(transcriptChannelId);
      if (logChannel?.isTextBased()) {
        const embed = infoEmbed({
          title: '📄 Transcript Ticket',
          fields: [
            { name: 'Channel', value: `#${channel.name}`, inline: true },
            { name: 'Ditutup Oleh', value: closedBy ? `<@${closedBy}>` : 'Sistem (auto-close)', inline: true },
            { name: 'Alasan', value: reason || '-' },
          ],
        });

        await logChannel.send({ embeds: [embed], files: [file] });
      }
    } catch (err) {
      console.error('[TicketManager] Gagal mengirim transcript ke channel log:', err.message);
    }
  }

  const dmEnabled = config.ticket?.dmTranscriptToBuyer !== false; // default aktif kecuali di-set false
  if (dmEnabled && buyerId) {
    try {
      const dmFile = new AttachmentBuilder(Buffer.from(transcriptText, 'utf-8'), {
        name: `transcript-${channel.name}.txt`,
      });

      const buyerUser = await client.users.fetch(buyerId);
      const dmEmbed = infoEmbed({
        title: '📄 Transcript Ticket Kamu',
        description: `Berikut riwayat percakapan ticket **#${channel.name}** yang baru saja ditutup.`,
      });

      await buyerUser.send({ embeds: [dmEmbed], files: [dmFile] });
    } catch (err) {
      // Wajar gagal kalau buyer menutup DM dari member non-server / privasi server dimatikan.
      console.error('[TicketManager] Gagal mengirim transcript ke DM buyer:', err.message);
    }
  }
}

async function confirmClose(interaction) {
  const { channel, client } = interaction;
  const ticketInfo = parseTicketTopic(channel.topic);

  await interaction.update({
    embeds: [successEmbed({ title: '🔒 Ticket Ditutup', description: 'Channel ini telah dikunci dan akan segera dihapus.' })],
    components: [],
  });

  await sendTranscriptLog(client, channel, {
    closedBy: interaction.user.id,
    reason: 'Ditutup manual melalui tombol Tutup Ticket.',
    buyerId: ticketInfo?.buyerId,
  });

  try {
    if (ticketInfo?.buyerId) {
      await channel.permissionOverwrites.edit(ticketInfo.buyerId, { SendMessages: false });
    }
  } catch (err) {
    console.error('[TicketManager] Gagal mengunci channel:', err.message);
  }

  setTimeout(async () => {
    try {
      await channel.delete('Ticket ditutup oleh user.');
    } catch (err) {
      console.error('[TicketManager] Gagal menghapus channel:', err.message);
    }
  }, 5000);
}

async function cancelClose(interaction) {
  await interaction.update({
    embeds: [infoEmbed({ title: '❌ Dibatalkan', description: 'Penutupan ticket dibatalkan.' })],
    components: [],
  });
}

/**
 * Menutup satu channel ticket secara otomatis karena tidak aktif:
 * kirim notice, buat transcript, lalu hapus channel.
 */
async function autoCloseTicket(channel) {
  const ticketInfo = parseTicketTopic(channel.topic);

  try {
    await channel.send({
      embeds: [
        infoEmbed({
          title: '🔒 Ticket Ditutup Otomatis',
          description: 'Ticket ini ditutup otomatis karena tidak ada aktivitas dalam waktu yang lama.',
        }),
      ],
    });
  } catch (err) {
    console.error('[TicketManager] Gagal mengirim notice auto-close:', err.message);
  }

  await sendTranscriptLog(channel.client, channel, {
    closedBy: null,
    reason: 'Auto-close: tidak ada aktivitas.',
    buyerId: ticketInfo?.buyerId,
  });

  try {
    await channel.delete('Auto-close: tidak ada aktivitas.');
  } catch (err) {
    console.error('[TicketManager] Gagal menghapus channel (auto-close):', err.message);
  }
}

/**
 * Memindai semua channel ticket di ticketCategoryId, dan menutup otomatis
 * yang sudah tidak aktif melewati batas ticket.autoClose.inactiveHours.
 */
async function checkInactiveTickets(client) {
  const config = getConfig();
  const autoClose = config.ticket?.autoClose;
  if (!autoClose?.enabled) return;

  const categoryId = config.channels?.ticketCategoryId;
  if (!categoryId) return;

  const inactiveMs = (autoClose.inactiveHours || 24) * 60 * 60 * 1000;
  const guildId = process.env.GUILD_ID;

  try {
    const guild = await client.guilds.fetch(guildId);
    const channels = await guild.channels.fetch();

    const ticketChannels = channels.filter(
      (ch) => ch && ch.parentId === categoryId && typeof ch.topic === 'string' && ch.topic.startsWith('ticket:'),
    );

    for (const channel of ticketChannels.values()) {
      let lastActivity = channel.createdTimestamp;

      try {
        const lastMessages = await channel.messages.fetch({ limit: 1 });
        const lastMsg = lastMessages.first();
        if (lastMsg) lastActivity = lastMsg.createdTimestamp;
      } catch (err) {
        // Channel kosong atau gagal fetch pesan -> pakai waktu channel dibuat.
      }

      const inactiveDuration = Date.now() - lastActivity;
      if (inactiveDuration >= inactiveMs) {
        await autoCloseTicket(channel);
      }
    }
  } catch (err) {
    console.error('[TicketManager] Gagal memindai ticket tidak aktif:', err.message);
  }
}

/**
 * Dipanggil sekali saat bot ready untuk mengaktifkan safety-net auto-close ticket.
 */
function init(client) {
  setInterval(() => {
    checkInactiveTickets(client).catch((err) => console.error('[TicketManager] Error interval auto-close:', err.message));
  }, AUTO_CLOSE_CHECK_INTERVAL_MS);
}

module.exports = { init, createTicket, requestCloseConfirmation, confirmClose, cancelClose };
