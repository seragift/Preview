'use strict';

const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { getConfig } = require('../utils/configManager');
const { isOwner } = require('../utils/permissions');
const { infoEmbed, errorEmbed } = require('../utils/embedBuilder');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('panelticket')
    .setDescription('Mengirim panel ticket untuk customer.'),

  async execute(interaction) {
    const config = getConfig();

    if (!isOwner(interaction.user.id, config)) {
      return interaction.reply({
        embeds: [errorEmbed('Command ini hanya dapat digunakan oleh owner bot.')],
        ephemeral: true,
      });
    }

    const ticketConfig = config.ticket || {};
    const categories = ticketConfig.categories || {};

    const descriptionParts = [
      ticketConfig.panelDescription || 'Pilih kategori yang sesuai, lalu ikuti langkah berikutnya.',
      '',
      '**Membuat ticket harus memiliki tujuan yang jelas!**',
      '',
    ];

    const buttons = [];

    if (categories.order?.enabled !== false) {
      descriptionParts.push(`${categories.order?.label || '🛒 Order'}\n${categories.order?.description || ''}`, '');
      buttons.push(new ButtonBuilder().setCustomId('ticket_order').setLabel('Order').setEmoji('🛒').setStyle(ButtonStyle.Success));
    }

    if (categories.askReward?.enabled !== false) {
      descriptionParts.push(`${categories.askReward?.label || '🎉 Ask/Reward'}\n${categories.askReward?.description || ''}`, '');
      buttons.push(new ButtonBuilder().setCustomId('ticket_ask_reward').setLabel('Ask/Reward').setEmoji('🎉').setStyle(ButtonStyle.Danger));
    }

    if (categories.warranty?.enabled !== false) {
      descriptionParts.push(`${categories.warranty?.label || '✅ Claim Garansi'}\n${categories.warranty?.description || ''}`, '');
      buttons.push(new ButtonBuilder().setCustomId('ticket_warranty').setLabel('Claim Garansi').setEmoji('✅').setStyle(ButtonStyle.Primary));
    }

    const embed = infoEmbed({
      title: ticketConfig.panelTitle || '🎫 Dream Space — Ticket Panel',
      description: descriptionParts.join('\n'),
    });

    const row = new ActionRowBuilder().addComponents(...buttons);

    await interaction.reply({ embeds: [embed], components: [row] });
  },
};
