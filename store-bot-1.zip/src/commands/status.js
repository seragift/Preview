'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { getConfig, updateConfig } = require('../utils/configManager');
const { isOwner } = require('../utils/permissions');
const { errorEmbed, infoEmbed, successEmbed } = require('../utils/embedBuilder');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('status')
    .setDescription('Mengubah status toko (OPEN/CLOSE) dan mengirim pengumuman.')
    .addStringOption((option) =>
      option
        .setName('status')
        .setDescription('Status toko')
        .setRequired(true)
        .addChoices({ name: 'OPEN', value: 'OPEN' }, { name: 'CLOSE', value: 'CLOSE' }),
    ),

  async execute(interaction) {
    const config = getConfig();

    if (!isOwner(interaction.user.id, config)) {
      return interaction.reply({
        embeds: [errorEmbed('Command ini hanya dapat digunakan oleh owner bot.')],
        ephemeral: true,
      });
    }

    const status = interaction.options.getString('status', true);
    const statusConfig = config.status || {};

    let embed;

    if (status === 'CLOSE') {
      const emoji = statusConfig.closeEmoji || '🔴';
      const channelId = statusConfig.closeInfoChannelId;

      if (!channelId) {
        return interaction.reply({
          embeds: [errorEmbed('Channel info store belum dikonfigurasi di config.json (status.closeInfoChannelId).')],
          ephemeral: true,
        });
      }

      embed = infoEmbed({
        title: `${emoji} STORE CLOSE ${emoji}`,
        description:
          `Toko telah **TUTUP**. Silakan tunggu informasi store di <#${channelId}> .\n` +
          'Dan jika ada yang ingin ditanyakan silahkan buat ticket.',
      }).setColor('#ED4245');
    } else {
      const emoji = statusConfig.openEmoji || '🟢';
      const channelId = statusConfig.openOrderChannelId;

      if (!channelId) {
        return interaction.reply({
          embeds: [errorEmbed('Channel order belum dikonfigurasi di config.json (status.openOrderChannelId).')],
          ephemeral: true,
        });
      }

      embed = infoEmbed({
        title: `${emoji} STORE OPEN ${emoji}`,
        description:
          `Toko telah **dibuka**. Silakan order buat tiket di <#${channelId}> .\n` +
          'Dan jika ada yang ingin ditanyakan silahkan sudah online siap membantu.',
      }).setColor('#57F287');
    }

    const messagePayload = { embeds: [embed] };

    if (statusConfig.notifyRoleId) {
      messagePayload.content = `<@&${statusConfig.notifyRoleId}>`;
      messagePayload.allowedMentions = { roles: [statusConfig.notifyRoleId] };
    }

    const statusChannelId = statusConfig.statusChannelId;
    if (!statusChannelId) {
      return interaction.reply({
        embeds: [errorEmbed('Channel status belum dikonfigurasi di config.json (status.statusChannelId).')],
        ephemeral: true,
      });
    }

    let statusChannel;
    try {
      statusChannel = await interaction.guild.channels.fetch(statusChannelId);
    } catch (err) {
      return interaction.reply({
        embeds: [errorEmbed('Channel status tidak ditemukan. Periksa status.statusChannelId di config.json.')],
        ephemeral: true,
      });
    }

    if (!statusChannel?.isTextBased()) {
      return interaction.reply({ embeds: [errorEmbed('Channel status tidak valid.')], ephemeral: true });
    }

    try {
      await statusChannel.send(messagePayload);
    } catch (err) {
      console.error('[Status] Gagal mengirim embed status:', err.message);
      return interaction.reply({
        embeds: [errorEmbed('Gagal mengirim embed status. Periksa permission bot di channel tersebut.')],
        ephemeral: true,
      });
    }

    await interaction.reply({
      embeds: [
        successEmbed({
          title: '✅ Status Diperbarui',
          description: `Status toko berhasil diubah menjadi **${status}**. Pengumuman sudah dikirim ke <#${statusChannelId}>.`,
        }),
      ],
      ephemeral: true,
    });

    await updateConfig((cfg) => {
      cfg.status = cfg.status || {};
      cfg.status.current = status;
      return cfg;
    });
  },
};
