'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { getConfig } = require('../utils/configManager');
const { isAdmin } = require('../utils/permissions');
const { successEmbed, errorEmbed } = require('../utils/embedBuilder');
const { addWarranty } = require('../utils/warrantyManager');
const { formatWIB } = require('../utils/dateFormatter');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('garansi')
    .setDescription('Menambahkan garansi kepada customer.')
    .addUserOption((option) => option.setName('user').setDescription('Customer yang akan diberikan garansi').setRequired(true))
    .addIntegerOption((option) =>
      option.setName('hari').setDescription('Durasi garansi dalam hari (1-999)').setRequired(true).setMinValue(1).setMaxValue(999),
    ),

  async execute(interaction) {
    const config = getConfig();

    if (!isAdmin(interaction.member, config)) {
      return interaction.reply({
        embeds: [errorEmbed('Kamu tidak memiliki permission untuk menggunakan command ini.')],
        ephemeral: true,
      });
    }

    const warrantyRoleId = config.roles?.warrantyRoleId;
    if (!warrantyRoleId) {
      return interaction.reply({ embeds: [errorEmbed('Role garansi belum dikonfigurasi.')], ephemeral: true });
    }

    const targetUser = interaction.options.getUser('user', true);
    const days = interaction.options.getInteger('hari', true);

    await interaction.deferReply();

    try {
      const member = await interaction.guild.members.fetch(targetUser.id);
      await member.roles.add(warrantyRoleId);
      const expiresAt = await addWarranty(targetUser.id, warrantyRoleId, days);

      const formattedDate = formatWIB(expiresAt);

      const embed = successEmbed({
        title: '✅ Garansi Berhasil Ditambahkan',
        fields: [
          { name: 'Customer', value: `<@${targetUser.id}>`, inline: true },
          { name: 'Durasi', value: `${days} Hari`, inline: true },
          { name: 'Berakhir', value: formattedDate, inline: false },
          { name: 'Role', value: `<@&${warrantyRoleId}>`, inline: true },
        ],
      });

      await interaction.editReply({ embeds: [embed] });

      const logChannelId = config.channels?.logChannelId;
      if (logChannelId) {
        try {
          const logChannel = await interaction.guild.channels.fetch(logChannelId);
          if (logChannel?.isTextBased()) {
            await logChannel.send({ embeds: [embed] });
          }
        } catch (err) {
          console.error('[Garansi] Gagal mengirim log:', err.message);
        }
      }
    } catch (err) {
      console.error('[Garansi] Gagal memproses garansi:', err.message);
      return interaction.editReply({ embeds: [errorEmbed('Gagal menambahkan garansi. Periksa role ID atau permission bot.')] });
    }
  },
};
