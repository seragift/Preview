'use strict';

const {
  SlashCommandBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  EmbedBuilder,
} = require('discord.js');
const { getConfig, incrementTestimonyCounter } = require('../utils/configManager');
const { isOwner } = require('../utils/permissions');
const { errorEmbed, successEmbed, infoEmbed } = require('../utils/embedBuilder');
const { addWarranty } = require('../utils/warrantyManager');
const { createPending, getPending, attachPromptMessage, deletePending } = require('../utils/testimoniManager');
const { formatWIB } = require('../utils/dateFormatter');

// Menampilkan rating sebagai bintang, contoh: rating 3 -> "⭐⭐⭐ (3/5)"
function starDisplay(rating) {
  return `${'⭐'.repeat(rating)} (${rating}/5)`;
}

async function buildLockedRow(pendingId) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`testimoni_fill_${pendingId}`)
      .setLabel('Testimoni Sudah Diisi')
      .setEmoji('✅')
      .setStyle(ButtonStyle.Success)
      .setDisabled(true),
  );
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('testimoni')
    .setDescription('Membuka sesi testimoni untuk buyer. Garansi baru aktif setelah testimoni diisi.')
    .addUserOption((option) => option.setName('buyer').setDescription('Buyer / customer').setRequired(true))
    .addUserOption((option) => option.setName('seller').setDescription('Seller yang menangani transaksi ini').setRequired(true))
    .addIntegerOption((option) =>
      option.setName('garansi').setDescription('Durasi garansi dalam hari (1-999)').setRequired(true).setMinValue(1).setMaxValue(999),
    )
    .addAttachmentOption((option) => option.setName('bukti').setDescription('Bukti transaksi (gambar, opsional)').setRequired(false)),

  // Dipanggil saat /testimoni dijalankan oleh seller/admin.
  async execute(interaction) {
    const config = getConfig();

    if (!isOwner(interaction.user.id, config)) {
      return interaction.reply({
        embeds: [errorEmbed('Command ini hanya dapat digunakan oleh owner bot.')],
        ephemeral: true,
      });
    }

    const warrantyRoleId = config.roles?.warrantyRoleId;
    if (!warrantyRoleId) {
      return interaction.reply({
        embeds: [errorEmbed('Role garansi belum dikonfigurasi di config.json (roles.warrantyRoleId).')],
        ephemeral: true,
      });
    }

    const buyer = interaction.options.getUser('buyer', true);
    const seller = interaction.options.getUser('seller', true);
    const garansiHari = interaction.options.getInteger('garansi', true);
    const bukti = interaction.options.getAttachment('bukti');

    if (bukti && bukti.contentType && !bukti.contentType.startsWith('image/')) {
      return interaction.reply({ embeds: [errorEmbed('Bukti harus berupa file gambar.')], ephemeral: true });
    }

    await interaction.deferReply();

    const pendingId = createPending({
      guildId: interaction.guildId,
      buyerId: buyer.id,
      sellerId: seller.id,
      garansiHari,
      buktiUrl: bukti?.url || null,
      createdBy: interaction.user.id,
    });

    const embed = infoEmbed({
      title: '📝 Isi Testimoni',
      description:
        `Halo <@${buyer.id}>, silakan klik tombol di bawah untuk mengisi testimoni.\n\n` +
        '⚠️ **Garansi tidak dapat diklaim sebelum testimoni diisi.**',
      fields: [
        { name: 'Buyer', value: `<@${buyer.id}>`, inline: true },
        { name: 'Seller', value: `<@${seller.id}>`, inline: true },
        { name: 'Durasi Garansi', value: `${garansiHari} Hari`, inline: true },
      ],
    });

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`testimoni_fill_${pendingId}`).setLabel('Isi Testimoni').setEmoji('📝').setStyle(ButtonStyle.Primary),
    );

    const sent = await interaction.editReply({ embeds: [embed], components: [row] });
    attachPromptMessage(pendingId, { channelId: sent.channelId, messageId: sent.id });
  },

  // Dipanggil dari interactionHandler saat buyer menekan tombol "Isi Testimoni".
  async handleButtonClick(interaction, pendingId) {
    const pending = getPending(pendingId);

    if (!pending) {
      return interaction.reply({
        embeds: [errorEmbed('Sesi testimoni ini sudah tidak berlaku atau sudah diisi.')],
        ephemeral: true,
      });
    }

    if (interaction.user.id !== pending.buyerId) {
      return interaction.reply({
        embeds: [errorEmbed('Hanya buyer yang bersangkutan yang dapat mengisi testimoni ini.')],
        ephemeral: true,
      });
    }

    const modal = new ModalBuilder().setCustomId(`testimoni_modal_${pendingId}`).setTitle('Isi Testimoni');

    const barangInput = new TextInputBuilder().setCustomId('testimoni_barang').setLabel('Barang').setStyle(TextInputStyle.Short).setRequired(true);
    const hargaInput = new TextInputBuilder()
      .setCustomId('testimoni_harga')
      .setLabel('Harga')
      .setPlaceholder('Contoh: Rp 100.000')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);
    const ratingInput = new TextInputBuilder()
      .setCustomId('testimoni_rating')
      .setLabel('Rating (1-5)')
      .setPlaceholder('Contoh: 5')
      .setStyle(TextInputStyle.Short)
      .setMinLength(1)
      .setMaxLength(1)
      .setRequired(true);
    const noteInput = new TextInputBuilder()
      .setCustomId('testimoni_note')
      .setLabel('Note')
      .setPlaceholder('Pesan testimoni kamu')
      .setStyle(TextInputStyle.Paragraph)
      .setMaxLength(500)
      .setRequired(true);

    modal.addComponents(
      new ActionRowBuilder().addComponents(barangInput),
      new ActionRowBuilder().addComponents(hargaInput),
      new ActionRowBuilder().addComponents(ratingInput),
      new ActionRowBuilder().addComponents(noteInput),
    );

    await interaction.showModal(modal);
  },

  // Dipanggil dari interactionHandler saat buyer submit modal testimoni.
  async handleModalSubmit(interaction, pendingId) {
    const config = getConfig();
    const pending = getPending(pendingId);

    if (!pending) {
      return interaction.reply({
        embeds: [errorEmbed('Sesi testimoni ini sudah tidak berlaku atau sudah diisi.')],
        ephemeral: true,
      });
    }

    if (interaction.user.id !== pending.buyerId) {
      return interaction.reply({
        embeds: [errorEmbed('Hanya buyer yang bersangkutan yang dapat mengisi testimoni ini.')],
        ephemeral: true,
      });
    }

    const barang = interaction.fields.getTextInputValue('testimoni_barang').trim();
    const harga = interaction.fields.getTextInputValue('testimoni_harga').trim();
    const ratingRaw = interaction.fields.getTextInputValue('testimoni_rating').trim();
    const rating = parseInt(ratingRaw, 10);
    const note = interaction.fields.getTextInputValue('testimoni_note').trim();

    if (!Number.isInteger(rating) || rating < 1 || rating > 5) {
      return interaction.reply({ embeds: [errorEmbed('Rating harus berupa angka 1-5.')], ephemeral: true });
    }

    await interaction.deferReply({ ephemeral: true });

    const testimonyChannelId = config.testimony?.channelId || config.channels?.testimonyChannelId;
    if (!testimonyChannelId) {
      return interaction.editReply({ embeds: [errorEmbed('Channel testimoni belum dikonfigurasi.')] });
    }

    let channel;
    try {
      channel = await interaction.guild.channels.fetch(testimonyChannelId);
    } catch (err) {
      return interaction.editReply({ embeds: [errorEmbed('Channel testimoni tidak ditemukan.')] });
    }
    if (!channel?.isTextBased()) {
      return interaction.editReply({ embeds: [errorEmbed('Channel testimoni tidak valid.')] });
    }

    const warrantyRoleId = config.roles?.warrantyRoleId;
    if (!warrantyRoleId) {
      return interaction.editReply({ embeds: [errorEmbed('Role garansi belum dikonfigurasi di config.json.')] });
    }

    // Tambahkan role garansi ke buyer + jadwalkan penghapusan otomatis saat expired.
    let expiresAt;
    try {
      const member = await interaction.guild.members.fetch(pending.buyerId);
      await member.roles.add(warrantyRoleId);
      expiresAt = await addWarranty(pending.buyerId, warrantyRoleId, pending.garansiHari);
    } catch (err) {
      console.error('[Testimoni] Gagal menambahkan role garansi:', err.message);
      return interaction.editReply({
        embeds: [errorEmbed('Testimoni valid, tapi gagal menambahkan role garansi. Periksa role ID atau permission bot, lalu hubungi admin.')],
      });
    }

    const counter = await incrementTestimonyCounter();
    const formattedExpiry = formatWIB(expiresAt);

    const embed = new EmbedBuilder()
      .setColor(config.bot?.color || '#5865F2')
      .setTitle('✅ NEW TESTIMONY - DREAM SPACE STORE')
      .setDescription('Sebuah transaksi baru telah berhasil diselesaikan!')
      .addFields(
        { name: '👤 Pembeli', value: `<@${pending.buyerId}>`, inline: true },
        { name: '👨‍💼 Seller', value: `<@${pending.sellerId}>`, inline: true },
        { name: '📦 Barang', value: `\`${barang}\`` },
        { name: '💰 Harga', value: `\`${harga}\`` },
        { name: '⭐ Rating', value: starDisplay(rating) },
        { name: '📝 Note', value: note },
        { name: '🛡️ Garansi', value: `${pending.garansiHari} Hari (berakhir ${formattedExpiry})` },
      )
      .setFooter({ text: config.bot?.footer || 'Dream Space © 2026' })
      .setTimestamp();

    if (pending.buktiUrl) embed.setImage(pending.buktiUrl);

    await channel.send({ content: `Makasih Dah Order & Testimoni #${counter}`, embeds: [embed] });

    // Kunci tombol di embed prompt supaya testimoni tidak bisa diisi ulang.
    if (pending.channelId && pending.messageId) {
      try {
        const promptChannel = await interaction.guild.channels.fetch(pending.channelId);
        if (promptChannel?.isTextBased()) {
          const promptMessage = await promptChannel.messages.fetch(pending.messageId);
          await promptMessage.edit({ components: [await buildLockedRow(pendingId)] });
        }
      } catch (err) {
        console.error('[Testimoni] Gagal mengunci tombol prompt:', err.message);
      }
    }

    deletePending(pendingId);

    await interaction.editReply({
      embeds: [
        successEmbed({
          title: '✅ Testimoni Terkirim',
          description: `Testimoni #${counter} berhasil dikirim ke <#${channel.id}> dan role garansi telah aktif sampai ${formattedExpiry}.`,
        }),
      ],
    });
  },
};
