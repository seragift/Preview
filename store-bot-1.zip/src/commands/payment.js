'use strict';

const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { getConfig } = require('../utils/configManager');
const { isOwner } = require('../utils/permissions');
const { infoEmbed, errorEmbed } = require('../utils/embedBuilder');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('payment')
    .setDescription('Menampilkan metode pembayaran yang tersedia.'),

  async execute(interaction) {
    const config = getConfig();

    if (!isOwner(interaction.user.id, config)) {
      return interaction.reply({
        embeds: [errorEmbed('Command ini hanya dapat digunakan oleh owner bot.')],
        ephemeral: true,
      });
    }

    const embed = infoEmbed({
      title: '💳 Metode Pembayaran',
      description:
        'Pilih salah satu tombol di bawah untuk melihat detail pembayaran.\n\n' +
        '**DANA**\nKlik tombol di bawah untuk detail\n\n' +
        '**QRIS**\nKlik tombol di bawah untuk detail',
    });

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('payment_dana').setLabel('DANA').setEmoji('🔵').setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId('payment_qris').setLabel('QRIS').setEmoji('🟢').setStyle(ButtonStyle.Success),
    );

    await interaction.reply({ embeds: [embed], components: [row] });
  },
};
