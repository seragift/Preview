'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { getConfig } = require('../utils/configManager');
const { isOwner } = require('../utils/permissions');
const { infoEmbed, errorEmbed } = require('../utils/embedBuilder');

const COMMAND_LIST = [
  { usage: '/payment', desc: 'Menampilkan metode pembayaran (DANA/QRIS) dengan tombol detail.' },
  { usage: '/panelticket', desc: 'Mengirim panel ticket (Order / Ask-Reward / Claim Garansi).' },
  { usage: '/addcus user:@user', desc: 'Menambahkan role buyer ke customer.' },
  { usage: '/garansi user:@user hari:<1-999>', desc: 'Menambahkan garansi + role garansi langsung ke user.' },
  { usage: '/cekgaransi', desc: 'Cek sisa waktu garansi.' },
  {
    usage: '/testimoni buyer:@buyer seller:@seller garansi:<1-999> bukti:<attachment opsional>',
    desc: 'Membuka sesi testimoni untuk buyer. Garansi baru aktif setelah testimoni diisi lewat tombol + modal.',
  },
  { usage: '/status status:OPEN|CLOSE', desc: 'Mengirim pengumuman buka/tutup toko ke channel status + tag role.' },
  { usage: '/help', desc: 'Menampilkan daftar command ini.' },
];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('help')
    .setDescription('Menampilkan daftar semua command bot.'),

  async execute(interaction) {
    const config = getConfig();

    if (!isOwner(interaction.user.id, config)) {
      return interaction.reply({
        embeds: [errorEmbed('Command ini hanya dapat digunakan oleh owner bot.')],
        ephemeral: true,
      });
    }

    const description = COMMAND_LIST.map((c) => `**\`${c.usage}\`**\n${c.desc}`).join('\n\n');

    const embed = infoEmbed({
      title: '📖 Daftar Command',
      description: `${description}\n\n_Semua command hanya bisa dijalankan oleh owner bot._`,
    });

    await interaction.reply({ embeds: [embed], ephemeral: true });
  },
};
