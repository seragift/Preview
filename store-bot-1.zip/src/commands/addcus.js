'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { getConfig } = require('../utils/configManager');
const { isOwner } = require('../utils/permissions');
const { successEmbed, errorEmbed } = require('../utils/embedBuilder');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('addcus')
    .setDescription('Menambahkan role buyer kepada customer.')
    .addUserOption((option) => option.setName('user').setDescription('User yang akan dijadikan customer').setRequired(true)),

  async execute(interaction) {
    const config = getConfig();

    if (!isOwner(interaction.user.id, config)) {
      return interaction.reply({
        embeds: [errorEmbed('Command ini hanya dapat digunakan oleh owner bot.')],
        ephemeral: true,
      });
    }

    const buyerRoleId = config.roles?.buyerRoleId;
    if (!buyerRoleId) {
      return interaction.reply({ embeds: [errorEmbed('Role buyer belum dikonfigurasi.')], ephemeral: true });
    }

    const targetUser = interaction.options.getUser('user', true);

    await interaction.deferReply();

    let member;
    try {
      member = await interaction.guild.members.fetch(targetUser.id);
      await member.roles.add(buyerRoleId);
    } catch (err) {
      console.error('[Addcus] Gagal menambahkan role buyer:', err.message);
      return interaction.editReply({ embeds: [errorEmbed('Gagal menambahkan role buyer. Periksa role ID atau permission bot.')] });
    }

    const embed = successEmbed({
      title: '✅ Customer Berhasil Ditambahkan',
      fields: [
        { name: 'Customer', value: `<@${targetUser.id}>`, inline: true },
        { name: 'Role', value: `<@&${buyerRoleId}>`, inline: true },
      ],
    });

    await interaction.editReply({ embeds: [embed] });

    const logChannelId = config.channels?.logChannelId;
    if (logChannelId) {
      try {
        const logChannel = await interaction.guild.channels.fetch(logChannelId);
        if (logChannel?.isTextBased()) {
          await logChannel.send({ embeds: [embed] });
        }
      } catch (err) {
        console.error('[Addcus] Gagal mengirim log:', err.message);
      }
    }
  },
};
