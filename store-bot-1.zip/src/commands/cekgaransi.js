'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { getConfig } = require('../utils/configManager');
const { isOwner } = require('../utils/permissions');
const { getWarranty } = require('../utils/warrantyManager');
const { infoEmbed, errorEmbed } = require('../utils/embedBuilder');
const { formatWIB } = require('../utils/dateFormatter');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('cekgaransi')
    .setDescription('Cek status garansi kamu saat ini.'),

  async execute(interaction) {
    const config = getConfig();

    if (!isOwner(interaction.user.id, config)) {
      return interaction.reply({
        embeds: [errorEmbed('Command ini hanya dapat digunakan oleh owner bot.')],
        ephemeral: true,
      });
    }

    const warranty = getWarranty(interaction.user.id);

    if (!warranty) {
      return interaction.reply({
        embeds: [errorEmbed('Kamu tidak memiliki garansi aktif saat ini.')],
        ephemeral: true,
      });
    }

    const remainingMs = warranty.expiresAt - Date.now();
    const remainingDays = Math.max(0, Math.ceil(remainingMs / (24 * 60 * 60 * 1000)));
    const sisaWaktu = remainingMs > 0 ? `${remainingDays} Hari lagi` : 'Sudah melewati batas waktu (akan segera dicabut)';

    const embed = infoEmbed({
      title: '🛡️ Status Garansi Kamu',
      fields: [
        { name: 'Role Garansi', value: `<@&${warranty.roleId}>`, inline: true },
        { name: 'Sisa Waktu', value: sisaWaktu, inline: true },
        { name: 'Berakhir', value: formatWIB(warranty.expiresAt) },
      ],
    });

    await interaction.reply({ embeds: [embed], ephemeral: true });
  },
};
