'use strict';

const { Events } = require('discord.js');
const { init: initWarranty } = require('../utils/warrantyManager');
const { init: initTicket } = require('../utils/ticketManager');

module.exports = {
  name: Events.ClientReady,
  once: true,
  async execute(client) {
    console.log(`[Ready] Login sebagai ${client.user.tag}`);
    initWarranty(client);
    initTicket(client);
  },
};
