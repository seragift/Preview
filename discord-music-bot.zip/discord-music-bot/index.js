require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { Client, GatewayIntentBits, Partials, Collection } = require('discord.js');
const { initMusicManager } = require('./music/MusicManager');

// ==================== INISIALISASI CLIENT ====================
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.GuildMembers,
  ],
  partials: [Partials.Channel, Partials.Message],
});

client.commands = new Collection();

// ==================== AUTO-LOADER COMMANDS ====================
const commandsPath = path.join(__dirname, 'commands');
const commandFiles = fs.readdirSync(commandsPath).filter((file) => file.endsWith('.js'));

for (const file of commandFiles) {
  const filePath = path.join(commandsPath, file);
  const command = require(filePath);

  if (!command.name || !command.execute) {
    console.warn(`[COMMAND LOADER] File "${file}" tidak valid, dilewati.`);
    continue;
  }

  client.commands.set(command.name, command);
  console.log(`[COMMAND LOADER] Command "${command.name}" berhasil dimuat.`);
}

// ==================== AUTO-LOADER EVENTS ====================
const eventsPath = path.join(__dirname, 'events');
const eventFiles = fs.readdirSync(eventsPath).filter((file) => file.endsWith('.js'));

for (const file of eventFiles) {
  const filePath = path.join(eventsPath, file);
  const event = require(filePath);

  if (!event.name || !event.execute) {
    console.warn(`[EVENT LOADER] File "${file}" tidak valid, dilewati.`);
    continue;
  }

  if (event.once) {
    client.once(event.name, (...args) => event.execute(...args, client));
  } else {
    client.on(event.name, (...args) => event.execute(...args, client));
  }

  console.log(`[EVENT LOADER] Event "${event.name}" berhasil dimuat.`);
}

// ==================== INISIALISASI MUSIC MANAGER (DISTUBE) ====================
initMusicManager(client);

// ==================== ERROR HANDLING GLOBAL ====================
process.on('unhandledRejection', (error) => {
  console.error('[UNHANDLED REJECTION]', error);
});

process.on('uncaughtException', (error) => {
  console.error('[UNCAUGHT EXCEPTION]', error);
});

client.on('error', (error) => {
  console.error('[CLIENT ERROR]', error);
});

client.on('warn', (info) => {
  console.warn('[CLIENT WARNING]', info);
});

// ==================== LOGIN ====================
if (!process.env.TOKEN) {
  console.error('[BOT STARTUP] TOKEN tidak ditemukan! Pastikan file .env sudah dikonfigurasi dengan benar.');
  process.exit(1);
}

client.login(process.env.TOKEN).catch((err) => {
  console.error('[BOT STARTUP] Gagal login ke Discord:', err.message);
  process.exit(1);
});
