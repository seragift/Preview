const { handleButtonInteraction } = require('../music/PlayerControls');
const { buildQueueEmbed } = require('../commands/queue');
const { errorEmbed } = require('../utils/embeds');

module.exports = {
  name: 'interactionCreate',
  once: false,
  async execute(interaction, client) {
    if (!interaction.isButton()) return;

    try {
      if (interaction.customId.startsWith('music_')) {
        await handleButtonInteraction(interaction, client);
        return;
      }

      if (interaction.customId.startsWith('queue_')) {
        const distube = client.distube;
        const queue = distube.getQueue(interaction.guild.id);

        if (!queue) {
          return interaction.reply({
            embeds: [errorEmbed('Queue sudah tidak tersedia.')],
            ephemeral: true,
          });
        }

        const currentPage = parseInt(interaction.message.embeds[0]?.footer?.text?.match(/Halaman (\d+)/)?.[1] || '1', 10);
        const totalPages = Math.max(Math.ceil(queue.songs.length / 10), 1);

        let newPage = currentPage;
        if (interaction.customId === 'queue_next') newPage = Math.min(currentPage + 1, totalPages);
        if (interaction.customId === 'queue_prev') newPage = Math.max(currentPage - 1, 1);

        const { embed, row } = buildQueueEmbed(queue, newPage, totalPages);
        await interaction.update({ embeds: [embed], components: [row] });
        return;
      }
    } catch (err) {
      console.error('[INTERACTION ERROR]', err);
      if (!interaction.replied && !interaction.deferred) {
        await interaction.reply({ embeds: [errorEmbed(`Terjadi kesalahan: ${err.message}`)], ephemeral: true }).catch(() => {});
      }
    }
  },
};
