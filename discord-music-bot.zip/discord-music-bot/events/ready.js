const { ActivityType } = require('discord.js');
const config = require('../config.json');

module.exports = {
  name: 'ready',
  once: true,
  execute(client) {
    console.log('==============================================');
    console.log(`[BOT STARTUP] Berhasil login sebagai ${client.user.tag}`);
    console.log(`[BOT STARTUP] Melayani ${client.guilds.cache.size} server`);
    console.log(`[BOT STARTUP] Prefix: ${config.prefix}`);
    console.log('==============================================');

    const updatePresence = () => {
      client.user.setPresence({
        activities: [
          {
            name: `${config.prefix}play | ${client.guilds.cache.size} server`,
            type: ActivityType.Listening,
          },
        ],
        status: 'online',
      });
    };

    updatePresence();
    setInterval(updatePresence, 60000);
  },
};
