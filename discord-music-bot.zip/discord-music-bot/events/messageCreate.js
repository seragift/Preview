const config = require('../config.json');
const { errorEmbed } = require('../utils/embeds');

module.exports = {
  name: 'messageCreate',
  once: false,
  async execute(message, client) {
    if (message.author.bot) return;
    if (!message.guild) return;
    if (!message.content.startsWith(config.prefix)) return;

    const args = message.content.slice(config.prefix.length).trim().split(/ +/);
    const commandName = args.shift().toLowerCase();

    const command =
      client.commands.get(commandName) ||
      client.commands.find((cmd) => cmd.aliases && cmd.aliases.includes(commandName));

    if (!command) return;

    try {
      console.log(`[COMMAND USAGE] ${message.author.tag} menjalankan "${commandName}" di guild "${message.guild.name}"`);
      await command.execute(message, args, client);
    } catch (err) {
      console.error(`[COMMAND ERROR] Gagal menjalankan command "${commandName}":`, err);
      message.channel.send({
        embeds: [errorEmbed(`Terjadi kesalahan saat menjalankan command:\n\`${err.message}\``)],
      }).catch(() => {});
    }
  },
};
