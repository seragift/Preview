const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs-extra');

const dbDir = path.join(__dirname);
fs.ensureDirSync(dbDir);

const db = new Database(path.join(dbDir, 'database.db'));
db.pragma('journal_mode = WAL');

// ==================== SKEMA TABEL ====================

db.exec(`
  CREATE TABLE IF NOT EXISTS history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    song_name TEXT NOT NULL,
    song_url TEXT NOT NULL,
    played_at INTEGER NOT NULL
  );
`);

db.exec(`
  CREATE TABLE IF NOT EXISTS favorites (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT NOT NULL,
    song_name TEXT NOT NULL,
    song_url TEXT NOT NULL,
    added_at INTEGER NOT NULL,
    UNIQUE(user_id, song_url)
  );
`);

db.exec(`
  CREATE TABLE IF NOT EXISTS song_stats (
    song_url TEXT PRIMARY KEY,
    song_name TEXT NOT NULL,
    play_count INTEGER NOT NULL DEFAULT 0
  );
`);

db.exec(`
  CREATE TABLE IF NOT EXISTS user_stats (
    user_id TEXT PRIMARY KEY,
    username TEXT NOT NULL,
    play_count INTEGER NOT NULL DEFAULT 0
  );
`);

db.exec(`
  CREATE TABLE IF NOT EXISTS guild_stats (
    guild_id TEXT PRIMARY KEY,
    total_plays INTEGER NOT NULL DEFAULT 0
  );
`);

// ==================== PREPARED STATEMENTS ====================

const stmts = {
  insertHistory: db.prepare(
    `INSERT INTO history (guild_id, user_id, song_name, song_url, played_at) VALUES (?, ?, ?, ?, ?)`
  ),
  getHistory: db.prepare(
    `SELECT * FROM history WHERE guild_id = ? ORDER BY played_at DESC LIMIT ?`
  ),
  addFavorite: db.prepare(
    `INSERT OR IGNORE INTO favorites (user_id, song_name, song_url, added_at) VALUES (?, ?, ?, ?)`
  ),
  removeFavorite: db.prepare(`DELETE FROM favorites WHERE user_id = ? AND song_url = ?`),
  getFavorites: db.prepare(`SELECT * FROM favorites WHERE user_id = ? ORDER BY added_at DESC`),
  upsertSongStat: db.prepare(`
    INSERT INTO song_stats (song_url, song_name, play_count)
    VALUES (?, ?, 1)
    ON CONFLICT(song_url) DO UPDATE SET play_count = play_count + 1, song_name = excluded.song_name
  `),
  topSongs: db.prepare(`SELECT * FROM song_stats ORDER BY play_count DESC LIMIT ?`),
  upsertUserStat: db.prepare(`
    INSERT INTO user_stats (user_id, username, play_count)
    VALUES (?, ?, 1)
    ON CONFLICT(user_id) DO UPDATE SET play_count = play_count + 1, username = excluded.username
  `),
  topUsers: db.prepare(`SELECT * FROM user_stats ORDER BY play_count DESC LIMIT ?`),
  upsertGuildStat: db.prepare(`
    INSERT INTO guild_stats (guild_id, total_plays)
    VALUES (?, 1)
    ON CONFLICT(guild_id) DO UPDATE SET total_plays = total_plays + 1
  `),
  totalPlays: db.prepare(`SELECT SUM(total_plays) as total FROM guild_stats`),
};

// ==================== FUNGSI EXPORT ====================

function addHistory(guildId, userId, songName, songUrl) {
  try {
    stmts.insertHistory.run(guildId, userId, songName, songUrl, Date.now());
  } catch (err) {
    console.error('[DATABASE] Gagal menyimpan history:', err.message);
  }
}

function getHistory(guildId, limit = 10) {
  try {
    return stmts.getHistory.all(guildId, limit);
  } catch (err) {
    console.error('[DATABASE] Gagal mengambil history:', err.message);
    return [];
  }
}

function addFavorite(userId, songName, songUrl) {
  try {
    stmts.addFavorite.run(userId, songName, songUrl, Date.now());
    return true;
  } catch (err) {
    console.error('[DATABASE] Gagal menambah favorite:', err.message);
    return false;
  }
}

function removeFavorite(userId, songUrl) {
  try {
    stmts.removeFavorite.run(userId, songUrl);
    return true;
  } catch (err) {
    console.error('[DATABASE] Gagal menghapus favorite:', err.message);
    return false;
  }
}

function getFavorites(userId) {
  try {
    return stmts.getFavorites.all(userId);
  } catch (err) {
    console.error('[DATABASE] Gagal mengambil favorite:', err.message);
    return [];
  }
}

function recordPlay(guildId, userId, username, songName, songUrl) {
  try {
    addHistory(guildId, userId, songName, songUrl);
    stmts.upsertSongStat.run(songUrl, songName);
    stmts.upsertUserStat.run(userId, username);
    stmts.upsertGuildStat.run(guildId);
  } catch (err) {
    console.error('[DATABASE] Gagal mencatat statistik:', err.message);
  }
}

function getTopSongs(limit = 10) {
  try {
    return stmts.topSongs.all(limit);
  } catch (err) {
    console.error('[DATABASE] Gagal mengambil top songs:', err.message);
    return [];
  }
}

function getTopUsers(limit = 10) {
  try {
    return stmts.topUsers.all(limit);
  } catch (err) {
    console.error('[DATABASE] Gagal mengambil top users:', err.message);
    return [];
  }
}

function getTotalPlays() {
  try {
    const row = stmts.totalPlays.get();
    return row?.total || 0;
  } catch (err) {
    console.error('[DATABASE] Gagal mengambil total plays:', err.message);
    return 0;
  }
}

module.exports = {
  db,
  addHistory,
  getHistory,
  addFavorite,
  removeFavorite,
  getFavorites,
  recordPlay,
  getTopSongs,
  getTopUsers,
  getTotalPlays,
};
