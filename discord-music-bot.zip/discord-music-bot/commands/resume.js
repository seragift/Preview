const { errorEmbed, successEmbed } = require('../utils/embeds');

module.exports = {
  name: 'resume',
  aliases: ['unpause'],
  description: 'Melanjutkan musik yang sedang dijeda.',
  async execute(message, args, client) {
    const queue = client.distube.getQueue(message.guild.id);

    if (!queue) {
      return message.channel.send({ embeds: [errorEmbed('Tidak ada musik yang sedang diputar.')] });
    }

    if (!queue.paused) {
      return message.channel.send({ embeds: [errorEmbed('Musik sedang tidak dalam keadaan dijeda.')] });
    }

    try {
      queue.resume();
      message.channel.send({ embeds: [successEmbed('▶️ Musik dilanjutkan.')] });
    } catch (err) {
      message.channel.send({ embeds: [errorEmbed(`Gagal melanjutkan musik: ${err.message}`)] });
    }
  },
};
