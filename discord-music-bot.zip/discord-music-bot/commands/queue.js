const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { baseEmbed, errorEmbed } = require('../utils/embeds');
const { formatDuration, formatQueueDuration, truncate } = require('../utils/helpers');
const config = require('../config.json');

const PAGE_SIZE = config.maxQueueDisplay || 10;

/**
 * Membangun embed dan tombol pagination untuk queue
 * @param {import('distube').Queue} queue
 * @param {number} page
 * @param {number} totalPages
 */
function buildQueueEmbed(queue, page = 1, totalPages = 1) {
  const start = (page - 1) * PAGE_SIZE;
  const end = start + PAGE_SIZE;
  const songsOnPage = queue.songs.slice(start, end);

  const description = songsOnPage
    .map((song, index) => {
      const realIndex = start + index;
      const prefix = realIndex === 0 ? '🎶 **Sedang Diputar**' : `**${realIndex}.**`;
      return `${prefix} [${truncate(song.name, 50)}](${song.url}) \`[${song.formattedDuration || formatDuration(song.duration)}]\` - ${song.user || 'Unknown'}`;
    })
    .join('\n\n');

  const embed = baseEmbed({
    title: '🎵 Daftar Antrian Musik',
    description: description || 'Queue kosong.',
    fields: [
      { name: 'Total Lagu', value: `${queue.songs.length}`, inline: true },
      { name: 'Total Durasi', value: formatQueueDuration(queue.songs), inline: true },
      { name: 'Loop', value: queue.repeatMode === 0 ? 'Off' : queue.repeatMode === 1 ? 'Lagu' : 'Queue', inline: true },
    ],
    footer: { text: `Halaman ${page}/${totalPages}` },
  });

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('queue_prev').setLabel('◀️ Sebelumnya').setStyle(ButtonStyle.Secondary).setDisabled(page <= 1),
    new ButtonBuilder().setCustomId('queue_next').setLabel('Selanjutnya ▶️').setStyle(ButtonStyle.Secondary).setDisabled(page >= totalPages)
  );

  return { embed, row };
}

module.exports = {
  name: 'queue',
  aliases: ['q'],
  description: 'Menampilkan daftar antrian lagu.',
  buildQueueEmbed,
  async execute(message, args, client) {
    const queue = client.distube.getQueue(message.guild.id);

    if (!queue || !queue.songs.length) {
      return message.channel.send({ embeds: [errorEmbed('Queue saat ini kosong.')] });
    }

    const totalPages = Math.max(Math.ceil(queue.songs.length / PAGE_SIZE), 1);
    const { embed, row } = buildQueueEmbed(queue, 1, totalPages);

    message.channel.send({ embeds: [embed], components: [row] });
  },
};
