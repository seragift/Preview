const { errorEmbed, successEmbed } = require('../utils/embeds');

module.exports = {
  name: 'remove',
  aliases: ['rm', 'delete'],
  description: 'Menghapus lagu dari queue berdasarkan posisi.',
  async execute(message, args, client) {
    const queue = client.distube.getQueue(message.guild.id);

    if (!queue) {
      return message.channel.send({ embeds: [errorEmbed('Tidak ada musik yang sedang diputar.')] });
    }

    const index = parseInt(args[0], 10);

    if (isNaN(index) || index <= 0 || index >= queue.songs.length) {
      return message.channel.send({
        embeds: [errorEmbed(`Posisi tidak valid. Gunakan angka antara 1-${queue.songs.length - 1}.`)],
      });
    }

    try {
      const removedSong = queue.songs[index];
      queue.songs.splice(index, 1);
      message.channel.send({ embeds: [successEmbed(`🗑️ Berhasil menghapus **${removedSong.name}** dari queue.`)] });
    } catch (err) {
      message.channel.send({ embeds: [errorEmbed(`Gagal menghapus lagu: ${err.message}`)] });
    }
  },
};
