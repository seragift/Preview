const { errorEmbed, successEmbed } = require('../utils/embeds');

module.exports = {
  name: 'stop',
  aliases: ['dc', 'disconnect'],
  description: 'Menghentikan musik dan membersihkan queue.',
  async execute(message, args, client) {
    const queue = client.distube.getQueue(message.guild.id);

    if (!queue) {
      return message.channel.send({ embeds: [errorEmbed('Tidak ada musik yang sedang diputar.')] });
    }

    try {
      queue.stop();
      message.channel.send({ embeds: [successEmbed('⏹️ Musik dihentikan dan bot keluar dari voice channel.')] });
    } catch (err) {
      message.channel.send({ embeds: [errorEmbed(`Gagal menghentikan musik: ${err.message}`)] });
    }
  },
};
