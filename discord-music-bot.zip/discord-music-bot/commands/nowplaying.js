const { AttachmentBuilder } = require('discord.js');
const { baseEmbed, errorEmbed } = require('../utils/embeds');
const { formatDuration } = require('../utils/helpers');
const { createMusicCard } = require('../music/CanvasCard');
const { getControlRow } = require('../music/PlayerControls');

module.exports = {
  name: 'nowplaying',
  aliases: ['np', 'current'],
  description: 'Menampilkan informasi lagu yang sedang diputar beserta music card.',
  async execute(message, args, client) {
    const queue = client.distube.getQueue(message.guild.id);

    if (!queue || !queue.songs.length) {
      return message.channel.send({ embeds: [errorEmbed('Tidak ada musik yang sedang diputar.')] });
    }

    const song = queue.songs[0];

    try {
      const cardBuffer = await createMusicCard({
        thumbnail: song.thumbnail,
        title: song.name,
        author: song.uploader?.name || 'Unknown',
        currentTime: queue.currentTime,
        duration: song.duration,
        isLive: song.isLive,
        requesterAvatar: song.user?.displayAvatarURL?.({ extension: 'png', size: 128 }),
        requesterName: song.user?.username,
      });

      const attachment = new AttachmentBuilder(cardBuffer, { name: 'nowplaying.png' });

      const repeatLabel = queue.repeatMode === 0 ? 'Off' : queue.repeatMode === 1 ? 'Lagu' : 'Queue';

      const embed = baseEmbed({
        title: '🎶 Now Playing',
        description: `**[${song.name}](${song.url})**`,
        fields: [
          { name: 'Channel', value: song.uploader?.name || 'Unknown', inline: true },
          { name: 'Durasi', value: `${formatDuration(queue.currentTime)} / ${song.formattedDuration || formatDuration(song.duration)}`, inline: true },
          { name: 'Requester', value: `${song.user || 'Unknown'}`, inline: true },
          { name: 'Loop', value: repeatLabel, inline: true },
          { name: 'Autoplay', value: queue.autoplay ? 'Aktif' : 'Nonaktif', inline: true },
          { name: 'Volume', value: `${queue.volume}%`, inline: true },
        ],
        image: 'attachment://nowplaying.png',
      });

      message.channel.send({
        embeds: [embed],
        files: [attachment],
        components: getControlRow(queue),
      });
    } catch (err) {
      console.error('[NOWPLAYING ERROR]', err);
      message.channel.send({ embeds: [errorEmbed(`Gagal menampilkan now playing: ${err.message}`)] });
    }
  },
};
