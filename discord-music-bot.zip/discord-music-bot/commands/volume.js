const { errorEmbed, successEmbed, infoEmbed } = require('../utils/embeds');
const config = require('../config.json');

module.exports = {
  name: 'volume',
  aliases: ['vol'],
  description: 'Mengatur volume musik (0-150).',
  async execute(message, args, client) {
    const queue = client.distube.getQueue(message.guild.id);

    if (!queue) {
      return message.channel.send({ embeds: [errorEmbed('Tidak ada musik yang sedang diputar.')] });
    }

    if (!args.length) {
      return message.channel.send({ embeds: [infoEmbed(`Volume saat ini: **${queue.volume}%**`)] });
    }

    const volume = parseInt(args[0], 10);

    if (isNaN(volume) || volume < 0 || volume > (config.maxVolume || 150)) {
      return message.channel.send({
        embeds: [errorEmbed(`Volume harus berupa angka antara 0-${config.maxVolume || 150}.`)],
      });
    }

    try {
      queue.setVolume(volume);
      message.channel.send({ embeds: [successEmbed(`🔊 Volume diatur ke **${volume}%**.`)] });
    } catch (err) {
      message.channel.send({ embeds: [errorEmbed(`Gagal mengatur volume: ${err.message}`)] });
    }
  },
};
