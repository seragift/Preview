const { errorEmbed, infoEmbed } = require('../utils/embeds');
const { validateVoice } = require('../utils/helpers');

module.exports = {
  name: 'play',
  aliases: ['p'],
  description: 'Memutar lagu dari URL YouTube, kata kunci pencarian, atau playlist YouTube.',
  async execute(message, args, client) {
    if (!args.length) {
      return message.channel.send({
        embeds: [errorEmbed(`Gunakan format: \`${require('../config.json').prefix}play <url/nama lagu>\``)],
      });
    }

    const validation = validateVoice(message);
    if (!validation.valid) {
      return message.channel.send({ embeds: [errorEmbed(validation.reason)] });
    }

    const query = args.join(' ');
    const loadingMsg = await message.channel.send({ embeds: [infoEmbed(`🔎 Mencari **${query}**...`)] });

    try {
      await client.distube.play(validation.voiceChannel, query, {
        member: message.member,
        textChannel: message.channel,
        message,
      });

      await loadingMsg.delete().catch(() => {});
    } catch (err) {
      console.error('[PLAY COMMAND ERROR]', err);
      await loadingMsg.edit({
        embeds: [errorEmbed(`Gagal memutar lagu: \`${err.message || 'Terjadi kesalahan tidak diketahui'}\``)],
      }).catch(() => {});
    }
  },
};
