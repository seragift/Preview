const { errorEmbed, successEmbed } = require('../utils/embeds');

module.exports = {
  name: 'skip',
  aliases: ['s', 'next'],
  description: 'Melewati lagu yang sedang diputar.',
  async execute(message, args, client) {
    const queue = client.distube.getQueue(message.guild.id);

    if (!queue) {
      return message.channel.send({ embeds: [errorEmbed('Tidak ada musik yang sedang diputar.')] });
    }

    if (queue.songs.length <= 1 && queue.repeatMode === 0) {
      return message.channel.send({ embeds: [errorEmbed('Tidak ada lagu selanjutnya dalam queue.')] });
    }

    const currentSong = queue.songs[0];

    try {
      await queue.skip();
      message.channel.send({ embeds: [successEmbed(`⏭️ Berhasil melewati **${currentSong.name}**.`)] });
    } catch (err) {
      message.channel.send({ embeds: [errorEmbed(`Gagal melewati lagu: ${err.message}`)] });
    }
  },
};
