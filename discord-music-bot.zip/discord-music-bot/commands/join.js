const { joinVoiceChannel } = require('@discordjs/voice');
const { errorEmbed, successEmbed } = require('../utils/embeds');
const { validateVoice } = require('../utils/helpers');

module.exports = {
  name: 'join',
  aliases: ['connect', 'summon'],
  description: 'Membuat bot bergabung ke voice channel kamu.',
  async execute(message, args, client) {
    const validation = validateVoice(message);

    if (!validation.valid) {
      return message.channel.send({ embeds: [errorEmbed(validation.reason)] });
    }

    const existingQueue = client.distube.getQueue(message.guild.id);
    if (existingQueue) {
      return message.channel.send({ embeds: [errorEmbed('Bot sudah berada di voice channel dan sedang memutar musik.')] });
    }

    try {
      joinVoiceChannel({
        channelId: validation.voiceChannel.id,
        guildId: message.guild.id,
        adapterCreator: message.guild.voiceAdapterCreator,
        selfDeaf: true,
      });

      console.log(`[VOICE] Bot bergabung ke voice channel "${validation.voiceChannel.name}" di guild "${message.guild.name}"`);
      message.channel.send({ embeds: [successEmbed(`🔊 Berhasil bergabung ke **${validation.voiceChannel.name}**.`)] });
    } catch (err) {
      console.error('[JOIN COMMAND ERROR]', err);
      message.channel.send({ embeds: [errorEmbed(`Gagal bergabung ke voice channel: ${err.message}`)] });
    }
  },
};
