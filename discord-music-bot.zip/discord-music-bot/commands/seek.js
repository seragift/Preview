const { errorEmbed, successEmbed } = require('../utils/embeds');

/**
 * Mengubah format "mm:ss" atau angka detik menjadi detik
 */
function parseTimeInput(input) {
  if (!input) return NaN;
  if (/^\d+$/.test(input)) return parseInt(input, 10);

  const parts = input.split(':').map(Number);
  if (parts.some(isNaN)) return NaN;

  if (parts.length === 2) {
    const [m, s] = parts;
    return m * 60 + s;
  }
  if (parts.length === 3) {
    const [h, m, s] = parts;
    return h * 3600 + m * 60 + s;
  }
  return NaN;
}

module.exports = {
  name: 'seek',
  aliases: [],
  description: 'Melompat ke posisi tertentu dalam lagu (format: detik atau mm:ss).',
  async execute(message, args, client) {
    const queue = client.distube.getQueue(message.guild.id);

    if (!queue) {
      return message.channel.send({ embeds: [errorEmbed('Tidak ada musik yang sedang diputar.')] });
    }

    if (!args.length) {
      return message.channel.send({ embeds: [errorEmbed('Gunakan format: `!seek <detik>` atau `!seek mm:ss`')] });
    }

    const seconds = parseTimeInput(args[0]);
    const song = queue.songs[0];

    if (isNaN(seconds) || seconds < 0) {
      return message.channel.send({ embeds: [errorEmbed('Format waktu tidak valid.')] });
    }

    if (song.duration && seconds > song.duration) {
      return message.channel.send({ embeds: [errorEmbed('Waktu melebihi durasi lagu.')] });
    }

    try {
      queue.seek(seconds);
      message.channel.send({ embeds: [successEmbed(`⏩ Berhasil melompat ke posisi **${args[0]}**.`)] });
    } catch (err) {
      message.channel.send({ embeds: [errorEmbed(`Gagal melakukan seek: ${err.message}`)] });
    }
  },
};
