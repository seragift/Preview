const { errorEmbed, successEmbed } = require('../utils/embeds');

module.exports = {
  name: 'loop',
  aliases: ['repeat'],
  description: 'Mengatur mode loop: off, song, atau queue.',
  async execute(message, args, client) {
    const queue = client.distube.getQueue(message.guild.id);

    if (!queue) {
      return message.channel.send({ embeds: [errorEmbed('Tidak ada musik yang sedang diputar.')] });
    }

    const modeArg = args[0]?.toLowerCase();
    const modeMap = { off: 0, disable: 0, song: 1, track: 1, queue: 2, all: 2 };

    let newMode;

    if (modeArg && modeArg in modeMap) {
      newMode = modeMap[modeArg];
    } else {
      // Cycle otomatis jika tidak ada argumen: off -> song -> queue -> off
      newMode = (queue.repeatMode + 1) % 3;
    }

    try {
      queue.setRepeatMode(newMode);
      const labels = { 0: '🔁 Loop dimatikan.', 1: '🔂 Loop lagu diaktifkan.', 2: '🔁 Loop queue diaktifkan.' };
      message.channel.send({ embeds: [successEmbed(labels[newMode])] });
    } catch (err) {
      message.channel.send({ embeds: [errorEmbed(`Gagal mengatur loop: ${err.message}`)] });
    }
  },
};
