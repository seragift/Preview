const { errorEmbed, successEmbed } = require('../utils/embeds');

module.exports = {
  name: 'pause',
  aliases: [],
  description: 'Menjeda musik yang sedang diputar.',
  async execute(message, args, client) {
    const queue = client.distube.getQueue(message.guild.id);

    if (!queue) {
      return message.channel.send({ embeds: [errorEmbed('Tidak ada musik yang sedang diputar.')] });
    }

    if (queue.paused) {
      return message.channel.send({ embeds: [errorEmbed('Musik sudah dalam keadaan dijeda.')] });
    }

    try {
      queue.pause();
      message.channel.send({ embeds: [successEmbed('⏸️ Musik dijeda.')] });
    } catch (err) {
      message.channel.send({ embeds: [errorEmbed(`Gagal menjeda musik: ${err.message}`)] });
    }
  },
};
