const { errorEmbed, successEmbed } = require('../utils/embeds');

module.exports = {
  name: 'shuffle',
  aliases: ['mix'],
  description: 'Mengacak urutan lagu dalam queue.',
  async execute(message, args, client) {
    const queue = client.distube.getQueue(message.guild.id);

    if (!queue) {
      return message.channel.send({ embeds: [errorEmbed('Tidak ada musik yang sedang diputar.')] });
    }

    if (queue.songs.length <= 2) {
      return message.channel.send({ embeds: [errorEmbed('Tidak cukup lagu dalam queue untuk diacak.')] });
    }

    try {
      queue.shuffle();
      message.channel.send({ embeds: [successEmbed('🔀 Queue berhasil diacak.')] });
    } catch (err) {
      message.channel.send({ embeds: [errorEmbed(`Gagal mengacak queue: ${err.message}`)] });
    }
  },
};
