const { errorEmbed, successEmbed } = require('../utils/embeds');

module.exports = {
  name: 'autoplay',
  aliases: ['ap'],
  description: 'Mengaktifkan atau menonaktifkan mode autoplay.',
  async execute(message, args, client) {
    const queue = client.distube.getQueue(message.guild.id);

    if (!queue) {
      return message.channel.send({ embeds: [errorEmbed('Tidak ada musik yang sedang diputar.')] });
    }

    try {
      const newState = queue.toggleAutoplay();
      message.channel.send({
        embeds: [successEmbed(`🔀 Autoplay sekarang **${newState ? 'Aktif' : 'Nonaktif'}**.`)],
      });
    } catch (err) {
      message.channel.send({ embeds: [errorEmbed(`Gagal mengubah autoplay: ${err.message}`)] });
    }
  },
};
