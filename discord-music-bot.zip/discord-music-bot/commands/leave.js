const { getVoiceConnection } = require('@discordjs/voice');
const { errorEmbed, successEmbed } = require('../utils/embeds');

module.exports = {
  name: 'leave',
  aliases: ['dc', 'disconnectvc'],
  description: 'Membuat bot keluar dari voice channel.',
  async execute(message, args, client) {
    const queue = client.distube.getQueue(message.guild.id);

    if (queue) {
      queue.stop();
      console.log(`[VOICE] Bot meninggalkan voice channel di guild "${message.guild.name}" (via stop queue)`);
      return message.channel.send({ embeds: [successEmbed('👋 Bot keluar dari voice channel.')] });
    }

    const connection = getVoiceConnection(message.guild.id);
    if (connection) {
      connection.destroy();
      console.log(`[VOICE] Bot meninggalkan voice channel di guild "${message.guild.name}"`);
      return message.channel.send({ embeds: [successEmbed('👋 Bot keluar dari voice channel.')] });
    }

    return message.channel.send({ embeds: [errorEmbed('Bot sedang tidak berada di voice channel manapun.')] });
  },
};
