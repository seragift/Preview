const lyricsFinder = require('lyrics-finder');
const { baseEmbed, errorEmbed, infoEmbed } = require('../utils/embeds');
const { truncate } = require('../utils/helpers');

module.exports = {
  name: 'lyrics',
  aliases: ['lirik'],
  description: 'Menampilkan lirik lagu yang sedang diputar atau berdasarkan kata kunci.',
  async execute(message, args, client) {
    const queue = client.distube.getQueue(message.guild.id);
    let query = args.join(' ');

    if (!query) {
      if (!queue || !queue.songs.length) {
        return message.channel.send({
          embeds: [errorEmbed('Tidak ada musik yang sedang diputar. Sertakan nama lagu: `!lyrics <nama lagu>`')],
        });
      }
      query = queue.songs[0].name;
    }

    const loadingMsg = await message.channel.send({ embeds: [infoEmbed(`🔎 Mencari lirik untuk **${query}**...`)] });

    try {
      const lyrics = await lyricsFinder(query, '');

      if (!lyrics) {
        return loadingMsg.edit({
          embeds: [errorEmbed(`Lirik untuk **${query}** tidak ditemukan.`)],
        });
      }

      const chunks = splitLyrics(lyrics, 4000);

      const embed = baseEmbed({
        title: `📜 Lirik: ${truncate(query, 200)}`,
        description: chunks[0],
      });

      await loadingMsg.delete().catch(() => {});
      await message.channel.send({ embeds: [embed] });

      for (let i = 1; i < chunks.length; i++) {
        await message.channel.send({ embeds: [baseEmbed({ description: chunks[i] })] });
      }
    } catch (err) {
      console.error('[LYRICS ERROR]', err);
      loadingMsg.edit({ embeds: [errorEmbed(`Gagal mengambil lirik: ${err.message}`)] }).catch(() => {});
    }
  },
};

function splitLyrics(text, maxLength) {
  const chunks = [];
  let remaining = text;

  while (remaining.length > maxLength) {
    let splitIndex = remaining.lastIndexOf('\n', maxLength);
    if (splitIndex === -1) splitIndex = maxLength;
    chunks.push(remaining.substring(0, splitIndex));
    remaining = remaining.substring(splitIndex);
  }
  chunks.push(remaining);

  return chunks;
}
