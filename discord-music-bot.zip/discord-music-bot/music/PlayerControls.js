const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { errorEmbed, successEmbed } = require('../utils/embeds');

/**
 * Membuat baris tombol kontrol musik berdasarkan status queue
 * @param {import('distube').Queue} queue
 */
function getControlRow(queue) {
  const isPaused = queue?.paused || false;
  const repeatMode = queue?.repeatMode || 0;
  const autoplay = queue?.autoplay || false;

  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('music_pauseresume')
      .setEmoji(isPaused ? '▶️' : '⏸️')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('music_skip')
      .setEmoji('⏭️')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('music_stop')
      .setEmoji('⏹️')
      .setStyle(ButtonStyle.Danger),
    new ButtonBuilder()
      .setCustomId('music_loop')
      .setEmoji('🔁')
      .setStyle(repeatMode !== 0 ? ButtonStyle.Success : ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('music_autoplay')
      .setEmoji('🔀')
      .setStyle(autoplay ? ButtonStyle.Success : ButtonStyle.Secondary)
  );

  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('music_volumedown')
      .setEmoji('🔉')
      .setLabel('Vol -')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('music_volumeup')
      .setEmoji('🔊')
      .setLabel('Vol +')
      .setStyle(ButtonStyle.Secondary)
  );

  return [row1, row2];
}

/**
 * Menangani interaksi tombol kontrol musik
 * @param {import('discord.js').ButtonInteraction} interaction
 * @param {import('discord.js').Client} client
 */
async function handleButtonInteraction(interaction, client) {
  const { customId, guild, member } = interaction;
  const distube = client.distube;
  const queue = distube.getQueue(guild.id);

  if (!queue) {
    return interaction.reply({
      embeds: [errorEmbed('Tidak ada musik yang sedang diputar saat ini.')],
      ephemeral: true,
    });
  }

  const voiceChannel = member.voice.channel;
  if (!voiceChannel || voiceChannel.id !== queue.voiceChannel.id) {
    return interaction.reply({
      embeds: [errorEmbed('Kamu harus berada di voice channel yang sama dengan bot!')],
      ephemeral: true,
    });
  }

  try {
    switch (customId) {
      case 'music_pauseresume': {
        if (queue.paused) {
          queue.resume();
          await interaction.reply({ embeds: [successEmbed('▶️ Musik dilanjutkan.')], ephemeral: true });
        } else {
          queue.pause();
          await interaction.reply({ embeds: [successEmbed('⏸️ Musik dijeda.')], ephemeral: true });
        }
        break;
      }

      case 'music_skip': {
        const current = queue.songs[0];
        if (queue.songs.length <= 1 && queue.repeatMode === 0) {
          await interaction.reply({ embeds: [errorEmbed('Tidak ada lagu selanjutnya dalam queue.')], ephemeral: true });
          break;
        }
        await queue.skip();
        await interaction.reply({ embeds: [successEmbed(`⏭️ Melewati **${current?.name || 'lagu ini'}**.`)], ephemeral: true });
        break;
      }

      case 'music_stop': {
        queue.stop();
        await interaction.reply({ embeds: [successEmbed('⏹️ Musik dihentikan dan queue dibersihkan.')], ephemeral: true });
        break;
      }

      case 'music_loop': {
        const modes = [0, 2, 1]; // off -> queue -> song -> off
        const currentIndex = modes.indexOf(queue.repeatMode);
        const nextMode = modes[(currentIndex + 1) % modes.length];
        queue.setRepeatMode(nextMode);
        const labels = { 0: 'Loop Dimatikan', 1: 'Loop Lagu Aktif', 2: 'Loop Queue Aktif' };
        await interaction.reply({ embeds: [successEmbed(`🔁 ${labels[nextMode]}.`)], ephemeral: true });
        break;
      }

      case 'music_autoplay': {
        const newState = queue.toggleAutoplay();
        await interaction.reply({
          embeds: [successEmbed(`🔀 Autoplay sekarang **${newState ? 'Aktif' : 'Nonaktif'}**.`)],
          ephemeral: true,
        });
        break;
      }

      case 'music_volumeup': {
        const newVolume = Math.min((queue.volume || 100) + 10, 150);
        queue.setVolume(newVolume);
        await interaction.reply({ embeds: [successEmbed(`🔊 Volume dinaikkan ke **${newVolume}%**.`)], ephemeral: true });
        break;
      }

      case 'music_volumedown': {
        const newVolume = Math.max((queue.volume || 100) - 10, 0);
        queue.setVolume(newVolume);
        await interaction.reply({ embeds: [successEmbed(`🔉 Volume diturunkan ke **${newVolume}%**.`)], ephemeral: true });
        break;
      }

      default:
        break;
    }
  } catch (err) {
    console.error('[PLAYER CONTROLS ERROR]', err);
    if (!interaction.replied) {
      await interaction.reply({ embeds: [errorEmbed(`Gagal memproses aksi: ${err.message}`)], ephemeral: true });
    }
  }
}

module.exports = { getControlRow, handleButtonInteraction };
