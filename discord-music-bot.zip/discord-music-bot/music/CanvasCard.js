const { createCanvas, loadImage, registerFont } = require('canvas');
const path = require('path');

const WIDTH = 900;
const HEIGHT = 300;

/**
 * Menggambar rounded rectangle
 */
function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

/**
 * Membuat background blur-ish gradient dari thumbnail
 */
function drawBackground(ctx, image) {
  // Gambar cover blur sebagai background dengan overlay gelap
  const scale = Math.max(WIDTH / image.width, HEIGHT / image.height);
  const w = image.width * scale;
  const h = image.height * scale;
  const x = (WIDTH - w) / 2;
  const y = (HEIGHT - h) / 2;

  ctx.filter = 'blur(12px) brightness(0.4)';
  ctx.drawImage(image, x, y, w, h);
  ctx.filter = 'none';

  const gradient = ctx.createLinearGradient(0, 0, WIDTH, 0);
  gradient.addColorStop(0, 'rgba(15,15,20,0.92)');
  gradient.addColorStop(1, 'rgba(15,15,20,0.75)');
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, WIDTH, HEIGHT);
}

/**
 * Membuat Music Card sebagai Buffer PNG
 * @param {object} data
 * @param {string} data.thumbnail - URL thumbnail lagu
 * @param {string} data.title - Judul lagu
 * @param {string} data.author - Nama channel/uploader
 * @param {number} data.currentTime - Waktu saat ini (detik)
 * @param {number} data.duration - Total durasi (detik)
 * @param {string} data.requesterAvatar - URL avatar requester
 * @param {string} data.requesterName - Nama requester
 */
async function createMusicCard(data) {
  const canvas = createCanvas(WIDTH, HEIGHT);
  const ctx = canvas.getContext('2d');

  let thumbImage;
  try {
    thumbImage = await loadImage(data.thumbnail);
  } catch (err) {
    thumbImage = await loadImage('https://i.imgur.com/9dQjJvB.png');
  }

  // Background
  drawBackground(ctx, thumbImage);

  // Card container (rounded)
  ctx.save();
  roundRect(ctx, 0, 0, WIDTH, HEIGHT, 24);
  ctx.clip();

  // Thumbnail kotak di kiri
  const thumbSize = 220;
  const thumbX = 40;
  const thumbY = (HEIGHT - thumbSize) / 2;

  ctx.save();
  roundRect(ctx, thumbX, thumbY, thumbSize, thumbSize, 16);
  ctx.clip();
  ctx.drawImage(thumbImage, thumbX, thumbY, thumbSize, thumbSize);
  ctx.restore();

  // Border emas untuk thumbnail
  ctx.strokeStyle = '#FFD700';
  ctx.lineWidth = 4;
  roundRect(ctx, thumbX, thumbY, thumbSize, thumbSize, 16);
  ctx.stroke();

  // Text area
  const textX = thumbX + thumbSize + 40;
  const textWidth = WIDTH - textX - 40;

  ctx.fillStyle = '#FFD700';
  ctx.font = 'bold 16px sans-serif';
  ctx.fillText('NOW PLAYING', textX, 55);

  ctx.fillStyle = '#FFFFFF';
  ctx.font = 'bold 30px sans-serif';
  const title = truncateText(ctx, data.title || 'Unknown Title', textWidth);
  ctx.fillText(title, textX, 95);

  ctx.fillStyle = '#CCCCCC';
  ctx.font = '20px sans-serif';
  const author = truncateText(ctx, data.author || 'Unknown Channel', textWidth);
  ctx.fillText(author, textX, 130);

  // Progress bar
  const barX = textX;
  const barY = 190;
  const barWidth = textWidth;
  const barHeight = 10;

  ctx.fillStyle = 'rgba(255,255,255,0.2)';
  roundRect(ctx, barX, barY, barWidth, barHeight, 5);
  ctx.fill();

  const duration = data.duration && data.duration > 0 ? data.duration : 1;
  const percentage = Math.min(Math.max((data.currentTime || 0) / duration, 0), 1);
  const progressWidth = Math.max(barWidth * percentage, 10);

  const progressGradient = ctx.createLinearGradient(barX, 0, barX + progressWidth, 0);
  progressGradient.addColorStop(0, '#FFD700');
  progressGradient.addColorStop(1, '#FFA500');
  ctx.fillStyle = progressGradient;
  roundRect(ctx, barX, barY, progressWidth, barHeight, 5);
  ctx.fill();

  // Progress dot
  ctx.beginPath();
  ctx.arc(barX + progressWidth, barY + barHeight / 2, 8, 0, Math.PI * 2);
  ctx.fillStyle = '#FFFFFF';
  ctx.fill();

  // Waktu
  ctx.fillStyle = '#FFFFFF';
  ctx.font = '16px sans-serif';
  const currentTimeText = formatTime(data.currentTime || 0);
  const durationText = data.isLive ? 'LIVE' : formatTime(data.duration || 0);
  ctx.fillText(currentTimeText, barX, barY + 32);
  const durationTextWidth = ctx.measureText(durationText).width;
  ctx.fillText(durationText, barX + barWidth - durationTextWidth, barY + 32);

  // Requester avatar (kanan bawah kecil)
  if (data.requesterAvatar) {
    try {
      const avatarImg = await loadImage(data.requesterAvatar);
      const avatarSize = 40;
      const avatarX = textX;
      const avatarY = barY + 45;

      ctx.save();
      ctx.beginPath();
      ctx.arc(avatarX + avatarSize / 2, avatarY + avatarSize / 2, avatarSize / 2, 0, Math.PI * 2);
      ctx.clip();
      ctx.drawImage(avatarImg, avatarX, avatarY, avatarSize, avatarSize);
      ctx.restore();

      ctx.strokeStyle = '#FFD700';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(avatarX + avatarSize / 2, avatarY + avatarSize / 2, avatarSize / 2, 0, Math.PI * 2);
      ctx.stroke();

      ctx.fillStyle = '#AAAAAA';
      ctx.font = '14px sans-serif';
      ctx.fillText(`Diminta oleh ${data.requesterName || 'Unknown'}`, avatarX + avatarSize + 12, avatarY + 25);
    } catch (err) {
      // Abaikan jika avatar gagal dimuat
    }
  }

  ctx.restore();

  return canvas.toBuffer('image/png');
}

function truncateText(ctx, text, maxWidth) {
  let result = text;
  while (ctx.measureText(result).width > maxWidth && result.length > 3) {
    result = result.substring(0, result.length - 4) + '...';
  }
  return result;
}

function formatTime(seconds) {
  seconds = Math.floor(seconds);
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  const pad = (n) => String(n).padStart(2, '0');
  if (h > 0) return `${pad(h)}:${pad(m)}:${pad(s)}`;
  return `${pad(m)}:${pad(s)}`;
}

module.exports = { createMusicCard };
