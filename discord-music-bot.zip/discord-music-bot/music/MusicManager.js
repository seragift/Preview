const { DisTube } = require('distube');
const { AttachmentBuilder } = require('discord.js');
const { baseEmbed, errorEmbed, infoEmbed } = require('../utils/embeds');
const { formatDuration, truncate } = require('../utils/helpers');
const { getControlRow } = require('./PlayerControls');
const { createMusicCard } = require('./CanvasCard');
const db = require('../database/database');
const config = require('../config.json');

/**
 * Inisialisasi instance DisTube dan mendaftarkan seluruh event listener
 * @param {import('discord.js').Client} client
 */
function initMusicManager(client) {
  const distube = new DisTube(client, {
    emitNewSongOnly: true,
    savePreviousSongs: true,
    emitAddSongWhenCreatingQueue: false,
    emitAddListWhenCreatingQueue: false,
    nsfw: false,
    leaveOnEmpty: true,
    emptyCooldown: Math.floor((config.leaveOnEmptyDelay || 30000) / 1000),
    leaveOnFinish: true,
    leaveOnStop: true,
    joinNewVoiceChannel: true,
  });

  client.distube = distube;

  // ==================== EVENT: LAGU DIPUTAR ====================
  distube.on('playSong', async (queue, song) => {
    try {
      console.log(`[MUSIC] Memutar "${song.name}" di guild ${queue.textChannel?.guild?.name}`);

      db.recordPlay(
        queue.textChannel.guild.id,
        song.user?.id || 'unknown',
        song.user?.username || 'Unknown',
        song.name,
        song.url
      );

      const cardBuffer = await createMusicCard({
        thumbnail: song.thumbnail,
        title: song.name,
        author: song.uploader?.name || 'Unknown',
        currentTime: 0,
        duration: song.duration,
        isLive: song.isLive,
        requesterAvatar: song.user?.displayAvatarURL?.({ extension: 'png', size: 128 }),
        requesterName: song.user?.username,
      });

      const attachment = new AttachmentBuilder(cardBuffer, { name: 'nowplaying.png' });

      const embed = baseEmbed({
        title: '🎶 Sedang Memutar',
        description: `**[${song.name}](${song.url})**`,
        fields: [
          { name: 'Durasi', value: song.formattedDuration || formatDuration(song.duration), inline: true },
          { name: 'Diminta oleh', value: `${song.user || 'Unknown'}`, inline: true },
          { name: 'Volume', value: `${queue.volume}%`, inline: true },
        ],
        image: 'attachment://nowplaying.png',
      });

      queue.textChannel.send({
        embeds: [embed],
        files: [attachment],
        components: getControlRow(queue),
      });
    } catch (err) {
      console.error('[MUSIC MANAGER] Error saat playSong:', err);
    }
  });

  // ==================== EVENT: LAGU DITAMBAHKAN ====================
  distube.on('addSong', (queue, song) => {
    try {
      const embed = baseEmbed({
        title: '➕ Lagu Ditambahkan ke Queue',
        description: `**[${song.name}](${song.url})**`,
        thumbnail: song.thumbnail,
        fields: [
          { name: 'Durasi', value: song.formattedDuration || formatDuration(song.duration), inline: true },
          { name: 'Posisi', value: `${queue.songs.length - 1}`, inline: true },
          { name: 'Diminta oleh', value: `${song.user || 'Unknown'}`, inline: true },
        ],
      });
      queue.textChannel.send({ embeds: [embed] });
    } catch (err) {
      console.error('[MUSIC MANAGER] Error saat addSong:', err);
    }
  });

  // ==================== EVENT: PLAYLIST DITAMBAHKAN ====================
  distube.on('addList', (queue, playlist) => {
    try {
      const embed = baseEmbed({
        title: '📃 Playlist Ditambahkan ke Queue',
        description: `**${playlist.name}**`,
        thumbnail: playlist.thumbnail,
        fields: [
          { name: 'Jumlah Lagu', value: `${playlist.songs.length}`, inline: true },
          { name: 'Diminta oleh', value: `${playlist.user || 'Unknown'}`, inline: true },
        ],
      });
      queue.textChannel.send({ embeds: [embed] });
    } catch (err) {
      console.error('[MUSIC MANAGER] Error saat addList:', err);
    }
  });

  // ==================== EVENT: LAGU SELESAI ====================
  distube.on('finishSong', (queue, song) => {
    console.log(`[MUSIC] Selesai memutar "${song.name}"`);
  });

  // ==================== EVENT: QUEUE SELESAI SEPENUHNYA ====================
  distube.on('finish', (queue) => {
    try {
      console.log(`[MUSIC] Queue selesai di guild ${queue.textChannel?.guild?.name}`);
      queue.textChannel.send({ embeds: [infoEmbed('Semua lagu dalam queue telah selesai diputar.', '🏁 Queue Selesai')] });
    } catch (err) {
      console.error('[MUSIC MANAGER] Error saat finish:', err);
    }
  });

  // ==================== EVENT: QUEUE KOSONG (User Meninggalkan VC) ====================
  distube.on('empty', (queue) => {
    try {
      queue.textChannel.send({ embeds: [infoEmbed('Voice channel kosong, bot keluar dari voice channel.', '👋 Voice Channel Kosong')] });
    } catch (err) {
      console.error('[MUSIC MANAGER] Error saat empty:', err);
    }
  });

  // ==================== EVENT: BOT DISCONNECT ====================
  distube.on('disconnect', (queue) => {
    try {
      console.log(`[MUSIC] Bot terputus dari voice channel di guild ${queue.textChannel?.guild?.name}`);
    } catch (err) {
      console.error('[MUSIC MANAGER] Error saat disconnect:', err);
    }
  });

  // ==================== EVENT: TIDAK ADA LAGU TERKAIT (AUTOPLAY) ====================
  distube.on('noRelated', (queue) => {
    try {
      queue.textChannel.send({ embeds: [errorEmbed('Tidak dapat menemukan lagu terkait untuk autoplay.')] });
    } catch (err) {
      console.error('[MUSIC MANAGER] Error saat noRelated:', err);
    }
  });

  // ==================== EVENT: ERROR ====================
  distube.on('error', (textChannel, error) => {
    console.error('[DISTUBE ERROR]', error);
    try {
      const channel = textChannel?.send ? textChannel : textChannel?.textChannel;
      if (channel && channel.send) {
        channel.send({
          embeds: [errorEmbed(`Terjadi kesalahan saat memproses musik:\n\`${truncate(error.message || String(error), 500)}\``)],
        });
      }
    } catch (err) {
      console.error('[MUSIC MANAGER] Gagal mengirim pesan error:', err);
    }
  });

  // ==================== EVENT: PENCARIAN TIDAK DITEMUKAN ====================
  distube.on('searchNoResult', (message, query) => {
    try {
      message.channel.send({ embeds: [errorEmbed(`Tidak ditemukan hasil untuk pencarian: **${query}**`)] });
    } catch (err) {
      console.error('[MUSIC MANAGER] Error saat searchNoResult:', err);
    }
  });

  // ==================== DUKUNGAN STAGE CHANNEL ====================
  // Otomatis meminta izin bicara / un-suppress saat bot bergabung ke Stage Channel
  client.on('voiceStateUpdate', async (oldState, newState) => {
    try {
      if (newState.member?.id !== client.user.id) return;
      if (!newState.channel || newState.channel.type !== 13 /* GuildStageVoice */) return;

      if (newState.suppress) {
        await newState.setSuppressed(false).catch(async () => {
          await newState.setRequestToSpeak(true).catch(() => {});
        });
        console.log(`[VOICE] Bot berhasil unmute diri di Stage Channel "${newState.channel.name}"`);
      }
    } catch (err) {
      console.error('[MUSIC MANAGER] Error saat menangani Stage Channel:', err);
    }
  });

  console.log('[MUSIC MANAGER] DisTube berhasil diinisialisasi.');
  return distube;
}

module.exports = { initMusicManager };
