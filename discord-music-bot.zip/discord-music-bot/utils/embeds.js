const { EmbedBuilder } = require('discord.js');
const config = require('../config.json');

/**
 * Membuat embed dasar berwarna gold
 * @param {object} options
 */
function baseEmbed(options = {}) {
  const embed = new EmbedBuilder()
    .setColor(options.color || config.embedColor)
    .setTimestamp();

  if (options.title) embed.setTitle(options.title);
  if (options.description) embed.setDescription(options.description);
  if (options.thumbnail) embed.setThumbnail(options.thumbnail);
  if (options.image) embed.setImage(options.image);
  if (options.author) embed.setAuthor(options.author);
  if (options.fields) embed.addFields(options.fields);
  if (options.footer) {
    embed.setFooter(options.footer);
  } else {
    embed.setFooter({ text: config.footerText });
  }

  return embed;
}

function successEmbed(description, title = '✅ Berhasil') {
  return baseEmbed({ title, description });
}

function errorEmbed(description, title = '❌ Terjadi Kesalahan') {
  return baseEmbed({ title, description, color: '#FF5555' });
}

function infoEmbed(description, title = 'ℹ️ Informasi') {
  return baseEmbed({ title, description });
}

module.exports = {
  baseEmbed,
  successEmbed,
  errorEmbed,
  infoEmbed,
};
