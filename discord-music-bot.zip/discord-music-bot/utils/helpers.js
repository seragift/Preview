/**
 * Mengubah detik menjadi format waktu HH:MM:SS atau MM:SS
 * @param {number} seconds
 */
function formatDuration(seconds) {
  seconds = Math.floor(Number(seconds) || 0);
  if (!isFinite(seconds) || seconds < 0) return '00:00';

  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);

  const pad = (n) => String(n).padStart(2, '0');

  if (h > 0) {
    return `${pad(h)}:${pad(m)}:${pad(s)}`;
  }
  return `${pad(m)}:${pad(s)}`;
}

/**
 * Membuat progress bar teks untuk embed
 * @param {number} current - waktu saat ini (detik)
 * @param {number} total - total durasi (detik)
 * @param {number} size - panjang bar
 */
function createProgressBar(current, total, size = 20) {
  if (!total || total <= 0 || !isFinite(total)) {
    return '🔴 ` LIVE STREAM `';
  }

  const percentage = Math.min(Math.max(current / total, 0), 1);
  const progress = Math.round(size * percentage);
  const emptyProgress = size - progress;

  const progressText = '▬'.repeat(Math.max(progress - 1, 0));
  const emptyText = '▬'.repeat(Math.max(emptyProgress, 0));

  return `${progressText}🔘${emptyText}`;
}

/**
 * Memvalidasi apakah member berada dalam voice channel dan izin bot mencukupi
 */
function validateVoice(message) {
  const { member, guild } = message;
  const voiceChannel = member.voice.channel;

  if (!voiceChannel) {
    return { valid: false, reason: 'Kamu harus berada di dalam voice channel terlebih dahulu!' };
  }

  const permissions = voiceChannel.permissionsFor(guild.members.me);
  if (!permissions.has('Connect') || !permissions.has('Speak')) {
    return { valid: false, reason: 'Bot tidak memiliki izin untuk **Connect** atau **Speak** di voice channel tersebut!' };
  }

  if (voiceChannel.type === 13 /* GuildStageVoice */) {
    if (!permissions.has('RequestToSpeak') && !permissions.has('MuteMembers')) {
      return { valid: false, reason: 'Bot tidak memiliki izin untuk berbicara di Stage Channel ini!' };
    }
  }

  const botVoiceChannel = guild.members.me.voice.channel;
  if (botVoiceChannel && botVoiceChannel.id !== voiceChannel.id) {
    return { valid: false, reason: `Bot sedang digunakan di channel **${botVoiceChannel.name}**!` };
  }

  return { valid: true, voiceChannel };
}

/**
 * Format total durasi queue (array of songs milik distube)
 */
function formatQueueDuration(songs) {
  const totalSeconds = songs.reduce((acc, song) => acc + (song.duration || 0), 0);
  return formatDuration(totalSeconds);
}

/**
 * Memotong string terlalu panjang
 */
function truncate(str, length = 60) {
  if (!str) return '';
  return str.length > length ? `${str.substring(0, length - 3)}...` : str;
}

/**
 * Delay promise
 */
function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

module.exports = {
  formatDuration,
  createProgressBar,
  validateVoice,
  formatQueueDuration,
  truncate,
  sleep,
};
