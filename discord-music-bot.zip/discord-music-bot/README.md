# Discord Music Bot (Jockie-Style)

Bot musik Discord berbasis Node.js, discord.js v14, DisTube, dan Canvas.

## Instalasi

1. **Install Node.js** versi 18 ke atas.
2. **Install dependency:**
   ```bash
   npm install
   ```
   > Catatan: `canvas` dan `better-sqlite3` adalah native module. Di Linux pastikan sudah terinstall `build-essential`, `libcairo2-dev`, `libpango1.0-dev`, `libjpeg-dev`, `libgif-dev`, `librsvg2-dev`. Di Windows/Mac umumnya langsung berjalan dengan prebuilt binary.

3. **Konfigurasi token:**
   - Salin `.env.example` menjadi `.env`.
   - Isi `TOKEN` dengan token bot dari [Discord Developer Portal](https://discord.com/developers/applications).
   - Pastikan intent **MESSAGE CONTENT** dan **SERVER MEMBERS** diaktifkan di halaman Bot pada Developer Portal.

4. **Jalankan bot:**
   ```bash
   npm start
   ```

## Konfigurasi (config.json)

| Key | Deskripsi |
|---|---|
| `prefix` | Prefix command (default `!`) |
| `embedColor` | Warna embed (default gold `#FFD700`) |
| `maxVolume` | Batas maksimum volume |
| `defaultVolume` | Volume default saat lagu diputar |
| `leaveOnEmptyDelay` | Delay (ms) sebelum bot keluar saat voice channel kosong |
| `leaveOnFinishDelay` | Delay (ms) sebelum bot keluar saat queue selesai |
| `maxQueueDisplay` | Jumlah lagu per halaman pada command `queue` |

## Daftar Command

| Command | Alias | Deskripsi |
|---|---|---|
| `!play <url/keyword>` | `!p` | Memutar lagu dari URL, keyword, atau playlist YouTube |
| `!skip` | `!s`, `!next` | Melewati lagu saat ini |
| `!stop` | `!dc` | Menghentikan musik & membersihkan queue |
| `!pause` | - | Menjeda musik |
| `!resume` | `!unpause` | Melanjutkan musik |
| `!queue` | `!q` | Menampilkan antrian dengan pagination |
| `!nowplaying` | `!np` | Menampilkan music card & info lagu |
| `!volume <0-150>` | `!vol` | Mengatur volume |
| `!loop [off/song/queue]` | `!repeat` | Mengatur mode loop |
| `!shuffle` | `!mix` | Mengacak queue |
| `!remove <posisi>` | `!rm` | Menghapus lagu dari queue |
| `!seek <detik/mm:ss>` | - | Melompat ke posisi tertentu |
| `!autoplay` | `!ap` | Toggle autoplay |
| `!lyrics [judul]` | `!lirik` | Menampilkan lirik lagu |
| `!join` | `!summon` | Bot bergabung ke voice channel |
| `!leave` | `!dc` | Bot keluar dari voice channel |

## Fitur Utama

- Multi-server queue (setiap guild memiliki queue terpisah secara otomatis melalui DisTube).
- Tombol interaktif: pause/resume, skip, stop, loop, autoplay, volume up/down.
- Music Card modern menggunakan Canvas dengan progress bar, thumbnail, dan avatar requester.
- Auto-leave saat voice channel kosong & saat queue selesai.
- Dukungan Stage Channel (auto request-to-speak/un-suppress).
- Statistik & histori pemutaran tersimpan di SQLite (`database/database.db`), termasuk lagu paling sering diputar dan pengguna paling aktif.
- Auto-loader command & event dari folder `commands/` dan `events/`.

## Troubleshooting

- **Bot tidak merespon command:** Pastikan intent `MESSAGE CONTENT` diaktifkan di Developer Portal dan bot memiliki permission `Read Messages`, `Send Messages`, `Embed Links`, `Attach Files`.
- **Gagal memutar lagu / error ytdl:** DisTube bergantung pada ekstraksi YouTube yang dapat berubah sewaktu-waktu. Jika terjadi error ekstraksi, pertimbangkan menambahkan plugin `@distube/yt-dlp` sebagai fallback dengan menambahkannya ke `plugins` pada `music/MusicManager.js`.
- **Canvas gagal di-install:** Install dependency native yang dibutuhkan `node-canvas` sesuai OS (lihat dokumentasi resmi node-canvas).
