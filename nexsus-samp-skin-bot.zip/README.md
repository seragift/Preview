# Nexsus SAMP — Skin Checker Bot

Bot Discord untuk mengecek data skin SA-MP / GTA San Andreas (ID `0` sampai `311`) menggunakan prefix command, ditampilkan dalam bentuk **Container (Components V2)** lengkap dengan foto/icon skin dan deskripsi nama skin.

Data ID & nama skin diambil dari **SA-MP Wiki** (sumber resmi yang juga dipakai oleh dokumentasi [open.mp](https://open.mp/id/docs/scripting/resources/skins)), sehingga ID dijamin sesuai.

## ✨ Fitur

- `!skin <id>` — tampilkan detail 1 skin (ID, nama, model name, gender, lokasi singleplayer) beserta foto preview-nya, dalam Container Components V2.
- `!skin cari <kata kunci>` — cari skin berdasarkan nama/model (mis. `!skin cari police`).
- `!skin random` — tampilkan skin acak.
- Bisa dipakai di banyak server sekaligus (bot tidak di-lock ke satu Guild ID — command berbasis prefix, bukan slash command per-guild).

## 📁 Struktur Folder

```
nexsus-samp-skin-bot/
├─ .env                  # isi token bot kamu di sini (JANGAN di-commit ke git)
├─ .env.example          # contoh format .env
├─ index.js              # entry point bot
├─ package.json
└─ src/
   ├─ config.js          # load token & prefix dari .env
   ├─ commands/
   │  └─ skin.js         # logic command !skin
   ├─ handlers/
   │  ├─ commandHandler.js   # auto-load semua command
   │  └─ messageHandler.js   # listener messageCreate + parsing prefix
   ├─ utils/
   │  ├─ skinData.js     # load & query src/data/skins.json
   │  └─ skinCard.js     # builder tampilan Container Components V2
   └─ data/
      └─ skins.json      # dataset 312 skin (ID 0-311)
```

## 🚀 Cara Menjalankan

1. **Install dependency**
   ```bash
   npm install
   ```

2. **Buat aplikasi bot di Discord Developer Portal**
   - Buka https://discord.com/developers/applications → **New Application**.
   - Masuk ke tab **Bot** → klik **Reset Token** → copy token-nya.
   - Di tab **Bot**, aktifkan **MESSAGE CONTENT INTENT** (wajib, karena bot membaca isi pesan untuk prefix command).

3. **Isi file `.env`**
   ```env
   DISCORD_TOKEN=token_bot_kamu
   PREFIX=!
   BOT_NAME=Nexsus SAMP
   ```

4. **Invite bot ke server** (tanpa perlu Guild ID tertentu, jadi bisa dipakai di server manapun):
   - Di Developer Portal → tab **OAuth2 → URL Generator**.
   - Scope: centang `bot`.
   - Bot Permissions: centang **View Channels**, **Send Messages**, **Read Message History** (Embed Links tidak wajib karena pakai Components V2, bukan embed biasa).
   - Buka URL yang dihasilkan di browser, pilih server, lalu **Authorize**.

5. **Jalankan bot**
   ```bash
   npm start
   ```
   Kalau berhasil, di terminal akan muncul log `[READY] Nexsus SAMP online sebagai ...`.

## 💬 Contoh Penggunaan

```
!skin 0
!skin 299
!skin cari police
!skin random
```

## ⚠️ Catatan

- ID **74** valid secara rentang (0-311) tapi **tidak digunakan** oleh game — kalau dipakai di `SetPlayerSkin`, player otomatis kembali ke skin ID `0` (CJ). Bot akan menandai ID ini sebagai "Tidak digunakan / Invalid".
- Fitur Components V2 (Container) butuh **discord.js versi 14.18 ke atas**. `package.json` sudah diset ke versi yang mendukung ini — pastikan jalankan `npm install` agar dapat versi terbaru.
- Jangan commit file `.env` ke repository publik karena berisi token rahasia bot kamu.
