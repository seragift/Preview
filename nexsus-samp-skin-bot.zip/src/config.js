require('dotenv').config();

const DISCORD_TOKEN = process.env.DISCORD_TOKEN;
const PREFIX = process.env.PREFIX || '!';
const BOT_NAME = process.env.BOT_NAME || 'Nexsus SAMP';

if (!DISCORD_TOKEN || DISCORD_TOKEN.includes('ISI_TOKEN')) {
  console.error(
    '[FATAL] DISCORD_TOKEN belum diisi di file .env. Buka file .env dan isi dengan token bot dari Discord Developer Portal.',
  );
  process.exit(1);
}

module.exports = { DISCORD_TOKEN, PREFIX, BOT_NAME };
