const fs = require('node:fs');
const path = require('node:path');

const dataPath = path.join(__dirname, '..', 'data', 'skins.json');
const rawData = fs.readFileSync(dataPath, 'utf-8');

/** @type {Array<{id:number, model:string|null, name:string, location:string, gender:string, image:string, valid:boolean}>} */
const skins = JSON.parse(rawData);

const MIN_ID = 0;
const MAX_ID = 311;

/**
 * Ambil data skin berdasarkan ID (0-311).
 * @param {number} id
 */
function getSkinById(id) {
  if (!Number.isInteger(id) || id < MIN_ID || id > MAX_ID) return null;
  return skins[id] ?? null;
}

/**
 * Cari skin berdasarkan potongan nama atau model name (case-insensitive).
 * @param {string} query
 * @param {number} limit
 */
function searchSkins(query, limit = 10) {
  const q = query.toLowerCase();
  return skins
    .filter((s) => s.valid && (s.name.toLowerCase().includes(q) || (s.model || '').toLowerCase().includes(q)))
    .slice(0, limit);
}

function getRandomValidSkin() {
  const validSkins = skins.filter((s) => s.valid);
  return validSkins[Math.floor(Math.random() * validSkins.length)];
}

module.exports = {
  skins,
  MIN_ID,
  MAX_ID,
  getSkinById,
  searchSkins,
  getRandomValidSkin,
};
