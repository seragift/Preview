const { ContainerBuilder, SectionBuilder, TextDisplayBuilder, ThumbnailBuilder } = require('discord.js');

/**
 * Bangun Container (Components V2) default (tanpa warna) untuk 1 data skin.
 * Isi hanya nama skin + ID di bagian judul, dengan foto skin di sebelah kanan (thumbnail accessory).
 * @param {{id:number, model:string|null, name:string, location:string, gender:string, image:string, valid:boolean}} skin
 */
function buildSkinContainer(skin) {
  const container = new ContainerBuilder();

  const title = new TextDisplayBuilder().setContent(
    `## ${skin.name}\n**ID Skin:** \`${skin.id}\``,
  );

  const thumbnail = new ThumbnailBuilder()
    .setURL(skin.image)
    .setDescription(`Preview skin ID ${skin.id}`);

  const section = new SectionBuilder().addTextDisplayComponents(title).setThumbnailAccessory(thumbnail);

  container.addSectionComponents(section);

  return container;
}

module.exports = { buildSkinContainer };
