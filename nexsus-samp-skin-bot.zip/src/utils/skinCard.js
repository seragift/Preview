const {
  ContainerBuilder,
  SectionBuilder,
  TextDisplayBuilder,
  ThumbnailBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
} = require('discord.js');

const ACCENT_COLOR_VALID = 0x2ecc71; // hijau
const ACCENT_COLOR_INVALID = 0xe74c3c; // merah

/**
 * Bangun Container (Components V2) untuk menampilkan 1 data skin.
 * @param {{id:number, model:string|null, name:string, location:string, gender:string, image:string, valid:boolean}} skin
 */
function buildSkinContainer(skin) {
  const container = new ContainerBuilder().setAccentColor(
    skin.valid ? ACCENT_COLOR_VALID : ACCENT_COLOR_INVALID,
  );

  const header = new TextDisplayBuilder().setContent(
    `## 🧍 Nexsus SAMP — Skin Checker\n**ID Skin:** \`${skin.id}\``,
  );
  container.addTextDisplayComponents(header);
  container.addSeparatorComponents(
    new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true),
  );

  const detailLines = skin.valid
    ? [
        `**Nama Skin:** ${skin.name}`,
        `**Model Name:** \`${skin.model}\``,
        `**Gender:** ${skin.gender}`,
        `**Lokasi (Singleplayer):** ${skin.location}`,
      ]
    : [
        `**Status:** Skin ID ini tidak digunakan / invalid di SA-MP.`,
        `Jika dipakai lewat \`SetPlayerSkin\`, player akan otomatis kembali ke skin ID 0 (CJ).`,
      ];

  const detailText = new TextDisplayBuilder().setContent(detailLines.join('\n'));
  const thumbnail = new ThumbnailBuilder()
    .setURL(skin.image)
    .setDescription(`Preview skin ID ${skin.id}`);

  const section = new SectionBuilder()
    .addTextDisplayComponents(detailText)
    .setThumbnailAccessory(thumbnail);

  container.addSectionComponents(section);

  container.addSeparatorComponents(
    new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true),
  );

  const footer = new TextDisplayBuilder().setContent(
    `-# Sumber data: SA-MP Wiki • Rentang ID valid: 0-311 (kecuali 74)`,
  );
  container.addTextDisplayComponents(footer);

  return container;
}

module.exports = { buildSkinContainer };
