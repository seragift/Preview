const { EmbedBuilder } = require('discord.js');

/**
 * Bangun embed sederhana untuk 1 data skin.
 * Format:
 *   Skin id: <id>
 *   Nama skin: <nama>              (icon skin tampil di thumbnail, pojok kanan atas)
 * @param {{id:number, model:string|null, name:string, location:string, gender:string, image:string, valid:boolean}} skin
 */
function buildSkinEmbed(skin) {
  const embed = new EmbedBuilder()
    .setDescription(`**Skin id:** ${skin.id}\n**Nama skin:** ${skin.name}`)
    .setThumbnail(skin.image);

  return embed;
}

module.exports = { buildSkinEmbed };
