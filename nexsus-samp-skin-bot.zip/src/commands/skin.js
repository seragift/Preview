const {
  ContainerBuilder,
  TextDisplayBuilder,
  MessageFlags,
} = require('discord.js');
const { getSkinById, searchSkins, getRandomValidSkin, MIN_ID, MAX_ID } = require('../utils/skinData');
const { buildSkinContainer } = require('../utils/skinCard');

function buildInfoContainer(text, color = 0xf1c40f) {
  const container = new ContainerBuilder().setAccentColor(color);
  container.addTextDisplayComponents(new TextDisplayBuilder().setContent(text));
  return container;
}

module.exports = {
  name: 'skin',
  aliases: ['skins', 'gtaskin'],
  description: 'Cek data skin SA-MP berdasarkan ID (0-311), nama, atau acak.',
  usage: '!skin <id> | !skin cari <kata kunci> | !skin random',
  /**
   * @param {import('discord.js').Message} message
   * @param {string[]} args
   * @param {string} prefix
   */
  async execute(message, args, prefix) {
    // Tanpa argumen -> tampilkan cara pakai
    if (!args.length) {
      const help = buildInfoContainer(
        [
          '## ℹ️ Cara Pakai — Nexsus SAMP Skin Checker',
          `\`${prefix}skin <id>\` — contoh: \`${prefix}skin 0\` (0 sampai 311)`,
          `\`${prefix}skin cari <kata kunci>\` — contoh: \`${prefix}skin cari police\``,
          `\`${prefix}skin random\` — tampilkan skin acak`,
        ].join('\n'),
      );
      return message.reply({ components: [help], flags: MessageFlags.IsComponentsV2 });
    }

    const sub = args[0].toLowerCase();

    // !skin random
    if (sub === 'random' || sub === 'acak') {
      const skin = getRandomValidSkin();
      const container = buildSkinContainer(skin);
      return message.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
    }

    // !skin cari <query> / !skin search <query>
    if (sub === 'cari' || sub === 'search') {
      const query = args.slice(1).join(' ').trim();
      if (!query) {
        const info = buildInfoContainer(
          `Masukkan kata kunci pencarian.\nContoh: \`${prefix}skin cari police\``,
          0xe67e22,
        );
        return message.reply({ components: [info], flags: MessageFlags.IsComponentsV2 });
      }

      const results = searchSkins(query, 10);
      if (!results.length) {
        const info = buildInfoContainer(
          `Tidak ada skin yang cocok dengan kata kunci **${query}**.`,
          0xe74c3c,
        );
        return message.reply({ components: [info], flags: MessageFlags.IsComponentsV2 });
      }

      const lines = results.map((s) => `\`${String(s.id).padStart(3, '0')}\` — ${s.name} (${s.model})`);
      const info = buildInfoContainer(
        [`## 🔎 Hasil pencarian: "${query}"`, ...lines, '', `Gunakan \`${prefix}skin <id>\` untuk detail lengkap.`].join(
          '\n',
        ),
        0x3498db,
      );
      return message.reply({ components: [info], flags: MessageFlags.IsComponentsV2 });
    }

    // !skin <id>
    const id = Number.parseInt(sub, 10);
    if (Number.isNaN(id) || String(id) !== sub) {
      const info = buildInfoContainer(
        `Argumen tidak dikenali: \`${args[0]}\`\nGunakan \`${prefix}skin <id>\` (contoh: \`${prefix}skin 0\`), \`${prefix}skin cari <kata kunci>\`, atau \`${prefix}skin random\`.`,
        0xe74c3c,
      );
      return message.reply({ components: [info], flags: MessageFlags.IsComponentsV2 });
    }

    if (id < MIN_ID || id > MAX_ID) {
      const info = buildInfoContainer(
        `ID skin harus di antara **${MIN_ID}** sampai **${MAX_ID}**.\nContoh: \`${prefix}skin 0\``,
        0xe74c3c,
      );
      return message.reply({ components: [info], flags: MessageFlags.IsComponentsV2 });
    }

    const skin = getSkinById(id);
    const container = buildSkinContainer(skin);
    return message.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
  },
};
