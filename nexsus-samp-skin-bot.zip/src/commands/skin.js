const { ContainerBuilder, TextDisplayBuilder, MessageFlags } = require('discord.js');
const {
  getSkinById,
  getSkinByQuery,
  searchSkins,
  getRandomValidSkin,
  MIN_ID,
  MAX_ID,
} = require('../utils/skinData');
const { buildSkinContainer } = require('../utils/skinCard');

function buildInfoContainer(text) {
  const container = new ContainerBuilder();
  container.addTextDisplayComponents(new TextDisplayBuilder().setContent(text));
  return container;
}

module.exports = {
  name: 'skin',
  aliases: ['skins', 'gtaskin'],
  description: 'Cek data skin SA-MP berdasarkan ID (0-311), nama, atau acak.',
  usage: '!skin <id|nama> | !skin cari <kata kunci> | !skin random',
  /**
   * @param {import('discord.js').Message} message
   * @param {string[]} args
   * @param {string} prefix
   */
  async execute(message, args, prefix) {
    // Tanpa argumen -> tampilkan cara pakai
    if (!args.length) {
      const help = buildInfoContainer(
        [
          '## ℹ️ Cara Pakai — Nexsus SAMP Skin Checker',
          `\`${prefix}skin <id>\` — contoh: \`${prefix}skin 0\` (0 sampai 311)`,
          `\`${prefix}skin <nama>\` — contoh: \`${prefix}skin cj\`, \`${prefix}skin swat\``,
          `\`${prefix}skin cari <kata kunci>\` — contoh: \`${prefix}skin cari police\``,
          `\`${prefix}skin random\` — tampilkan skin acak`,
        ].join('\n'),
      );
      return message.reply({ components: [help], flags: MessageFlags.IsComponentsV2 });
    }

    const sub = args[0].toLowerCase();

    // !skin random
    if (sub === 'random' || sub === 'acak') {
      const skin = getRandomValidSkin();
      const container = buildSkinContainer(skin);
      return message.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
    }

    // !skin cari <query> / !skin search <query> -> daftar beberapa hasil
    if (sub === 'cari' || sub === 'search') {
      const query = args.slice(1).join(' ').trim();
      if (!query) {
        const info = buildInfoContainer(`Masukkan kata kunci pencarian.\nContoh: \`${prefix}skin cari police\``);
        return message.reply({ components: [info], flags: MessageFlags.IsComponentsV2 });
      }

      const results = searchSkins(query, 10);
      if (!results.length) {
        const info = buildInfoContainer(`Tidak ada skin yang cocok dengan kata kunci **${query}**.`);
        return message.reply({ components: [info], flags: MessageFlags.IsComponentsV2 });
      }

      const lines = results.map((s) => `\`${String(s.id).padStart(3, '0')}\` — ${s.name} (${s.model})`);
      const info = buildInfoContainer(
        [`## 🔎 Hasil pencarian: "${query}"`, ...lines, '', `Gunakan \`${prefix}skin <id>\` untuk detail lengkap.`].join(
          '\n',
        ),
      );
      return message.reply({ components: [info], flags: MessageFlags.IsComponentsV2 });
    }

    // Jika argumen berupa angka -> cari berdasarkan ID
    const asNumber = Number.parseInt(sub, 10);
    const isNumeric = !Number.isNaN(asNumber) && String(asNumber) === sub;

    if (isNumeric) {
      if (asNumber < MIN_ID || asNumber > MAX_ID) {
        const info = buildInfoContainer(
          `ID skin harus di antara **${MIN_ID}** sampai **${MAX_ID}**.\nContoh: \`${prefix}skin 0\``,
        );
        return message.reply({ components: [info], flags: MessageFlags.IsComponentsV2 });
      }

      const skin = getSkinById(asNumber);
      const container = buildSkinContainer(skin);
      return message.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
    }

    // Bukan angka & bukan subcommand -> anggap sebagai nama/model skin, berlaku untuk SEMUA skin
    // Contoh: !skin cj, !skin swat, !skin big smoke
    const query = args.join(' ').trim();
    const skin = getSkinByQuery(query);

    if (!skin) {
      const info = buildInfoContainer(
        [
          `Skin dengan nama **${query}** tidak ditemukan.`,
          `Coba \`${prefix}skin cari ${query}\` untuk melihat skin yang mirip, atau gunakan \`${prefix}skin <id>\`.`,
        ].join('\n'),
      );
      return message.reply({ components: [info], flags: MessageFlags.IsComponentsV2 });
    }

    const container = buildSkinContainer(skin);
    return message.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
  },
};
