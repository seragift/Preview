const { EmbedBuilder } = require('discord.js');
const {
  getSkinById,
  getSkinByQuery,
  searchSkins,
  getRandomValidSkin,
  MIN_ID,
  MAX_ID,
} = require('../utils/skinData');
const { buildSkinEmbed } = require('../utils/skinCard');

function buildInfoEmbed(text) {
  return new EmbedBuilder().setDescription(text);
}

module.exports = {
  name: 'skin',
  aliases: ['skins', 'gtaskin'],
  description: 'Cek data skin SA-MP berdasarkan ID (0-311), nama, atau acak.',
  usage: '!skin <id|nama> | !skin cari <kata kunci> | !skin random',
  /**
   * @param {import('discord.js').Message} message
   * @param {string[]} args
   * @param {string} prefix
   */
  async execute(message, args, prefix) {
    // Tanpa argumen -> tampilkan cara pakai
    if (!args.length) {
      const help = buildInfoEmbed(
        [
          '**Cara Pakai — Nexsus SAMP Skin Checker**',
          `\`${prefix}skin <id>\` — contoh: \`${prefix}skin 0\` (0 sampai 311)`,
          `\`${prefix}skin <nama>\` — contoh: \`${prefix}skin cj\`, \`${prefix}skin swat\``,
          `\`${prefix}skin cari <kata kunci>\` — contoh: \`${prefix}skin cari police\``,
          `\`${prefix}skin random\` — tampilkan skin acak`,
        ].join('\n'),
      );
      return message.reply({ embeds: [help] });
    }

    const sub = args[0].toLowerCase();

    // !skin random
    if (sub === 'random' || sub === 'acak') {
      const skin = getRandomValidSkin();
      return message.reply({ embeds: [buildSkinEmbed(skin)] });
    }

    // !skin cari <query> / !skin search <query> -> daftar beberapa hasil
    if (sub === 'cari' || sub === 'search') {
      const query = args.slice(1).join(' ').trim();
      if (!query) {
        const info = buildInfoEmbed(`Masukkan kata kunci pencarian.\nContoh: \`${prefix}skin cari police\``);
        return message.reply({ embeds: [info] });
      }

      const results = searchSkins(query, 10);
      if (!results.length) {
        const info = buildInfoEmbed(`Tidak ada skin yang cocok dengan kata kunci **${query}**.`);
        return message.reply({ embeds: [info] });
      }

      const lines = results.map((s) => `\`${String(s.id).padStart(3, '0')}\` — ${s.name} (${s.model})`);
      const info = buildInfoEmbed(
        [`**Hasil pencarian: "${query}"**`, ...lines, '', `Gunakan \`${prefix}skin <id>\` untuk detail lengkap.`].join(
          '\n',
        ),
      );
      return message.reply({ embeds: [info] });
    }

    // Jika argumen berupa angka -> cari berdasarkan ID
    const asNumber = Number.parseInt(sub, 10);
    const isNumeric = !Number.isNaN(asNumber) && String(asNumber) === sub;

    if (isNumeric) {
      if (asNumber < MIN_ID || asNumber > MAX_ID) {
        const info = buildInfoEmbed(
          `ID skin harus di antara **${MIN_ID}** sampai **${MAX_ID}**.\nContoh: \`${prefix}skin 0\``,
        );
        return message.reply({ embeds: [info] });
      }

      const skin = getSkinById(asNumber);
      return message.reply({ embeds: [buildSkinEmbed(skin)] });
    }

    // Bukan angka & bukan subcommand -> anggap sebagai nama/model skin, berlaku untuk SEMUA skin
    // Contoh: !skin cj, !skin swat, !skin big smoke
    const query = args.join(' ').trim();
    const skin = getSkinByQuery(query);

    if (!skin) {
      const info = buildInfoEmbed(
        [
          `Skin dengan nama **${query}** tidak ditemukan.`,
          `Coba \`${prefix}skin cari ${query}\` untuk melihat skin yang mirip, atau gunakan \`${prefix}skin <id>\`.`,
        ].join('\n'),
      );
      return message.reply({ embeds: [info] });
    }

    return message.reply({ embeds: [buildSkinEmbed(skin)] });
  },
};
