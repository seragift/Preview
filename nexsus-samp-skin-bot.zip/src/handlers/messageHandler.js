const { PREFIX } = require('../config');

/**
 * @param {import('discord.js').Client} client
 * @param {Map<string, any>} commands
 */
function registerMessageHandler(client, commands) {
  client.on('messageCreate', async (message) => {
    try {
      // Abaikan pesan dari bot lain / diri sendiri, dan pesan tanpa prefix
      if (message.author.bot) return;
      if (!message.content.startsWith(PREFIX)) return;

      const args = message.content.slice(PREFIX.length).trim().split(/\s+/);
      const commandName = args.shift()?.toLowerCase();
      if (!commandName) return;

      const command = commands.get(commandName);
      if (!command) return;

      await command.execute(message, args, PREFIX);
    } catch (err) {
      console.error('[ERROR] Gagal menjalankan command:', err);
      if (message.channel?.send) {
        message.channel
          .send('⚠️ Terjadi kesalahan saat menjalankan command tersebut.')
          .catch(() => {});
      }
    }
  });
}

module.exports = { registerMessageHandler };
