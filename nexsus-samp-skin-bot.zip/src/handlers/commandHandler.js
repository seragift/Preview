const fs = require('node:fs');
const path = require('node:path');

/**
 * Muat semua command dari folder src/commands secara otomatis.
 * @returns {Map<string, any>} map nama command (& alias) -> module command
 */
function loadCommands() {
  const commands = new Map();
  const commandsPath = path.join(__dirname, '..', 'commands');
  const files = fs.readdirSync(commandsPath).filter((f) => f.endsWith('.js'));

  for (const file of files) {
    const command = require(path.join(commandsPath, file));
    if (!command?.name || typeof command.execute !== 'function') {
      console.warn(`[WARN] Command di file "${file}" tidak valid, dilewati.`);
      continue;
    }

    commands.set(command.name, command);
    if (Array.isArray(command.aliases)) {
      for (const alias of command.aliases) {
        commands.set(alias, command);
      }
    }
    console.log(`[OK] Command dimuat: ${command.name}`);
  }

  return commands;
}

module.exports = { loadCommands };
