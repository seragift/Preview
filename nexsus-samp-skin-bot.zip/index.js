const { Client, GatewayIntentBits, Partials, ActivityType } = require('discord.js');
const { DISCORD_TOKEN, PREFIX, BOT_NAME } = require('./src/config');
const { loadCommands } = require('./src/handlers/commandHandler');
const { registerMessageHandler } = require('./src/handlers/messageHandler');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
  partials: [Partials.Channel],
});

const commands = loadCommands();
registerMessageHandler(client, commands);

client.once('ready', (c) => {
  console.log(`[READY] ${BOT_NAME} online sebagai ${c.user.tag}`);
  console.log(`[INFO] Prefix aktif: "${PREFIX}"`);
  console.log(`[INFO] Bot aktif di ${c.guilds.cache.size} server.`);

  c.user.setPresence({
    activities: [{ name: `${PREFIX}skin <id> | ${BOT_NAME}`, type: ActivityType.Watching }],
    status: 'online',
  });
});

client.on('error', (err) => console.error('[CLIENT ERROR]', err));
process.on('unhandledRejection', (err) => console.error('[UNHANDLED REJECTION]', err));

client.login(DISCORD_TOKEN);
