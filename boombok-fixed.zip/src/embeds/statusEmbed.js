const { EmbedBuilder } = require('discord.js');

const COLORS = {
    progress: '#5865F2', // Blurple - proses berjalan
    success: '#57F287',  // Hijau - berhasil
    error:   '#ED4245',  // Merah - gagal
    warning: '#FEE75C',  // Kuning - peringatan / limit
    info:    '#5865F2'   // Blurple - info umum
};

function getFooterContext(ctx) {
    if (ctx?.client?.user && ctx?.guild) {
        return { text: `${ctx.client.user.username} • ${ctx.guild.name}`, iconURL: ctx.client.user.displayAvatarURL() };
    }
    if (ctx?.client?.user) {
        return { text: ctx.client.user.username, iconURL: ctx.client.user.displayAvatarURL() };
    }
    return null;
}

/**
 * Progress bar visual dari persentase (0-100)
 */
function buildProgressBar(percent) {
    const totalSegments = 10;
    const filled = Math.round((percent / 100) * totalSegments);
    const bar = '▰'.repeat(filled) + '▱'.repeat(totalSegments - filled);
    return `${bar}  \`${percent}%\``;
}

/**
 * Embed status proses (loading/progress) — dipakai di setiap tahap: fetch info, download, upload
 */
function createProgressEmbed(ctx, title, percent, detail = null) {
    const embed = new EmbedBuilder()
        .setColor(COLORS.progress)
        .setAuthor({ name: title, iconURL: ctx.client.user.displayAvatarURL() })
        .setDescription(`${buildProgressBar(percent)}${detail ? `\n\n> ${detail}` : ''}`)
        .setTimestamp();

    const footer = getFooterContext(ctx);
    if (footer) embed.setFooter(footer);
    return embed;
}

/**
 * Embed error seragam dengan format sebab-akibat yang rapi
 */
function createErrorEmbed(ctx, title, description, cause = null) {
    const embed = new EmbedBuilder()
        .setColor(COLORS.error)
        .setAuthor({ name: title, iconURL: ctx.client.user.displayAvatarURL() })
        .setDescription(description)
        .setTimestamp();

    if (cause) {
        // Discord membatasi value field embed maksimal 1024 karakter.
        // Sisakan ruang untuk ```...``` (6 karakter) + buffer.
        const MAX_LEN = 1000;
        let causeText = String(cause);
        if (causeText.length > MAX_LEN) {
            causeText = causeText.slice(0, MAX_LEN) + '\n... (dipotong)';
        }
        embed.addFields({ name: '⚠️ Penyebab', value: `\`\`\`${causeText}\`\`\`` });
    }

    const footer = getFooterContext(ctx);
    if (footer) embed.setFooter(footer);
    return embed;
}

/**
 * Embed peringatan (limit kuota, durasi melebihi batas, tautan tidak valid, dsb)
 */
function createWarningEmbed(ctx, title, description) {
    const embed = new EmbedBuilder()
        .setColor(COLORS.warning)
        .setAuthor({ name: title, iconURL: ctx.client.user.displayAvatarURL() })
        .setDescription(description)
        .setTimestamp();

    const footer = getFooterContext(ctx);
    if (footer) embed.setFooter(footer);
    return embed;
}

/**
 * Embed info/success umum (bukan hasil convert musik) — dipakai untuk command admin/owner
 */
function createInfoEmbed(ctx, title, description, fields = [], color = COLORS.success) {
    const embed = new EmbedBuilder()
        .setColor(color)
        .setAuthor({ name: title, iconURL: ctx.client.user.displayAvatarURL() })
        .setDescription(description)
        .setTimestamp();

    if (fields.length) embed.addFields(fields);

    const footer = getFooterContext(ctx);
    if (footer) embed.setFooter(footer);
    return embed;
}

module.exports = {
    COLORS,
    buildProgressBar,
    createProgressEmbed,
    createErrorEmbed,
    createWarningEmbed,
    createInfoEmbed
};
