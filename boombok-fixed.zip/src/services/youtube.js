const YTDlpWrap = require('yt-dlp-wrap').default;
const path = require('path');
const fs = require('fs');
const axios = require('axios');
const config = require('../../config.json');

const ytdlpPath = path.join(process.cwd(), 'yt-dlp');
const cookiesPath = path.join(process.cwd(), 'cookies.txt');
let ytdlp;

/**
 * Ubah durasi format ISO 8601 dari YouTube Data API (contoh: "PT4M13S") jadi total detik.
 */
function parseISO8601Duration(duration) {
    const match = (duration || '').match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/);
    if (!match) return 0;
    const hours = parseInt(match[1] || '0', 10);
    const minutes = parseInt(match[2] || '0', 10);
    const seconds = parseInt(match[3] || '0', 10);
    return hours * 3600 + minutes * 60 + seconds;
}

/**
 * Ambil metadata video lewat YouTube Data API v3 resmi (butuh youtubeApiKey di config.json).
 * Ini jalur utama karena tidak kena wall "Sign in to confirm you're not a bot" sama sekali —
 * beda dengan scraping via yt-dlp yang rawan diblokir YouTube.
 * Return null kalau API key kosong / request gagal, supaya caller bisa fallback ke yt-dlp.
 */
async function getVideoInfoFromApi(videoId) {
    if (!config.youtubeApiKey) return null;
    try {
        const { data } = await axios.get('https://www.googleapis.com/youtube/v3/videos', {
            params: {
                part: 'snippet,contentDetails,statistics',
                id: videoId,
                key: config.youtubeApiKey
            }
        });
        const item = data.items && data.items[0];
        if (!item) return null;
        const durationSeconds = parseISO8601Duration(item.contentDetails.duration);
        const thumbnails = item.snippet.thumbnails || {};
        const thumbnail = (thumbnails.maxres || thumbnails.high || thumbnails.medium || thumbnails.default || {}).url
            || 'https://i.imgur.com/8Q5FqW0.png';
        return {
            title: item.snippet.title || 'Unknown Title',
            durationSeconds,
            durationString: formatDuration(durationSeconds),
            channelName: item.snippet.channelTitle || 'Unknown Channel',
            views: item.statistics && item.statistics.viewCount
                ? Number(item.statistics.viewCount).toLocaleString('id-ID')
                : '0',
            thumbnailUrl: thumbnail
        };
    } catch (err) {
        console.warn('⚠️ YouTube Data API gagal (cek youtubeApiKey/quota), fallback ke yt-dlp:', err.message);
        return null;
    }
}

/**
 * Workaround untuk error YouTube "Sign in to confirm you're not a bot":
 * - Paksa pakai player_client=android (jalur ini biasanya belum kena wall bot-check
 *   yang berlaku di jalur client web).
 * - Kalau ada file cookies.txt (hasil export cookie akun YouTube via ekstensi browser
 *   seperti "Get cookies.txt LOCALLY"), otomatis dipakai juga sebagai lapisan kedua.
 *   Ini opsional — taruh file cookies.txt di root project kalau workaround android
 *   client saja masih belum cukup.
 */
function getBotCheckBypassArgs() {
    const args = ['--extractor-args', 'youtube:player_client=android,web'];
    if (fs.existsSync(cookiesPath)) {
        args.push('--cookies', cookiesPath);
    }
    return args;
}

async function initYtdlp() {
    if (!fs.existsSync(ytdlpPath)) {
        console.log('📥 yt-dlp tidak ditemukan. Mengunduh yt-dlp otomatis...');
        try {
            await YTDlpWrap.downloadFromGithub(ytdlpPath);
            fs.chmodSync(ytdlpPath, '755');
            console.log('✅ yt-dlp berhasil diunduh otomatis!');
        } catch (err) {
            console.error('❌ Gagal mengunduh yt-dlp otomatis:', err);
            process.exit(1);
        }
    }
    ytdlp = new YTDlpWrap(ytdlpPath);
}

function formatDuration(seconds) {
    if (!seconds) return '00:00';
    const date = new Date(0);
    date.setSeconds(seconds);
    const timeString = date.toISOString().substr(11, 8);
    return timeString.startsWith('00:') ? timeString.substr(3) : timeString;
}

/**
 * Tentukan bitrate audio berdasarkan durasi video.
 * Video panjang otomatis diturunkan kualitasnya, DUA alasan:
 * 1) proses download+convert jauh lebih cepat
 * 2) Top4top (anonymous/tanpa akun) punya limit ±100MB per file — video berjam-jam
 *    di bitrate tinggi bakal nabrak limit itu dan bikin upload gagal/return halaman error
 *    (yang sebelumnya nongol sebagai "Gagal memparsing link upload Top4top").
 * Tabel di bawah dijaga supaya estimasi ukuran file tetap di bawah ±90MB (kasih margin aman).
 */
function getAudioQuality(durationSeconds = 0) {
    if (durationSeconds >= 10800) return '32K';  // >= 3 jam  -> ~90MB di 3 jam, aman di bawah limit
    if (durationSeconds >= 7200)  return '48K';  // >= 2 jam
    if (durationSeconds >= 3600)  return '64K';  // >= 1 jam
    if (durationSeconds >= 1800)  return '96K';  // >= 30 menit -> prioritas kecepatan
    if (durationSeconds >= 600)   return '128K'; // >= 10 menit -> kualitas menengah
    return '192K';                               // < 10 menit -> kualitas penuh
}

async function getVideoInfo(videoUrl, videoId = null) {
    // 1. Coba lewat YouTube Data API resmi dulu (kalau videoId ada & API key diisi)
    if (videoId) {
        const apiResult = await getVideoInfoFromApi(videoId);
        if (apiResult) return apiResult;
    }

    // 2. Fallback: scraping via yt-dlp (tetap rawan kena bot-check YouTube)
    if (!ytdlp) await initYtdlp();
    const metadata = await ytdlp.getVideoInfo([
        videoUrl,
        '-f', 'bestaudio/best',
        ...getBotCheckBypassArgs()
    ]);

    // Cari thumbnail terbaik
    const thumbnail = metadata.thumbnail || (metadata.thumbnails && metadata.thumbnails.length ? metadata.thumbnails[metadata.thumbnails.length - 1].url : 'https://i.imgur.com/8Q5FqW0.png');

    return {
        title: metadata.title || 'Unknown Title',
        durationSeconds: metadata.duration || 0,
        durationString: formatDuration(metadata.duration),
        channelName: metadata.uploader || 'Unknown Channel',
        views: metadata.view_count ? metadata.view_count.toLocaleString('id-ID') : '0',
        thumbnailUrl: thumbnail
    };
}

// Ambang batas durasi buat nentuin strategi download (detik)
const ARIA2_THRESHOLD_SECONDS = 600; // >= 10 menit

/**
 * Video panjang -> aria2c sebagai external downloader (multi-koneksi paralel, paling ngebut).
 * Video pendek/menengah -> native downloader yt-dlp TAPI tetap dipaksa chunked/paralel via
 * --http-chunk-size + --concurrent-fragments, jadi tetap dapet speed boost tanpa perlu
 * spawn proses tambahan (aria2c) yang overhead-nya gak worth it buat file kecil.
 */
function getDownloaderArgs(durationSeconds = 0) {
    if (durationSeconds >= ARIA2_THRESHOLD_SECONDS) {
        return ['--downloader', 'aria2c', '--downloader-args', 'aria2c:-x 16 -s 16 -k 1M'];
    }
    return ['--http-chunk-size', '10M', '--concurrent-fragments', '4'];
}

/**
 * Download + convert ke MP3 dalam SATU proses yt-dlp (ekstraksi audio langsung),
 * menggantikan alur lama (download mp4 mentah -> convert terpisah via fluent-ffmpeg).
 * Ini menghilangkan satu tahap I/O penuh (tidak ada lagi file video mentah di disk)
 * sehingga proses jauh lebih cepat, ditambah kualitas dinamis untuk video panjang.
 *
 * PENTING: '-f bestaudio/best' memaksa yt-dlp ambil stream AUDIO-ONLY dari YouTube,
 * bukan video+audio gabungan lalu di-strip. Sebelumnya flag ini nggak ada, jadi selama
 * ini kemungkinan besar tetap download videonya juga (sia-sia, karena cuma butuh audio) —
 * ini optimasi speed paling signifikan dari semuanya.
 */
async function processAudio(videoUrl, videoId, durationSeconds = 0) {
    if (!ytdlp) await initYtdlp();

    const tempAudioPath = path.join(process.cwd(), `audio_${videoId}.mp3`);
    const audioQuality = getAudioQuality(durationSeconds);
    const usingAria2 = durationSeconds >= ARIA2_THRESHOLD_SECONDS;

    const baseArgs = [
        videoUrl,
        '-f', 'bestaudio/best',
        '-x',
        '--audio-format', 'mp3',
        '--audio-quality', audioQuality,
        '--no-playlist',
        '--no-write-info-json',
        '--no-write-thumbnail',
        '-o', tempAudioPath,
        ...getBotCheckBypassArgs()
    ];

    try {
        await ytdlp.execPromise([...baseArgs, ...getDownloaderArgs(durationSeconds)]);
    } catch (err) {
        // Fallback: kalau aria2c belum terinstall di container (ENOENT/exec gagal),
        // otomatis retry pakai native chunked downloader biar tetap jalan.
        if (usingAria2 && /aria2c|ENOENT|not found/i.test(err.message || '')) {
            console.warn('⚠️ aria2c gagal dipanggil, fallback ke native chunked downloader:', err.message);
            await ytdlp.execPromise([...baseArgs, '--http-chunk-size', '10M', '--concurrent-fragments', '4']);
            return { audioPath: tempAudioPath, quality: audioQuality, downloader: 'ffmpeg (fallback)' };
        }
        throw err;
    }

    return { audioPath: tempAudioPath, quality: audioQuality, downloader: usingAria2 ? 'aria2c' : 'ffmpeg' };
}

module.exports = {
    initYtdlp,
    getVideoInfo,
    processAudio,
    getAudioQuality,
    getDownloaderArgs
};
