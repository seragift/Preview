const { Client, Collection, GatewayIntentBits, Partials, REST, Routes } = require('discord.js');
const fs = require('fs');
const path = require('path');

// ===== CEK FILE CONFIG =====
const CONFIG_PATH = path.join(__dirname, 'config.json');
if (!fs.existsSync(CONFIG_PATH)) {
    console.error('❌ config.json tidak ditemukan!');
    console.log('📝 Buat file config.json dengan format:');
    console.log(JSON.stringify({
        token: "YOUR_BOT_TOKEN",
        clientId: "YOUR_CLIENT_ID",
        logChannelId: "1517881564007239833"
    }, null, 2));
    process.exit(1);
}

let config;
try {
    config = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
    console.log('✅ Config loaded successfully');
} catch (error) {
    console.error('❌ Error parsing config.json:', error.message);
    console.log('📝 Pastikan config.json adalah JSON valid!');
    process.exit(1);
}

// ===== VALIDASI CONFIG =====
if (!config.token || config.token === 'YOUR_BOT_TOKEN_HERE') {
    console.error('❌ Token tidak valid di config.json!');
    process.exit(1);
}

if (!config.clientId || config.clientId === 'YOUR_CLIENT_ID_HERE') {
    console.error('❌ Client ID tidak valid di config.json!');
    process.exit(1);
}

// ===== IMPORT AUTOPOST HANDLE =====
const { 
    startAutopostEngine,
    stopEngine,
    handleAutopostSubcommands,
    handleAutopostAutocomplete,
    autoPostDB,
    saveConfig,
    loadConfig
} = require('./autopostHandle');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.DirectMessages,
        GatewayIntentBits.GuildVoiceStates
    ],
    partials: [Partials.Channel, Partials.Message, Partials.User]
});

client.commands = new Collection();
const commandsArray = [];

// Load commands
const foldersPath = path.join(__dirname, 'commands');
if (fs.existsSync(foldersPath)) {
    fs.readdirSync(foldersPath).forEach(folder => {
        const commandFiles = fs.readdirSync(path.join(foldersPath, folder)).filter(f => f.endsWith('.js'));
        for (const file of commandFiles) {
            try {
                const cmd = require(path.join(foldersPath, folder, file));
                if (cmd.data) {
                    client.commands.set(cmd.data.name, cmd);
                    commandsArray.push(cmd.data.toJSON());
                }
            } catch (error) {
                console.error(`❌ Failed to load command ${file}:`, error.message);
            }
        }
    });
}

// Login
client.login(config.token).then(async () => {
    console.log('🔓 Bot Aktif');
    console.log(`📊 Loaded ${client.commands.size} commands`);
    
    try {
        const rest = new REST({ version: '10' }).setToken(config.token);
        await rest.put(Routes.applicationCommands(config.clientId), { body: commandsArray });
        console.log('✅ Commands terdaftar!');
    } catch (error) {
        console.error('❌ Register commands error:', error.message);
    }

    // Start engine
    const logChannelId = config.logChannelId || config.logChannel || '1517881564007239833';
    startAutopostEngine(logChannelId, client);
    console.log('🔁 AzesZ AutoPost Engine started');

}).catch(error => {
    console.error('❌ Login error:', error.message);
    process.exit(1);
});

// Interaction handler
client.on('interactionCreate', async interaction => {
    try {
        if (interaction.isAutocomplete()) {
            if (interaction.commandName === 'autopostpanel') {
                await handleAutopostAutocomplete(interaction);
            }
            return;
        }

        if (interaction.isButton()) {
            if (interaction.customId === 'setup_autopost') {
                return interaction.reply({ 
                    content: '⚠️ Gunakan `/autopostpanel create` untuk setup baru.', 
                    ephemeral: true 
                });
            }
            return;
        }

        if (interaction.isModalSubmit()) {
            if (interaction.customId === 'autopost_modal') {
                return interaction.reply({ 
                    content: '⚠️ Gunakan `/autopostpanel create` untuk setup baru.', 
                    ephemeral: true 
                });
            }
            return;
        }

        if (interaction.isChatInputCommand()) {
            const command = client.commands.get(interaction.commandName);
            if (!command) {
                return interaction.reply({ content: '❌ Command tidak ditemukan.', ephemeral: true });
            }

            if (interaction.commandName === 'autopostpanel') {
                const subcommand = interaction.options.getSubcommand();
                await handleAutopostSubcommands(interaction, subcommand);
                return;
            }

            await command.execute(interaction);
        }
    } catch (error) {
        console.error('Interaction error:', error);
        if (!interaction.replied) {
            await interaction.reply({ content: `❌ Error: ${error.message}`, ephemeral: true });
        }
    }
});

client.once('ready', () => {
    console.log(`✅ Logged in as ${client.user.tag}`);
    console.log(`📡 Connected to ${client.guilds.cache.size} guilds`);
});

// ===== HEALTH CHECK =====
setInterval(() => {
    try {
        let activeConfigs = 0;
        let totalConfigs = 0;
        for (const [key, data] of autoPostDB) {
            totalConfigs++;
            if (data && data.active === true) {
                activeConfigs++;
            }
        }
        console.log(`💓 Heartbeat: ${totalConfigs} configs, ${activeConfigs} active`);
    } catch (error) {
        console.error('❌ Health check error:', error.message);
    }
}, 60000);

// ===== ERROR HANDLING =====
process.on('unhandledRejection', error => {
    console.error('❌ Unhandled rejection:', error);
});

process.on('uncaughtException', error => {
    console.error('❌ Uncaught exception:', error);
});

// ===== GRACEFUL SHUTDOWN =====
process.on('SIGINT', () => {
    console.log('🛑 Shutting down...');
    try {
        if (typeof stopEngine === 'function') stopEngine();
        if (typeof saveConfig === 'function') saveConfig();
    } catch (e) {
        console.error('Shutdown error:', e);
    }
    process.exit(0);
});

process.on('SIGTERM', () => {
    console.log('🛑 Shutting down...');
    try {
        if (typeof stopEngine === 'function') stopEngine();
        if (typeof saveConfig === 'function') saveConfig();
    } catch (e) {
        console.error('Shutdown error:', e);
    }
    process.exit(0);
});