const { ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

const CONFIG_PATH = path.join(__dirname, 'autopost_config.json');
let autoPostDB = new Map();
let engineInterval = null;
let clientInstance = null;
let isEngineRunning = false;
let isProcessing = false;

// ===================== LOAD & SAVE CONFIG =====================
function loadConfig() {
    try {
        if (fs.existsSync(CONFIG_PATH)) {
            const data = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
            autoPostDB = new Map(Object.entries(data));
            console.log('✅ Config loaded:', autoPostDB.size, 'entries');
            
            for (const [key, data] of autoPostDB) {
                console.log(`📌 Config: ${key} | active: ${data.active} | name: ${data.name} | targets: ${data.targets?.length || 0} | delay: ${data.delay}s`);
            }
        } else {
            console.log('📭 No existing config found, creating new...');
        }
    } catch (e) {
        console.error('❌ Config load error:', e.message);
    }
}

function saveConfig() {
    try {
        const obj = Object.fromEntries(autoPostDB);
        fs.writeFileSync(CONFIG_PATH, JSON.stringify(obj, null, 2));
        console.log('💾 Config saved:', autoPostDB.size, 'entries');
    } catch (e) {
        console.error('❌ Config save error:', e.message);
    }
}

// ===================== VALIDATION =====================
function validateChannels(channelsStr) {
    const ids = channelsStr.split(',').map(id => id.trim());
    if (ids.length < 1 || ids.length > 10) {
        throw new Error('Minimal 1 dan maksimal 10 channel target');
    }
    for (const id of ids) {
        if (!/^\d{17,20}$/.test(id)) {
            throw new Error(`Invalid channel ID: ${id}`);
        }
    }
    return ids;
}

// ===================== CHANNEL INFO =====================
async function getChannelInfo(channelId) {
    try {
        if (!clientInstance) {
            return { serverName: 'Unknown', channelName: 'Unknown', serverId: null, channelLink: null };
        }
        
        const channel = await clientInstance.channels.fetch(channelId);
        if (!channel) {
            return { serverName: 'Unknown', channelName: 'Unknown', serverId: null, channelLink: null };
        }
        
        const guild = channel.guild;
        const serverName = guild ? guild.name : 'DM';
        const serverId = guild ? guild.id : null;
        const channelName = channel.name || 'Unknown';
        const channelLink = guild ? `https://discord.com/channels/${guild.id}/${channel.id}` : null;
        
        return { serverName, channelName, serverId, channelLink };
    } catch (error) {
        return { serverName: 'Unknown', channelName: 'Unknown', serverId: null, channelLink: null };
    }
}

// ===================== SUBCOMMANDS HANDLER =====================
async function handleAutopostSubcommands(interaction, subcommand) {
    const userId = interaction.user.id;
    const guildId = interaction.guildId;

    switch (subcommand) {
        case 'create': {
            const name = interaction.options.getString('name');
            const token = interaction.options.getString('token');
            const channels = interaction.options.getString('channels');
            const message = interaction.options.getString('message');
            const delay = interaction.options.getInteger('delay');
            const logChannel = interaction.options.getString('log_channel') || null;

            const channelIds = validateChannels(channels);
            
            let duplicateFound = false;
            for (const [key, data] of autoPostDB) {
                if (data.name === name && data.guildId === guildId) {
                    duplicateFound = true;
                    break;
                }
            }
            
            if (duplicateFound) {
                throw new Error(`Autopost dengan nama "${name}" sudah ada`);
            }

            const configId = `${guildId}_${userId}_${name}`;
            autoPostDB.set(configId, {
                name: name,
                guildId: guildId,
                userId: userId,
                token: token,
                targets: channelIds,
                message: message,
                delay: delay,
                logChannel: logChannel,
                lastSent: 0,
                active: true,
                createdAt: new Date().toISOString(),
                totalSent: 0,
                totalFailed: 0,
                lastError: null
            });
            saveConfig();

            const embed = new EmbedBuilder()
                .setColor(0x00ff00)
                .setTitle('✅ AzesZ AutoPost — Created')
                .addFields(
                    { name: '📌 Name', value: name, inline: true },
                    { name: '🎯 Targets', value: `${channelIds.length} channel`, inline: true },
                    { name: '⏱️ Delay', value: `${delay}s`, inline: true },
                    { name: '📝 Message', value: message.substring(0, 100) + (message.length > 100 ? '...' : '') },
                    { name: 'Status', value: '🟢 Active' }
                )
                .setTimestamp();

            await interaction.reply({ embeds: [embed], ephemeral: true });
            break;
        }

        case 'edit': {
            const name = interaction.options.getString('name');
            const newMessage = interaction.options.getString('new_message');
            const newDelay = interaction.options.getInteger('new_delay');
            const addChannels = interaction.options.getString('add_channels');
            const removeChannels = interaction.options.getString('remove_channels');

            let targetConfig = null;
            let configId = null;

            for (const [key, data] of autoPostDB) {
                if (data.name === name && data.guildId === guildId) {
                    targetConfig = data;
                    configId = key;
                    break;
                }
            }

            if (!targetConfig) {
                throw new Error(`Autopost "${name}" tidak ditemukan`);
            }

            if (newMessage) targetConfig.message = newMessage;
            if (newDelay) targetConfig.delay = newDelay;

            if (addChannels) {
                const newIds = validateChannels(addChannels);
                const currentSet = new Set(targetConfig.targets);
                for (const id of newIds) {
                    if (!currentSet.has(id)) {
                        currentSet.add(id);
                    }
                }
                if (currentSet.size > 10) {
                    throw new Error('Total channel maksimal 10');
                }
                targetConfig.targets = Array.from(currentSet);
            }

            if (removeChannels) {
                const removeIds = removeChannels.split(',').map(id => id.trim());
                const currentSet = new Set(targetConfig.targets);
                for (const id of removeIds) {
                    currentSet.delete(id);
                }
                if (currentSet.size < 1) {
                    throw new Error('Minimal 1 channel target');
                }
                targetConfig.targets = Array.from(currentSet);
            }

            saveConfig();

            const embed = new EmbedBuilder()
                .setColor(0x00aaff)
                .setTitle('✏️ AzesZ AutoPost — Updated')
                .addFields(
                    { name: '📌 Name', value: name, inline: true },
                    { name: '🎯 Targets', value: `${targetConfig.targets.length} channel`, inline: true },
                    { name: '⏱️ Delay', value: `${targetConfig.delay}s`, inline: true },
                    { name: '📝 Message', value: targetConfig.message.substring(0, 100) + (targetConfig.message.length > 100 ? '...' : '') }
                )
                .setTimestamp();

            await interaction.reply({ embeds: [embed], ephemeral: true });
            break;
        }

        case 'list': {
            const configs = [];
            for (const [key, data] of autoPostDB) {
                if (data.guildId === guildId) {
                    configs.push({
                        name: data.name,
                        userId: data.userId,
                        targets: data.targets.length,
                        delay: data.delay,
                        active: data.active,
                        totalSent: data.totalSent || 0,
                        totalFailed: data.totalFailed || 0,
                        lastError: data.lastError || null
                    });
                }
            }

            if (configs.length === 0) {
                return interaction.reply({ 
                    content: '📭 Belum ada autopost yang dikonfigurasi.', 
                    ephemeral: true 
                });
            }

            const embed = new EmbedBuilder()
                .setColor(0x0099ff)
                .setTitle('📋 AzesZ AutoPost — List')
                .setDescription(`Total: ${configs.length} autopost`)
                .setTimestamp();

            for (const config of configs) {
                const statusText = config.active ? '🟢 Active' : '🔴 Inactive';
                const errorText = config.lastError ? `\n⚠️ Error: ${config.lastError.substring(0, 50)}` : '';
                embed.addFields({
                    name: `📌 ${config.name}`,
                    value: `🎯 Targets: ${config.targets}\n⏱️ Delay: ${config.delay}s\n📊 Status: ${statusText}\n📈 Sent: ${config.totalSent} | Failed: ${config.totalFailed}${errorText}`,
                    inline: false
                });
            }

            await interaction.reply({ embeds: [embed], ephemeral: true });
            break;
        }

        case 'delete': {
            const name = interaction.options.getString('name');
            let configId = null;

            for (const [key, data] of autoPostDB) {
                if (data.name === name && data.guildId === guildId) {
                    configId = key;
                    break;
                }
            }

            if (!configId) {
                throw new Error(`Autopost "${name}" tidak ditemukan`);
            }

            autoPostDB.delete(configId);
            saveConfig();

            await interaction.reply({ 
                content: `✅ AzesZ AutoPost "${name}" berhasil dihapus.`, 
                ephemeral: true 
            });
            break;
        }

        case 'toggle': {
            const name = interaction.options.getString('name');
            const status = interaction.options.getBoolean('status');

            let targetConfig = null;
            let configId = null;

            for (const [key, data] of autoPostDB) {
                if (data.name === name && data.guildId === guildId) {
                    targetConfig = data;
                    configId = key;
                    break;
                }
            }

            if (!targetConfig) {
                throw new Error(`Autopost "${name}" tidak ditemukan`);
            }

            targetConfig.active = status;
            saveConfig();

            await interaction.reply({ 
                content: `✅ AzesZ AutoPost "${name}" ${status ? 'diaktifkan' : 'dinonaktifkan'}.`, 
                ephemeral: true 
            });
            break;
        }
    }
}

// ===================== AUTOCOMPLETE =====================
async function handleAutopostAutocomplete(interaction) {
    const focusedValue = interaction.options.getFocused();
    const guildId = interaction.guildId;
    const choices = [];

    for (const [key, data] of autoPostDB) {
        if (data.guildId === guildId) {
            if (data.name.toLowerCase().includes(focusedValue.toLowerCase())) {
                choices.push(data.name);
            }
        }
    }

    await interaction.respond(
        choices.slice(0, 25).map(choice => ({ name: choice, value: choice }))
    );
}

// ===================== SEND MESSAGE =====================
async function sendMessageWithRetry(token, target, message, retries = 3) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 20000);

    for (let attempt = 1; attempt <= retries; attempt++) {
        try {
            const response = await fetch(`https://discord.com/api/v9/channels/${target}/messages`, {
                method: 'POST',
                headers: { 
                    'Authorization': token, 
                    'Content-Type': 'application/json',
                    'User-Agent': 'Mozilla/5.0 (compatible; DiscordBot/1.0)'
                },
                body: JSON.stringify({ content: message }),
                signal: controller.signal
            });

            clearTimeout(timeout);

            if (response.status === 429) {
                const retryAfter = parseInt(response.headers.get('retry-after') || '5');
                await new Promise(resolve => setTimeout(resolve, retryAfter * 1000));
                continue;
            }

            if (response.status === 401) {
                return { success: false, error: '❌ Token tidak valid atau expired' };
            }

            if (response.status === 403) {
                return { success: false, error: '❌ Tidak memiliki akses ke channel ini' };
            }

            if (response.status === 404) {
                return { success: false, error: '❌ Channel tidak ditemukan' };
            }

            if (!response.ok) {
                const errorText = await response.text();
                let errorMsg = `HTTP ${response.status}`;
                try {
                    const json = JSON.parse(errorText);
                    errorMsg = json.message || errorMsg;
                } catch (e) {}
                throw new Error(errorMsg);
            }

            const responseData = await response.json();
            return { success: true, status: response.status, messageId: responseData.id };
        } catch (error) {
            if (attempt === retries) {
                return { success: false, error: error.message };
            }
            await new Promise(resolve => setTimeout(resolve, 2000 * attempt));
        }
    }
    return { success: false, error: 'Max retries exceeded' };
}

// ===================== ENGINE — 24/7 =====================
function startAutopostEngine(logChannelId, client) {
    console.log('🔁 Starting AzesZ AutoPost Engine 24/7...');
    
    if (!client) {
        console.error('❌ Client is undefined!');
        return;
    }

    clientInstance = client;
    
    if (engineInterval) {
        clearInterval(engineInterval);
        engineInterval = null;
        console.log('🔄 Old engine stopped');
    }

    isEngineRunning = true;
    isProcessing = false;
    console.log('✅ AzesZ AutoPost Engine 24/7 started successfully');

    // ===== ENGINE LOOP — CHECK EVERY 5 SECONDS =====
    engineInterval = setInterval(async () => {
        // Skip if already processing
        if (isProcessing) {
            return;
        }

        try {
            if (!isEngineRunning) {
                console.log('⏹️ Engine stopped by flag');
                clearInterval(engineInterval);
                engineInterval = null;
                return;
            }

            isProcessing = true;
            const now = Date.now();
            let processedAny = false;

            // ===== LOOP THROUGH ALL CONFIGS =====
            for (const [configId, data] of autoPostDB) {
                try {
                    // Skip inactive configs
                    if (!data.active) {
                        continue;
                    }

                    // ===== CALCULATE TIME SINCE LAST SEND =====
                    const lastSent = data.lastSent || 0;
                    const delayMs = (data.delay || 10) * 1000;
                    const timeSinceLastSend = now - lastSent;

                    // ===== CHECK IF IT'S TIME TO SEND =====
                    if (timeSinceLastSend >= delayMs) {
                        processedAny = true;
                        console.log(`📤 Processing: ${data.name} (${configId}) | Time since last: ${Math.round(timeSinceLastSend/1000)}s / ${data.delay}s`);
                        
                        const targets = data.targets || [];
                        let successCount = 0;
                        let failCount = 0;
                        const channelDetails = [];

                        // ===== SEND TO EACH TARGET =====
                        for (const target of targets) {
                            try {
                                const channelInfo = await getChannelInfo(target);
                                const result = await sendMessageWithRetry(data.token, target, data.message);
                                
                                if (result.success) {
                                    data.totalSent = (data.totalSent || 0) + 1;
                                    successCount++;
                                    data.lastError = null;
                                    console.log(`✅ Sent to ${target}`);
                                } else {
                                    data.totalFailed = (data.totalFailed || 0) + 1;
                                    failCount++;
                                    data.lastError = result.error;
                                    console.log(`❌ Failed to ${target}: ${result.error}`);
                                }

                                // ===== UPDATE LAST SENT TIME =====
                                data.lastSent = Date.now(); // Use current time
                                data.lastAttempt = new Date().toISOString();
                                data.status = result.success ? 'success' : 'failed';
                                
                                // ===== SAVE CONFIG AFTER EACH TARGET =====
                                saveConfig();

                                channelDetails.push({
                                    id: target,
                                    serverName: channelInfo.serverName,
                                    channelName: channelInfo.channelName,
                                    serverId: channelInfo.serverId,
                                    channelLink: channelInfo.channelLink,
                                    success: result.success,
                                    error: result.error
                                });

                                // Delay antar target
                                await new Promise(resolve => setTimeout(resolve, 1500));
                            } catch (targetError) {
                                console.error(`❌ Target error ${target}:`, targetError.message);
                                failCount++;
                                data.totalFailed = (data.totalFailed || 0) + 1;
                                data.lastError = targetError.message;
                                saveConfig();
                            }
                        }

                        // ===== BUILD LOGS =====
                        const totalSuccess = successCount;
                        const totalFailed = failCount;

                        const embed = new EmbedBuilder()
                            .setColor(totalFailed === 0 ? 0x00ff00 : (totalSuccess > 0 ? 0xffa500 : 0xff0000))
                            .setTitle(totalFailed === 0 ? '✅ AzesZ AutoPost — Success' : '⚠️ AzesZ AutoPost — Failed')
                            .setDescription(totalFailed === 0 ? '✔ **TERKIRIM**' : '❌ **GAGAL TERKIRIM**')
                            .addFields(
                                { 
                                    name: '📌 Akun Post', 
                                    value: `**${data.name || 'Unnamed'}**\nID: \`${configId}\``, 
                                    inline: false 
                                },
                                { 
                                    name: '🎯 Channel', 
                                    value: `**${totalSuccess}** channel dikirim ${totalFailed > 0 ? `\n❌ **${totalFailed}** channel gagal` : ''}`, 
                                    inline: false 
                                },
                                { 
                                    name: '⏰ Waktu', 
                                    value: `<t:${Math.floor(Date.now() / 1000)}:F>`, 
                                    inline: false 
                                }
                            )
                            .addFields({
                                name: '📊 Statistik Akun Post',
                                value: `Akun : **${data.name || 'Unnamed'}**\n✅ Sukses : ${data.totalSent} ❌ Gagal : ${data.totalFailed}\n📈 Rate : ${data.totalSent + data.totalFailed > 0 ? Math.round((data.totalSent / (data.totalSent + data.totalFailed)) * 100) : 0}%`,
                                inline: false
                            });

                        // ===== DETAIL CHANNEL =====
                        let detailText = '';
                        for (const detail of channelDetails) {
                            const icon = detail.success ? '✅' : '❌';
                            const serverDisplay = detail.serverName !== 'Unknown' ? detail.serverName : '#unknown';
                            const channelDisplay = detail.channelName !== 'Unknown' ? detail.channelName : 'Unknown Channel';
                            const urlDisplay = detail.channelLink ? `[${detail.channelLink}](${detail.channelLink})` : 'No link';
                            const errorDisplay = detail.error ? `\n└─ ⚠️ ${detail.error}` : '';
                            detailText += `${icon} **${serverDisplay}** > #${channelDisplay}\n└─ ${urlDisplay}${errorDisplay}\n`;
                        }

                        if (detailText.length > 0) {
                            embed.addFields({
                                name: '📋 Detail Channel',
                                value: detailText.substring(0, 1024),
                                inline: false
                            });
                        }

                        embed.setFooter({ text: `AzesZ AutoPost · Auto Scheduler | ${new Date().toLocaleString()}` });

                        // ===== SEND LOGS =====
                        try {
                            const logCh = await client.channels.fetch(logChannelId);
                            if (logCh) {
                                await logCh.send({ embeds: [embed] });
                            }
                        } catch (logError) {
                            console.error('Log channel error:', logError.message);
                        }

                        if (data.logChannel) {
                            try {
                                const customLog = await client.channels.fetch(data.logChannel);
                                if (customLog) {
                                    await customLog.send({ embeds: [embed] });
                                }
                            } catch (e) {
                                console.error('Custom log error:', e.message);
                            }
                        }

                        console.log(`✅ Completed: ${data.name} | Next send in ${data.delay}s`);
                    }
                } catch (configError) {
                    console.error(`❌ Error processing ${configId}:`, configError.message);
                }
            }

            // ===== HEARTBEAT LOG (every 60 seconds only) =====
            if (!processedAny) {
                // Silent mode - health check handles this
            }

        } catch (error) {
            console.error('❌ Engine loop error:', error.message);
            console.error(error.stack);
        } finally {
            isProcessing = false;
        }
    }, 5000); // Check every 5 seconds

    console.log('🔁 Engine interval ID:', engineInterval);
}

// ===================== STOP ENGINE =====================
function stopEngine() {
    isEngineRunning = false;
    isProcessing = false;
    if (engineInterval) {
        clearInterval(engineInterval);
        engineInterval = null;
        console.log('⏹️ Engine stopped');
        return true;
    }
    return false;
}

function stopAutopost(userId) {
    if (autoPostDB.has(userId)) {
        const data = autoPostDB.get(userId);
        data.active = false;
        saveConfig();
        return true;
    }
    return false;
}

function removeAutopost(userId) {
    const removed = autoPostDB.delete(userId);
    if (removed) saveConfig();
    return removed;
}

// ===================== LOAD CONFIG =====================
loadConfig();

// ===================== EXPORT =====================
module.exports = { 
    handleAutopostSubcommands,
    handleAutopostAutocomplete,
    startAutopostEngine,
    stopEngine,
    autoPostDB,
    stopAutopost,
    removeAutopost,
    saveConfig,
    loadConfig,
    validateChannels
};

console.log('✅ AzesZ AutoPost — autopostHandle.js loaded successfully');
console.log('📤 Exported functions:', Object.keys(module.exports).join(', '));
    

