const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { handleAutopostSubcommands, handleAutopostAutocomplete } = require('../../autopostHandle');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('autopostpanel')
        .setDescription('📡 Panel konfigurasi autopost')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
        .addSubcommand(sub => sub
            .setName('create')
            .setDescription('Buat konfigurasi autopost baru')
            .addStringOption(opt => opt
                .setName('name')
                .setDescription('Nama unik untuk autopost')
                .setRequired(true)
                .setMaxLength(30)
                .setMinLength(3)
            )
            .addStringOption(opt => opt
                .setName('token')
                .setDescription('User Token untuk autopost')
                .setRequired(true)
            )
            .addStringOption(opt => opt
                .setName('channels')
                .setDescription('ID channel target (pisahkan dengan koma, max 10)')
                .setRequired(true)
            )
            .addStringOption(opt => opt
                .setName('message')
                .setDescription('Pesan yang akan dikirim')
                .setRequired(true)
                .setMaxLength(2000)
            )
            .addIntegerOption(opt => opt
                .setName('delay')
                .setDescription('Delay dalam detik (min 5)')
                .setRequired(true)
                .setMinValue(5)
                .setMaxValue(3600)
            )
            .addStringOption(opt => opt
                .setName('log_channel')
                .setDescription('ID channel log (opsional)')
                .setRequired(false)
            )
        )
        .addSubcommand(sub => sub
            .setName('edit')
            .setDescription('Edit konfigurasi autopost yang sudah ada')
            .addStringOption(opt => opt
                .setName('name')
                .setDescription('Nama autopost yang akan diedit')
                .setRequired(true)
                .setAutocomplete(true) // ===== AUTOCOMPLETE ACTIVE =====
            )
            .addStringOption(opt => opt
                .setName('new_message')
                .setDescription('Pesan baru')
                .setRequired(false)
                .setMaxLength(2000)
            )
            .addIntegerOption(opt => opt
                .setName('new_delay')
                .setDescription('Delay baru dalam detik (min 5)')
                .setRequired(false)
                .setMinValue(5)
                .setMaxValue(3600)
            )
            .addStringOption(opt => opt
                .setName('add_channels')
                .setDescription('Tambah channel target (pisahkan dengan koma)')
                .setRequired(false)
            )
            .addStringOption(opt => opt
                .setName('remove_channels')
                .setDescription('Hapus channel target (pisahkan dengan koma)')
                .setRequired(false)
            )
        )
        .addSubcommand(sub => sub
            .setName('list')
            .setDescription('Lihat daftar semua autopost')
        )
        .addSubcommand(sub => sub
            .setName('delete')
            .setDescription('Hapus konfigurasi autopost')
            .addStringOption(opt => opt
                .setName('name')
                .setDescription('Nama autopost yang akan dihapus')
                .setRequired(true)
                .setAutocomplete(true) // ===== AUTOCOMPLETE ACTIVE =====
            )
        )
        .addSubcommand(sub => sub
            .setName('toggle')
            .setDescription('Aktifkan/nonaktifkan autopost')
            .addStringOption(opt => opt
                .setName('name')
                .setDescription('Nama autopost')
                .setRequired(true)
                .setAutocomplete(true) // ===== AUTOCOMPLETE ACTIVE =====
            )
            .addBooleanOption(opt => opt
                .setName('status')
                .setDescription('True = aktif, False = nonaktif')
                .setRequired(true)
            )
        ),
    
    async autocomplete(interaction) {
        await handleAutopostAutocomplete(interaction);
    },
    
    async execute(interaction) {
        // Check permission
        if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
            return interaction.reply({ 
                content: '❌ Hanya **Administrator** yang dapat menggunakan command ini.', 
                ephemeral: true 
            });
        }

        const subcommand = interaction.options.getSubcommand();
        
        try {
            await handleAutopostSubcommands(interaction, subcommand);
        } catch (error) {
            console.error('Error in autopost subcommand:', error);
            if (!interaction.replied) {
                await interaction.reply({ 
                    content: `❌ Error: ${error.message}`, 
                    ephemeral: true 
                });
            }
        }
    }
};

