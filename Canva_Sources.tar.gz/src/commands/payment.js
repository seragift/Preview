const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { paymentEmbed } = require('../utils/embeds');
const { loadConfig } = require('../utils/config');

module.exports = {
  data: new SlashCommandBuilder().setName('payment').setDescription('Lihat metode pembayaran yang tersedia'),

  async execute(interaction) {
    const config = loadConfig();
    const row = new ActionRowBuilder();

    config.payment.slice(0, 5).forEach((method, index) => {
      row.addComponents(
        new ButtonBuilder().setCustomId(`payment_${index}`).setLabel(method.name).setStyle(ButtonStyle.Secondary)
      );
    });

    await interaction.reply({ embeds: [paymentEmbed()], components: [row] });
  },
};
