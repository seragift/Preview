const { SlashCommandBuilder } = require('discord.js');
const db = require('../utils/database');
const { statusEmbed } = require('../utils/embeds');
const { loadConfig } = require('../utils/config');

function ensureRow() {
  const row = db.prepare('SELECT * FROM shop_status WHERE id = 1').get();
  if (!row) {
    db.prepare('INSERT INTO shop_status (id, status, updated_by, updated_at) VALUES (1, ?, NULL, ?)').run(
      'close',
      Date.now()
    );
  }
}

function getStatus() {
  ensureRow();
  return db.prepare('SELECT * FROM shop_status WHERE id = 1').get();
}

function setStatus(status, userId) {
  ensureRow();
  db.prepare('UPDATE shop_status SET status = ?, updated_by = ?, updated_at = ? WHERE id = 1').run(
    status,
    userId,
    Date.now()
  );
}

function getCustom() {
  db.exec(
    'CREATE TABLE IF NOT EXISTS status_custom (id INTEGER PRIMARY KEY CHECK (id = 1), title TEXT, description TEXT, tag TEXT, image_url TEXT)'
  );
  return db.prepare('SELECT * FROM status_custom WHERE id = 1').get() || {};
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('status')
    .setDescription('Lihat atau ubah status toko')
    .addSubcommand((sub) => sub.setName('view').setDescription('Lihat status toko saat ini'))
    .addSubcommand((sub) =>
      sub
        .setName('set')
        .setDescription('Ubah status toko (admin only)')
        .addStringOption((opt) =>
          opt
            .setName('kondisi')
            .setDescription('open atau close')
            .setRequired(true)
            .addChoices({ name: 'Open', value: 'open' }, { name: 'Close', value: 'close' })
        )
    ),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();

    if (sub === 'view') {
      const row = getStatus();
      return interaction.reply({ embeds: [statusEmbed(row.status, row.updated_by, row.updated_at, getCustom())] });
    }

    if (sub === 'set') {
      const config = loadConfig();
      if (config.roles.admin && !interaction.member.roles.cache.has(config.roles.admin)) {
        return interaction.reply({ content: 'Kamu tidak punya izin untuk mengubah status toko.', ephemeral: true });
      }

      const kondisi = interaction.options.getString('kondisi');
      setStatus(kondisi, interaction.user.id);
      const row = getStatus();
      const custom = getCustom();

      return interaction.reply({
        content: custom.tag ? `<@&${custom.tag}>` : undefined,
        embeds: [statusEmbed(row.status, row.updated_by, row.updated_at, custom)],
      });
    }
  },
};
