/*
  samp.yar
  Fokus pada file/modifikasi SA-MP (Lua/MoonLoader/CLEO/pawn). Tidak menganggap
  seluruh MoonLoader/CLEO/plugin sebagai malware — yang dicari adalah KOMBINASI
  perilaku SA-MP script dengan credential collection / network eksternal mencurigakan.
*/

rule SAMP_Script_With_Credential_Access
{
    meta:
        description = "Script SA-MP/MoonLoader yang mengakses credential/config game dan mengirim ke luar"
        category = "samp"
        severity = "high"

    strings:
        $samp1 = "samp.get" ascii wide nocase
        $samp2 = "sampGetCurrentServerAddress" ascii wide
        $samp3 = "moonloader" nocase ascii wide
        $samp4 = "lua_State" ascii wide

        $cred1 = "password" nocase ascii wide
        $cred2 = "login" nocase ascii wide
        $cred3 = "gta_sa.exe" nocase ascii wide

        $net1 = "requests.post" ascii wide
        $net2 = "http.post" nocase ascii wide
        $net3 = "discord.com/api/webhooks" ascii wide nocase

    condition:
        (any of ($samp*)) and (any of ($cred*)) and (any of ($net*))
}

rule CLEO_Plugin_Network_Exfil_Combo
{
    meta:
        description = "CLEO/mod script dengan kombinasi file access dan network access tak wajar"
        category = "samp"
        severity = "medium"

    strings:
        $cleo1 = "CLEO" ascii wide
        $cleo2 = ".cs" ascii wide
        $cleo3 = "opcode" nocase ascii wide

        $file1 = "ReadFile" ascii wide
        $file2 = "io.open" ascii wide
        $file3 = "GetPrivateProfileString" ascii wide

        $net1 = "InternetOpen" ascii wide
        $net2 = "WinHttpOpen" ascii wide
        $net3 = "socket.connect" ascii wide

    condition:
        (any of ($cleo*)) and (any of ($file*)) and (any of ($net*))
}

rule Pawn_AMX_Suspicious_External_Communication
{
    meta:
        description = "Script pawn/amx SA-MP dengan pola komunikasi eksternal mencurigakan"
        category = "samp"
        severity = "medium"

    strings:
        $pawn1 = "#include <a_samp>" ascii wide
        $pawn2 = "OnPlayerConnect" ascii wide
        $pawn3 = "SendRconCommand" ascii wide

        $net1 = "HTTP_Get" ascii wide nocase
        $net2 = "curl" nocase ascii wide
        $net3 = "webhook" nocase ascii wide

    condition:
        (any of ($pawn*)) and (any of ($net*))
}
