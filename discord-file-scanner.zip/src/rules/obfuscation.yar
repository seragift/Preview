/*
  obfuscation.yar
  Deteksi indikasi obfuscation/encoded payload/dynamic execution.
  High entropy sendiri tidak otomatis berarti malware — rule ini fokus pada
  kombinasi obfuscation dengan eksekusi dinamis atau payload tersembunyi.
*/

rule Dynamic_Code_Execution_With_Encoded_Payload
{
    meta:
        description = "Kombinasi eval-like execution dengan payload berenkode (base64/hex)"
        category = "obfuscation"
        severity = "medium"

    strings:
        $exec1 = "eval(" ascii wide
        $exec2 = "exec(" ascii wide
        $exec3 = "Function(" ascii wide
        $exec4 = "Invoke-Expression" nocase ascii wide
        $exec5 = "IEX(" nocase ascii wide
        $exec6 = "loadstring(" ascii wide

        $encoded1 = "base64" nocase ascii wide
        $encoded2 = "FromBase64String" ascii wide
        $encoded3 = /[A-Za-z0-9+\/]{80,}={0,2}/ ascii wide

    condition:
        (any of ($exec*)) and (any of ($encoded1, $encoded2, $encoded3))
}

rule Excessive_String_Concatenation_Obfuscation
{
    meta:
        description = "Pola concatenation string berlebihan yang umum pada obfuscated payload"
        category = "obfuscation"
        severity = "low"

    strings:
        $concat1 = /(\"[A-Za-z0-9]{1,3}\"\s*\+\s*){10,}/ ascii wide
        $concat2 = /(chr\(\d+\)\s*[.+]\s*){10,}/ ascii wide nocase

    condition:
        any of them
}

rule Compressed_Payload_Runtime_Decompress
{
    meta:
        description = "Payload terkompresi yang di-decompress saat runtime lalu dieksekusi"
        category = "obfuscation"
        severity = "medium"

    strings:
        $decomp1 = "zlib.decompress" ascii wide
        $decomp2 = "gzip.decompress" ascii wide
        $decomp3 = "System.IO.Compression.GZipStream" ascii wide
        $decomp4 = "MemoryStream" ascii wide

        $exec1 = "exec(" ascii wide
        $exec2 = "eval(" ascii wide
        $exec3 = "Assembly.Load" ascii wide

    condition:
        (any of ($decomp*)) and (any of ($exec*))
}
