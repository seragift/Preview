/*
  keylogger.yar
  Fokus: kombinasi input capture + penyimpanan/pengiriman hasil capture,
  bukan sekadar string "keylogger".
*/

rule Keyboard_Hook_Windows_API_Combo
{
    meta:
        description = "Kombinasi Windows keyboard hook API dengan penyimpanan/pengiriman hasil"
        category = "keylogger"
        severity = "high"

    strings:
        $hook1 = "SetWindowsHookExA" ascii wide
        $hook2 = "SetWindowsHookExW" ascii wide
        $hook3 = "GetAsyncKeyState" ascii wide
        $hook4 = "GetKeyboardState" ascii wide
        $hook5 = "WH_KEYBOARD_LL" ascii wide

        $store1 = "keys.log" nocase ascii wide
        $store2 = "keystrokes" nocase ascii wide
        $store3 = "logfile" nocase ascii wide

        $send1 = "sendmessage" nocase ascii wide
        $send2 = "http.post" nocase ascii wide
        $send3 = "webhook" nocase ascii wide

    condition:
        (any of ($hook*)) and ((any of ($store*)) or (any of ($send*)))
}

rule JS_Keyboard_Event_Exfil_Combo
{
    meta:
        description = "Kombinasi event listener keyboard JS dengan pengiriman data ke endpoint eksternal"
        category = "keylogger"
        severity = "high"

    strings:
        $evt1 = "addEventListener(\"keydown\"" ascii wide
        $evt2 = "addEventListener('keydown'" ascii wide
        $evt3 = "onkeydown" ascii wide nocase
        $evt4 = "onkeypress" ascii wide nocase
        $evt5 = "event.key" ascii wide

        $net1 = "fetch(" ascii wide
        $net2 = "XMLHttpRequest" ascii wide
        $net3 = "navigator.sendBeacon" ascii wide

    condition:
        (any of ($evt*)) and (any of ($net*))
}

rule Input_Capture_Buffer_Pattern
{
    meta:
        description = "Pola akumulasi buffer keystroke sebelum dikirim ke remote endpoint"
        category = "keylogger"
        severity = "medium"

    strings:
        $buf1 = "keybuffer" nocase ascii wide
        $buf2 = "key_buffer" nocase ascii wide
        $buf3 = "capturedKeys" nocase ascii wide
        $flush1 = "setInterval" ascii wide
        $flush2 = "setTimeout" ascii wide
        $net1 = "http" nocase ascii wide

    condition:
        (any of ($buf*)) and (any of ($flush*)) and $net1
}
