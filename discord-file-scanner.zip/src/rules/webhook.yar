/*
  webhook.yar
  Membedakan antara sekadar URL webhook vs kombinasi pengumpulan data + pengiriman ke webhook.
*/

rule Discord_Webhook_URL_Present
{
    meta:
        description = "Terdapat URL Discord webhook di dalam file (severity rendah bila berdiri sendiri)"
        category = "webhook"
        severity = "low"

    strings:
        $wh1 = /discord(?:app)?\.com\/api\/webhooks\/\d+\/[A-Za-z0-9_-]+/ ascii wide

    condition:
        $wh1
}

rule Webhook_Data_Exfiltration_Combo
{
    meta:
        description = "Kombinasi URL webhook dengan pengumpulan data sistem/credential sebelum dikirim"
        category = "webhook"
        severity = "high"

    strings:
        $wh1 = /discord(?:app)?\.com\/api\/webhooks\/\d+\/[A-Za-z0-9_-]+/ ascii wide

        $collect1 = "os.environ" ascii wide
        $collect2 = "GetSystemInfo" ascii wide
        $collect3 = "socket.gethostname" ascii wide
        $collect4 = "username" nocase ascii wide
        $collect5 = "ipapi.co" ascii wide
        $collect6 = "get-ip" nocase ascii wide

        $send1 = "requests.post" ascii wide
        $send2 = "http.post" nocase ascii wide
        $send3 = "multipart/form-data" ascii wide
        $send4 = "content: {" ascii wide

    condition:
        $wh1 and (any of ($collect*)) and (any of ($send*))
}

rule Webhook_POST_Payload_Pattern
{
    meta:
        description = "Pola pengiriman payload JSON/embed ke webhook (indikasi exfiltration terstruktur)"
        category = "webhook"
        severity = "medium"

    strings:
        $wh1 = /discord(?:app)?\.com\/api\/webhooks\/\d+\/[A-Za-z0-9_-]+/ ascii wide
        $payload1 = "\"embeds\"" ascii wide
        $payload2 = "\"content\"" ascii wide
        $payload3 = "application/json" ascii wide

    condition:
        $wh1 and 2 of ($payload*)
}
