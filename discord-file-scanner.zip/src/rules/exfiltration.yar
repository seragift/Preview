/*
  exfiltration.yar
  Fokus: kombinasi data collection + encoding/serialization + network request,
  atau credential collection + HTTP POST.
*/

rule Data_Collection_Encoding_Network_Combo
{
    meta:
        description = "Kombinasi pengumpulan data lokal, encoding/serialization, dan pengiriman jaringan"
        category = "exfiltration"
        severity = "high"

    strings:
        $collect1 = "readFileSync" ascii wide
        $collect2 = "glob.glob" ascii wide
        $collect3 = "os.walk" ascii wide
        $collect4 = "Directory.GetFiles" ascii wide
        $collect5 = "documents" nocase ascii wide

        $encode1 = "base64" nocase ascii wide
        $encode2 = "json.dumps" ascii wide
        $encode3 = "JSON.stringify" ascii wide
        $encode4 = "zlib" nocase ascii wide

        $net1 = "requests.post" ascii wide
        $net2 = "http.post" nocase ascii wide
        $net3 = "socket.connect" ascii wide
        $net4 = "ftp" nocase ascii wide

    condition:
        (any of ($collect*)) and (any of ($encode*)) and (any of ($net*))
}

rule Credential_Collection_HTTP_POST_Combo
{
    meta:
        description = "Kombinasi credential collection dengan HTTP POST ke endpoint eksternal"
        category = "exfiltration"
        severity = "high"

    strings:
        $cred1 = "password" nocase ascii wide
        $cred2 = "credential" nocase ascii wide
        $cred3 = "Login Data" ascii wide
        $cred4 = "token" nocase ascii wide

        $post1 = "requests.post" ascii wide
        $post2 = "urllib.request" ascii wide
        $post3 = "HttpWebRequest" ascii wide
        $post4 = "curl -X POST" nocase ascii wide

    condition:
        (any of ($cred*)) and (any of ($post*))
}

rule Archive_Then_Send_Pattern
{
    meta:
        description = "Pola kompresi hasil kumpulan data sebelum dikirim (umum pada stealer)"
        category = "exfiltration"
        severity = "medium"

    strings:
        $zip1 = "zipfile" nocase ascii wide
        $zip2 = "shutil.make_archive" ascii wide
        $zip3 = "System.IO.Compression" ascii wide
        $send1 = "upload" nocase ascii wide
        $send2 = "http.post" nocase ascii wide
        $send3 = "ftp" nocase ascii wide

    condition:
        (any of ($zip*)) and (any of ($send*))
}
