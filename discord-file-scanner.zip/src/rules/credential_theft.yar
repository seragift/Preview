/*
  credential_theft.yar
  Fokus: kombinasi pola yang menunjukkan pengumpulan credential/login information,
  bukan sekadar satu keyword umum. Dirancang agar false positive rendah.
*/

rule Credential_Access_Pattern_Combo
{
    meta:
        description = "Kombinasi akses path browser/credential store dengan pembacaan data login"
        category = "credential_theft"
        severity = "high"

    strings:
        $browser_path1 = "Login Data" ascii wide
        $browser_path2 = "\\Google\\Chrome\\User Data" ascii wide nocase
        $browser_path3 = "\\Mozilla\\Firefox\\Profiles" ascii wide nocase
        $browser_path4 = "AppData\\Local\\Google\\Chrome" ascii wide nocase
        $cred_store1 = "CredentialManager" ascii wide
        $cred_store2 = "vaultcli.dll" ascii wide nocase
        $decrypt1 = "CryptUnprotectData" ascii wide
        $decrypt2 = "DPAPI" ascii wide

    condition:
        (any of ($browser_path*) or any of ($cred_store*)) and any of ($decrypt*)
}

rule Discord_Token_Harvesting
{
    meta:
        description = "Pola pengambilan token Discord dari local storage / leveldb"
        category = "credential_theft"
        severity = "high"

    strings:
        $ld1 = "Local Storage\\leveldb" ascii wide nocase
        $ld2 = "discord\\Local Storage" ascii wide nocase
        $token1 = /mfa\.[a-zA-Z0-9_-]{80,}/ ascii wide
        $token2 = /[MN][a-zA-Z\d]{23}\.[a-zA-Z\d-_]{6}\.[a-zA-Z\d-_]{27,}/ ascii wide

    condition:
        (any of ($ld*)) and (any of ($token*))
}

rule Login_Form_Data_Collection
{
    meta:
        description = "Kombinasi field form login (username+password) dengan serialisasi/pengiriman data"
        category = "credential_theft"
        severity = "medium"

    strings:
        $field1 = "username" nocase ascii wide
        $field2 = "password" nocase ascii wide
        $field3 = "passwd" nocase ascii wide
        $collect1 = "FormData" ascii wide
        $collect2 = "getElementById" ascii wide
        $send1 = "XMLHttpRequest" ascii wide
        $send2 = "fetch(" ascii wide
        $send3 = "axios.post" ascii wide

    condition:
        (($field1 or $field3) and $field2) and (any of ($collect*)) and (any of ($send*))
}
