'use strict';

require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { REST, Routes } = require('discord.js');
const logger = require('./utils/logger');

async function main() {
  const token = process.env.DISCORD_TOKEN;
  if (!token) {
    throw new Error('DISCORD_TOKEN tidak ditemukan di .env');
  }

  const commands = [];
  const commandsDir = path.join(__dirname, 'commands');
  const files = fs.readdirSync(commandsDir).filter((f) => f.endsWith('.js'));

  for (const file of files) {
    const command = require(path.join(commandsDir, file));
    if (command?.data) {
      commands.push(command.data.toJSON());
    }
  }

  const rest = new REST().setToken(token);

  // Ambil application ID langsung dari token via REST (tidak butuh GUILD_ID / hardcoded ID).
  const app = await rest.get(Routes.oauth2CurrentApplication());
  const clientId = app.id;

  logger.info(`Mendaftarkan ${commands.length} global command untuk application ${clientId}...`);

  await rest.put(Routes.applicationCommands(clientId), { body: commands });

  logger.info('Global command berhasil didaftarkan. Perubahan dapat memakan waktu hingga 1 jam untuk tersebar ke seluruh server.');
}

main().catch((err) => {
  logger.error(`Gagal deploy command: ${err.message}`);
  process.exit(1);
});
