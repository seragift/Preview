'use strict';

const fs = require('fs');
const fsp = require('fs/promises');
const path = require('path');
const crypto = require('crypto');
const { randomUUID } = require('crypto');

const logger = require('../utils/logger');
const { cleanupDir } = require('../utils/cleanup');
const archive = require('./archive');
const strings = require('./strings');
const entropy = require('./entropy');
const yara = require('./yara');
const risk = require('./risk');

const TEMP_ROOT = path.join(__dirname, '..', 'temp');

let activeScanCount = 0;

function getActiveScanCount() {
  return activeScanCount;
}

async function sha256File(filePath) {
  return new Promise((resolve, reject) => {
    const hash = crypto.createHash('sha256');
    const stream = fs.createReadStream(filePath);
    stream.on('data', (chunk) => hash.update(chunk));
    stream.on('end', () => resolve(hash.digest('hex')));
    stream.on('error', reject);
  });
}

function withTimeout(promise, ms, message) {
  let timer;
  const timeout = new Promise((_, reject) => {
    timer = setTimeout(() => reject(new Error(message)), ms);
  });
  return Promise.race([promise, timeout]).finally(() => clearTimeout(timer));
}

/**
 * Melakukan static scan penuh terhadap satu file yang sudah didownload.
 *
 * @param {object} params
 * @param {string} params.filePath - path file asli (hasil download) di temp/<scan-id>/
 * @param {string} params.fileName - nama file asli
 * @param {object} params.config - config.json
 * @returns {Promise<object>} hasil scan terstruktur
 */
async function scanFile({ filePath, fileName, config }) {
  const scanId = randomUUID();
  const scanDir = path.join(TEMP_ROOT, scanId);

  if (activeScanCount >= config.maxConcurrentScans) {
    throw new Error('SCAN_QUEUE_FULL');
  }

  activeScanCount++;
  logger.scan(`Mulai scan (id=${scanId}) untuk file: ${fileName}`);

  try {
    const scanPromise = performScan({ filePath, fileName, scanDir, config, scanId });
    const timeoutMs = config.scanTimeoutSeconds * 1000;
    return await withTimeout(scanPromise, timeoutMs, 'SCAN_TIMEOUT');
  } finally {
    activeScanCount--;
    if (config.deleteTemporaryFiles) {
      await cleanupDir(scanDir);
    }
  }
}

async function performScan({ filePath, fileName, scanDir, config, scanId }) {
  fs.mkdirSync(scanDir, { recursive: true });

  const sha256 = await sha256File(filePath);
  logger.scan(`[${scanId}] SHA256 calculated: ${sha256}`);

  let filesToAnalyze = [filePath];

  if (archive.isArchiveFile(fileName)) {
    logger.scan(`[${scanId}] Extracting archive: ${fileName}`);
    try {
      const extractDir = path.join(scanDir, 'extracted');
      const totalFilesRef = { count: 0 };
      filesToAnalyze = await archive.extractRecursive(filePath, extractDir, config, 0, totalFilesRef);
      if (filesToAnalyze.length === 0) {
        filesToAnalyze = [filePath];
      }
    } catch (err) {
      logger.error(`[${scanId}] Gagal ekstraksi arsip: ${err.message}`);
      return {
        status: 'ERROR',
        errorReason: 'ARCHIVE_EXTRACT_FAILED',
        riskScore: 0,
        detections: [],
        filesScanned: 0,
        yaraMatches: [],
        suspiciousStrings: [],
        suspiciousUrls: [],
        highEntropyFiles: [],
        sha256
      };
    }
  }

  // Batasi jumlah file yang benar-benar dianalisis untuk menjaga performa
  const cappedFiles = filesToAnalyze.slice(0, config.maxArchiveFiles);

  const aggregate = {
    credentialIndicators: [],
    inputCaptureIndicators: [],
    networkIndicators: [],
    discordWebhooks: [],
    suspiciousUrls: [],
    base64LikeCount: 0,
    hexEncodedCount: 0,
    highEntropyFiles: [],
    yaraMatches: [],
    filesScanned: 0
  };

  for (const f of cappedFiles) {
    try {
      const stat = await fsp.stat(f);
      if (stat.size > config.maxFileSizeBytes) {
        continue; // lewati file individual yang terlalu besar
      }

      const strRes = await strings.analyzeFile(f);
      aggregate.credentialIndicators.push(...strRes.credentialIndicators);
      aggregate.inputCaptureIndicators.push(...strRes.inputCaptureIndicators);
      aggregate.networkIndicators.push(...strRes.networkIndicators);
      aggregate.discordWebhooks.push(...strRes.discordWebhooks);
      aggregate.suspiciousUrls.push(...strRes.suspiciousUrls);
      aggregate.base64LikeCount += strRes.base64LikeCount;
      aggregate.hexEncodedCount += strRes.hexEncodedCount;

      const entRes = await entropy.analyzeEntropy(f);
      if (entRes.isHighEntropy) {
        aggregate.highEntropyFiles.push({ file: path.basename(f), entropy: entRes.entropy });
      }

      if (config.enableYara) {
        const matches = await yara.runYara(f, config);
        if (matches.length > 0) {
          logger.yara(`[${scanId}] ${matches.length} match pada ${path.basename(f)}`);
        }
        aggregate.yaraMatches.push(...matches);
      }

      aggregate.filesScanned++;
    } catch (err) {
      logger.warn(`[${scanId}] Gagal menganalisis file ${f}: ${err.message}`);
    }
  }

  aggregate.credentialIndicators = [...new Set(aggregate.credentialIndicators)];
  aggregate.inputCaptureIndicators = [...new Set(aggregate.inputCaptureIndicators)];
  aggregate.networkIndicators = [...new Set(aggregate.networkIndicators)];
  aggregate.discordWebhooks = [...new Set(aggregate.discordWebhooks)];
  aggregate.suspiciousUrls = [...new Set(aggregate.suspiciousUrls)].slice(0, 25);

  const riskResult = risk.computeRisk(aggregate);

  logger.risk(`[${scanId}] Score: ${riskResult.score} (${riskResult.status})`);
  logger.scan(`[${scanId}] Result: ${riskResult.status}`);

  return {
    status: riskResult.status,
    riskScore: riskResult.score,
    riskBreakdown: riskResult.breakdown,
    detections: riskResult.detections,
    filesScanned: aggregate.filesScanned,
    yaraMatches: aggregate.yaraMatches,
    suspiciousStrings: {
      credential: aggregate.credentialIndicators,
      inputCapture: aggregate.inputCaptureIndicators,
      network: aggregate.networkIndicators
    },
    suspiciousUrls: aggregate.suspiciousUrls,
    discordWebhooks: aggregate.discordWebhooks,
    highEntropyFiles: aggregate.highEntropyFiles,
    sha256
  };
}

module.exports = { scanFile, getActiveScanCount, TEMP_ROOT };
