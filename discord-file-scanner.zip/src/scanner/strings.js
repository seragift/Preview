'use strict';

const fsp = require('fs/promises');

// Batas ukuran baca file untuk analisis string (mencegah pembacaan file raksasa ke memori).
const MAX_READ_BYTES = 20 * 1024 * 1024; // 20MB

const CREDENTIAL_KEYWORDS = [
  'username', 'user_name', 'password', 'passwd', 'login',
  'credential', 'account', 'session_token', 'auth_token',
  'api_key', 'secret_key', 'access_token'
];

const INPUT_CAPTURE_KEYWORDS = [
  'keyboard hook', 'keylogger', 'getasynckeystate', 'setwindowshookex',
  'onkeydown', 'onkeypress', 'keystroke', 'key capture', 'input capture',
  'hook_keyboard', 'record_keys'
];

const NETWORK_KEYWORDS = [
  'http.post', 'axios.post', 'fetch(', 'xmlhttprequest', 'urlopen',
  'requests.post', 'sendasync', 'httpclient', 'websocket'
];

const DISCORD_WEBHOOK_REGEX = /https?:\/\/(?:ptb\.|canary\.)?discord(?:app)?\.com\/api\/webhooks\/\d+\/[\w-]+/gi;
const GENERIC_URL_REGEX = /https?:\/\/[^\s"'<>]+/gi;
const IP_ADDRESS_REGEX = /\b(?:\d{1,3}\.){3}\d{1,3}(?::\d{1,5})?\b/g;

const BASE64_LIKE_REGEX = /(?:[A-Za-z0-9+/]{40,}={0,2})/g;
const HEX_ENCODED_REGEX = /(?:\\x[0-9a-fA-F]{2}){10,}/g;

function countOccurrences(content, keywords) {
  const lowerContent = content.toLowerCase();
  const found = [];
  for (const kw of keywords) {
    if (lowerContent.includes(kw.toLowerCase())) {
      found.push(kw);
    }
  }
  return found;
}

/**
 * Menganalisis satu file dan mengembalikan indikator string yang ditemukan.
 * Tidak langsung menandai file berbahaya — hanya mengumpulkan indicator mentah
 * untuk diproses oleh risk engine.
 */
async function analyzeFile(filePath) {
  const result = {
    filePath,
    credentialIndicators: [],
    inputCaptureIndicators: [],
    networkIndicators: [],
    discordWebhooks: [],
    suspiciousUrls: [],
    base64LikeCount: 0,
    hexEncodedCount: 0
  };

  let content;
  try {
    const stat = await fsp.stat(filePath);
    if (stat.size > MAX_READ_BYTES) {
      // Baca sebagian saja untuk file besar (heuristik, bukan analisis penuh).
      const fh = await fsp.open(filePath, 'r');
      const buffer = Buffer.alloc(MAX_READ_BYTES);
      await fh.read(buffer, 0, MAX_READ_BYTES, 0);
      await fh.close();
      content = buffer.toString('utf8', 0, MAX_READ_BYTES);
    } else {
      const buffer = await fsp.readFile(filePath);
      content = buffer.toString('utf8');
    }
  } catch {
    return result; // file biner tidak terbaca sebagai teks, lewati analisis string
  }

  result.credentialIndicators = countOccurrences(content, CREDENTIAL_KEYWORDS);
  result.inputCaptureIndicators = countOccurrences(content, INPUT_CAPTURE_KEYWORDS);
  result.networkIndicators = countOccurrences(content, NETWORK_KEYWORDS);

  const webhookMatches = content.match(DISCORD_WEBHOOK_REGEX) || [];
  result.discordWebhooks = [...new Set(webhookMatches)];

  const urlMatches = content.match(GENERIC_URL_REGEX) || [];
  const nonWebhookUrls = urlMatches.filter((u) => !DISCORD_WEBHOOK_REGEX.test(u));
  DISCORD_WEBHOOK_REGEX.lastIndex = 0;
  result.suspiciousUrls = [...new Set(nonWebhookUrls)].slice(0, 25);

  const base64Matches = content.match(BASE64_LIKE_REGEX) || [];
  result.base64LikeCount = base64Matches.length;

  const hexMatches = content.match(HEX_ENCODED_REGEX) || [];
  result.hexEncodedCount = hexMatches.length;

  return result;
}

module.exports = { analyzeFile, DISCORD_WEBHOOK_REGEX, GENERIC_URL_REGEX };
