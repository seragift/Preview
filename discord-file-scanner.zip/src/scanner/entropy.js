'use strict';

const fsp = require('fs/promises');

const ENTROPY_SAMPLE_BYTES = 1 * 1024 * 1024; // 1MB sample cukup untuk estimasi entropy
const HIGH_ENTROPY_THRESHOLD = 7.2; // skala 0-8 bit/byte

/**
 * Menghitung Shannon entropy dari sebuah buffer.
 * @param {Buffer} buffer
 * @returns {number} nilai entropy 0-8
 */
function shannonEntropy(buffer) {
  if (!buffer || buffer.length === 0) return 0;

  const freq = new Array(256).fill(0);
  for (const byte of buffer) {
    freq[byte]++;
  }

  let entropy = 0;
  const len = buffer.length;
  for (const count of freq) {
    if (count === 0) continue;
    const p = count / len;
    entropy -= p * Math.log2(p);
  }
  return entropy;
}

/**
 * Menghitung entropy untuk sebuah file (menggunakan sample jika file besar).
 * High entropy adalah indikator tambahan saja — bukan bukti langsung malware,
 * karena archive/binary/compressed asset yang legitimate juga bisa entropy tinggi.
 */
async function analyzeEntropy(filePath) {
  const stat = await fsp.stat(filePath);
  let buffer;

  if (stat.size > ENTROPY_SAMPLE_BYTES) {
    const fh = await fsp.open(filePath, 'r');
    buffer = Buffer.alloc(ENTROPY_SAMPLE_BYTES);
    await fh.read(buffer, 0, ENTROPY_SAMPLE_BYTES, 0);
    await fh.close();
  } else {
    buffer = await fsp.readFile(filePath);
  }

  const entropy = shannonEntropy(buffer);

  return {
    filePath,
    entropy: Number(entropy.toFixed(3)),
    isHighEntropy: entropy >= HIGH_ENTROPY_THRESHOLD,
    sizeAnalyzed: buffer.length
  };
}

module.exports = { analyzeEntropy, shannonEntropy, HIGH_ENTROPY_THRESHOLD };
