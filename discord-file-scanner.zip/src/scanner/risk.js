'use strict';

const WEIGHTS = {
  CREDENTIAL_INDICATOR: 10,
  SUSPICIOUS_URL: 10,
  EXTERNAL_HTTP_REQUEST: 10,
  WEBHOOK: 25,
  OBFUSCATION: 15,
  INPUT_CAPTURE: 30,
  DATA_COLLECTION: 20,
  CREDENTIAL_PLUS_NETWORK: 30,
  CREDENTIAL_PLUS_WEBHOOK: 40,
  DATA_COLLECTION_PLUS_EXFIL: 40,
  YARA_MATCH: 20
};

const THRESHOLDS = {
  SAFE_MAX: 19,
  SUSPICIOUS_MAX: 39,
  HIGH_MAX: 69
};

function clamp(score) {
  return Math.max(0, Math.min(100, Math.round(score)));
}

function statusFromScore(score) {
  if (score <= THRESHOLDS.SAFE_MAX) return 'SAFE';
  if (score <= THRESHOLDS.SUSPICIOUS_MAX) return 'SUSPICIOUS';
  if (score <= THRESHOLDS.HIGH_MAX) return 'HIGH';
  return 'CRITICAL';
}

/**
 * Menghitung risk score berdasarkan aggregasi indikator dari seluruh file yang di-scan.
 * Memperhatikan KOMBINASI indikator, bukan hanya jumlah keyword.
 *
 * @param {object} aggregate - hasil agregasi dari strings.js, entropy.js, yara.js
 * @returns {{score: number, status: string, breakdown: object[], detections: string[]}}
 */
function computeRisk(aggregate) {
  const breakdown = [];
  const detections = [];
  let score = 0;

  const hasCredential = aggregate.credentialIndicators.length > 0;
  const hasInputCapture = aggregate.inputCaptureIndicators.length > 0;
  const hasNetwork = aggregate.networkIndicators.length > 0;
  const hasWebhook = aggregate.discordWebhooks.length > 0;
  const hasSuspiciousUrl = aggregate.suspiciousUrls.length > 0;
  const hasHighEntropy = aggregate.highEntropyFiles.length > 0;
  const hasObfuscationSignal = aggregate.base64LikeCount > 5 || aggregate.hexEncodedCount > 3;

  function add(points, label, detectionLabel) {
    score += points;
    breakdown.push({ label, points });
    if (detectionLabel) detections.push(detectionLabel);
  }

  if (hasCredential) {
    add(WEIGHTS.CREDENTIAL_INDICATOR, 'Credential indicator', 'Credential-related pattern');
  }
  if (hasSuspiciousUrl) {
    add(WEIGHTS.SUSPICIOUS_URL, 'Suspicious URL', 'Suspicious external URL');
  }
  if (hasNetwork) {
    add(WEIGHTS.EXTERNAL_HTTP_REQUEST, 'External HTTP request', 'External HTTP request');
  }
  if (hasWebhook) {
    add(WEIGHTS.WEBHOOK, 'Discord webhook usage', 'Discord webhook usage');
  }
  if (hasObfuscationSignal || hasHighEntropy) {
    add(WEIGHTS.OBFUSCATION, 'Obfuscated / encoded content', 'Obfuscated string');
  }
  if (hasInputCapture) {
    add(WEIGHTS.INPUT_CAPTURE, 'Input/key capture pattern', 'Input capture pattern');
  }
  if (hasInputCapture && hasNetwork) {
    add(WEIGHTS.DATA_COLLECTION, 'Data collection behavior', 'Data collection + network transmission');
  }

  // Kombinasi berbahaya
  if (hasCredential && hasNetwork) {
    add(WEIGHTS.CREDENTIAL_PLUS_NETWORK, 'Credential access + network', 'Credential access combined with network activity');
  }
  if (hasCredential && hasWebhook) {
    add(WEIGHTS.CREDENTIAL_PLUS_WEBHOOK, 'Credential access + webhook', 'Credential + webhook exfiltration pattern');
  }
  if ((hasInputCapture || hasCredential) && (hasWebhook || hasNetwork) && hasObfuscationSignal) {
    add(WEIGHTS.DATA_COLLECTION_PLUS_EXFIL, 'Data collection + exfiltration + obfuscation', 'Data collection combined with exfiltration and obfuscation');
  }

  // YARA matches menambah skor per kategori rule unik (dibatasi agar tidak dominan berlebihan)
  const uniqueRuleFiles = new Set((aggregate.yaraMatches || []).map((m) => m.ruleFile));
  if (uniqueRuleFiles.size > 0) {
    const yaraPoints = Math.min(uniqueRuleFiles.size * WEIGHTS.YARA_MATCH, 60);
    add(yaraPoints, `YARA rule matched (${[...uniqueRuleFiles].join(', ')})`, `YARA detection: ${[...uniqueRuleFiles].join(', ')}`);
  }

  const finalScore = clamp(score);
  const status = statusFromScore(finalScore);

  return {
    score: finalScore,
    status,
    breakdown,
    detections: [...new Set(detections)]
  };
}

module.exports = { computeRisk, WEIGHTS, THRESHOLDS, statusFromScore };
