'use strict';

const fsp = require('fs/promises');

// Magic bytes umum untuk validasi tambahan (bukan satu-satunya sumber kebenaran).
// Untuk format teks (.lua, .cs, .pwn, .amx, .txt, .json, .js) tidak ada magic bytes baku,
// sehingga file tersebut dilewati dari pengecekan signature dan hanya divalidasi via extension.
const SIGNATURES = {
  '.zip': [[0x50, 0x4b, 0x03, 0x04], [0x50, 0x4b, 0x05, 0x06], [0x50, 0x4b, 0x07, 0x08]],
  '.rar': [[0x52, 0x61, 0x72, 0x21, 0x1a, 0x07]],
  '.7z': [[0x37, 0x7a, 0xbc, 0xaf, 0x27, 0x1c]],
  '.gz': [[0x1f, 0x8b]],
  '.tgz': [[0x1f, 0x8b]],
  '.tar': null // tar tidak punya magic bytes di awal file (header berbasis offset), dilewati
};

function matchesSignature(buffer, signatures) {
  return signatures.some((sig) =>
    sig.every((byte, i) => buffer[i] === byte)
  );
}

/**
 * Memvalidasi magic bytes file terhadap extension yang diklaim.
 * Mengembalikan true jika valid ATAU jika format tidak memiliki signature baku (mis. teks).
 */
async function validateSignature(filePath, extLower) {
  const signatures = SIGNATURES[extLower];
  if (signatures === undefined) {
    return true; // extension tidak ada di daftar signature (format teks) — lewati
  }
  if (signatures === null) {
    return true; // format tanpa magic bytes baku (tar)
  }

  const fh = await fsp.open(filePath, 'r');
  const buffer = Buffer.alloc(8);
  await fh.read(buffer, 0, 8, 0);
  await fh.close();

  return matchesSignature(buffer, signatures);
}

module.exports = { validateSignature };
