'use strict';

const path = require('path');
const fs = require('fs');
const { spawn } = require('child_process');
const logger = require('../utils/logger');

const RULES_DIR = path.join(__dirname, '..', 'rules');

const RULE_FILES = [
  'credential_theft.yar',
  'keylogger.yar',
  'webhook.yar',
  'exfiltration.yar',
  'obfuscation.yar',
  'samp.yar'
];

/**
 * Menjalankan binary YARA terhadap satu file, menggunakan seluruh rule file yang tersedia.
 * Menggunakan spawn dengan argument array (bukan shell string) untuk mencegah command/shell injection.
 *
 * @param {string} targetFilePath - path file yang akan discan
 * @param {object} config
 * @returns {Promise<Array<{rule: string, tags: string[], file: string}>>}
 */
function runYara(targetFilePath, config) {
  return new Promise((resolve) => {
    if (!config.enableYara) {
      resolve([]);
      return;
    }

    const availableRules = RULE_FILES
      .map((f) => path.join(RULES_DIR, f))
      .filter((p) => fs.existsSync(p));

    if (availableRules.length === 0) {
      logger.warn('[YARA] Tidak ada rule file ditemukan, YARA scan dilewati.');
      resolve([]);
      return;
    }

    // Gabungkan rule ke satu proses per rule file agar match dapat diatribusikan ke kategori rule.
    const matches = [];
    let pending = availableRules.length;

    if (pending === 0) {
      resolve([]);
      return;
    }

    for (const ruleFile of availableRules) {
      const args = ['-w', ruleFile, targetFilePath];
      const child = spawn(config.yaraCommand, args, {
        shell: false,
        timeout: Math.min(config.scanTimeoutSeconds, 30) * 1000
      });

      let stdout = '';
      let stderr = '';

      child.stdout.on('data', (d) => { stdout += d.toString(); });
      child.stderr.on('data', (d) => { stderr += d.toString(); });

      child.on('error', (err) => {
        // Binary yara tidak terinstall atau gagal dijalankan — jangan gagalkan seluruh scan.
        logger.warn(`[YARA] Gagal menjalankan yara untuk ${path.basename(ruleFile)}: ${err.message}`);
        finish();
      });

      child.on('close', (code) => {
        if (stdout.trim()) {
          const lines = stdout.trim().split('\n');
          for (const line of lines) {
            const parts = line.trim().split(/\s+/);
            if (parts.length >= 2) {
              matches.push({
                rule: parts[0],
                ruleFile: path.basename(ruleFile, '.yar'),
                file: parts[parts.length - 1]
              });
            }
          }
        }
        if (code !== 0 && stderr.trim()) {
          logger.warn(`[YARA] ${path.basename(ruleFile)} stderr: ${stderr.trim().slice(0, 200)}`);
        }
        finish();
      });

      function finish() {
        pending--;
        if (pending === 0) {
          resolve(matches);
        }
      }
    }
  });
}

module.exports = { runYara, RULE_FILES };
