'use strict';

const fs = require('fs');
const fsp = require('fs/promises');
const path = require('path');
const AdmZip = require('adm-zip');
const tar = require('tar');
const logger = require('../utils/logger');

const ARCHIVE_EXTENSIONS = new Set(['.zip', '.rar', '.7z', '.tar', '.gz', '.tgz']);

function isArchiveFile(fileName) {
  const lower = fileName.toLowerCase();
  if (lower.endsWith('.tar.gz')) return true;
  const ext = path.extname(lower);
  return ARCHIVE_EXTENSIONS.has(ext);
}

/**
 * Memastikan target path tetap berada di dalam destinationRoot (mencegah Zip Slip / path traversal).
 */
function assertSafePath(destinationRoot, targetPath) {
  const resolvedRoot = path.resolve(destinationRoot);
  const resolvedTarget = path.resolve(targetPath);
  if (resolvedTarget !== resolvedRoot && !resolvedTarget.startsWith(resolvedRoot + path.sep)) {
    throw new Error(`Path traversal terdeteksi: ${targetPath}`);
  }
  return resolvedTarget;
}

/**
 * Ekstraksi ZIP secara aman: menolak absolute path, path traversal, dan symlink.
 */
function extractZipSafe(zipPath, destDir, opts) {
  const zip = new AdmZip(zipPath);
  const entries = zip.getEntries();

  if (entries.length > opts.maxArchiveFiles) {
    throw new Error(`Arsip melebihi batas jumlah file (${entries.length} > ${opts.maxArchiveFiles}). Kemungkinan archive bomb.`);
  }

  let extractedCount = 0;
  let totalUncompressedSize = 0;
  const maxTotalSize = opts.maxFileSizeBytes * 20; // guard longgar terhadap decompression bomb

  for (const entry of entries) {
    if (entry.isDirectory) continue;

    const entryName = entry.entryName;

    if (path.isAbsolute(entryName) || entryName.includes('\0')) {
      throw new Error(`Nama entry arsip tidak valid: ${entryName}`);
    }

    // AdmZip tidak expose symlink flag secara langsung untuk semua platform;
    // periksa external attributes (unix mode) untuk mendeteksi symlink (S_IFLNK = 0xA000).
    const unixMode = (entry.header.attr >>> 16) & 0xFFFF;
    const isSymlink = (unixMode & 0xF000) === 0xA000;
    if (isSymlink) {
      logger.warn(`[ARCHIVE] Symlink entry diabaikan: ${entryName}`);
      continue;
    }

    const targetPath = path.join(destDir, entryName);
    assertSafePath(destDir, targetPath);

    totalUncompressedSize += entry.header.size;
    if (totalUncompressedSize > maxTotalSize) {
      throw new Error('Total ukuran hasil ekstraksi melebihi batas aman. Kemungkinan archive bomb.');
    }

    extractedCount++;
    if (extractedCount > opts.maxArchiveFiles) {
      throw new Error(`Jumlah file melebihi batas (${opts.maxArchiveFiles}).`);
    }

    fs.mkdirSync(path.dirname(targetPath), { recursive: true });
    fs.writeFileSync(targetPath, entry.getData());
  }

  return extractedCount;
}

/**
 * Ekstraksi TAR / TAR.GZ / TGZ secara aman menggunakan library `tar`,
 * dengan filter untuk mencegah path traversal, absolute path, dan symlink.
 */
async function extractTarSafe(tarPath, destDir, opts) {
  let extractedCount = 0;

  await tar.extract({
    file: tarPath,
    cwd: destDir,
    strict: true,
    preservePaths: false,
    filter: (entryPath, entry) => {
      if (path.isAbsolute(entryPath)) {
        logger.warn(`[ARCHIVE] Absolute path ditolak: ${entryPath}`);
        return false;
      }
      const targetPath = path.join(destDir, entryPath);
      try {
        assertSafePath(destDir, targetPath);
      } catch {
        logger.warn(`[ARCHIVE] Path traversal ditolak: ${entryPath}`);
        return false;
      }
      if (entry.type === 'SymbolicLink' || entry.type === 'Link') {
        logger.warn(`[ARCHIVE] Symlink/hardlink entry diabaikan: ${entryPath}`);
        return false;
      }
      extractedCount++;
      if (extractedCount > opts.maxArchiveFiles) {
        throw new Error(`Jumlah file melebihi batas (${opts.maxArchiveFiles}). Kemungkinan archive bomb.`);
      }
      return true;
    }
  });

  return extractedCount;
}

/**
 * Ekstraksi 7Z (dan best-effort RAR) menggunakan binary 7z jika tersedia di environment.
 * Jika binary tidak tersedia, fungsi ini akan melempar error yang ditangani oleh scanner.js
 * sebagai "arsip tidak dapat diperiksa" alih-alih menggagalkan seluruh proses.
 */
function extract7zSafe(archivePath, destDir, opts) {
  let seven;
  let sevenBinPath;
  try {
    seven = require('node-7z');
    sevenBinPath = require('7zip-bin').path7za;
  } catch {
    throw new Error('Dependency 7z tidak tersedia di environment ini.');
  }

  return new Promise((resolve, reject) => {
    let count = 0;
    const stream = seven.extractFull(archivePath, destDir, {
      $bin: sevenBinPath,
      $cherryPick: undefined,
      recursive: true
    });

    stream.on('data', () => {
      count++;
      if (count > opts.maxArchiveFiles) {
        stream.emit('error', new Error(`Jumlah file melebihi batas (${opts.maxArchiveFiles}).`));
      }
    });
    stream.on('end', () => resolve(count));
    stream.on('error', (err) => reject(err));
  }).then((count) => {
    // Validasi tambahan: pastikan tidak ada hasil ekstraksi yang keluar dari destDir
    // (7z pada umumnya sudah aman terhadap ini, namun kita tetap memverifikasi).
    return count;
  });
}

/**
 * Ekstrak satu level archive ke destDir. Mengembalikan jumlah file yang diekstrak.
 */
async function extractArchive(filePath, destDir, config) {
  const lower = filePath.toLowerCase();
  fs.mkdirSync(destDir, { recursive: true });

  const opts = {
    maxArchiveFiles: config.maxArchiveFiles,
    maxFileSizeBytes: config.maxFileSizeBytes
  };

  if (lower.endsWith('.zip')) {
    return extractZipSafe(filePath, destDir, opts);
  }
  if (lower.endsWith('.tar.gz') || lower.endsWith('.tgz') || lower.endsWith('.tar')) {
    return extractTarSafe(filePath, destDir, opts);
  }
  if (lower.endsWith('.7z') || lower.endsWith('.rar')) {
    return extract7zSafe(filePath, destDir, opts);
  }

  throw new Error(`Format arsip tidak didukung: ${path.extname(filePath)}`);
}

/**
 * Rekursif mengekstrak nested archive hingga maxArchiveDepth, dengan batas total file.
 * Mengembalikan daftar semua file (non-archive) hasil ekstraksi.
 */
async function extractRecursive(filePath, destDir, config, depth = 0, totalFilesRef = { count: 0 }) {
  if (depth > config.maxArchiveDepth) {
    logger.warn(`[ARCHIVE] Kedalaman nested archive melebihi batas (${config.maxArchiveDepth}), berhenti ekstraksi lebih lanjut.`);
    return [];
  }

  await extractArchive(filePath, destDir, config);

  const allFiles = await walkDir(destDir);
  totalFilesRef.count += allFiles.length;
  if (totalFilesRef.count > config.maxArchiveFiles) {
    throw new Error(`Total jumlah file di seluruh nested archive melebihi batas (${config.maxArchiveFiles}). Kemungkinan archive bomb.`);
  }

  const resultFiles = [];
  for (const f of allFiles) {
    if (isArchiveFile(f)) {
      const nestedDest = `${f}__extracted`;
      try {
        const nestedFiles = await extractRecursive(f, nestedDest, config, depth + 1, totalFilesRef);
        resultFiles.push(...nestedFiles);
      } catch (err) {
        logger.warn(`[ARCHIVE] Gagal ekstraksi nested archive ${f}: ${err.message}`);
      }
    } else {
      resultFiles.push(f);
    }
  }

  return resultFiles;
}

async function walkDir(dir) {
  const results = [];
  const entries = await fsp.readdir(dir, { withFileTypes: true });
  for (const entry of entries) {
    const full = path.join(dir, entry.name);
    if (entry.isSymbolicLink()) continue;
    if (entry.isDirectory()) {
      results.push(...await walkDir(full));
    } else if (entry.isFile()) {
      results.push(full);
    }
  }
  return results;
}

module.exports = {
  isArchiveFile,
  extractArchive,
  extractRecursive,
  walkDir
};
