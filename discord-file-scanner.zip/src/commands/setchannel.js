'use strict';

const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  ChannelType,
  MessageFlags
} = require('discord.js');
const db = require('../database/database');
const logger = require('../utils/logger');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setchannel')
    .setDescription('Atur channel yang akan otomatis discan oleh File Scanner.')
    .addChannelOption((option) =>
      option
        .setName('channel')
        .setDescription('Channel yang akan digunakan untuk auto-scan')
        .addChannelTypes(ChannelType.GuildText)
        .setRequired(true)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction) {
    if (!interaction.inGuild()) {
      await interaction.reply({
        content: '⚠️ Command ini hanya dapat digunakan di dalam server, bukan DM.',
        flags: MessageFlags.Ephemeral
      });
      return;
    }

    const member = interaction.member;
    const hasPermission =
      member.permissions.has(PermissionFlagsBits.ManageGuild) ||
      member.permissions.has(PermissionFlagsBits.Administrator);

    if (!hasPermission) {
      await interaction.reply({
        content: '⚠️ Kamu membutuhkan permission **Manage Guild** atau **Administrator** untuk menggunakan command ini.',
        flags: MessageFlags.Ephemeral
      });
      return;
    }

    const channel = interaction.options.getChannel('channel');

    if (!channel || channel.type !== ChannelType.GuildText) {
      await interaction.reply({
        content: '⚠️ Channel yang dipilih bukan text channel yang valid.',
        flags: MessageFlags.Ephemeral
      });
      return;
    }

    db.setScanChannel(interaction.guild.id, channel.id);
    logger.info(`Guild ${interaction.guild.id} mengatur scan channel ke #${channel.name} (${channel.id})`);

    await interaction.reply({
      content: `✅ Scan channel berhasil diatur.\n\nSemua file yang dikirim ke <#${channel.id}> akan otomatis diperiksa.`,
      flags: MessageFlags.Ephemeral
    });
  }
};
