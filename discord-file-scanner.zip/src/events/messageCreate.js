'use strict';

const fs = require('fs');
const fsp = require('fs/promises');
const path = require('path');
const { Events } = require('discord.js');

const db = require('../database/database');
const logger = require('../utils/logger');
const { cleanupDir } = require('../utils/cleanup');
const { buildResultEmbed, buildDetailButtonRow } = require('../utils/embed');
const resultStore = require('../utils/resultStore');
const scanner = require('../scanner/scanner');
const { validateSignature } = require('../scanner/signature');

function getExtension(fileName) {
  const lower = fileName.toLowerCase();
  if (lower.endsWith('.tar.gz')) return '.tar.gz';
  return path.extname(lower);
}

async function downloadAttachment(url, destPath) {
  const res = await fetch(url);
  if (!res.ok) {
    throw new Error(`HTTP ${res.status}`);
  }
  const arrayBuffer = await res.arrayBuffer();
  await fsp.writeFile(destPath, Buffer.from(arrayBuffer));
}

module.exports = {
  name: Events.MessageCreate,
  async execute(message, config) {
    // 1. Ignore DM
    if (!message.guild) return;
    // 2. Ignore bot
    if (message.author.bot) return;
    // 3 & 4. Ambil guild_id
    const guildId = message.guild.id;

    // 5. Cari konfigurasi guild
    const settings = db.getGuildSettings(guildId);
    if (!settings) return;

    // 6. Pastikan scanner aktif
    if (!settings.enabled) return;

    // 7. Pastikan channel sesuai
    if (!settings.scan_channel_id || message.channel.id !== settings.scan_channel_id) return;

    // 8-9. Periksa attachment
    if (!message.attachments || message.attachments.size === 0) return;

    for (const attachment of message.attachments.values()) {
      await handleAttachment(message, attachment, settings, config).catch((err) => {
        logger.error(`Gagal memproses attachment ${attachment.name}: ${err.message}`);
      });
    }
  }
};

async function handleAttachment(message, attachment, settings, config) {
  const fileName = attachment.name || 'unknown_file';
  const ext = getExtension(fileName);

  const allowedExts = config.allowedExtensions.map((e) => e.toLowerCase());
  if (!allowedExts.includes(ext)) {
    logger.scan(`File diabaikan (extension tidak didukung): ${fileName}`);
    return;
  }

  if (attachment.size > config.maxFileSizeBytes) {
    await message.reply({
      content: `⚠️ **FILE TIDAK DAPAT DIPERIKSA**\n\nUkuran file \`${fileName}\` melebihi batas scanner (${config.maxFileSizeMB}MB).`
    }).catch(() => {});
    return;
  }

  logger.scan(`User ${message.author.id} uploaded ${fileName}`);

  const scanId = require('crypto').randomUUID();
  const downloadDir = path.join(scanner.TEMP_ROOT, `dl-${scanId}`);
  fs.mkdirSync(downloadDir, { recursive: true });
  const localPath = path.join(downloadDir, sanitizeFileName(fileName));

  let statusMsg;
  try {
    statusMsg = await message.reply({ content: `🔍 Memeriksa \`${fileName}\`...` }).catch(() => null);

    await downloadAttachment(attachment.url, localPath);

    const sigValid = await validateSignature(localPath, ext);
    if (!sigValid) {
      await finalizeReply(statusMsg, message, {
        content: `⚠️ File \`${fileName}\` ditolak: signature file tidak sesuai dengan extension yang diklaim.`
      });
      await cleanupDir(downloadDir);
      return;
    }

    const result = await scanner.scanFile({ filePath: localPath, fileName, config });

    if (result.status === 'ERROR') {
      const reasonText = {
        ARCHIVE_EXTRACT_FAILED: '⚠️ File tidak dapat diperiksa.\n\nArsip rusak atau formatnya tidak valid.'
      }[result.errorReason] || '⚠️ Pemeriksaan gagal.\n\nBot tidak dapat memastikan keamanan file ini. Silakan coba kembali.';

      await finalizeReply(statusMsg, message, { content: reasonText });
      if (config.saveScanHistory) {
        db.saveScanHistory({
          guildId: message.guild.id,
          channelId: message.channel.id,
          userId: message.author.id,
          fileName,
          fileSize: attachment.size,
          sha256: result.sha256,
          status: 'ERROR',
          riskScore: 0,
          detections: 0
        });
      }
      return;
    }

    const embed = buildResultEmbed({ fileName, result, requestedBy: message.author.tag });
    const row = buildDetailButtonRow(false);

    const sentMsg = await finalizeReply(statusMsg, message, { content: '', embeds: [embed], components: [row] });

    if (sentMsg) {
      resultStore.set(sentMsg.id, { fileName, result });
    }

    if (config.saveScanHistory) {
      db.saveScanHistory({
        guildId: message.guild.id,
        channelId: message.channel.id,
        userId: message.author.id,
        fileName,
        fileSize: attachment.size,
        sha256: result.sha256,
        status: result.status,
        riskScore: result.riskScore,
        detections: result.detections.length
      });
    }

    if (settings.log_channel_id) {
      const logChannel = message.guild.channels.cache.get(settings.log_channel_id);
      if (logChannel && logChannel.isTextBased()) {
        await logChannel.send({ embeds: [embed] }).catch(() => {});
      }
    }
  } catch (err) {
    logger.error(`Scan error untuk ${fileName}: ${err.message}`);

    let content = '⚠️ Pemeriksaan gagal.\n\nBot tidak dapat memastikan keamanan file ini. Silakan coba kembali.';
    if (err.message === 'SCAN_TIMEOUT') {
      content = '⚠️ Pemeriksaan dihentikan karena melewati batas waktu scanner.';
    } else if (err.message === 'SCAN_QUEUE_FULL') {
      content = '⚠️ Scanner sedang sibuk memproses file lain. Silakan coba beberapa saat lagi.';
    } else if (err.message.includes('HTTP') || err.message.toLowerCase().includes('fetch')) {
      content = '⚠️ Gagal mengunduh file.\nSilakan coba upload kembali.';
    }

    await finalizeReply(statusMsg, message, { content }).catch(() => {});
  } finally {
    if (config.deleteTemporaryFiles) {
      await cleanupDir(downloadDir);
    }
  }
}

async function finalizeReply(statusMsg, message, payload) {
  try {
    if (statusMsg && statusMsg.editable) {
      return await statusMsg.edit(payload);
    }
    return await message.reply(payload);
  } catch {
    return null;
  }
}

function sanitizeFileName(name) {
  return name.replace(/[/\\?%*:|"<>\x00-\x1f]/g, '_').slice(0, 200);
}
