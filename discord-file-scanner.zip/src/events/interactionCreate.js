'use strict';

const { Events, MessageFlags } = require('discord.js');
const logger = require('../utils/logger');
const resultStore = require('../utils/resultStore');
const { buildDetailEmbed } = require('../utils/embed');

module.exports = {
  name: Events.InteractionCreate,
  async execute(interaction, config) {
    if (interaction.isChatInputCommand()) {
      const command = interaction.client.commands.get(interaction.commandName);
      if (!command) return;

      try {
        await command.execute(interaction, config);
      } catch (err) {
        logger.error(`Error menjalankan command ${interaction.commandName}: ${err.message}`);
        const payload = {
          content: '⚠️ Terjadi kesalahan saat menjalankan command ini.',
          flags: MessageFlags.Ephemeral
        };
        if (interaction.replied || interaction.deferred) {
          await interaction.followUp(payload).catch(() => {});
        } else {
          await interaction.reply(payload).catch(() => {});
        }
      }
      return;
    }

    if (interaction.isButton() && interaction.customId === 'scan_detail') {
      const stored = resultStore.get(interaction.message.id);
      if (!stored) {
        await interaction.reply({
          content: '⚠️ Detail scan tidak lagi tersedia (kadaluarsa).',
          flags: MessageFlags.Ephemeral
        });
        return;
      }

      const embed = buildDetailEmbed(stored);
      await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
    }
  }
};
