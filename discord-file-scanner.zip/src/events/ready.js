'use strict';

const { Events } = require('discord.js');
const logger = require('../utils/logger');

module.exports = {
  name: Events.ClientReady,
  once: true,
  execute(client, config) {
    logger.info('🛡️  Discord File Scanner');
    logger.info('Status: Online');
    logger.info(`Servers: ${client.guilds.cache.size}`);
    logger.info('Scanner: Enabled');
    logger.info('Database: SQLite');
    logger.info(`YARA: ${config.enableYara ? 'Enabled' : 'Disabled'}`);
  }
};
