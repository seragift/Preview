'use strict';

function timestamp() {
  return new Date().toISOString();
}

function format(tag, msg) {
  return `[${timestamp()}] [${tag}] ${msg}`;
}

const logger = {
  info: (msg) => console.log(format('INFO', msg)),
  warn: (msg) => console.warn(format('WARN', msg)),
  error: (msg) => console.error(format('ERROR', msg)),
  scan: (msg) => console.log(format('SCAN', msg)),
  database: (msg) => console.log(format('DATABASE', msg)),
  yara: (msg) => console.log(format('YARA', msg)),
  risk: (msg) => console.log(format('RISK', msg)),
  cleanup: (msg) => console.log(format('CLEANUP', msg))
};

module.exports = logger;
