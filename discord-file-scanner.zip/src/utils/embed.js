'use strict';

const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle
} = require('discord.js');

const COLORS = {
  SAFE: 0x2ecc71,
  SUSPICIOUS: 0xe67e22,
  HIGH: 0xe74c3c,
  CRITICAL: 0xc0392b,
  ERROR: 0x95a5a6
};

const STATUS_LABEL = {
  SAFE: '🟢 FILE AMAN',
  SUSPICIOUS: '🟠 FILE MENCURIGAKAN',
  HIGH: '🔴 BAHAYA — INDIKASI PENCURIAN DATA',
  CRITICAL: '🔴 BAHAYA — INDIKASI PENCURIAN DATA',
  ERROR: '⚠️ PEMERIKSAAN GAGAL'
};

function truncate(str, max = 1000) {
  if (!str) return str;
  return str.length > max ? `${str.slice(0, max)}…` : str;
}

/**
 * Membangun embed hasil scan (versi ringkas untuk pengguna awam).
 */
function buildResultEmbed({ fileName, result, requestedBy }) {
  const status = result.status;
  const color = COLORS[status] || COLORS.ERROR;

  const embed = new EmbedBuilder()
    .setColor(color)
    .setTitle(STATUS_LABEL[status] || STATUS_LABEL.ERROR)
    .addFields(
      { name: 'Nama File', value: `\`${fileName}\``, inline: false }
    )
    .setFooter({ text: `Diperiksa oleh Discord File Scanner • diminta oleh ${requestedBy}` })
    .setTimestamp();

  if (status === 'ERROR') {
    embed.setDescription(
      '⚠️ Pemeriksaan gagal.\n\nBot tidak dapat memastikan keamanan file ini. Silakan coba kembali.'
    );
    return embed;
  }

  if (status === 'SAFE') {
    embed.setDescription(
      'Tidak ditemukan indikasi pencurian data, keylogger, credential stealing, atau aktivitas mencurigakan yang terdeteksi.'
    );
  } else if (status === 'SUSPICIOUS') {
    embed.setDescription(
      'Ditemukan beberapa pola yang memerlukan pemeriksaan lebih lanjut.\n\n⚠️ Jangan menjalankan file sebelum diperiksa lebih lanjut.'
    );
  } else {
    embed.setDescription(
      'Sistem menemukan kombinasi pola yang berpotensi digunakan untuk mengumpulkan dan mengirim data pengguna.\n\n⚠️ File ini sangat tidak disarankan untuk dijalankan atau dipasang.'
    );
  }

  embed.addFields(
    { name: 'File diperiksa', value: `${result.filesScanned}`, inline: true },
    { name: 'Deteksi', value: `${result.detections.length}`, inline: true },
    { name: 'Risk Score', value: `${result.riskScore}/100`, inline: true }
  );

  if (result.detections.length > 0) {
    const list = result.detections.slice(0, 10).map((d) => `• ${d}`).join('\n');
    embed.addFields({ name: 'Indikasi', value: truncate(list, 1024) });
  }

  embed.addFields({ name: 'SHA-256', value: `\`${result.sha256}\`` });

  return embed;
}

/**
 * Embed detail teknis (ditampilkan ketika tombol "Detail Scan" ditekan).
 * Tidak menampilkan payload/data sensitif secara mentah — hanya metadata.
 */
function buildDetailEmbed({ fileName, result }) {
  const embed = new EmbedBuilder()
    .setColor(COLORS[result.status] || COLORS.ERROR)
    .setTitle(`🔎 Detail Scan — ${fileName}`)
    .setTimestamp();

  const yaraRules = [...new Set((result.yaraMatches || []).map((m) => `${m.ruleFile}:${m.rule}`))];
  embed.addFields({
    name: 'YARA Rules Matched',
    value: yaraRules.length > 0 ? truncate(yaraRules.join('\n'), 1000) : 'Tidak ada'
  });

  const breakdown = (result.riskBreakdown || [])
    .map((b) => `• ${b.label}: +${b.points}`)
    .join('\n');
  embed.addFields({
    name: 'Risk Score Breakdown',
    value: breakdown ? truncate(breakdown, 1000) : 'Tidak ada'
  });

  embed.addFields(
    { name: 'Jumlah File Dianalisis', value: `${result.filesScanned}`, inline: true },
    { name: 'SHA-256', value: `\`${result.sha256}\``, inline: false }
  );

  const highEntropy = (result.highEntropyFiles || [])
    .map((e) => `• ${e.file} (entropy: ${e.entropy})`)
    .join('\n');
  embed.addFields({
    name: 'Entropy Indicator',
    value: highEntropy ? truncate(highEntropy, 1000) : 'Tidak ada file dengan entropy tinggi'
  });

  const urlCount = (result.suspiciousUrls || []).length;
  embed.addFields({
    name: 'Suspicious URLs',
    value: urlCount > 0 ? `${urlCount} URL ditemukan (disembunyikan demi keamanan)` : 'Tidak ada'
  });

  return embed;
}

function buildDetailButtonRow(disabled = false) {
  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('scan_detail')
      .setLabel('🔎 Detail Scan')
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(disabled)
  );
  return row;
}

module.exports = { buildResultEmbed, buildDetailEmbed, buildDetailButtonRow, COLORS };
