'use strict';

const fs = require('fs/promises');
const logger = require('./logger');

/**
 * Menghapus direktori temporary scan secara rekursif dan aman.
 * @param {string} dirPath
 */
async function cleanupDir(dirPath) {
  if (!dirPath) return;
  try {
    await fs.rm(dirPath, { recursive: true, force: true, maxRetries: 3 });
    logger.cleanup(`Temporary directory dihapus: ${dirPath}`);
  } catch (err) {
    logger.error(`Gagal menghapus temporary directory ${dirPath}: ${err.message}`);
  }
}

module.exports = { cleanupDir };
