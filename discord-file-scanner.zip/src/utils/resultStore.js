'use strict';

// Menyimpan hasil scan sementara di memori (keyed by Discord message id)
// agar tombol "Detail Scan" dapat menampilkan detail tanpa query ulang.
// TTL otomatis untuk mencegah memory leak pada bot yang berjalan lama.

const TTL_MS = 30 * 60 * 1000; // 30 menit
const store = new Map();

function set(messageId, data) {
  store.set(messageId, { data, expiresAt: Date.now() + TTL_MS });
}

function get(messageId) {
  const entry = store.get(messageId);
  if (!entry) return null;
  if (Date.now() > entry.expiresAt) {
    store.delete(messageId);
    return null;
  }
  return entry.data;
}

function sweep() {
  const now = Date.now();
  for (const [key, entry] of store.entries()) {
    if (now > entry.expiresAt) store.delete(key);
  }
}

setInterval(sweep, 5 * 60 * 1000).unref();

module.exports = { set, get };
