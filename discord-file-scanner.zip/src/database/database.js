'use strict';

const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');
const logger = require('../utils/logger');

const DB_PATH = path.join(__dirname, 'database.sqlite');

let db = null;

function init() {
  const dbDir = path.dirname(DB_PATH);
  if (!fs.existsSync(dbDir)) {
    fs.mkdirSync(dbDir, { recursive: true });
  }

  const isNew = !fs.existsSync(DB_PATH);

  db = new Database(DB_PATH);
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');

  db.exec(`
    CREATE TABLE IF NOT EXISTS guild_settings (
      guild_id TEXT PRIMARY KEY,
      scan_channel_id TEXT,
      log_channel_id TEXT,
      enabled INTEGER DEFAULT 1,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );
  `);

  db.exec(`
    CREATE TABLE IF NOT EXISTS scan_history (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guild_id TEXT NOT NULL,
      channel_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      file_name TEXT NOT NULL,
      file_size INTEGER,
      sha256 TEXT,
      status TEXT NOT NULL,
      risk_score INTEGER DEFAULT 0,
      detections INTEGER DEFAULT 0,
      scanned_at INTEGER NOT NULL
    );
  `);

  db.exec(`CREATE INDEX IF NOT EXISTS idx_scan_history_guild ON scan_history(guild_id);`);
  db.exec(`CREATE INDEX IF NOT EXISTS idx_scan_history_sha256 ON scan_history(sha256);`);

  logger.database(isNew ? 'database.sqlite dibuat baru.' : 'database.sqlite dimuat.');

  return db;
}

function getDb() {
  if (!db) {
    throw new Error('Database belum diinisialisasi. Panggil init() terlebih dahulu.');
  }
  return db;
}

// ---------- guild_settings helpers ----------

function getGuildSettings(guildId) {
  const stmt = getDb().prepare('SELECT * FROM guild_settings WHERE guild_id = ?');
  return stmt.get(guildId) || null;
}

function ensureGuildRow(guildId) {
  const existing = getGuildSettings(guildId);
  if (existing) return existing;

  const now = Date.now();
  const stmt = getDb().prepare(`
    INSERT INTO guild_settings (guild_id, scan_channel_id, log_channel_id, enabled, created_at, updated_at)
    VALUES (?, NULL, NULL, 1, ?, ?)
  `);
  stmt.run(guildId, now, now);
  return getGuildSettings(guildId);
}

function setScanChannel(guildId, channelId) {
  ensureGuildRow(guildId);
  const stmt = getDb().prepare(`
    UPDATE guild_settings SET scan_channel_id = ?, updated_at = ? WHERE guild_id = ?
  `);
  stmt.run(channelId, Date.now(), guildId);
  return getGuildSettings(guildId);
}

function setLogChannel(guildId, channelId) {
  ensureGuildRow(guildId);
  const stmt = getDb().prepare(`
    UPDATE guild_settings SET log_channel_id = ?, updated_at = ? WHERE guild_id = ?
  `);
  stmt.run(channelId, Date.now(), guildId);
  return getGuildSettings(guildId);
}

function setGuildEnabled(guildId, enabled) {
  ensureGuildRow(guildId);
  const stmt = getDb().prepare(`
    UPDATE guild_settings SET enabled = ?, updated_at = ? WHERE guild_id = ?
  `);
  stmt.run(enabled ? 1 : 0, Date.now(), guildId);
  return getGuildSettings(guildId);
}

// ---------- scan_history helpers ----------

function saveScanHistory(data) {
  const stmt = getDb().prepare(`
    INSERT INTO scan_history
      (guild_id, channel_id, user_id, file_name, file_size, sha256, status, risk_score, detections, scanned_at)
    VALUES
      (@guild_id, @channel_id, @user_id, @file_name, @file_size, @sha256, @status, @risk_score, @detections, @scanned_at)
  `);
  const info = stmt.run({
    guild_id: data.guildId,
    channel_id: data.channelId,
    user_id: data.userId,
    file_name: data.fileName,
    file_size: data.fileSize ?? null,
    sha256: data.sha256 ?? null,
    status: data.status,
    risk_score: data.riskScore ?? 0,
    detections: data.detections ?? 0,
    scanned_at: Date.now()
  });
  return info.lastInsertRowid;
}

function getScanHistory(id) {
  const stmt = getDb().prepare('SELECT * FROM scan_history WHERE id = ?');
  return stmt.get(id) || null;
}

function closeDb() {
  if (db) {
    db.close();
    db = null;
  }
}

module.exports = {
  init,
  getDb,
  getGuildSettings,
  ensureGuildRow,
  setScanChannel,
  setLogChannel,
  setGuildEnabled,
  saveScanHistory,
  getScanHistory,
  closeDb
};
