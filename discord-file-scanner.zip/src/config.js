'use strict';

const fs = require('fs');
const path = require('path');

const CONFIG_PATH = path.join(__dirname, '..', 'config.json');

const DEFAULTS = {
  maxFileSizeMB: 100,
  maxArchiveFiles: 1000,
  maxArchiveDepth: 5,
  scanTimeoutSeconds: 120,
  deleteTemporaryFiles: true,
  saveScanHistory: true,
  enableYara: true,
  maxConcurrentScans: 3,
  yaraCommand: 'yara',
  allowedExtensions: ['.zip', '.rar', '.7z', '.tar', '.tar.gz', '.tgz', '.lua', '.cs', '.pwn', '.amx', '.txt', '.json', '.js']
};

function loadConfig() {
  let raw = {};

  if (fs.existsSync(CONFIG_PATH)) {
    try {
      raw = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
    } catch (err) {
      throw new Error(`[CONFIG] Gagal membaca config.json: ${err.message}`);
    }
  }

  const cfg = { ...DEFAULTS, ...raw };

  const numericFields = [
    'maxFileSizeMB',
    'maxArchiveFiles',
    'maxArchiveDepth',
    'scanTimeoutSeconds',
    'maxConcurrentScans'
  ];

  for (const field of numericFields) {
    if (typeof cfg[field] !== 'number' || !Number.isFinite(cfg[field]) || cfg[field] <= 0) {
      throw new Error(`[CONFIG] Nilai "${field}" tidak valid. Harus berupa angka positif.`);
    }
  }

  const boolFields = ['deleteTemporaryFiles', 'saveScanHistory', 'enableYara'];
  for (const field of boolFields) {
    if (typeof cfg[field] !== 'boolean') {
      throw new Error(`[CONFIG] Nilai "${field}" harus boolean (true/false).`);
    }
  }

  if (!Array.isArray(cfg.allowedExtensions) || cfg.allowedExtensions.length === 0) {
    throw new Error('[CONFIG] "allowedExtensions" harus berupa array yang tidak kosong.');
  }

  if (typeof cfg.yaraCommand !== 'string' || cfg.yaraCommand.trim() === '') {
    throw new Error('[CONFIG] "yaraCommand" harus berupa string yang valid.');
  }

  cfg.maxFileSizeBytes = cfg.maxFileSizeMB * 1024 * 1024;

  return cfg;
}

module.exports = { loadConfig };
