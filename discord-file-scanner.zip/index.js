'use strict';

require('dotenv').config();

const fs = require('fs');
const path = require('path');
const { Client, GatewayIntentBits, Partials, Collection } = require('discord.js');

const logger = require('./src/utils/logger');
const { loadConfig } = require('./src/config');
const db = require('./src/database/database');

async function main() {
  // 1. Load dotenv (sudah dilakukan di atas)
  const token = process.env.DISCORD_TOKEN;
  if (!token) {
    logger.error('DISCORD_TOKEN tidak ditemukan. Pastikan file .env sudah dikonfigurasi.');
    process.exit(1);
  }

  // 2. Load config.json
  const config = loadConfig();
  logger.info('Konfigurasi berhasil dimuat dan divalidasi.');

  // 3. Initialize SQLite
  db.init();

  // Pastikan folder temp ada
  const tempDir = path.join(__dirname, 'src', 'temp');
  if (!fs.existsSync(tempDir)) {
    fs.mkdirSync(tempDir, { recursive: true });
  }

  const client = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.MessageContent
    ],
    partials: [Partials.Message, Partials.Channel]
  });

  // 4. Load commands
  client.commands = new Collection();
  const commandsDir = path.join(__dirname, 'src', 'commands');
  for (const file of fs.readdirSync(commandsDir).filter((f) => f.endsWith('.js'))) {
    const command = require(path.join(commandsDir, file));
    if (command?.data?.name) {
      client.commands.set(command.data.name, command);
    }
  }

  // 5. Load events
  const eventsDir = path.join(__dirname, 'src', 'events');
  for (const file of fs.readdirSync(eventsDir).filter((f) => f.endsWith('.js'))) {
    const event = require(path.join(eventsDir, file));
    if (event.once) {
      client.once(event.name, (...args) => event.execute(...args, config));
    } else {
      client.on(event.name, (...args) => event.execute(...args, config));
    }
  }

  process.on('unhandledRejection', (err) => {
    logger.error(`Unhandled rejection: ${err?.message || err}`);
  });

  async function shutdown(signal) {
    logger.info(`Menerima ${signal}, melakukan graceful shutdown...`);
    try {
      const tempDir2 = path.join(__dirname, 'src', 'temp');
      if (fs.existsSync(tempDir2)) {
        for (const entry of fs.readdirSync(tempDir2)) {
          fs.rmSync(path.join(tempDir2, entry), { recursive: true, force: true });
        }
      }
      logger.cleanup('Seluruh temporary scan directory dibersihkan.');
    } catch (err) {
      logger.error(`Gagal membersihkan temp saat shutdown: ${err.message}`);
    }

    db.closeDb();
    client.destroy();
    process.exit(0);
  }

  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));

  // 6. Login Discord
  await client.login(token);
}

main().catch((err) => {
  logger.error(`Gagal menjalankan bot: ${err.message}`);
  process.exit(1);
});
