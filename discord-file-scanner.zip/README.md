# 🛡️ Discord File Scanner

Bot Discord untuk pemeriksaan otomatis file/modpack SA-MP guna mendeteksi indikasi
**credential theft**, **keylogger**, **webhook/data exfiltration**, dan **obfuscation**,
menggunakan static analysis (YARA + string/entropy analysis). Bot **tidak pernah**
menjalankan file yang di-upload — seluruh pemeriksaan bersifat statis.

Mendukung **multi-server** tanpa perlu `GUILD_ID`; seluruh konfigurasi per-server
disimpan di SQLite.

---

## 1. Requirements

- Node.js 20 atau lebih baru
- npm
- YARA (binary `yara` di PATH) — opsional tapi sangat direkomendasikan
- OS: Linux/Windows/macOS (VPS Linux direkomendasikan untuk produksi)

---

## 2. Install Node.js

**Ubuntu/Debian:**
```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs
```

**Windows:** unduh installer dari https://nodejs.org (pilih versi LTS 20+).

**macOS (Homebrew):**
```bash
brew install node@20
```

---

## 3. Install YARA

**Ubuntu/Debian:**
```bash
sudo apt-get update
sudo apt-get install -y yara
```

**CentOS/RHEL/Fedora:**
```bash
sudo dnf install -y yara
```

**macOS (Homebrew):**
```bash
brew install yara
```

**Windows:**
1. Unduh binary rilis dari https://github.com/VirusTotal/yara/releases
2. Ekstrak dan tambahkan folder berisi `yara.exe` ke PATH sistem.

Verifikasi instalasi:
```bash
yara --version
```

Jika binary YARA tidak tersedia, bot tetap berjalan — YARA scan otomatis dilewati
dan hasil analisis tetap didasarkan pada string/entropy analysis, namun akurasi
deteksi akan berkurang. Set `"enableYara": false` di `config.json` untuk mematikan
YARA secara eksplisit.

---

## 4. Clone project & install dependency

```bash
git clone <repo-url> discord-file-scanner
cd discord-file-scanner
npm install
```

> Catatan: dependency `node-7z` + `7zip-bin` digunakan untuk mendukung ekstraksi
> `.7z` (dan best-effort `.rar`). Jika instalasi native dependency gagal di
> environment tertentu (mis. beberapa shared hosting terbatas), format `.zip`,
> `.tar`, `.tar.gz`, `.tgz`, dan seluruh format teks tetap berfungsi normal;
> `.7z`/`.rar` akan otomatis dilaporkan sebagai "arsip tidak dapat diperiksa".

---

## 5. Konfigurasi `.env`

Salin `.env.example` menjadi `.env`:
```bash
cp .env.example .env
```

Isi dengan token bot Discord kamu:
```
DISCORD_TOKEN=YOUR_DISCORD_BOT_TOKEN
```

Tidak perlu `GUILD_ID` — bot bekerja secara global di seluruh server tempat ia diundang.

---

## 6. Konfigurasi `config.json`

```json
{
  "maxFileSizeMB": 100,
  "maxArchiveFiles": 1000,
  "maxArchiveDepth": 5,
  "scanTimeoutSeconds": 120,
  "deleteTemporaryFiles": true,
  "saveScanHistory": true,
  "enableYara": true,
  "maxConcurrentScans": 3,
  "yaraCommand": "yara",
  "allowedExtensions": [".zip", ".rar", ".7z", ".tar", ".tar.gz", ".tgz", ".lua", ".cs", ".pwn", ".amx", ".txt", ".json", ".js"]
}
```

| Field | Keterangan |
|---|---|
| `maxFileSizeMB` | Batas ukuran file yang diperiksa (MB) |
| `maxArchiveFiles` | Batas jumlah file di dalam arsip (mencegah archive bomb) |
| `maxArchiveDepth` | Batas kedalaman nested archive |
| `scanTimeoutSeconds` | Batas waktu total satu proses scan |
| `deleteTemporaryFiles` | Hapus file temporary setelah scan (disarankan `true`) |
| `saveScanHistory` | Simpan riwayat scan ke SQLite |
| `enableYara` | Aktifkan/nonaktifkan YARA scan |
| `maxConcurrentScans` | Batas scan simultan agar VPS tidak kehabisan resource |
| `yaraCommand` | Nama/path binary yara (default `yara`) |
| `allowedExtensions` | Daftar extension file yang diterima |

---

## 7. Menjalankan bot

Daftarkan slash command (global, tidak butuh GUILD_ID) — cukup sekali atau setiap
kali menambah command baru:
```bash
npm run deploy
```

Jalankan bot:
```bash
npm start
```

Untuk menjaga bot tetap berjalan di VPS/Pterodactyl, gunakan process manager
seperti `pm2` atau startup command sesuai panel hosting kamu.

---

## 8. Cara menggunakan `/setchannel`

1. Jalankan `/setchannel channel:#nama-channel` di server Discord kamu.
2. Membutuhkan permission **Manage Guild** atau **Administrator**.
3. Setelah diatur, seluruh file yang diupload ke channel tersebut akan otomatis
   diperiksa oleh bot — **tidak perlu command tambahan**.

---

## 9. Cara kerja auto scan

1. User mengupload file ke scan channel.
2. Bot memvalidasi extension, ukuran, dan magic bytes file.
3. Bot mengunduh file ke folder temporary unik (`src/temp/<scan-id>/`).
4. SHA-256 dihitung terlebih dahulu.
5. Jika file berupa arsip, diekstrak secara aman (anti Zip Slip/path traversal/symlink/archive bomb) — termasuk nested archive hingga `maxArchiveDepth`.
6. Setiap file hasil ekstraksi dianalisis: string pattern, entropy, dan YARA.
7. Risk engine menghitung skor berdasarkan **kombinasi** indikator.
8. Bot membalas dengan embed hasil (SAFE/SUSPICIOUS/HIGH/CRITICAL) + tombol **🔎 Detail Scan**.
9. Riwayat scan disimpan ke SQLite (tanpa menyimpan file secara permanen).
10. Seluruh file temporary dihapus otomatis.

---

## 10. Format file yang didukung

`.zip` `.rar` `.7z` `.tar` `.tar.gz` `.tgz` `.lua` `.cs` `.pwn` `.amx` `.txt` `.json` `.js`

---

## 11. Limit scanner

- Ukuran file maksimum: sesuai `maxFileSizeMB` (default 100MB)
- Jumlah file dalam arsip maksimum: sesuai `maxArchiveFiles` (default 1000)
- Kedalaman nested archive maksimum: sesuai `maxArchiveDepth` (default 5)
- Timeout scan: sesuai `scanTimeoutSeconds` (default 120 detik)
- Scan simultan maksimum: sesuai `maxConcurrentScans` (default 3)

---

## 12. Arti status SAFE/SUSPICIOUS/HIGH/CRITICAL

| Skor | Status | Arti |
|---|---|---|
| 0–19 | 🟢 SAFE | Tidak ditemukan indikator berbahaya signifikan |
| 20–39 | 🟠 SUSPICIOUS | Ada indikator yang perlu diperiksa lebih lanjut |
| 40–69 | 🔴 HIGH | Kombinasi indikator kuat — indikasi pencurian data |
| 70–100 | 🔴 CRITICAL | Kombinasi indikator sangat kuat — indikasi pencurian data |

Bot **tidak pernah** menyatakan file "100% aman" — status SAFE berarti tidak
ditemukan indikator signifikan pada saat scan, bukan jaminan mutlak.

---

## 13. Troubleshooting

**Bot tidak merespon saat file diupload**
- Pastikan `/setchannel` sudah dijalankan di channel yang benar.
- Pastikan bot memiliki permission `View Channel`, `Send Messages`, `Attach Files`, `Read Message History` di channel tersebut.
- Pastikan Message Content Intent diaktifkan di [Discord Developer Portal](https://discord.com/developers/applications) → Bot → Privileged Gateway Intents.

**Slash command tidak muncul**
- Jalankan ulang `npm run deploy`.
- Global command dapat memakan waktu hingga 1 jam untuk tersebar ke seluruh server (biasanya jauh lebih cepat).

**YARA scan tidak berjalan / selalu 0 match**
- Pastikan `yara --version` berhasil dijalankan di terminal server.
- Pastikan `yaraCommand` di `config.json` sesuai dengan path/nama binary di environment kamu.

**Error saat ekstraksi `.7z`/`.rar`**
- Pastikan dependency `node-7z` dan `7zip-bin` terinstall dengan benar (`npm install` tanpa error).
- Di beberapa environment terbatas, dependency native ini mungkin tidak tersedia — bot akan melaporkan file tersebut sebagai "tidak dapat diperiksa" alih-alih crash.

**Database error / database.sqlite terkunci**
- Pastikan hanya satu instance bot yang berjalan terhadap file `database.sqlite` yang sama.
- Hapus file `database.sqlite-wal` dan `database.sqlite-shm` jika bot dihentikan secara paksa dan database tampak corrupt (backup dulu `database.sqlite` sebelum mencoba ini).

---

## Struktur Folder

```
discord-file-scanner/
├── index.js
├── package.json
├── .env
├── .env.example
├── config.json
├── README.md
│
├── src/
│   ├── config.js
│   ├── deploy-commands.js
│   │
│   ├── database/
│   │   ├── database.sqlite      (dibuat otomatis)
│   │   └── database.js
│   │
│   ├── commands/
│   │   └── setchannel.js
│   │
│   ├── events/
│   │   ├── ready.js
│   │   ├── interactionCreate.js
│   │   └── messageCreate.js
│   │
│   ├── scanner/
│   │   ├── scanner.js
│   │   ├── yara.js
│   │   ├── strings.js
│   │   ├── entropy.js
│   │   ├── archive.js
│   │   ├── signature.js
│   │   └── risk.js
│   │
│   ├── rules/
│   │   ├── credential_theft.yar
│   │   ├── keylogger.yar
│   │   ├── webhook.yar
│   │   ├── exfiltration.yar
│   │   ├── obfuscation.yar
│   │   └── samp.yar
│   │
│   ├── utils/
│   │   ├── embed.js
│   │   ├── logger.js
│   │   ├── cleanup.js
│   │   └── resultStore.js
│   │
│   └── temp/                    (folder kerja sementara, dikosongkan otomatis)
```

---

## Keamanan

- Seluruh query SQLite menggunakan prepared statements (`better-sqlite3`).
- Ekstraksi arsip memvalidasi setiap path untuk mencegah Zip Slip / path traversal,
  menolak absolute path, dan mengabaikan symlink.
- Limit jumlah file & kedalaman nested archive mencegah archive bomb.
- Pemanggilan YARA melalui `child_process.spawn` dengan argument array (bukan shell
  string) untuk mencegah command/shell injection.
- File yang diupload **tidak pernah dieksekusi** — seluruh analisis bersifat statis.
- File pengguna tidak disimpan permanen; hanya SHA-256 dan metadata scan yang disimpan.
