const db = require('../database/database');

const ytService = require('../services/youtube');

const { uploadToTop4Top } = require('../services/uploader');

const { createMusicEmbed } = require('../embeds/musicEmbed');

const {
    createProgressEmbed,
    createErrorEmbed,
    createWarningEmbed
} = require('../embeds/statusEmbed');

const fs = require('fs');

// Library untuk Spotify info dan Play-DL pencarian YouTube

const spotifyUrlInfo = require('spotify-url-info')(require('isomorphic-unfetch'));

const play = require('play-dl');

function getWIBDate() {
    const d = new Date();
    const wibTime = new Date(d.getTime() + (7 * 60 * 60 * 1000));
    return wibTime.toISOString().split('T')[0];
}

function checkUserStatus(userId) {
    const now = Date.now();
    const premium = db.prepare('SELECT expires_at FROM premium_users WHERE user_id = ?').get(userId);

    if (premium && premium.expires_at > now) {
        return { isPremium: true, maxDuration: Infinity };
    }

    if (premium) {
        db.prepare('DELETE FROM premium_users WHERE user_id = ?').run(userId);
    }

    const today = getWIBDate();
    let userLimit = db.prepare('SELECT * FROM daily_limits WHERE user_id = ?').get(userId);

    if (!userLimit || userLimit.last_reset !== today) {
        db.prepare('INSERT OR REPLACE INTO daily_limits (user_id, count, last_reset) VALUES (?, 0, ?)')
          .run(userId, today);
        userLimit = { count: 0 };
    }

    return { isPremium: false, count: userLimit.count, maxDuration: 3600 };
}

function incrementLimit(userId) {
    const today = getWIBDate();
    db.prepare('UPDATE daily_limits SET count = count + 1 WHERE user_id = ? AND last_reset = ?')
      .run(userId, today);
}

/**
 * Handle konversi Link Spotify
 */
async function handleSpotifyConversion(message, spotifyUrl, forceConvert = false) {
    const embedTitle = forceConvert ? '♻️ Convert Ulang • Mencari lagu Spotify' : '🎵 Memproses Link Spotify';

    const loadingMessage = await message.reply({
        embeds: [createProgressEmbed(message, embedTitle, 10, 'Mengambil metadata dari Spotify...')]
    });

    try {
        // 1. Ambil data lagu dari Spotify URL
        const trackData = await spotifyUrlInfo.getPreview(spotifyUrl);
        const querySearch = `${trackData.title} - ${trackData.artist}`;

        // 2. Update progress: mencari padanan lagu di YouTube
        await loadingMessage.edit({
            embeds: [createProgressEmbed(message, embedTitle, 30, `Mencari **${querySearch}** di YouTube...`)]
        });

        const ytSearch = await play.search(querySearch, { limit: 1, source: { youtube: 'video' } });

        if (!ytSearch || ytSearch.length === 0) {
            const noResultEmbed = createErrorEmbed(
                message,
                '❌ Lagu Tidak Ditemukan',
                `Sistem gagal menemukan padanan lagu **${querySearch}** di platform streaming YouTube.`
            );
            return await loadingMessage.edit({ embeds: [noResultEmbed] });
        }

        const videoUrl = ytSearch[0].url;
        const videoId = ytSearch[0].id;

        // 3. Hapus pesan loading pencarian Spotify, lalu oper ke handler utama youtube convert
        await loadingMessage.delete();
        await handleVideoConversion(message, videoUrl, videoId, forceConvert);

    } catch (error) {
        console.error(error);
        const errorEmbed = createErrorEmbed(
            message,
            '❌ Spotify Fetch Gagal',
            'Gagal mengambil informasi dari link Spotify tersebut.',
            error.message
        );
        if (loadingMessage) await loadingMessage.edit({ embeds: [errorEmbed] });
    }
}

/**
 * Handle inti konversi: download MP3 >>> upload Top4Top >>> kirim hasil
 */
async function handleVideoConversion(message, videoUrl, videoId, forceConvert = false) {
    const userId = message.author.id;

    // Cache hit -> langsung kirim hasil tanpa proses ulang
    if (!forceConvert) {
        const cachedVideo = db.prepare('SELECT * FROM converted_videos WHERE video_id = ?').get(videoId);
        if (cachedVideo) {
            const embed = createMusicEmbed({
                title: cachedVideo.title,
                duration: cachedVideo.duration,
                convertDuration: cachedVideo.convert_duration,
                channel: cachedVideo.channel_name,
                views: cachedVideo.views,
                thumbnail: cachedVideo.thumbnail_url,
                url: cachedVideo.converted_url,
                author: message.author,
                status: `⚡ Diambil langsung dari Database Cache! | ${message.client.user.username} • ${message.guild.name}`
            });
            return message.reply({ embeds: [embed] });
        }
    }

    const userStatus = checkUserStatus(userId);
    if (!userStatus.isPremium && userStatus.count >= 5) {
        const limitEmbed = createWarningEmbed(
            message,
            '⛔ Kuota Harian Habis',
            'Kuota harian kamu habis! (Maks **5x** convert per hari).\nQuota reset otomatis setiap jam **00:00 WIB**.'
        );
        return message.reply({ embeds: [limitEmbed] });
    }

    const embedTitle = forceConvert ? '♻️ Convert Ulang • Memproses Musik' : '🎵 Memproses Musik';

    // Tahap 1/3 - Ambil metadata video (Progres 15%)
    const loadingMessage = await message.reply({
        embeds: [createProgressEmbed(message, embedTitle, 15, 'Mengambil informasi video...')]
    });

    const startTime = Date.now();
    let tempAudioPath = null;

    try {
        const videoInfo = await ytService.getVideoInfo(videoUrl);

        if (!userStatus.isPremium && videoInfo.durationSeconds > userStatus.maxDuration) {
            const durationEmbed = createWarningEmbed(
                message,
                '⛔ Durasi Melebihi Batas',
                'Durasi video melebihi batas maksimal **1 jam** untuk user non-premium!'
            );
            await loadingMessage.delete();
            return message.reply({ embeds: [durationEmbed] });
        }

        // Hard cap absolut (berlaku juga untuk premium): di atas ±6.5 jam, walau bitrate
        // sudah diturunkan ke minimum (32K), hasil MP3-nya tetap berpotensi nabrak limit
        // upload Top4top (±100MB/file anonymous). Jadi ditolak dari awal, bukan pas upload gagal.
        const ABSOLUTE_MAX_DURATION_SECONDS = 23400; // 6.5 jam
        if (videoInfo.durationSeconds > ABSOLUTE_MAX_DURATION_SECONDS) {
            const tooLongEmbed = createWarningEmbed(
                message,
                '⛔ Video Terlalu Panjang',
                `Durasi video (**${videoInfo.durationString}**) melebihi batas absolut **6.5 jam** yang didukung hosting upload saat ini, berlaku untuk semua user termasuk premium.`
            );
            await loadingMessage.delete();
            return message.reply({ embeds: [tooLongEmbed] });
        }

        const qualityHint = ytService.getAudioQuality(videoInfo.durationSeconds);
        const engineHint = videoInfo.durationSeconds >= 600 ? 'aria2c' : 'ffmpeg';

        // Tahap 2/3 - Download MP3 (kualitas & engine download otomatis menyesuaikan durasi agar tetap cepat) (Progres 45%)
        // Tidak di-await: update UI ini gak perlu nunggu round-trip Discord API kelar
        // dulu baru mulai download, biar prosesnya langsung jalan berbarengan.
        loadingMessage.edit({
            embeds: [createProgressEmbed(
                message,
                embedTitle,
                45,
                `Mengunduh & mengonversi audio (**${qualityHint}** • engine **${engineHint}**)...`
            )]
        }).catch(() => {});

        // 1. DOWNLOAD MP3 (durasi panjang otomatis pakai aria2c multi-koneksi, durasi pendek cukup ffmpeg)
        const { audioPath, downloader } = await ytService.processAudio(videoUrl, videoId, videoInfo.durationSeconds);
        tempAudioPath = audioPath;
        console.log(`[Convert] videoId=${videoId} durasi=${videoInfo.durationSeconds}s downloader=${downloader} quality=${qualityHint}`);

        // Tahap 3/3 - Upload ke Top4Top (Progres 80%)
        loadingMessage.edit({
            embeds: [createProgressEmbed(message, embedTitle, 80, 'Mengunggah hasil ke Top4Top...')]
        }).catch(() => {});

        const safeTitle = `${videoInfo.title.replace(/[^a-zA-Z0-9]/g, '_')}.mp3`;

        // 2. UPLOAD TOP4TOP
        const downloadLink = await uploadToTop4Top(tempAudioPath, safeTitle);

        const processedTime = Math.round((Date.now() - startTime) / 1000) + ' detik';

        db.prepare(`
            INSERT OR REPLACE INTO converted_videos (video_id, title, duration, convert_duration, channel_name, views, thumbnail_url, converted_url)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `).run(videoId, videoInfo.title, videoInfo.durationString, processedTime, videoInfo.channelName, videoInfo.views, videoInfo.thumbnailUrl, downloadLink);

        if (!userStatus.isPremium) {
            incrementLimit(userId);
        }

        // 3. KIRIM HASIL (embed hasil akhir dipertahankan sama seperti sebelumnya)
        const embed = createMusicEmbed({
            title: videoInfo.title,
            duration: videoInfo.durationString,
            convertDuration: processedTime,
            channel: videoInfo.channelName,
            views: videoInfo.views,
            thumbnail: videoInfo.thumbnailUrl,
            url: downloadLink,
            author: message.author,
            status: forceConvert
                ? `♻️ Berhasil diconvert ulang dan memperbarui database! | ${message.client.user.username} • ${message.guild.name}`
                : `✅ Berhasil dikonversi dan disimpan ke cache! | ${message.client.user.username} • ${message.guild.name}`
        });

        await loadingMessage.edit({ embeds: [embed] });

    } catch (error) {
        console.error(error);
        const errorEmbed = createErrorEmbed(
            message,
            '❌ Proses Konversi Gagal',
            'Terjadi kesalahan internal saat memproses video ke Top4Top.',
            error.message
        );
        if (loadingMessage) await loadingMessage.edit({ embeds: [errorEmbed] });
    } finally {
        if (tempAudioPath && fs.existsSync(tempAudioPath)) fs.unlinkSync(tempAudioPath);
    }
}

module.exports = {
    checkUserStatus,
    incrementLimit,
    handleVideoConversion,
    handleSpotifyConversion
};
