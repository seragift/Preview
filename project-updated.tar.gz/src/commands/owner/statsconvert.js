const { SlashCommandBuilder } = require('discord.js');

const db = require('../../database/database');

const config = require('../../../config.json');

const { createInfoEmbed, createErrorEmbed } = require('../../embeds/statusEmbed');

function getWIBDate() {
    const d = new Date();
    const wibTime = new Date(d.getTime() + (7 * 60 * 60 * 1000));
    return wibTime.toISOString().split('T')[0];
}

function formatUptime(seconds) {
    const d = Math.floor(seconds / 86400);
    const h = Math.floor((seconds % 86400) / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);
    return `${d}h ${h}j ${m}m ${s}d`.replace('0h ', '');
}

function formatBytes(bytes) {
    return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
}

// Rata-rata & terlama/tercepat dihitung dari kolom convert_duration (format teks "X detik")
function getConvertDurationStats() {
    const rows = db.prepare('SELECT convert_duration FROM converted_videos').all();
    const seconds = rows
        .map(r => parseInt(String(r.convert_duration).replace(/[^0-9]/g, ''), 10))
        .filter(n => !isNaN(n));

    if (!seconds.length) return { avg: null, fastest: null, slowest: null };

    const avg = Math.round(seconds.reduce((a, b) => a + b, 0) / seconds.length);
    return { avg, fastest: Math.min(...seconds), slowest: Math.max(...seconds) };
}

module.exports = {

    data: new SlashCommandBuilder()

        .setName('statsconvert')

        .setDescription('Melihat statistik database converter (Owner Only)'),

    async execute(interaction) {

        if (interaction.user.id !== config.ownerId) {

            return interaction.reply({
                embeds: [createErrorEmbed(interaction, '❌ Akses Ditolak', 'Perintah ini hanya bisa diakses oleh Owner Bot!')],
                ephemeral: true
            });

        }

        const today = getWIBDate();

        const totalCache = db.prepare('SELECT COUNT(*) as total FROM converted_videos').get().total;
        const totalPremium = db.prepare('SELECT COUNT(*) as total FROM premium_users').get().total;
        const totalChannel = db.prepare('SELECT COUNT(*) as total FROM active_channels').get().total;

        const todayRow = db.prepare(
            'SELECT COALESCE(SUM(count), 0) as totalCount, COUNT(*) as totalUsers FROM daily_limits WHERE last_reset = ? AND count > 0'
        ).get(today);

        const lastVideo = db.prepare('SELECT title FROM converted_videos ORDER BY rowid DESC LIMIT 1').get();

        const { avg, fastest, slowest } = getConvertDurationStats();

        const mem = process.memoryUsage();

        return interaction.reply({

            embeds: [createInfoEmbed(
                interaction,
                '📊 Statistik Bot Converter',
                'Ringkasan lengkap data cache, aktivitas, dan performa converter saat ini.',
                [
                    { name: '🗄️ Total Video di Cache', value: `**${totalCache}**`, inline: true },
                    { name: '💎 User Premium Aktif', value: `**${totalPremium}**`, inline: true },
                    { name: '📺 Channel Aktif (setchannel)', value: `**${totalChannel}**`, inline: true },
                    { name: '🔄 Konversi Hari Ini', value: `**${todayRow.totalCount}x**`, inline: true },
                    { name: '👤 User Aktif Hari Ini', value: `**${todayRow.totalUsers}** user`, inline: true },
                    { name: '🎬 Terakhir Dikonversi', value: lastVideo ? `${lastVideo.title.slice(0, 40)}` : '-', inline: true },
                    {
                        name: '⏱️ Rata-rata Waktu Proses',
                        value: avg !== null ? `**${avg} detik**` : '-',
                        inline: true
                    },
                    {
                        name: '⚡ Tercepat / Terlama',
                        value: avg !== null ? `**${fastest}d** / **${slowest}d**` : '-',
                        inline: true
                    },
                    { name: '💾 Memori Proses', value: `${formatBytes(mem.rss)}`, inline: true },
                    { name: '🕐 Uptime Bot', value: `${formatUptime(process.uptime())}`, inline: true }
                ]
            )]

        });

    }

};
