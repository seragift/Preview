const Database = require('better-sqlite3');

const path = require('path');

const db = new Database(path.join(__dirname, 'database.db'));

// Tabel Cache Video

db.prepare(`

    CREATE TABLE IF NOT EXISTS converted_videos (

        video_id TEXT PRIMARY KEY,

        title TEXT,

        duration INTEGER,

        convert_duration TEXT,

        channel_name TEXT,

        views TEXT,

        thumbnail_url TEXT,

        converted_url TEXT

    )

`).run();

// Tabel User Premium

db.prepare(`

    CREATE TABLE IF NOT EXISTS premium_users (

        user_id TEXT PRIMARY KEY,

        expires_at INTEGER

    )

`).run();

// Tabel Limit Harian Non-Premium

db.prepare(`

    CREATE TABLE IF NOT EXISTS daily_limits (

        user_id TEXT PRIMARY KEY,

        count INTEGER DEFAULT 0,

        last_reset TEXT

    )

`).run();

// Tabel Setchannel

db.prepare(`

    CREATE TABLE IF NOT EXISTS active_channels (

        channel_id TEXT PRIMARY KEY

    )

`).run();

module.exports = db;