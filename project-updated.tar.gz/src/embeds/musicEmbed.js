const { EmbedBuilder } = require('discord.js');

module.exports = {

    createMusicEmbed: (data) => {

        return new EmbedBuilder()

            .setColor('#16A085')

            .setTitle('🎵 Music Berhasil Diproses!')

            .setDescription(`Berikut adalah detail lagu yang sudah diproses untuk ${data.author || 'User'}:\`\n**Selesai dalam waktu:** ${data.convertDuration}`)

            .setThumbnail(data.thumbnail)

            .addFields(

                { name: '📝 Judul Lagu', value: data.title, inline: false },

                { name: '⏱️ Durasi', value: data.duration, inline: true },

                { name: '📺 Channel', value: data.channel, inline: true },

                { name: '👁️ Views', value: data.views, inline: true },

                { name: '🔗 Link Download', value: `${data.url}`, inline: false }

            )

            .setFooter({ text: data.status })

            .setTimestamp();

    }

};