const db = require('../database/database');

const { handleVideoConversion, handleSpotifyConversion } = require('../utils/converModal');

const { createWarningEmbed } = require('../embeds/statusEmbed');

// Regex Penjaga

const YT_REGEX = /(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:[^\/\n\s]+\/\S+\/|(?:v|e(?:mbed)?)\/|\S*?[?&]v=)|youtu\.be\/)([a-zA-Z0-9_-]{11})/;

const SPOTIFY_REGEX = /https?:\/\/open\.spotify\.com\/track\/([a-zA-Z0-9]+)/;

module.exports = {

    name: 'messageCreate',

    async execute(message) {

        if (message.author.bot || !message.guild) return;

        const isChannelActive = db.prepare('SELECT channel_id FROM active_channels WHERE channel_id = ?').get(message.channel.id);

        if (!isChannelActive) return;

        const content = message.content.trim();

        let forceConvert = false;

        let targetText = content;

        // 1. Deteksi Command Manual !convert

        if (content.toLowerCase().startsWith('!convert')) {

            forceConvert = true;

            targetText = content.slice('!convert'.length).trim();

        }

        // 2. Filter Jalur Tautan (Spotify vs YouTube)

        const matchSpotify = targetText.match(SPOTIFY_REGEX);

        if (matchSpotify) {

            const spotifyUrl = matchSpotify[0];

            return await handleSpotifyConversion(message, spotifyUrl, forceConvert);

        }

        const matchYoutube = targetText.match(YT_REGEX);

        if (matchYoutube) {

            const videoUrl = matchYoutube[0];

            const videoId = matchYoutube[1];

            return await handleVideoConversion(message, videoUrl, videoId, forceConvert);

        }

        // Jika mengetik !convert tapi tidak memasukkan link yang valid

        if (forceConvert) {

            return message.reply({
                embeds: [createWarningEmbed(
                    message,
                    '⚠️ Tautan Tidak Valid',
                    'Gunakan format berikut untuk melakukan convert:\n```!convert <URL YouTube / Spotify>```'
                )]
            });

        }

    }

};
