const { Events, REST, Routes } = require('discord.js');

const config = require('../../config.json');

const ytService = require('../services/youtube');

module.exports = {

    name: Events.ClientReady,

    once: true,

    async execute(client) {

        // Inisialisasi komponen yt-dlp bawaan kamu

        await ytService.initYtdlp();

        console.log(`Bot berhasil online sebagai ${client.user.tag}!`);

        const commands = Array.from(client.commands.values()).map(cmd => cmd.data.toJSON());

        const rest = new REST({ version: '10' }).setToken(config.token);

        try {

            console.log('🔄 Menyegarkan application (/) commands secara Global...');

            await rest.put(

                Routes.applicationCommands(config.clientId),

                { body: commands },

            );

            console.log('✅ Berhasil meregistrasi commands secara Global.');

        } catch (error) {

            console.error('❌ Gagal meregistrasi slash commands:', error);

        }

    },

};