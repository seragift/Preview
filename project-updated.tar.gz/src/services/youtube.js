const YTDlpWrap = require('yt-dlp-wrap').default;
const path = require('path');
const fs = require('fs');

const ytdlpPath = path.join(process.cwd(), 'yt-dlp');
let ytdlp;

async function initYtdlp() {
    if (!fs.existsSync(ytdlpPath)) {
        console.log('📥 yt-dlp tidak ditemukan. Mengunduh yt-dlp otomatis...');
        try {
            await YTDlpWrap.downloadFromGithub(ytdlpPath);
            fs.chmodSync(ytdlpPath, '755');
            console.log('✅ yt-dlp berhasil diunduh otomatis!');
        } catch (err) {
            console.error('❌ Gagal mengunduh yt-dlp otomatis:', err);
            process.exit(1);
        }
    }
    ytdlp = new YTDlpWrap(ytdlpPath);
}

function formatDuration(seconds) {
    if (!seconds) return '00:00';
    const date = new Date(0);
    date.setSeconds(seconds);
    const timeString = date.toISOString().substr(11, 8);
    return timeString.startsWith('00:') ? timeString.substr(3) : timeString;
}

/**
 * Tentukan bitrate audio berdasarkan durasi video.
 * Video panjang otomatis diturunkan kualitasnya, DUA alasan:
 * 1) proses download+convert jauh lebih cepat
 * 2) Top4top (anonymous/tanpa akun) punya limit ±100MB per file — video berjam-jam
 *    di bitrate tinggi bakal nabrak limit itu dan bikin upload gagal/return halaman error
 *    (yang sebelumnya nongol sebagai "Gagal memparsing link upload Top4top").
 * Tabel di bawah dijaga supaya estimasi ukuran file tetap di bawah ±90MB (kasih margin aman).
 */
function getAudioQuality(durationSeconds = 0) {
    if (durationSeconds >= 10800) return '32K';  // >= 3 jam  -> ~90MB di 3 jam, aman di bawah limit
    if (durationSeconds >= 7200)  return '48K';  // >= 2 jam
    if (durationSeconds >= 3600)  return '64K';  // >= 1 jam
    if (durationSeconds >= 1800)  return '96K';  // >= 30 menit -> prioritas kecepatan
    if (durationSeconds >= 600)   return '128K'; // >= 10 menit -> kualitas menengah
    return '192K';                               // < 10 menit -> kualitas penuh
}

async function getVideoInfo(videoUrl) {
    if (!ytdlp) await initYtdlp();
    const metadata = await ytdlp.getVideoInfo(videoUrl);

    // Cari thumbnail terbaik
    const thumbnail = metadata.thumbnail || (metadata.thumbnails && metadata.thumbnails.length ? metadata.thumbnails[metadata.thumbnails.length - 1].url : 'https://i.imgur.com/8Q5FqW0.png');

    return {
        title: metadata.title || 'Unknown Title',
        durationSeconds: metadata.duration || 0,
        durationString: formatDuration(metadata.duration),
        channelName: metadata.uploader || 'Unknown Channel',
        views: metadata.view_count ? metadata.view_count.toLocaleString('id-ID') : '0',
        thumbnailUrl: thumbnail
    };
}

// Ambang batas durasi buat nentuin strategi download (detik)
const ARIA2_THRESHOLD_SECONDS = 600; // >= 10 menit

/**
 * Video panjang -> aria2c sebagai external downloader (multi-koneksi paralel, paling ngebut).
 * Video pendek/menengah -> native downloader yt-dlp TAPI tetap dipaksa chunked/paralel via
 * --http-chunk-size + --concurrent-fragments, jadi tetap dapet speed boost tanpa perlu
 * spawn proses tambahan (aria2c) yang overhead-nya gak worth it buat file kecil.
 */
function getDownloaderArgs(durationSeconds = 0) {
    if (durationSeconds >= ARIA2_THRESHOLD_SECONDS) {
        return ['--downloader', 'aria2c', '--downloader-args', 'aria2c:-x 16 -s 16 -k 1M'];
    }
    return ['--http-chunk-size', '10M', '--concurrent-fragments', '4'];
}

/**
 * Download + convert ke MP3 dalam SATU proses yt-dlp (ekstraksi audio langsung),
 * menggantikan alur lama (download mp4 mentah -> convert terpisah via fluent-ffmpeg).
 * Ini menghilangkan satu tahap I/O penuh (tidak ada lagi file video mentah di disk)
 * sehingga proses jauh lebih cepat, ditambah kualitas dinamis untuk video panjang.
 *
 * PENTING: '-f bestaudio/best' memaksa yt-dlp ambil stream AUDIO-ONLY dari YouTube,
 * bukan video+audio gabungan lalu di-strip. Sebelumnya flag ini nggak ada, jadi selama
 * ini kemungkinan besar tetap download videonya juga (sia-sia, karena cuma butuh audio) —
 * ini optimasi speed paling signifikan dari semuanya.
 */
async function processAudio(videoUrl, videoId, durationSeconds = 0) {
    if (!ytdlp) await initYtdlp();

    const tempAudioPath = path.join(process.cwd(), `audio_${videoId}.mp3`);
    const audioQuality = getAudioQuality(durationSeconds);
    const usingAria2 = durationSeconds >= ARIA2_THRESHOLD_SECONDS;

    const baseArgs = [
        videoUrl,
        '-f', 'bestaudio/best',
        '-x',
        '--audio-format', 'mp3',
        '--audio-quality', audioQuality,
        '--no-playlist',
        '--no-write-info-json',
        '--no-write-thumbnail',
        '-o', tempAudioPath
    ];

    try {
        await ytdlp.execPromise([...baseArgs, ...getDownloaderArgs(durationSeconds)]);
    } catch (err) {
        // Fallback: kalau aria2c belum terinstall di container (ENOENT/exec gagal),
        // otomatis retry pakai native chunked downloader biar tetap jalan.
        if (usingAria2 && /aria2c|ENOENT|not found/i.test(err.message || '')) {
            console.warn('⚠️ aria2c gagal dipanggil, fallback ke native chunked downloader:', err.message);
            await ytdlp.execPromise([...baseArgs, '--http-chunk-size', '10M', '--concurrent-fragments', '4']);
            return { audioPath: tempAudioPath, quality: audioQuality, downloader: 'ffmpeg (fallback)' };
        }
        throw err;
    }

    return { audioPath: tempAudioPath, quality: audioQuality, downloader: usingAria2 ? 'aria2c' : 'ffmpeg' };
}

module.exports = {
    initYtdlp,
    getVideoInfo,
    processAudio,
    getAudioQuality,
    getDownloaderArgs
};
