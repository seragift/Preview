const axios = require('axios');

const FormData = require('form-data');

const fs = require('fs');

// Top4top (upload anonymous/tanpa akun) membatasi ±100MB per file.
// Kasih margin aman di 95MB supaya kita gagal cepat dengan pesan jelas,
// daripada nunggu upload penuh baru ketahuan ditolak server.
const MAX_UPLOAD_BYTES = 95 * 1024 * 1024;

module.exports = {

    uploadToTop4Top: async (filePath, fileName) => {

        const { size } = fs.statSync(filePath);

        if (size > MAX_UPLOAD_BYTES) {
            const sizeMB = (size / 1024 / 1024).toFixed(1);
            throw new Error(
                `Ukuran hasil audio (${sizeMB}MB) melebihi batas upload Top4top (±100MB/file untuk anonymous upload). ` +
                `Ini biasanya kejadian di video yang durasinya sangat panjang (berjam-jam).`
            );
        }

        const formData = new FormData();

        formData.append('file_0_', fs.createReadStream(filePath), {

            filename: fileName,

            contentType: 'audio/mpeg'

        });

        formData.append('submitr', 'تحميل الملفات');

        const response = await axios.post('https://top4top.io/index.php', formData, {

            headers: {

                ...formData.getHeaders(),

                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'

            },

            maxContentLength: Infinity,

            maxBodyLength: Infinity

        });

        const html = response.data;

        const linkMatch = html.match(/value="(https:\/\/top4top\.io\/downloadf-[^"]+)"/) || 

                          html.match(/href="(https?:\/\/b\.top4top\.io\/m_[^"]+\.mp3)"/) ||

                          html.match(/value="(https?:\/\/.\.top4top\.io\/m_[^"]+\.mp3)"/);

        if (!linkMatch) {
            const sizeMB = (size / 1024 / 1024).toFixed(1);
            const looksLikeSizeError = /حجم|كبير|large|size/i.test(html);
            throw new Error(
                looksLikeSizeError
                    ? `Top4top menolak file (${sizeMB}MB) — kemungkinan besar karena ukuran file terlalu besar.`
                    : `Gagal memparsing link upload Top4top (ukuran file: ${sizeMB}MB). Kemungkinan struktur halaman Top4top berubah atau server sedang bermasalah.`
            );
        }

        return linkMatch[1];

    }

};