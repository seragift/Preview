# Community Moderation Bot

Bot Discord moderasi multi-server dengan SQLite.

## Setup

1. Install dependency:
   ```
   npm install
   ```
2. Copy `.env.example` menjadi `.env`, isi `TOKEN` dan `CLIENT_ID`.
3. Isi `apiBaseUrl` di `config.json` dengan base URL API downloader/search kamu (contoh: `https://api.domainkamu.com`). Tanpa ini, fitur downloader/search/BMKG tidak akan jalan.
4. Jalankan bot:
   ```
   npm start
   ```
   Setiap kali `npm start` dijalankan, bot otomatis **bulk-overwrite semua slash command** (upload ulang command terbaru, command lama yang tidak ada di kode otomatis kehapus) sebelum login (lihat `deploy-commands.js`). Tidak perlu jalankan `npm run deploy` manual lagi, tapi command itu masih tersedia kalau mau deploy tanpa menyalakan bot.

## Izin Bot yang Dibutuhkan (Discord Developer Portal & saat invite)

- **Intents**: Server Members Intent, Message Content Intent (aktifkan di Bot tab)
- **Permissions saat invite**: Kick Members, Ban Members, Manage Roles, Manage Messages, Manage Webhooks, View Audit Log, Send Messages, Embed Links, Attach Files, Read Message History

## Fitur

| Kategori | Command |
|---|---|
| Moderasi | `/kick`, `/ban`, `/clear`, `/giverole`, `/removerole` |
| Temprole | `/temprole`, `/temproleedit`, `/temprolelist` |
| Security | `/antilink on/off`, `/antispam on/off`, `/antiwebhook on/off`, `/modlog set|view`, `/securityinfo`, `/whitelist` |
| Announcement | `/ann` (title, description, image, icon, tag role, button link) |
| Downloader Setup | `/setchannel`, `/removechannel` (bmkg/tiktok/all) |
| Search | `/pinterest`, `/tokopedia`, `/wikipedia` (embed dengan navigasi ◀️▶️, maks 10 hasil) |
| Utility | `/help` |

## Fitur Downloader Otomatis (TikTok)

Setelah `/setchannel #channel tiktok` (atau `all`) diatur, user tinggal **kirim link TikTok biasa** ke channel tersebut — bot otomatis mendeteksi link, mengunduh video-nya (bukan cuma link, filenya beneran di-attach ke Discord), dan membalas dengan file tersebut. Kalau video gagal diunduh atau kekurangan format, bot fallback ke slideshow foto (kalau post-nya foto), lalu fallback ke thumbnail saja. Ukuran file dibatasi ~24MB (batas upload bot Discord tanpa boost). Link yang diproses dengan cara ini otomatis dilewatkan dari Anti-Link.

## Fitur BMKG Otomatis

Setelah `/setchannel #channel bmkg`, bot mengecek endpoint gempa BMKG setiap 5 menit (`src/scheduler/bmkgChecker.js`) dan mengirim embed otomatis ke channel tersebut kalau ada data gempa baru (dibandingkan berdasarkan ID/waktu terakhir yang tersimpan per server).

## Catatan Soal API (Stenly)

Field mapping sudah dikonfirmasi langsung dari `https://stenly.org` (per 13 Sep 2026):

- **Tokopedia**: param `query`, response `{ Result: [{ Name, Url, Image, Price, Rating, Sold, Shop:{Name,City} }] }`
- **Pinterest**: param `q`, response `{ data: [{ title, url, image, thumbnail }] }`
- **Wikipedia**: param `query`, response cuma **1 artikel** `{ Result: { Title, Extract, Url, Images:[{Url}] } }` — bukan list. Navigasi ◀️▶️ di `/wikipedia` dipakai untuk browsing galeri gambar artikel tersebut, bukan artikel lain.
- **TikTok**: param `url`, response `{ Result: { Title, Thumbnail, Downloads:[{Type,Url}] } }` — bot mencoba download video dari `Downloads` (utamakan yang HD), fallback ke slideshow foto, fallback ke thumbnail.
- **BMKG**: tanpa param, response `{ data: { tanggal, jam, magnitudo, kedalaman, wilayah, image_url } }`

> Spotify & CapCut sudah **dihapus** dari bot ini (endpoint-nya bermasalah di sisi provider saat dites — Spotify selalu error identik, CapCut `"Failed to parse response"`). Kalau providernya sudah normal lagi nanti, tinggal tambahkan lagi function-nya di `src/utils/apiClient.js` mengikuti pola yang sama.

Requires **Node.js 18+** (dipakai `fetch` bawaan Node, tidak ada dependency HTTP client tambahan).

## Catatan Teknis

- Semua setting security (antilink/antispam/antiwebhook, channel modlog) disimpan **per server** di tabel `guild_configs`.
- `/whitelist` menyimpan pengecualian **per channel dan/atau per role** untuk tiap fitur security (`antilink`, `antispam`, `antiwebhook`) di tabel `whitelists`. Tidak ada lagi whitelist domain di `config.json` — begitu Anti-Link ON, **semua link dihapus** kecuali channel/role tersebut ada di whitelist.
- Anti-Spam: begitu batas pesan tercapai (default 5 pesan / 5 detik di `config.json`), **semua pesan** dalam rentang tersebut ikut dihapus (bulk delete), bukan cuma pesan terakhir, lalu user di-timeout.
- Anti-Webhook: mendeteksi via Audit Log lalu langsung menghapus webhook yang baru dibuat — kecuali channel tempat webhook dibuat atau role pembuatnya ada di whitelist.
- User dengan permission **Manage Messages** otomatis bypass Anti-Link & Anti-Spam (tetap berlaku terlepas dari whitelist).
- Temprole dicek tiap 30 detik oleh scheduler (`src/scheduler/temproleChecker.js`) untuk auto-remove role expired.
- Database file otomatis dibuat di `database/bot.db` saat bot pertama kali dijalankan.
