# Community Moderation Bot

Bot Discord moderasi multi-server dengan SQLite.

## Setup

1. Install dependency:
   ```
   npm install
   ```
2. Copy `.env.example` menjadi `.env`, isi `TOKEN` dan `CLIENT_ID`.
3. Jalankan bot:
   ```
   npm start
   ```
   Setiap kali `npm start` dijalankan, bot otomatis **bulk-overwrite semua slash command** (upload ulang command terbaru, command lama yang tidak ada di kode otomatis kehapus) sebelum login (lihat `deploy-commands.js`). Tidak perlu jalankan `npm run deploy` manual lagi, tapi command itu masih tersedia kalau mau deploy tanpa menyalakan bot.

## Izin Bot yang Dibutuhkan (Discord Developer Portal & saat invite)

- **Intents**: Server Members Intent, Message Content Intent (aktifkan di Bot tab)
- **Permissions saat invite**: Kick Members, Ban Members, Manage Roles, Manage Messages, Manage Webhooks, View Audit Log, Send Messages, Embed Links, Attach Files, Read Message History

## Fitur

| Kategori | Command |
|---|---|
| Moderasi | `/kick`, `/ban`, `/clear`, `/giverole`, `/removerole` |
| Temprole | `/temprole`, `/temproleedit`, `/temprolelist` |
| Security | `/antilink on/off`, `/antispam on/off`, `/antiwebhook on/off`, `/modlog set|view`, `/securityinfo`, `/whitelist` |
| Announcement | `/ann` (title, description, image, icon, tag role, button link) |
| Search | `/pinterest` (embed navigasi ◀️▶️, hanya hasil bergambar, maks 10) |
| Utility | `/help` |

## Catatan Teknis

- Semua setting security (antilink/antispam/antiwebhook, channel modlog) disimpan **per server** di tabel `guild_configs`.
- `/whitelist` menyimpan pengecualian **per channel dan/atau per role** untuk tiap fitur security (`antilink`, `antispam`, `antiwebhook`) di tabel `whitelists`. Begitu Anti-Link ON, **semua link dihapus** kecuali channel/role tersebut ada di whitelist.
- Anti-Spam: begitu batas pesan tercapai (default 5 pesan / 5 detik di `config.json`), **semua pesan** dalam rentang tersebut ikut dihapus (bulk delete), bukan cuma pesan terakhir, lalu user di-timeout.
- Anti-Webhook: mendeteksi via Audit Log lalu langsung menghapus webhook yang baru dibuat — kecuali channel tempat webhook dibuat atau role pembuatnya ada di whitelist.
- User dengan permission **Manage Messages** otomatis bypass Anti-Link & Anti-Spam (tetap berlaku terlepas dari whitelist).
- Temprole dicek tiap 30 detik oleh scheduler (`src/scheduler/temproleChecker.js`) untuk auto-remove role expired.
- Database file otomatis dibuat di `database/bot.db` saat bot pertama kali dijalankan.
