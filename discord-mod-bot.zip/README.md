# Community Moderation Bot

Bot Discord moderasi multi-server dengan SQLite.

## Setup

1. Install dependency:
   ```
   npm install
   ```
2. Copy `.env.example` menjadi `.env`, isi `TOKEN` dan `CLIENT_ID`.
3. Isi `apiBaseUrl` di `config.json` dengan base URL API downloader/search kamu (contoh: `https://api.domainkamu.com`). Tanpa ini, fitur downloader/search/BMKG tidak akan jalan.
4. Jalankan bot:
   ```
   npm start
   ```
   Setiap kali `npm start` dijalankan, bot otomatis **bulk-overwrite semua slash command** (upload ulang command terbaru, command lama yang tidak ada di kode otomatis kehapus) sebelum login (lihat `deploy-commands.js`). Tidak perlu jalankan `npm run deploy` manual lagi, tapi command itu masih tersedia kalau mau deploy tanpa menyalakan bot.

## Izin Bot yang Dibutuhkan (Discord Developer Portal & saat invite)

- **Intents**: Server Members Intent, Message Content Intent (aktifkan di Bot tab)
- **Permissions saat invite**: Kick Members, Ban Members, Manage Roles, Manage Messages, Manage Webhooks, View Audit Log, Send Messages, Embed Links, Attach Files, Read Message History

## Fitur

| Kategori | Command |
|---|---|
| Moderasi | `/kick`, `/ban`, `/clear`, `/giverole`, `/removerole` |
| Temprole | `/temprole`, `/temproleedit`, `/temprolelist` |
| Security | `/antilink on/off`, `/antispam on/off`, `/antiwebhook on/off`, `/modlog set|view`, `/securityinfo`, `/whitelist` |
| Announcement | `/ann` (title, description, image, icon, tag role, button link) |
| Downloader Setup | `/setchannel`, `/removechannel` (bmkg/spotify/tiktok/capcut/all) |
| Search | `/pinterest`, `/tokopedia`, `/wikipedia` (embed dengan navigasi ◀️▶️, maks 10 hasil) |
| Utility | `/help` |

## Fitur Downloader Otomatis (Spotify/TikTok/CapCut)

Setelah `/setchannel #channel spotify` (atau tiktok/capcut/all) diatur, user tinggal **kirim link biasa** ke channel tersebut — bot otomatis mendeteksi link dan memprosesnya lewat API, lalu membalas dengan embed + tombol Download. Link yang diproses dengan cara ini otomatis dilewatkan dari Anti-Link.

## Fitur BMKG Otomatis

Setelah `/setchannel #channel bmkg`, bot mengecek endpoint gempa BMKG setiap 5 menit (`src/scheduler/bmkgChecker.js`) dan mengirim embed otomatis ke channel tersebut kalau ada data gempa baru (dibandingkan berdasarkan ID/waktu terakhir yang tersimpan per server).

## Catatan Penting Soal API

Endpoint (`/api/downloader/spotify`, `/api/downloader/tiktok`, `/api/downloader/capcut`, `/api/search/pinterest`, `/api/search/wikipedia`, `/api/info/gempa`, `/api/tokopedia`) sudah di-wire di `src/utils/apiClient.js`, tapi **nama parameter query (`url`/`q`) dan struktur field response (misal `data.title`, `data.thumbnail`, `item.image`, dst) adalah ASUMSI umum** karena dokumentasi API asli tidak saya ketahui persis. Kalau hasil di Discord kosong/aneh (gambar tidak muncul, harga tidak muncul, dsb), cek response asli API-nya lalu sesuaikan nama field di:
- `src/utils/apiClient.js` (path & parameter)
- `src/events/messageCreate.js` → `handleDownloaderLinks()` (field Spotify/TikTok/CapCut)
- `src/scheduler/bmkgChecker.js` → `buildGempaEmbed()` (field BMKG)
- `src/commands/search/pinterest.js`, `tokopedia.js`, `wikipedia.js` (field per item)

Requires **Node.js 18+** (dipakai `fetch` bawaan Node, tidak ada dependency HTTP client tambahan).

## Catatan Teknis

- Semua setting security (antilink/antispam/antiwebhook, channel modlog) disimpan **per server** di tabel `guild_configs`.
- `/whitelist` menyimpan pengecualian **per channel dan/atau per role** untuk tiap fitur security (`antilink`, `antispam`, `antiwebhook`) di tabel `whitelists`. Tidak ada lagi whitelist domain di `config.json` — begitu Anti-Link ON, **semua link dihapus** kecuali channel/role tersebut ada di whitelist.
- Anti-Spam: begitu batas pesan tercapai (default 5 pesan / 5 detik di `config.json`), **semua pesan** dalam rentang tersebut ikut dihapus (bulk delete), bukan cuma pesan terakhir, lalu user di-timeout.
- Anti-Webhook: mendeteksi via Audit Log lalu langsung menghapus webhook yang baru dibuat — kecuali channel tempat webhook dibuat atau role pembuatnya ada di whitelist.
- User dengan permission **Manage Messages** otomatis bypass Anti-Link & Anti-Spam (tetap berlaku terlepas dari whitelist).
- Temprole dicek tiap 30 detik oleh scheduler (`src/scheduler/temproleChecker.js`) untuk auto-remove role expired.
- Database file otomatis dibuat di `database/bot.db` saat bot pertama kali dijalankan.
