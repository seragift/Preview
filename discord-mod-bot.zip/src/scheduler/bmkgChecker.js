const serviceChannels = require('../database/models/serviceChannels');
const bmkgState = require('../database/models/bmkgState');
const { extractObject } = require('../utils/responseUtil');
const { baseEmbed } = require('../utils/embed');
const api = require('../utils/apiClient');
const logger = require('../utils/logger');

const CHECK_INTERVAL_MS = 5 * 60 * 1000; // 5 minutes

function buildGempaEmbed(data) {
  return baseEmbed()
    .setTitle('🌏 Info Gempa BMKG')
    .addFields(
      { name: 'Magnitudo', value: String(data.magnitude || data.magnitudo || '-'), inline: true },
      { name: 'Kedalaman', value: String(data.depth || data.kedalaman || '-'), inline: true },
      { name: 'Wilayah', value: String(data.region || data.wilayah || data.lokasi || '-'), inline: false },
      { name: 'Waktu', value: String(data.time || data.waktu || data.tanggal || '-'), inline: false }
    )
    .setImage(data.shakemap || data.image || null);
}

function getQuakeId(data) {
  return data.id || data.datetime || data.time || data.tanggal || JSON.stringify(data).slice(0, 100);
}

function startBmkgChecker(client) {
  setInterval(async () => {
    let raw;
    try {
      raw = await api.infoGempa();
    } catch (err) {
      logger.error('Gagal ambil data BMKG:', err);
      return;
    }

    const data = extractObject(raw);
    if (!data || Object.keys(data).length === 0) return;

    const quakeId = getQuakeId(data);

    for (const guild of client.guilds.cache.values()) {
      const channelId = serviceChannels.getChannel(guild.id, 'bmkg');
      if (!channelId) continue;

      const lastId = bmkgState.getLastQuakeId(guild.id);
      if (lastId === quakeId) continue;

      const channel = guild.channels.cache.get(channelId);
      if (!channel) continue;

      await channel.send({ embeds: [buildGempaEmbed(data)] }).catch((err) => {
        logger.error(`Gagal kirim info BMKG ke guild ${guild.id}:`, err);
      });
      bmkgState.setLastQuakeId(guild.id, quakeId);
    }
  }, CHECK_INTERVAL_MS);

  logger.info('BMKG checker berjalan setiap 5 menit.');
}

module.exports = { startBmkgChecker };
