const temproles = require('../database/models/temproles');
const logger = require('../utils/logger');

const CHECK_INTERVAL_MS = 30 * 1000; // 30 seconds

function startTemproleChecker(client) {
  setInterval(async () => {
    const expired = temproles.getExpired();
    if (expired.length === 0) return;

    for (const entry of expired) {
      try {
        const guild = client.guilds.cache.get(entry.guild_id);
        if (!guild) {
          temproles.remove(entry.id);
          continue;
        }

        const member = await guild.members.fetch(entry.user_id).catch(() => null);
        if (member && member.roles.cache.has(entry.role_id)) {
          await member.roles.remove(entry.role_id, 'Temprole expired').catch((err) => {
            logger.error(`Gagal remove temprole dari ${entry.user_id}:`, err);
          });
        }

        temproles.remove(entry.id);
        logger.info(`Temprole expired & dihapus: guild=${entry.guild_id} user=${entry.user_id} role=${entry.role_id}`);
      } catch (err) {
        logger.error('Error saat memproses temprole expired:', err);
      }
    }
  }, CHECK_INTERVAL_MS);

  logger.info('Temprole checker berjalan setiap 30 detik.');
}

module.exports = { startTemproleChecker };
