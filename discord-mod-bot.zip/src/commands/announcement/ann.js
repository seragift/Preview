const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle
} = require('discord.js');
const config = require('../../../config.json');
const { errorEmbed } = require('../../utils/embed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ann')
    .setDescription('Kirim pengumuman ke channel ini')
    .addStringOption((opt) => opt.setName('title').setDescription('Judul pengumuman').setRequired(true))
    .addStringOption((opt) => opt.setName('description').setDescription('Isi pengumuman').setRequired(true))
    .addAttachmentOption((opt) => opt.setName('image').setDescription('Gambar besar (banner)').setRequired(false))
    .addAttachmentOption((opt) => opt.setName('icon').setDescription('Icon kecil (thumbnail)').setRequired(false))
    .addRoleOption((opt) => opt.setName('tag_role').setDescription('Role yang akan di-mention').setRequired(false))
    .addStringOption((opt) => opt.setName('button_label').setDescription('Label tombol').setRequired(false))
    .addStringOption((opt) => opt.setName('button_url').setDescription('URL tombol (link)').setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .setDMPermission(false),

  async execute(interaction) {
    const title = interaction.options.getString('title');
    const description = interaction.options.getString('description');
    const image = interaction.options.getAttachment('image');
    const icon = interaction.options.getAttachment('icon');
    const tagRole = interaction.options.getRole('tag_role');
    const buttonLabel = interaction.options.getString('button_label');
    const buttonUrl = interaction.options.getString('button_url');

    if ((buttonLabel && !buttonUrl) || (!buttonLabel && buttonUrl)) {
      return interaction.reply({
        embeds: [errorEmbed('Button label dan button url harus diisi berdua, atau dikosongkan berdua.')],
        ephemeral: true
      });
    }

    if (buttonUrl && !/^https?:\/\//i.test(buttonUrl)) {
      return interaction.reply({
        embeds: [errorEmbed('Button URL harus diawali dengan http:// atau https://')],
        ephemeral: true
      });
    }

    const embed = new EmbedBuilder()
      .setColor(config.embedColor)
      .setTitle(title)
      .setDescription(description)
      .setFooter({ text: config.footerText })
      .setTimestamp();

    if (image) embed.setImage(image.url);
    if (icon) embed.setThumbnail(icon.url);

    const components = [];
    if (buttonUrl && buttonLabel) {
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setLabel(buttonLabel).setStyle(ButtonStyle.Link).setURL(buttonUrl)
      );
      components.push(row);
    }

    const content = tagRole ? `${tagRole}` : undefined;

    await interaction.channel.send({
      content,
      embeds: [embed],
      components,
      allowedMentions: { roles: tagRole ? [tagRole.id] : [] }
    });

    await interaction.reply({ content: '✅ Pengumuman berhasil dikirim.', ephemeral: true });
  }
};
