const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed } = require('../../utils/embed');
const guildConfig = require('../../database/models/guildConfig');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('antispam')
    .setDescription('Aktifkan/nonaktifkan proteksi anti-spam')
    .addStringOption((opt) =>
      opt
        .setName('status')
        .setDescription('ON atau OFF')
        .setRequired(true)
        .addChoices({ name: 'ON', value: 'on' }, { name: 'OFF', value: 'off' })
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .setDMPermission(false),

  async execute(interaction) {
    const status = interaction.options.getString('status') === 'on';
    guildConfig.setToggle(interaction.guild.id, 'antispam', status);

    await interaction.reply({
      embeds: [successEmbed(`Anti-Spam sekarang **${status ? 'AKTIF' : 'NONAKTIF'}**.`)]
    });
  }
};
