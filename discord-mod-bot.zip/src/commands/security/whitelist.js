const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embed');
const whitelists = require('../../database/models/whitelists');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('whitelist')
    .setDescription('Kelola whitelist channel/role untuk fitur security')
    .addStringOption((opt) =>
      opt
        .setName('security')
        .setDescription('Fitur security yang di-whitelist')
        .setRequired(true)
        .addChoices(
          { name: 'Anti-Link', value: 'antilink' },
          { name: 'Anti-Spam', value: 'antispam' },
          { name: 'Anti-Webhook', value: 'antiwebhook' }
        )
    )
    .addStringOption((opt) =>
      opt
        .setName('status')
        .setDescription('ON untuk menambah, OFF untuk menghapus whitelist')
        .setRequired(true)
        .addChoices({ name: 'ON', value: 'on' }, { name: 'OFF', value: 'off' })
    )
    .addChannelOption((opt) =>
      opt
        .setName('channel')
        .setDescription('Channel yang di-whitelist')
        .addChannelTypes(ChannelType.GuildText)
        .setRequired(false)
    )
    .addRoleOption((opt) => opt.setName('role').setDescription('Role yang di-whitelist').setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .setDMPermission(false),

  async execute(interaction) {
    const type = interaction.options.getString('security');
    const status = interaction.options.getString('status');
    const channel = interaction.options.getChannel('channel');
    const role = interaction.options.getRole('role');

    if (!channel && !role) {
      return interaction.reply({
        embeds: [errorEmbed('Isi minimal salah satu: `channel` atau `role`.')],
        ephemeral: true
      });
    }

    const labels = { antilink: 'Anti-Link', antispam: 'Anti-Spam', antiwebhook: 'Anti-Webhook' };
    const resultLines = [];

    if (status === 'on') {
      if (channel) {
        const added = whitelists.addChannel(interaction.guild.id, type, channel.id);
        resultLines.push(added ? `${channel} ditambahkan ke whitelist.` : `${channel} sudah ada di whitelist.`);
      }
      if (role) {
        const added = whitelists.addRole(interaction.guild.id, type, role.id);
        resultLines.push(added ? `${role} ditambahkan ke whitelist.` : `${role} sudah ada di whitelist.`);
      }
    } else {
      if (channel) {
        const removed = whitelists.removeChannel(interaction.guild.id, type, channel.id);
        resultLines.push(removed ? `${channel} dihapus dari whitelist.` : `${channel} tidak ditemukan di whitelist.`);
      }
      if (role) {
        const removed = whitelists.removeRole(interaction.guild.id, type, role.id);
        resultLines.push(removed ? `${role} dihapus dari whitelist.` : `${role} tidak ditemukan di whitelist.`);
      }
    }

    await interaction.reply({
      embeds: [successEmbed(`**Whitelist ${labels[type]}**\n${resultLines.join('\n')}`)]
    });
  }
};
