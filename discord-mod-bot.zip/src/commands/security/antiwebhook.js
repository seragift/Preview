const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed } = require('../../utils/embed');
const guildConfig = require('../../database/models/guildConfig');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('antiwebhook')
    .setDescription('Aktifkan/nonaktifkan proteksi anti-webhook')
    .addStringOption((opt) =>
      opt
        .setName('status')
        .setDescription('ON atau OFF')
        .setRequired(true)
        .addChoices({ name: 'ON', value: 'on' }, { name: 'OFF', value: 'off' })
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .setDMPermission(false),

  async execute(interaction) {
    const status = interaction.options.getString('status') === 'on';
    guildConfig.setToggle(interaction.guild.id, 'antiwebhook', status);

    await interaction.reply({
      embeds: [successEmbed(`Anti-Webhook sekarang **${status ? 'AKTIF' : 'NONAKTIF'}**.`)]
    });
  }
};
