const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { baseEmbed } = require('../../utils/embed');
const guildConfig = require('../../database/models/guildConfig');
const modlogs = require('../../database/models/modlogs');
const whitelists = require('../../database/models/whitelists');

function statusText(enabled) {
  return enabled ? '🟢 ON' : '🔴 OFF';
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('securityinfo')
    .setDescription('Lihat status pengaturan security server ini')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .setDMPermission(false),

  async execute(interaction) {
    const cfg = guildConfig.getConfig(interaction.guild.id);
    const recentLogs = modlogs.getRecent(interaction.guild.id, 5);

    const modlogChannel = cfg.modlog_channel_id ? `<#${cfg.modlog_channel_id}>` : 'Belum diatur';
    const wlCounts = {
      antilink: whitelists.countByType(interaction.guild.id, 'antilink'),
      antispam: whitelists.countByType(interaction.guild.id, 'antispam'),
      antiwebhook: whitelists.countByType(interaction.guild.id, 'antiwebhook')
    };

    const embed = baseEmbed()
      .setTitle(`🛡️ Security Info — ${interaction.guild.name}`)
      .addFields(
        { name: 'Anti-Link', value: `${statusText(cfg.antilink)}\n${wlCounts.antilink} whitelist`, inline: true },
        { name: 'Anti-Spam', value: `${statusText(cfg.antispam)}\n${wlCounts.antispam} whitelist`, inline: true },
        { name: 'Anti-Webhook', value: `${statusText(cfg.antiwebhook)}\n${wlCounts.antiwebhook} whitelist`, inline: true },
        { name: 'Channel Modlog', value: modlogChannel, inline: false }
      );

    if (recentLogs.length > 0) {
      const typeLabel = { link: '🔗', spam: '⚠️', webhook: '🪝' };
      const lines = recentLogs.map((log) => {
        const ts = Math.floor(log.timestamp / 1000);
        return `${typeLabel[log.type] || '•'} <@${log.user_id}> — ${log.action_taken || '-'} — <t:${ts}:R>`;
      });
      embed.addFields({ name: `Log Terbaru (${recentLogs.length})`, value: lines.join('\n').slice(0, 1000) });
    } else {
      embed.addFields({ name: 'Log Terbaru', value: 'Belum ada log tercatat.' });
    }

    await interaction.reply({ embeds: [embed] });
  }
};
