const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { successEmbed, baseEmbed, errorEmbed } = require('../../utils/embed');
const guildConfig = require('../../database/models/guildConfig');
const modlogs = require('../../database/models/modlogs');

const TYPE_LABEL = { link: '🔗 Link', spam: '⚠️ Spam', webhook: '🪝 Webhook' };

module.exports = {
  data: new SlashCommandBuilder()
    .setName('modlog')
    .setDescription('Kelola channel log moderasi (anti-link, anti-spam, anti-webhook)')
    .addSubcommand((sub) =>
      sub
        .setName('set')
        .setDescription('Set channel untuk menerima log moderasi')
        .addChannelOption((opt) =>
          opt
            .setName('channel')
            .setDescription('Channel tujuan log')
            .addChannelTypes(ChannelType.GuildText)
            .setRequired(true)
        )
    )
    .addSubcommand((sub) => sub.setName('view').setDescription('Lihat log moderasi terbaru'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .setDMPermission(false),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();

    if (sub === 'set') {
      const channel = interaction.options.getChannel('channel');
      guildConfig.setModlogChannel(interaction.guild.id, channel.id);
      return interaction.reply({
        embeds: [successEmbed(`Channel modlog diatur ke ${channel}.`)]
      });
    }

    if (sub === 'view') {
      const logs = modlogs.getRecent(interaction.guild.id, 15);
      if (logs.length === 0) {
        return interaction.reply({ embeds: [errorEmbed('Belum ada log moderasi tercatat.')], ephemeral: true });
      }

      const lines = logs.map((log) => {
        const ts = Math.floor(log.timestamp / 1000);
        const label = TYPE_LABEL[log.type] || log.type;
        return `${label} — <@${log.user_id}> — ${log.action_taken || '-'} — <t:${ts}:R>`;
      });

      const embed = baseEmbed()
        .setTitle(`📜 Log Moderasi Terbaru (${logs.length})`)
        .setDescription(lines.join('\n').slice(0, 4000));

      return interaction.reply({ embeds: [embed], ephemeral: true });
    }
  }
};
