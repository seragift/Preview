const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed } = require('../../utils/embed');
const guildConfig = require('../../database/models/guildConfig');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('antilink')
    .setDescription('Aktifkan/nonaktifkan proteksi anti-link')
    .addStringOption((opt) =>
      opt
        .setName('status')
        .setDescription('ON atau OFF')
        .setRequired(true)
        .addChoices({ name: 'ON', value: 'on' }, { name: 'OFF', value: 'off' })
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .setDMPermission(false),

  async execute(interaction) {
    const status = interaction.options.getString('status') === 'on';
    guildConfig.setToggle(interaction.guild.id, 'antilink', status);

    await interaction.reply({
      embeds: [successEmbed(`Anti-Link sekarang **${status ? 'AKTIF' : 'NONAKTIF'}**.`)]
    });
  }
};
