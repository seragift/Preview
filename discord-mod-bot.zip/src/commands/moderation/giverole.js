const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('giverole')
    .setDescription('Berikan role ke member')
    .addUserOption((opt) => opt.setName('user').setDescription('Target user').setRequired(true))
    .addRoleOption((opt) => opt.setName('role').setDescription('Role yang diberikan').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
    .setDMPermission(false),

  async execute(interaction) {
    const targetUser = interaction.options.getUser('user');
    const role = interaction.options.getRole('role');
    const targetMember = await interaction.guild.members.fetch(targetUser.id).catch(() => null);
    const botMember = await interaction.guild.members.fetchMe();

    if (!targetMember) {
      return interaction.reply({ embeds: [errorEmbed('Member tidak ditemukan di server ini.')], ephemeral: true });
    }
    if (role.position >= botMember.roles.highest.position) {
      return interaction.reply({ embeds: [errorEmbed('Role tersebut lebih tinggi atau sejajar dengan role bot.')], ephemeral: true });
    }
    if (targetMember.roles.cache.has(role.id)) {
      return interaction.reply({ embeds: [errorEmbed(`${targetUser.tag} sudah memiliki role ini.`)], ephemeral: true });
    }

    await targetMember.roles.add(role);
    await interaction.reply({ embeds: [successEmbed(`Role **${role.name}** berhasil diberikan ke **${targetUser.tag}**.`)] });
  }
};
