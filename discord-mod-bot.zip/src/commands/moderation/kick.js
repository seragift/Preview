const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embed');
const { canModerate } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('kick')
    .setDescription('Kick member dari server')
    .addUserOption((opt) => opt.setName('user').setDescription('User yang akan di-kick').setRequired(true))
    .addStringOption((opt) => opt.setName('reason').setDescription('Alasan kick').setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers)
    .setDMPermission(false),

  async execute(interaction) {
    const targetUser = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason') || 'Tidak ada alasan diberikan';
    const targetMember = await interaction.guild.members.fetch(targetUser.id).catch(() => null);
    const botMember = await interaction.guild.members.fetchMe();

    const check = canModerate(interaction.guild, botMember, targetMember);
    if (!check.ok) {
      return interaction.reply({ embeds: [errorEmbed(check.reason)], ephemeral: true });
    }
    if (!targetMember.kickable) {
      return interaction.reply({ embeds: [errorEmbed('Bot tidak memiliki izin untuk kick user ini.')], ephemeral: true });
    }

    await targetMember.kick(reason);
    await interaction.reply({
      embeds: [successEmbed(`**${targetUser.tag}** berhasil di-kick.\n**Alasan:** ${reason}`)]
    });
  }
};
