const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embed');
const { canModerate } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('Ban member dari server')
    .addUserOption((opt) => opt.setName('user').setDescription('User yang akan di-ban').setRequired(true))
    .addStringOption((opt) => opt.setName('reason').setDescription('Alasan ban').setRequired(false))
    .addIntegerOption((opt) =>
      opt.setName('delete_days').setDescription('Hapus pesan N hari terakhir (0-7)').setRequired(false)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .setDMPermission(false),

  async execute(interaction) {
    const targetUser = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason') || 'Tidak ada alasan diberikan';
    const deleteDays = interaction.options.getInteger('delete_days') || 0;
    const targetMember = await interaction.guild.members.fetch(targetUser.id).catch(() => null);
    const botMember = await interaction.guild.members.fetchMe();

    if (targetMember) {
      const check = canModerate(interaction.guild, botMember, targetMember);
      if (!check.ok) {
        return interaction.reply({ embeds: [errorEmbed(check.reason)], ephemeral: true });
      }
      if (!targetMember.bannable) {
        return interaction.reply({ embeds: [errorEmbed('Bot tidak memiliki izin untuk ban user ini.')], ephemeral: true });
      }
    }

    await interaction.guild.members.ban(targetUser.id, {
      deleteMessageSeconds: deleteDays * 86400,
      reason
    });

    await interaction.reply({
      embeds: [successEmbed(`**${targetUser.tag}** berhasil di-ban.\n**Alasan:** ${reason}`)]
    });
  }
};
