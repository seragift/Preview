const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('clear')
    .setDescription('Hapus sejumlah pesan di channel ini')
    .addIntegerOption((opt) =>
      opt.setName('jumlah').setDescription('Jumlah pesan (1-100)').setRequired(true).setMinValue(1).setMaxValue(100)
    )
    .addUserOption((opt) => opt.setName('user').setDescription('Hanya hapus pesan dari user ini').setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .setDMPermission(false),

  async execute(interaction) {
    const amount = interaction.options.getInteger('jumlah');
    const targetUser = interaction.options.getUser('user');

    await interaction.deferReply({ ephemeral: true });

    const messages = await interaction.channel.messages.fetch({ limit: 100 });
    let filtered = messages;
    if (targetUser) {
      filtered = messages.filter((m) => m.author.id === targetUser.id);
    }
    const toDelete = [...filtered.values()].slice(0, amount);

    if (toDelete.length === 0) {
      return interaction.editReply({ embeds: [errorEmbed('Tidak ada pesan yang cocok untuk dihapus.')] });
    }

    const deleted = await interaction.channel.bulkDelete(toDelete, true).catch(() => null);
    if (!deleted) {
      return interaction.editReply({
        embeds: [errorEmbed('Gagal menghapus pesan (pesan mungkin lebih tua dari 14 hari).')]
      });
    }

    await interaction.editReply({ embeds: [successEmbed(`Berhasil menghapus **${deleted.size}** pesan.`)] });
  }
};
