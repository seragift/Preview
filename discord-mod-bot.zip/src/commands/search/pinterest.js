const { SlashCommandBuilder, EmbedBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const config = require('../../../config.json');
const { errorEmbed } = require('../../utils/embed');
const { paginate } = require('../../utils/paginator');
const logger = require('../../utils/logger');

const API_URL = 'https://stenly.org/api/search/pinterest';

module.exports = {
  data: new SlashCommandBuilder()
    .setName('pinterest')
    .setDescription('Cari gambar dari Pinterest')
    .addStringOption((opt) => opt.setName('query').setDescription('Kata kunci pencarian').setRequired(true))
    .setDMPermission(false),

  async execute(interaction) {
    const query = interaction.options.getString('query');
    await interaction.deferReply();

    let raw;
    try {
      const apiUrl = new URL(API_URL);
      apiUrl.searchParams.set('q', query);

      const response = await fetch(apiUrl, { headers: { 'User-Agent': 'Mozilla/5.0' } });
      raw = await response.json();

      if (!response.ok || raw?.success === false) {
        throw new Error(raw?.Error || raw?.error || raw?.message || `HTTP ${response.status}`);
      }
    } catch (err) {
      logger.error('Pinterest API error:', err);
      return interaction.editReply({ embeds: [errorEmbed(`Gagal mengambil data dari Pinterest API.\n\`${err.message}\``)] });
    }

    const results = Array.isArray(raw?.data) ? raw.data : [];

    // Hanya ambil item yang benar-benar punya gambar (buang entri tanpa foto)
    const items = results.filter((item) => item?.image || item?.thumbnail).slice(0, 10);

    if (items.length === 0) {
      return interaction.editReply({ embeds: [errorEmbed(`Tidak ada hasil foto untuk "${query}".`)] });
    }

    await paginate(
      interaction,
      items,
      (item, index, total) =>
        new EmbedBuilder()
          .setColor(0xe60023)
          .setTitle((item.title || `📌 Pinterest — ${query}`).slice(0, 256))
          .setImage(item.image || item.thumbnail)
          .setFooter({ text: `${config.footerText} • Hasil ${index + 1} dari ${total}` })
          .setTimestamp(),
      (item) => (item.url ? [new ButtonBuilder().setLabel('Buka di Pinterest').setStyle(ButtonStyle.Link).setURL(item.url)] : [])
    );
  }
};
