const { SlashCommandBuilder, EmbedBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const config = require('../../../config.json');
const { errorEmbed } = require('../../utils/embed');
const { paginate } = require('../../utils/paginator');
const { extractArray } = require('../../utils/responseUtil');
const api = require('../../utils/apiClient');
const logger = require('../../utils/logger');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('pinterest')
    .setDescription('Cari gambar/video dari Pinterest')
    .addStringOption((opt) => opt.setName('keyword').setDescription('Kata kunci pencarian').setRequired(true))
    .setDMPermission(false),

  async execute(interaction) {
    const keyword = interaction.options.getString('keyword');
    await interaction.deferReply();

    let raw;
    try {
      raw = await api.searchPinterest(keyword);
    } catch (err) {
      logger.error('Pinterest API error:', err);
      return interaction.editReply({ embeds: [errorEmbed('Gagal mengambil data dari Pinterest API.')] });
    }

    const items = extractArray(raw).slice(0, 10);
    if (items.length === 0) {
      return interaction.editReply({ embeds: [errorEmbed(`Tidak ada hasil untuk "${keyword}".`)] });
    }

    await paginate(
      interaction,
      items,
      (item, index, total) =>
        new EmbedBuilder()
          .setColor(config.embedColor)
          .setTitle(`📌 Pinterest — ${keyword}`)
          .setImage(item.url || item.image || item.thumbnail || item.image_url || null)
          .setFooter({ text: `${config.footerText} • Hasil ${index + 1} dari ${total}` })
          .setTimestamp(),
      (item) => {
        const link = item.pin_url || item.source_url || item.link || item.url;
        return link ? [new ButtonBuilder().setLabel('Buka di Pinterest').setStyle(ButtonStyle.Link).setURL(link)] : [];
      }
    );
  }
};
