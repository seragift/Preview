const { SlashCommandBuilder, EmbedBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const config = require('../../../config.json');
const { errorEmbed } = require('../../utils/embed');
const { paginate } = require('../../utils/paginator');
const logger = require('../../utils/logger');

const API_URL = 'https://stenly.org/api/tokopedia';

module.exports = {
  data: new SlashCommandBuilder()
    .setName('tokopedia')
    .setDescription('Cari produk di Tokopedia')
    .addStringOption((opt) => opt.setName('query').setDescription('Nama produk yang ingin dicari').setRequired(true))
    .setDMPermission(false),

  async execute(interaction) {
    const query = interaction.options.getString('query');
    await interaction.deferReply();

    let raw;
    try {
      const apiUrl = new URL(API_URL);
      apiUrl.searchParams.set('query', query);

      const response = await fetch(apiUrl, { headers: { 'User-Agent': 'Mozilla/5.0' } });
      raw = await response.json();

      if (!response.ok || raw?.Status === false) {
        throw new Error(raw?.Error || raw?.error || raw?.message || `HTTP ${response.status}`);
      }
    } catch (err) {
      logger.error('Tokopedia API error:', err);
      return interaction.editReply({ embeds: [errorEmbed(`Gagal mengambil data dari Tokopedia API.\n\`${err.message}\``)] });
    }

    const products = Array.isArray(raw?.Result) ? raw.Result : [];

    // Hanya ambil produk yang punya foto
    const items = products.filter((p) => p?.Image || p?.Image_300).slice(0, 25);

    if (items.length === 0) {
      return interaction.editReply({ embeds: [errorEmbed(`Tidak ada produk bergambar untuk "${query}".`)] });
    }

    await paginate(
      interaction,
      items,
      (item, index, total) => {
        const price = item.Price || '-';
        const originalPrice = item.Original_price;
        const priceLine =
          originalPrice && originalPrice !== price ? `💰 **${price}** ~~${originalPrice}~~` : `💰 **${price}**`;

        const descLines = [
          priceLine,
          `⭐ Rating: ${item.Rating || '-'}`,
          `📦 Terjual: ${item.Sold || '-'}`,
          item.Shop?.Name ? `🏪 ${item.Shop.Name}${item.Shop.City ? ` (${item.Shop.City})` : ''}` : null
        ].filter(Boolean);

        return new EmbedBuilder()
          .setColor(0x03ac0e)
          .setTitle((item.Name || 'Produk Tokopedia').slice(0, 256))
          .setDescription(descLines.join('\n'))
          .setImage(item.Image || item.Image_300)
          .setFooter({ text: `${config.footerText} • Produk ${index + 1} dari ${total}` })
          .setTimestamp();
      },
      (item) => (item.Url ? [new ButtonBuilder().setLabel('Lihat Produk').setStyle(ButtonStyle.Link).setURL(item.Url)] : [])
    );
  }
};
