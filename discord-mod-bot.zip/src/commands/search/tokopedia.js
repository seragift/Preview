const { SlashCommandBuilder, EmbedBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const config = require('../../../config.json');
const { errorEmbed } = require('../../utils/embed');
const { paginate } = require('../../utils/paginator');
const { extractArray } = require('../../utils/responseUtil');
const api = require('../../utils/apiClient');
const logger = require('../../utils/logger');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('tokopedia')
    .setDescription('Cari produk dari Tokopedia')
    .addStringOption((opt) => opt.setName('keyword').setDescription('Kata kunci produk').setRequired(true))
    .setDMPermission(false),

  async execute(interaction) {
    const keyword = interaction.options.getString('keyword');
    await interaction.deferReply();

    let raw;
    try {
      raw = await api.searchTokopedia(keyword);
    } catch (err) {
      logger.error('Tokopedia API error:', err);
      return interaction.editReply({ embeds: [errorEmbed('Gagal mengambil data dari Tokopedia API.')] });
    }

    const items = extractArray(raw).slice(0, 10);
    if (items.length === 0) {
      return interaction.editReply({ embeds: [errorEmbed(`Tidak ada produk untuk "${keyword}".`)] });
    }

    await paginate(
      interaction,
      items,
      (item, index, total) => {
        const descLines = [
          item.price ? `💰 **Harga:** ${item.price}` : null,
          item.rating ? `⭐ **Rating:** ${item.rating}` : null,
          item.sold ? `📦 **Terjual:** ${item.sold}` : null,
          item.shop_name || item.shop ? `🏪 **Toko:** ${item.shop_name || item.shop}` : null
        ].filter(Boolean);

        return new EmbedBuilder()
          .setColor(config.embedColor)
          .setTitle((item.name || item.title || 'Produk Tokopedia').slice(0, 256))
          .setDescription(descLines.join('\n') || 'Tidak ada detail tambahan.')
          .setImage(item.image || item.thumbnail || item.image_url || null)
          .setFooter({ text: `${config.footerText} • Produk ${index + 1} dari ${total}` })
          .setTimestamp();
      },
      (item) => {
        const link = item.url || item.link;
        return link ? [new ButtonBuilder().setLabel('Ke Toko').setStyle(ButtonStyle.Link).setURL(link)] : [];
      }
    );
  }
};
