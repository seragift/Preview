const { SlashCommandBuilder, EmbedBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const config = require('../../../config.json');
const { errorEmbed } = require('../../utils/embed');
const { paginate } = require('../../utils/paginator');
const api = require('../../utils/apiClient');
const logger = require('../../utils/logger');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('tokopedia')
    .setDescription('Cari produk dari Tokopedia')
    .addStringOption((opt) => opt.setName('keyword').setDescription('Kata kunci produk').setRequired(true))
    .setDMPermission(false),

  async execute(interaction) {
    const keyword = interaction.options.getString('keyword');
    await interaction.deferReply();

    let raw;
    try {
      raw = await api.searchTokopedia(keyword);
    } catch (err) {
      logger.error('Tokopedia API error:', err);
      return interaction.editReply({ embeds: [errorEmbed('Gagal mengambil data dari Tokopedia API.')] });
    }

    if (raw?.Status === false) {
      return interaction.editReply({ embeds: [errorEmbed(raw.Error || 'Tokopedia API mengembalikan error.')] });
    }

    const items = Array.isArray(raw?.Result) ? raw.Result.slice(0, 10) : [];
    if (items.length === 0) {
      return interaction.editReply({ embeds: [errorEmbed(`Tidak ada produk untuk "${keyword}".`)] });
    }

    await paginate(
      interaction,
      items,
      (item, index, total) => {
        const descLines = [
          item.Price ? `💰 **Harga:** ${item.Price}` : null,
          item.Rating ? `⭐ **Rating:** ${item.Rating}` : null,
          item.Sold ? `📦 **Terjual:** ${item.Sold}` : null,
          item.Shop?.Name ? `🏪 **Toko:** ${item.Shop.Name}${item.Shop.City ? ` (${item.Shop.City})` : ''}` : null
        ].filter(Boolean);

        return new EmbedBuilder()
          .setColor(config.embedColor)
          .setTitle((item.Name || 'Produk Tokopedia').slice(0, 256))
          .setDescription(descLines.join('\n') || 'Tidak ada detail tambahan.')
          .setImage(item.Image || item.Image_300 || null)
          .setFooter({ text: `${config.footerText} • Produk ${index + 1} dari ${total}` })
          .setTimestamp();
      },
      (item) => (item.Url ? [new ButtonBuilder().setLabel('Ke Toko').setStyle(ButtonStyle.Link).setURL(item.Url)] : [])
    );
  }
};
