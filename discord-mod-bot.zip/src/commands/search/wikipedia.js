const { SlashCommandBuilder, EmbedBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const config = require('../../../config.json');
const { errorEmbed } = require('../../utils/embed');
const { paginate } = require('../../utils/paginator');
const { extractArray } = require('../../utils/responseUtil');
const api = require('../../utils/apiClient');
const logger = require('../../utils/logger');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('wikipedia')
    .setDescription('Cari artikel dari Wikipedia')
    .addStringOption((opt) => opt.setName('keyword').setDescription('Kata kunci pencarian').setRequired(true))
    .setDMPermission(false),

  async execute(interaction) {
    const keyword = interaction.options.getString('keyword');
    await interaction.deferReply();

    let raw;
    try {
      raw = await api.searchWikipedia(keyword);
    } catch (err) {
      logger.error('Wikipedia API error:', err);
      return interaction.editReply({ embeds: [errorEmbed('Gagal mengambil data dari Wikipedia API.')] });
    }

    const items = extractArray(raw).slice(0, 10);
    if (items.length === 0) {
      return interaction.editReply({ embeds: [errorEmbed(`Tidak ada artikel untuk "${keyword}".`)] });
    }

    await paginate(
      interaction,
      items,
      (item, index, total) =>
        new EmbedBuilder()
          .setColor(config.embedColor)
          .setTitle((item.title || 'Wikipedia').slice(0, 256))
          .setDescription((item.extract || item.snippet || item.description || 'Tidak ada ringkasan.').slice(0, 2000))
          .setThumbnail(item.thumbnail || item.image || null)
          .setFooter({ text: `${config.footerText} • Hasil ${index + 1} dari ${total}` })
          .setTimestamp(),
      (item) => {
        const link = item.url || item.link;
        return link ? [new ButtonBuilder().setLabel('Buka di Wikipedia').setStyle(ButtonStyle.Link).setURL(link)] : [];
      }
    );
  }
};
