const { SlashCommandBuilder, EmbedBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const config = require('../../../config.json');
const { errorEmbed } = require('../../utils/embed');
const { paginate } = require('../../utils/paginator');
const api = require('../../utils/apiClient');
const logger = require('../../utils/logger');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('wikipedia')
    .setDescription('Cari artikel dari Wikipedia')
    .addStringOption((opt) => opt.setName('keyword').setDescription('Kata kunci pencarian').setRequired(true))
    .setDMPermission(false),

  async execute(interaction) {
    const keyword = interaction.options.getString('keyword');
    await interaction.deferReply();

    let raw;
    try {
      raw = await api.searchWikipedia(keyword);
    } catch (err) {
      logger.error('Wikipedia API error:', err);
      return interaction.editReply({ embeds: [errorEmbed('Gagal mengambil data dari Wikipedia API.')] });
    }

    if (raw?.Status === false || !raw?.Result) {
      return interaction.editReply({ embeds: [errorEmbed(`Tidak ada artikel untuk "${keyword}".`)] });
    }

    const article = raw.Result;
    // API ini mengembalikan SATU artikel per pencarian (bukan list banyak artikel),
    // jadi navigasi ◀️▶️ dipakai untuk menjelajah galeri gambar dari artikel yang sama.
    const images = Array.isArray(article.Images) && article.Images.length > 0 ? article.Images : [null];

    await paginate(
      interaction,
      images,
      (image, index, total) =>
        new EmbedBuilder()
          .setColor(config.embedColor)
          .setTitle((article.Title || 'Wikipedia').slice(0, 256))
          .setURL(article.Url || null)
          .setDescription((article.Extract || article.Description || 'Tidak ada ringkasan.').slice(0, 2000))
          .setImage(image?.Url || null)
          .setFooter({
            text: total > 1 ? `${config.footerText} • Gambar ${index + 1} dari ${total}` : config.footerText
          })
          .setTimestamp(),
      () => (article.Url ? [new ButtonBuilder().setLabel('Buka di Wikipedia').setStyle(ButtonStyle.Link).setURL(article.Url)] : [])
    );
  }
};
