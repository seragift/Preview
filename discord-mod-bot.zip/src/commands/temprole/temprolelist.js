const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { baseEmbed, errorEmbed } = require('../../utils/embed');
const temproles = require('../../database/models/temproles');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('temprolelist')
    .setDescription('Lihat daftar temprole yang sedang aktif di server ini')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
    .setDMPermission(false),

  async execute(interaction) {
    const active = temproles.listActive(interaction.guild.id);

    if (active.length === 0) {
      return interaction.reply({ embeds: [errorEmbed('Tidak ada temprole yang sedang aktif.')], ephemeral: true });
    }

    const lines = active.map((entry) => {
      const remainingMs = entry.expires_at - Date.now();
      const expiresUnix = Math.floor(entry.expires_at / 1000);
      return `<@${entry.user_id}> — <@&${entry.role_id}> — expires <t:${expiresUnix}:R>`;
    });

    const embed = baseEmbed()
      .setTitle(`📋 Temprole Aktif (${active.length})`)
      .setDescription(lines.join('\n').slice(0, 4000));

    await interaction.reply({ embeds: [embed] });
  }
};
