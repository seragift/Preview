const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embed');
const { parseDuration, formatDuration } = require('../../utils/duration');
const temproles = require('../../database/models/temproles');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('temprole')
    .setDescription('Berikan role sementara ke member')
    .addUserOption((opt) => opt.setName('user').setDescription('Target user').setRequired(true))
    .addRoleOption((opt) => opt.setName('role').setDescription('Role yang diberikan').setRequired(true))
    .addStringOption((opt) =>
      opt.setName('durasi').setDescription('Contoh: 30m, 2h, 1d').setRequired(true)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
    .setDMPermission(false),

  async execute(interaction) {
    const targetUser = interaction.options.getUser('user');
    const role = interaction.options.getRole('role');
    const durationInput = interaction.options.getString('durasi');
    const durationMs = parseDuration(durationInput);

    if (!durationMs) {
      return interaction.reply({
        embeds: [errorEmbed('Format durasi tidak valid. Gunakan contoh: `30m`, `2h`, `1d`.')],
        ephemeral: true
      });
    }

    const targetMember = await interaction.guild.members.fetch(targetUser.id).catch(() => null);
    const botMember = await interaction.guild.members.fetchMe();

    if (!targetMember) {
      return interaction.reply({ embeds: [errorEmbed('Member tidak ditemukan di server ini.')], ephemeral: true });
    }
    if (role.position >= botMember.roles.highest.position) {
      return interaction.reply({ embeds: [errorEmbed('Role tersebut lebih tinggi atau sejajar dengan role bot.')], ephemeral: true });
    }

    if (!targetMember.roles.cache.has(role.id)) {
      await targetMember.roles.add(role);
    }

    temproles.addTemprole({
      guildId: interaction.guild.id,
      userId: targetUser.id,
      roleId: role.id,
      addedBy: interaction.user.id,
      durationMs
    });

    await interaction.reply({
      embeds: [
        successEmbed(
          `Role **${role.name}** diberikan ke **${targetUser.tag}** selama **${formatDuration(durationMs)}**.`
        )
      ]
    });
  }
};
