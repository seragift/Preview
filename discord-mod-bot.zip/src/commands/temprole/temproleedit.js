const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embed');
const { parseDuration, formatDuration } = require('../../utils/duration');
const temproles = require('../../database/models/temproles');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('temproleedit')
    .setDescription('Ubah durasi temprole yang sedang aktif')
    .addUserOption((opt) => opt.setName('user').setDescription('Target user').setRequired(true))
    .addRoleOption((opt) => opt.setName('role').setDescription('Role temprole yang diubah').setRequired(true))
    .addStringOption((opt) =>
      opt.setName('durasi_baru').setDescription('Durasi baru sejak sekarang, contoh: 2h, 1d').setRequired(true)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
    .setDMPermission(false),

  async execute(interaction) {
    const targetUser = interaction.options.getUser('user');
    const role = interaction.options.getRole('role');
    const durationInput = interaction.options.getString('durasi_baru');
    const durationMs = parseDuration(durationInput);

    if (!durationMs) {
      return interaction.reply({
        embeds: [errorEmbed('Format durasi tidak valid. Gunakan contoh: `30m`, `2h`, `1d`.')],
        ephemeral: true
      });
    }

    const existing = temproles.getActiveByUserAndRole(interaction.guild.id, targetUser.id, role.id);
    if (!existing) {
      return interaction.reply({
        embeds: [errorEmbed(`Tidak ditemukan temprole aktif untuk **${targetUser.tag}** dengan role **${role.name}**.`)],
        ephemeral: true
      });
    }

    const newExpiresAt = Date.now() + durationMs;
    temproles.updateExpiry(existing.id, newExpiresAt);

    await interaction.reply({
      embeds: [
        successEmbed(
          `Durasi temprole **${role.name}** untuk **${targetUser.tag}** diperbarui menjadi **${formatDuration(durationMs)}** sejak sekarang.`
        )
      ]
    });
  }
};
