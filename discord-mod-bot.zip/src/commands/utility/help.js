const { SlashCommandBuilder } = require('discord.js');
const { baseEmbed } = require('../../utils/embed');

const CATEGORY_LABELS = {
  moderation: '🔨 Moderasi',
  temprole: '⏱️ Temprole',
  security: '🛡️ Security',
  announcement: '📢 Announcement',
  downloader: '⬇️ Downloader & Channel Setup',
  search: '🔎 Search',
  utility: '🧰 Utility'
};

const CATEGORY_ORDER = ['moderation', 'temprole', 'security', 'announcement', 'downloader', 'search', 'utility'];

module.exports = {
  data: new SlashCommandBuilder().setName('help').setDescription('Lihat daftar semua command bot').setDMPermission(false),

  async execute(interaction, client) {
    const grouped = new Map();
    for (const command of client.commands.values()) {
      const cat = command.category || 'lainnya';
      if (!grouped.has(cat)) grouped.set(cat, []);
      grouped.get(cat).push(command);
    }

    const embed = baseEmbed()
      .setTitle('📖 Daftar Command')
      .setDescription('Berikut semua command yang tersedia di bot ini.');

    const orderedCats = [...CATEGORY_ORDER.filter((c) => grouped.has(c)), ...[...grouped.keys()].filter((c) => !CATEGORY_ORDER.includes(c))];

    for (const cat of orderedCats) {
      const commands = grouped.get(cat);
      const label = CATEGORY_LABELS[cat] || `📁 ${cat}`;
      const lines = commands
        .sort((a, b) => a.data.name.localeCompare(b.data.name))
        .map((c) => `\`/${c.data.name}\` — ${c.data.description}`);
      embed.addFields({ name: label, value: lines.join('\n').slice(0, 1024) });
    }

    await interaction.reply({ embeds: [embed] });
  }
};
