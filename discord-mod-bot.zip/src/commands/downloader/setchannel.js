const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { successEmbed } = require('../../utils/embed');
const serviceChannels = require('../../database/models/serviceChannels');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setchannel')
    .setDescription('Set channel untuk fitur downloader/info otomatis')
    .addChannelOption((opt) =>
      opt.setName('channel').setDescription('Channel tujuan').addChannelTypes(ChannelType.GuildText).setRequired(true)
    )
    .addStringOption((opt) =>
      opt
        .setName('service')
        .setDescription('Layanan yang diarahkan ke channel ini')
        .setRequired(true)
        .addChoices(
          { name: 'BMKG', value: 'bmkg' },
          { name: 'TikTok', value: 'tiktok' },
          { name: 'Semua (ALL)', value: 'all' }
        )
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .setDMPermission(false),

  async execute(interaction) {
    const channel = interaction.options.getChannel('channel');
    const service = interaction.options.getString('service');

    const targets = service === 'all' ? serviceChannels.VALID_SERVICES : [service];
    for (const svc of targets) {
      serviceChannels.setChannel(interaction.guild.id, svc, channel.id);
    }

    const label = service === 'all' ? 'BMKG, TikTok (semua)' : service.toUpperCase();
    await interaction.reply({ embeds: [successEmbed(`Channel untuk **${label}** diatur ke ${channel}.`)] });
  }
};
