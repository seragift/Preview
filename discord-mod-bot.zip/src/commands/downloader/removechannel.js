const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embed');
const serviceChannels = require('../../database/models/serviceChannels');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('removechannel')
    .setDescription('Hapus channel binding untuk fitur downloader/info otomatis')
    .addStringOption((opt) =>
      opt
        .setName('service')
        .setDescription('Layanan yang di-unbind')
        .setRequired(true)
        .addChoices(
          { name: 'BMKG', value: 'bmkg' },
          { name: 'Spotify', value: 'spotify' },
          { name: 'TikTok', value: 'tiktok' },
          { name: 'CapCut', value: 'capcut' },
          { name: 'Semua (ALL)', value: 'all' }
        )
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .setDMPermission(false),

  async execute(interaction) {
    const service = interaction.options.getString('service');
    const targets = service === 'all' ? serviceChannels.VALID_SERVICES : [service];

    let removedAny = false;
    for (const svc of targets) {
      if (serviceChannels.removeChannel(interaction.guild.id, svc)) removedAny = true;
    }

    if (!removedAny) {
      return interaction.reply({ embeds: [errorEmbed('Tidak ada channel binding yang ditemukan untuk dihapus.')], ephemeral: true });
    }

    const label = service === 'all' ? 'BMKG, Spotify, TikTok, CapCut (semua)' : service.toUpperCase();
    await interaction.reply({ embeds: [successEmbed(`Channel binding untuk **${label}** berhasil dihapus.`)] });
  }
};
