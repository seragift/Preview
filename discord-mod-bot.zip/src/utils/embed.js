const { EmbedBuilder } = require('discord.js');
const config = require('../../config.json');

function baseEmbed() {
  return new EmbedBuilder()
    .setColor(config.embedColor)
    .setFooter({ text: config.footerText })
    .setTimestamp();
}

function successEmbed(description) {
  return baseEmbed().setColor(config.successColor).setDescription(`✅ ${description}`);
}

function errorEmbed(description) {
  return baseEmbed().setColor(config.errorColor).setDescription(`❌ ${description}`);
}

function modlogEmbed({ type, user, content, actionTaken }) {
  const titles = {
    link: '🔗 Anti-Link Triggered',
    spam: '⚠️ Anti-Spam Triggered',
    webhook: '🪝 Anti-Webhook Triggered'
  };
  const embed = baseEmbed()
    .setColor(config.errorColor)
    .setTitle(titles[type] || 'Security Log')
    .addFields(
      { name: 'User', value: user ? `<@${user}> (${user})` : 'Unknown', inline: false }
    );
  if (content) embed.addFields({ name: 'Content', value: content.slice(0, 1000) });
  if (actionTaken) embed.addFields({ name: 'Action', value: actionTaken });
  return embed;
}

module.exports = { baseEmbed, successEmbed, errorEmbed, modlogEmbed };
