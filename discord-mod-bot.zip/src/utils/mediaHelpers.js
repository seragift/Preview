const MAX_DOWNLOAD_SIZE = 24 * 1024 * 1024; // stay under Discord's ~25MB bot upload cap

function cleanText(text, max = 1000) {
  if (!text) return '-';
  const cleaned = String(text).replace(/\s+/g, ' ').trim();
  return cleaned.length > max ? `${cleaned.slice(0, max - 3)}...` : cleaned;
}

function validUrl(url) {
  if (!url || typeof url !== 'string') return false;
  try {
    const parsed = new URL(url);
    return ['http:', 'https:'].includes(parsed.protocol) && url.length <= 512;
  } catch {
    return false;
  }
}

/**
 * Returns the first defined/non-null value for any of the given keys on obj.
 * Useful when an API's response casing/field naming is inconsistent (e.g. "Url" vs "url").
 */
function firstValue(obj, keys) {
  for (const key of keys) {
    if (obj && obj[key] !== undefined && obj[key] !== null) return obj[key];
  }
  return null;
}

/**
 * Collects candidate image URLs from a variety of common field names/shapes
 * (used for slideshow/photo-post style TikTok results).
 */
function collectImages(result) {
  const images = [];
  const fields = ['Images', 'images', 'Photos', 'photos', 'Slides', 'slides', 'Image_urls', 'image_urls', 'Photo_urls', 'photo_urls'];

  for (const field of fields) {
    const value = result?.[field];
    if (!Array.isArray(value)) continue;

    for (const item of value) {
      if (typeof item === 'string') {
        if (validUrl(item)) images.push(item);
      } else if (item && typeof item === 'object') {
        const url = firstValue(item, ['Url', 'url', 'URL', 'Image', 'image', 'Image_url', 'image_url']);
        if (validUrl(url)) images.push(url);
      }
    }
  }

  return [...new Set(images)];
}

/**
 * Downloads a URL into a Buffer, enforcing a max size (Discord bot upload cap).
 * Throws if the request fails or the file exceeds MAX_DOWNLOAD_SIZE.
 */
async function downloadBuffer(url) {
  const response = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0' }, redirect: 'follow' });
  if (!response.ok) throw new Error(`Download media gagal: HTTP ${response.status}`);

  const contentLength = Number(response.headers.get('content-length') || 0);
  if (contentLength > MAX_DOWNLOAD_SIZE) {
    throw new Error(`File terlalu besar: ${(contentLength / 1024 / 1024).toFixed(1)} MB`);
  }

  const arrayBuffer = await response.arrayBuffer();
  const buffer = Buffer.from(arrayBuffer);
  if (buffer.length > MAX_DOWNLOAD_SIZE) {
    throw new Error(`File terlalu besar: ${(buffer.length / 1024 / 1024).toFixed(1)} MB`);
  }

  return buffer;
}

module.exports = { MAX_DOWNLOAD_SIZE, cleanText, validUrl, firstValue, collectImages, downloadBuffer };
