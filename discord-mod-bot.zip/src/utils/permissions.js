const { PermissionsBitField } = require('discord.js');

/**
 * Checks if the executing member has the given permission(s).
 * @param {import('discord.js').GuildMember} member
 * @param {bigint[]} permissions
 */
function hasPermission(member, permissions) {
  return member.permissions.has(permissions);
}

/**
 * Checks the bot can act on the target member (role hierarchy + not owner).
 */
function canModerate(guild, botMember, targetMember) {
  if (!targetMember) return { ok: false, reason: 'Member tidak ditemukan.' };
  if (targetMember.id === guild.ownerId) {
    return { ok: false, reason: 'Tidak bisa moderasi pemilik server.' };
  }
  if (targetMember.roles.highest.position >= botMember.roles.highest.position) {
    return { ok: false, reason: 'Role target lebih tinggi atau sejajar dengan role bot.' };
  }
  return { ok: true };
}

module.exports = { hasPermission, canModerate, PermissionsBitField };
