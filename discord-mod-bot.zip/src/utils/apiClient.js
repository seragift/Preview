const config = require('../../config.json');

/**
 * Field mapping berikut sudah dikonfirmasi langsung dari dokumentasi & response live
 * https://stenly.org (per 13 Sep 2026):
 *  - Tokopedia (/api/tokopedia): param "query" (bukan "q"). Response: { Status, Result: [{ Name, Url, Image, Price, Rating, Sold, Shop:{Name,Url}, ... }] }
 *  - Pinterest (/api/search/pinterest): param "q". Response: { success, data: [{ title, url, image, thumbnail, ... }] }
 *  - Wikipedia (/api/search/wikipedia): param "query" (+ optional lang/limit). Response HANYA 1 artikel:
 *    { Status, Result: { Title, Extract, Url, Images: [{Alt,Url}], ... } } — bukan list banyak artikel.
 *  - TikTok (/api/downloader/tiktok): param "url". Response: { Status, Result: { Title, Thumbnail, Downloads: [{Type, Url}] } }
 *  - BMKG (/api/info/gempa): tanpa param. Response: { success, data: { tanggal, jam, magnitudo, kedalaman, wilayah, image_url } }
 */

function buildUrl(path, params = {}) {
  const base = (config.apiBaseUrl || '').replace(/\/$/, '');
  const url = new URL(base + path);
  for (const [key, value] of Object.entries(params)) {
    if (value !== undefined && value !== null) url.searchParams.set(key, value);
  }
  return url.toString();
}

async function getJson(path, params) {
  if (!config.apiBaseUrl) {
    throw new Error('config.json: "apiBaseUrl" belum diisi.');
  }
  const url = buildUrl(path, params);
  const res = await fetch(url);
  if (!res.ok) {
    throw new Error(`API request gagal (${res.status} ${res.statusText}) — ${url}`);
  }
  return res.json();
}

const downloadTiktok = (url) => getJson('/api/downloader/tiktok', { url });
const searchPinterest = (q) => getJson('/api/search/pinterest', { q });
const searchWikipedia = (query) => getJson('/api/search/wikipedia', { query, lang: 'id', limit: 5 });
const infoGempa = () => getJson('/api/info/gempa');
const searchTokopedia = (query) => getJson('/api/tokopedia', { query, limit: 10 });

module.exports = {
  downloadTiktok,
  searchPinterest,
  searchWikipedia,
  infoGempa,
  searchTokopedia
};
