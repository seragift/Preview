const config = require('../../config.json');

/**
 * IMPORTANT — BACA INI:
 * Nama parameter query (`url`, `q`) dan bentuk response JSON di bawah ini adalah
 * ASUMSI umum untuk API downloader/search sejenis. Karena dokumentasi API asli kamu
 * tidak tersedia di sini, sesuaikan path/parameter/nama field di file ini (dan di
 * command yang memakainya) dengan dokumentasi API kamu yang sebenarnya jika berbeda.
 *
 * Isi `apiBaseUrl` di config.json terlebih dahulu, contoh: "https://api.domainkamu.com"
 */

function buildUrl(path, params = {}) {
  const base = (config.apiBaseUrl || '').replace(/\/$/, '');
  const url = new URL(base + path);
  for (const [key, value] of Object.entries(params)) {
    if (value !== undefined && value !== null) url.searchParams.set(key, value);
  }
  return url.toString();
}

async function getJson(path, params) {
  if (!config.apiBaseUrl) {
    throw new Error('config.json: "apiBaseUrl" belum diisi.');
  }
  const url = buildUrl(path, params);
  const res = await fetch(url);
  if (!res.ok) {
    throw new Error(`API request gagal (${res.status} ${res.statusText}) — ${url}`);
  }
  return res.json();
}

const downloadSpotify = (url) => getJson('/api/downloader/spotify', { url });
const downloadTiktok = (url) => getJson('/api/downloader/tiktok', { url });
const downloadCapcut = (url) => getJson('/api/downloader/capcut', { url });
const searchPinterest = (q) => getJson('/api/search/pinterest', { q });
const searchWikipedia = (q) => getJson('/api/search/wikipedia', { q });
const infoGempa = () => getJson('/api/info/gempa');
const searchTokopedia = (q) => getJson('/api/tokopedia', { q });

module.exports = {
  downloadSpotify,
  downloadTiktok,
  downloadCapcut,
  searchPinterest,
  searchWikipedia,
  infoGempa,
  searchTokopedia
};
