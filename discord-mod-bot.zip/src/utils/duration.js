const UNIT_MS = {
  s: 1000,
  m: 60 * 1000,
  h: 60 * 60 * 1000,
  d: 24 * 60 * 60 * 1000
};

/**
 * Parses a duration string like "1d", "2h", "30m", "45s" into milliseconds.
 * Returns null if invalid.
 */
function parseDuration(input) {
  const match = /^(\d+)([smhd])$/i.exec(input.trim());
  if (!match) return null;
  const value = parseInt(match[1], 10);
  const unit = match[2].toLowerCase();
  if (!UNIT_MS[unit] || value <= 0) return null;
  return value * UNIT_MS[unit];
}

function formatDuration(ms) {
  const seconds = Math.floor(ms / 1000);
  const days = Math.floor(seconds / 86400);
  const hours = Math.floor((seconds % 86400) / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const parts = [];
  if (days) parts.push(`${days}h`);
  if (hours) parts.push(`${hours}j`);
  if (minutes) parts.push(`${minutes}m`);
  if (parts.length === 0) parts.push(`${seconds}d`);
  return parts.join(' ');
}

module.exports = { parseDuration, formatDuration };
