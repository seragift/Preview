const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

function navRow(disabled) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('page_prev').setEmoji('◀️').setStyle(ButtonStyle.Secondary).setDisabled(disabled),
    new ButtonBuilder().setCustomId('page_next').setEmoji('▶️').setStyle(ButtonStyle.Secondary).setDisabled(disabled)
  );
}

/**
 * Sends a paginated embed reply with ◀️ ▶️ navigation buttons.
 * Requires interaction to already be deferred (interaction.deferReply()).
 *
 * @param {import('discord.js').ChatInputCommandInteraction} interaction
 * @param {Array} items
 * @param {(item: any, index: number, total: number) => import('discord.js').EmbedBuilder} buildEmbed
 * @param {(item: any, index: number, total: number) => import('discord.js').ButtonBuilder[]} buildExtraButtons
 */
async function paginate(interaction, items, buildEmbed, buildExtraButtons = () => [], { time = 5 * 60 * 1000 } = {}) {
  let index = 0;
  const single = items.length <= 1;

  const render = () => {
    const embed = buildEmbed(items[index], index, items.length);
    const rows = [navRow(single)];
    const extras = buildExtraButtons(items[index], index, items.length);
    if (extras.length > 0) rows.push(new ActionRowBuilder().addComponents(...extras));
    return { embeds: [embed], components: rows };
  };

  const message = await interaction.editReply(render());
  if (single) return;

  const collector = message.createMessageComponentCollector({
    time,
    filter: (btn) => btn.user.id === interaction.user.id
  });

  collector.on('collect', async (btn) => {
    if (btn.customId === 'page_prev') {
      index = (index - 1 + items.length) % items.length;
    } else if (btn.customId === 'page_next') {
      index = (index + 1) % items.length;
    } else {
      return;
    }
    await btn.update(render());
  });

  collector.on('end', async () => {
    await interaction.editReply({ components: [navRow(true)] }).catch(() => {});
  });
}

module.exports = { paginate };
