/**
 * Extracts an array of results from a variety of common API response shapes.
 * Handles: raw array, { result: [...] }, { data: [...] }, { results: [...] }.
 */
function extractArray(res) {
  if (Array.isArray(res)) return res;
  if (Array.isArray(res?.result)) return res.result;
  if (Array.isArray(res?.data)) return res.data;
  if (Array.isArray(res?.results)) return res.results;
  return [];
}

/**
 * Extracts a single result object from common API response shapes.
 * Handles: { result: {...} }, { data: {...} }, or the raw object itself.
 */
function extractObject(res) {
  if (res?.result && typeof res.result === 'object' && !Array.isArray(res.result)) return res.result;
  if (res?.data && typeof res.data === 'object' && !Array.isArray(res.data)) return res.data;
  return res || {};
}

module.exports = { extractArray, extractObject };
