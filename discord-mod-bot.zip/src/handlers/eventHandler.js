const fs = require('fs');
const path = require('path');
const logger = require('../utils/logger');

function loadEvents(client) {
  const eventsDir = path.join(__dirname, '..', 'events');
  const files = fs.readdirSync(eventsDir).filter((f) => f.endsWith('.js'));
  let loaded = 0;

  for (const file of files) {
    const event = require(path.join(eventsDir, file));
    if (!event?.name || !event?.execute) {
      logger.warn(`Event file tidak valid (dilewati): ${file}`);
      continue;
    }
    if (event.once) {
      client.once(event.name, (...args) => event.execute(...args, client));
    } else {
      client.on(event.name, (...args) => event.execute(...args, client));
    }
    loaded++;
  }

  logger.info(`Loaded ${loaded} events.`);
}

module.exports = { loadEvents };
