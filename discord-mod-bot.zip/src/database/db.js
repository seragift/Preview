const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

const dbDir = path.join(__dirname, '..', '..', 'database');
if (!fs.existsSync(dbDir)) fs.mkdirSync(dbDir, { recursive: true });

const db = new Database(path.join(dbDir, 'bot.db'));
db.pragma('journal_mode = WAL');

db.exec(`
  CREATE TABLE IF NOT EXISTS guild_configs (
    guild_id TEXT PRIMARY KEY,
    antilink INTEGER NOT NULL DEFAULT 0,
    antispam INTEGER NOT NULL DEFAULT 0,
    antiwebhook INTEGER NOT NULL DEFAULT 0,
    modlog_channel_id TEXT
  );

  CREATE TABLE IF NOT EXISTS temproles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    role_id TEXT NOT NULL,
    added_by TEXT NOT NULL,
    created_at INTEGER NOT NULL,
    expires_at INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS mod_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id TEXT NOT NULL,
    type TEXT NOT NULL,
    user_id TEXT,
    content TEXT,
    action_taken TEXT,
    timestamp INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS whitelists (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id TEXT NOT NULL,
    type TEXT NOT NULL,
    channel_id TEXT,
    role_id TEXT,
    created_at INTEGER NOT NULL
  );

  CREATE INDEX IF NOT EXISTS idx_whitelists_guild_type ON whitelists (guild_id, type);

  CREATE INDEX IF NOT EXISTS idx_temproles_expires ON temproles (expires_at);
  CREATE INDEX IF NOT EXISTS idx_modlogs_guild ON mod_logs (guild_id);
`);

module.exports = db;
