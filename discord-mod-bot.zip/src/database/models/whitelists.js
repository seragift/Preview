const db = require('../db');

const VALID_TYPES = ['antilink', 'antispam', 'antiwebhook'];

function assertType(type) {
  if (!VALID_TYPES.includes(type)) throw new Error(`Invalid whitelist type: ${type}`);
}

function findExact(guildId, type, channelId, roleId) {
  return db
    .prepare(
      `SELECT * FROM whitelists WHERE guild_id = ? AND type = ?
       AND channel_id IS ? AND role_id IS ?`
    )
    .get(guildId, type, channelId, roleId);
}

function addChannel(guildId, type, channelId) {
  assertType(type);
  if (findExact(guildId, type, channelId, null)) return false;
  db.prepare(
    `INSERT INTO whitelists (guild_id, type, channel_id, role_id, created_at) VALUES (?, ?, ?, NULL, ?)`
  ).run(guildId, type, channelId, Date.now());
  return true;
}

function addRole(guildId, type, roleId) {
  assertType(type);
  if (findExact(guildId, type, null, roleId)) return false;
  db.prepare(
    `INSERT INTO whitelists (guild_id, type, channel_id, role_id, created_at) VALUES (?, ?, NULL, ?, ?)`
  ).run(guildId, type, roleId, Date.now());
  return true;
}

function removeChannel(guildId, type, channelId) {
  assertType(type);
  const result = db
    .prepare(`DELETE FROM whitelists WHERE guild_id = ? AND type = ? AND channel_id = ?`)
    .run(guildId, type, channelId);
  return result.changes > 0;
}

function removeRole(guildId, type, roleId) {
  assertType(type);
  const result = db
    .prepare(`DELETE FROM whitelists WHERE guild_id = ? AND type = ? AND role_id = ?`)
    .run(guildId, type, roleId);
  return result.changes > 0;
}

function list(guildId, type) {
  assertType(type);
  return db.prepare(`SELECT * FROM whitelists WHERE guild_id = ? AND type = ?`).all(guildId, type);
}

function countByType(guildId, type) {
  assertType(type);
  return db.prepare(`SELECT COUNT(*) AS c FROM whitelists WHERE guild_id = ? AND type = ?`).get(guildId, type).c;
}

/**
 * Returns true if the given channel or any of the given roleIds is whitelisted for `type`.
 */
function isWhitelisted(guildId, type, channelId, roleIds = []) {
  const entries = list(guildId, type);
  return entries.some(
    (entry) => (entry.channel_id && entry.channel_id === channelId) || (entry.role_id && roleIds.includes(entry.role_id))
  );
}

module.exports = {
  VALID_TYPES,
  addChannel,
  addRole,
  removeChannel,
  removeRole,
  list,
  countByType,
  isWhitelisted
};
