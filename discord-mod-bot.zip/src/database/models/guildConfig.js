const db = require('../db');

const insertDefault = db.prepare(`
  INSERT OR IGNORE INTO guild_configs (guild_id, antilink, antispam, antiwebhook, modlog_channel_id)
  VALUES (?, 0, 0, 0, NULL)
`);

const selectStmt = db.prepare(`SELECT * FROM guild_configs WHERE guild_id = ?`);

function getConfig(guildId) {
  insertDefault.run(guildId);
  return selectStmt.get(guildId);
}

function setToggle(guildId, field, value) {
  if (!['antilink', 'antispam', 'antiwebhook'].includes(field)) {
    throw new Error(`Invalid config field: ${field}`);
  }
  insertDefault.run(guildId);
  db.prepare(`UPDATE guild_configs SET ${field} = ? WHERE guild_id = ?`).run(value ? 1 : 0, guildId);
  return getConfig(guildId);
}

function setModlogChannel(guildId, channelId) {
  insertDefault.run(guildId);
  db.prepare(`UPDATE guild_configs SET modlog_channel_id = ? WHERE guild_id = ?`).run(channelId, guildId);
  return getConfig(guildId);
}

module.exports = { getConfig, setToggle, setModlogChannel };
