const db = require('../db');

const upsertStmt = db.prepare(`
  INSERT INTO bmkg_state (guild_id, last_quake_id) VALUES (?, ?)
  ON CONFLICT(guild_id) DO UPDATE SET last_quake_id = excluded.last_quake_id
`);

function getLastQuakeId(guildId) {
  const row = db.prepare(`SELECT last_quake_id FROM bmkg_state WHERE guild_id = ?`).get(guildId);
  return row ? row.last_quake_id : null;
}

function setLastQuakeId(guildId, quakeId) {
  upsertStmt.run(guildId, quakeId);
}

module.exports = { getLastQuakeId, setLastQuakeId };
