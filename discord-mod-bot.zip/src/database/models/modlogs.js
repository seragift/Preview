const db = require('../db');

const insertStmt = db.prepare(`
  INSERT INTO mod_logs (guild_id, type, user_id, content, action_taken, timestamp)
  VALUES (@guild_id, @type, @user_id, @content, @action_taken, @timestamp)
`);

function addLog({ guildId, type, userId, content, actionTaken }) {
  return insertStmt.run({
    guild_id: guildId,
    type,
    user_id: userId || null,
    content: content || null,
    action_taken: actionTaken || null,
    timestamp: Date.now()
  }).lastInsertRowid;
}

function getRecent(guildId, limit = 20) {
  return db.prepare(`
    SELECT * FROM mod_logs WHERE guild_id = ? ORDER BY timestamp DESC LIMIT ?
  `).all(guildId, limit);
}

module.exports = { addLog, getRecent };
