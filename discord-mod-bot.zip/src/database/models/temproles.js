const db = require('../db');

const insertStmt = db.prepare(`
  INSERT INTO temproles (guild_id, user_id, role_id, added_by, created_at, expires_at)
  VALUES (@guild_id, @user_id, @role_id, @added_by, @created_at, @expires_at)
`);

function addTemprole({ guildId, userId, roleId, addedBy, durationMs }) {
  const now = Date.now();
  const result = insertStmt.run({
    guild_id: guildId,
    user_id: userId,
    role_id: roleId,
    added_by: addedBy,
    created_at: now,
    expires_at: now + durationMs
  });
  return result.lastInsertRowid;
}

function getActiveByUserAndRole(guildId, userId, roleId) {
  return db.prepare(`
    SELECT * FROM temproles WHERE guild_id = ? AND user_id = ? AND role_id = ?
    ORDER BY expires_at DESC LIMIT 1
  `).get(guildId, userId, roleId);
}

function updateExpiry(id, newExpiresAt) {
  db.prepare(`UPDATE temproles SET expires_at = ? WHERE id = ?`).run(newExpiresAt, id);
}

function listActive(guildId) {
  return db.prepare(`
    SELECT * FROM temproles WHERE guild_id = ? AND expires_at > ? ORDER BY expires_at ASC
  `).all(guildId, Date.now());
}

function getExpired() {
  return db.prepare(`SELECT * FROM temproles WHERE expires_at <= ?`).all(Date.now());
}

function remove(id) {
  db.prepare(`DELETE FROM temproles WHERE id = ?`).run(id);
}

module.exports = {
  addTemprole,
  getActiveByUserAndRole,
  updateExpiry,
  listActive,
  getExpired,
  remove
};
