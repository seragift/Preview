const db = require('../db');

const VALID_SERVICES = ['bmkg', 'spotify', 'tiktok', 'capcut'];

const upsertStmt = db.prepare(`
  INSERT INTO service_channels (guild_id, service, channel_id) VALUES (?, ?, ?)
  ON CONFLICT(guild_id, service) DO UPDATE SET channel_id = excluded.channel_id
`);

function assertService(service) {
  if (!VALID_SERVICES.includes(service)) throw new Error(`Invalid service: ${service}`);
}

function setChannel(guildId, service, channelId) {
  assertService(service);
  upsertStmt.run(guildId, service, channelId);
}

function removeChannel(guildId, service) {
  assertService(service);
  const result = db.prepare(`DELETE FROM service_channels WHERE guild_id = ? AND service = ?`).run(guildId, service);
  return result.changes > 0;
}

function getChannel(guildId, service) {
  assertService(service);
  const row = db.prepare(`SELECT channel_id FROM service_channels WHERE guild_id = ? AND service = ?`).get(guildId, service);
  return row ? row.channel_id : null;
}

function findServiceByChannel(guildId, channelId) {
  return db
    .prepare(`SELECT service FROM service_channels WHERE guild_id = ? AND channel_id = ?`)
    .all(guildId, channelId)
    .map((r) => r.service);
}

module.exports = { VALID_SERVICES, setChannel, removeChannel, getChannel, findServiceByChannel };
