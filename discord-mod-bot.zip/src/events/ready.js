const { Events } = require('discord.js');
const logger = require('../utils/logger');
const { startTemproleChecker } = require('../scheduler/temproleChecker');
const { startBmkgChecker } = require('../scheduler/bmkgChecker');

module.exports = {
  name: Events.ClientReady,
  once: true,
  execute(client) {
    logger.info(`Logged in as ${client.user.tag} — serving ${client.guilds.cache.size} guild(s).`);
    client.user.setActivity('/help | menjaga komunitas', { type: 3 });
    startTemproleChecker(client);
    startBmkgChecker(client);
  }
};
