const { AuditLogEvent } = require('discord.js');
const guildConfig = require('../database/models/guildConfig');
const modlogs = require('../database/models/modlogs');
const whitelists = require('../database/models/whitelists');
const { modlogEmbed } = require('../utils/embed');
const logger = require('../utils/logger');

async function sendModlog(guild, embed) {
  const cfg = guildConfig.getConfig(guild.id);
  if (!cfg.modlog_channel_id) return;
  const channel = guild.channels.cache.get(cfg.modlog_channel_id);
  if (!channel) return;
  channel.send({ embeds: [embed] }).catch(() => {});
}

module.exports = {
  name: 'webhookUpdate',
  async execute(channel) {
    const guild = channel.guild;
    if (!guild) return;

    const cfg = guildConfig.getConfig(guild.id);
    if (!cfg.antiwebhook) return;

    try {
      const auditLogs = await guild.fetchAuditLogs({ type: AuditLogEvent.WebhookCreate, limit: 1 });
      const entry = auditLogs.entries.first();
      if (!entry) return;

      // Only act on very recent creations (within 10s) to avoid re-processing old entries
      if (Date.now() - entry.createdTimestamp > 10000) return;

      const executor = entry.executor;
      const executorMember = executor ? await guild.members.fetch(executor.id).catch(() => null) : null;
      const executorRoleIds = executorMember ? [...executorMember.roles.cache.keys()] : [];

      if (whitelists.isWhitelisted(guild.id, 'antiwebhook', channel.id, executorRoleIds)) {
        return; // channel or executor's role is whitelisted, allow the webhook to stay
      }

      const webhooks = await channel.fetchWebhooks().catch(() => null);
      const createdWebhook = webhooks?.get(entry.targetId);

      if (createdWebhook) {
        await createdWebhook.delete('Anti-Webhook: pembuatan webhook tidak diizinkan').catch(() => {});
      }

      modlogs.addLog({
        guildId: guild.id,
        type: 'webhook',
        userId: executor?.id,
        content: `Webhook dibuat di #${channel.name}`,
        actionTaken: 'Webhook dihapus'
      });

      await sendModlog(
        guild,
        modlogEmbed({
          type: 'webhook',
          user: executor?.id,
          content: `Webhook baru terdeteksi di #${channel.name}`,
          actionTaken: 'Webhook otomatis dihapus (Anti-Webhook)'
        })
      );
    } catch (err) {
      logger.error('Error di webhookUpdate handler:', err);
    }
  }
};
