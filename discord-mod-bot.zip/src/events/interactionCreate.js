const { Events } = require('discord.js');
const logger = require('../utils/logger');
const { errorEmbed } = require('../utils/embed');

module.exports = {
  name: Events.InteractionCreate,
  async execute(interaction, client) {
    if (!interaction.isChatInputCommand()) return;

    const command = client.commands.get(interaction.commandName);
    if (!command) {
      logger.warn(`Command tidak ditemukan: ${interaction.commandName}`);
      return;
    }

    try {
      await command.execute(interaction, client);
    } catch (err) {
      logger.error(`Error menjalankan command ${interaction.commandName}:`, err);
      const payload = { embeds: [errorEmbed('Terjadi kesalahan saat menjalankan command ini.')], ephemeral: true };
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp(payload).catch(() => {});
      } else {
        await interaction.reply(payload).catch(() => {});
      }
    }
  }
};
