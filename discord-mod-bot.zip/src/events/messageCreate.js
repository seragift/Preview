const { Events, PermissionsBitField, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const guildConfig = require('../database/models/guildConfig');
const modlogs = require('../database/models/modlogs');
const whitelists = require('../database/models/whitelists');
const serviceChannels = require('../database/models/serviceChannels');
const config = require('../../config.json');
const { modlogEmbed, baseEmbed, errorEmbed } = require('../utils/embed');
const { extractObject } = require('../utils/responseUtil');
const api = require('../utils/apiClient');
const logger = require('../utils/logger');

const URL_REGEX = /(https?:\/\/[^\s]+)|(discord\.gg\/[^\s]+)/gi;

const SPOTIFY_REGEX = /https?:\/\/(open\.)?spotify\.com\/\S+/i;
const TIKTOK_REGEX = /https?:\/\/(www\.|vt\.|vm\.)?tiktok\.com\/\S+/i;
const CAPCUT_REGEX = /https?:\/\/(www\.)?capcut\.com\/\S+/i;

const DOWNLOADER_TITLES = {
  spotify: '🎵 Spotify Downloader',
  tiktok: '🎬 TikTok Downloader',
  capcut: '📹 CapCut Downloader'
};

// In-memory spam tracker: Map<guildId:userId:channelId, { id, timestamp }[]>
const spamTracker = new Map();

async function sendModlog(guild, embed) {
  const cfg = guildConfig.getConfig(guild.id);
  if (!cfg.modlog_channel_id) return;
  const channel = guild.channels.cache.get(cfg.modlog_channel_id);
  if (!channel) return;
  channel.send({ embeds: [embed] }).catch(() => {});
}

function memberRoleIds(member) {
  return [...member.roles.cache.keys()];
}

function detectDownloaderLink(content) {
  const spotify = content.match(SPOTIFY_REGEX);
  if (spotify) return { service: 'spotify', url: spotify[0] };
  const tiktok = content.match(TIKTOK_REGEX);
  if (tiktok) return { service: 'tiktok', url: tiktok[0] };
  const capcut = content.match(CAPCUT_REGEX);
  if (capcut) return { service: 'capcut', url: capcut[0] };
  return null;
}

/**
 * Detects Spotify/TikTok/CapCut links and processes them via the downloader API,
 * but ONLY inside the channel configured via /setchannel for that service.
 * Returns true if the message was handled (so antilink/antispam should be skipped).
 */
async function handleDownloaderLinks(message) {
  const detected = detectDownloaderLink(message.content);
  if (!detected) return false;

  const { service, url } = detected;
  const boundChannelId = serviceChannels.getChannel(message.guild.id, service);
  if (!boundChannelId || boundChannelId !== message.channel.id) return false;

  await message.channel.sendTyping().catch(() => {});

  try {
    let raw;
    if (service === 'spotify') raw = await api.downloadSpotify(url);
    else if (service === 'tiktok') raw = await api.downloadTiktok(url);
    else raw = await api.downloadCapcut(url);

    const data = extractObject(raw);
    const downloadUrl =
      data.download_url ||
      data.url ||
      data.play ||
      (Array.isArray(data.video) && data.video[0]) ||
      (Array.isArray(data.audio) && data.audio[0]) ||
      null;

    const embed = baseEmbed()
      .setTitle(DOWNLOADER_TITLES[service])
      .setDescription(data.title || data.caption || 'Link berhasil diproses.')
      .setThumbnail(data.thumbnail || data.cover || null);

    const components = [];
    if (downloadUrl) {
      components.push(
        new ActionRowBuilder().addComponents(
          new ButtonBuilder().setLabel('Download').setStyle(ButtonStyle.Link).setURL(downloadUrl)
        )
      );
    }

    await message.reply({ embeds: [embed], components });
  } catch (err) {
    logger.error(`Gagal memproses link ${service}:`, err);
    await message.reply({ embeds: [errorEmbed(`Gagal memproses link ${service}. Coba lagi nanti.`)] }).catch(() => {});
  }

  return true;
}

async function handleAntilink(message) {
  const matches = message.content.match(URL_REGEX);
  if (!matches) return false;

  const hasBypass = message.member.permissions.has(PermissionsBitField.Flags.ManageMessages);
  if (hasBypass) return false;

  if (whitelists.isWhitelisted(message.guild.id, 'antilink', message.channel.id, memberRoleIds(message.member))) {
    return false;
  }

  await message.delete().catch(() => {});
  modlogs.addLog({
    guildId: message.guild.id,
    type: 'link',
    userId: message.author.id,
    content: message.content,
    actionTaken: 'Pesan dihapus'
  });
  await sendModlog(
    message.guild,
    modlogEmbed({
      type: 'link',
      user: message.author.id,
      content: message.content,
      actionTaken: 'Pesan dihapus (Anti-Link)'
    })
  );
  return true;
}

async function handleAntispam(message) {
  const hasBypass = message.member.permissions.has(PermissionsBitField.Flags.ManageMessages);
  if (hasBypass) return false;

  if (whitelists.isWhitelisted(message.guild.id, 'antispam', message.channel.id, memberRoleIds(message.member))) {
    return false;
  }

  const key = `${message.guild.id}:${message.author.id}:${message.channel.id}`;
  const now = Date.now();
  const { maxMessages, timeWindowMs, muteDurationMs } = config.antispam;

  const recent = (spamTracker.get(key) || []).filter((m) => now - m.timestamp < timeWindowMs);
  recent.push({ id: message.id, timestamp: now });
  spamTracker.set(key, recent);

  if (recent.length < maxMessages) return false;

  spamTracker.delete(key);

  let actionTaken = `${recent.length} pesan dihapus`;
  if (message.member.moderatable) {
    await message.member.timeout(muteDurationMs, 'Terdeteksi spam otomatis').catch(() => {});
    actionTaken += `, timeout ${Math.round(muteDurationMs / 1000)} detik`;
  }

  const ids = recent.map((m) => m.id);
  const deleted = await message.channel.bulkDelete(ids, true).catch(() => null);
  if (!deleted) {
    // fallback: delete one by one if bulkDelete fails (e.g. some messages already gone)
    for (const id of ids) {
      const msg = await message.channel.messages.fetch(id).catch(() => null);
      if (msg) await msg.delete().catch(() => {});
    }
  }

  modlogs.addLog({
    guildId: message.guild.id,
    type: 'spam',
    userId: message.author.id,
    content: `${recent.length} pesan beruntun`,
    actionTaken
  });
  await sendModlog(
    message.guild,
    modlogEmbed({
      type: 'spam',
      user: message.author.id,
      content: `Mengirim ${recent.length} pesan dalam ${Math.round(timeWindowMs / 1000)} detik`,
      actionTaken
    })
  );
  return true;
}

module.exports = {
  name: Events.MessageCreate,
  async execute(message) {
    if (message.author.bot || !message.guild || !message.member) return;

    const cfg = guildConfig.getConfig(message.guild.id);

    try {
      const downloaderHandled = await handleDownloaderLinks(message);
      if (downloaderHandled) return;

      if (cfg.antilink) {
        const handled = await handleAntilink(message);
        if (handled) return;
      }
      if (cfg.antispam) {
        await handleAntispam(message);
      }
    } catch (err) {
      logger.error('Error di messageCreate handler:', err);
    }
  }
};
