const { Events, PermissionsBitField, AttachmentBuilder } = require('discord.js');
const guildConfig = require('../database/models/guildConfig');
const modlogs = require('../database/models/modlogs');
const whitelists = require('../database/models/whitelists');
const serviceChannels = require('../database/models/serviceChannels');
const config = require('../../config.json');
const { modlogEmbed, baseEmbed, errorEmbed } = require('../utils/embed');
const { firstValue, validUrl, collectImages, downloadBuffer } = require('../utils/mediaHelpers');
const api = require('../utils/apiClient');
const logger = require('../utils/logger');

const URL_REGEX = /(https?:\/\/[^\s]+)|(discord\.gg\/[^\s]+)/gi;
const TIKTOK_REGEX = /https?:\/\/(www\.|vt\.|vm\.)?tiktok\.com\/\S+/i;

// In-memory spam tracker: Map<guildId:userId:channelId, { id, timestamp }[]>
const spamTracker = new Map();

async function sendModlog(guild, embed) {
  const cfg = guildConfig.getConfig(guild.id);
  if (!cfg.modlog_channel_id) return;
  const channel = guild.channels.cache.get(cfg.modlog_channel_id);
  if (!channel) return;
  channel.send({ embeds: [embed] }).catch(() => {});
}

function memberRoleIds(member) {
  return [...member.roles.cache.keys()];
}

/**
 * Detects TikTok links and downloads the actual video/photo, attaching it directly
 * to the reply — but ONLY inside the channel configured via /setchannel for TikTok.
 * Returns true if the message was handled (so antilink/antispam should be skipped).
 */
async function handleDownloaderLinks(message) {
  const match = message.content.match(TIKTOK_REGEX);
  if (!match) return false;

  const boundChannelId = serviceChannels.getChannel(message.guild.id, 'tiktok');
  if (!boundChannelId || boundChannelId !== message.channel.id) return false;

  const url = match[0];
  await message.channel.sendTyping().catch(() => {});

  try {
    const raw = await api.downloadTiktok(url);
    if (raw?.Status === false) throw new Error(raw.Error || 'TikTok API error');

    const result = raw.Result || {};
    const title = firstValue(result, ['Title', 'title']) || 'TikTok';

    // 1) Coba download video (utamakan link "Downloads" resmi dari API, HD kalau ada)
    const downloads = Array.isArray(result.Downloads) ? result.Downloads : [];
    const mp4Downloads = downloads.filter((d) => /mp4/i.test(d?.Type || ''));
    const hd = mp4Downloads.find((d) => /hd/i.test(d?.Type || ''));
    const videoUrl = (hd || mp4Downloads[0])?.Url || firstValue(result, ['Preview_video', 'preview_video', 'Video', 'video']);

    if (validUrl(videoUrl)) {
      try {
        const buffer = await downloadBuffer(videoUrl);
        const attachment = new AttachmentBuilder(buffer, { name: 'tiktok.mp4' });
        const embed = baseEmbed().setTitle('🎬 TikTok Downloader').setDescription(title);
        await message.reply({ embeds: [embed], files: [attachment] });
        return true;
      } catch (err) {
        logger.warn(`TikTok video gagal diunduh, coba fallback: ${err.message}`);
      }
    }

    // 2) Fallback: slideshow/foto
    const images = collectImages(result);
    if (images.length > 0) {
      const files = [];
      for (let i = 0; i < Math.min(images.length, 10); i++) {
        try {
          const buffer = await downloadBuffer(images[i]);
          files.push(new AttachmentBuilder(buffer, { name: `tiktok-${i + 1}.jpg` }));
        } catch (err) {
          logger.warn(`TikTok image ${i + 1} gagal diunduh: ${err.message}`);
        }
      }
      if (files.length > 0) {
        await message.reply({ content: `📸 ${files.length} gambar berhasil diunduh — **${title}**`, files });
        return true;
      }
    }

    // 3) Fallback terakhir: thumbnail saja
    const thumbnail = firstValue(result, ['Thumbnail', 'thumbnail', 'Poster', 'poster']);
    if (validUrl(thumbnail)) {
      try {
        const buffer = await downloadBuffer(thumbnail);
        const attachment = new AttachmentBuilder(buffer, { name: 'tiktok.jpg' });
        await message.reply({ content: `📸 Hanya thumbnail yang tersedia — **${title}**`, files: [attachment] });
        return true;
      } catch (err) {
        logger.warn(`TikTok thumbnail gagal diunduh: ${err.message}`);
      }
    }

    await message.reply({ embeds: [errorEmbed('Media TikTok tidak dapat diambil.')] });
  } catch (err) {
    logger.error('Gagal memproses link TikTok:', err);
    await message.reply({ embeds: [errorEmbed('Gagal memproses link TikTok. Coba lagi nanti.')] }).catch(() => {});
  }

  return true;
}

async function handleAntilink(message) {
  const matches = message.content.match(URL_REGEX);
  if (!matches) return false;

  const hasBypass = message.member.permissions.has(PermissionsBitField.Flags.ManageMessages);
  if (hasBypass) return false;

  if (whitelists.isWhitelisted(message.guild.id, 'antilink', message.channel.id, memberRoleIds(message.member))) {
    return false;
  }

  await message.delete().catch(() => {});
  modlogs.addLog({
    guildId: message.guild.id,
    type: 'link',
    userId: message.author.id,
    content: message.content,
    actionTaken: 'Pesan dihapus'
  });
  await sendModlog(
    message.guild,
    modlogEmbed({
      type: 'link',
      user: message.author.id,
      content: message.content,
      actionTaken: 'Pesan dihapus (Anti-Link)'
    })
  );
  return true;
}

async function handleAntispam(message) {
  const hasBypass = message.member.permissions.has(PermissionsBitField.Flags.ManageMessages);
  if (hasBypass) return false;

  if (whitelists.isWhitelisted(message.guild.id, 'antispam', message.channel.id, memberRoleIds(message.member))) {
    return false;
  }

  const key = `${message.guild.id}:${message.author.id}:${message.channel.id}`;
  const now = Date.now();
  const { maxMessages, timeWindowMs, muteDurationMs } = config.antispam;

  const recent = (spamTracker.get(key) || []).filter((m) => now - m.timestamp < timeWindowMs);
  recent.push({ id: message.id, timestamp: now });
  spamTracker.set(key, recent);

  if (recent.length < maxMessages) return false;

  spamTracker.delete(key);

  let actionTaken = `${recent.length} pesan dihapus`;
  if (message.member.moderatable) {
    await message.member.timeout(muteDurationMs, 'Terdeteksi spam otomatis').catch(() => {});
    actionTaken += `, timeout ${Math.round(muteDurationMs / 1000)} detik`;
  }

  const ids = recent.map((m) => m.id);
  const deleted = await message.channel.bulkDelete(ids, true).catch(() => null);
  if (!deleted) {
    // fallback: delete one by one if bulkDelete fails (e.g. some messages already gone)
    for (const id of ids) {
      const msg = await message.channel.messages.fetch(id).catch(() => null);
      if (msg) await msg.delete().catch(() => {});
    }
  }

  modlogs.addLog({
    guildId: message.guild.id,
    type: 'spam',
    userId: message.author.id,
    content: `${recent.length} pesan beruntun`,
    actionTaken
  });
  await sendModlog(
    message.guild,
    modlogEmbed({
      type: 'spam',
      user: message.author.id,
      content: `Mengirim ${recent.length} pesan dalam ${Math.round(timeWindowMs / 1000)} detik`,
      actionTaken
    })
  );
  return true;
}

module.exports = {
  name: Events.MessageCreate,
  async execute(message) {
    if (message.author.bot || !message.guild || !message.member) return;

    const cfg = guildConfig.getConfig(message.guild.id);

    try {
      const downloaderHandled = await handleDownloaderLinks(message);
      if (downloaderHandled) return;

      if (cfg.antilink) {
        const handled = await handleAntilink(message);
        if (handled) return;
      }
      if (cfg.antispam) {
        await handleAntispam(message);
      }
    } catch (err) {
      logger.error('Error di messageCreate handler:', err);
    }
  }
};
