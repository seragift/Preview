require('dotenv').config();
const { Client, GatewayIntentBits, Partials } = require('discord.js');
const logger = require('./src/utils/logger');
const { loadCommands } = require('./src/handlers/commandHandler');
const { loadEvents } = require('./src/handlers/eventHandler');
const { deployCommands } = require('./deploy-commands');

require('./src/database/db'); // initialize database + tables on boot

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildWebhooks
  ],
  partials: [Partials.Message, Partials.Channel]
});

loadCommands(client);
loadEvents(client);

process.on('unhandledRejection', (err) => logger.error('Unhandled promise rejection:', err));
process.on('uncaughtException', (err) => logger.error('Uncaught exception:', err));

(async () => {
  await deployCommands(); // reset lalu upload ulang semua slash command tiap start
  await client.login(process.env.TOKEN);
})();
