require('dotenv').config();
const { REST, Routes } = require('discord.js');
const { walk } = require('./src/handlers/commandHandler');
const path = require('path');
const logger = require('./src/utils/logger');

function collectCommandData() {
  const commandsDir = path.join(__dirname, 'src', 'commands');
  const files = walk(commandsDir);
  const commandData = [];

  for (const file of files) {
    delete require.cache[require.resolve(file)];
    const command = require(file);
    if (!command?.data) {
      logger.warn(`Melewati file tanpa "data": ${file}`);
      continue;
    }
    commandData.push(command.data.toJSON());
  }

  return commandData;
}

/**
 * Uploads the current command set as a full bulk overwrite.
 * A single PUT to this endpoint already replaces the ENTIRE global command list —
 * anything not included gets removed automatically, so no separate "reset" step
 * is needed (doing reset-then-upload as two PUTs actually doubles propagation delay).
 */
async function deployCommands() {
  const rest = new REST().setToken(process.env.TOKEN);
  const commandData = collectCommandData();

  try {
    logger.info(`Mendaftarkan ${commandData.length} slash command secara global (bulk overwrite)...`);
    await rest.put(Routes.applicationCommands(process.env.CLIENT_ID), { body: commandData });
    logger.info('Slash command berhasil di-deploy. (Biasanya muncul dalam beberapa menit, jarang lebih dari 1 jam)');
  } catch (err) {
    logger.error('Gagal deploy slash command:', err);
  }
}

// Allow running standalone: `node deploy-commands.js` or `npm run deploy`
if (require.main === module) {
  deployCommands();
}

module.exports = { deployCommands, collectCommandData };
