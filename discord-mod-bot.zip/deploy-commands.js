require('dotenv').config();
const { REST, Routes } = require('discord.js');
const { walk } = require('./src/handlers/commandHandler');
const path = require('path');
const logger = require('./src/utils/logger');

function collectCommandData() {
  const commandsDir = path.join(__dirname, 'src', 'commands');
  const files = walk(commandsDir);
  const commandData = [];

  for (const file of files) {
    delete require.cache[require.resolve(file)];
    const command = require(file);
    if (!command?.data) {
      logger.warn(`Melewati file tanpa "data": ${file}`);
      continue;
    }
    commandData.push(command.data.toJSON());
  }

  return commandData;
}

/**
 * Resets (clears) all global slash commands, then uploads the current command set.
 * Safe to call every time the bot starts.
 */
async function deployCommands() {
  const rest = new REST().setToken(process.env.TOKEN);
  const commandData = collectCommandData();

  try {
    logger.info('Mereset slash command lama...');
    await rest.put(Routes.applicationCommands(process.env.CLIENT_ID), { body: [] });

    logger.info(`Mendaftarkan ${commandData.length} slash command baru secara global...`);
    await rest.put(Routes.applicationCommands(process.env.CLIENT_ID), { body: commandData });

    logger.info('Slash command berhasil di-deploy ulang. (Bisa memakan waktu hingga 1 jam untuk muncul di semua server)');
  } catch (err) {
    logger.error('Gagal deploy slash command:', err);
  }
}

// Allow running standalone: `node deploy-commands.js` or `npm run deploy`
if (require.main === module) {
  deployCommands();
}

module.exports = { deployCommands, collectCommandData };
