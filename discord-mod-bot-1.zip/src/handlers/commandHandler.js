const fs = require('fs');
const path = require('path');
const { Collection } = require('discord.js');
const logger = require('../utils/logger');

function walk(dir) {
  let files = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      files = files.concat(walk(fullPath));
    } else if (entry.name.endsWith('.js')) {
      files.push(fullPath);
    }
  }
  return files;
}

function loadCommands(client) {
  client.commands = new Collection();
  const commandsDir = path.join(__dirname, '..', 'commands');
  const files = walk(commandsDir);

  for (const file of files) {
    delete require.cache[require.resolve(file)];
    const command = require(file);
    if (!command?.data || !command?.execute) {
      logger.warn(`Command file tidak valid (dilewati): ${file}`);
      continue;
    }
    client.commands.set(command.data.name, command);
  }

  logger.info(`Loaded ${client.commands.size} commands.`);
  return client.commands;
}

module.exports = { loadCommands, walk };
