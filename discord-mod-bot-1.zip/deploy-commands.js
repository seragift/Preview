require('dotenv').config();
const { REST, Routes } = require('discord.js');
const { walk } = require('./src/handlers/commandHandler');
const path = require('path');
const logger = require('./src/utils/logger');

async function main() {
  const commandsDir = path.join(__dirname, 'src', 'commands');
  const files = walk(commandsDir);
  const commandData = [];

  for (const file of files) {
    const command = require(file);
    if (!command?.data) {
      logger.warn(`Melewati file tanpa "data": ${file}`);
      continue;
    }
    commandData.push(command.data.toJSON());
  }

  const rest = new REST().setToken(process.env.TOKEN);

  try {
    logger.info(`Mendaftarkan ${commandData.length} slash command secara global...`);
    await rest.put(Routes.applicationCommands(process.env.CLIENT_ID), { body: commandData });
    logger.info('Slash command berhasil didaftarkan. (Bisa memakan waktu hingga 1 jam untuk muncul di semua server)');
  } catch (err) {
    logger.error('Gagal mendaftarkan slash command:', err);
  }
}

main();
