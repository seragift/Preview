# SA-MP Anti-Stealer / Modpack Security Scanner v2

Bot Discord untuk **defensive security**: mendeteksi indikasi stealer/malware pada file
SA-MP/GTA San Andreas (credential stealing, keylogging, data exfiltration, webhook
berbahaya, process injection, obfuscation) memakai **static analysis saja**.

**Bot ini tidak pernah menjalankan file yang diupload user.** Semua analisis dilakukan
dengan membaca byte file secara langsung: hash, YARA, parsing header PE, entropy, dan
string scanning. Tidak ada file yang di-execute, di-load sebagai DLL, atau dijalankan
lewat shell dalam bentuk apa pun.

## Catatan Desain (mengikuti revisi terakhir)

- **Struktur**: `.env`, `config.json`, `index.js`, `package.json` ada di root project;
  semua kode lain ada di `src/`.
- **Multi-server**: tidak ada `GUILD_ID` di `.env`. Slash command didaftarkan secara
  **global** (`npm run deploy`), dan setiap server Discord punya database SQLite sendiri
  di `src/data/guilds/<guildId>.db` — channel scanner, channel log, riwayat scan,
  whitelist, dan blocklist sepenuhnya terpisah antar server.
- Project memakai ES Modules (`"type": "module"`) supaya bisa pakai versi terbaru
  `file-type` dan `execa` (keduanya sudah ESM-only di versi terbaru).

## Daftar Isi

1. Requirements
2. Instalasi Node.js
3. Setup Bot Discord
4. Discord Intents (wajib)
5. Install YARA (Ubuntu 22.04/24.04)
6. Install ClamAV (Ubuntu 22.04/24.04)
7. Install Archive Tools
8. npm install
9. config.json
10. .env
11. Menjalankan Bot
12. Deploy dengan PM2
13. Deploy dengan Docker
14. Menambah YARA Rule Baru
15. Penanganan False Positive
16. Keterbatasan Keamanan

## 1. Requirements

- Node.js >= 20
- YARA (system binary)
- ClamAV / `clamscan` (opsional tapi sangat direkomendasikan)
- `unrar` dan `p7zip-full` (untuk scan isi file `.rar` dan `.7z`)

## 2. Instalasi Node.js

```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs
node --version   # pastikan v20.x atau lebih baru
```

## 3. Setup Bot Discord

1. Buka https://discord.com/developers/applications → **New Application**.
2. Tab **Bot** → **Reset Token** → simpan untuk `DISCORD_TOKEN`.
3. Tab **General Information** → salin **Application ID** untuk `CLIENT_ID`.
4. Undang bot lewat OAuth2 URL Generator: scope `bot` + `applications.commands`,
   permission minimal `Send Messages`, `Embed Links`, `Attach Files`,
   `Read Message History`, `Use Slash Commands`.

## 4. Discord Intents (WAJIB)

Di tab **Bot** → **Privileged Gateway Intents**, aktifkan:

- ✅ **Message Content Intent**

Tanpa ini bot **tidak bisa melihat attachment** pada pesan yang bukan dari/mention bot,
jadi scan otomatis tidak akan pernah jalan. Ini penyebab paling umum bot "diam saja"
saat file diupload ke channel scanner.

## 5. Install YARA (Ubuntu 22.04 / 24.04)

```bash
sudo apt update
sudo apt install -y yara
yara --version
```

## 6. Install ClamAV (Ubuntu 22.04 / 24.04)

```bash
sudo apt update
sudo apt install -y clamav clamav-daemon

sudo systemctl stop clamav-freshclam
sudo freshclam
sudo systemctl start clamav-freshclam

clamscan --version
```

Bot memakai `clamscan` (CLI), bukan daemon socket — lebih sederhana untuk deploy, sedikit
lebih lambat per-scan. Kalau `clamscan` tidak ditemukan di PATH, bot tetap jalan normal
hanya dengan YARA + static analysis (lihat bagian 30 di spec awal kamu) — tidak crash.

## 7. Install Archive Tools

```bash
sudo apt install -y unrar p7zip-full
```

## 8. npm install

```bash
cd samp-anti-stealer-bot
npm install
```

> Kalau instalasi `better-sqlite3` gagal karena perlu kompilasi native:
> `sudo apt install -y build-essential python3`, lalu `npm install` lagi.
> Kalau versi salah satu paket di `package.json` sudah tidak tersedia di npm registry,
> jalankan `npm install <nama-paket>@latest` untuk paket itu saja.

## 9. config.json

File ini di root, isinya **hanya setting global/non-guild** (bukan secret):

| Key | Keterangan |
|---|---|
| `maxFileSizeMB` | Batas ukuran file biasa |
| `maxArchiveSizeMB` | Batas ukuran file archive (sebelum diekstrak) |
| `maxExtractedSizeMB` | Batas total ukuran hasil ekstraksi (anti zip-bomb) |
| `maxFilesInArchive` | Batas jumlah file dalam satu archive |
| `scanTimeoutSeconds` | Timeout per proses eksternal (YARA/ClamAV/unrar/7z) |
| `maxTotalScanTimeSeconds` | Timeout keseluruhan satu scan |
| `maxConcurrentScans` | Jumlah scan paralel maksimum |
| `maxScansPerUserPerMinute` | Rate limit per user |
| `clamavEnabled` / `yaraEnabled` / `peAnalysisEnabled` | Toggle fitur |
| `entropyThreshold` | Ambang batas "high entropy" (default 7.2 dari skala 0-8) |

Channel scanner dan channel log **tidak ada di file ini** — itu diatur per-server lewat
`/setchannel` dan `/setlogchannel`, dan disimpan di database masing-masing guild.

## 10. .env

Copy `.env.example` ke `.env`, lalu isi:

```
DISCORD_TOKEN=isi_token_bot_kamu
CLIENT_ID=isi_application_id_kamu
```

Tidak ada `GUILD_ID` — ini disengaja, lihat "Catatan Desain" di atas. Jangan pernah
commit file `.env` (sudah masuk `.gitignore`).

## 11. Menjalankan Bot

```bash
npm run deploy   # daftarkan slash command secara GLOBAL (sekali di awal, atau tiap command berubah)
npm start
```

> Command global butuh waktu **sampai ~1 jam** untuk muncul di semua server setelah
> deploy pertama kali (limitasi API Discord, bukan bug). Command yang sudah pernah
> didaftarkan akan langsung tersedia begitu bot diundang ke server baru.

Setelah bot online, di setiap server jalankan:

```
/setchannel #nama-channel-scanner
/setlogchannel #nama-channel-log      (opsional)
```

## 12. Deploy dengan PM2

```bash
npm install -g pm2
pm2 start index.js --name samp-scanner
pm2 save
pm2 startup   # ikuti instruksi yang muncul supaya PM2 auto-start saat reboot
```

## 13. Deploy dengan Docker

```bash
docker build -t samp-scanner .

docker run -d --name samp-scanner \
  --env-file .env \
  -v $(pwd)/src/data:/app/src/data \
  -v $(pwd)/src/logs:/app/src/logs \
  --memory=512m --cpus=1 \
  --restart unless-stopped \
  samp-scanner
```

`--memory` dan `--cpus` di `docker run` inilah yang benar-benar membatasi resource
container — Dockerfile sendiri tidak bisa memaksa limit itu. Jalankan `freshclam` secara
berkala di luar container (cron/systemd timer) supaya database ClamAV tidak basi, karena
image tidak fetch definitions saat build (build environment bisa saja tanpa akses internet).

## 14. Menambah YARA Rule Baru

1. Buat file baru di `src/yara/`, misalnya `src/yara/my_new_rule.yar`.
2. Tambahkan baris `include "my_new_rule.yar"` di `src/yara/master.yar`.
3. Setiap rule **wajib** punya `meta: category = "..." severity = "..." description = "..."`
   — ini yang dibaca `src/scanner/yaraScanner.js` untuk menyusun hasil scan. Nilai
   `severity` yang valid: `critical` (langsung memaksa verdict MALICIOUS), `high`,
   `medium`, `low`.
4. Ikuti prinsip semua rule yang sudah ada: **jangan** buat rule yang fire dari satu
   indikator lemah saja (satu nama API, satu keyword) — selalu syaratkan kombinasi
   minimal 2 indikator, seperti yang diminta di spec awal kamu.

## 15. Penanganan False Positive

Sistem ini memisahkan **detection** (apa yang ditemukan) dari **verdict** (kesimpulan
risiko). Kalau file legitimate ke-flag SUSPICIOUS/HIGH RISK padahal aman:

```
/whitelist hash:<sha256> reason:"alasan kamu"
```

Verdict berubah jadi 🟢 TRUSTED, tapi detection asli tetap tersimpan dan bisa dilihat
lewat `/scaninfo` — riwayatnya tidak hilang, cuma reputasinya yang berubah. Kebalikannya,
kalau ada hash yang terbukti malicious tapi score-nya belum cukup untuk auto-MALICIOUS,
admin bisa paksa lewat:

```
/blocklist hash:<sha256> reason:"alasan kamu"
```

## 16. Keterbatasan Keamanan (baca sebelum dipakai production)

- **Static analysis tidak bisa menjamin file 100% aman atau 100% berbahaya** — ini alat
  bantu deteksi, bukan kepastian mutlak. Pesan ini sengaja selalu muncul di footer setiap
  hasil scan.
- Parser PE (`src/scanner/peScanner.js`) ditulis custom tanpa dependency eksternal, supaya
  tidak bergantung pada API package pihak ketiga yang bisa berubah sewaktu-waktu. Yang
  di-parse: DOS/NT header, section table + entropy per section, import table (named
  imports), export table dasar. **Belum** mencakup: resource directory, TLS callback,
  rich header, dan verifikasi digital signature (Authenticode).
- Listing isi file `.rar`/`.7z` sebelum ekstraksi mem-parsing output teks dari CLI
  `unrar`/`7z`, yang formatnya best-effort (bisa sedikit berbeda antar versi tool). Karena
  itu ada lapisan kedua: setelah ekstraksi, ukuran & jumlah file **diverifikasi ulang**
  secara aktual dan dihapus otomatis kalau ternyata melebihi batas.
- Archive di dalam archive **tidak diekstrak lebih lanjut** (dibatasi 1 level) — hanya
  ditandai `NESTED_ARCHIVE_NOT_EXTRACTED` di hasil per-file, supaya tidak jadi celah
  archive-bomb bersarang.
- Whitelist/blocklist/riwayat scan bersifat **per-server** (per file database), tidak
  dibagikan antar server. Kalau nanti butuh reputation hash yang dibagikan lintas server,
  itu bisa ditambahkan sebagai database global terpisah di atas struktur yang sudah ada.
- Bot ini adalah lapisan bantu, bukan pengganti kewaspadaan admin/user saat menginstall
  mod dari sumber yang tidak dikenal.
