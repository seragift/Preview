/*
    Process injection indicators. Requires 2+ of these APIs together (spec section 17) -
    OpenProcess alone is extremely common (any tool that reads another process's window
    title, checks if a game is running, etc. calls it) and must never fire by itself.
*/

rule Suspicious_Process_Injection_APIs
{
    meta:
        category = "process_injection"
        severity = "medium"
        description = "Combination of APIs commonly associated with remote process injection"
    strings:
        $p1 = "OpenProcess" ascii wide
        $p2 = "VirtualAllocEx" ascii wide
        $p3 = "WriteProcessMemory" ascii wide
        $p4 = "CreateRemoteThread" ascii wide
        $p5 = "NtWriteVirtualMemory" ascii wide
        $p6 = "NtCreateThreadEx" ascii wide
    condition:
        2 of them
}
