/*
    Obfuscation/packing indicators (spec section 20). Low severity by design - packed
    executables and base64 blobs are extremely common in legitimate software too
    (installers, DRM, asset bundles). These only nudge the score, never decide it alone.
*/

rule Known_Packer_Section_Names
{
    meta:
        category = "obfuscation"
        severity = "low"
        description = "Section/marker names associated with common executable packers or protectors"
    strings:
        $upx1 = "UPX0" ascii
        $upx2 = "UPX1" ascii
        $upx3 = "UPX!" ascii
        $themida = ".themida" ascii nocase
        $vmp = ".vmp0" ascii nocase
        $aspack = ".aspack" ascii nocase
    condition:
        any of them
}

rule Long_Base64_Blob
{
    meta:
        category = "obfuscation"
        severity = "low"
        description = "Long base64-like encoded string block - may indicate an embedded payload or obfuscated data"
    strings:
        $b64 = /[A-Za-z0-9+\/]{200,}={0,2}/
    condition:
        $b64
}
