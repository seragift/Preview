/*
    Input capture (keylogging) indicators. A SINGLE API here (e.g. GetAsyncKeyState) is
    common in totally legitimate software (games poll key state constantly for input).
    The rule below requires at least 2 of these APIs together before it fires at all,
    matching spec section 12's explicit requirement to never treat one API as malware.
*/

rule Suspicious_Keyboard_Hook_APIs
{
    meta:
        category = "input_capture"
        severity = "medium"
        description = "Combination of keyboard state/hook APIs commonly used for keylogging"
    strings:
        $api1 = "GetAsyncKeyState" ascii wide
        $api2 = "GetKeyState" ascii wide
        $api3 = "GetKeyboardState" ascii wide
        $api4 = "SetWindowsHookExA" ascii wide
        $api5 = "SetWindowsHookExW" ascii wide
    condition:
        2 of ($api*)
}
