/*
    SA-MP/GTA San Andreas modding context (spec section 21). On its own this just means
    "this file is part of a GTA SA / SA-MP mod" - completely normal and expected for
    everything this bot scans. It only becomes a HIGH severity finding when a modding
    artifact (CLEO/MoonLoader/SAMPFUNCS/modloader) is found together with credential-
    capture or webhook indicators, i.e. a plugin that looks like a game mod but also
    looks like a stealer.
*/

rule SAMP_GTA_Modding_Artifact
{
    meta:
        category = "samp_context"
        severity = "info"
        description = "File references common GTA SA / SA-MP modding components (context only, not inherently malicious)"
    strings:
        $c1 = "CLEO" ascii wide
        $c2 = "MoonLoader" ascii wide nocase
        $c3 = "SAMPFUNCS" ascii wide nocase
        $c4 = "modloader" ascii wide nocase
        $c5 = "samp.dll" ascii wide nocase
        $c6 = "gta_sa.exe" ascii wide nocase
    condition:
        any of them
}

rule SAMP_Plugin_With_Credential_Or_Webhook_Indicators
{
    meta:
        category = "exfiltration"
        severity = "high"
        description = "SA-MP/GTA modding artifact combined with credential-capture or webhook indicators - high risk of a stealer plugin disguised as a game mod"
    strings:
        $ctx1 = "CLEO" ascii wide
        $ctx2 = "MoonLoader" ascii wide nocase
        $ctx3 = "SAMPFUNCS" ascii wide nocase
        $ctx4 = "modloader" ascii wide nocase
        $wh1 = "discord.com/api/webhooks/" ascii wide nocase
        $wh2 = "discordapp.com/api/webhooks/" ascii wide nocase
        $cred1 = "Login Data" ascii wide
        $cred2 = "ssfn" ascii wide
        $api1 = "GetAsyncKeyState" ascii wide
    condition:
        any of ($ctx*) and (any of ($wh*) or any of ($cred*) or $api1)
}
