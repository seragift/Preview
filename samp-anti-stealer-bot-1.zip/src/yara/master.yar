/*
    SA-MP Anti-Stealer / Modpack Security Scanner - Master YARA rule file.

    This file only includes the category modules below - it defines no rules itself.
    Every rule in this project is a passive pattern-matcher: YARA rules cannot execute
    code or take any action, they can only report whether a byte/string pattern was
    found. All rules here follow the same defensive principle stated throughout the
    project spec: a single API name or keyword is never enough on its own, detections
    are built from COMBINATIONS of weak indicators. See riskEngine.js for how these
    detections are turned into a score and a verdict.
*/

include "credential_capture.yar"
include "input_capture.yar"
include "webhook_exfiltration.yar"
include "network_exfiltration.yar"
include "process_manipulation.yar"
include "obfuscation.yar"
include "samp_specific.yar"
