/*
    Discord webhook detection. A bare webhook URL is NOT malware - many legitimate
    SA-MP/GTA tools use webhooks for logging, admin alerts, etc. (spec section 13).
    It only becomes a high-severity finding when combined with input-capture or
    credential-related indicators, which is what the second rule below checks for.
*/

rule Discord_Webhook_URL_Present
{
    meta:
        category = "webhook"
        severity = "low"
        description = "Discord webhook URL pattern found - not inherently malicious on its own"
    strings:
        $wh1 = "discord.com/api/webhooks/" ascii wide nocase
        $wh2 = "discordapp.com/api/webhooks/" ascii wide nocase
    condition:
        any of them
}

rule Webhook_Combined_With_Input_Capture
{
    meta:
        category = "exfiltration"
        severity = "high"
        description = "Discord webhook indicator combined with keyboard/input capture APIs - possible credential/keylog exfiltration channel"
    strings:
        $wh1 = "discord.com/api/webhooks/" ascii wide nocase
        $wh2 = "discordapp.com/api/webhooks/" ascii wide nocase
        $api1 = "GetAsyncKeyState" ascii wide
        $api2 = "SetWindowsHookExA" ascii wide
        $api3 = "SetWindowsHookExW" ascii wide
        $api4 = "GetKeyboardState" ascii wide
    condition:
        any of ($wh*) and any of ($api*)
}
