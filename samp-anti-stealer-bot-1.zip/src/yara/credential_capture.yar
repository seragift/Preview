/*
    Credential capture indicators: references to where account credentials/session data
    are commonly stored (browser credential stores, Steam session files) and Discord-token-
    shaped strings. These are context/indicator rules only - always combined with other
    signals by riskEngine.js before affecting the verdict.
*/

rule Discord_Token_Pattern
{
    meta:
        category = "credential_capture"
        severity = "medium"
        description = "String pattern resembling a Discord authentication token"
    strings:
        $tok1 = /[MN][A-Za-z\d]{23}\.[\w-]{6}\.[\w-]{27}/
        $tok2 = /mfa\.[\w-]{84}/
    condition:
        any of them
}

rule Browser_Credential_Store_Reference
{
    meta:
        category = "credential_capture"
        severity = "medium"
        description = "Multiple references to browser credential storage locations (Chrome/Edge Login Data, Local State, leveldb)"
    strings:
        $c1 = "Login Data" ascii wide
        $c2 = "Local State" ascii wide
        $c3 = "\\Google\\Chrome\\User Data" ascii wide nocase
        $c4 = "\\Microsoft\\Edge\\User Data" ascii wide nocase
        $c5 = "leveldb" ascii wide nocase
    condition:
        2 of them
}

rule Steam_Credential_Reference
{
    meta:
        category = "credential_capture"
        severity = "medium"
        description = "Multiple references to Steam session/config files sometimes targeted for account theft"
    strings:
        $s1 = "ssfn" ascii wide
        $s2 = "loginusers.vdf" ascii wide nocase
        $s3 = "\\Steam\\config" ascii wide nocase
    condition:
        2 of them
}
