/*
    Networking API indicators. Requires 2+ distinct HTTP/Internet APIs before firing at
    all - a single WinHTTP/WinINet reference is common in legitimate update-checkers,
    launchers, etc. Severity rises sharply when combined with input-capture APIs.
*/

rule Suspicious_Network_APIs
{
    meta:
        category = "network"
        severity = "low"
        description = "Presence of multiple Windows networking APIs commonly used to send HTTP requests"
    strings:
        $n1 = "WinHttpOpen" ascii wide
        $n2 = "WinHttpConnect" ascii wide
        $n3 = "HttpSendRequestA" ascii wide
        $n4 = "HttpSendRequestW" ascii wide
        $n5 = "InternetOpenA" ascii wide
        $n6 = "InternetOpenW" ascii wide
        $n7 = "InternetConnectA" ascii wide
        $n8 = "InternetConnectW" ascii wide
        $n9 = "URLDownloadToFileA" ascii wide
        $n10 = "URLDownloadToFileW" ascii wide
    condition:
        2 of them
}

rule Network_Combined_With_Input_Capture
{
    meta:
        category = "exfiltration"
        severity = "high"
        description = "Network communication APIs combined with keyboard/input capture APIs - possible data exfiltration"
    strings:
        $net1 = "HttpSendRequestA" ascii wide
        $net2 = "HttpSendRequestW" ascii wide
        $net3 = "InternetConnectA" ascii wide
        $net4 = "InternetConnectW" ascii wide
        $net5 = "WinHttpConnect" ascii wide
        $api1 = "GetAsyncKeyState" ascii wide
        $api2 = "SetWindowsHookExA" ascii wide
        $api3 = "SetWindowsHookExW" ascii wide
        $api4 = "GetKeyboardState" ascii wide
    condition:
        any of ($net*) and any of ($api*)
}
