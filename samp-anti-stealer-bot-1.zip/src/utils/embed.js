import { EmbedBuilder } from 'discord.js';

const VERDICT_COLOR = {
  SAFE: 0x2ecc71,
  SUSPICIOUS: 0xf1c40f,
  'HIGH RISK': 0xe67e22,
  MALICIOUS: 0xe74c3c,
};

const VERDICT_EMOJI = {
  SAFE: '🟢',
  SUSPICIOUS: '🟡',
  'HIGH RISK': '🟠',
  MALICIOUS: '🔴',
};

const SEVERITY_EMOJI = {
  critical: '🔴',
  high: '🔴',
  medium: '🟡',
  low: '🟢',
  info: '🟢',
};

const REJECTION_MESSAGES = {
  FILE_TOO_LARGE: 'File exceeds the maximum allowed size.',
  ARCHIVE_TOO_LARGE: 'Archive file exceeds the maximum allowed compressed size.',
  EMPTY_FILE: 'File is empty.',
  INVALID_FILENAME: 'Filename contains invalid or unsafe characters.',
  TOO_MANY_FILES: 'Archive contains too many files.',
  ARCHIVE_TOO_LARGE_UNCOMPRESSED: 'Archive would decompress to an excessive size (possible archive bomb).',
  ARCHIVE_CORRUPT: 'Archive appears to be corrupt or unreadable.',
  ARCHIVE_LISTING_FAILED: 'Could not safely inspect archive contents before extraction.',
  ARCHIVE_EXTRACTION_FAILED: 'Archive extraction failed.',
  UNSUPPORTED_ARCHIVE_TYPE: 'Unsupported archive type.',
  SCAN_TIMEOUT: 'Scan exceeded the maximum allowed time and was aborted.',
  INTERNAL_ERROR: 'An internal error occurred while scanning this file.',
};

function formatSize(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

export function buildScanResultEmbed(result) {
  const verdictLabel = result.trusted ? 'TRUSTED (Whitelisted)' : result.verdict;
  const color = result.trusted ? VERDICT_COLOR.SAFE : (VERDICT_COLOR[result.verdict] || 0x95a5a6);
  const emoji = result.trusted ? '🟢' : (VERDICT_EMOJI[result.verdict] || '⚪');

  const embed = new EmbedBuilder()
    .setTitle('🛡️ SA-MP SECURITY SCANNER')
    .setColor(color)
    .addFields(
      { name: 'File', value: `\`${result.filename}\``, inline: true },
      { name: 'Size', value: formatSize(result.fileSize), inline: true },
      { name: 'SHA-256', value: `\`${result.sha256}\`` },
      { name: 'Verdict', value: `${emoji} ${verdictLabel}`, inline: true },
      { name: 'Risk Score', value: `${result.score}`, inline: true }
    );

  const detections = result.detections || [];
  const detectionLines = detections.slice(0, 15).map((d) => {
    const e = SEVERITY_EMOJI[d.severity] || '⚪';
    return `${e} **${d.rule}**\n${d.description || d.category || ''}`;
  });

  embed.addFields({
    name: `Detections${detections.length > 15 ? ` (showing 15 of ${detections.length})` : ''}`,
    value: detectionLines.length > 0 ? detectionLines.join('\n\n').slice(0, 1024) : 'No significant indicators found.',
  });

  embed.addFields(
    { name: 'Files scanned', value: `${result.filesScanned}`, inline: true },
    { name: 'Scan duration', value: `${result.durationSeconds} seconds`, inline: true }
  );

  if (!result.clamavAvailable) {
    embed.addFields({ name: 'ClamAV', value: '🟡 Unavailable' });
  }

  embed.setFooter({ text: '⚠️ Static analysis cannot guarantee that a file is completely safe.' });
  embed.setTimestamp();

  return embed;
}

export function buildArchiveResultEmbed(result) {
  const embed = buildScanResultEmbed(result);
  embed.setTitle('🛡️ SA-MP SECURITY SCANNER — Archive Report');

  const files = result.perFileResults || [];
  if (files.length > 0) {
    const lines = files.slice(0, 25).map((f) => {
      const flagged = f.pe?.writeExecuteSections?.length > 0 || f.flags?.includes('UNKNOWN_FILE_TYPE');
      const marker = flagged ? '🟡' : '🟢';
      return `${marker} \`${f.relativePath}\``;
    });
    const suffix = files.length > 25 ? `\n...and ${files.length - 25} more file(s)` : '';
    embed.addFields({
      name: `Files in archive (${files.length})`,
      value: (lines.join('\n') + suffix).slice(0, 1024) || 'None',
    });
  }

  return embed;
}

export function buildRejectionEmbed(reason, filename) {
  return new EmbedBuilder()
    .setTitle('⚠️ Scan Rejected')
    .setColor(0x95a5a6)
    .addFields(
      { name: 'File', value: `\`${filename}\`` },
      { name: 'Reason', value: REJECTION_MESSAGES[reason] || reason || 'Unknown error.' }
    )
    .setTimestamp();
}
