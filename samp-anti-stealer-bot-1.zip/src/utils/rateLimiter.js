const WINDOW_MS = 60 * 1000;

/** userId -> array of request timestamps (ms) within the current window */
const buckets = new Map();

/**
 * Sliding-window rate limiter. Returns { allowed: true } or
 * { allowed: false, retryAfterSeconds } without mutating state on rejection beyond
 * pruning expired timestamps.
 */
export function checkRateLimit(userId, maxPerMinute = 3) {
  const now = Date.now();
  const timestamps = (buckets.get(userId) || []).filter((t) => now - t < WINDOW_MS);

  if (timestamps.length >= maxPerMinute) {
    buckets.set(userId, timestamps);
    const oldest = timestamps[0];
    const retryAfterSeconds = Math.max(1, Math.ceil((WINDOW_MS - (now - oldest)) / 1000));
    return { allowed: false, retryAfterSeconds };
  }

  timestamps.push(now);
  buckets.set(userId, timestamps);
  return { allowed: true };
}
