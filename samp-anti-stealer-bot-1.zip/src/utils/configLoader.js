import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// src/utils -> src -> project root, where config.json lives (per the requested structure).
const CONFIG_PATH = path.join(__dirname, '..', '..', 'config.json');

const DEFAULTS = {
  maxFileSizeMB: 50,
  maxArchiveSizeMB: 100,
  maxExtractedSizeMB: 500,
  maxFilesInArchive: 1000,
  scanTimeoutSeconds: 60,
  maxTotalScanTimeSeconds: 300,
  maxConcurrentScans: 2,
  maxScansPerUserPerMinute: 3,
  clamavEnabled: true,
  yaraEnabled: true,
  peAnalysisEnabled: true,
  entropyThreshold: 7.2,
  stringExtraction: { minLength: 5, maxStringsPerFile: 5000 },
  supportedExtensions: {
    executables: ['.exe', '.dll', '.asi', '.scr', '.sys'],
    sampGta: ['.cs', '.lua', '.amx', '.pwn', '.inc'],
    archives: ['.zip', '.rar', '.7z'],
  },
};

let cached = null;

/**
 * Loads config.json once and caches it. This file holds only global, non-secret,
 * non-guild-specific operational settings (limits, feature toggles). Per-guild settings
 * (scanner channel, log channel) live in each guild's own SQLite database instead -
 * see src/database/databaseManager.js.
 */
export function loadConfig() {
  if (cached) return cached;

  try {
    const raw = fs.readFileSync(CONFIG_PATH, 'utf-8');
    const parsed = JSON.parse(raw);
    cached = {
      ...DEFAULTS,
      ...parsed,
      stringExtraction: { ...DEFAULTS.stringExtraction, ...(parsed.stringExtraction || {}) },
      supportedExtensions: { ...DEFAULTS.supportedExtensions, ...(parsed.supportedExtensions || {}) },
    };
  } catch (err) {
    console.warn(`[config] Could not read config.json (${err.message}), using built-in defaults.`);
    cached = { ...DEFAULTS };
  }

  return cached;
}

/** Forces the next loadConfig() call to re-read the file from disk. Mainly useful for tests. */
export function reloadConfig() {
  cached = null;
  return loadConfig();
}
