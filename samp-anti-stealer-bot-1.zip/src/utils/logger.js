import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const LOG_DIR = path.join(__dirname, '..', 'logs');

try {
  fs.mkdirSync(LOG_DIR, { recursive: true });
} catch {
  // If this fails we still want the bot to run - it just falls back to console-only logging.
}

// Never log Discord tokens, full webhook URLs, or other secrets (spec section 27).
// This redacts common shapes wherever a log line happens to contain them.
function redact(text) {
  if (typeof text !== 'string') return text;
  return text
    .replace(/(discord(?:app)?\.com\/api\/webhooks\/\d+\/)[\w-]+/gi, '$1REDACTED')
    .replace(/[MN][A-Za-z\d]{23}\.[\w-]{6}\.[\w-]{27}/g, 'REDACTED_DISCORD_TOKEN')
    .replace(/mfa\.[\w-]{84}/g, 'REDACTED_DISCORD_TOKEN');
}

function serializeMeta(meta) {
  if (meta === undefined) return '';
  if (meta instanceof Error) {
    return ` ${redact(meta.message)}\n${redact(meta.stack || '')}`;
  }
  try {
    return ` ${redact(JSON.stringify(meta))}`;
  } catch {
    return ` ${redact(String(meta))}`;
  }
}

function writeLine(level, message, meta) {
  const timestamp = new Date().toISOString();
  const line = `[${timestamp}] [${level.toUpperCase()}] ${redact(String(message))}${serializeMeta(meta)}`;

  const fileName = `${timestamp.slice(0, 10)}.log`;
  fs.appendFile(path.join(LOG_DIR, fileName), line + '\n', () => {
    // Intentionally ignore write errors here - logging must never crash the bot.
  });

  if (level === 'error') console.error(line);
  else if (level === 'warn') console.warn(line);
  else console.log(line);
}

export const logger = {
  info: (message, meta) => writeLine('info', message, meta),
  warn: (message, meta) => writeLine('warn', message, meta),
  error: (message, meta) => writeLine('error', message, meta),
};
