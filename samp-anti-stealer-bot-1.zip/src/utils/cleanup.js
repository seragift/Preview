import fs from 'fs';
import path from 'path';

/** Recursively deletes a directory. Safe to call even if it does not exist. */
export async function removeDir(dirPath) {
  await fs.promises.rm(dirPath, { recursive: true, force: true });
}

/**
 * Removes leftover per-scan temp directories older than maxAgeMs, e.g. from a previous
 * crashed run. Scan directories are always supposed to be cleaned up in a `finally` block
 * (see scanner/scanner.js), but this is a defensive second layer so temp/ never accumulates
 * user-uploaded file remnants indefinitely.
 */
export async function cleanupOrphanedTempDirs(tempRoot, maxAgeMs = 60 * 60 * 1000) {
  let entries;
  try {
    entries = await fs.promises.readdir(tempRoot, { withFileTypes: true });
  } catch {
    return; // temp root doesn't exist yet - nothing to clean up
  }

  const now = Date.now();
  for (const entry of entries) {
    if (entry.name === '.gitkeep') continue;
    const fullPath = path.join(tempRoot, entry.name);
    try {
      const stat = await fs.promises.stat(fullPath);
      if (now - stat.mtimeMs > maxAgeMs) {
        await removeDir(fullPath);
      }
    } catch {
      // Entry may have been removed concurrently - ignore.
    }
  }
}
