import Database from 'better-sqlite3';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { SCHEMA_SQL } from './schema.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// Multi-server design: every guild gets its own SQLite file, created lazily on first use.
// This is a deliberate choice for the "no GUILD_ID in .env" requirement - it keeps each
// server's channel settings, scan history, whitelist, and blocklist fully isolated from
// every other server, with no shared table or shared guild_id column to reason about.
// (Trade-off: there is no built-in cross-server hash reputation. See README "Security
// Limitations" if you want to add a shared global list on top of this later.)
const DB_DIR = path.join(__dirname, '..', 'data', 'guilds');

/** guildId -> open better-sqlite3 Database instance */
const connections = new Map();

function getDb(guildId) {
  if (connections.has(guildId)) return connections.get(guildId);

  fs.mkdirSync(DB_DIR, { recursive: true });
  const dbPath = path.join(DB_DIR, `${guildId}.db`);
  const db = new Database(dbPath);
  db.pragma('journal_mode = WAL');
  db.exec(SCHEMA_SQL);

  connections.set(guildId, db);
  return db;
}

export function getSettings(guildId) {
  const db = getDb(guildId);
  const rows = db.prepare('SELECT key, value FROM settings').all();
  const map = Object.fromEntries(rows.map((r) => [r.key, r.value]));
  return {
    scannerChannelId: map.scannerChannelId || null,
    logChannelId: map.logChannelId || null,
  };
}

export function setSetting(guildId, key, value) {
  const db = getDb(guildId);
  db.prepare(
    `INSERT INTO settings (key, value) VALUES (?, ?)
     ON CONFLICT(key) DO UPDATE SET value = excluded.value`
  ).run(key, value);
}

export function insertScanHistory(guildId, { userId, filename, sha256, fileSize, verdict, riskScore }) {
  const db = getDb(guildId);
  const info = db
    .prepare(
      `INSERT INTO scan_history (user_id, filename, sha256, file_size, verdict, risk_score)
       VALUES (?, ?, ?, ?, ?, ?)`
    )
    .run(userId, filename, sha256, fileSize, verdict, riskScore);
  return info.lastInsertRowid;
}

export function insertDetections(guildId, scanId, detections) {
  if (!detections || detections.length === 0) return;
  const db = getDb(guildId);
  const stmt = db.prepare(
    `INSERT INTO detections (scan_id, file_path, rule_name, category, severity, description)
     VALUES (?, ?, ?, ?, ?, ?)`
  );
  const insertMany = db.transaction((rows) => {
    for (const d of rows) {
      stmt.run(scanId, d.file || '', d.rule || '', d.category || null, d.severity || null, d.description || null);
    }
  });
  insertMany(detections);
}

export function getScanByHash(guildId, sha256) {
  const db = getDb(guildId);
  return db.prepare('SELECT * FROM scan_history WHERE sha256 = ? ORDER BY created_at DESC LIMIT 1').get(sha256);
}

export function getWhitelistEntry(guildId, sha256) {
  const db = getDb(guildId);
  return db.prepare('SELECT * FROM whitelist WHERE sha256 = ?').get(sha256);
}

export function addWhitelist(guildId, sha256, reason, adminId) {
  const db = getDb(guildId);
  db.prepare('INSERT OR REPLACE INTO whitelist (sha256, reason, admin_id) VALUES (?, ?, ?)').run(
    sha256,
    reason,
    adminId
  );
}

export function removeWhitelist(guildId, sha256) {
  const db = getDb(guildId);
  return db.prepare('DELETE FROM whitelist WHERE sha256 = ?').run(sha256).changes > 0;
}

export function getBlocklistEntry(guildId, sha256) {
  const db = getDb(guildId);
  return db.prepare('SELECT * FROM blocklist WHERE sha256 = ?').get(sha256);
}

export function addBlocklist(guildId, sha256, reason, adminId) {
  const db = getDb(guildId);
  db.prepare('INSERT OR REPLACE INTO blocklist (sha256, reason, admin_id) VALUES (?, ?, ?)').run(
    sha256,
    reason,
    adminId
  );
}

export function removeBlocklist(guildId, sha256) {
  const db = getDb(guildId);
  return db.prepare('DELETE FROM blocklist WHERE sha256 = ?').run(sha256).changes > 0;
}

export function getStats(guildId) {
  const db = getDb(guildId);
  const total = db.prepare('SELECT COUNT(*) AS c FROM scan_history').get().c;
  const byVerdict = db.prepare('SELECT verdict, COUNT(*) AS c FROM scan_history GROUP BY verdict').all();
  return { total, byVerdict };
}

/** Closes every open per-guild database connection. Call on process shutdown. */
export function closeAll() {
  for (const db of connections.values()) {
    try {
      db.close();
    } catch {
      // ignore - process is exiting anyway
    }
  }
  connections.clear();
}
