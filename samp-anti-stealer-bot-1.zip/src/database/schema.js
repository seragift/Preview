// Schema applied to EVERY per-guild SQLite database (src/data/guilds/<guildId>.db).
// Because each guild already gets its own database file, tables do not need a guild_id
// column - file-level separation is the isolation boundary. `settings` is a generic
// key-value table so new per-guild settings can be added later without a migration.

export const SCHEMA_SQL = `
CREATE TABLE IF NOT EXISTS settings (
  key   TEXT PRIMARY KEY,
  value TEXT
);

CREATE TABLE IF NOT EXISTS scan_history (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id    TEXT NOT NULL,
  filename   TEXT NOT NULL,
  sha256     TEXT NOT NULL,
  file_size  INTEGER NOT NULL,
  verdict    TEXT NOT NULL,
  risk_score INTEGER NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_scan_history_sha256 ON scan_history(sha256);
CREATE INDEX IF NOT EXISTS idx_scan_history_user ON scan_history(user_id);

CREATE TABLE IF NOT EXISTS detections (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  scan_id     INTEGER NOT NULL REFERENCES scan_history(id) ON DELETE CASCADE,
  file_path   TEXT NOT NULL,
  rule_name   TEXT NOT NULL,
  category    TEXT,
  severity    TEXT,
  description TEXT
);

CREATE INDEX IF NOT EXISTS idx_detections_scan_id ON detections(scan_id);

CREATE TABLE IF NOT EXISTS whitelist (
  sha256     TEXT PRIMARY KEY,
  reason     TEXT,
  admin_id   TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS blocklist (
  sha256     TEXT PRIMARY KEY,
  reason     TEXT,
  admin_id   TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
`;
