import fs from 'fs';
import crypto from 'crypto';

/** Computes the SHA-256 hash of a file by streaming it - never loads the whole file into RAM. */
export function computeSha256(filePath) {
  return new Promise((resolve, reject) => {
    const hash = crypto.createHash('sha256');
    const stream = fs.createReadStream(filePath);
    stream.on('data', (chunk) => hash.update(chunk));
    stream.on('end', () => resolve(hash.digest('hex')));
    stream.on('error', reject);
  });
}
