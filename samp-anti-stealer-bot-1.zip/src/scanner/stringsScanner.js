const MIN_STRING_LENGTH_DEFAULT = 5;

// Keyword scanner (spec section 14). Deliberately treated as a WEAK signal - a single
// keyword hit like "key" or "login" is common in totally legitimate code and must never
// be treated as evidence of malware on its own. See riskEngine.js for how this is capped.
const CREDENTIAL_KEYWORDS = [
  'username', 'password', 'passwd', 'login', 'account', 'credential',
  'token', 'session', 'cookie', 'key', 'auth', 'serial',
];

const NETWORK_APIS = [
  'WinHttpOpen', 'WinHttpConnect', 'HttpSendRequestA', 'HttpSendRequestW',
  'InternetOpenA', 'InternetOpenW', 'InternetConnectA', 'InternetConnectW',
  'URLDownloadToFileA', 'URLDownloadToFileW',
];

const INPUT_CAPTURE_APIS = [
  'GetAsyncKeyState', 'GetKeyState', 'GetKeyboardState',
  'SetWindowsHookExA', 'SetWindowsHookExW',
];

const PROCESS_APIS = [
  'OpenProcess', 'VirtualAllocEx', 'WriteProcessMemory',
  'CreateRemoteThread', 'NtWriteVirtualMemory', 'NtCreateThreadEx',
];

const WEBHOOK_PATTERN = /(discord(?:app)?\.com\/api\/webhooks\/\d+\/[\w-]+)/gi;
const URL_PATTERN = /https?:\/\/[^\s"'<>]+/gi;
const IPV4_PATTERN = /\b(?:\d{1,3}\.){3}\d{1,3}\b/g;
const BASE64_LIKE_PATTERN = /[A-Za-z0-9+/]{200,}={0,2}/g;
const HEX_BLOB_PATTERN = /(?:[0-9a-fA-F]{2}){100,}/g;

/**
 * Extracts printable-ASCII "strings" from a raw byte buffer, similar in spirit to the
 * Unix `strings` utility. Implemented in pure JS so we don't need another system
 * dependency alongside YARA/ClamAV/unrar/7z.
 */
export function extractPrintableStrings(buffer, minLength = MIN_STRING_LENGTH_DEFAULT, maxStrings = 5000) {
  const strings = [];
  let current = '';

  for (let i = 0; i < buffer.length; i++) {
    if (strings.length >= maxStrings) break;
    const byte = buffer[i];
    const isPrintable = byte >= 0x20 && byte <= 0x7e;
    if (isPrintable) {
      current += String.fromCharCode(byte);
    } else {
      if (current.length >= minLength) strings.push(current);
      current = '';
    }
  }
  if (current.length >= minLength && strings.length < maxStrings) strings.push(current);

  return strings;
}

function redactWebhook(url) {
  const match = url.match(/^(discord(?:app)?\.com\/api\/webhooks\/)(\d+)\/(.+)$/i);
  if (!match) return 'discord.com/api/webhooks/REDACTED';
  return `${match[1]}${match[2]}/REDACTED`;
}

/**
 * Runs all string-based detectors over a file's raw bytes. This never touches the network -
 * URLs/webhooks/IPs found here are only ever reported, never fetched (spec section 15).
 */
export function scanStrings(buffer, config) {
  const minLength = config?.stringExtraction?.minLength ?? MIN_STRING_LENGTH_DEFAULT;
  const maxStrings = config?.stringExtraction?.maxStringsPerFile ?? 5000;
  const strings = extractPrintableStrings(buffer, minLength, maxStrings);
  const joined = strings.join('\n');
  const lowerJoined = joined.toLowerCase();

  const keywordHits = [];
  for (const kw of CREDENTIAL_KEYWORDS) {
    if (lowerJoined.includes(kw)) keywordHits.push(kw);
  }

  const apiHits = {
    inputCapture: INPUT_CAPTURE_APIS.filter((api) => joined.includes(api)),
    network: NETWORK_APIS.filter((api) => joined.includes(api)),
    processInjection: PROCESS_APIS.filter((api) => joined.includes(api)),
  };

  const webhooksFound = [...new Set([...joined.matchAll(WEBHOOK_PATTERN)].map((m) => redactWebhook(m[1])))];
  const urlsFound = [...new Set([...joined.matchAll(URL_PATTERN)].map((m) => m[0]))].slice(0, 50);
  const ipsFound = [...new Set([...joined.matchAll(IPV4_PATTERN)].map((m) => m[0]))].slice(0, 50);

  const base64BlobCount = [...joined.matchAll(BASE64_LIKE_PATTERN)].length;
  const hexBlobCount = [...joined.matchAll(HEX_BLOB_PATTERN)].length;
  const printableRatio = buffer.length > 0 ? joined.length / buffer.length : 1;

  return {
    keywordHits,
    apiHits,
    webhooksFound,
    urlsFound,
    ipsFound,
    obfuscationIndicators: {
      base64BlobCount,
      hexBlobCount,
      printableRatio: Number(printableRatio.toFixed(3)),
      lowPrintableRatio: printableRatio < 0.15 && buffer.length > 1024,
    },
  };
}
