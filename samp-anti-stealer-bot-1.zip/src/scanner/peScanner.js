// Minimal static PE (Portable Executable) parser for .exe/.dll/.asi/.scr/.sys files.
// Reads raw bytes with Buffer only - never loads, maps, or executes the target file.
//
// Covers: DOS/NT headers, section table + per-section entropy, and the import/export
// tables (named imports/exports; ordinal-only imports are counted but not resolved).
//
// Deliberately NOT covered (see README "Security Limitations"): resource directory,
// TLS callbacks, rich header, delay-load imports, Authenticode signature verification.
// This is intentionally a bounded, dependency-free implementation rather than a
// best-effort wrapper around a third-party parser.

import { calculateEntropy } from './entropyScanner.js';

const IMAGE_FILE_MACHINE = {
  0x014c: 'x86',
  0x8664: 'x64',
  0x01c0: 'ARM',
  0xaa64: 'ARM64',
};

const KNOWN_GOOD_SECTIONS = new Set([
  '.text', '.data', '.rdata', '.rsrc', '.reloc', '.pdata', '.idata', '.edata',
  '.bss', '.tls', '.debug', '.didat',
]);

const PACKER_SECTION_HINTS = ['upx', 'themida', 'vmp', 'aspack', 'petite', 'mpress', 'nsp', 'enigma'];

const MAX_SECTIONS = 96; // sanity bound - legitimate PE files rarely exceed a few dozen
const MAX_IMPORT_DESCRIPTORS = 200;
const MAX_IMPORTS_PER_DLL = 500;
const MAX_EXPORT_NAMES = 500;

export function analyzePe(buffer) {
  try {
    if (buffer.length < 0x40 || buffer.readUInt16LE(0) !== 0x5a4d) {
      return { isPe: false, error: 'NOT_A_PE_FILE' };
    }

    const e_lfanew = buffer.readUInt32LE(0x3c);
    if (e_lfanew <= 0 || e_lfanew + 24 > buffer.length) {
      return { isPe: false, error: 'INVALID_PE_OFFSET' };
    }
    if (buffer.readUInt32LE(e_lfanew) !== 0x00004550) {
      return { isPe: false, error: 'INVALID_PE_SIGNATURE' };
    }

    const coffOffset = e_lfanew + 4;
    const machine = buffer.readUInt16LE(coffOffset);
    const numberOfSections = buffer.readUInt16LE(coffOffset + 2);
    const timeDateStamp = buffer.readUInt32LE(coffOffset + 4);
    const sizeOfOptionalHeader = buffer.readUInt16LE(coffOffset + 16);
    const characteristics = buffer.readUInt16LE(coffOffset + 18);

    if (numberOfSections === 0 || numberOfSections > MAX_SECTIONS) {
      return { isPe: false, error: 'SUSPICIOUS_SECTION_COUNT' };
    }

    const optHeaderOffset = coffOffset + 20;
    if (optHeaderOffset + 2 > buffer.length) return { isPe: false, error: 'TRUNCATED_HEADER' };

    const magic = buffer.readUInt16LE(optHeaderOffset);
    const isPe32Plus = magic === 0x20b;
    const isPe32 = magic === 0x10b;
    if (!isPe32 && !isPe32Plus) return { isPe: false, error: 'UNKNOWN_OPTIONAL_HEADER_MAGIC' };
    if (optHeaderOffset + sizeOfOptionalHeader > buffer.length) return { isPe: false, error: 'TRUNCATED_HEADER' };

    const addressOfEntryPoint = buffer.readUInt32LE(optHeaderOffset + 16);

    const imageBaseOffset = isPe32Plus ? optHeaderOffset + 24 : optHeaderOffset + 28;
    const imageBase = isPe32Plus ? buffer.readBigUInt64LE(imageBaseOffset) : BigInt(buffer.readUInt32LE(imageBaseOffset));

    // Subsystem/DllCharacteristics sit at the SAME offsets in both PE32 and PE32+
    // (removing the 4-byte BaseOfData field in PE32+ is exactly offset by ImageBase
    // growing from 4 to 8 bytes), so no branching is needed here.
    const subsystem = buffer.readUInt16LE(optHeaderOffset + 68);
    const dllCharacteristics = buffer.readUInt16LE(optHeaderOffset + 70);

    const numberOfRvaAndSizesOffset = isPe32Plus ? optHeaderOffset + 108 : optHeaderOffset + 92;
    const numberOfRvaAndSizes = buffer.readUInt32LE(numberOfRvaAndSizesOffset);
    const dataDirOffset = numberOfRvaAndSizesOffset + 4;

    const dataDirectories = [];
    for (let i = 0; i < Math.min(numberOfRvaAndSizes, 16); i++) {
      const off = dataDirOffset + i * 8;
      if (off + 8 > buffer.length) break;
      dataDirectories.push({
        virtualAddress: buffer.readUInt32LE(off),
        size: buffer.readUInt32LE(off + 4),
      });
    }

    const sectionTableOffset = optHeaderOffset + sizeOfOptionalHeader;
    const sections = [];
    for (let i = 0; i < numberOfSections; i++) {
      const off = sectionTableOffset + i * 40;
      if (off + 40 > buffer.length) break;

      const name = buffer.subarray(off, off + 8).toString('ascii').replace(/\0+$/, '');
      const virtualSize = buffer.readUInt32LE(off + 8);
      const virtualAddress = buffer.readUInt32LE(off + 12);
      const sizeOfRawData = buffer.readUInt32LE(off + 16);
      const pointerToRawData = buffer.readUInt32LE(off + 20);
      const sectionCharacteristics = buffer.readUInt32LE(off + 36);

      const isExecutable = !!(sectionCharacteristics & 0x20000000);
      const isWritable = !!(sectionCharacteristics & 0x80000000);
      const isReadable = !!(sectionCharacteristics & 0x40000000);

      let entropy = null;
      if (pointerToRawData > 0 && sizeOfRawData > 0 && pointerToRawData + sizeOfRawData <= buffer.length) {
        entropy = Number(calculateEntropy(buffer.subarray(pointerToRawData, pointerToRawData + sizeOfRawData)).toFixed(3));
      }

      const lowerName = name.toLowerCase();
      const looksLikePacker = PACKER_SECTION_HINTS.some((hint) => lowerName.includes(hint));
      const isKnownName = KNOWN_GOOD_SECTIONS.has(lowerName) || name === '';

      sections.push({
        name, virtualSize, virtualAddress, sizeOfRawData, pointerToRawData,
        isExecutable, isWritable, isReadable, entropy, looksLikePacker,
        suspicious: (isExecutable && isWritable) || (!isKnownName && !looksLikePacker && name.length > 0),
      });
    }

    const imports = parseImports(buffer, dataDirectories[1], sections, isPe32Plus);
    const exportNames = parseExports(buffer, dataDirectories[0], sections);

    return {
      isPe: true,
      machine: IMAGE_FILE_MACHINE[machine] || `0x${machine.toString(16)}`,
      timeDateStamp,
      imageBase: imageBase.toString(),
      isDll: !!(characteristics & 0x2000),
      addressOfEntryPoint,
      subsystem,
      hasNoAslr: !(dllCharacteristics & 0x0040),
      hasNoDep: !(dllCharacteristics & 0x0100),
      sections,
      imports,
      exportNames,
      writeExecuteSections: sections.filter((s) => s.isExecutable && s.isWritable).map((s) => s.name),
      suspiciousSectionNames: sections.filter((s) => s.suspicious).map((s) => s.name),
      packedSectionHints: sections.filter((s) => s.looksLikePacker).map((s) => s.name),
    };
  } catch {
    return { isPe: false, error: 'PE_PARSE_EXCEPTION' };
  }
}

function rvaToOffset(rva, sections) {
  for (const s of sections) {
    const span = Math.max(s.virtualSize, s.sizeOfRawData);
    if (rva >= s.virtualAddress && rva < s.virtualAddress + span) {
      return s.pointerToRawData + (rva - s.virtualAddress);
    }
  }
  return -1;
}

function readCString(buffer, offset, maxLen = 256) {
  if (offset < 0 || offset >= buffer.length) return '';
  let end = offset;
  while (end < buffer.length && end < offset + maxLen && buffer[end] !== 0) end++;
  return buffer.toString('latin1', offset, end);
}

function parseImports(buffer, importDir, sections, isPe32Plus) {
  const results = [];
  if (!importDir || importDir.virtualAddress === 0) return results;

  const baseOffset = rvaToOffset(importDir.virtualAddress, sections);
  if (baseOffset < 0) return results;

  const thunkSize = isPe32Plus ? 8 : 4;
  const ordinalFlag = isPe32Plus ? 1n << 63n : 1n << 31n;
  const ordinalMask = 0xffffn;

  for (let i = 0; i < MAX_IMPORT_DESCRIPTORS; i++) {
    const descOffset = baseOffset + i * 20;
    if (descOffset + 20 > buffer.length) break;

    const originalFirstThunk = buffer.readUInt32LE(descOffset);
    const nameRva = buffer.readUInt32LE(descOffset + 12);
    const firstThunk = buffer.readUInt32LE(descOffset + 16);

    if (originalFirstThunk === 0 && nameRva === 0 && firstThunk === 0) break; // end marker

    const nameOffset = rvaToOffset(nameRva, sections);
    const dllName = nameOffset >= 0 ? readCString(buffer, nameOffset) : '(unknown)';

    const thunkRva = originalFirstThunk || firstThunk;
    const thunkOffset = rvaToOffset(thunkRva, sections);
    const functions = [];

    if (thunkOffset >= 0) {
      for (let j = 0; j < MAX_IMPORTS_PER_DLL; j++) {
        const entryOffset = thunkOffset + j * thunkSize;
        if (entryOffset + thunkSize > buffer.length) break;

        const thunkValue = isPe32Plus ? buffer.readBigUInt64LE(entryOffset) : BigInt(buffer.readUInt32LE(entryOffset));
        if (thunkValue === 0n) break;

        if (thunkValue & ordinalFlag) {
          functions.push(`Ordinal#${Number(thunkValue & ordinalMask)}`);
        } else {
          const nameOff = rvaToOffset(Number(thunkValue & 0x7fffffffn), sections);
          if (nameOff >= 0) functions.push(readCString(buffer, nameOff + 2)); // skip 2-byte Hint field
        }
      }
    }

    results.push({ dll: dllName, functions });
  }

  return results;
}

function parseExports(buffer, exportDir, sections) {
  if (!exportDir || exportDir.virtualAddress === 0) return [];
  try {
    const offset = rvaToOffset(exportDir.virtualAddress, sections);
    if (offset < 0 || offset + 40 > buffer.length) return [];

    const numberOfNames = buffer.readUInt32LE(offset + 24);
    const addressOfNamesRva = buffer.readUInt32LE(offset + 32);
    const namesOffset = rvaToOffset(addressOfNamesRva, sections);
    if (namesOffset < 0) return [];

    const names = [];
    for (let i = 0; i < Math.min(numberOfNames, MAX_EXPORT_NAMES); i++) {
      const entryOffset = namesOffset + i * 4;
      if (entryOffset + 4 > buffer.length) break;
      const nameRva = buffer.readUInt32LE(entryOffset);
      const nameOff = rvaToOffset(nameRva, sections);
      if (nameOff >= 0) names.push(readCString(buffer, nameOff));
    }
    return names;
  } catch {
    return [];
  }
}
