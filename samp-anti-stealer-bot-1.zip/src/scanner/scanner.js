import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { Readable } from 'stream';
import { pipeline } from 'stream/promises';
import { fileURLToPath } from 'url';

import { validateFile, isKnownExtension } from './fileValidator.js';
import { computeSha256 } from './hashScanner.js';
import { extractArchive } from './archiveScanner.js';
import { scanWithYara } from './yaraScanner.js';
import { scanWithClamAV } from './clamavScanner.js';
import { analyzePe } from './peScanner.js';
import { scanStrings } from './stringsScanner.js';
import { analyzeEntropy } from './entropyScanner.js';
import { calculateRisk } from './riskEngine.js';
import * as db from '../database/databaseManager.js';
import { loadConfig } from '../utils/configLoader.js';
import { removeDir } from '../utils/cleanup.js';
import { logger } from '../utils/logger.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const TEMP_ROOT = path.join(__dirname, '..', 'temp', 'scans');
const ARCHIVE_EXTS = new Set(['.zip', '.rar', '.7z']);
const PE_EXTS = new Set(['.exe', '.dll', '.asi', '.scr', '.sys']);

/**
 * Runs a full scan on a Discord attachment. Never throws - always resolves to either
 * a rejection object ({ rejected: true, reason, filename }) or a full result object.
 * The per-scan temp directory is ALWAYS removed in `finally`, no matter how the scan ends.
 */
export async function runScan({ guildId, userId, attachment }) {
  const config = loadConfig();
  const scanId = crypto.randomUUID();
  const scanDir = path.join(TEMP_ROOT, scanId);
  const startedAt = Date.now();

  await fs.promises.mkdir(scanDir, { recursive: true });

  try {
    return await withTimeout(
      performScan({ guildId, userId, attachment, scanDir, scanId, config, startedAt }),
      (config.maxTotalScanTimeSeconds || 300) * 1000
    );
  } catch (err) {
    if (err.message === 'SCAN_TIMEOUT') {
      return buildRejection('SCAN_TIMEOUT', attachment, scanId);
    }
    logger.error('Unexpected scan error', err);
    return buildRejection('INTERNAL_ERROR', attachment, scanId);
  } finally {
    await removeDir(scanDir).catch((e) => logger.error('Temp dir cleanup failed', e));
  }
}

function withTimeout(promise, ms) {
  let timer;
  const timeout = new Promise((_, reject) => {
    timer = setTimeout(() => reject(new Error('SCAN_TIMEOUT')), ms);
  });
  return Promise.race([promise, timeout]).finally(() => clearTimeout(timer));
}

function buildRejection(reason, attachment, scanId) {
  return { rejected: true, reason, filename: attachment.name, scanId };
}

function sanitizeFilename(name) {
  return name.replace(/[/\\:*?"<>|]/g, '_').slice(-150);
}

async function downloadFile(url, destPath) {
  const res = await fetch(url);
  if (!res.ok || !res.body) throw new Error(`Failed to download attachment: HTTP ${res.status}`);
  await pipeline(Readable.fromWeb(res.body), fs.createWriteStream(destPath));
}

async function performScan({ guildId, userId, attachment, scanDir, scanId, config, startedAt }) {
  const ext = path.extname(attachment.name).toLowerCase();
  const isArchiveExt = ARCHIVE_EXTS.has(ext);

  // Pre-download size check using Discord-reported size (avoids downloading huge files
  // we're going to reject anyway). The definitive check happens again after download.
  const maxBytes = (isArchiveExt ? (config.maxArchiveSizeMB || 100) : (config.maxFileSizeMB || 50)) * 1024 * 1024;
  if (attachment.size > maxBytes) {
    return buildRejection(isArchiveExt ? 'ARCHIVE_TOO_LARGE' : 'FILE_TOO_LARGE', attachment, scanId);
  }

  const originalPath = path.join(scanDir, 'original_' + sanitizeFilename(attachment.name));
  await downloadFile(attachment.url, originalPath);

  const validation = await validateFile(originalPath, attachment.name, config);
  if (!validation.ok) {
    return buildRejection(validation.reason, attachment, scanId);
  }

  const sha256 = await computeSha256(originalPath);
  const whitelistEntry = db.getWhitelistEntry(guildId, sha256);
  const blocklistEntry = db.getBlocklistEntry(guildId, sha256);

  let filesToScan;
  let isArchive = false;

  if (isArchiveExt) {
    isArchive = true;
    const extractDir = path.join(scanDir, 'extracted');
    const archiveResult = await extractArchive(originalPath, extractDir, config);
    if (archiveResult.error) {
      return buildRejection(archiveResult.error, attachment, scanId);
    }
    filesToScan = archiveResult.files;
  } else {
    filesToScan = [{ absolutePath: originalPath, relativePath: attachment.name }];
  }

  const perFileResults = [];
  for (const file of filesToScan) {
    perFileResults.push(await analyzeFile(file, config));
  }

  const yaraTarget = isArchive ? path.join(scanDir, 'extracted') : originalPath;
  const yaraResults = config.yaraEnabled
    ? await scanWithYara(yaraTarget, config)
    : { available: false, matches: [] };

  const clamavTarget = isArchive ? path.join(scanDir, 'extracted') : originalPath;
  const clamavResult = config.clamavEnabled
    ? await scanWithClamAV(clamavTarget, config)
    : { available: false, findings: [] };

  const risk = calculateRisk({
    perFileResults,
    yaraResults,
    clamavResult,
    isWhitelisted: !!whitelistEntry,
    knownMaliciousHash: !!blocklistEntry,
  });

  const historyId = db.insertScanHistory(guildId, {
    userId,
    filename: attachment.name,
    sha256,
    fileSize: attachment.size,
    verdict: risk.verdict,
    riskScore: risk.score,
  });
  db.insertDetections(guildId, historyId, risk.detections);

  const durationSeconds = ((Date.now() - startedAt) / 1000).toFixed(2);

  return {
    rejected: false,
    scanId,
    filename: attachment.name,
    sha256,
    fileSize: attachment.size,
    verdict: risk.verdict,
    score: risk.score,
    trusted: risk.trusted,
    detections: risk.detections,
    isArchive,
    perFileResults,
    filesScanned: filesToScan.length,
    durationSeconds,
    clamavAvailable: clamavResult.available,
  };
}

async function analyzeFile(file, config) {
  const ext = path.extname(file.relativePath).toLowerCase();
  const result = { relativePath: file.relativePath, ext, flags: [] };

  try {
    const buffer = await fs.promises.readFile(file.absolutePath);

    result.strings = scanStrings(buffer, config);
    result.entropy = analyzeEntropy(buffer, config);

    if (PE_EXTS.has(ext) && config.peAnalysisEnabled) {
      result.pe = analyzePe(buffer);
    }

    if (ARCHIVE_EXTS.has(ext)) {
      result.flags.push('NESTED_ARCHIVE_NOT_EXTRACTED');
    }

    if (!isKnownExtension(ext)) {
      result.flags.push('UNKNOWN_FILE_TYPE');
    }
  } catch (err) {
    result.error = 'FILE_ANALYSIS_ERROR';
    logger.error(`Failed to analyze ${file.relativePath}`, err);
  }

  return result;
}
