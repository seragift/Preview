import { execa } from 'execa';
import { logger } from '../utils/logger.js';

let clamavAvailableCache = null;

export async function isClamAvAvailable() {
  if (clamavAvailableCache !== null) return clamavAvailableCache;
  try {
    await execa('clamscan', ['--version'], { timeout: 5000 });
    clamavAvailableCache = true;
  } catch {
    clamavAvailableCache = false;
  }
  return clamavAvailableCache;
}

/**
 * Runs `clamscan` over targetPath. Returns { available, findings: [{file, signature}] }.
 * If ClamAV is not installed, the scanner keeps running on YARA/static analysis alone
 * (spec section 30) - this never throws or crashes the bot.
 */
export async function scanWithClamAV(targetPath, config) {
  const available = await isClamAvAvailable();
  if (!available) return { available: false, findings: [] };

  const timeoutSeconds = config.scanTimeoutSeconds || 60;

  const result = await execa(
    'clamscan',
    ['--no-summary', '--infected', '--recursive', targetPath],
    { timeout: timeoutSeconds * 1000, reject: false }
  ).catch((err) => ({ exitCode: -1, stdout: '', stderr: String(err) }));

  // clamscan exit codes: 0 = clean, 1 = infected file(s) found, 2 = a scan error occurred.
  if (result.exitCode === 2 || result.exitCode === -1) {
    logger.error('ClamAV scan error', result.stderr);
    return { available: true, findings: [], error: 'CLAMAV_EXECUTION_ERROR' };
  }

  return { available: true, findings: parseClamavOutput(result.stdout) };
}

function parseClamavOutput(stdout) {
  const findings = [];
  if (!stdout) return findings;
  for (const line of stdout.split('\n')) {
    const m = line.match(/^(.+):\s+(.+)\s+FOUND\s*$/);
    if (m) findings.push({ file: m[1].trim(), signature: m[2].trim() });
  }
  return findings;
}
