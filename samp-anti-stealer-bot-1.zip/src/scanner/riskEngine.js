// Central scoring engine (spec sections 22-24). Detection and verdict are kept separate:
// every individual indicator is still reported in `detections`, but the numeric score
// (and therefore the verdict) only rewards COMBINATIONS of weak signals, never a single
// API name or keyword in isolation. Signals from all files in a scan (e.g. every file
// inside an archive) are unioned into one set of booleans first, so the same combination
// found in three different files is scored once, not three times.

const SCORE = {
  YARA_CRITICAL: 100,
  YARA_HIGH: 25,
  YARA_MEDIUM: 10,
  YARA_LOW: 3,
  KNOWN_MALICIOUS_HASH: 100,
  CREDENTIAL_CAPTURE_COMBO: 25,
  WEBHOOK_AND_CAPTURE_COMBO: 30,
  SUSPICIOUS_NETWORK: 10,
  PROCESS_INJECTION_COMBO: 25,
  CREDENTIAL_KEYWORD_UNIT: 3,
  CREDENTIAL_KEYWORDS_MAX: 9,
  OBFUSCATION: 5,
  HIGH_ENTROPY: 3,
  PACKED_PE: 5,
};

const INPUT_CAPTURE_FUNCS = ['GetAsyncKeyState', 'GetKeyState', 'GetKeyboardState', 'SetWindowsHookExA', 'SetWindowsHookExW'];
const PROCESS_INJECTION_FUNCS = ['OpenProcess', 'VirtualAllocEx', 'WriteProcessMemory', 'CreateRemoteThread', 'NtWriteVirtualMemory', 'NtCreateThreadEx'];

function combo(rule, category, severity, description) {
  return { file: '(combined analysis)', rule, category, severity, description };
}

function severityToScore(severity) {
  switch (severity) {
    case 'critical': return 0; // scored separately via forceMalicious to avoid double counting
    case 'high': return SCORE.YARA_HIGH;
    case 'medium': return SCORE.YARA_MEDIUM;
    default: return SCORE.YARA_LOW;
  }
}

function scoreToVerdict(score) {
  if (score >= 100) return 'MALICIOUS';
  if (score >= 50) return 'HIGH RISK';
  if (score >= 20) return 'SUSPICIOUS';
  return 'SAFE';
}

/**
 * @param perFileResults  array of per-file analysis results (strings/entropy/pe) from scanner.js
 * @param yaraResults     { available, matches } from yaraScanner.js
 * @param clamavResult    { available, findings } from clamavScanner.js
 * @param isWhitelisted   boolean - hash is in this guild's whitelist
 * @param knownMaliciousHash boolean - hash is in this guild's blocklist
 */
export function calculateRisk({ perFileResults, yaraResults, clamavResult, isWhitelisted, knownMaliciousHash }) {
  const detections = [];
  let score = 0;
  let forceMalicious = false;

  for (const finding of clamavResult?.findings || []) {
    forceMalicious = true;
    score += SCORE.YARA_CRITICAL;
    detections.push({
      file: finding.file,
      rule: `ClamAV:${finding.signature}`,
      category: 'known_malware',
      severity: 'critical',
      description: `ClamAV signature match: ${finding.signature}`,
    });
  }

  for (const match of yaraResults?.matches || []) {
    if (match.severity === 'critical') {
      forceMalicious = true;
      score += SCORE.YARA_CRITICAL;
    } else {
      score += severityToScore(match.severity);
    }
    detections.push({
      file: match.file,
      rule: match.rule,
      category: match.category,
      severity: match.severity,
      description: match.description,
    });
  }

  if (knownMaliciousHash) {
    forceMalicious = true;
    score += SCORE.KNOWN_MALICIOUS_HASH;
    detections.push({
      file: '(whole file)',
      rule: 'KnownMaliciousHash',
      category: 'known_malware',
      severity: 'critical',
      description: 'File hash matches an entry on this server\'s malicious-hash blocklist.',
    });
  }

  // Union per-file signals into one set for the whole scan (archive-aware).
  const signals = {
    hasInputCapture: false,
    hasNetwork: false,
    hasProcessInjection: false,
    hasWebhook: false,
    keywordSet: new Set(),
    hasObfuscation: false,
    hasHighEntropy: false,
    hasPackedPe: false,
  };

  for (const file of perFileResults || []) {
    const s = file.strings;
    if (s) {
      if (s.apiHits.inputCapture.length > 0) signals.hasInputCapture = true;
      if (s.apiHits.network.length > 0) signals.hasNetwork = true;
      if (s.apiHits.processInjection.length > 0) signals.hasProcessInjection = true;
      if (s.webhooksFound.length > 0) signals.hasWebhook = true;
      for (const kw of s.keywordHits) signals.keywordSet.add(kw);
      if (s.obfuscationIndicators.base64BlobCount > 0 || s.obfuscationIndicators.hexBlobCount > 0 || s.obfuscationIndicators.lowPrintableRatio) {
        signals.hasObfuscation = true;
      }
    }

    if (file.entropy?.highEntropy) signals.hasHighEntropy = true;

    if (file.pe?.isPe) {
      if (file.pe.writeExecuteSections?.length > 0) signals.hasPackedPe = true;
      if (file.pe.packedSectionHints?.length > 0) signals.hasPackedPe = true;

      const allImportedFuncs = (file.pe.imports || []).flatMap((imp) => imp.functions);
      if (INPUT_CAPTURE_FUNCS.some((fn) => allImportedFuncs.includes(fn))) signals.hasInputCapture = true;
      if (PROCESS_INJECTION_FUNCS.some((fn) => allImportedFuncs.includes(fn))) signals.hasProcessInjection = true;
    }
  }

  if (signals.hasInputCapture && signals.hasWebhook) {
    score += SCORE.WEBHOOK_AND_CAPTURE_COMBO;
    detections.push(combo(
      'Webhook + Input Capture',
      'exfiltration',
      'high',
      'Keyboard/input-capture indicators found alongside a Discord webhook URL - possible keylog exfiltration channel.'
    ));
  } else if (signals.hasInputCapture && signals.keywordSet.size > 0) {
    score += SCORE.CREDENTIAL_CAPTURE_COMBO;
    detections.push(combo(
      'Input Capture + Credential Keywords',
      'credential_capture',
      'medium',
      'Keyboard/input-capture indicators found alongside credential-related strings.'
    ));
  }

  if (signals.hasNetwork) {
    score += SCORE.SUSPICIOUS_NETWORK;
    detections.push(combo(
      'Suspicious Network APIs',
      'network',
      'low',
      'Networking APIs are present. Not inherently malicious on its own.'
    ));
  }

  if (signals.hasProcessInjection) {
    score += SCORE.PROCESS_INJECTION_COMBO;
    detections.push(combo(
      'Process Injection APIs',
      'process_injection',
      'medium',
      'Combination of process-injection-related APIs detected.'
    ));
  }

  if (signals.keywordSet.size > 0) {
    const kwScore = Math.min(signals.keywordSet.size * SCORE.CREDENTIAL_KEYWORD_UNIT, SCORE.CREDENTIAL_KEYWORDS_MAX);
    score += kwScore;
    detections.push(combo(
      'Credential Keywords',
      'credential_capture',
      'low',
      `Found ${signals.keywordSet.size} credential-related keyword(s) (${[...signals.keywordSet].slice(0, 5).join(', ')}${signals.keywordSet.size > 5 ? ', ...' : ''}). Keywords alone are not evidence of malware.`
    ));
  }

  if (signals.hasObfuscation) {
    score += SCORE.OBFUSCATION;
    detections.push(combo(
      'Obfuscation Indicators',
      'obfuscation',
      'low',
      'Long encoded/base64/hex-like strings or a low printable-string ratio was detected.'
    ));
  }

  if (signals.hasHighEntropy) {
    score += SCORE.HIGH_ENTROPY;
    detections.push(combo(
      'High Entropy',
      'obfuscation',
      'low',
      'High entropy content detected - may indicate packing, encryption, or compression.'
    ));
  }

  if (signals.hasPackedPe) {
    score += SCORE.PACKED_PE;
    detections.push(combo(
      'Packed/Suspicious PE Sections',
      'obfuscation',
      'low',
      'Executable sections with packer indicators or write+execute permissions were detected.'
    ));
  }

  let verdict = scoreToVerdict(score);
  if (forceMalicious) verdict = 'MALICIOUS';

  const trusted = !!isWhitelisted && !knownMaliciousHash;

  return { score, verdict, detections, trusted };
}
