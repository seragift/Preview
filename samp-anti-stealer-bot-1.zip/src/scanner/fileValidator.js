import fs from 'fs';
import path from 'path';
import { fileTypeFromFile } from 'file-type';

const KNOWN_EXTENSIONS = new Set([
  '.exe', '.dll', '.asi', '.scr', '.sys',
  '.cs', '.lua', '.amx', '.pwn', '.inc',
  '.zip', '.rar', '.7z',
]);

// Extensions where we have a reliable magic-byte signature to cross-check against.
// Text/script formats (.cs, .lua, .pwn, .inc, .amx bytecode) generally have no reliable
// magic bytes, so we only flag a mismatch for the binary/archive formats below - this
// avoids false "mismatch" flags on ordinary scripts while still catching the classic
// "renamed .exe" or "renamed archive" trick (spec section 9).
const BINARY_EXT_SIGNATURES = {
  '.exe': ['exe', 'dll'],
  '.dll': ['exe', 'dll'],
  '.asi': ['exe', 'dll'], // ASI plugins are DLLs renamed with a .asi extension
  '.scr': ['exe', 'dll'],
  '.sys': ['exe', 'dll'],
  '.zip': ['zip'],
  '.rar': ['rar'],
  '.7z': ['7z'],
};

export function isKnownExtension(ext) {
  return KNOWN_EXTENSIONS.has(ext);
}

/**
 * Validates a downloaded file before any scanning happens. Returns
 * { ok: true, ext, detected, mimeMismatch, knownExtension } or { ok: false, reason }.
 */
export async function validateFile(filePath, originalName, config) {
  if (!originalName || originalName.includes('..') || originalName.includes('\0') || originalName.includes('/') || originalName.includes('\\')) {
    return { ok: false, reason: 'INVALID_FILENAME' };
  }

  let stat;
  try {
    stat = await fs.promises.stat(filePath);
  } catch {
    return { ok: false, reason: 'INTERNAL_ERROR' };
  }

  if (stat.size === 0) {
    return { ok: false, reason: 'EMPTY_FILE' };
  }

  const ext = path.extname(originalName).toLowerCase();
  const isArchive = ['.zip', '.rar', '.7z'].includes(ext);
  const maxBytes = (isArchive ? (config.maxArchiveSizeMB || 100) : (config.maxFileSizeMB || 50)) * 1024 * 1024;
  if (stat.size > maxBytes) {
    return { ok: false, reason: isArchive ? 'ARCHIVE_TOO_LARGE' : 'FILE_TOO_LARGE' };
  }

  let detected = null;
  try {
    detected = await fileTypeFromFile(filePath);
  } catch {
    detected = null;
  }

  let mimeMismatch = false;
  if (detected && BINARY_EXT_SIGNATURES[ext]) {
    mimeMismatch = !BINARY_EXT_SIGNATURES[ext].includes(detected.ext);
  }

  return {
    ok: true,
    ext,
    detected,
    mimeMismatch,
    knownExtension: KNOWN_EXTENSIONS.has(ext),
  };
}
