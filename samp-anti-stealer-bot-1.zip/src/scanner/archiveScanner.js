import AdmZip from 'adm-zip';
import path from 'path';
import fs from 'fs';
import { execa } from 'execa';

/**
 * Extracts an archive into extractDir with several layers of protection against
 * archive bombs and path traversal (zip-slip):
 *  - entry count is checked against maxFilesInArchive before writing anything
 *  - total UNCOMPRESSED size is checked against maxExtractedSizeMB before writing
 *    anything (for RAR/7z this is a best-effort listing parse - see note below)
 *  - every extracted entry path is resolved and verified to stay inside extractDir
 *  - a post-extraction walk re-verifies actual size/count as a second, authoritative
 *    safety net regardless of whether the pre-check was accurate
 *  - all external processes (unrar/7z) run with a timeout
 *
 * Returns { files: [{absolutePath, relativePath}], fileCount } or { error: '<REASON>', files: [] }.
 */
export async function extractArchive(archivePath, extractDir, config) {
  const ext = path.extname(archivePath).toLowerCase();
  await fs.promises.mkdir(extractDir, { recursive: true });

  if (ext === '.zip') return extractZip(archivePath, extractDir, config);
  if (ext === '.rar') return extractRar(archivePath, extractDir, config);
  if (ext === '.7z') return extractSevenZip(archivePath, extractDir, config);

  return { error: 'UNSUPPORTED_ARCHIVE_TYPE', files: [] };
}

function isPathSafe(baseDir, targetPath) {
  const resolvedBase = path.resolve(baseDir) + path.sep;
  const resolvedTarget = path.resolve(targetPath);
  return resolvedTarget.startsWith(resolvedBase);
}

async function extractZip(archivePath, extractDir, config) {
  const maxFiles = config.maxFilesInArchive || 1000;
  const maxExtractedBytes = (config.maxExtractedSizeMB || 500) * 1024 * 1024;

  let zip;
  try {
    zip = new AdmZip(archivePath);
  } catch {
    return { error: 'ARCHIVE_CORRUPT', files: [] };
  }

  let entries;
  try {
    entries = zip.getEntries();
  } catch {
    return { error: 'ARCHIVE_CORRUPT', files: [] };
  }

  const fileEntries = entries.filter((e) => !e.isDirectory);

  if (fileEntries.length > maxFiles) {
    return { error: 'TOO_MANY_FILES', files: [] };
  }

  const totalUncompressed = fileEntries.reduce((sum, e) => sum + (e.header?.size || 0), 0);
  if (totalUncompressed > maxExtractedBytes) {
    return { error: 'ARCHIVE_TOO_LARGE_UNCOMPRESSED', files: [] };
  }

  const files = [];
  for (const entry of fileEntries) {
    const destPath = path.join(extractDir, entry.entryName);
    if (!isPathSafe(extractDir, destPath)) {
      continue; // zip-slip / path traversal attempt - silently skip this entry
    }

    try {
      await fs.promises.mkdir(path.dirname(destPath), { recursive: true });
      await fs.promises.writeFile(destPath, entry.getData());
      files.push({ absolutePath: destPath, relativePath: entry.entryName });
    } catch {
      // Skip entries that fail to extract individually rather than aborting the whole scan.
      continue;
    }
  }

  return { files, fileCount: files.length };
}

/** Recursively walks a directory, returning [{ absolutePath, size }] for every regular file. */
async function walkDir(dir) {
  const results = [];

  async function walk(current) {
    let entries;
    try {
      entries = await fs.promises.readdir(current, { withFileTypes: true });
    } catch {
      return;
    }
    for (const entry of entries) {
      const fullPath = path.join(current, entry.name);
      if (entry.isDirectory()) {
        await walk(fullPath);
      } else if (entry.isFile()) {
        try {
          const stat = await fs.promises.stat(fullPath);
          results.push({ absolutePath: fullPath, size: stat.size });
        } catch {
          continue;
        }
      }
    }
  }

  await walk(dir);
  return results;
}

// unrar's `v` (verbose list) output is a text table; exact column spacing has varied
// slightly across unrar versions, so this parser is deliberately best-effort. If it can't
// recognize the format at all, extraction is refused (fail closed) rather than proceeding
// blind. The post-extraction walkDir() check below is the authoritative safety net either way.
function parseUnrarVerboseListing(stdout) {
  const lines = stdout.split('\n');
  let totalSize = 0;
  let fileCount = 0;
  let matchedAny = false;

  for (const line of lines) {
    const m = line.match(/^\s*[.\-A-Za-z]{1,10}\s+(\d+)\s+\d+\s+\d+%/);
    if (m) {
      totalSize += parseInt(m[1], 10);
      fileCount++;
      matchedAny = true;
    }
  }

  if (!matchedAny) return null;
  return { totalSize, fileCount };
}

async function extractRar(archivePath, extractDir, config) {
  const maxExtractedBytes = (config.maxExtractedSizeMB || 500) * 1024 * 1024;
  const maxFiles = config.maxFilesInArchive || 1000;
  const timeout = (config.scanTimeoutSeconds || 60) * 1000;

  let listResult;
  try {
    listResult = await execa('unrar', ['v', '-c-', archivePath], { timeout });
  } catch {
    return { error: 'ARCHIVE_LISTING_FAILED', files: [] };
  }

  const parsed = parseUnrarVerboseListing(listResult.stdout);
  if (!parsed) {
    return { error: 'ARCHIVE_LISTING_FAILED', files: [] };
  }
  if (parsed.fileCount > maxFiles) {
    return { error: 'TOO_MANY_FILES', files: [] };
  }
  if (parsed.totalSize > maxExtractedBytes) {
    return { error: 'ARCHIVE_TOO_LARGE_UNCOMPRESSED', files: [] };
  }

  try {
    await execa('unrar', ['x', '-y', '-o+', '-c-', archivePath, extractDir + path.sep], { timeout });
  } catch {
    return { error: 'ARCHIVE_EXTRACTION_FAILED', files: [] };
  }

  return verifyAndCollect(extractDir, maxExtractedBytes, maxFiles);
}

// 7z's `l` (list) output ends with a summary footer line such as:
//   "12345678    1234567  5 files, 2 folders"
// Column spacing/locale varies by 7-Zip build, so - same as unrar above - this is
// best-effort with fail-closed behavior on parse failure.
function parse7zListing(stdout) {
  const match = stdout.match(/(\d+)\s+\d+\s+(\d+)\s+files?/i);
  if (!match) return null;
  return { totalSize: parseInt(match[1], 10), fileCount: parseInt(match[2], 10) };
}

async function extractSevenZip(archivePath, extractDir, config) {
  const maxExtractedBytes = (config.maxExtractedSizeMB || 500) * 1024 * 1024;
  const maxFiles = config.maxFilesInArchive || 1000;
  const timeout = (config.scanTimeoutSeconds || 60) * 1000;

  let listResult;
  try {
    listResult = await execa('7z', ['l', archivePath], { timeout });
  } catch {
    return { error: 'ARCHIVE_LISTING_FAILED', files: [] };
  }

  const parsed = parse7zListing(listResult.stdout);
  if (!parsed) {
    return { error: 'ARCHIVE_LISTING_FAILED', files: [] };
  }
  if (parsed.fileCount > maxFiles) {
    return { error: 'TOO_MANY_FILES', files: [] };
  }
  if (parsed.totalSize > maxExtractedBytes) {
    return { error: 'ARCHIVE_TOO_LARGE_UNCOMPRESSED', files: [] };
  }

  try {
    await execa('7z', ['x', `-o${extractDir}`, '-y', archivePath], { timeout });
  } catch {
    return { error: 'ARCHIVE_EXTRACTION_FAILED', files: [] };
  }

  return verifyAndCollect(extractDir, maxExtractedBytes, maxFiles);
}

async function verifyAndCollect(extractDir, maxExtractedBytes, maxFiles) {
  const walked = await walkDir(extractDir);
  const actualTotalSize = walked.reduce((sum, f) => sum + f.size, 0);

  if (actualTotalSize > maxExtractedBytes || walked.length > maxFiles) {
    return { error: 'ARCHIVE_TOO_LARGE_UNCOMPRESSED', files: [] };
  }

  const files = walked.map((f) => ({
    absolutePath: f.absolutePath,
    relativePath: path.relative(extractDir, f.absolutePath),
  }));

  return { files, fileCount: files.length };
}
