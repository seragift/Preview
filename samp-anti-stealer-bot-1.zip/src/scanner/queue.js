import { runScan } from './scanner.js';
import { loadConfig } from '../utils/configLoader.js';

const config = loadConfig();
const MAX_CONCURRENT = config.maxConcurrentScans || 2;

let active = 0;
const waiting = [];

/**
 * job: { guildId, userId, attachment, onQueued?(), onComplete(result), onError(err) }
 * onQueued fires synchronously, at most once, only if the job could not start immediately.
 */
export function enqueueScan(job) {
  if (active >= MAX_CONCURRENT) {
    job.onQueued?.();
  }
  waiting.push(job);
  processQueue();
}

function processQueue() {
  while (active < MAX_CONCURRENT && waiting.length > 0) {
    const job = waiting.shift();
    active++;
    runJob(job).finally(() => {
      active--;
      processQueue();
    });
  }
}

async function runJob(job) {
  try {
    const result = await runScan({ guildId: job.guildId, userId: job.userId, attachment: job.attachment });
    await job.onComplete(result);
  } catch (err) {
    await job.onError(err);
  }
}

export function getQueueStatus() {
  return { active, queued: waiting.length, maxConcurrent: MAX_CONCURRENT };
}
