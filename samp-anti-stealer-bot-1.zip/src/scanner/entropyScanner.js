/**
 * Shannon entropy of a byte buffer, in bits per byte (0 = totally uniform/repetitive,
 * 8 = maximally random). High entropy is a weak signal of packing, encryption, or
 * compression - NOT proof of anything malicious on its own (spec section 19).
 */
export function calculateEntropy(buffer) {
  if (!buffer || buffer.length === 0) return 0;

  const freq = new Array(256).fill(0);
  for (let i = 0; i < buffer.length; i++) {
    freq[buffer[i]]++;
  }

  let entropy = 0;
  const len = buffer.length;
  for (const count of freq) {
    if (count === 0) continue;
    const p = count / len;
    entropy -= p * Math.log2(p);
  }

  return entropy;
}

/** Whole-file entropy analysis with a configurable "high entropy" threshold. */
export function analyzeEntropy(buffer, config) {
  const threshold = config?.entropyThreshold ?? 7.2;
  const value = calculateEntropy(buffer);
  return {
    value: Number(value.toFixed(3)),
    highEntropy: value >= threshold,
    threshold,
  };
}
