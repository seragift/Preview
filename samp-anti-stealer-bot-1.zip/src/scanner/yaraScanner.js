import { execa } from 'execa';
import path from 'path';
import { fileURLToPath } from 'url';
import { logger } from '../utils/logger.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const MASTER_RULES_PATH = path.join(__dirname, '..', 'yara', 'master.yar');

let yaraAvailableCache = null;

export async function isYaraAvailable() {
  if (yaraAvailableCache !== null) return yaraAvailableCache;
  try {
    await execa('yara', ['--version'], { timeout: 5000 });
    yaraAvailableCache = true;
  } catch {
    yaraAvailableCache = false;
  }
  return yaraAvailableCache;
}

/**
 * Runs the full rule set (src/yara/master.yar, which includes every category module)
 * against targetPath (a single file or, with -r, a directory to recurse into).
 * Returns { available, matches: [{rule, category, severity, description, file}] }.
 * Never throws - if YARA is missing or fails, returns available:false / an error flag
 * so the rest of the scan can continue (spec sections 30-31).
 */
export async function scanWithYara(targetPath, config) {
  const available = await isYaraAvailable();
  if (!available) return { available: false, matches: [] };

  const timeoutSeconds = config.scanTimeoutSeconds || 60;

  const result = await execa(
    'yara',
    ['-r', '-m', '-s', '-w', '-a', String(timeoutSeconds), MASTER_RULES_PATH, targetPath],
    { timeout: timeoutSeconds * 1000, reject: false }
  ).catch((err) => ({ exitCode: -1, stdout: '', stderr: String(err) }));

  if (result.exitCode !== 0) {
    logger.error('YARA exited with an error', result.stderr);
    return { available: true, matches: [], error: 'YARA_EXECUTION_ERROR' };
  }

  return { available: true, matches: parseYaraOutput(result.stdout) };
}

function parseYaraOutput(stdout) {
  const matches = [];
  if (!stdout) return matches;

  for (const line of stdout.split('\n')) {
    if (!line || /^\s/.test(line)) continue; // skip indented matched-string detail lines (-s output)

    // Format (with -m -s -w): rule_name [key1="val1",key2="val2"] file_path
    const m = line.match(/^(\S+)\s*(\[.*?\])?\s+(.+)$/);
    if (!m) continue;

    const [, ruleName, metaBlock, filePath] = m;
    const meta = parseMeta(metaBlock);

    matches.push({
      rule: ruleName,
      category: meta.category || 'uncategorized',
      severity: meta.severity || 'low',
      description: meta.description || '',
      file: filePath.trim(),
    });
  }

  return matches;
}

function parseMeta(metaBlock) {
  const meta = {};
  if (!metaBlock) return meta;
  const inner = metaBlock.slice(1, -1);
  const pairRegex = /(\w+)="((?:[^"\\]|\\.)*)"/g;
  let match;
  while ((match = pairRegex.exec(inner)) !== null) {
    meta[match[1]] = match[2].replace(/\\"/g, '"');
  }
  return meta;
}
