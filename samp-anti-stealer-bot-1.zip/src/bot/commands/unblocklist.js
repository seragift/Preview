import { SlashCommandBuilder, PermissionFlagsBits } from 'discord.js';
import { removeBlocklist } from '../../database/databaseManager.js';

export const data = new SlashCommandBuilder()
  .setName('unblocklist')
  .setDescription('Remove a hash from this server\'s known-malicious blocklist')
  .addStringOption((opt) => opt.setName('hash').setDescription('SHA-256 hash').setRequired(true))
  .setDefaultMemberPermissions(PermissionFlagsBits.Administrator);

export async function execute(interaction) {
  const hash = interaction.options.getString('hash').trim().toLowerCase();
  const removed = removeBlocklist(interaction.guild.id, hash);

  await interaction.reply(removed ? `Hash \`${hash}\` dihapus dari blocklist.` : 'Hash tidak ditemukan di blocklist server ini.');
}
