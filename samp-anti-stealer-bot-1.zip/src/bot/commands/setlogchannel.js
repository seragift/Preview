import { SlashCommandBuilder, PermissionFlagsBits, ChannelType } from 'discord.js';
import { setSetting } from '../../database/databaseManager.js';

export const data = new SlashCommandBuilder()
  .setName('setlogchannel')
  .setDescription('Set the channel where a copy of every scan report will also be posted')
  .addChannelOption((opt) =>
    opt
      .setName('channel')
      .setDescription('The channel to use for scan logs')
      .addChannelTypes(ChannelType.GuildText)
      .setRequired(true)
  )
  .setDefaultMemberPermissions(PermissionFlagsBits.Administrator);

export async function execute(interaction) {
  const channel = interaction.options.getChannel('channel');
  setSetting(interaction.guild.id, 'logChannelId', channel.id);

  await interaction.reply(`✅ Log channel berhasil diatur ke <#${channel.id}>`);
}
