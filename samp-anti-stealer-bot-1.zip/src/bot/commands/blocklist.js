import { SlashCommandBuilder, PermissionFlagsBits } from 'discord.js';
import { addBlocklist } from '../../database/databaseManager.js';

export const data = new SlashCommandBuilder()
  .setName('blocklist')
  .setDescription('Mark a file hash as known-malicious for this server (forces a MALICIOUS verdict on future scans)')
  .addStringOption((opt) => opt.setName('hash').setDescription('SHA-256 hash').setRequired(true))
  .addStringOption((opt) => opt.setName('reason').setDescription('Reason for blocklisting').setRequired(false))
  .setDefaultMemberPermissions(PermissionFlagsBits.Administrator);

export async function execute(interaction) {
  const hash = interaction.options.getString('hash').trim().toLowerCase();
  if (!/^[a-f0-9]{64}$/.test(hash)) {
    await interaction.reply({ content: '⚠️ Format hash tidak valid. Gunakan SHA-256 (64 karakter hex).', ephemeral: true });
    return;
  }

  const reason = interaction.options.getString('reason') || null;
  addBlocklist(interaction.guild.id, hash, reason, interaction.user.id);

  await interaction.reply(`🔴 Hash \`${hash}\` ditandai sebagai KNOWN MALICIOUS untuk server ini.`);
}
