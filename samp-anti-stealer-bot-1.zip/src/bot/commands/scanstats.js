import { SlashCommandBuilder } from 'discord.js';
import { getStats } from '../../database/databaseManager.js';

export const data = new SlashCommandBuilder()
  .setName('scanstats')
  .setDescription('Show scan statistics for this server');

export async function execute(interaction) {
  const stats = getStats(interaction.guild.id);

  const lines = [`**Total scans:** ${stats.total}`];
  for (const row of stats.byVerdict) {
    lines.push(`${row.verdict}: ${row.c}`);
  }

  await interaction.reply(lines.join('\n'));
}
