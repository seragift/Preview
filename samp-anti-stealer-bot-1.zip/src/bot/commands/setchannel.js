import { SlashCommandBuilder, PermissionFlagsBits, ChannelType } from 'discord.js';
import { setSetting } from '../../database/databaseManager.js';

export const data = new SlashCommandBuilder()
  .setName('setchannel')
  .setDescription('Set the channel where uploaded files will be automatically scanned')
  .addChannelOption((opt) =>
    opt
      .setName('channel')
      .setDescription('The channel to use as the scanner channel')
      .addChannelTypes(ChannelType.GuildText)
      .setRequired(true)
  )
  .setDefaultMemberPermissions(PermissionFlagsBits.Administrator);

export async function execute(interaction) {
  const channel = interaction.options.getChannel('channel');
  setSetting(interaction.guild.id, 'scannerChannelId', channel.id);

  await interaction.reply(`✅ Scanner channel berhasil diatur ke <#${channel.id}>`);
}
