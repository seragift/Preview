import { SlashCommandBuilder } from 'discord.js';
import { getScanByHash, getWhitelistEntry, getBlocklistEntry } from '../../database/databaseManager.js';

export const data = new SlashCommandBuilder()
  .setName('scaninfo')
  .setDescription('Look up previous scan history for this server by SHA-256 hash')
  .addStringOption((opt) => opt.setName('hash').setDescription('SHA-256 hash to look up').setRequired(true));

export async function execute(interaction) {
  const hash = interaction.options.getString('hash').trim().toLowerCase();

  if (!/^[a-f0-9]{64}$/.test(hash)) {
    await interaction.reply({ content: '⚠️ Format hash tidak valid. Gunakan SHA-256 (64 karakter hex).', ephemeral: true });
    return;
  }

  const scan = getScanByHash(interaction.guild.id, hash);
  if (!scan) {
    await interaction.reply({ content: 'Tidak ditemukan riwayat scan untuk hash tersebut di server ini.', ephemeral: true });
    return;
  }

  const whitelisted = getWhitelistEntry(interaction.guild.id, hash);
  const blocklisted = getBlocklistEntry(interaction.guild.id, hash);

  const lines = [
    `**File:** ${scan.filename}`,
    `**SHA-256:** \`${scan.sha256}\``,
    `**Verdict:** ${scan.verdict}`,
    `**Risk Score:** ${scan.risk_score}`,
    `**Scanned:** ${scan.created_at}`,
  ];
  if (whitelisted) lines.push(`🟢 **Whitelisted** — ${whitelisted.reason || 'no reason given'}`);
  if (blocklisted) lines.push(`🔴 **Blocklisted** — ${blocklisted.reason || 'no reason given'}`);

  await interaction.reply(lines.join('\n'));
}
