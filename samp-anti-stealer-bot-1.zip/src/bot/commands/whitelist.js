import { SlashCommandBuilder, PermissionFlagsBits } from 'discord.js';
import { addWhitelist } from '../../database/databaseManager.js';

export const data = new SlashCommandBuilder()
  .setName('whitelist')
  .setDescription('Mark a file hash as trusted for this server (does not remove existing detections from reports)')
  .addStringOption((opt) => opt.setName('hash').setDescription('SHA-256 hash').setRequired(true))
  .addStringOption((opt) => opt.setName('reason').setDescription('Reason for whitelisting').setRequired(false))
  .setDefaultMemberPermissions(PermissionFlagsBits.Administrator);

export async function execute(interaction) {
  const hash = interaction.options.getString('hash').trim().toLowerCase();
  if (!/^[a-f0-9]{64}$/.test(hash)) {
    await interaction.reply({ content: '⚠️ Format hash tidak valid. Gunakan SHA-256 (64 karakter hex).', ephemeral: true });
    return;
  }

  const reason = interaction.options.getString('reason') || null;
  addWhitelist(interaction.guild.id, hash, reason, interaction.user.id);

  await interaction.reply(`🟢 Hash \`${hash}\` ditandai sebagai TRUSTED untuk server ini.`);
}
