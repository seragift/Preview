import { SlashCommandBuilder, PermissionFlagsBits } from 'discord.js';
import { removeWhitelist } from '../../database/databaseManager.js';

export const data = new SlashCommandBuilder()
  .setName('unwhitelist')
  .setDescription('Remove a hash from this server\'s trusted whitelist')
  .addStringOption((opt) => opt.setName('hash').setDescription('SHA-256 hash').setRequired(true))
  .setDefaultMemberPermissions(PermissionFlagsBits.Administrator);

export async function execute(interaction) {
  const hash = interaction.options.getString('hash').trim().toLowerCase();
  const removed = removeWhitelist(interaction.guild.id, hash);

  await interaction.reply(removed ? `Hash \`${hash}\` dihapus dari whitelist.` : 'Hash tidak ditemukan di whitelist server ini.');
}
