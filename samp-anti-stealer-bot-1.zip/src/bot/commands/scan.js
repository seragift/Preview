import { SlashCommandBuilder } from 'discord.js';
import { runScan } from '../../scanner/scanner.js';
import { buildScanResultEmbed, buildArchiveResultEmbed, buildRejectionEmbed } from '../../utils/embed.js';
import { checkRateLimit } from '../../utils/rateLimiter.js';
import { loadConfig } from '../../utils/configLoader.js';
import { logger } from '../../utils/logger.js';

export const data = new SlashCommandBuilder()
  .setName('scan')
  .setDescription('Manually scan an uploaded file for security indicators')
  .addAttachmentOption((opt) => opt.setName('file').setDescription('The file to scan').setRequired(true));

export async function execute(interaction) {
  const config = loadConfig();
  const attachment = interaction.options.getAttachment('file');

  const rl = checkRateLimit(interaction.user.id, config.maxScansPerUserPerMinute);
  if (!rl.allowed) {
    await interaction.reply({
      content: `⏳ Kamu mengirim file terlalu cepat. Coba lagi dalam ${rl.retryAfterSeconds} detik.`,
      ephemeral: true,
    });
    return;
  }

  await interaction.deferReply();

  try {
    const result = await runScan({ guildId: interaction.guild.id, userId: interaction.user.id, attachment });

    const embed = result.rejected
      ? buildRejectionEmbed(result.reason, result.filename)
      : result.isArchive
        ? buildArchiveResultEmbed(result)
        : buildScanResultEmbed(result);

    await interaction.editReply({ embeds: [embed] });
  } catch (err) {
    logger.error('/scan command failed', err);
    await interaction.editReply('⚠️ Terjadi kesalahan saat memindai file ini.');
  }
}
