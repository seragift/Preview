// Registers slash commands GLOBALLY (Routes.applicationCommands), not per-guild, since this
// bot is designed to run in many servers without a hardcoded GUILD_ID. Run this once after
// first setup, and again any time a command definition changes:
//
//   npm run deploy
//
// Note: global command changes can take up to ~1 hour to appear in every server (unlike
// guild-scoped commands, which are instant). This is a Discord API limitation, not a bug.

import 'dotenv/config';
import fs from 'fs';
import path from 'path';
import { fileURLToPath, pathToFileURL } from 'url';
import { REST, Routes } from 'discord.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

async function main() {
  if (!process.env.DISCORD_TOKEN || !process.env.CLIENT_ID) {
    console.error('DISCORD_TOKEN dan CLIENT_ID wajib diisi di file .env (lihat .env.example).');
    process.exit(1);
  }

  const commandsDir = path.join(__dirname, 'commands');
  const files = fs.readdirSync(commandsDir).filter((f) => f.endsWith('.js'));
  const commands = [];

  for (const file of files) {
    const mod = await import(pathToFileURL(path.join(commandsDir, file)).href);
    if (mod.data) {
      commands.push(mod.data.toJSON());
    } else {
      console.warn(`Skipping ${file}: no "data" export found.`);
    }
  }

  const rest = new REST().setToken(process.env.DISCORD_TOKEN);

  console.log(`Mendaftarkan ${commands.length} global slash command: ${commands.map((c) => c.name).join(', ')}`);
  await rest.put(Routes.applicationCommands(process.env.CLIENT_ID), { body: commands });
  console.log('Selesai. Command global bisa memakan waktu hingga ~1 jam untuk muncul di semua server.');
}

main().catch((err) => {
  console.error('Gagal mendaftarkan command:', err);
  process.exit(1);
});
