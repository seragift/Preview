import { Events } from 'discord.js';
import { getSettings } from '../../database/databaseManager.js';
import { checkRateLimit } from '../../utils/rateLimiter.js';
import { enqueueScan } from '../../scanner/queue.js';
import { buildScanResultEmbed, buildArchiveResultEmbed, buildRejectionEmbed } from '../../utils/embed.js';
import { loadConfig } from '../../utils/configLoader.js';
import { logger } from '../../utils/logger.js';

export const name = Events.MessageCreate;

export async function execute(message) {
  try {
    if (message.author.bot) return;
    if (!message.guild) return; // ignore DMs
    if (message.attachments.size === 0) return; // "Jika tidak ada attachment: abaikan."

    const settings = getSettings(message.guild.id);
    if (!settings.scannerChannelId || message.channel.id !== settings.scannerChannelId) return;

    const config = loadConfig();
    const rl = checkRateLimit(message.author.id, config.maxScansPerUserPerMinute);
    if (!rl.allowed) {
      await message.reply(`⏳ Kamu mengirim file terlalu cepat. Coba lagi dalam ${rl.retryAfterSeconds} detik.`);
      return;
    }

    for (const attachment of message.attachments.values()) {
      await message.reply('🔎 File diterima. Memulai security analysis...');

      enqueueScan({
        guildId: message.guild.id,
        userId: message.author.id,
        attachment,
        onQueued: () => {
          message.channel.send('⏳ Scanner sedang sibuk. File kamu masuk antrean.').catch(() => {});
        },
        onComplete: async (result) => {
          const embed = result.rejected
            ? buildRejectionEmbed(result.reason, result.filename)
            : result.isArchive
              ? buildArchiveResultEmbed(result)
              : buildScanResultEmbed(result);
          await message.channel.send({ embeds: [embed] }).catch(() => {});

          if (settings.logChannelId && settings.logChannelId !== message.channel.id) {
            const logChannel = message.guild.channels.cache.get(settings.logChannelId);
            if (logChannel?.isTextBased()) {
              logChannel.send({ embeds: [embed] }).catch(() => {});
            }
          }
        },
        onError: async (err) => {
          logger.error('Scan failed', err);
          await message.channel.send('⚠️ Terjadi kesalahan saat memindai file ini.').catch(() => {});
        },
      });
    }
  } catch (err) {
    logger.error('messageCreate handler error', err);
  }
}
