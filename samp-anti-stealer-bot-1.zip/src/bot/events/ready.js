import { Events } from 'discord.js';
import { logger } from '../../utils/logger.js';

export const name = Events.ClientReady;
export const once = true;

export function execute(client) {
  logger.info(`Logged in as ${client.user.tag}`);
  logger.info(`Serving ${client.guilds.cache.size} guild(s)`);
  client.user.setActivity('for stealer mods 🛡️');
}
