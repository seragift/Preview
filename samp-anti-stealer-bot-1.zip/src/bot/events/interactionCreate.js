import { Events } from 'discord.js';
import { logger } from '../../utils/logger.js';

export const name = Events.InteractionCreate;

export async function execute(interaction) {
  if (!interaction.isChatInputCommand()) return;

  const command = interaction.client.commands.get(interaction.commandName);
  if (!command) return;

  try {
    await command.execute(interaction);
  } catch (err) {
    logger.error(`Command "${interaction.commandName}" failed`, err);
    const payload = { content: '⚠️ Terjadi kesalahan saat menjalankan command ini.', ephemeral: true };
    try {
      if (interaction.deferred || interaction.replied) {
        await interaction.editReply(payload);
      } else {
        await interaction.reply(payload);
      }
    } catch {
      // Interaction may have already expired - nothing more we can do.
    }
  }
}
