import 'dotenv/config';
import fs from 'fs';
import path from 'path';
import { fileURLToPath, pathToFileURL } from 'url';
import { Client, GatewayIntentBits, Collection } from 'discord.js';

import { logger } from './src/utils/logger.js';
import { closeAll } from './src/database/databaseManager.js';
import { cleanupOrphanedTempDirs } from './src/utils/cleanup.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

if (!process.env.DISCORD_TOKEN || !process.env.CLIENT_ID) {
  console.error(
    'DISCORD_TOKEN dan CLIENT_ID wajib diisi di file .env (lihat .env.example).'
  );
  process.exit(1);
}

// Message Content intent is required to see attachments on messages the bot did not author
// or is not directly mentioned in. It must also be enabled in the Discord Developer Portal
// under Bot -> Privileged Gateway Intents -> Message Content Intent. See README section 4.
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
});

client.commands = new Collection();

async function loadCommands() {
  const commandsDir = path.join(__dirname, 'src', 'bot', 'commands');
  const files = fs.readdirSync(commandsDir).filter((f) => f.endsWith('.js'));

  for (const file of files) {
    const mod = await import(pathToFileURL(path.join(commandsDir, file)).href);
    if (mod.data && mod.execute) {
      client.commands.set(mod.data.name, mod);
    } else {
      logger.warn(`Command file ${file} is missing "data" or "execute" export, skipping.`);
    }
  }

  logger.info(`Loaded ${client.commands.size} slash command(s).`);
}

async function loadEvents() {
  const eventsDir = path.join(__dirname, 'src', 'bot', 'events');
  const files = fs.readdirSync(eventsDir).filter((f) => f.endsWith('.js'));

  for (const file of files) {
    const mod = await import(pathToFileURL(path.join(eventsDir, file)).href);
    if (!mod.name || !mod.execute) {
      logger.warn(`Event file ${file} is missing "name" or "execute" export, skipping.`);
      continue;
    }
    if (mod.once) {
      client.once(mod.name, (...args) => mod.execute(...args, client));
    } else {
      client.on(mod.name, (...args) => mod.execute(...args, client));
    }
  }

  logger.info(`Loaded ${files.length} event handler(s).`);
}

async function main() {
  await cleanupOrphanedTempDirs(path.join(__dirname, 'src', 'temp', 'scans'));
  await loadCommands();
  await loadEvents();
  await client.login(process.env.DISCORD_TOKEN);
}

function shutdown(signal) {
  logger.info(`Received ${signal}, shutting down...`);
  closeAll();
  client.destroy();
  process.exit(0);
}

process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));

process.on('unhandledRejection', (err) => {
  logger.error('Unhandled promise rejection', err);
});
process.on('uncaughtException', (err) => {
  logger.error('Uncaught exception', err);
});

main().catch((err) => {
  logger.error('Fatal startup error', err);
  process.exit(1);
});
