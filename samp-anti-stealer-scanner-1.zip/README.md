# SA-MP Anti-Stealer / Modpack Security Scanner v2

Bot Discord untuk **defensive static security scanning** file SA-MP/GTA:SA
(plugin `.asi`, script `.cs`/`.lua`/`.amx`/`.pwn`, dan archive modpack
`.zip`/`.rar`/`.7z`). Mendeteksi indikasi credential stealing, keylogging,
data exfiltration, webhook Discord tersembunyi, process injection, dan
obfuscation — **tanpa pernah mengeksekusi file yang diupload**.

> ⚠️ Static analysis tidak bisa menjamin file 100% aman. Verdict `SAFE`
> berarti *"tidak ada indikator malicious yang diketahui"*, bukan jaminan mutlak.

Bot ini bersifat **global** — sekali dijalankan, bisa dipakai di semua
server Discord manapun bot diundang, masing-masing dengan setting channel
sendiri-sendiri (disimpan per `guild_id` di database).

---

## 1. Requirements

- Node.js **20+**
- Ubuntu 22.04/24.04 (disarankan) atau OS Linux lain yang setara
- Akses `sudo` untuk install YARA, ClamAV, dan p7zip
- Discord Bot Application (Developer Portal)

---

## 2. Instalasi Node.js 20+ (Ubuntu)

```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs
node -v   # pastikan v20.x atau lebih baru
```

---

## 3. Setup Discord Bot

1. Buka https://discord.com/developers/applications → **New Application**.
2. Tab **Bot** → *Reset Token* → salin token (untuk `.env`).
3. Di tab **Bot**, aktifkan intent:
   - `MESSAGE CONTENT INTENT` (wajib, untuk membaca attachment)
   - `SERVER MEMBERS INTENT` (opsional)
4. Tab **OAuth2 → URL Generator**:
   - Scope: `bot`, `applications.commands`
   - Bot Permissions: `Send Messages`, `Embed Links`, `Read Message History`,
     `Attach Files`, `Use Slash Commands`
   - Gunakan URL yang dihasilkan untuk invite bot ke server.
5. Salin **Application ID** (CLIENT_ID) dari tab **General Information**.

### Discord Intents yang dipakai bot (index.js)

- `Guilds`
- `GuildMessages`
- `MessageContent`

---

## 4. Install YARA (Ubuntu 22.04/24.04)

```bash
sudo apt update
sudo apt install -y yara
yara --version
```

Jika versi repo terlalu lama dan butuh fitur YARA terbaru, build dari source:

```bash
sudo apt install -y automake libtool make gcc pkg-config libssl-dev libjansson-dev
git clone --recursive https://github.com/VirusTotal/yara.git
cd yara
./bootstrap.sh
./configure
make
sudo make install
sudo ldconfig
```

---

## 5. Install ClamAV (Ubuntu 22.04/24.04)

```bash
sudo apt update
sudo apt install -y clamav clamav-daemon
sudo systemctl stop clamav-freshclam
sudo freshclam        # update virus database awal
sudo systemctl start clamav-freshclam
clamscan --version
```

> Jika ClamAV tidak terinstall/tidak ditemukan, bot tetap berjalan normal
> menggunakan YARA + static analysis saja (lihat `config.json` →
> `clamavEnabled`). Bot **tidak akan crash** jika ClamAV tidak ada.

---

## 6. Install p7zip (untuk ekstraksi .rar dan .7z)

```bash
sudo apt install -y p7zip-full
7z --help
```

---

## 7. Install Dependencies Bot

```bash
git clone <repo-anda>
cd samp-anti-stealer-scanner
npm install
```

Dependencies utama: `discord.js`, `dotenv`, `better-sqlite3`, `adm-zip`.
YARA, ClamAV, dan 7z adalah **system dependencies** (binary eksternal,
dipanggil lewat `child_process`, bukan npm package).

---

## 8. Konfigurasi

### `.env`

```bash
cp .env.example .env
```

Isi:

```
DISCORD_TOKEN=isi_token_bot_di_sini
CLIENT_ID=isi_application_id_di_sini
```

**Tidak ada `GUILD_ID`** — command didaftarkan secara global agar bot bisa
dipakai di server manapun tanpa konfigurasi ulang.

### `config.json`

Berisi konfigurasi non-secret (limit ukuran file, timeout, toggle
YARA/ClamAV/PE analysis, dsb). Edit sesuai kebutuhan server kamu — lihat
komentar di setiap key.

---

## 9. Registrasi Slash Command (Global)

```bash
npm run register
```

Command akan tersedia di **semua server** tempat bot diundang. Propagasi
pertama kali oleh Discord bisa memakan waktu hingga ~1 jam; update
berikutnya biasanya langsung terlihat.

---

## 10. Menjalankan Bot

```bash
npm start
```

Jika berhasil, log akan menampilkan status YARA/ClamAV availability dan
bot online di semua guild.

---

## 11. Cara Pakai

1. Admin server menjalankan `/setchannel #scanner` di channel yang mau
   dipantau.
2. (Opsional) `/setlogchannel #logs` untuk channel log hasil scan.
3. User tinggal upload file/archive ke channel tersebut → bot otomatis
   scan dan balas dengan embed hasil.
4. Command tambahan:
   - `/scan file:<attachment>` — scan manual di channel manapun.
   - `/scaninfo hash:<sha256>` — cek riwayat scan berdasarkan hash.
   - `/scanstats` — statistik scan per server.
   - `/whitelist hash:<sha256> reason:<...>` — tandai hash sebagai TRUSTED (admin).
   - `/unwhitelist hash:<sha256>` — hapus status TRUSTED (admin).

---

## 12. Deployment dengan PM2

```bash
npm install -g pm2
pm2 start index.js --name samp-scanner
pm2 save
pm2 startup   # ikuti instruksi yang muncul agar auto-start saat reboot
pm2 logs samp-scanner
```

---

## 13. Deployment dengan Docker

```bash
docker build -t samp-scanner .
docker run -d \
  --name samp-scanner \
  --env-file .env \
  --memory=512m --cpus=1 \
  -v $(pwd)/src/data:/app/src/data \
  -v $(pwd)/logs:/app/logs \
  samp-scanner
```

Container berjalan sebagai user non-root (`node`) dan tetap butuh YARA,
ClamAV, dan p7zip terinstall di dalam image (sudah termasuk di
`Dockerfile` yang disediakan).

---

## 14. Pengembangan YARA Rule

Rule ada di `src/yara/*.yar`, diimpor lewat `src/yara/master.yar`. Prinsip
yang dipakai:

- **Jangan** buat rule yang match dari 1 API/string tunggal untuk kategori
  high-severity — selalu kombinasikan minimal 2-3 indikator
  (`condition: any of ($key*) and any of ($out*)` atau `N of them`).
- Beri `meta.category` dan `meta.severity` yang konsisten dengan mapping
  di `src/scanner/yaraScanner.js` (`RULE_META`).
- Test rule secara manual sebelum deploy:
  ```bash
  yara -r src/yara/master.yar /path/ke/file/sample
  ```
- Tambahkan file `.yar` baru → daftarkan lewat `include` di `master.yar`.

---

## 15. False-Positive Handling

- Risk Engine (`src/scanner/riskEngine.js`) memisahkan **deteksi** dari
  **verdict** — satu indikator lemah (mis. keyword "password", entropy
  tinggi) tidak pernah otomatis menghasilkan `MALICIOUS`.
- Kombinasi API (mis. `GetAsyncKeyState` + `HttpSendRequest`) diberi bobot
  jauh lebih tinggi daripada API tunggal.
- Admin bisa `/whitelist` hash file yang legitimate tapi ke-flag —
  verdict berikutnya jadi `SAFE` (🟢 TRUSTED), namun detail deteksi tetap
  ditampilkan agar transparan.
- Jika banyak false positive dari rule tertentu, perketat `condition` di
  file `.yar` terkait (tambah jumlah indikator yang harus match bersamaan).

---

## 16. Keterbatasan Keamanan (Baca!)

- Ini adalah **static analysis scanner**, bukan sandbox dinamis. File
  yang sangat well-obfuscated/encrypted secara custom bisa lolos dari
  deteksi string/YARA.
- Parser PE (`src/scanner/peScanner.js`) adalah parser header/section
  ringan buatan sendiri (tanpa dependency eksternal) — cukup untuk
  entropy/section-flag analysis, bukan disassembler penuh.
- ClamAV signature database perlu di-update rutin (`freshclam`) agar tetap
  efektif.
- Bot **tidak pernah** menjalankan/membuka file yang diupload dengan cara
  apa pun (tidak execute EXE/DLL/ASI, tidak load script Lua/Pawn/CS, tidak
  membuka URL yang ditemukan di dalam file).
- Semua file sementara berada di `temp/scans/<scan-id>/` dan dihapus
  otomatis (`finally` block) setelah scan selesai — termasuk saat error.
- Rate limit (`maxScansPerUserPerMinute`, `maxConcurrentScans`) mencegah
  abuse tapi bukan pertahanan DDoS penuh; pertimbangkan reverse proxy /
  firewall tambahan jika bot publik dan besar.

---

## Struktur Project

```
.
├── .env / .env.example
├── config.json
├── index.js
├── package.json
├── README.md
├── Dockerfile
├── logs/
├── temp/scans/<scan-id>/        (dibuat & dihapus otomatis saat runtime)
└── src/
    ├── bot/
    │   ├── commands/            (/setchannel, /scan, /scaninfo, /scanstats, /whitelist, /unwhitelist, /setlogchannel)
    │   ├── events/              (ready, messageCreate, interactionCreate)
    │   ├── registerCommands.js  (registrasi slash command GLOBAL)
    │   └── scanHandler.js       (pipeline bersama: download -> scan -> embed -> log)
    ├── scanner/
    │   ├── scanner.js           (orkestrator utama)
    │   ├── fileValidator.js
    │   ├── hashScanner.js
    │   ├── entropyScanner.js
    │   ├── stringsScanner.js
    │   ├── archiveScanner.js
    │   ├── peScanner.js
    │   ├── yaraScanner.js
    │   ├── clamavScanner.js
    │   ├── riskEngine.js
    │   └── scanQueue.js
    ├── database/
    │   └── database.js          (SQLite: guild_settings, scan_history, detections, whitelist)
    ├── utils/
    │   ├── logger.js
    │   ├── embed.js
    │   ├── cleanup.js
    │   └── rateLimiter.js
    ├── yara/
    │   ├── master.yar
    │   ├── credential_capture.yar
    │   ├── input_capture.yar
    │   ├── webhook_exfiltration.yar
    │   ├── network_exfiltration.yar
    │   ├── process_manipulation.yar
    │   ├── obfuscation.yar
    │   └── samp_specific.yar
    └── data/
        └── scanner.db            (dibuat otomatis saat pertama run)
```
