'use strict';

const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');
const logger = require('../utils/logger');

const DATA_DIR = path.join(__dirname, '..', 'data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const DB_PATH = path.join(DATA_DIR, 'scanner.db');
const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS guild_settings (
  guild_id          TEXT PRIMARY KEY,
  scanner_channel_id TEXT,
  log_channel_id    TEXT,
  updated_at        TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS scan_history (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  guild_id    TEXT NOT NULL,
  user_id     TEXT NOT NULL,
  filename    TEXT NOT NULL,
  sha256      TEXT NOT NULL,
  file_size   INTEGER NOT NULL,
  verdict     TEXT NOT NULL,
  risk_score  INTEGER NOT NULL,
  created_at  TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS detections (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  scan_id     INTEGER NOT NULL REFERENCES scan_history(id) ON DELETE CASCADE,
  file_path   TEXT NOT NULL,
  rule_name   TEXT,
  category    TEXT,
  severity    TEXT,
  description TEXT
);

CREATE TABLE IF NOT EXISTS whitelist (
  sha256      TEXT PRIMARY KEY,
  reason      TEXT,
  admin_id    TEXT NOT NULL,
  created_at  TEXT DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_scan_history_sha256 ON scan_history(sha256);
CREATE INDEX IF NOT EXISTS idx_scan_history_guild ON scan_history(guild_id);
`);

logger.info('Database ready', { path: DB_PATH });

// ---- guild_settings ----

function setScannerChannel(guildId, channelId) {
  db.prepare(
    `INSERT INTO guild_settings (guild_id, scanner_channel_id, updated_at)
     VALUES (?, ?, datetime('now'))
     ON CONFLICT(guild_id) DO UPDATE SET scanner_channel_id = excluded.scanner_channel_id, updated_at = datetime('now')`
  ).run(guildId, channelId);
}

function setLogChannel(guildId, channelId) {
  db.prepare(
    `INSERT INTO guild_settings (guild_id, log_channel_id, updated_at)
     VALUES (?, ?, datetime('now'))
     ON CONFLICT(guild_id) DO UPDATE SET log_channel_id = excluded.log_channel_id, updated_at = datetime('now')`
  ).run(guildId, channelId);
}

function getGuildSettings(guildId) {
  return db.prepare(`SELECT * FROM guild_settings WHERE guild_id = ?`).get(guildId) || null;
}

// ---- scan_history / detections ----

function insertScanRecord({ guildId, userId, filename, sha256, fileSize, verdict, riskScore }) {
  const info = db
    .prepare(
      `INSERT INTO scan_history (guild_id, user_id, filename, sha256, file_size, verdict, risk_score)
       VALUES (?, ?, ?, ?, ?, ?, ?)`
    )
    .run(guildId, userId, filename, sha256, fileSize, verdict, riskScore);
  return info.lastInsertRowid;
}

function insertDetections(scanId, detections) {
  if (!detections || detections.length === 0) return;
  const stmt = db.prepare(
    `INSERT INTO detections (scan_id, file_path, rule_name, category, severity, description)
     VALUES (?, ?, ?, ?, ?, ?)`
  );
  const insertMany = db.transaction((rows) => {
    for (const d of rows) {
      stmt.run(scanId, d.filePath || '', d.rule || null, d.category || null, d.severity || null, d.description || '');
    }
  });
  insertMany(detections);
}

function getScanByHash(sha256) {
  return db.prepare(`SELECT * FROM scan_history WHERE sha256 = ? ORDER BY created_at DESC LIMIT 1`).get(sha256);
}

function getScanStats(guildId) {
  const total = db.prepare(`SELECT COUNT(*) AS c FROM scan_history WHERE guild_id = ?`).get(guildId).c;
  const byVerdict = db
    .prepare(`SELECT verdict, COUNT(*) AS c FROM scan_history WHERE guild_id = ? GROUP BY verdict`)
    .all(guildId);
  const recent = db
    .prepare(`SELECT filename, verdict, risk_score, created_at FROM scan_history WHERE guild_id = ? ORDER BY created_at DESC LIMIT 5`)
    .all(guildId);
  return { total, byVerdict, recent };
}

// ---- whitelist ----

function addWhitelist(sha256, reason, adminId) {
  db.prepare(
    `INSERT INTO whitelist (sha256, reason, admin_id) VALUES (?, ?, ?)
     ON CONFLICT(sha256) DO UPDATE SET reason = excluded.reason, admin_id = excluded.admin_id, created_at = datetime('now')`
  ).run(sha256, reason || null, adminId);
}

function removeWhitelist(sha256) {
  const info = db.prepare(`DELETE FROM whitelist WHERE sha256 = ?`).run(sha256);
  return info.changes > 0;
}

function isWhitelisted(sha256) {
  return !!db.prepare(`SELECT 1 FROM whitelist WHERE sha256 = ?`).get(sha256);
}

module.exports = {
  db,
  setScannerChannel,
  setLogChannel,
  getGuildSettings,
  insertScanRecord,
  insertDetections,
  getScanByHash,
  getScanStats,
  addWhitelist,
  removeWhitelist,
  isWhitelisted,
};
