/*
  Input capture / global hook indicators. Hooking APIs alone are common in
  legitimate SA-MP mod menus (hotkeys) — this rule requires low-level raw
  input capture combined with a persistence/output mechanism to fire.
*/

rule Input_RawCapture_Plus_Persistence
{
    meta:
        description = "Raw input capture API dikombinasikan dengan mekanisme persistence/output"
        category = "input_capture"
        severity = "high"

    strings:
        $hook1 = "SetWindowsHookExA" ascii
        $hook2 = "SetWindowsHookExW" ascii
        $hook3 = "RegisterRawInputDevices" ascii
        $hook4 = "GetRawInputData" ascii

        $persist1 = "CurrentVersion\\Run" ascii wide
        $persist2 = "schtasks" nocase ascii
        $persist3 = "CreateFileA" ascii
        $persist4 = "CreateFileW" ascii

    condition:
        any of ($hook*) and any of ($persist*)
}
