/*
  Discord webhook detection. A bare webhook URL is NOT malware by itself
  (many legitimate SA-MP tools log to Discord) — severity only escalates
  when combined with credential/input capture APIs.
*/

rule Webhook_URL_Present
{
    meta:
        description = "Discord webhook URL ditemukan dalam file - indikator saja, bukan bukti malware"
        category = "webhook_exfiltration"
        severity = "low"

    strings:
        $w1 = "discord.com/api/webhooks/" ascii
        $w2 = "discordapp.com/api/webhooks/" ascii

    condition:
        any of them
}

rule Webhook_Plus_Credential_Capture
{
    meta:
        description = "Webhook Discord dikombinasikan dengan API credential/input capture - indikasi kuat data exfiltration"
        category = "webhook_exfiltration"
        severity = "high"

    strings:
        $w1 = "discord.com/api/webhooks/" ascii
        $w2 = "discordapp.com/api/webhooks/" ascii

        $c1 = "GetAsyncKeyState" ascii
        $c2 = "GetKeyboardState" ascii
        $c3 = "password" nocase ascii wide
        $c4 = "steam_appid" ascii
        $c5 = "HttpSendRequest" ascii

    condition:
        any of ($w*) and any of ($c*)
}
