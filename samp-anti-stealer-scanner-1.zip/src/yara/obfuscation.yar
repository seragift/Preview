/*
  Packing/obfuscation indicators — common packer section names and known
  packer strings. Informational: contributes a small score only.
*/

rule Known_Packer_Sections
{
    meta:
        description = "Nama section umum untuk packer/protector dikenal"
        category = "obfuscation"
        severity = "low"

    strings:
        $s1 = ".upx0" ascii
        $s2 = ".upx1" ascii
        $s3 = ".aspack" ascii
        $s4 = ".vmp0" ascii
        $s5 = ".vmp1" ascii
        $s6 = "Themida" ascii
        $s7 = "VMProtect" ascii
        $s8 = "UPX!" ascii

    condition:
        any of them
}

rule Long_Encoded_Blob
{
    meta:
        description = "String base64/hex yang sangat panjang - indikasi payload terenkode"
        category = "obfuscation"
        severity = "low"

    strings:
        $b64 = /[A-Za-z0-9+\/]{120,}={0,2}/
        $hex = /[0-9A-Fa-f]{160,}/

    condition:
        any of them
}
