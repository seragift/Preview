/*
  Suspicious networking indicators — static string presence of low-level
  HTTP/socket APIs. Common in legitimate updaters too, so this only scores
  meaningfully when correlated with other categories in the risk engine.
*/

rule Network_API_Cluster
{
    meta:
        description = "Kombinasi beberapa API networking low-level dalam satu file"
        category = "network_exfiltration"
        severity = "medium"

    strings:
        $n1 = "WinHttpOpen" ascii
        $n2 = "WinHttpConnect" ascii
        $n3 = "InternetOpenA" ascii
        $n4 = "InternetOpenW" ascii
        $n5 = "URLDownloadToFileA" ascii
        $n6 = "URLDownloadToFileW" ascii
        $n7 = "HttpSendRequestA" ascii
        $n8 = "WSAStartup" ascii

    condition:
        3 of them
}
