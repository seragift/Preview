/*
  Credential capture indicators — requires a COMBINATION of a
  keyboard/input hooking API together with credential-related strings or
  an output primitive. A single API string is never enough on its own.
*/

rule Credential_Keylog_Plus_Output
{
    meta:
        description = "Kombinasi API input-capture dengan file/network write - indikasi credential/keylog exfiltration"
        category = "credential_capture"
        severity = "high"

    strings:
        $key1 = "GetAsyncKeyState" ascii
        $key2 = "GetKeyState" ascii
        $key3 = "GetKeyboardState" ascii
        $key4 = "SetWindowsHookExA" ascii
        $key5 = "SetWindowsHookExW" ascii

        $out1 = "WriteFile" ascii
        $out2 = "HttpSendRequest" ascii
        $out3 = "InternetConnect" ascii
        $out4 = "WinHttpSendRequest" ascii
        $out5 = "URLDownloadToFile" ascii

    condition:
        any of ($key*) and any of ($out*)
}

rule Credential_String_Cluster
{
    meta:
        description = "Kumpulan string terkait credential dalam jumlah signifikan di satu file - indikasi lemah, hanya nudge score kecil"
        category = "credential_capture"
        severity = "low"

    strings:
        $c1 = "password" nocase ascii wide
        $c2 = "username" nocase ascii wide
        $c3 = "login" nocase ascii wide
        $c4 = "steam_appid" nocase ascii
        $c5 = "discord_token" nocase ascii wide
        $c6 = "session_token" nocase ascii wide

    condition:
        3 of them
}
