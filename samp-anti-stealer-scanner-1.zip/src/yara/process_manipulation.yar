/*
  Process injection indicators — requires at least 2-3 APIs from the
  classic injection chain together, never a single API alone.
*/

rule Process_Injection_Chain
{
    meta:
        description = "Kombinasi API classic process-injection chain (OpenProcess/VirtualAllocEx/WriteProcessMemory/CreateRemoteThread)"
        category = "process_manipulation"
        severity = "high"

    strings:
        $p1 = "OpenProcess" ascii
        $p2 = "VirtualAllocEx" ascii
        $p3 = "WriteProcessMemory" ascii
        $p4 = "CreateRemoteThread" ascii
        $p5 = "NtWriteVirtualMemory" ascii
        $p6 = "NtCreateThreadEx" ascii

    condition:
        3 of them
}
