/*
  Master YARA index — SA-MP Anti-Stealer / Modpack Security Scanner
  Semua rule di sini bersifat DEFENSIF: hanya melakukan pattern matching
  read-only terhadap byte file untuk MENDETEKSI indikasi stealer/keylogger/
  exfiltration. Tidak ada rule yang mengeksekusi, memodifikasi, atau
  mereplikasi apa pun.
*/

include "credential_capture.yar"
include "input_capture.yar"
include "webhook_exfiltration.yar"
include "network_exfiltration.yar"
include "process_manipulation.yar"
include "obfuscation.yar"
include "samp_specific.yar"
