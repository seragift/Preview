/*
  SA-MP/GTA:SA ecosystem markers (CLEO/MoonLoader/SAMPFUNCS/modloader).
  Purely informational on their own — used mainly for the SA-MP-specific
  structural analysis layer, not as malware evidence.
*/

rule SAMP_Loader_Markers
{
    meta:
        description = "Marker loader/plugin ekosistem SA-MP terdeteksi (informational)"
        category = "samp_specific"
        severity = "low"

    strings:
        $m1 = "CLEO" ascii
        $m2 = "MoonLoader" ascii
        $m3 = "SAMPFUNCS" ascii
        $m4 = "modloader" nocase ascii
        $m5 = "samp.dll" nocase ascii
        $m6 = "SA-MP" ascii

    condition:
        any of them
}

rule SAMP_Plugin_With_Credential_Capture
{
    meta:
        description = "File dalam konteks plugin SA-MP (.asi) dengan indikasi credential capture - severity tinggi karena target langsung ke akun game"
        category = "samp_specific"
        severity = "high"

    strings:
        $samp1 = "SAMPFUNCS" ascii
        $samp2 = "samp.dll" nocase ascii
        $samp3 = "CGameSA" ascii

        $cred1 = "GetAsyncKeyState" ascii
        $cred2 = "password" nocase ascii wide
        $cred3 = "discord.com/api/webhooks/" ascii

    condition:
        any of ($samp*) and any of ($cred*)
}
