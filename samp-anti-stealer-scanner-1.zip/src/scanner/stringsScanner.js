'use strict';

const { calculateEntropy } = require('./entropyScanner');

const MIN_STRING_LEN = 5;

// ---- Indicator dictionaries (static pattern lists — used only for read-only detection) ----

const KEYLOG_INPUT_APIS = [
  'GetAsyncKeyState',
  'GetKeyState',
  'GetKeyboardState',
  'SetWindowsHookExA',
  'SetWindowsHookExW',
  'RegisterRawInputDevices',
];

const NETWORK_APIS = [
  'WinHttpOpen',
  'WinHttpConnect',
  'WinHttpSendRequest',
  'HttpSendRequestA',
  'HttpSendRequestW',
  'InternetOpenA',
  'InternetOpenW',
  'InternetConnectA',
  'InternetConnectW',
  'URLDownloadToFileA',
  'URLDownloadToFileW',
  'WSAStartup',
  'connect',
  'send',
];

const PROCESS_INJECTION_APIS = [
  'OpenProcess',
  'VirtualAllocEx',
  'WriteProcessMemory',
  'CreateRemoteThread',
  'NtWriteVirtualMemory',
  'NtCreateThreadEx',
];

const FILE_WRITE_APIS = ['WriteFile', 'CreateFileA', 'CreateFileW', 'fopen', 'fwrite'];

const CREDENTIAL_KEYWORDS = [
  'username',
  'password',
  'passwd',
  'login',
  'account',
  'credential',
  'token',
  'session',
  'cookie',
  'auth',
  'serial',
  // "key" is deliberately excluded from the standalone list — far too common
  // in legitimate code (hotkey, key bind, dictionary key). It only counts
  // combined with other stronger signals elsewhere.
];

const SAMP_INDICATORS = ['CLEO', 'MoonLoader', 'SAMPFUNCS', 'modloader', 'samp.dll', 'GTA San Andreas', 'SA-MP'];

const WEBHOOK_PATTERN = /(discord(?:app)?\.com\/api\/webhooks\/\d+\/[A-Za-z0-9_-]+)/gi;
const URL_PATTERN = /\bhttps?:\/\/[^\s"'<>]{4,}/gi;
const IP_PATTERN = /\b(?:\d{1,3}\.){3}\d{1,3}\b/g;
const DOMAIN_PATTERN = /\b[a-z0-9-]+(?:\.[a-z0-9-]+)+\.(?:com|net|org|io|xyz|ru|cc|gg|tk|club|top|info)\b/gi;
const BASE64_BLOB_PATTERN = /[A-Za-z0-9+/]{60,}={0,2}/g;
const HEX_BLOB_PATTERN = /(?:0x)?[0-9A-Fa-f]{80,}/g;

/**
 * Extract printable ASCII/UTF-16LE-ish strings from a buffer (like the `strings` tool).
 */
function extractStrings(buffer, minLen = MIN_STRING_LEN) {
  const strings = [];
  let current = '';

  const pushIfLongEnough = () => {
    if (current.length >= minLen) strings.push(current);
    current = '';
  };

  for (let i = 0; i < buffer.length; i++) {
    const byte = buffer[i];
    const isPrintable = byte >= 0x20 && byte <= 0x7e;
    if (isPrintable) {
      current += String.fromCharCode(byte);
    } else {
      pushIfLongEnough();
    }
  }
  pushIfLongEnough();

  return strings;
}

function redactWebhook(url) {
  return url.replace(/(webhooks\/\d+\/)([A-Za-z0-9_-]+)/i, '$1REDACTED');
}

function findMatches(text, apiList) {
  const found = new Set();
  for (const api of apiList) {
    // word-boundary-ish match so we don't match substrings inside unrelated identifiers
    const re = new RegExp(`(?<![A-Za-z0-9_])${api}(?![A-Za-z0-9_])`);
    if (re.test(text)) found.add(api);
  }
  return [...found];
}

/**
 * Run the full string/IOC pass over a buffer. Returns raw signal counts;
 * riskEngine decides how these combine into a verdict.
 */
function scanBuffer(buffer, relativePath = '') {
  const strings = extractStrings(buffer);
  const joined = strings.join('\n');

  const keylogApis = findMatches(joined, KEYLOG_INPUT_APIS);
  const networkApis = findMatches(joined, NETWORK_APIS);
  const injectionApis = findMatches(joined, PROCESS_INJECTION_APIS);
  const fileWriteApis = findMatches(joined, FILE_WRITE_APIS);

  const credentialKeywordsFound = new Set();
  const lowerJoined = joined.toLowerCase();
  for (const kw of CREDENTIAL_KEYWORDS) {
    if (lowerJoined.includes(kw)) credentialKeywordsFound.add(kw);
  }

  const webhookMatches = [...new Set((joined.match(WEBHOOK_PATTERN) || []).map(redactWebhook))];
  const urlMatches = [...new Set((joined.match(URL_PATTERN) || []).filter((u) => !/discord(?:app)?\.com\/api\/webhooks/i.test(u)))];
  const ipMatches = [...new Set(joined.match(IP_PATTERN) || [])];
  const domainMatches = [...new Set(joined.match(DOMAIN_PATTERN) || [])].filter(
    (d) => !urlMatches.some((u) => u.includes(d))
  );

  const sampIndicators = findMatches(joined, SAMP_INDICATORS);

  // Obfuscation heuristics
  const longBase64Blobs = (joined.match(BASE64_BLOB_PATTERN) || []).length;
  const longHexBlobs = (joined.match(HEX_BLOB_PATTERN) || []).length;
  const printableRatio = buffer.length > 0 ? strings.join('').length / buffer.length : 1;
  const entropy = calculateEntropy(buffer);

  const obfuscationSignals = [];
  if (longBase64Blobs > 0) obfuscationSignals.push(`${longBase64Blobs} long base64-like blob(s)`);
  if (longHexBlobs > 0) obfuscationSignals.push(`${longHexBlobs} long hex blob(s)`);
  if (printableRatio < 0.15 && buffer.length > 2048) obfuscationSignals.push('very low printable-string ratio');
  if (entropy >= 7.5) obfuscationSignals.push('very high overall entropy');

  return {
    relativePath,
    keylogApis,
    networkApis,
    injectionApis,
    fileWriteApis,
    credentialKeywordsFound: [...credentialKeywordsFound],
    webhookMatches,
    urlMatches: urlMatches.slice(0, 10),
    ipMatches: ipMatches.slice(0, 10),
    domainMatches: domainMatches.slice(0, 10),
    sampIndicators,
    obfuscationSignals,
    printableRatio,
    entropy,
  };
}

module.exports = {
  scanBuffer,
  extractStrings,
  redactWebhook,
  KEYLOG_INPUT_APIS,
  NETWORK_APIS,
  PROCESS_INJECTION_APIS,
  FILE_WRITE_APIS,
  CREDENTIAL_KEYWORDS,
  SAMP_INDICATORS,
};
