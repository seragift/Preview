'use strict';

const SCORES = {
  KNOWN_MALICIOUS_HASH: 100,
  YARA_MALICIOUS_MATCH: 100,
  CREDENTIAL_CAPTURE_COMBO: 25, // keylog/input API + file or network write
  WEBHOOK_PLUS_CREDENTIAL: 30, // webhook found alongside credential-capture combo
  SUSPICIOUS_NETWORK: 10,
  PROCESS_INJECTION_COMBO: 25, // 2+ injection-related APIs together
  CREDENTIAL_KEYWORDS: 3, // small nudge only — keywords alone are weak
  OBFUSCATION: 5,
  HIGH_ENTROPY: 3,
  PACKED_PE: 5,
  SUSPICIOUS_DOMAIN: 15,
  DATA_EXFIL_CORRELATION: 20, // keylog + write + network, the strongest static behavior pattern
};

function verdictFromScore(score, forcedMalicious) {
  if (forcedMalicious) return 'MALICIOUS';
  if (score >= 100) return 'MALICIOUS';
  if (score >= 50) return 'HIGH_RISK';
  if (score >= 20) return 'SUSPICIOUS';
  return 'SAFE';
}

/**
 * Combine every static signal collected for ONE file into a single score +
 * a human-readable detection list. Designed to avoid double-counting the
 * same underlying evidence twice (e.g. a keylog API contributes to the
 * combo score, not additionally as a lone "keylog API found" line item).
 */
function evaluateFile({ stringsResult, peResult, yaraMatches = [], clamavHits = [], knownMaliciousHash = false }) {
  let score = 0;
  const detections = [];
  let forcedMalicious = knownMaliciousHash;

  if (knownMaliciousHash) {
    score += SCORES.KNOWN_MALICIOUS_HASH;
    detections.push({
      category: 'Known Malicious Hash',
      severity: 'high',
      description: 'SHA-256 file ini cocok dengan hash malicious yang sudah diketahui sebelumnya.',
    });
  }

  for (const m of yaraMatches) {
    score += SCORES.YARA_MALICIOUS_MATCH;
    forcedMalicious = true;
    detections.push({
      category: `YARA: ${m.rule}`,
      severity: 'high',
      description: `Rule YARA "${m.rule}" (${m.category}) cocok.`,
      rule: m.rule,
    });
  }

  for (const c of clamavHits) {
    score += SCORES.KNOWN_MALICIOUS_HASH;
    forcedMalicious = true;
    detections.push({
      category: 'ClamAV Detection',
      severity: 'high',
      description: `ClamAV mendeteksi signature: ${c.signature}`,
    });
  }

  if (stringsResult) {
    const {
      keylogApis = [],
      networkApis = [],
      injectionApis = [],
      fileWriteApis = [],
      credentialKeywordsFound = [],
      webhookMatches = [],
      domainMatches = [],
      obfuscationSignals = [],
      entropy = 0,
    } = stringsResult;

    const hasKeylog = keylogApis.length > 0;
    const hasNetwork = networkApis.length > 0;
    const hasWrite = fileWriteApis.length > 0;
    const hasInjection = injectionApis.length >= 2;
    const hasWebhook = webhookMatches.length > 0;

    // Data exfiltration correlation: keylog/input + write + network together
    // is the strongest static behavior signal — score it once, at the top tier.
    if (hasKeylog && hasWrite && hasNetwork) {
      score += SCORES.DATA_EXFIL_CORRELATION;
      detections.push({
        category: 'Data Exfiltration Pattern',
        severity: 'high',
        description: `Kombinasi input capture (${keylogApis.join(', ')}) + file write + network API (${networkApis.join(', ')}) — pola khas exfiltration.`,
      });
    } else if (hasKeylog && (hasWrite || hasNetwork)) {
      // Weaker but still notable combo (credential capture combo)
      score += SCORES.CREDENTIAL_CAPTURE_COMBO;
      detections.push({
        category: 'Credential Capture',
        severity: 'high',
        description: `Kombinasi API input capture (${keylogApis.join(', ')}) dengan ${hasWrite ? 'file write' : 'network API'}.`,
      });
    } else if (hasKeylog) {
      // Keyboard API alone — legitimate in many SA-MP mods/plugins (hotkeys).
      // Do not treat as evidence by itself; no score, informational only.
      detections.push({
        category: 'Input API (informational)',
        severity: 'low',
        description: `API keyboard terdeteksi (${keylogApis.join(', ')}) tanpa indikasi output data — umum dipakai untuk hotkey/keybind legitimate.`,
      });
    }

    if (hasWebhook) {
      if (hasKeylog) {
        score += SCORES.WEBHOOK_PLUS_CREDENTIAL;
        detections.push({
          category: 'Discord Webhook',
          severity: 'high',
          description: `Webhook Discord terdeteksi (${webhookMatches[0]}) dikombinasikan dengan input capture — indikasi kuat exfiltration.`,
        });
      } else {
        detections.push({
          category: 'Discord Webhook',
          severity: 'medium',
          description: `Webhook Discord terdeteksi: ${webhookMatches[0]}. Webhook saja bukan bukti malware — hanya indikator.`,
        });
      }
    }

    if (hasInjection) {
      score += SCORES.PROCESS_INJECTION_COMBO;
      detections.push({
        category: 'Process Manipulation',
        severity: 'high',
        description: `Kombinasi API process injection terdeteksi: ${injectionApis.join(', ')}.`,
      });
    }

    if (!hasKeylog && hasNetwork) {
      score += SCORES.SUSPICIOUS_NETWORK;
      detections.push({
        category: 'Network Activity',
        severity: 'medium',
        description: `API networking terdeteksi: ${networkApis.join(', ')}.`,
      });
    }

    if (domainMatches.length > 0) {
      score += SCORES.SUSPICIOUS_DOMAIN;
      detections.push({
        category: 'External Domain',
        severity: 'medium',
        description: `Domain eksternal ditemukan dalam string: ${domainMatches.slice(0, 3).join(', ')}.`,
      });
    }

    if (credentialKeywordsFound.length > 0) {
      score += SCORES.CREDENTIAL_KEYWORDS;
      detections.push({
        category: 'Credential Keywords',
        severity: 'low',
        description: `Kata kunci terkait credential ditemukan: ${credentialKeywordsFound.slice(0, 5).join(', ')} (hanya indikasi lemah).`,
      });
    }

    if (obfuscationSignals.length > 0) {
      score += SCORES.OBFUSCATION;
      detections.push({
        category: 'Obfuscation',
        severity: 'low',
        description: `Indikasi obfuscation: ${obfuscationSignals.join('; ')}.`,
      });
    } else if (entropy >= 7.5) {
      score += SCORES.HIGH_ENTROPY;
      detections.push({
        category: 'High Entropy',
        severity: 'low',
        description: `Entropy keseluruhan file tinggi (${entropy.toFixed(2)}/8) — bisa jadi compressed/encrypted, bukan pasti malware.`,
      });
    }
  }

  if (peResult && peResult.isValidPE) {
    if (peResult.executableWritableSections.length > 0) {
      score += SCORES.PROCESS_INJECTION_COMBO;
      detections.push({
        category: 'Process Manipulation',
        severity: 'high',
        description: `Section executable+writable ditemukan: ${peResult.executableWritableSections.join(', ')} — pola umum shellcode/self-modifying code.`,
      });
    }
    if (peResult.packedIndicator) {
      score += SCORES.PACKED_PE;
      detections.push({
        category: 'Obfuscation',
        severity: 'low',
        description: `Indikasi packing pada PE: ${peResult.suspiciousSectionNames.join(', ') || 'high-entropy sections'}.`,
      });
    }
  }

  const verdict = verdictFromScore(score, forcedMalicious);
  return { score, verdict, detections };
}

module.exports = { evaluateFile, verdictFromScore, SCORES };
