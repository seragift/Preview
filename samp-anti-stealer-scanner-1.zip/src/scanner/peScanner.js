'use strict';

const fs = require('fs/promises');
const { calculateEntropy, classifyEntropy } = require('./entropyScanner');

const IMAGE_SCN_MEM_EXECUTE = 0x20000000;
const IMAGE_SCN_MEM_WRITE = 0x80000000;

const SUSPICIOUS_SECTION_NAMES = new Set([
  '.upx0', '.upx1', '.upx2', '.aspack', '.adata', '.packed', '.enigma1', '.enigma2',
  '.themida', '.vmp0', '.vmp1', '.mpress1', '.mpress2', '.petite',
]);

function readCString(buffer, offset, maxLen = 8) {
  let end = offset;
  while (end < buffer.length && end < offset + maxLen && buffer[end] !== 0x00) end++;
  return buffer.toString('ascii', offset, end);
}

/**
 * Minimal, read-only PE (Portable Executable) header parser.
 * Only inspects headers/sections as data — never loads, links, or executes
 * anything from the file.
 */
async function analyzePE(filePath) {
  const buffer = await fs.readFile(filePath);
  const result = {
    isValidPE: false,
    machine: null,
    numberOfSections: 0,
    timestamp: null,
    entryPointRVA: null,
    sections: [],
    suspiciousSectionNames: [],
    executableWritableSections: [],
    highEntropySections: [],
    packedIndicator: false,
    error: null,
  };

  try {
    if (buffer.length < 0x40 || buffer.readUInt16LE(0) !== 0x5a4d) {
      result.error = 'Bukan file MZ/PE yang valid.';
      return result;
    }

    const peOffset = buffer.readUInt32LE(0x3c);
    if (peOffset + 24 > buffer.length || buffer.readUInt32LE(peOffset) !== 0x00004550) {
      result.error = 'PE header signature tidak ditemukan.';
      return result;
    }

    const coffOffset = peOffset + 4;
    result.machine = buffer.readUInt16LE(coffOffset).toString(16);
    result.numberOfSections = buffer.readUInt16LE(coffOffset + 2);
    result.timestamp = buffer.readUInt32LE(coffOffset + 4);
    const sizeOfOptionalHeader = buffer.readUInt16LE(coffOffset + 16);

    const optHeaderOffset = coffOffset + 20;
    if (sizeOfOptionalHeader >= 4) {
      const magic = buffer.readUInt16LE(optHeaderOffset);
      const isPE32Plus = magic === 0x20b;
      const entryPointOffset = optHeaderOffset + 16;
      if (entryPointOffset + 4 <= buffer.length) {
        result.entryPointRVA = buffer.readUInt32LE(entryPointOffset);
      }
      result.imageType = isPE32Plus ? 'PE32+' : 'PE32';
    }

    const sectionTableOffset = optHeaderOffset + sizeOfOptionalHeader;
    const SECTION_HEADER_SIZE = 40;

    for (let i = 0; i < result.numberOfSections; i++) {
      const base = sectionTableOffset + i * SECTION_HEADER_SIZE;
      if (base + SECTION_HEADER_SIZE > buffer.length) break;

      const name = readCString(buffer, base, 8).replace(/\0+$/, '') || `(unnamed_${i})`;
      const virtualSize = buffer.readUInt32LE(base + 8);
      const rawSize = buffer.readUInt32LE(base + 16);
      const rawPtr = buffer.readUInt32LE(base + 20);
      const characteristics = buffer.readUInt32LE(base + 36);

      const isExecutable = (characteristics & IMAGE_SCN_MEM_EXECUTE) !== 0;
      const isWritable = (characteristics & IMAGE_SCN_MEM_WRITE) !== 0;

      let entropy = 0;
      if (rawSize > 0 && rawPtr + rawSize <= buffer.length) {
        const sectionBuf = buffer.subarray(rawPtr, rawPtr + Math.min(rawSize, 4 * 1024 * 1024));
        entropy = calculateEntropy(sectionBuf);
      }

      const section = {
        name,
        virtualSize,
        rawSize,
        isExecutable,
        isWritable,
        entropy: Number(entropy.toFixed(2)),
        entropyClass: classifyEntropy(entropy),
      };
      result.sections.push(section);

      if (SUSPICIOUS_SECTION_NAMES.has(name.toLowerCase())) {
        result.suspiciousSectionNames.push(name);
      }
      if (isExecutable && isWritable) {
        result.executableWritableSections.push(name);
      }
      if (entropy >= 7.5) {
        result.highEntropySections.push(name);
      }
    }

    result.packedIndicator =
      result.suspiciousSectionNames.length > 0 ||
      (result.highEntropySections.length >= Math.max(1, Math.ceil(result.sections.length * 0.5)) &&
        result.sections.length > 0);

    result.isValidPE = true;
  } catch (err) {
    result.error = `Gagal parsing PE: ${err.message}`;
  }

  return result;
}

module.exports = { analyzePE };
