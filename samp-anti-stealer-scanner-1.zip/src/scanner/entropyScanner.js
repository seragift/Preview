'use strict';

/**
 * Shannon entropy (bits per byte, 0-8) of a buffer.
 * High entropy (>7.2) is *suggestive* of packing/encryption/compression —
 * never treated as proof of malware on its own (see riskEngine).
 */
function calculateEntropy(buffer) {
  if (!buffer || buffer.length === 0) return 0;

  const freq = new Array(256).fill(0);
  for (let i = 0; i < buffer.length; i++) {
    freq[buffer[i]]++;
  }

  let entropy = 0;
  const len = buffer.length;
  for (let i = 0; i < 256; i++) {
    if (freq[i] === 0) continue;
    const p = freq[i] / len;
    entropy -= p * Math.log2(p);
  }
  return entropy;
}

function classifyEntropy(entropy) {
  if (entropy >= 7.5) return 'very_high';
  if (entropy >= 6.8) return 'high';
  if (entropy >= 4.5) return 'medium';
  return 'low';
}

module.exports = { calculateEntropy, classifyEntropy };
