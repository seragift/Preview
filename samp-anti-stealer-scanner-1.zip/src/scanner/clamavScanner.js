'use strict';

const { execFile } = require('child_process');
const logger = require('../utils/logger');

function checkAvailable(clamavBinary = 'clamscan') {
  return new Promise((resolve) => {
    execFile(clamavBinary, ['--version'], { timeout: 5000 }, (err) => resolve(!err));
  });
}

/**
 * Run ClamAV as an additional read-only detection layer.
 * If unavailable or it errors, the rest of the scanner keeps working —
 * ClamAV is a bonus signal, never a hard dependency.
 */
function runClamAV(targetPath, config) {
  return new Promise((resolve) => {
    const bin = config.clamavBinary || 'clamscan';
    const args = ['-r', '--no-summary', '--infected', targetPath];

    execFile(
      bin,
      args,
      { timeout: (config.scanTimeoutSeconds || 60) * 1000, maxBuffer: 1024 * 1024 * 10 },
      (err, stdout, stderr) => {
        if (err && err.code === 'ENOENT') {
          return resolve({ available: false, error: 'ClamAV binary tidak ditemukan', infected: [] });
        }
        if (err && err.killed) {
          return resolve({ available: true, error: 'ClamAV timeout', infected: [] });
        }
        // clamscan exit code 1 = infected files found (not a real "error")
        if (err && err.code !== 1) {
          logger.warn('clamav: run reported error', { stderr: stderr || err.message });
          return resolve({ available: true, error: stderr || err.message, infected: [] });
        }

        const infected = [];
        const lines = (stdout || '').split('\n').filter(Boolean);
        for (const line of lines) {
          const match = line.match(/^(.+): (.+) FOUND$/);
          if (match) {
            infected.push({ file: match[1], signature: match[2] });
          }
        }

        resolve({ available: true, error: null, infected });
      }
    );
  });
}

module.exports = { runClamAV, checkAvailable };
