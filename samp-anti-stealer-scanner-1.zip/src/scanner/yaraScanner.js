'use strict';

const path = require('path');
const { execFile } = require('child_process');
const logger = require('../utils/logger');

const YARA_RULES_PATH = path.join(__dirname, '..', 'yara', 'master.yar');

// Map rule name prefixes to category/severity for consistent embed output.
const RULE_META = {
  Credential: { category: 'credential_capture', severity: 'high' },
  InputCapture: { category: 'input_capture', severity: 'high' },
  Webhook: { category: 'webhook_exfiltration', severity: 'medium' },
  Network: { category: 'network_exfiltration', severity: 'medium' },
  Process: { category: 'process_manipulation', severity: 'high' },
  Obfuscation: { category: 'obfuscation', severity: 'low' },
  SAMP: { category: 'samp_specific', severity: 'medium' },
};

function metaForRule(ruleName) {
  for (const prefix of Object.keys(RULE_META)) {
    if (ruleName.toLowerCase().includes(prefix.toLowerCase())) return RULE_META[prefix];
  }
  return { category: 'generic', severity: 'medium' };
}

/**
 * Check whether the `yara` binary is available on this system.
 */
function checkAvailable(yaraBinary = 'yara') {
  return new Promise((resolve) => {
    execFile(yaraBinary, ['--version'], { timeout: 5000 }, (err) => resolve(!err));
  });
}

/**
 * Run YARA rules against a single file or directory.
 * Never executes anything from the target — YARA performs read-only pattern
 * matching against file bytes.
 */
function runYara(targetPath, config) {
  return new Promise((resolve) => {
    const yaraBinary = config.yaraBinary || 'yara';
    const args = ['-r', '-w', YARA_RULES_PATH, targetPath];

    execFile(
      yaraBinary,
      args,
      { timeout: (config.scanTimeoutSeconds || 60) * 1000, maxBuffer: 1024 * 1024 * 10 },
      (err, stdout, stderr) => {
        if (err && err.killed) {
          return resolve({ available: true, error: 'YARA timeout', matches: [] });
        }
        if (err && err.code === 'ENOENT') {
          return resolve({ available: false, error: 'YARA binary tidak ditemukan', matches: [] });
        }
        // Non-zero exit without stdout usually means a rule/compile error, not "no match".
        if (err && !stdout) {
          logger.warn('yara: run reported error', { stderr: stderr || err.message });
          return resolve({ available: true, error: stderr || err.message, matches: [] });
        }

        const matches = [];
        const lines = (stdout || '').split('\n').filter(Boolean);
        for (const line of lines) {
          // Default yara output format: "<rule_name> <file_path>"
          const spaceIdx = line.indexOf(' ');
          if (spaceIdx === -1) continue;
          const ruleName = line.slice(0, spaceIdx);
          const filePath = line.slice(spaceIdx + 1).trim();
          const meta = metaForRule(ruleName);
          matches.push({
            rule: ruleName,
            file: filePath,
            category: meta.category,
            severity: meta.severity,
          });
        }

        resolve({ available: true, error: null, matches });
      }
    );
  });
}

module.exports = { runYara, checkAvailable, YARA_RULES_PATH };
