'use strict';

const crypto = require('crypto');
const fs = require('fs');

/**
 * Compute SHA-256 of a file via stream so large files never load fully into RAM.
 */
function sha256File(filePath) {
  return new Promise((resolve, reject) => {
    const hash = crypto.createHash('sha256');
    const stream = fs.createReadStream(filePath);
    stream.on('data', (chunk) => hash.update(chunk));
    stream.on('end', () => resolve(hash.digest('hex')));
    stream.on('error', reject);
  });
}

module.exports = { sha256File };
