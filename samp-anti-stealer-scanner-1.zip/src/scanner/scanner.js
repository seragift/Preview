'use strict';

const path = require('path');
const fs = require('fs/promises');
const crypto = require('crypto');

const { validateFile } = require('./fileValidator');
const { sha256File } = require('./hashScanner');
const { scanBuffer } = require('./stringsScanner');
const { analyzePE } = require('./peScanner');
const { extractArchive, listFilesRecursive } = require('./archiveScanner');
const { runYara, checkAvailable: yaraAvailable } = require('./yaraScanner');
const { runClamAV, checkAvailable: clamavAvailable } = require('./clamavScanner');
const { evaluateFile } = require('./riskEngine');
const { createScanDir, cleanupScanDir } = require('../utils/cleanup');
const { isWhitelisted, getScanByHash } = require('../database/database');
const logger = require('../utils/logger');

function newScanId() {
  return crypto.randomBytes(8).toString('hex');
}

function formatBytes(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

/**
 * Read a bounded chunk of a file for string/entropy analysis without
 * loading arbitrarily huge files fully into memory.
 */
async function readForAnalysis(filePath, maxBytes = 25 * 1024 * 1024) {
  const stat = await fs.stat(filePath);
  const size = Math.min(stat.size, maxBytes);
  const fh = await fs.open(filePath, 'r');
  const buffer = Buffer.alloc(size);
  await fh.read(buffer, 0, size, 0);
  await fh.close();
  return buffer;
}

/**
 * Run every static analysis component against ONE file on disk.
 * Every component is wrapped so a single failure never crashes the scan.
 */
async function analyzeSingleFile(filePath, relativePath, validation, config, componentErrors) {
  let stringsResult = null;
  let peResult = null;
  let yaraMatches = [];
  let clamavHits = [];

  try {
    const buffer = await readForAnalysis(filePath);
    stringsResult = scanBuffer(buffer, relativePath);
  } catch (err) {
    componentErrors.push(`String/IOC scanner gagal pada ${relativePath}: ${err.message}`);
  }

  if (config.peAnalysisEnabled && validation.isExecutable) {
    try {
      peResult = await analyzePE(filePath);
    } catch (err) {
      componentErrors.push(`PE scanner gagal pada ${relativePath}: ${err.message}`);
    }
  }

  if (config.yaraEnabled) {
    try {
      const yaraResult = await runYara(filePath, config);
      if (!yaraResult.available) {
        componentErrors.push('YARA tidak tersedia di sistem ini.');
      } else if (yaraResult.error) {
        componentErrors.push(`YARA error: ${yaraResult.error}`);
      } else {
        yaraMatches = yaraResult.matches;
      }
    } catch (err) {
      componentErrors.push(`YARA scanner gagal: ${err.message}`);
    }
  }

  if (config.clamavEnabled) {
    try {
      const clamResult = await runClamAV(filePath, config);
      if (!clamResult.available) {
        componentErrors.push('ClamAV tidak tersedia di sistem ini.');
      } else if (clamResult.error) {
        componentErrors.push(`ClamAV error: ${clamResult.error}`);
      } else {
        clamavHits = clamResult.infected;
      }
    } catch (err) {
      componentErrors.push(`ClamAV scanner gagal: ${err.message}`);
    }
  }

  return { stringsResult, peResult, yaraMatches, clamavHits };
}

/**
 * Full scan pipeline for a single uploaded file (non-archive, or one file
 * extracted from within an archive).
 */
async function scanSingleFile({ filePath, filename, config }) {
  const componentErrors = [];
  const validation = await validateFile(filePath, filename, config);

  if (!validation.ok) {
    return {
      filename,
      sizeLabel: formatBytes(validation.size || 0),
      sha256: 'N/A',
      verdict: 'ERROR',
      riskScore: 0,
      detections: [],
      componentErrors: validation.issues,
      durationSeconds: '0.00',
      rejected: true,
    };
  }

  const start = Date.now();
  const sha256 = await sha256File(filePath);

  const whitelisted = isWhitelisted(sha256);
  const priorScan = getScanByHash(sha256);
  const knownMaliciousHash = !whitelisted && priorScan && priorScan.verdict === 'MALICIOUS';

  const { stringsResult, peResult, yaraMatches, clamavHits } = await analyzeSingleFile(
    filePath,
    filename,
    validation,
    config,
    componentErrors
  );

  if (validation.extensionMismatch) {
    componentErrors.push(...validation.issues);
  }

  const { score, verdict, detections } = evaluateFile({
    stringsResult,
    peResult,
    yaraMatches,
    clamavHits,
    knownMaliciousHash,
  });

  const finalVerdict = whitelisted && verdict !== 'MALICIOUS' ? 'SAFE' : verdict;

  const durationSeconds = ((Date.now() - start) / 1000).toFixed(2);

  return {
    filename,
    sizeLabel: formatBytes(validation.size),
    sha256,
    verdict: finalVerdict,
    riskScore: score,
    detections,
    componentErrors,
    durationSeconds,
    whitelisted,
    fileSize: validation.size,
  };
}

/**
 * Full scan pipeline for an uploaded archive: extract safely, scan every
 * contained file, then roll results up into an overall archive verdict.
 */
async function scanArchive({ filePath, filename, ext, config, scanDir }) {
  const start = Date.now();
  const sha256 = await sha256File(filePath);
  const stat = await fs.stat(filePath);

  const extractDir = path.join(scanDir, 'extracted');
  const notableFiles = [];
  let filesScanned = 0;
  let suspiciousCount = 0;
  let maliciousCount = 0;
  let overallScore = 0;
  const componentErrors = [];

  try {
    await extractArchive(filePath, extractDir, ext, config);
  } catch (err) {
    return {
      filename,
      sizeLabel: formatBytes(stat.size),
      sha256,
      overallVerdict: 'ERROR',
      filesScanned: 0,
      suspiciousCount: 0,
      maliciousCount: 0,
      notableFiles: [],
      durationSeconds: ((Date.now() - start) / 1000).toFixed(2),
      error: err.message,
    };
  }

  const files = await listFilesRecursive(extractDir);

  for (const f of files) {
    filesScanned++;
    try {
      const result = await scanSingleFile({ filePath: f.fullPath, filename: f.relativePath, config });
      overallScore = Math.max(overallScore, result.riskScore);

      if (result.verdict === 'MALICIOUS') maliciousCount++;
      else if (result.verdict === 'HIGH_RISK' || result.verdict === 'SUSPICIOUS') suspiciousCount++;

      if (result.verdict !== 'SAFE') {
        notableFiles.push({
          relativePath: f.relativePath,
          verdict: result.verdict,
          riskScore: result.riskScore,
        });
      }
    } catch (err) {
      componentErrors.push(`Gagal scan ${f.relativePath}: ${err.message}`);
    }
  }

  notableFiles.sort((a, b) => b.riskScore - a.riskScore);

  let overallVerdict = 'SAFE';
  if (maliciousCount > 0) overallVerdict = 'MALICIOUS';
  else if (overallScore >= 50) overallVerdict = 'HIGH_RISK';
  else if (overallScore >= 20 || suspiciousCount > 0) overallVerdict = 'SUSPICIOUS';

  const durationSeconds = ((Date.now() - start) / 1000).toFixed(2);

  return {
    filename,
    sizeLabel: formatBytes(stat.size),
    sha256,
    overallVerdict,
    riskScore: overallScore,
    filesScanned,
    suspiciousCount,
    maliciousCount,
    notableFiles,
    componentErrors,
    durationSeconds,
  };
}

/**
 * Top-level entry point: creates an isolated temp dir for this scan,
 * downloads/copies the target file into it, runs the right pipeline
 * (single file vs archive), and guarantees cleanup afterward.
 */
async function runScan({ sourcePath, filename, config }) {
  const scanId = newScanId();
  const scanDir = await createScanDir(scanId);
  const ext = path.extname(filename).toLowerCase();

  try {
    const workingPath = path.join(scanDir, 'upload' + ext);
    await fs.copyFile(sourcePath, workingPath);

    const validation = await validateFile(workingPath, filename, config);
    if (!validation.ok) {
      return { type: 'file', scanId, result: { filename, verdict: 'ERROR', componentErrors: validation.issues, riskScore: 0, sha256: 'N/A', sizeLabel: formatBytes(validation.size || 0), detections: [], durationSeconds: '0.00', rejected: true } };
    }

    if (validation.isArchive) {
      const result = await scanArchive({ filePath: workingPath, filename, ext, config, scanDir });
      return { type: 'archive', scanId, result };
    }

    const result = await scanSingleFile({ filePath: workingPath, filename, config });
    return { type: 'file', scanId, result };
  } finally {
    await cleanupScanDir(scanDir);
  }
}

async function checkEngineAvailability(config) {
  const [yara, clamav] = await Promise.all([
    yaraAvailable(config.yaraBinary),
    clamavAvailable(config.clamavBinary),
  ]);
  return { yara, clamav };
}

module.exports = { runScan, scanSingleFile, scanArchive, checkEngineAvailability, formatBytes };
