'use strict';

const path = require('path');
const fs = require('fs/promises');

const EXECUTABLE_EXT = new Set(['.exe', '.dll', '.asi', '.scr', '.sys']);
const SAMP_EXT = new Set(['.cs', '.lua', '.amx', '.pwn', '.inc']);
const ARCHIVE_EXT = new Set(['.zip', '.rar', '.7z']);
const KNOWN_EXT = new Set([...EXECUTABLE_EXT, ...SAMP_EXT, ...ARCHIVE_EXT]);

// Magic bytes for common formats we care about (read-only sniffing, never parsed as code).
const MAGIC_SIGNATURES = [
  { name: 'PE', ext: ['.exe', '.dll', '.asi', '.scr', '.sys'], bytes: [0x4d, 0x5a] }, // 'MZ'
  { name: 'ZIP', ext: ['.zip'], bytes: [0x50, 0x4b, 0x03, 0x04] },
  { name: 'ZIP_EMPTY', ext: ['.zip'], bytes: [0x50, 0x4b, 0x05, 0x06] },
  { name: 'RAR', ext: ['.rar'], bytes: [0x52, 0x61, 0x72, 0x21, 0x1a, 0x07] },
  { name: '7Z', ext: ['.7z'], bytes: [0x37, 0x7a, 0xbc, 0xaf, 0x27, 0x1c] },
];

function matchesSignature(buffer, sig) {
  if (buffer.length < sig.bytes.length) return false;
  for (let i = 0; i < sig.bytes.length; i++) {
    if (buffer[i] !== sig.bytes[i]) return false;
  }
  return true;
}

function detectMagicType(buffer) {
  for (const sig of MAGIC_SIGNATURES) {
    if (matchesSignature(buffer, sig)) return sig.name;
  }
  return 'UNKNOWN';
}

/**
 * Sanitize an entry path from inside an archive to prevent path traversal
 * (e.g. "../../etc/passwd" or absolute paths) escaping the extraction root.
 */
function isSafeArchiveEntryPath(entryPath, extractionRoot) {
  const normalized = path.normalize(entryPath).replace(/^(\.\.[/\\])+/, '');
  const resolved = path.resolve(extractionRoot, normalized);
  const resolvedRoot = path.resolve(extractionRoot);
  return resolved === resolvedRoot || resolved.startsWith(resolvedRoot + path.sep);
}

/**
 * Validate an uploaded file before any scanning happens.
 * Never trusts the extension alone — cross-checks against magic bytes.
 */
async function validateFile(filePath, declaredName, config) {
  const issues = [];
  const ext = path.extname(declaredName).toLowerCase();

  const stat = await fs.stat(filePath).catch(() => null);
  if (!stat) {
    return { ok: false, issues: ['File tidak ditemukan / gagal diunduh.'] };
  }

  if (stat.size === 0) {
    issues.push('File kosong (0 bytes).');
  }

  const maxBytes = config.maxFileSizeMB * 1024 * 1024;
  if (stat.size > maxBytes) {
    issues.push(`File melebihi batas ukuran maksimum (${config.maxFileSizeMB} MB).`);
  }

  // Read a small header chunk for magic-byte sniffing.
  const fh = await fs.open(filePath, 'r');
  const headerBuf = Buffer.alloc(16);
  await fh.read(headerBuf, 0, 16, 0);
  await fh.close();

  const magicType = detectMagicType(headerBuf);
  const isKnownExt = KNOWN_EXT.has(ext);

  let extensionMismatch = false;
  if (magicType === 'PE' && !EXECUTABLE_EXT.has(ext)) extensionMismatch = true;
  if ((magicType === 'ZIP' || magicType === 'ZIP_EMPTY') && ext !== '.zip') extensionMismatch = true;
  if (magicType === 'RAR' && ext !== '.rar') extensionMismatch = true;
  if (magicType === '7Z' && ext !== '.7z') extensionMismatch = true;

  if (extensionMismatch) {
    issues.push(
      `Ekstensi file (${ext || '(none)'}) tidak cocok dengan magic bytes yang terdeteksi (${magicType}). Kemungkinan disamarkan.`
    );
  }

  return {
    ok: issues.filter((i) => i.includes('melebihi') || i.includes('kosong')).length === 0,
    issues,
    size: stat.size,
    ext,
    magicType,
    isKnownExt,
    isExecutable: EXECUTABLE_EXT.has(ext) || magicType === 'PE',
    isArchive: ARCHIVE_EXT.has(ext) || magicType === 'ZIP' || magicType === 'ZIP_EMPTY' || magicType === 'RAR' || magicType === '7Z',
    isSampFile: SAMP_EXT.has(ext),
    extensionMismatch,
  };
}

module.exports = {
  validateFile,
  detectMagicType,
  isSafeArchiveEntryPath,
  EXECUTABLE_EXT,
  SAMP_EXT,
  ARCHIVE_EXT,
  KNOWN_EXT,
};
