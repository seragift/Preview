'use strict';

const path = require('path');
const fs = require('fs/promises');
const { execFile } = require('child_process');
const AdmZip = require('adm-zip');
const { isSafeArchiveEntryPath } = require('./fileValidator');
const logger = require('../utils/logger');

function execFileP(bin, args, opts = {}) {
  return new Promise((resolve, reject) => {
    const child = execFile(bin, args, { timeout: opts.timeoutMs || 30000, maxBuffer: 1024 * 1024 * 20 }, (err, stdout, stderr) => {
      if (err) {
        err.stdout = stdout;
        err.stderr = stderr;
        return reject(err);
      }
      resolve({ stdout, stderr });
    });
    if (opts.signal) {
      opts.signal.addEventListener('abort', () => child.kill('SIGKILL'));
    }
  });
}

/**
 * Extract a ZIP archive safely: enforces max total extracted size, max file
 * count, and rejects path-traversal entry names before writing anything.
 */
async function extractZip(zipPath, destDir, config) {
  const zip = new AdmZip(zipPath);
  const entries = zip.getEntries();

  const maxFiles = config.maxFilesInArchive;
  const maxExtractedBytes = config.maxExtractedSizeMB * 1024 * 1024;

  if (entries.length > maxFiles) {
    throw new Error(`Archive berisi ${entries.length} file, melebihi batas ${maxFiles} (kemungkinan zip bomb).`);
  }

  let totalUncompressed = 0;
  for (const entry of entries) {
    totalUncompressed += entry.header.size;
    if (totalUncompressed > maxExtractedBytes) {
      throw new Error(
        `Ukuran hasil ekstraksi melebihi batas ${config.maxExtractedSizeMB} MB (kemungkinan zip bomb).`
      );
    }
    if (!isSafeArchiveEntryPath(entry.entryName, destDir)) {
      throw new Error(`Entry archive mencurigakan (path traversal): ${entry.entryName}`);
    }
  }

  await fs.mkdir(destDir, { recursive: true });

  for (const entry of entries) {
    if (entry.isDirectory) continue;
    const targetPath = path.resolve(destDir, entry.entryName);
    await fs.mkdir(path.dirname(targetPath), { recursive: true });
    await fs.writeFile(targetPath, entry.getData());
  }

  return { fileCount: entries.filter((e) => !e.isDirectory).length, totalUncompressed };
}

/**
 * Extract RAR/7Z via the system `7z` binary (p7zip-full on Ubuntu handles both).
 * We list contents first to enforce limits *before* extracting anything.
 */
async function extract7zOrRar(archivePath, destDir, config) {
  const sevenZipBin = config.sevenZipBinary || '7z';
  const maxFiles = config.maxFilesInArchive;
  const maxExtractedBytes = config.maxExtractedSizeMB * 1024 * 1024;

  let listOutput;
  try {
    const { stdout } = await execFileP(sevenZipBin, ['l', '-slt', archivePath], { timeoutMs: 20000 });
    listOutput = stdout;
  } catch (err) {
    throw new Error(`Gagal membaca isi archive (7z tidak tersedia atau archive corrupt): ${err.message}`);
  }

  const entryBlocks = listOutput.split(/\r?\n\r?\n/);
  let fileCount = 0;
  let totalSize = 0;
  for (const block of entryBlocks) {
    const pathMatch = block.match(/^Path = (.+)$/m);
    const sizeMatch = block.match(/^Size = (\d+)$/m);
    const attrMatch = block.match(/^Attributes = (.+)$/m);
    if (!pathMatch) continue;
    const isDir = attrMatch && attrMatch[1].includes('D');
    if (isDir) continue;

    fileCount++;
    totalSize += sizeMatch ? parseInt(sizeMatch[1], 10) : 0;

    if (!isSafeArchiveEntryPath(pathMatch[1], destDir)) {
      throw new Error(`Entry archive mencurigakan (path traversal): ${pathMatch[1]}`);
    }
  }

  if (fileCount > maxFiles) {
    throw new Error(`Archive berisi ${fileCount} file, melebihi batas ${maxFiles} (kemungkinan bomb).`);
  }
  if (totalSize > maxExtractedBytes) {
    throw new Error(`Ukuran hasil ekstraksi (${totalSize} bytes) melebihi batas ${config.maxExtractedSizeMB} MB.`);
  }

  await fs.mkdir(destDir, { recursive: true });
  await execFileP(sevenZipBin, ['x', archivePath, `-o${destDir}`, '-y', '-bd'], { timeoutMs: config.scanTimeoutSeconds * 1000 });

  return { fileCount, totalUncompressed: totalSize };
}

/**
 * Recursively list files under a directory (post-extraction), used to feed
 * the per-file scan loop. Depth-limited to avoid nested-archive recursion abuse.
 */
async function listFilesRecursive(dir, baseDir = dir, depth = 0, maxDepth = 5) {
  if (depth > maxDepth) return [];
  const out = [];
  const entries = await fs.readdir(dir, { withFileTypes: true }).catch(() => []);
  for (const entry of entries) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      out.push(...(await listFilesRecursive(full, baseDir, depth + 1, maxDepth)));
    } else if (entry.isFile()) {
      out.push({ fullPath: full, relativePath: path.relative(baseDir, full) });
    }
  }
  return out;
}

async function extractArchive(archivePath, destDir, ext, config) {
  logger.info('archive: extracting', { ext, destDir });
  if (ext === '.zip') {
    return extractZip(archivePath, destDir, config);
  }
  if (ext === '.rar' || ext === '.7z') {
    return extract7zOrRar(archivePath, destDir, config);
  }
  throw new Error(`Format archive tidak didukung: ${ext}`);
}

module.exports = { extractArchive, listFilesRecursive };
