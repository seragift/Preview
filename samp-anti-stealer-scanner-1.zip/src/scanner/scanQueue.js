'use strict';

const STATUS = {
  QUEUED: 'QUEUED',
  SCANNING: 'SCANNING',
  COMPLETED: 'COMPLETED',
  FAILED: 'FAILED',
};

class ScanQueue {
  constructor() {
    this.jobs = new Map(); // scanId -> { status, meta }
  }

  register(scanId, meta = {}) {
    this.jobs.set(scanId, { status: STATUS.QUEUED, meta, updatedAt: Date.now() });
  }

  setStatus(scanId, status) {
    const job = this.jobs.get(scanId);
    if (job) {
      job.status = status;
      job.updatedAt = Date.now();
    }
  }

  getStatus(scanId) {
    return this.jobs.get(scanId)?.status || null;
  }

  remove(scanId) {
    this.jobs.delete(scanId);
  }
}

module.exports = { ScanQueue, STATUS };
