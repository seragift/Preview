'use strict';

const fs = require('fs/promises');
const path = require('path');
const os = require('os');
const crypto = require('crypto');

const { runScan } = require('../scanner/scanner');
const { buildFileResultEmbed, buildArchiveSummaryEmbed } = require('../utils/embed');
const { insertScanRecord, insertDetections, getGuildSettings } = require('../database/database');
const logger = require('../utils/logger');
const { KNOWN_EXT } = require('../scanner/fileValidator');

const DOWNLOAD_ROOT = path.join(os.tmpdir(), 'samp-scanner-downloads');

async function downloadAttachment(attachment) {
  await fs.mkdir(DOWNLOAD_ROOT, { recursive: true });
  const dest = path.join(DOWNLOAD_ROOT, `${crypto.randomBytes(8).toString('hex')}_${path.basename(attachment.name)}`);

  const res = await fetch(attachment.url);
  if (!res.ok) throw new Error(`Gagal mengunduh attachment (HTTP ${res.status})`);

  const arrayBuffer = await res.arrayBuffer();
  await fs.writeFile(dest, Buffer.from(arrayBuffer));
  return dest;
}

function logToChannel(client, logChannelId, text) {
  if (!logChannelId) return;
  const channel = client.channels.cache.get(logChannelId);
  if (channel && channel.isTextBased()) {
    channel.send({ content: text.slice(0, 1990) }).catch((err) => logger.warn('Gagal kirim log ke channel', { error: err.message }));
  }
}

/**
 * Full pipeline: download -> runScan -> persist to DB -> build embed -> reply.
 * Shared by the automatic messageCreate flow and the manual /scan command.
 */
async function processAttachment({ attachment, guildId, userId, context, reply, followUp }) {
  const { config, rateLimiter, client } = context;
  const ext = path.extname(attachment.name || '').toLowerCase();
  const guildSettings = guildId ? getGuildSettings(guildId) : null;
  const logChannelId = guildSettings?.log_channel_id || null;

  if (attachment.size > config.maxArchiveSizeMB * 1024 * 1024 && KNOWN_EXT.has(ext) === false) {
    return reply({ content: `❌ File terlalu besar (maks ${config.maxArchiveSizeMB} MB untuk archive).` });
  }

  if (rateLimiter.isUserRateLimited(userId)) {
    return reply({
      content: `⏳ Kamu sudah mencapai batas ${config.maxScansPerUserPerMinute} scan/menit. Coba lagi sebentar.`,
    });
  }
  rateLimiter.recordHit(userId);

  if (rateLimiter.isFull) {
    await reply({ content: '⏳ Scanner sedang sibuk. File kamu masuk antrean...' });
  }

  await rateLimiter.acquire();

  let downloadedPath;
  try {
    downloadedPath = await downloadAttachment(attachment);

    const { type, result } = await runScan({ sourcePath: downloadedPath, filename: attachment.name, config });

    if (type === 'archive') {
      if (result.overallVerdict === 'ERROR') {
        await reply({ content: `⚠️ Gagal memproses archive: ${result.error}` });
        return;
      }

      const scanId = insertScanRecord({
        guildId,
        userId,
        filename: result.filename,
        sha256: result.sha256,
        fileSize: attachment.size,
        verdict: result.overallVerdict,
        riskScore: result.riskScore || 0,
      });
      insertDetections(
        scanId,
        result.notableFiles.map((f) => ({
          filePath: f.relativePath,
          category: 'archive_member',
          severity: f.verdict === 'MALICIOUS' ? 'high' : 'medium',
          description: `${f.relativePath}: ${f.verdict} (score ${f.riskScore})`,
        }))
      );

      const embed = buildArchiveSummaryEmbed(result);
      await reply({ embeds: [embed] });

      logToChannel(
        client,
        logChannelId,
        `📦 Archive scan | user:${userId} | ${result.filename} | sha256:${result.sha256} | verdict:${result.overallVerdict} | files:${result.filesScanned}`
      );
    } else {
      if (result.rejected) {
        await reply({ content: `❌ File ditolak:\n${result.componentErrors.join('\n')}` });
        return;
      }

      const scanId = insertScanRecord({
        guildId,
        userId,
        filename: result.filename,
        sha256: result.sha256,
        fileSize: result.fileSize,
        verdict: result.verdict,
        riskScore: result.riskScore,
      });
      insertDetections(
        scanId,
        result.detections.map((d) => ({
          filePath: result.filename,
          rule: d.rule,
          category: d.category,
          severity: d.severity,
          description: d.description,
        }))
      );

      const embed = buildFileResultEmbed(result);
      await reply({ embeds: [embed] });

      logToChannel(
        client,
        logChannelId,
        `🔎 File scan | user:${userId} | ${result.filename} | sha256:${result.sha256} | verdict:${result.verdict} | score:${result.riskScore}`
      );
    }
  } catch (err) {
    logger.error('processAttachment failed', { error: err.message });
    await reply({ content: `⚠️ Terjadi error saat scanning: ${err.message}` }).catch(() => {});
  } finally {
    rateLimiter.release();
    if (downloadedPath) {
      await fs.unlink(downloadedPath).catch(() => {});
    }
  }
}

module.exports = { processAttachment };
