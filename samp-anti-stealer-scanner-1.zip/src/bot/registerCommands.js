'use strict';

require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { REST, Routes } = require('discord.js');

const commandsPath = path.join(__dirname, 'commands');
const commandFiles = fs.readdirSync(commandsPath).filter((f) => f.endsWith('.js'));

const commands = [];
for (const file of commandFiles) {
  const command = require(path.join(commandsPath, file));
  commands.push(command.data.toJSON());
}

const rest = new REST().setToken(process.env.DISCORD_TOKEN);

(async () => {
  try {
    console.log(`Mendaftarkan ${commands.length} slash command secara GLOBAL (berlaku di semua server)...`);

    // Global registration: no guild ID needed. Propagation can take up to ~1 hour
    // the first time; instant on subsequent updates in practice.
    await rest.put(Routes.applicationCommands(process.env.CLIENT_ID), { body: commands });

    console.log('✅ Slash command berhasil didaftarkan secara global.');
  } catch (err) {
    console.error('❌ Gagal mendaftarkan command:', err);
    process.exit(1);
  }
})();
