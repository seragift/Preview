'use strict';

const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { setLogChannel } = require('../../database/database');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setlogchannel')
    .setDescription('Atur channel log hasil scan (admin only)')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addChannelOption((opt) =>
      opt
        .setName('channel')
        .setDescription('Channel untuk log scan')
        .addChannelTypes(ChannelType.GuildText)
        .setRequired(true)
    ),

  async execute(interaction) {
    if (!interaction.memberPermissions?.has(PermissionFlagsBits.Administrator)) {
      return interaction.reply({ content: '❌ Hanya administrator yang dapat menggunakan command ini.', ephemeral: true });
    }

    const channel = interaction.options.getChannel('channel');
    setLogChannel(interaction.guildId, channel.id);

    return interaction.reply({ content: `✅ Log channel berhasil diatur ke <#${channel.id}>` });
  },
};
