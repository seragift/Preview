'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { processAttachment } = require('../scanHandler');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('scan')
    .setDescription('Scan sebuah file secara manual (bisa dipakai di channel manapun)')
    .addAttachmentOption((opt) => opt.setName('file').setDescription('File yang ingin discan').setRequired(true)),

  async execute(interaction, context) {
    const attachment = interaction.options.getAttachment('file');
    await interaction.deferReply();

    await processAttachment({
      attachment,
      guildId: interaction.guildId,
      userId: interaction.user.id,
      context,
      reply: async (payload) => interaction.editReply(payload),
      followUp: async (payload) => interaction.followUp(payload),
    });
  },
};
