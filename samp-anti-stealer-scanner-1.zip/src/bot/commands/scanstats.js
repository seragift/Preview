'use strict';

const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getScanStats } = require('../../database/database');

module.exports = {
  data: new SlashCommandBuilder().setName('scanstats').setDescription('Statistik hasil scan di server ini'),

  async execute(interaction) {
    const stats = getScanStats(interaction.guildId);

    const verdictLines = stats.byVerdict.map((v) => `${v.verdict}: ${v.c}`).join('\n') || 'Belum ada data.';
    const recentLines =
      stats.recent.map((r) => `\`${r.filename}\` — ${r.verdict} (score ${r.risk_score})`).join('\n') || '—';

    const embed = new EmbedBuilder()
      .setTitle('📊 Scanner Statistics')
      .addFields(
        { name: 'Total Scan', value: `${stats.total}`, inline: true },
        { name: 'Berdasarkan Verdict', value: verdictLines, inline: false },
        { name: '5 Scan Terakhir', value: recentLines, inline: false }
      );

    return interaction.reply({ embeds: [embed] });
  },
};
