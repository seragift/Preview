'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { addWhitelist } = require('../../database/database');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('whitelist')
    .setDescription('Tandai sebuah hash file sebagai TRUSTED (admin only)')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addStringOption((opt) => opt.setName('hash').setDescription('SHA-256 hash file').setRequired(true))
    .addStringOption((opt) => opt.setName('reason').setDescription('Alasan whitelist').setRequired(false)),

  async execute(interaction) {
    if (!interaction.memberPermissions?.has(PermissionFlagsBits.Administrator)) {
      return interaction.reply({ content: '❌ Hanya administrator yang dapat menggunakan command ini.', ephemeral: true });
    }

    const hash = interaction.options.getString('hash').trim().toLowerCase();
    if (!/^[a-f0-9]{64}$/.test(hash)) {
      return interaction.reply({ content: '❌ Format hash tidak valid. Harus SHA-256 (64 karakter hex).', ephemeral: true });
    }

    const reason = interaction.options.getString('reason') || null;
    addWhitelist(hash, reason, interaction.user.id);

    return interaction.reply({
      content: `🟢 Hash \`${hash}\` ditandai sebagai TRUSTED.\nCatatan: whitelist mengubah reputasi, bukan menghapus hasil deteksi static analysis.`,
    });
  },
};
