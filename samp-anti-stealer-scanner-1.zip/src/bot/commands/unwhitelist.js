'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { removeWhitelist } = require('../../database/database');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('unwhitelist')
    .setDescription('Hapus status TRUSTED dari sebuah hash (admin only)')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addStringOption((opt) => opt.setName('hash').setDescription('SHA-256 hash file').setRequired(true)),

  async execute(interaction) {
    if (!interaction.memberPermissions?.has(PermissionFlagsBits.Administrator)) {
      return interaction.reply({ content: '❌ Hanya administrator yang dapat menggunakan command ini.', ephemeral: true });
    }

    const hash = interaction.options.getString('hash').trim().toLowerCase();
    const removed = removeWhitelist(hash);

    return interaction.reply({
      content: removed ? `✅ Hash \`${hash}\` dihapus dari whitelist.` : `ℹ️ Hash tersebut tidak ada di whitelist.`,
    });
  },
};
