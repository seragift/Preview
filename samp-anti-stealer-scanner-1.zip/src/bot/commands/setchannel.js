'use strict';

const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { setScannerChannel } = require('../../database/database');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setchannel')
    .setDescription('Atur channel yang dipantau untuk auto-scan file (admin only)')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addChannelOption((opt) =>
      opt
        .setName('channel')
        .setDescription('Channel untuk scanner')
        .addChannelTypes(ChannelType.GuildText)
        .setRequired(true)
    ),

  async execute(interaction) {
    if (!interaction.memberPermissions?.has(PermissionFlagsBits.Administrator)) {
      return interaction.reply({ content: '❌ Hanya administrator yang dapat menggunakan command ini.', ephemeral: true });
    }

    const channel = interaction.options.getChannel('channel');
    setScannerChannel(interaction.guildId, channel.id);

    return interaction.reply({
      content: `✅ Scanner channel berhasil diatur ke <#${channel.id}>`,
    });
  },
};
