'use strict';

const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getScanByHash, isWhitelisted } = require('../../database/database');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('scaninfo')
    .setDescription('Lihat riwayat scan berdasarkan SHA-256 hash')
    .addStringOption((opt) => opt.setName('hash').setDescription('SHA-256 hash file').setRequired(true)),

  async execute(interaction) {
    const hash = interaction.options.getString('hash').trim().toLowerCase();

    if (!/^[a-f0-9]{64}$/.test(hash)) {
      return interaction.reply({ content: '❌ Format hash tidak valid. Harus SHA-256 (64 karakter hex).', ephemeral: true });
    }

    const record = getScanByHash(hash);
    if (!record) {
      return interaction.reply({ content: 'ℹ️ Tidak ada riwayat scan untuk hash ini.', ephemeral: true });
    }

    const whitelisted = isWhitelisted(hash);

    const embed = new EmbedBuilder()
      .setTitle('📄 Scan Info')
      .addFields(
        { name: 'Filename', value: record.filename, inline: true },
        { name: 'SHA-256', value: `\`${record.sha256}\``, inline: false },
        { name: 'Verdict Terakhir', value: record.verdict, inline: true },
        { name: 'Risk Score', value: `${record.risk_score}`, inline: true },
        { name: 'Reputation', value: whitelisted ? '🟢 TRUSTED (whitelisted)' : '—', inline: true },
        { name: 'Scan Terakhir', value: record.created_at, inline: false }
      );

    return interaction.reply({ embeds: [embed] });
  },
};
