'use strict';

const { getGuildSettings } = require('../../database/database');
const { processAttachment } = require('../scanHandler');
const logger = require('../../utils/logger');

module.exports = {
  name: 'messageCreate',
  once: false,
  async execute(message, context) {
    if (message.author.bot) return;
    if (!message.guildId) return; // ignore DMs
    if (message.attachments.size === 0) return; // no attachment -> ignore

    const settings = getGuildSettings(message.guildId);
    if (!settings || !settings.scanner_channel_id) return; // scanner not configured for this guild
    if (message.channelId !== settings.scanner_channel_id) return; // only the configured channel

    await message.reply('🔎 File diterima. Memulai security analysis...').catch(() => {});

    for (const attachment of message.attachments.values()) {
      // eslint-disable-next-line no-await-in-loop
      await processAttachment({
        attachment,
        guildId: message.guildId,
        userId: message.author.id,
        context,
        reply: async (payload) => message.channel.send(payload),
        followUp: async (payload) => message.channel.send(payload),
      }).catch((err) => logger.error('messageCreate scan failed', { error: err.message }));
    }
  },
};
