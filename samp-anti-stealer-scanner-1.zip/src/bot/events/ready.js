'use strict';

const { ActivityType } = require('discord.js');
const { checkEngineAvailability } = require('../../scanner/scanner');
const { sweepOrphaned } = require('../../utils/cleanup');
const logger = require('../../utils/logger');

module.exports = {
  name: 'ready',
  once: true,
  async execute(client, context) {
    logger.info(`Bot online sebagai ${client.user.tag}`, { guilds: client.guilds.cache.size });

    const availability = await checkEngineAvailability(context.config);
    logger.info('Engine availability', availability);
    if (!availability.yara) logger.warn('YARA tidak terdeteksi di sistem - scan akan berjalan tanpa YARA.');
    if (!availability.clamav) logger.warn('ClamAV tidak terdeteksi di sistem - scan akan berjalan tanpa ClamAV.');

    client.user.setPresence({
      activities: [{ name: `${client.guilds.cache.size} server | static file security scan`, type: ActivityType.Watching }],
      status: 'online',
    });

    await sweepOrphaned();
    setInterval(() => sweepOrphaned().catch(() => {}), 15 * 60 * 1000);
  },
};
