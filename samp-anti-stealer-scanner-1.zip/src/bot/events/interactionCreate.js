'use strict';

const logger = require('../../utils/logger');

module.exports = {
  name: 'interactionCreate',
  once: false,
  async execute(interaction, context) {
    if (!interaction.isChatInputCommand()) return;

    const command = interaction.client.commands.get(interaction.commandName);
    if (!command) return;

    try {
      await command.execute(interaction, context);
    } catch (err) {
      logger.error(`Command ${interaction.commandName} error`, { error: err.message });
      const payload = { content: '⚠️ Terjadi error saat menjalankan command ini.', ephemeral: true };
      if (interaction.deferred || interaction.replied) {
        await interaction.editReply(payload).catch(() => {});
      } else {
        await interaction.reply(payload).catch(() => {});
      }
    }
  },
};
