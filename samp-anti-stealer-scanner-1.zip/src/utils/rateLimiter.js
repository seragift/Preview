'use strict';

/**
 * Simple sliding-window rate limiter per user, plus a concurrency semaphore
 * to cap how many scans run at once (protects CPU from YARA/ClamAV/archive work).
 */
class RateLimiter {
  constructor({ maxPerUserPerMinute = 3, maxConcurrent = 2 } = {}) {
    this.maxPerUserPerMinute = maxPerUserPerMinute;
    this.maxConcurrent = maxConcurrent;
    this.userHits = new Map(); // userId -> array of timestamps
    this.activeCount = 0;
    this.queue = [];
  }

  isUserRateLimited(userId) {
    const now = Date.now();
    const windowMs = 60 * 1000;
    const hits = (this.userHits.get(userId) || []).filter((t) => now - t < windowMs);
    this.userHits.set(userId, hits);
    return hits.length >= this.maxPerUserPerMinute;
  }

  recordHit(userId) {
    const hits = this.userHits.get(userId) || [];
    hits.push(Date.now());
    this.userHits.set(userId, hits);
  }

  get activeSlots() {
    return this.activeCount;
  }

  get isFull() {
    return this.activeCount >= this.maxConcurrent;
  }

  get queueLength() {
    return this.queue.length;
  }

  /**
   * Acquire a concurrency slot. Resolves with position info when a slot is
   * granted (immediately if free, otherwise once queued work ahead finishes).
   */
  acquire() {
    return new Promise((resolve) => {
      const tryAcquire = () => {
        if (this.activeCount < this.maxConcurrent) {
          this.activeCount++;
          resolve();
        } else {
          this.queue.push(tryAcquire);
        }
      };
      tryAcquire();
    });
  }

  release() {
    this.activeCount = Math.max(0, this.activeCount - 1);
    const next = this.queue.shift();
    if (next) next();
  }
}

module.exports = RateLimiter;
