'use strict';

const { EmbedBuilder } = require('discord.js');

const VERDICT_META = {
  SAFE: { emoji: '🟢', color: 0x2ecc71, label: 'SAFE' },
  SUSPICIOUS: { emoji: '🟡', color: 0xf1c40f, label: 'SUSPICIOUS' },
  HIGH_RISK: { emoji: '🟠', color: 0xe67e22, label: 'HIGH RISK' },
  MALICIOUS: { emoji: '🔴', color: 0xe74c3c, label: 'MALICIOUS' },
  ERROR: { emoji: '⚠️', color: 0x95a5a6, label: 'SCAN ERROR' },
};

function severityEmoji(severity) {
  if (severity === 'high') return '🔴';
  if (severity === 'medium') return '🟡';
  if (severity === 'low') return '🟢';
  return '⚪';
}

function buildFileResultEmbed(result) {
  const meta = VERDICT_META[result.verdict] || VERDICT_META.ERROR;

  const embed = new EmbedBuilder()
    .setTitle('🛡️ SA-MP Security Scanner')
    .setColor(meta.color)
    .addFields(
      { name: 'File', value: `\`${result.filename}\``, inline: true },
      { name: 'Size', value: result.sizeLabel, inline: true },
      { name: 'SHA-256', value: `\`${result.sha256}\``, inline: false },
      { name: 'Verdict', value: `${meta.emoji} **${meta.label}**`, inline: true },
      { name: 'Risk Score', value: `${result.riskScore}`, inline: true }
    );

  if (result.whitelisted) {
    embed.addFields({ name: 'Reputation', value: '🟢 TRUSTED (whitelisted by admin)', inline: false });
  }

  if (result.detections && result.detections.length > 0) {
    const grouped = result.detections
      .slice(0, 10)
      .map((d) => `${severityEmoji(d.severity)} **${d.category}**\n${d.description}`)
      .join('\n\n');
    embed.addFields({ name: 'Detections', value: grouped.slice(0, 1024) });
  } else {
    embed.addFields({ name: 'Detections', value: '🟢 No significant indicators found.' });
  }

  if (result.componentErrors && result.componentErrors.length > 0) {
    embed.addFields({
      name: 'Component Warnings',
      value: result.componentErrors.map((e) => `⚠️ ${e}`).join('\n').slice(0, 1024),
    });
  }

  embed.addFields({ name: 'Scan Duration', value: `${result.durationSeconds}s`, inline: true });

  embed.setFooter({
    text: 'Static analysis only — cannot guarantee a file is completely safe.',
  });
  embed.setTimestamp(new Date());

  return embed;
}

function buildArchiveSummaryEmbed(archiveResult) {
  const meta = VERDICT_META[archiveResult.overallVerdict] || VERDICT_META.ERROR;

  const embed = new EmbedBuilder()
    .setTitle('🛡️ SA-MP Security Scanner — Archive Report')
    .setColor(meta.color)
    .addFields(
      { name: 'Archive', value: `\`${archiveResult.filename}\``, inline: true },
      { name: 'Size', value: archiveResult.sizeLabel, inline: true },
      { name: 'SHA-256', value: `\`${archiveResult.sha256}\``, inline: false },
      { name: 'Files Scanned', value: `${archiveResult.filesScanned}`, inline: true },
      { name: 'Suspicious', value: `${archiveResult.suspiciousCount}`, inline: true },
      { name: 'Malicious', value: `${archiveResult.maliciousCount}`, inline: true },
      { name: 'Overall Verdict', value: `${meta.emoji} **${meta.label}**`, inline: false }
    );

  if (archiveResult.notableFiles && archiveResult.notableFiles.length > 0) {
    const list = archiveResult.notableFiles
      .slice(0, 15)
      .map((f) => {
        const m = VERDICT_META[f.verdict] || VERDICT_META.ERROR;
        return `${m.emoji} \`${f.relativePath}\`\n${m.label} (score ${f.riskScore})`;
      })
      .join('\n\n');
    embed.addFields({ name: 'Notable Files', value: list.slice(0, 1024) });
  }

  embed.addFields({ name: 'Scan Duration', value: `${archiveResult.durationSeconds}s`, inline: true });
  embed.setFooter({ text: 'Static analysis only — cannot guarantee a file is completely safe.' });
  embed.setTimestamp(new Date());

  return embed;
}

module.exports = { buildFileResultEmbed, buildArchiveSummaryEmbed, VERDICT_META, severityEmoji };
