'use strict';

const fs = require('fs');
const path = require('path');

const LOG_DIR = path.join(process.cwd(), 'logs');
if (!fs.existsSync(LOG_DIR)) fs.mkdirSync(LOG_DIR, { recursive: true });

const LOG_FILE = path.join(LOG_DIR, `bot-${new Date().toISOString().slice(0, 10)}.log`);

/**
 * Redact secrets/tokens/webhook tokens before logging anywhere.
 * Never log: Discord bot token, full webhook URLs, credential-looking values.
 */
function redact(str) {
  if (typeof str !== 'string') return str;
  let out = str;

  // Discord webhook URLs -> keep id, redact token
  out = out.replace(
    /(discord(?:app)?\.com\/api\/webhooks\/\d+\/)([A-Za-z0-9_-]+)/gi,
    '$1REDACTED'
  );

  // Discord bot tokens look like base64 segments separated by dots
  out = out.replace(/[A-Za-z0-9_-]{24,}\.[A-Za-z0-9_-]{6,}\.[A-Za-z0-9_-]{20,}/g, '[REDACTED_TOKEN]');

  return out;
}

function write(level, msg, meta) {
  const timestamp = new Date().toISOString();
  const safeMsg = redact(String(msg));
  const safeMeta = meta ? redact(JSON.stringify(meta)) : '';
  const line = `[${timestamp}] [${level}] ${safeMsg} ${safeMeta}`.trim();

  const consoleFn = level === 'ERROR' ? console.error : level === 'WARN' ? console.warn : console.log;
  consoleFn(line);

  try {
    fs.appendFileSync(LOG_FILE, line + '\n');
  } catch (_) {
    // Never let logging crash the bot
  }
}

module.exports = {
  info: (msg, meta) => write('INFO', msg, meta),
  warn: (msg, meta) => write('WARN', msg, meta),
  error: (msg, meta) => write('ERROR', msg, meta),
  debug: (msg, meta) => {
    if (process.env.DEBUG) write('DEBUG', msg, meta);
  },
  redact,
};
