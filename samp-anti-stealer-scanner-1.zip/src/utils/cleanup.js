'use strict';

const fs = require('fs/promises');
const path = require('path');
const logger = require('./logger');

const TEMP_ROOT = path.join(process.cwd(), 'temp', 'scans');

/**
 * Create an isolated temp directory for a single scan: temp/scans/<scan-id>/
 */
async function createScanDir(scanId) {
  const dir = path.join(TEMP_ROOT, scanId);
  await fs.mkdir(dir, { recursive: true });
  return dir;
}

/**
 * Recursively delete a scan's temp directory. Safe no-op if it doesn't exist.
 * Guards against accidentally deleting anything outside temp/scans/.
 */
async function cleanupScanDir(dir) {
  try {
    const resolved = path.resolve(dir);
    const resolvedRoot = path.resolve(TEMP_ROOT);
    if (!resolved.startsWith(resolvedRoot + path.sep) && resolved !== resolvedRoot) {
      logger.error('cleanup: refused to delete path outside temp/scans root', { dir });
      return;
    }
    await fs.rm(resolved, { recursive: true, force: true });
  } catch (err) {
    logger.error('cleanup: failed to remove scan dir', { dir, error: err.message });
  }
}

/**
 * Periodic sweep for orphaned scan directories older than maxAgeMs
 * (e.g. left behind after a crash mid-scan).
 */
async function sweepOrphaned(maxAgeMs = 30 * 60 * 1000) {
  try {
    await fs.mkdir(TEMP_ROOT, { recursive: true });
    const entries = await fs.readdir(TEMP_ROOT, { withFileTypes: true });
    const now = Date.now();
    for (const entry of entries) {
      if (!entry.isDirectory()) continue;
      const full = path.join(TEMP_ROOT, entry.name);
      const stat = await fs.stat(full).catch(() => null);
      if (stat && now - stat.mtimeMs > maxAgeMs) {
        await cleanupScanDir(full);
        logger.info('cleanup: swept orphaned scan dir', { dir: full });
      }
    }
  } catch (err) {
    logger.error('cleanup: sweep failed', { error: err.message });
  }
}

module.exports = { createScanDir, cleanupScanDir, sweepOrphaned, TEMP_ROOT };
