'use strict';

require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { Client, GatewayIntentBits, Collection, Partials } = require('discord.js');

const logger = require('./src/utils/logger');
const RateLimiter = require('./src/utils/rateLimiter');
require('./src/database/database'); // initializes DB + tables on require

let config;
try {
  config = JSON.parse(fs.readFileSync(path.join(__dirname, 'config.json'), 'utf-8'));
} catch (err) {
  logger.error('Gagal membaca config.json', { error: err.message });
  process.exit(1);
}

if (!process.env.DISCORD_TOKEN) {
  logger.error('DISCORD_TOKEN tidak ditemukan di .env. Salin .env.example ke .env dan isi token.');
  process.exit(1);
}
if (!process.env.CLIENT_ID) {
  logger.warn('CLIENT_ID tidak diset di .env — dibutuhkan untuk registrasi slash command (npm run register).');
}

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
  partials: [Partials.Message, Partials.Channel],
});

// Shared context passed into every command/event handler.
const context = {
  config,
  rateLimiter: new RateLimiter({
    maxPerUserPerMinute: config.maxScansPerUserPerMinute,
    maxConcurrent: config.maxConcurrentScans,
  }),
  client,
};

// ---- Load commands ----
client.commands = new Collection();
const commandsDir = path.join(__dirname, 'src', 'bot', 'commands');
for (const file of fs.readdirSync(commandsDir).filter((f) => f.endsWith('.js'))) {
  const command = require(path.join(commandsDir, file));
  client.commands.set(command.data.name, command);
}
logger.info(`Loaded ${client.commands.size} slash commands`);

// ---- Load events ----
const eventsDir = path.join(__dirname, 'src', 'bot', 'events');
for (const file of fs.readdirSync(eventsDir).filter((f) => f.endsWith('.js'))) {
  const event = require(path.join(eventsDir, file));
  if (event.once) {
    client.once(event.name, (...args) => event.execute(...args, context));
  } else {
    client.on(event.name, (...args) => event.execute(...args, context));
  }
}
logger.info(`Loaded events from ${eventsDir}`);

process.on('unhandledRejection', (err) => {
  logger.error('Unhandled rejection', { error: err?.message || String(err) });
});
process.on('uncaughtException', (err) => {
  logger.error('Uncaught exception', { error: err?.message || String(err) });
});

client.login(process.env.DISCORD_TOKEN);
