# SAMPAI Agent (V1)

AI coding agent berbasis Node.js yang jalan di VPS, khusus untuk membantu development project **SA-MP (San Andreas Multiplayer)**.

**V1 fokus penuh ke:** baca/tulis/edit/hapus file + jalankan command development (compile, dll) + memory yang tersimpan permanen di filesystem, sehingga agent tetap ingat kondisi project walau Node.js/VPS restart.

**V1 TIDAK melakukan:** install, start/stop, atau mengelola server SA-MP secara otomatis. Itu direncanakan untuk versi berikutnya (compiler integration, server.cfg management, start/stop/monitoring, dsb).

---

## 1. Struktur Folder

```
sampai-agent/
├── agent.js                  # entry point CLI (REPL)
├── package.json
├── .env.example
├── .gitignore
├── README.md
│
├── src/
│   ├── agent/
│   │   ├── loop.js           # loop utama: kirim ke LLM, jalankan tool calls, sampai selesai
│   │   ├── planner.js        # system prompt / aturan kerja agent
│   │   └── context.js        # bangun ringkasan context dari memory (bukan dari chat history)
│   │
│   ├── tools/
│   │   ├── files.js          # list_files, read_file, write_file, edit_file, delete_file
│   │   ├── shell.js          # run_command
│   │   └── index.js          # tool schema (function calling) + dispatcher
│   │
│   ├── memory/
│   │   ├── manager.js        # generic read/write JSON yang aman & atomik
│   │   ├── project.js        # project.json + decisions.json
│   │   ├── tasks.js          # tasks.json
│   │   ├── changes.js        # changes.json
│   │   └── errors.js         # errors.json
│   │
│   ├── security/
│   │   └── sandbox.js        # path validation, command allowlist/blocklist, file size limit
│   │
│   └── utils/
│       └── logger.js
│
├── memory/                   # DISIMPAN DI FILESYSTEM, bertahan lintas restart
│   ├── project.json
│   ├── tasks.json
│   ├── changes.json
│   ├── errors.json
│   └── decisions.json
│
├── logs/
│   ├── agent.log
│   ├── tool.log
│   ├── task.log
│   └── error.log
│
├── workspace/
│   └── samp-project/         # contoh project SA-MP (ganti dengan project asli kamu)
│
└── test/
    └── run-tests.js
```

## 2. Instalasi

Di VPS (Ubuntu/Debian, Node.js >= 18):

```bash
cd sampai-agent
npm install
cp .env.example .env
nano .env   # isi API key & endpoint
```

## 3. Konfigurasi API (`.env`)

Agent memakai API OpenAI-compatible, jadi bisa dipakai dengan provider apa pun yang kompatibel — termasuk **NaraRouter**:

```env
OPENAI_API_KEY=sk-xxxxxxxxxxxxxxxxxxxxxxxxxx
OPENAI_BASE_URL=https://router.bynara.id/v1
OPENAI_MODEL=agnes-2.5-flash

WORKSPACE=./workspace
MAX_TOOL_ITERATIONS=25
COMMAND_TIMEOUT_MS=30000
MAX_FILE_SIZE_KB=1024
MAX_COMMAND_OUTPUT_KB=64
```

Ganti `OPENAI_API_KEY` dengan API key asli dari dashboard NaraRouter kamu (jangan pernah commit `.env` ke git — sudah di-`.gitignore`). Model yang dipakai harus mendukung **function calling / tool use**; `agnes-2.5-flash` di screenshot dashboard kamu kompatibel dengan endpoint `/v1/chat/completions` ala OpenAI, jadi tinggal pakai konfigurasi di atas.

## 4. Menjalankan Agent

```bash
npm start
```

Lalu ketik perintah, misalnya:

```
> Baca source gamemode ini dan pahami strukturnya.
> Buatkan sistem login.
> Tambahkan command /veh.
> Apa yang belum selesai?
> Lanjutkan.
```

Ketik `exit` untuk keluar.

## 5. Cara Kerja Memory

Semua state project disimpan sebagai file JSON di folder `memory/`, **bukan** di memori percakapan — jadi tetap ada walau proses Node.js/VPS restart.

| File | Isi |
|---|---|
| `project.json` | nama/tipe project, status saat ini, struktur file penting, completed/in_progress/todo/failed, next_task |
| `tasks.json` | daftar task + step-nya (status: `pending`, `in_progress`, `blocked`, `failed`, `completed`, `verified`) |
| `changes.json` | log setiap file yang ditulis/diedit/dihapus (otomatis tercatat oleh tools) |
| `errors.json` | log error dari command/compile yang gagal, beserta solusi kalau sudah ditemukan |
| `decisions.json` | keputusan teknis penting beserta alasannya |

Setiap kali kamu kirim perintah, agent membaca ulang semua file ini dan meringkasnya jadi konteks untuk system prompt — termasuk saat kamu bilang **"Lanjutkan"**: agent akan cek `IN_PROGRESS`, `LAST_TASK`, dan `NEXT_TASK`, lalu melanjutkan dari step yang belum selesai (bukan mengulang dari awal).

Prioritas kebenaran kalau ada konflik: **kondisi file aktual > hasil command/test > hasil tool > memory lama > asumsi AI**. Kalau memory bilang sudah selesai tapi filenya belum ada, agent akan percaya file dan memperbaiki memory-nya.

## 6. Tools yang Tersedia untuk Agent

**Wajib (file & shell):**
- `list_files`, `read_file`, `write_file`, `edit_file`, `delete_file`
- `run_command` (dibatasi allowlist binary + blocklist pola berbahaya, lihat `src/security/sandbox.js`)

**Tambahan (memory/task management, dipakai agent secara otonom):**
- `create_task`, `update_task`
- `update_project_state`, `record_decision`
- `update_error`, `search_errors`

## 7. Keamanan

- Semua path dibatasi (sandbox) ke dalam `WORKSPACE` — path traversal (`../..`) ditolak.
- `run_command` cuma boleh menjalankan binary yang ada di allowlist (`ls`, `cat`, `grep`, `node`, `pawncc`, dst — edit `ALLOWED_BINARIES` di `src/security/sandbox.js` kalau perlu tambah).
- Pola command berbahaya (`rm -rf`, `sudo`, `curl`, `wget`, `chmod 777`, fork bomb, dst) diblokir walau binary-nya diizinkan.
- Command punya timeout (`COMMAND_TIMEOUT_MS`) dan batas ukuran output (`MAX_COMMAND_OUTPUT_KB`).
- File punya batas ukuran (`MAX_FILE_SIZE_KB`).
- Menghapus file penting (`server.cfg`, `gamemodes/*.pwn`, `.env`) butuh `confirm=true` eksplisit.

## 8. Testing

```bash
npm test
```

Menjalankan 7 test otomatis (list/read/write/edit file, run command, memory persistence, task continuation). Test ke-8 versi end-to-end lewat LLM (user bilang "lanjutkan" dan agent benar-benar nyambung) butuh `OPENAI_API_KEY` aktif — coba manual lewat `npm start`.

## 9. Roadmap Setelah V1

Setelah V1 stabil, baru ditambahkan:
- Integrasi compiler SA-MP (pawncc) otomatis
- Deteksi dependency/include
- Manajemen plugin & `server.cfg`
- Start/stop/restart server
- Monitoring server & player
- Automated deployment
