# SAMPAI Agent (V2)

AI coding agent berbasis Node.js yang jalan di VPS, khusus untuk membantu development project **SA-MP (San Andreas Multiplayer)**.

**Bisa dilakukan:**
- Baca/tulis/edit/hapus file source code
- Compile `.pwn` dengan parsing error/warning terstruktur (`compile_pawn`)
- Install, start, stop, restart, dan cek status server SA-MP/open.mp (`install_server`, `start_server`, `stop_server`, `restart_server`, `server_status`)
- Memory yang tersimpan permanen di filesystem, sehingga agent tetap ingat kondisi project & server walau Node.js/VPS restart

**Belum dilakukan (roadmap berikutnya):** manajemen plugin/dependency otomatis, monitoring player real-time, automated deployment. Lihat bagian [Roadmap](#9-roadmap-selanjutnya).

---

## 1. Struktur Folder

```
sampai-agent/
├── agent.js                  # entry point CLI (REPL)
├── package.json
├── .env.example
├── .gitignore
├── README.md
│
├── src/
│   ├── agent/
│   │   ├── loop.js           # loop utama: kirim ke LLM, jalankan tool calls, kumpulkan activity log, sampai selesai
│   │   ├── planner.js        # system prompt / aturan kerja agent
│   │   └── context.js        # bangun ringkasan context dari memory (bukan dari chat history)
│   │
│   ├── tools/
│   │   ├── files.js          # list_files, read_file, write_file, edit_file, delete_file
│   │   ├── shell.js          # run_command
│   │   ├── compiler.js       # compile_pawn - compile .pwn + parse error/warning terstruktur
│   │   ├── server.js         # install_server, start_server, stop_server, restart_server, server_status, read_server_log
│   │   ├── query.js          # query_server_info - protokol UDP resmi SA-MP/open.mp (player count asli)
│   │   ├── network_info.js   # find_free_port, detect_local_ips
│   │   ├── db.js             # db_setup - buat database/user MySQL + jalankan schema.sql
│   │   ├── notify.js         # notify_discord + auto-notify start/stop/restart (Discord Components V2, auto-split pesan panjang)
│   │   └── index.js          # tool schema (function calling) + dispatcher
│   │
│   ├── memory/
│   │   ├── manager.js        # generic read/write JSON yang aman & atomik
│   │   ├── project.js        # project.json + decisions.json
│   │   ├── tasks.js          # tasks.json
│   │   ├── changes.js        # changes.json
│   │   └── errors.js         # errors.json
│   │
│   ├── security/
│   │   ├── sandbox.js        # path validation, command allowlist/blocklist, file size limit
│   │   └── network.js        # allowlist host untuk download_url (install_server)
│   │
│   └── utils/
│       └── logger.js
│
├── memory/                   # DISIMPAN DI FILESYSTEM, bertahan lintas restart
│   ├── project.json
│   ├── tasks.json
│   ├── changes.json
│   ├── errors.json
│   └── decisions.json
│
├── logs/
│   ├── agent.log
│   ├── tool.log
│   ├── task.log
│   └── error.log
│
├── workspace/
│   └── gamemodes/
│       └── login_freeroam.pwn  # gamemode freeroam + sistem login (siap compile)
│
└── test/
    └── run-tests.js
```

## 2. Instalasi

Di VPS (Ubuntu/Debian, Node.js >= 18):

```bash
cd sampai-agent
npm install
cp .env.example .env
nano .env   # isi API key & endpoint
```

## 3. Konfigurasi API (`.env`)

Agent memakai API OpenAI-compatible, jadi bisa dipakai dengan provider apa pun yang kompatibel — termasuk **NaraRouter**:

```env
OPENAI_API_KEY=sk-xxxxxxxxxxxxxxxxxxxxxxxxxx
OPENAI_BASE_URL=https://router.bynara.id/v1
OPENAI_MODEL=agnes-2.5-flash

WORKSPACE=./workspace
MAX_TOOL_ITERATIONS=25
COMMAND_TIMEOUT_MS=30000
MAX_FILE_SIZE_KB=1024
MAX_COMMAND_OUTPUT_KB=64
```

Ganti `OPENAI_API_KEY` dengan API key asli dari dashboard NaraRouter kamu (jangan pernah commit `.env` ke git — sudah di-`.gitignore`). Model yang dipakai harus mendukung **function calling / tool use**; `agnes-2.5-flash` di screenshot dashboard kamu kompatibel dengan endpoint `/v1/chat/completions` ala OpenAI, jadi tinggal pakai konfigurasi di atas.

## 4. Menjalankan Agent

```bash
npm start
```

Lalu ketik perintah, misalnya:

```
> Baca source gamemode ini dan pahami strukturnya.
> Buatkan sistem login.
> Tambahkan command /veh.
> Apa yang belum selesai?
> Lanjutkan.
```

Ketik `exit` untuk keluar.

## 5. Cara Kerja Memory

Semua state project disimpan sebagai file JSON di folder `memory/`, **bukan** di memori percakapan — jadi tetap ada walau proses Node.js/VPS restart.

| File | Isi |
|---|---|
| `project.json` | nama/tipe project, status saat ini, struktur file penting, completed/in_progress/todo/failed, next_task |
| `tasks.json` | daftar task + step-nya (status: `pending`, `in_progress`, `blocked`, `failed`, `completed`, `verified`) |
| `changes.json` | log setiap file yang ditulis/diedit/dihapus (otomatis tercatat oleh tools) |
| `errors.json` | log error dari command/compile yang gagal, beserta solusi kalau sudah ditemukan |
| `decisions.json` | keputusan teknis penting beserta alasannya |
| `server.json` | status server (installed, install_dir, binary, cwd, args, pid, status, port, started_at/stopped_at) |

Setiap kali kamu kirim perintah, agent membaca ulang semua file ini dan meringkasnya jadi konteks untuk system prompt — termasuk saat kamu bilang **"Lanjutkan"**: agent akan cek `IN_PROGRESS`, `LAST_TASK`, dan `NEXT_TASK`, lalu melanjutkan dari step yang belum selesai (bukan mengulang dari awal).

Prioritas kebenaran kalau ada konflik: **kondisi file aktual > hasil command/test > hasil tool > memory lama > asumsi AI**. Kalau memory bilang sudah selesai tapi filenya belum ada, agent akan percaya file dan memperbaiki memory-nya.

## 6. Tools yang Tersedia untuk Agent

**Wajib (file & shell):**
- `list_files`, `read_file`, `write_file`, `edit_file`, `delete_file`
- `run_command` (dibatasi allowlist binary + blocklist pola berbahaya, lihat `src/security/sandbox.js`)

**Compiler:**
- `compile_pawn` - compile file `.pwn` pakai pawncc, hasilnya otomatis diparse jadi diagnostics terstruktur (file, line, code, severity, message). Setiap error/fatal error otomatis tercatat ke error memory (dengan dedupe - error yang sama di file+line yang sama tidak dicatat dobel). Agent dipandu lewat system prompt untuk selalu pakai tool ini (bukan `run_command`) setiap kali perlu compile/verify perubahan pada `.pwn`.

**Server management:**
- `install_server` - ekstrak arsip server (`.zip`/`.tar.gz`/`.tgz`/`.tar`) ke workspace. Sumbernya HARUS salah satu dari: (a) file yang sudah kamu upload sendiri ke workspace (`source_archive`), atau (b) URL `https://` dari host yang ada di allowlist (`src/security/network.js`) — default: GitHub (untuk open.mp) dan `files.sa-mp.com`. Host lain otomatis ditolak.
- `start_server` - jalankan binary server sebagai proses background yang tetap hidup walau sesi chat/agent sudah selesai. PID & konfigurasi (binary/cwd/args/port) disimpan ke `server.json`.
- `stop_server` - kirim `SIGTERM`, tunggu sampai `SERVER_STOP_TIMEOUT_MS` (default 8 detik), kalau belum berhenti baru `SIGKILL`.
- `restart_server` - stop lalu start lagi otomatis pakai konfigurasi terakhir yang tersimpan (tidak perlu sebut ulang binary/cwd/args).
- `server_status` - cek apakah proses (PID) masih hidup, sejak kapan jalan, binary & port yang dipakai. **Catatan:** ini cek proses OS, bukan query protokol game SA-MP penuh (jumlah player online real-time, dsb).
- `read_server_log` - baca N baris terakhir `logs/server-stdout.log`/`server-stderr.log`. Dipakai agent buat verifikasi server BENERAN online (PID hidup doang nggak cukup, bisa aja proses hidup tapi stuck di error startup).
- `query_server_info` - query info server **lewat protokol UDP resmi SA-MP/open.mp** (implementasi sesuai [dokumentasi resmi open.mp](https://open.mp/docs/tutorials/QueryMechanism)), balikin hostname, gamemode, language, dan **JUMLAH PLAYER ONLINE BENERAN** — bukan cuma cek proses kayak `server_status`. Kalau timeout, itu tanda ada masalah (port salah, firewall UDP, server belum selesai boot) walau proses OS-nya masih hidup.

**Database:**
- `db_setup` - bikin database + user MySQL/MariaDB baru (opsional jalankan `.sql` schema), balikin kredensialnya.
- `db_query` - jalankan satu query SQL (pakai kredensial admin dari `.env`) dan lihat hasilnya sebagai teks tabel langsung di chat. **Alternatif phpMyAdmin tanpa perlu install PHP/web server sama sekali** — cocok buat `SHOW TABLES`, `SELECT`, `DESCRIBE`, atau operasi kelola data lain. `DROP DATABASE`/`DROP SCHEMA` ditolak (terlalu destruktif buat dijalankan otomatis), dan cuma boleh satu statement per panggilan.

Lihat bagian [Database](#database-mysqlmariadb) di bawah untuk batasannya.

**Notifikasi:**
- `notify_discord` - kirim pesan custom ke Discord lewat webhook. `start_server`/`stop_server`/`restart_server` juga **otomatis** kirim notifikasi (🟢 online / 🔴 offline) tanpa perlu dipanggil manual — asal `DISCORD_WEBHOOK_URL` sudah diisi di `.env`. Kalau belum diisi, fitur ini diam-diam nonaktif (bukan error).

Output & error server berjalan disimpan di `logs/server-stdout.log` dan `logs/server-stderr.log`.

### IP & Port - cara tahu alamat buat connect

- **Format config dideteksi otomatis**: SA-MP legacy pakai `server.cfg` (teks), **open.mp modern (default) pakai `config.json`** (`network.port`, `network.bind`, `rcon.password`). `start_server`/`server_status` baca dua-duanya otomatis — hasilnya punya field `config_format` biar kamu tahu mana yang kepakai.
- **Penting buat open.mp**: server **menolak start total** kalau `rcon.password` di `config.json` masih default `"changeme"`. Agent otomatis cek ini sebelum/saat start dan kasih `warning` di hasilnya kalau masih default — pastikan sudah diganti sebelum `start_server`.
- **Port**: `start_server` otomatis membaca port dari `config.json`/`server.cfg` — bukan dari parameter yang kamu kasih (itu cuma fallback kalau filenya tidak ada). Hasilnya dikembalikan sebagai field `port` + `port_source`.
- `server_status` juga menampilkan `configured_port` (dibaca ulang dari `server.cfg` saat itu juga) terpisah dari `port` (port yang dipakai proses yang SEDANG jalan). Kalau kamu edit `server.cfg` tanpa restart server, dua angka ini bisa beda — itu tandanya server perlu di-`restart_server` biar port barunya kepakai.
- **IP**: SA-MP/open.mp defaultnya listen di semua network interface (`0.0.0.0`), jadi yang dipakai player untuk connect adalah **IP publik VPS kamu** — bukan sesuatu yang diatur lewat `server.cfg` (kecuali kamu isi baris `bind` ke IP tertentu). Agent bisa lihat IP VPS lewat `run_command` dengan `hostname -I` kalau kamu tanya.

### Auto-setting port kosong & IP di server.cfg

Kalau kamu minta agent "pasang port yang tersedia" atau "bentrok port, cariin yang kosong", agent akan:
1. Panggil `find_free_port` — ini **beneran nyoba bind ke port UDP** (bukan nebak), mulai dari port yang ada di `server.cfg` sekarang, naik terus sampai ketemu yang kosong.
2. Tulis hasilnya ke `server.cfg` pakai `edit_file`.
3. `start_server` otomatis baca ulang port yang baru itu dari `server.cfg`.

Kalau kamu minta isi baris `bind` dengan IP VPS, agent akan panggil `detect_local_ips` dulu (baca langsung dari network interface OS, bukan nebak) dan pakai salah satu IP yang `internal: false` dari situ. **Catatan:** kalau VPS-mu di belakang NAT/load balancer, IP yang nempel di interface OS bisa beda dari IP publik yang dikasih provider — kalau ragu, cek dashboard VPS kamu. Dan sebenarnya `bind` ini opsional: server SA-MP/open.mp defaultnya sudah bisa diakses lewat IP publik VPS tanpa perlu diisi sama sekali, kecuali VPS kamu punya banyak IP dan mau dipaksa pakai salah satu spesifik.

### Database (MySQL/MariaDB)

**Penting:** agent **TIDAK menginstall MySQL/MariaDB, PHP, web server, atau phpMyAdmin**. Itu semua instalasi software level sistem (`apt install`, `systemctl`, akses root, edit file di `/etc/`) yang memang sengaja di luar sandbox agent ini — command seperti `sudo`, `apt-get install`, `systemctl` diblokir permanen (lihat bagian Keamanan). Install MySQL/MariaDB sendiri dulu (manual, atau lewat one-click installer dari provider VPS kamu), baru agent bisa bantu bagian berikutnya:

1. Isi `DB_HOST`, `DB_PORT`, `DB_ADMIN_USER`, `DB_ADMIN_PASSWORD` di `.env` dengan kredensial admin MySQL yang sudah kamu install.
2. Minta agent bikin database + user baru buat project SA-MP kamu — dia akan pakai tool **`db_setup`**: bikin database & user MySQL baru (bukan pakai user admin), opsional langsung jalankan file `.sql` schema kalau kamu punya, lalu balikin kredensialnya. Kalau kamu nggak kasih password, sistem generate password acak yang aman dan agent **wajib menampilkannya** ke kamu di jawabannya (dicatat sekali saja, tidak diulang-ulang).
3. **Mau lihat/kelola isi database tanpa install phpMyAdmin?** Tinggal minta di chat, mis. *"tampilkan isi tabel players"* atau *"database apa aja yang ada"* — agent pakai **`db_query`** buat jalanin SQL-nya langsung dan tunjukkin hasilnya. Ini jauh lebih ringan daripada install PHP+Apache+phpMyAdmin cuma buat ngintip data. Kalau kamu tetap mau phpMyAdmin beneran (versi web GUI-nya), itu tetap instalasi manual seperti disebut di atas.
4. Password kredensial **tidak pernah tersimpan di `logs/tool.log`** — field apa pun yang namanya mengandung "password" otomatis di-redact sebelum ditulis ke log.
5. Kredensial connection MySQL yang di-generate itu masih perlu ditulis manual ke config project kamu (via `edit_file`) — formatnya beda-beda tergantung plugin MySQL yang dipakai gamemode kamu (mis. `#define` di `.pwn`, atau file `.ini` terpisah untuk plugin sscanf/mysql), jadi agent akan tanya/cek dulu formatnya sebelum nulis.

### Notifikasi Discord

1. Di server Discord kamu: **Server Settings → Integrations → Webhooks → New Webhook**, copy URL-nya.
2. Isi ke `.env`: `DISCORD_WEBHOOK_URL=https://discord.com/api/webhooks/...`
3. Selesai — `start_server`/`stop_server`/`restart_server` otomatis kirim notifikasi ke channel itu, nggak perlu setting lain.

**Batasan:** ini cuma notifikasi untuk aksi yang DIPICU lewat chat (kamu minta start/stop/restart). Kalau server crash sendiri di luar itu (bukan lewat `stop_server`), belum ada yang otomatis kedeteksi/notify — itu butuh fitur watchdog terpisah yang belum dibangun. Webhook cuma nerima dari `discord.com`/`discordapp.com` (dan varian ptb/canary) lewat HTTPS — URL lain otomatis ditolak.

**Format pesan:** pakai [Discord Components V2](https://docs.discord.com/developers/components/reference) (Container, tipe 17) yang polos — tanpa warna/accent bar seperti embed biasa, cuma teks markdown biasa. Kalau isi pesan kepanjangan (lebih dari ~3800 karakter), otomatis **kepecah jadi beberapa message berurutan** dengan penanda `(lanjutan 2/4)`, `(lanjutan 3/4)`, dst — bukan dipotong/hilang sebagian.

### Activity log - "apa aja yang barusan dikerjain agent"

Selain notifikasi online/offline, ada **ringkasan aktivitas per perintah kamu** yang otomatis terkirim ke Discord (asal `DISCORD_WEBHOOK_URL` diisi) — isinya daftar semua tool yang dipanggil di request itu (`run_command`, `write_file`, `edit_file`, `compile_pawn`, dst) beserta target dan status sukses/gagalnya. Contoh isi notifikasinya:

```
✅ `run_command` `pawncc gamemodes/main.pwn`
✅ `edit_file` `gamemodes/main.pwn`
✅ `compile_pawn` `gamemodes/main.pwn`
```

**Kenapa dikumpulin jadi 1 rangkaian pesan, bukan real-time per tool call:** Discord webhook punya rate limit ketat (~30 pesan/menit). Satu perintah ke agent bisa memicu belasan tool call (udah keliatan di semua test sepanjang percakapan ini) — kalau tiap tool call langsung kirim pesan sendiri, bisa kena throttle/drop pas task lagi rame-ramenya. Jadi didesain: kumpul dulu selama 1 request berjalan (maksimum 30 baris tool call, dipotong dengan keterangan "+N aksi lainnya" kalau lebih), lalu kirim begitu agent selesai merespons — otomatis kepecah jadi beberapa message Container V2 berurutan kalau ternyata masih kepanjangan setelah digabung jadi teks.

Mau matiin ini (cuma pengen notifikasi online/offline server aja, tanpa detail tool call)? Set `DISCORD_ACTIVITY_LOG=false` di `.env`.

### Perintah "jalankan &lt;folder&gt;" / online-kan server end-to-end

Kalau kamu minta agent nge-online-kan satu project sampai bener-bener jalan, dia akan urut: pahami struktur project → setup database kalau perlu (lihat batasan di atas) → `compile_pawn` (perbaiki error kalau ada) → cek/atur port → `start_server`/`restart_server` → cek `server_status` + `read_server_log` + `query_server_info` buat mastiin beneran online (PID hidup, log bersih, DAN port UDP-nya beneran bisa diakses) → lapor status akhir + IP:port buat connect. Kalau ada langkah yang gagal/butuh sesuatu darimu (mis. MySQL belum di-install), agent akan berhenti di situ dan bilang jujur apa yang masih kurang — bukan mengarang bahwa semuanya sudah beres.

**Tambahan (memory/task management, dipakai agent secara otonom):**
- `create_task`, `update_task`
- `update_project_state`, `record_decision`
- `update_error`, `search_errors`

### Konfigurasi compiler

Set `PAWNCC_PATH` di `.env`:

```env
PAWNCC_PATH=pawncc          # kalau pawncc sudah ada di $PATH
# atau
PAWNCC_PATH=/opt/pawncc/pawncc   # path absolut ke binary
```

`compile_pawn` menjalankan compiler di folder tempat file `.pwn` berada, lalu hasil `.amx` dibuat di folder yang sama. Task/step baru dianggap **`verified`** oleh agent hanya kalau `compile_pawn` benar-benar berhasil (tidak ada error/fatal error) - bukan cuma karena file berhasil ditulis.

## 7. Keamanan

- Semua path dibatasi (sandbox) ke dalam `WORKSPACE` — path traversal (`../..`) ditolak.
- `run_command` cuma boleh menjalankan binary yang ada di allowlist (`ls`, `cat`, `grep`, `node`, `pawncc`, `unzip`, `tar`, dst — edit `ALLOWED_BINARIES` di `src/security/sandbox.js` kalau perlu tambah).
- Pola command berbahaya (`rm -rf`, `sudo`, `curl`, `wget`, `chmod 777`, fork bomb, dst) diblokir walau binary-nya diizinkan.
- Command punya timeout (`COMMAND_TIMEOUT_MS`) dan batas ukuran output (`MAX_COMMAND_OUTPUT_KB`).
- File punya batas ukuran (`MAX_FILE_SIZE_KB`).
- Menghapus file penting (`server.cfg`, `gamemodes/*.pwn`, `.env`) butuh `confirm=true` eksplisit.
- `install_server` cuma boleh download dari host di allowlist (`src/security/network.js`) lewat `https://` — bukan lewat `curl`/`wget` shell yang memang sengaja diblokir. Ekstraksi arsip & argumen `start_server`/`compile_pawn` dieksekusi lewat `spawn`/`spawnSync` dengan argv array (bukan string shell), jadi nama file atau argumen aneh-aneh tidak bisa dipakai untuk command injection.
- `start_server` menjalankan binary langsung (bukan lewat shell) dan wajib berada di dalam `WORKSPACE`.
- `stop_server` mengirim `SIGTERM` dulu (graceful shutdown), baru `SIGKILL` kalau proses tidak berhenti dalam `SERVER_STOP_TIMEOUT_MS`.

## 8. Testing

```bash
npm test
```

Menjalankan 7 test otomatis (list/read/write/edit file, run command, memory persistence, task continuation). Test ke-8 versi end-to-end lewat LLM (user bilang "lanjutkan" dan agent benar-benar nyambung) butuh `OPENAI_API_KEY` aktif — coba manual lewat `npm start`.

Fitur compiler & server management sudah diuji manual (parsing diagnostics pawncc, dedupe error, install/start/status/stop/restart pakai binary dummy, dan penolakan host yang tidak di-allowlist) — tapi belum ada test otomatis untuk ini di `npm test` karena butuh binary pawncc/server SA-MP asli. Kalau mau, tambahkan test terpisah yang jalan hanya kalau binary-binary itu tersedia di environment kamu.

## 9. Pengetahuan SAMP Roleplay (Faction/Job/House/Inventory)

Agent sekarang punya baseline pengetahuan domain buat sistem roleplay yang paling umum, ditanam langsung di system prompt (bukan cuma nurut instruksi user mentah-mentah). Ini dipakai otomatis kapan pun kamu minta bikin/ubah sistem faction, job, atau house:

- **Virtual world** — interior rumah/HQ faction wajib dikasih virtual world ID unik per instance, biar player di house berbeda nggak saling kelihatan (bug klasik kalau dilewatkan).
- **Data structure** — pakai `enum` buat struct data (`e_HOUSE_DATA`, `e_FACTION_DATA`, dst), bukan array terpisah-pisah per field.
- **Persistence** — query MySQL wajib lewat callback threaded (`mysql_tquery`), bukan blocking sinkron; pakai `mysql_format` buat cegah SQL injection dari input player.
- **Faction** — command minimal (`/f`, `/finvite`, `/fkick`, `/frank`), validasi rank sebelum eksekusi aksi (bukan cuma cek status member).
- **Job** — pola state machine per player (idle → pickup → delivery → dibayar), checkpoint pakai `streamer` kalau titiknya banyak/tersebar, ada cooldown biar nggak bisa di-farming.
- **House** — beli/jual/lock, teleport exterior↔interior dengan virtual world yang bener, owner di-reference ke akun (bukan nama karakter mentah).
- **Inventory/Item** — item stackable vs non-stackable beda perlakuan slot, weight limit dicek SEBELUM item ditambah (bukan sesudah), ground item ada auto-cleanup, dan yang paling penting: **validasi kepemilikan+quantity item di server sebelum transaksi apa pun** — jangan percaya itemID dari client mentah-mentah (celah exploit paling umum di sistem inventory RP).

Kalau requirement kamu samar, agent terapkan baseline ini dan **sebutkan asumsi yang diambil** di jawaban akhir — bukan diam-diam nebak.

## 10. Roadmap Selanjutnya

Sudah selesai: coding + memory, compiler integration, server install/start/stop/restart/status, database (setup+query), notifikasi & activity log Discord, query player count asli (protokol UDP resmi), pengetahuan RP faction/job/house/inventory.

Belum ada, direncanakan berikutnya:
- Auto-restart kalau server crash (watchdog) - tipe notifikasi "crash" sudah disiapkan di `notify.js`, tinggal dipasang trigger-nya
- Auto-fetch include library umum (sscanf2, streamer, dst) kalau compile gagal karena belum ada
- Backup otomatis (gamemode + database) terjadwal
- Deteksi plugin yang didaftarkan di config tapi file-nya belum ada, sebelum start_server
- Git auto-commit per task selesai (history/rollback point)
