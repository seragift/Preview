# samp-project (contoh)

Ini adalah project SA-MP contoh/stub untuk mencoba SAMPAI Agent. Isinya sengaja minimal:

- `gamemodes/main.pwn` - gamemode dasar dengan `OnGameModeInit`, `OnPlayerConnect`, dll.
- `server.cfg` - contoh konfigurasi server.
- `filterscripts/`, `includes/` - folder kosong, siap dipakai.

Kamu bisa ganti isi folder ini dengan project SA-MP asli kamu, lalu jalankan agent dan minta:

```
Baca source gamemode ini dan pahami strukturnya.
```
