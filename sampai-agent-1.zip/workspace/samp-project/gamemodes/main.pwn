#include <a_samp>

#define GAMEMODE_NAME "SAMPAI Test Gamemode"

public OnGameModeInit()
{
    SetGameModeText(GAMEMODE_NAME);
    print("=== " GAMEMODE_NAME " dimuat ===");
    return 1;
}

public OnGameModeExit()
{
    print("=== " GAMEMODE_NAME " dimatikan ===");
    return 1;
}

public OnPlayerConnect(playerid)
{
    SendClientMessage(playerid, 0xFFFFFFFF, "Selamat datang di SAMPAI Test Server.");
    return 1;
}

public OnPlayerDisconnect(playerid, reason)
{
    return 1;
}

main()
{
    print("Contoh project - dibuat untuk testing SAMPAI Agent (V1)");
}
