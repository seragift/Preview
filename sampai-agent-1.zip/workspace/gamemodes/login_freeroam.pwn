#include <a_samp>

// ============================================================
// FREEROAM + LOGIN SYSTEM - contoh gamemode dari nol
// Cuma butuh a_samp.inc standar - TIDAK ada dependency plugin
// luar (mysql/whirlpool/dll), supaya bisa langsung dicompile
// dengan pawncc biasa tanpa setup tambahan.
//
// CATATAN KEAMANAN: SimpleHash() di bawah BUKAN hash yang aman
// secara kriptografis - ini cuma demo supaya password nggak
// kesimpen plaintext. Untuk server production, ganti dengan
// plugin whirlpool/bcrypt (butuh setup terpisah).
//
// CATATAN SETUP: folder "scriptfiles/users/" harus dibuat
// manual sekali sebelum server dijalankan - SA-MP/open.mp
// tidak bisa mkdir folder baru lewat native Pawn.
// ============================================================

#define COLOR_WHITE     0xFFFFFFFF
#define COLOR_GREEN     0x33AA33FF
#define COLOR_RED       0xAA3333FF
#define COLOR_YELLOW    0xFFFF00FF

#define DIALOG_REGISTER 1
#define DIALOG_LOGIN    2

#define MAX_LOGIN_ATTEMPTS 3

new gLoggedIn[MAX_PLAYERS];
new gLoginAttempts[MAX_PLAYERS];

public OnGameModeInit()
{
    SetGameModeText("Freeroam + Login v1");
    AddPlayerClass(0, 1958.3783, 1343.1572, 15.3746, 269.1425, 0, 0, 0, 0, 0, 0);

    print("Gamemode dimuat: Freeroam + Login System");
    print("PENTING: pastikan folder scriptfiles/users/ sudah dibuat manual.");
    return 1;
}

public OnGameModeExit()
{
    return 1;
}

public OnPlayerConnect(playerid)
{
    gLoggedIn[playerid] = 0;
    gLoginAttempts[playerid] = 0;

    TogglePlayerSpawn(playerid, 0);
    SetPlayerPos(playerid, 1958.3783, 1343.1572, 15.3746);
    SetPlayerCameraPos(playerid, 1963.3783, 1343.1572, 20.3746);
    SetPlayerCameraLookAt(playerid, 1958.3783, 1343.1572, 15.3746);

    new name[MAX_PLAYER_NAME];
    GetPlayerName(playerid, name, sizeof(name));

    new file[64];
    format(file, sizeof(file), "users/%s.txt", name);

    if (fexist(file))
    {
        ShowPlayerDialog(playerid, DIALOG_LOGIN, DIALOG_STYLE_PASSWORD,
            "Login", "Akun ini sudah terdaftar.\nMasukkan password kamu:", "Login", "Keluar");
    }
    else
    {
        ShowPlayerDialog(playerid, DIALOG_REGISTER, DIALOG_STYLE_PASSWORD,
            "Daftar Akun", "Akun belum terdaftar.\nBuat password baru (min. 4 karakter):", "Daftar", "Keluar");
    }
    return 1;
}

public OnPlayerDisconnect(playerid, reason)
{
    gLoggedIn[playerid] = 0;
    return 1;
}

public OnDialogResponse(playerid, dialogid, response, listitem, inputtext[])
{
    new name[MAX_PLAYER_NAME];
    GetPlayerName(playerid, name, sizeof(name));

    new file[64];
    format(file, sizeof(file), "users/%s.txt", name);

    if (dialogid == DIALOG_REGISTER)
    {
        if (!response)
        {
            Kick(playerid);
            return 1;
        }
        if (strlen(inputtext) < 4)
        {
            ShowPlayerDialog(playerid, DIALOG_REGISTER, DIALOG_STYLE_PASSWORD,
                "Daftar Akun", "Password minimal 4 karakter.\nBuat password baru:", "Daftar", "Keluar");
            return 1;
        }

        new hashed[16];
        SimpleHash(inputtext, hashed, sizeof(hashed));

        new File:f = fopen(file, io_write);
        if (f)
        {
            fwrite(f, hashed);
            fclose(f);
        }

        gLoggedIn[playerid] = 1;
        SendClientMessage(playerid, COLOR_GREEN, "Akun berhasil dibuat. Selamat datang!");
        TogglePlayerSpawn(playerid, 1);
        SpawnPlayer(playerid);
    }
    else if (dialogid == DIALOG_LOGIN)
    {
        if (!response)
        {
            Kick(playerid);
            return 1;
        }

        new storedHash[16];
        new File:f = fopen(file, io_read);
        if (f)
        {
            fread(f, storedHash);
            fclose(f);
        }

        new inputHash[16];
        SimpleHash(inputtext, inputHash, sizeof(inputHash));

        if (strcmp(storedHash, inputHash, false) == 0)
        {
            gLoggedIn[playerid] = 1;
            SendClientMessage(playerid, COLOR_GREEN, "Login berhasil. Selamat datang kembali!");
            TogglePlayerSpawn(playerid, 1);
            SpawnPlayer(playerid);
        }
        else
        {
            gLoginAttempts[playerid]++;
            if (gLoginAttempts[playerid] >= MAX_LOGIN_ATTEMPTS)
            {
                SendClientMessage(playerid, COLOR_RED, "Password salah 3 kali. Kamu di-kick.");
                Kick(playerid);
            }
            else
            {
                ShowPlayerDialog(playerid, DIALOG_LOGIN, DIALOG_STYLE_PASSWORD,
                    "Login", "Password salah. Coba lagi:", "Login", "Keluar");
            }
        }
    }
    return 1;
}

public OnPlayerSpawn(playerid)
{
    if (!gLoggedIn[playerid]) return 1;

    SetPlayerHealth(playerid, 100.0);
    SetPlayerArmour(playerid, 0.0);
    GivePlayerWeapon(playerid, 24, 100);
    SendClientMessage(playerid, COLOR_WHITE, "Ketik /help untuk lihat command yang tersedia.");
    return 1;
}

public OnPlayerCommandText(playerid, cmdtext[])
{
    if (!gLoggedIn[playerid])
    {
        SendClientMessage(playerid, COLOR_RED, "Kamu harus login dulu.");
        return 1;
    }

    if (strcmp(cmdtext, "/help", true) == 0)
    {
        SendClientMessage(playerid, COLOR_YELLOW, "Command: /help, /heal, /armor");
        return 1;
    }
    if (strcmp(cmdtext, "/heal", true) == 0)
    {
        SetPlayerHealth(playerid, 100.0);
        SendClientMessage(playerid, COLOR_GREEN, "Health kamu sudah dipulihkan.");
        return 1;
    }
    if (strcmp(cmdtext, "/armor", true) == 0)
    {
        SetPlayerArmour(playerid, 100.0);
        SendClientMessage(playerid, COLOR_GREEN, "Armor kamu sudah dipulihkan.");
        return 1;
    }
    return 0;
}

// Hash sederhana (BUKAN kriptografis aman) - cuma supaya password
// nggak kesimpen plaintext di file. Lihat catatan keamanan di atas.
stock SimpleHash(text[], result[], maxlen)
{
    new sum = 0;
    for (new i = 0; i < strlen(text); i++)
    {
        sum = (sum * 31 + text[i]) & 0x7FFFFFF;
    }
    format(result, maxlen, "%d", sum);
    return 1;
}
