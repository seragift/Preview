'use strict';
require('dotenv').config();
const path = require('path');
const fs = require('fs');
const readline = require('readline');
const { createLoop } = require('./src/agent/loop');
const { makeLogger } = require('./src/utils/logger');

const ROOT = __dirname;
const WORKSPACE = path.resolve(ROOT, process.env.WORKSPACE || './workspace');
const MEMORY_DIR = path.join(ROOT, 'memory');
const LOGS_DIR = path.join(ROOT, 'logs');

function assertEnv() {
  const required = ['OPENAI_API_KEY', 'OPENAI_BASE_URL', 'OPENAI_MODEL'];
  const missing = required.filter((k) => !process.env[k]);
  if (missing.length) {
    console.error(`[FATAL] Env var belum diset: ${missing.join(', ')}.`);
    console.error('Salin .env.example ke .env lalu isi OPENAI_API_KEY / OPENAI_BASE_URL / OPENAI_MODEL.');
    process.exit(1);
  }
}

function ensureDirs() {
  [WORKSPACE, MEMORY_DIR, LOGS_DIR].forEach((d) => fs.mkdirSync(d, { recursive: true }));
}

async function main() {
  assertEnv();
  ensureDirs();

  const logger = makeLogger(LOGS_DIR);
  const loop = createLoop({ workspace: WORKSPACE, memoryDir: MEMORY_DIR, logger });

  console.log('=== SAMPAI Agent (V1) - AI Coding Agent untuk project SA-MP ===');
  console.log(`Workspace : ${WORKSPACE}`);
  console.log(`Model     : ${process.env.OPENAI_MODEL} @ ${process.env.OPENAI_BASE_URL}`);
  console.log('Catatan   : V1 belum menangani install/start/stop server SA-MP.');
  console.log('Ketik pesan (mis. "baca source gamemode ini dan pahami strukturnya"), atau "exit" untuk keluar.\n');

  const rl = readline.createInterface({ input: process.stdin, output: process.stdout, prompt: '> ' });
  rl.prompt();

  rl.on('line', async (line) => {
    const input = line.trim();
    if (!input) return rl.prompt();
    if (['exit', 'quit'].includes(input.toLowerCase())) { rl.close(); return; }

    try {
      const reply = await loop.runAgent(input);
      console.log('\n' + reply + '\n');
    } catch (err) {
      console.error('[ERROR]', err.message);
    }
    rl.prompt();
  });

  rl.on('close', () => {
    console.log('Bye.');
    process.exit(0);
  });
}

main();
