'use strict';
const project = require('../memory/project');
const tasks = require('../memory/tasks');
const changes = require('../memory/changes');
const errors = require('../memory/errors');

const CONTINUATION_KEYWORDS = [
  'lanjutkan', 'lanjut', 'terusin', 'teruskan', 'continue', 'resume',
  'pekerjaan sebelumnya', 'pekerjaan terakhir',
];

function isContinuationRequest(text) {
  const t = (text || '').toLowerCase();
  return CONTINUATION_KEYWORDS.some((k) => t.includes(k));
}

function truncate(str, max = 200) {
  if (!str) return str;
  return str.length > max ? str.slice(0, max) + '…' : str;
}

// Membangun ringkasan context dari memory (bukan dari conversation history)
// supaya agent tetap tahu kondisi project walau proses Node.js baru saja restart.
function buildContext(memoryDir) {
  const proj = project.get(memoryDir);
  const lastTask = tasks.getLastActive(memoryDir);
  const recentChanges = changes.recent(memoryDir, 5);
  const openErrors = errors.recent(memoryDir, 10).filter((e) => e.status !== 'resolved').slice(0, 5);
  const decisions = project.getDecisions(memoryDir, 3);

  const summaryText = [
    `PROJECT: ${proj.project.name || '(belum diset)'} | type: ${proj.project.type} | status: ${proj.current_state.status}`,
    `LAST_ACTION: ${proj.current_state.last_action || '-'}`,
    `IN_PROGRESS: ${proj.in_progress.join(', ') || '-'}`,
    `TODO: ${proj.todo.join(', ') || '-'}`,
    `COMPLETED (5 terbaru): ${proj.completed.slice(-5).join(', ') || '-'}`,
    `FAILED: ${proj.failed.join(', ') || '-'}`,
    `NEXT_TASK: ${proj.next_task || '-'}`,
    lastTask
      ? `LAST_TASK: [${lastTask.id}] "${lastTask.title}" (status: ${lastTask.status}) - steps: ${lastTask.steps.map((s) => `${s.title}:${s.status}`).join(', ') || '-'}`
      : 'LAST_TASK: (belum ada task tercatat)',
    `RECENT_CHANGES: ${recentChanges.map((c) => `${c.file}(${c.action})`).join(', ') || '-'}`,
    `OPEN_ERRORS: ${openErrors.map((e) => `[${e.id}] ${truncate(e.error, 80)}`).join(' | ') || '-'}`,
    `RECENT_DECISIONS: ${decisions.map((d) => truncate(d.decision, 60)).join(' | ') || '-'}`,
  ].join('\n');

  return { project: proj, lastTask, recentChanges, openErrors, summaryText };
}

module.exports = { buildContext, isContinuationRequest };
