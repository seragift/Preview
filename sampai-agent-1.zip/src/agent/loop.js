'use strict';
const OpenAI = require('openai');
const { buildContext, isContinuationRequest } = require('./context');
const { buildSystemPrompt } = require('./planner');
const { toolDefinitions, executeTool } = require('../tools/index');
const tasksMem = require('../memory/tasks');
const projectMem = require('../memory/project');

const MAX_ITERATIONS = parseInt(process.env.MAX_TOOL_ITERATIONS || '25', 10);

function createLoop({ workspace, memoryDir, logger }) {
  const client = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY,
    baseURL: process.env.OPENAI_BASE_URL,
  });
  const model = process.env.OPENAI_MODEL;

  async function runAgent(userMessage) {
    const { summaryText, lastTask } = buildContext(memoryDir);
    logger.agent({ event: 'request', message: userMessage });

    // Continuation heuristic: kalau user minta "lanjutkan" dan ada task yang belum kelar,
    // pakai task_id itu sebagai default supaya tool call otomatis nyambung ke task yang sama.
    let taskId = null;
    if (isContinuationRequest(userMessage) && lastTask && !['completed', 'verified'].includes(lastTask.status)) {
      taskId = lastTask.id;
    }

    const systemPrompt = buildSystemPrompt(summaryText, workspace);
    const messages = [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: userMessage },
    ];

    const ctx = { workspace, memoryDir, taskId, logger };
    let iterations = 0;
    let finalText = '';

    while (iterations < MAX_ITERATIONS) {
      iterations += 1;
      let response;
      try {
        response = await client.chat.completions.create({
          model,
          messages,
          tools: toolDefinitions,
          tool_choice: 'auto',
        });
      } catch (err) {
        logger.error({ event: 'api_error', message: err.message });
        return `Terjadi error saat memanggil API model (${process.env.OPENAI_BASE_URL}): ${err.message}`;
      }

      const choice = response.choices && response.choices[0];
      if (!choice) {
        logger.error({ event: 'api_error', message: 'Response tanpa choices.' });
        return 'Model tidak mengembalikan response yang valid.';
      }
      const msg = choice.message;
      messages.push(msg);

      if (!msg.tool_calls || msg.tool_calls.length === 0) {
        finalText = msg.content || '';
        break;
      }

      for (const call of msg.tool_calls) {
        let args = {};
        try { args = JSON.parse(call.function.arguments || '{}'); } catch (_) { /* biarkan args = {} */ }

        const result = await executeTool(call.function.name, args, ctx);

        if (call.function.name === 'create_task' && result && result.id) {
          taskId = result.id;
          ctx.taskId = taskId;
        }

        messages.push({
          role: 'tool',
          tool_call_id: call.id,
          content: JSON.stringify(result).slice(0, 8000),
        });
      }
    }

    if (iterations >= MAX_ITERATIONS && !finalText) {
      finalText = 'Task belum selesai: batas maksimum iterasi tool tercapai (MAX_TOOL_ITERATIONS). Ketik "lanjutkan" untuk melanjutkan dari state terakhir.';
      if (taskId) {
        await tasksMem.updateStatus(memoryDir, taskId, 'blocked', { note: 'Max tool iterations reached' }).catch(() => {});
      }
    }

    await projectMem.patch(memoryDir, { current_state: { last_action: userMessage.slice(0, 200) } }).catch(() => {});
    logger.agent({ event: 'response', iterations, taskId, length: finalText.length });
    return finalText;
  }

  return { runAgent };
}

module.exports = { createLoop };
