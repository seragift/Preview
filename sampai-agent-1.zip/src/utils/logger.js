'use strict';
const fs = require('fs');
const path = require('path');

function makeLogger(logsDir) {
  fs.mkdirSync(logsDir, { recursive: true });

  function writeLine(fileName, obj) {
    const line = JSON.stringify({ timestamp: new Date().toISOString(), ...obj }) + '\n';
    fs.appendFileSync(path.join(logsDir, fileName), line, 'utf8');
  }

  return {
    agent: (obj) => writeLine('agent.log', obj),
    tool: (obj) => writeLine('tool.log', obj),
    task: (obj) => writeLine('task.log', obj),
    error: (obj) => writeLine('error.log', obj),
  };
}

module.exports = { makeLogger };
