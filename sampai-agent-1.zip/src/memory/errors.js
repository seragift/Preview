'use strict';
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const manager = require('./manager');

function file(memoryDir) { return path.join(memoryDir, 'errors.json'); }
const DEFAULT = { errors: [] };

async function record(memoryDir, { error, file: filePath, line, cause, solution, status, task_id }) {
  const entry = {
    id: 'err-' + uuidv4().slice(0, 8),
    error,
    file: filePath || null,
    line: line || null,
    cause: cause || null,
    solution: solution || null,
    status: status || 'open',
    task_id: task_id || null,
    timestamp: new Date().toISOString(),
  };
  await manager.update(file(memoryDir), DEFAULT, (current) => {
    current.errors.push(entry);
    return current;
  });
  return entry;
}

async function updateStatus(memoryDir, id, status, solution) {
  await manager.update(file(memoryDir), DEFAULT, (current) => {
    const e = current.errors.find((x) => x.id === id);
    if (!e) throw new Error(`Error ${id} tidak ditemukan.`);
    e.status = status;
    if (solution) e.solution = solution;
    return current;
  });
  return manager.readJSON(file(memoryDir), DEFAULT).errors.find((x) => x.id === id);
}

function search(memoryDir, query) {
  const q = (query || '').toLowerCase();
  return manager.readJSON(file(memoryDir), DEFAULT).errors.filter((e) =>
    (e.error || '').toLowerCase().includes(q) || (e.cause || '').toLowerCase().includes(q)
  );
}

function recent(memoryDir, limit = 10) {
  return manager.readJSON(file(memoryDir), DEFAULT).errors.slice(-limit).reverse();
}

module.exports = { record, updateStatus, search, recent };
