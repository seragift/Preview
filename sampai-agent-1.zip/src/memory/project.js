'use strict';
const path = require('path');
const manager = require('./manager');

function projectFile(memoryDir) { return path.join(memoryDir, 'project.json'); }
function decisionsFile(memoryDir) { return path.join(memoryDir, 'decisions.json'); }

const DEFAULT_PROJECT = {
  project: { name: '', path: '', type: 'samp-gamemode', description: '' },
  current_state: { status: 'uninitialized', version: '0.0.1', last_action: '' },
  structure: {
    important_files: [], entry_points: [], gamemodes: [],
    filterscripts: [], includes: [], plugins: [], configs: [],
  },
  completed: [],
  in_progress: [],
  todo: [],
  failed: [],
  next_task: '',
  updated_at: null,
};

const DEFAULT_DECISIONS = { decisions: [] };

function get(memoryDir) {
  return manager.readJSON(projectFile(memoryDir), DEFAULT_PROJECT);
}

async function patch(memoryDir, partial) {
  return manager.update(projectFile(memoryDir), DEFAULT_PROJECT, (current) => {
    const merged = { ...current, ...partial, updated_at: new Date().toISOString() };
    if (partial.structure) merged.structure = { ...current.structure, ...partial.structure };
    if (partial.current_state) merged.current_state = { ...current.current_state, ...partial.current_state };
    if (partial.project) merged.project = { ...current.project, ...partial.project };
    return merged;
  });
}

async function addDecision(memoryDir, decision, reason) {
  return manager.update(decisionsFile(memoryDir), DEFAULT_DECISIONS, (current) => {
    current.decisions.push({ decision, reason: reason || '', timestamp: new Date().toISOString() });
    return current;
  });
}

function getDecisions(memoryDir, limit = 20) {
  return manager.readJSON(decisionsFile(memoryDir), DEFAULT_DECISIONS).decisions.slice(-limit).reverse();
}

module.exports = { get, patch, addDecision, getDecisions, DEFAULT_PROJECT };
