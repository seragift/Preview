'use strict';
const path = require('path');
const manager = require('./manager');

function file(memoryDir) { return path.join(memoryDir, 'changes.json'); }
const DEFAULT = { changes: [] };
const MAX_KEEP = 500;

async function record(memoryDir, { file: filePath, action, description, task_id }) {
  const entry = {
    timestamp: new Date().toISOString(),
    file: filePath,
    action,
    description: description || '',
    task_id: task_id || null,
  };
  await manager.update(file(memoryDir), DEFAULT, (current) => {
    current.changes.push(entry);
    if (current.changes.length > MAX_KEEP) current.changes = current.changes.slice(-MAX_KEEP);
    return current;
  });
  return entry;
}

function recent(memoryDir, limit = 10) {
  const changes = manager.readJSON(file(memoryDir), DEFAULT).changes;
  return changes.slice(-limit).reverse();
}

function forFile(memoryDir, filePath) {
  return manager.readJSON(file(memoryDir), DEFAULT).changes.filter((c) => c.file === filePath);
}

module.exports = { record, recent, forFile };
