'use strict';
const fs = require('fs');
const path = require('path');

// Antrian promise per file supaya read-modify-write tidak saling tabrakan
// ketika beberapa update terjadi hampir bersamaan (mis. beberapa tool call cepat).
const locks = new Map();

function ensureFile(filePath, defaultValue) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  if (!fs.existsSync(filePath)) {
    fs.writeFileSync(filePath, JSON.stringify(defaultValue, null, 2), 'utf8');
  }
}

function readJSON(filePath, defaultValue) {
  ensureFile(filePath, defaultValue);
  try {
    const raw = fs.readFileSync(filePath, 'utf8');
    return raw.trim() ? JSON.parse(raw) : JSON.parse(JSON.stringify(defaultValue));
  } catch (err) {
    // File korup -> backup lalu reset ke default supaya agent tetap bisa jalan.
    const backup = filePath + `.corrupt-${Date.now()}.bak`;
    try { fs.copyFileSync(filePath, backup); } catch (_) {}
    const fresh = JSON.parse(JSON.stringify(defaultValue));
    fs.writeFileSync(filePath, JSON.stringify(fresh, null, 2), 'utf8');
    return fresh;
  }
}

function writeJSON(filePath, data) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  const tmp = filePath + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2), 'utf8');
  fs.renameSync(tmp, filePath); // rename atomic di filesystem yang sama
  return data;
}

function update(filePath, defaultValue, mutateFn) {
  const prev = locks.get(filePath) || Promise.resolve();
  const next = prev
    .catch(() => {})
    .then(() => {
      const current = readJSON(filePath, defaultValue);
      const updated = mutateFn(current) || current;
      return writeJSON(filePath, updated);
    });
  locks.set(filePath, next.catch(() => {}));
  return next;
}

module.exports = { readJSON, writeJSON, update, ensureFile };
