'use strict';
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const manager = require('./manager');

function file(memoryDir) { return path.join(memoryDir, 'tasks.json'); }
const DEFAULT = { tasks: [] };
const VALID_STATUS = ['pending', 'in_progress', 'blocked', 'failed', 'completed', 'verified'];

function list(memoryDir) {
  return manager.readJSON(file(memoryDir), DEFAULT).tasks;
}

function getById(memoryDir, id) {
  return list(memoryDir).find((t) => t.id === id) || null;
}

// Task terakhir yang masih aktif (in_progress/blocked), atau task terakhir apa saja jika tidak ada.
function getLastActive(memoryDir) {
  const tasks = list(memoryDir);
  const active = tasks.filter((t) => t.status === 'in_progress' || t.status === 'blocked');
  if (active.length) return active[active.length - 1];
  return tasks.length ? tasks[tasks.length - 1] : null;
}

async function create(memoryDir, title, steps = []) {
  const task = {
    id: 'task-' + uuidv4().slice(0, 8),
    title,
    status: 'in_progress',
    steps: steps.map((s) => (typeof s === 'string' ? { title: s, status: 'pending' } : s)),
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  };
  await manager.update(file(memoryDir), DEFAULT, (current) => {
    current.tasks.push(task);
    return current;
  });
  return task;
}

async function updateStatus(memoryDir, id, status, extra = {}) {
  if (!VALID_STATUS.includes(status)) throw new Error(`Status task tidak valid: ${status}`);
  await manager.update(file(memoryDir), DEFAULT, (current) => {
    const t = current.tasks.find((x) => x.id === id);
    if (!t) throw new Error(`Task ${id} tidak ditemukan.`);
    t.status = status;
    t.updated_at = new Date().toISOString();
    if (extra.note) t.note = extra.note;
    return current;
  });
  return getById(memoryDir, id);
}

async function updateStep(memoryDir, id, stepTitle, status) {
  await manager.update(file(memoryDir), DEFAULT, (current) => {
    const t = current.tasks.find((x) => x.id === id);
    if (!t) throw new Error(`Task ${id} tidak ditemukan.`);
    const step = t.steps.find((s) => s.title === stepTitle);
    if (!step) t.steps.push({ title: stepTitle, status });
    else step.status = status;
    t.updated_at = new Date().toISOString();
    return current;
  });
  return getById(memoryDir, id);
}

module.exports = { list, getById, getLastActive, create, updateStatus, updateStep, VALID_STATUS };
