'use strict';
const https = require('https');
const http = require('http');

const ALLOWED_WEBHOOK_HOSTS = ['discord.com', 'discordapp.com', 'ptb.discord.com', 'canary.discord.com'];

// Discord Components V2 (https://docs.discord.com/developers/components/reference):
// - Flag IS_COMPONENTS_V2 = 1<<15, WAJIB ada di setiap message yang pakai "components"
//   sebagai pengganti "embeds"/"content" (dua field itu tidak boleh dipakai bareng V2).
// - Type 17 = Container (wrapper layout, punya accent_color OPSIONAL - kita sengaja TIDAK
//   set accent_color sama sekali supaya tampilannya polos tanpa warna, sesuai permintaan).
// - Type 10 = Text Display (blok teks markdown).
// - Webhook WAJIB dipanggil dengan query param ?with_components=true, kalau tidak,
//   field "components" bakal diabaikan begitu saja oleh Discord.
const COMPONENTS_V2_FLAG = 1 << 15;
const COMPONENT_TYPE_CONTAINER = 17;
const COMPONENT_TYPE_TEXT_DISPLAY = 10;

// Batas aman per message (Discord: maks ~4000 karakter teks per message di Components V2).
// Dikasih margin buat overhead judul/penanda "lanjutan N/M".
const MAX_CHARS_PER_MESSAGE = 3800;

function isWebhookConfigured() {
  return !!process.env.DISCORD_WEBHOOK_URL;
}

// Request POST JSON generik (pilih http/https otomatis dari protokol URL) -
// dipisah dari validasi khusus Discord supaya gampang dites tanpa perlu
// webhook Discord asli.
function postJson(urlString, payload, timeoutMs = 10000) {
  return new Promise((resolve, reject) => {
    let url;
    try { url = new URL(urlString); } catch (err) { return reject(new Error('URL tidak valid.')); }
    const lib = url.protocol === 'http:' ? http : https;
    const data = JSON.stringify(payload);
    const req = lib.request(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) },
      timeout: timeoutMs,
    }, (res) => {
      let body = '';
      res.on('data', (chunk) => { body += chunk; });
      res.on('end', () => {
        if (res.statusCode >= 200 && res.statusCode < 300) resolve({ status: res.statusCode, body });
        else reject(new Error(`HTTP ${res.statusCode}: ${body.slice(0, 300)}`));
      });
    });
    req.on('error', reject);
    req.on('timeout', () => req.destroy(new Error('Timeout mengirim request.')));
    req.write(data);
    req.end();
  });
}

// Pecah teks panjang jadi beberapa bagian <= maxChars, sebisa mungkin motong di
// baris baru (bukan di tengah kata/baris) supaya tiap bagian tetap enak dibaca.
function chunkText(text, maxChars) {
  if (text.length <= maxChars) return [text];
  const chunks = [];
  let remaining = text;
  while (remaining.length > maxChars) {
    let cut = remaining.lastIndexOf('\n', maxChars);
    if (cut <= 0) cut = maxChars; // tidak ada newline yang pas, potong paksa
    chunks.push(remaining.slice(0, cut));
    remaining = remaining.slice(cut).replace(/^\n/, '');
  }
  if (remaining) chunks.push(remaining);
  return chunks;
}

function buildContainerPayload(chunk, title, chunkIndex, totalChunks) {
  const textComponents = [];
  if (chunkIndex === 0 && title) {
    textComponents.push({ type: COMPONENT_TYPE_TEXT_DISPLAY, content: `**${title}**` });
  } else if (totalChunks > 1) {
    textComponents.push({ type: COMPONENT_TYPE_TEXT_DISPLAY, content: `_(lanjutan ${chunkIndex + 1}/${totalChunks})_` });
  }
  textComponents.push({ type: COMPONENT_TYPE_TEXT_DISPLAY, content: chunk || '-' });

  return {
    flags: COMPONENTS_V2_FLAG,
    components: [
      { type: COMPONENT_TYPE_CONTAINER, components: textComponents }, // sengaja tanpa accent_color = polos
    ],
  };
}

// Kirim 1+ message Container V2 (otomatis kepecah jadi beberapa message kalau
// panjang teksnya lebih dari MAX_CHARS_PER_MESSAGE - "embed ke-2, ke-3, dst").
async function sendNotification(message, { title } = {}) {
  const webhookUrl = process.env.DISCORD_WEBHOOK_URL;
  if (!webhookUrl) {
    return { success: false, error: 'DISCORD_WEBHOOK_URL belum diisi di .env - notifikasi Discord tidak aktif.' };
  }

  let parsed;
  try { parsed = new URL(webhookUrl); } catch (err) { return { success: false, error: 'DISCORD_WEBHOOK_URL tidak valid.' }; }
  if (parsed.protocol !== 'https:') {
    return { success: false, error: `DISCORD_WEBHOOK_URL harus pakai https:// (dapat "${parsed.protocol}").` };
  }
  if (!ALLOWED_WEBHOOK_HOSTS.includes(parsed.hostname)) {
    return {
      success: false,
      error: `DISCORD_WEBHOOK_URL harus URL webhook Discord resmi (https://discord.com/api/webhooks/...). Host "${parsed.hostname}" tidak diizinkan.`,
    };
  }

  const sendUrl = webhookUrl.includes('?') ? `${webhookUrl}&with_components=true` : `${webhookUrl}?with_components=true`;
  const chunks = chunkText(String(message || '-'), MAX_CHARS_PER_MESSAGE);

  let sentCount = 0;
  let lastError = null;
  for (let i = 0; i < chunks.length; i++) {
    const payload = buildContainerPayload(chunks[i], title, i, chunks.length);
    try {
      await module.exports.postJson(sendUrl, payload); // lewat module.exports supaya bisa di-mock saat testing
      sentCount += 1;
    } catch (err) {
      lastError = err.message;
      break; // berhenti kalau ada bagian yang gagal, jangan kirim lanjutan yang bakal keliatan nyambung-nyambung palsu
    }
  }

  if (sentCount === chunks.length) return { success: true, parts_sent: sentCount };
  return {
    success: false,
    error: `Gagal kirim notifikasi Discord: ${lastError}`,
    parts_sent: sentCount,
    total_parts: chunks.length,
  };
}

const EVENT_TITLES = { online: '🟢 Server Online', offline: '🔴 Server Offline', crash: '⚠️ Server Crash Terdeteksi' };

// Dipakai internal oleh start_server/stop_server/restart_server - best-effort,
// TIDAK PERNAH throw supaya gagal kirim notifikasi tidak menggagalkan operasi
// server itu sendiri. Diam-diam skip kalau webhook belum dikonfigurasi.
async function notifyServerEvent(event, details = {}) {
  if (!process.env.DISCORD_WEBHOOK_URL) return { success: false, skipped: true };
  const lines = [];
  if (details.binary) lines.push(`Binary: \`${details.binary}\``);
  if (details.port) lines.push(`Port: \`${details.port}\``);
  if (details.pid) lines.push(`PID: \`${details.pid}\``);
  if (details.note) lines.push(details.note);
  return sendNotification(lines.join('\n') || '-', { title: EVENT_TITLES[event] || 'SAMPAI Agent' });
}

module.exports = {
  sendNotification, notifyServerEvent, isWebhookConfigured, postJson, ALLOWED_WEBHOOK_HOSTS,
  chunkText, buildContainerPayload, COMPONENTS_V2_FLAG,
};
