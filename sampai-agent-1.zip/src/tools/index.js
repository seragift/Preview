'use strict';
const filesTool = require('./files');
const shellTool = require('./shell');
const tasksMem = require('../memory/tasks');
const projectMem = require('../memory/project');
const changesMem = require('../memory/changes');
const errorsMem = require('../memory/errors');

const STATUS_ENUM = ['pending', 'in_progress', 'blocked', 'failed', 'completed', 'verified'];

const toolDefinitions = [
  {
    type: 'function',
    function: {
      name: 'list_files',
      description: 'Melihat daftar file dan folder di dalam workspace (relatif terhadap workspace root).',
      parameters: {
        type: 'object',
        properties: {
          path: { type: 'string', description: 'Folder relatif, default "." (root workspace).' },
          max_depth: { type: 'integer', description: 'Kedalaman folder maksimum yang ditelusuri, default 3.' },
        },
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'read_file',
      description: 'Membaca isi sebuah file di dalam workspace.',
      parameters: {
        type: 'object',
        properties: { path: { type: 'string', description: 'Path file relatif terhadap workspace.' } },
        required: ['path'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'write_file',
      description: 'Membuat file baru atau menimpa (overwrite) seluruh isi file yang sudah ada.',
      parameters: {
        type: 'object',
        properties: {
          path: { type: 'string' },
          content: { type: 'string' },
          task_id: { type: 'string', description: 'ID task yang sedang dikerjakan, jika ada.' },
          description: { type: 'string', description: 'Deskripsi singkat perubahan, untuk change log.' },
        },
        required: ['path', 'content'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'edit_file',
      description: 'Mengubah sebagian isi file dengan mengganti old_str (harus unik/hanya muncul sekali di file) dengan new_str.',
      parameters: {
        type: 'object',
        properties: {
          path: { type: 'string' },
          old_str: { type: 'string', description: 'Teks persis yang mau diganti, harus unik dalam file.' },
          new_str: { type: 'string' },
          task_id: { type: 'string' },
          description: { type: 'string' },
        },
        required: ['path', 'old_str', 'new_str'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'delete_file',
      description: 'Menghapus file. File penting (server.cfg, gamemodes/*.pwn, .env) butuh confirm=true.',
      parameters: {
        type: 'object',
        properties: {
          path: { type: 'string' },
          confirm: { type: 'boolean', description: 'Set true untuk mengonfirmasi hapus file penting/protected.' },
          task_id: { type: 'string' },
        },
        required: ['path'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'run_command',
      description: 'Menjalankan command Linux (dibatasi allowlist) untuk keperluan development/verifikasi, misalnya compile dengan pawncc atau menjalankan script node.',
      parameters: {
        type: 'object',
        properties: {
          command: { type: 'string' },
          cwd: { type: 'string', description: 'Working directory relatif terhadap workspace, default ".".' },
        },
        required: ['command'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'create_task',
      description: 'Membuat task baru di memory untuk melacak permintaan user saat ini. Panggil ini di awal pekerjaan baru (bukan continuation).',
      parameters: {
        type: 'object',
        properties: {
          title: { type: 'string' },
          steps: { type: 'array', items: { type: 'string' }, description: 'Daftar judul step awal yang direncanakan.' },
        },
        required: ['title'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'update_task',
      description: `Mengubah status task dan/atau salah satu step-nya. Status valid: ${STATUS_ENUM.join(', ')}.`,
      parameters: {
        type: 'object',
        properties: {
          task_id: { type: 'string' },
          status: { type: 'string', enum: STATUS_ENUM, description: 'Status baru untuk keseluruhan task.' },
          step_title: { type: 'string', description: 'Judul step yang mau diupdate (opsional).' },
          step_status: { type: 'string', enum: STATUS_ENUM, description: 'Status baru untuk step tersebut.' },
          note: { type: 'string', description: 'Catatan tambahan, misal alasan blocked/failed.' },
        },
        required: ['task_id'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'update_project_state',
      description: 'Update project.json: nama/deskripsi project, current_state, structure, completed/in_progress/todo/failed, dan next_task.',
      parameters: {
        type: 'object',
        properties: {
          project: { type: 'object', description: '{ name, path, type, description }' },
          current_state: { type: 'object', description: '{ status, version, last_action }' },
          structure: {
            type: 'object',
            description: '{ important_files, entry_points, gamemodes, filterscripts, includes, plugins, configs } (masing-masing array string)',
          },
          completed: { type: 'array', items: { type: 'string' } },
          in_progress: { type: 'array', items: { type: 'string' } },
          todo: { type: 'array', items: { type: 'string' } },
          failed: { type: 'array', items: { type: 'string' } },
          next_task: { type: 'string' },
        },
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'record_decision',
      description: 'Mencatat keputusan teknis penting beserta alasannya ke memory (mis. "pakai MySQL bukan SQLite karena ...").',
      parameters: {
        type: 'object',
        properties: { decision: { type: 'string' }, reason: { type: 'string' } },
        required: ['decision'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'update_error',
      description: 'Update status/solusi sebuah error yang sudah tercatat di error memory (pakai error_id dari hasil run_command yang gagal atau dari search_errors).',
      parameters: {
        type: 'object',
        properties: {
          error_id: { type: 'string' },
          status: { type: 'string', enum: ['open', 'investigating', 'resolved'] },
          solution: { type: 'string' },
        },
        required: ['error_id', 'status'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'search_errors',
      description: 'Mencari error serupa di error memory berdasarkan keyword, sebelum mencoba fix error yang mirip dari nol.',
      parameters: {
        type: 'object',
        properties: { query: { type: 'string' } },
        required: ['query'],
      },
    },
  },
];

async function executeTool(name, args, ctx) {
  const { workspace, memoryDir, logger } = ctx;
  const taskId = args.task_id || ctx.taskId;
  try {
    switch (name) {
      case 'list_files':
        return filesTool.listFiles(workspace, args.path || '.', { maxDepth: args.max_depth });

      case 'read_file':
        return filesTool.readFile(workspace, args.path);

      case 'write_file': {
        const res = filesTool.writeFile(workspace, args.path, args.content);
        if (res.success) {
          await changesMem.record(memoryDir, { file: args.path, action: res.action, description: args.description, task_id: taskId });
        }
        return res;
      }

      case 'edit_file': {
        const res = filesTool.editFile(workspace, args.path, args.old_str, args.new_str);
        if (res.success) {
          await changesMem.record(memoryDir, { file: args.path, action: 'edit', description: args.description, task_id: taskId });
        }
        return res;
      }

      case 'delete_file': {
        const res = filesTool.deleteFile(workspace, args.path, args.confirm);
        if (res.success) {
          await changesMem.record(memoryDir, { file: args.path, action: 'delete', description: 'File dihapus', task_id: taskId });
        }
        return res;
      }

      case 'run_command': {
        const res = shellTool.runCommand(workspace, args.command, args.cwd || '.');
        if (!res.success) {
          const errEntry = await errorsMem.record(memoryDir, {
            error: `${res.error}${res.output ? ' | output: ' + res.output.slice(0, 300) : ''}`,
            file: null,
            cause: null,
            solution: null,
            status: 'open',
            task_id: taskId,
          });
          return { ...res, error_id: errEntry.id };
        }
        return res;
      }

      case 'create_task':
        return await tasksMem.create(memoryDir, args.title, args.steps || []);

      case 'update_task': {
        if (args.step_title) {
          await tasksMem.updateStep(memoryDir, args.task_id, args.step_title, args.step_status || 'completed');
        }
        let task = tasksMem.getById(memoryDir, args.task_id);
        if (args.status) {
          task = await tasksMem.updateStatus(memoryDir, args.task_id, args.status, { note: args.note });
        }
        return { success: true, task };
      }

      case 'update_project_state':
        return { success: true, project: await projectMem.patch(memoryDir, args) };

      case 'record_decision':
        return { success: true, recorded: await projectMem.addDecision(memoryDir, args.decision, args.reason) };

      case 'update_error':
        return { success: true, error: await errorsMem.updateStatus(memoryDir, args.error_id, args.status, args.solution) };

      case 'search_errors':
        return { success: true, results: errorsMem.search(memoryDir, args.query) };

      default:
        return { success: false, error: `Tool tidak dikenal: ${name}` };
    }
  } catch (err) {
    return { success: false, error: err.message };
  } finally {
    if (logger) {
      try { logger.tool({ tool: name, args, task_id: taskId }); } catch (_) {}
    }
  }
}

module.exports = { toolDefinitions, executeTool };
