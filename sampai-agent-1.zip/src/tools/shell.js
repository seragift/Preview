'use strict';
const { execSync } = require('child_process');
const { resolveSafePath, isCommandAllowed } = require('../security/sandbox');

const TIMEOUT_MS = parseInt(process.env.COMMAND_TIMEOUT_MS || '30000', 10);
const MAX_OUTPUT_BYTES = (parseInt(process.env.MAX_COMMAND_OUTPUT_KB || '64', 10)) * 1024;

function runCommand(workspace, command, relCwd = '.') {
  const check = isCommandAllowed(command);
  if (!check.ok) return { success: false, error: check.reason };

  const cwd = resolveSafePath(workspace, relCwd);

  try {
    const output = execSync(command, {
      cwd,
      timeout: TIMEOUT_MS,
      maxBuffer: MAX_OUTPUT_BYTES,
      encoding: 'utf8',
      shell: '/bin/bash',
    });
    return { success: true, output: (output || '').slice(0, MAX_OUTPUT_BYTES), exitCode: 0 };
  } catch (err) {
    const out = (err.stdout || '') + (err.stderr || '');
    return {
      success: false,
      error: err.killed ? 'Command timeout / dihentikan paksa.' : 'Command gagal (exit code bukan 0).',
      output: out.slice(0, MAX_OUTPUT_BYTES),
      exitCode: err.status ?? -1,
    };
  }
}

module.exports = { runCommand };
