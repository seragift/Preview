'use strict';
const dgram = require('dgram');

// Implementasi protokol query resmi SA-MP/open.mp (bukan tebakan - spesifikasi
// byte-nya diambil dari dokumentasi resmi open.mp: open.mp/docs/tutorials/QueryMechanism).
//
// Request (11 byte): "SAMP" + 4 byte IP octet + port&0xFF + (port>>8)&0xFF + OPCODE
// Response 'i' (info): header 11 byte (echo) lalu:
//   byte 11    : password (0/1)
//   byte 12-13 : players (uint16 LE)
//   byte 14-15 : maxplayers (uint16 LE)
//   byte 16-19 : panjang hostname (uint32 LE) diikuti string hostname
//   lanjut     : panjang gamemode (uint32 LE) diikuti string gamemode
//   lanjut     : panjang language (uint32 LE) diikuti string language

function buildRequestPacket(ip, port, opcode) {
  const octets = ip.split('.').map(Number);
  if (octets.length !== 4 || octets.some((n) => Number.isNaN(n) || n < 0 || n > 255)) {
    throw new Error(`IP tidak valid: ${ip} (harus IPv4, mis. 127.0.0.1)`);
  }
  const buf = Buffer.alloc(11);
  buf.write('SAMP', 0, 'ascii');
  buf[4] = octets[0]; buf[5] = octets[1]; buf[6] = octets[2]; buf[7] = octets[3];
  buf[8] = port & 0xFF;
  buf[9] = (port >> 8) & 0xFF;
  buf[10] = opcode.charCodeAt(0);
  return buf;
}

function sendQuery(ip, port, opcode, timeoutMs) {
  return new Promise((resolve, reject) => {
    const socket = dgram.createSocket('udp4');
    let packet;
    try {
      packet = buildRequestPacket(ip, port, opcode);
    } catch (err) {
      socket.close();
      return reject(err);
    }

    let done = false;
    const finish = (fn, val) => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      try { socket.close(); } catch (_) {}
      fn(val);
    };

    const timer = setTimeout(() => {
      finish(reject, new Error('Timeout - server tidak merespons query (kemungkinan offline, port salah, atau UDP diblokir firewall).'));
    }, timeoutMs);

    socket.on('message', (msg) => finish(resolve, msg));
    socket.on('error', (err) => finish(reject, err));
    socket.send(packet, port, ip, (err) => { if (err) finish(reject, err); });
  });
}

function parseInfoResponse(buf) {
  let offset = 11;
  const password = buf.readUInt8(offset); offset += 1;
  const players = buf.readUInt16LE(offset); offset += 2;
  const maxplayers = buf.readUInt16LE(offset); offset += 2;

  const hostnameLen = buf.readUInt32LE(offset); offset += 4;
  const hostname = buf.toString('utf8', offset, offset + hostnameLen); offset += hostnameLen;

  const gamemodeLen = buf.readUInt32LE(offset); offset += 4;
  const gamemode = buf.toString('utf8', offset, offset + gamemodeLen); offset += gamemodeLen;

  const languageLen = buf.readUInt32LE(offset); offset += 4;
  const language = buf.toString('utf8', offset, offset + languageLen); offset += languageLen;

  return { password: !!password, players, maxplayers, hostname, gamemode, language };
}

async function queryServerInfo(ip, port, timeoutMs) {
  const targetIp = ip || '127.0.0.1';
  const targetPort = port;
  const timeout = Math.max(500, Math.min(15000, timeoutMs || 3000));

  if (!targetPort || targetPort < 1 || targetPort > 65535) {
    return { success: false, error: 'Port tidak valid/tidak diketahui.' };
  }

  try {
    const response = await sendQuery(targetIp, targetPort, 'i', timeout);
    if (response.length < 11 || response.toString('ascii', 0, 4) !== 'SAMP') {
      return { success: false, error: 'Response bukan format SAMP query yang valid - kemungkinan bukan server SA-MP/open.mp, atau port salah.' };
    }
    const info = parseInfoResponse(response);
    return { success: true, ip: targetIp, port: targetPort, ...info };
  } catch (err) {
    return { success: false, error: err.message };
  }
}

module.exports = { queryServerInfo, buildRequestPacket, parseInfoResponse };
