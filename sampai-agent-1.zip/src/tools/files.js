'use strict';
const fs = require('fs');
const path = require('path');
const { resolveSafePath, isProtected, checkFileSize } = require('../security/sandbox');

function listFiles(workspace, relDir = '.', opts = {}) {
  const dir = resolveSafePath(workspace, relDir);
  if (!fs.existsSync(dir)) return { success: false, error: `Folder tidak ditemukan: ${relDir}` };
  const maxDepth = opts.maxDepth ?? 3;
  const ignore = new Set(['node_modules', '.git']);

  function walk(current, depth) {
    if (depth > maxDepth) return [];
    const entries = fs.readdirSync(current, { withFileTypes: true });
    let results = [];
    for (const entry of entries) {
      if (ignore.has(entry.name)) continue;
      const full = path.join(current, entry.name);
      const rel = path.relative(workspace, full).replace(/\\/g, '/');
      if (entry.isDirectory()) {
        results.push({ path: rel, type: 'dir' });
        results = results.concat(walk(full, depth + 1));
      } else {
        const stat = fs.statSync(full);
        results.push({ path: rel, type: 'file', size: stat.size, modified: stat.mtime.toISOString() });
      }
    }
    return results;
  }

  return { success: true, base: relDir, entries: walk(dir, 0) };
}

function readFile(workspace, relPath) {
  const full = resolveSafePath(workspace, relPath);
  if (!fs.existsSync(full)) return { success: false, error: `File tidak ditemukan: ${relPath}` };
  const stat = fs.statSync(full);
  if (stat.isDirectory()) return { success: false, error: `${relPath} adalah folder, bukan file.` };
  checkFileSize(stat.size);
  const content = fs.readFileSync(full, 'utf8');
  return { success: true, path: relPath, content, size: stat.size };
}

function writeFile(workspace, relPath, content) {
  const full = resolveSafePath(workspace, relPath);
  checkFileSize(Buffer.byteLength(content || '', 'utf8'));
  fs.mkdirSync(path.dirname(full), { recursive: true });
  const existed = fs.existsSync(full);
  fs.writeFileSync(full, content ?? '', 'utf8');
  return { success: true, path: relPath, action: existed ? 'overwrite' : 'create' };
}

function editFile(workspace, relPath, oldStr, newStr) {
  const full = resolveSafePath(workspace, relPath);
  if (!fs.existsSync(full)) return { success: false, error: `File tidak ditemukan: ${relPath}` };
  if (typeof oldStr !== 'string' || oldStr.length === 0) {
    return { success: false, error: 'old_str tidak boleh kosong.' };
  }
  const content = fs.readFileSync(full, 'utf8');
  const occurrences = content.split(oldStr).length - 1;
  if (occurrences === 0) return { success: false, error: 'old_str tidak ditemukan di file. Baca ulang file untuk memastikan teks persis.' };
  if (occurrences > 1) return { success: false, error: `old_str ditemukan ${occurrences}x, harus unik. Perluas konteksnya (tambahkan baris sekitar).` };
  const updated = content.replace(oldStr, newStr);
  checkFileSize(Buffer.byteLength(updated, 'utf8'));
  fs.writeFileSync(full, updated, 'utf8');
  return { success: true, path: relPath };
}

function deleteFile(workspace, relPath, confirm = false) {
  const full = resolveSafePath(workspace, relPath);
  if (!fs.existsSync(full)) return { success: false, error: `File tidak ditemukan: ${relPath}` };
  if (isProtected(relPath) && !confirm) {
    return {
      success: false,
      error: `File "${relPath}" adalah file penting (protected). Panggil ulang delete_file dengan confirm=true jika benar-benar yakin.`,
      requiresConfirmation: true,
    };
  }
  fs.unlinkSync(full);
  return { success: true, path: relPath };
}

module.exports = { listFiles, readFile, writeFile, editFile, deleteFile };
