'use strict';
const os = require('os');
const dgram = require('dgram');

// Cek apakah sebuah port UDP kosong dengan benar-benar mencoba bind ke situ
// (bukan nebak) - port SA-MP/open.mp memang UDP.
function isPortFreeUDP(port) {
  return new Promise((resolve) => {
    const socket = dgram.createSocket('udp4');
    socket.once('error', () => {
      try { socket.close(); } catch (_) {}
      resolve(false);
    });
    try {
      socket.bind(port, '0.0.0.0', () => {
        socket.close();
        resolve(true);
      });
    } catch (err) {
      resolve(false);
    }
  });
}

async function findFreePort({ preferred_port, max_attempts } = {}) {
  const start = Math.max(1024, Math.min(65535, preferred_port || 7777));
  const attempts = Math.max(1, Math.min(200, max_attempts || 50));
  const tried = [];
  for (let i = 0; i < attempts; i++) {
    const candidate = start + i;
    if (candidate > 65535) break;
    tried.push(candidate);
    const free = await isPortFreeUDP(candidate);
    if (free) {
      return { success: true, port: candidate, checked_count: tried.length, preferred_port: start };
    }
  }
  return {
    success: false,
    error: `Tidak ada port UDP kosong ditemukan dari ${tried.length} percobaan mulai dari ${start}.`,
    checked: tried,
  };
}

// Baca IP langsung dari network interface OS (bukan lewat layanan luar/curl),
// supaya konsisten dengan kebijakan "tidak akses internet sembarangan".
function detectLocalIPs() {
  const interfaces = os.networkInterfaces();
  const result = [];
  for (const [ifaceName, addrs] of Object.entries(interfaces)) {
    for (const addr of addrs || []) {
      if (addr.family === 'IPv4') {
        result.push({ interface: ifaceName, address: addr.address, internal: addr.internal });
      }
    }
  }
  return {
    success: true,
    interfaces: result,
    likely_public: result.filter((r) => !r.internal).map((r) => r.address),
    note: 'Ini IP yang benar-benar nempel di network interface OS. Kalau VPS di belakang NAT/load balancer, IP publik yang dipakai player untuk connect bisa BEDA dari daftar ini - cek dashboard provider VPS kalau ragu.',
  };
}

module.exports = { findFreePort, detectLocalIPs, isPortFreeUDP };
