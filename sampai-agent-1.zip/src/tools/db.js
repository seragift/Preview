'use strict';
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { spawnSync } = require('child_process');
const { resolveSafePath } = require('../security/sandbox');

// Identifier MySQL (nama database/user) divalidasi ketat karena bakal diselipkan
// langsung ke statement SQL (CREATE DATABASE/USER tidak bisa di-parameterize
// lewat prepared statement biasa).
const IDENTIFIER_RE = /^[A-Za-z_][A-Za-z0-9_]{0,63}$/;

function isMysqlClientAvailable() {
  const r = spawnSync('mysql', ['--version'], { encoding: 'utf8' });
  return !r.error && r.status === 0;
}

function generatePassword(len = 20) {
  return crypto.randomBytes(len * 2).toString('base64').replace(/[^A-Za-z0-9]/g, '').slice(0, len);
}

// Escape nilai buat diselipkan di dalam string SQL berkutip-tunggal.
function escapeSqlString(value) {
  return String(value).replace(/\\/g, '\\\\').replace(/'/g, "\\'");
}

// Kredensial ditulis ke file sementara ber-permission 600 (bukan lewat argumen
// command line atau env var) supaya tidak nyangkut di `ps aux` / process list.
function writeTempDefaultsFile(user, password, host, port) {
  const tmpPath = path.join(os.tmpdir(), `.sampai-mysql-${crypto.randomBytes(6).toString('hex')}.cnf`);
  const content = `[client]\nuser=${user}\npassword=${password}\nhost=${host}\nport=${port}\n`;
  fs.writeFileSync(tmpPath, content, { mode: 0o600 });
  return tmpPath;
}

function runMysql(defaultsFile, extraArgs, sqlInput) {
  const spawnArgs = [`--defaults-extra-file=${defaultsFile}`, ...extraArgs];
  return spawnSync('mysql', spawnArgs, { input: sqlInput, encoding: 'utf8', timeout: 30000 });
}

async function setupDatabase(workspace, { database_name, app_user, app_password, schema_file }) {
  const adminUser = process.env.DB_ADMIN_USER;
  const adminPassword = process.env.DB_ADMIN_PASSWORD;
  const host = process.env.DB_HOST || '127.0.0.1';
  const port = process.env.DB_PORT || '3306';

  if (!adminUser || !adminPassword) {
    return {
      success: false,
      error: 'MySQL belum dikonfigurasi di agent. User perlu install & jalankan MySQL/MariaDB sendiri dulu (agent tidak melakukan ini), lalu isi DB_ADMIN_USER dan DB_ADMIN_PASSWORD di .env dengan kredensial admin-nya.',
    };
  }
  if (!isMysqlClientAvailable()) {
    return { success: false, error: 'MySQL client ("mysql" command) tidak ditemukan/tidak bisa dijalankan di VPS. Pastikan mysql-client terinstall.' };
  }
  if (!database_name || !IDENTIFIER_RE.test(database_name)) {
    return { success: false, error: 'database_name tidak valid (hanya huruf/angka/underscore, tidak diawali angka, maks 64 karakter).' };
  }
  if (!app_user || !IDENTIFIER_RE.test(app_user)) {
    return { success: false, error: 'app_user tidak valid (hanya huruf/angka/underscore, tidak diawali angka, maks 64 karakter).' };
  }

  const finalPassword = app_password || generatePassword(20);
  const generated = !app_password;
  const userHost = (host === '127.0.0.1' || host === 'localhost') ? 'localhost' : '%';

  const adminDefaultsFile = writeTempDefaultsFile(adminUser, adminPassword, host, port);
  try {
    const sql = [
      `CREATE DATABASE IF NOT EXISTS \`${database_name}\` CHARACTER SET utf8mb4;`,
      `CREATE USER IF NOT EXISTS '${app_user}'@'${userHost}' IDENTIFIED BY '${escapeSqlString(finalPassword)}';`,
      `GRANT ALL PRIVILEGES ON \`${database_name}\`.* TO '${app_user}'@'${userHost}';`,
      'FLUSH PRIVILEGES;',
    ].join('\n');

    const result = runMysql(adminDefaultsFile, [], sql);
    if (result.error || result.status !== 0) {
      return {
        success: false,
        error: `Gagal setup database (cek kredensial admin MySQL di .env): ${((result.stderr || (result.error && result.error.message)) || 'unknown error').slice(0, 500)}`,
      };
    }
  } finally {
    try { fs.unlinkSync(adminDefaultsFile); } catch (_) {}
  }

  let schemaResult = null;
  if (schema_file) {
    const schemaFull = resolveSafePath(workspace, schema_file);
    if (!fs.existsSync(schemaFull)) {
      return { success: false, error: `Schema file tidak ditemukan: ${schema_file}`, database_created: true, app_user, database: database_name };
    }
    const sqlContent = fs.readFileSync(schemaFull, 'utf8');
    const appDefaultsFile = writeTempDefaultsFile(app_user, finalPassword, host, port);
    try {
      const r = runMysql(appDefaultsFile, [database_name], sqlContent);
      schemaResult = {
        success: !r.error && r.status === 0,
        error: r.error ? r.error.message : (r.status !== 0 ? (r.stderr || '').slice(0, 500) : null),
      };
    } finally {
      try { fs.unlinkSync(appDefaultsFile); } catch (_) {}
    }
  }

  return {
    success: true,
    database: database_name,
    app_user,
    app_password: finalPassword,
    password_generated: generated,
    host,
    port,
    schema_applied: schema_file ? !!(schemaResult && schemaResult.success) : null,
    schema_error: schemaResult && !schemaResult.success ? schemaResult.error : null,
    warning: generated
      ? 'Password di-generate otomatis oleh sistem - WAJIB ditampilkan ke user di jawaban, jangan cuma disimpan diam-diam.'
      : undefined,
  };
}

async function queryDatabase(workspace, { sql, database, limit }) {
  const adminUser = process.env.DB_ADMIN_USER;
  const adminPassword = process.env.DB_ADMIN_PASSWORD;
  const host = process.env.DB_HOST || '127.0.0.1';
  const port = process.env.DB_PORT || '3306';

  if (!adminUser || !adminPassword) {
    return {
      success: false,
      error: 'MySQL belum dikonfigurasi di agent. Isi DB_ADMIN_USER dan DB_ADMIN_PASSWORD di .env dulu (kredensial admin MySQL yang sudah kamu install manual).',
    };
  }
  if (!isMysqlClientAvailable()) {
    return { success: false, error: 'MySQL client ("mysql" command) tidak ditemukan/tidak bisa dijalankan di VPS.' };
  }
  if (!sql || typeof sql !== 'string' || !sql.trim()) {
    return { success: false, error: 'sql wajib diisi.' };
  }

  const trimmed = sql.trim();
  if (/\bdrop\s+(database|schema)\b/i.test(trimmed)) {
    return {
      success: false,
      error: 'Query ditolak: DROP DATABASE/SCHEMA tidak diizinkan lewat db_query karena terlalu destruktif untuk dijalankan otomatis. Kalau memang mau, lakukan manual langsung di VPS.',
    };
  }
  // Satu statement per panggilan - cegah stacked queries (mis. "SELECT 1; DROP TABLE users;")
  const withoutTrailingSemicolon = trimmed.replace(/;\s*$/, '');
  if (withoutTrailingSemicolon.includes(';')) {
    return { success: false, error: 'Cuma boleh satu statement per db_query (jangan gabung beberapa query pakai ";"). Panggil db_query beberapa kali kalau perlu banyak query.' };
  }
  if (database && !IDENTIFIER_RE.test(database)) {
    return { success: false, error: 'Nama database tidak valid.' };
  }

  const defaultsFile = writeTempDefaultsFile(adminUser, adminPassword, host, port);
  try {
    const args = ['--table'];
    if (database) args.push(database);
    const result = runMysql(defaultsFile, args, `${withoutTrailingSemicolon};`);
    if (result.error || result.status !== 0) {
      return {
        success: false,
        error: ((result.stderr || (result.error && result.error.message)) || 'unknown error').slice(0, 800),
      };
    }
    const outLines = (result.stdout || '').split(/\r?\n/).filter((l) => l.length > 0);
    const maxLines = Math.max(5, Math.min(200, limit || 50));
    return {
      success: true,
      output: outLines.slice(0, maxLines).join('\n'),
      truncated: outLines.length > maxLines,
      total_lines: outLines.length,
    };
  } finally {
    try { fs.unlinkSync(defaultsFile); } catch (_) {}
  }
}

module.exports = { setupDatabase, queryDatabase, IDENTIFIER_RE };
