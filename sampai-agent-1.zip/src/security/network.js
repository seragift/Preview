'use strict';

// Host yang boleh dipakai untuk download_url di install_server.
// Tambah/kurangi sesuai kebutuhan, tapi jaga tetap ketat - ini satu-satunya
// jalur di mana agent boleh mengambil data dari luar workspace/internet.
const ALLOWED_DOWNLOAD_HOSTS = [
  'github.com',
  'raw.githubusercontent.com',
  'codeload.github.com',
  'objects.githubusercontent.com', // target redirect asset release GitHub
  'files.sa-mp.com',
];

function isDownloadUrlAllowed(urlString) {
  let u;
  try {
    u = new URL(urlString);
  } catch (err) {
    return { ok: false, reason: 'URL tidak valid.' };
  }
  if (u.protocol !== 'https:') {
    return { ok: false, reason: 'Hanya URL https:// yang diizinkan untuk download.' };
  }
  if (!ALLOWED_DOWNLOAD_HOSTS.includes(u.hostname)) {
    return {
      ok: false,
      reason: `Host "${u.hostname}" tidak ada di allowlist download. Host yang diizinkan: ${ALLOWED_DOWNLOAD_HOSTS.join(', ')}.`,
    };
  }
  return { ok: true };
}

module.exports = { isDownloadUrlAllowed, ALLOWED_DOWNLOAD_HOSTS };
