'use strict';
const path = require('path');

// Pola command yang diblokir total, walau binary-nya ada di allowlist
// (misalnya "find" boleh, tapi "find / -delete" tetap harus lolos allowlist binary
// dan tidak match pola berbahaya di bawah).
const BLOCKED_PATTERNS = [
  /\brm\s+-rf\b/i,
  /\bsudo\b/i,
  /\bshutdown\b/i,
  /\breboot\b/i,
  /\bmkfs\b/i,
  /\bdd\s+if=/i,
  /\bchmod\s+777\b/i,
  /\bchown\b/i,
  /\bcurl\b/i,
  /\bwget\b/i,
  /\bnetcat\b|\bnc\s+-/i,
  /\bssh\b/i,
  /\bscp\b/i,
  /\bkill\s+-9\b/i,
  /\bkillall\b/i,
  /:\(\)\s*{\s*:\|:&\s*};:/, // fork bomb
  />\s*\/dev\/(sd|nvme)/i,
  /\bapt(-get)?\s+(install|remove|purge)\b/i,
  /\byum\b|\bdnf\b/i,
  /\bsystemctl\b|\bservice\b/i,
  /\bpasswd\b/i,
  /\buseradd\b|\buserdel\b/i,
  /\bcrontab\b/i,
  /\biptables\b/i,
  /\/etc\/(passwd|shadow)/i,
  /\.\.(\/|\\)/, // path traversal di argumen command
];

// Hanya binary di daftar ini yang boleh dijalankan lewat run_command.
// Tambahkan compiler/tool lain di sini kalau memang dibutuhkan & aman.
const ALLOWED_BINARIES = [
  'ls', 'cat', 'wc', 'grep', 'egrep', 'fgrep', 'find', 'echo', 'pwd',
  'head', 'tail', 'mkdir', 'touch', 'mv', 'cp', 'diff', 'tree',
  'node', 'npm', 'npx',
  'pawncc', 'pawn', './pawncc', './pawncc.exe',
];

function isCommandAllowed(cmd) {
  const trimmed = (cmd || '').trim();
  if (!trimmed) return { ok: false, reason: 'Command kosong.' };

  for (const pattern of BLOCKED_PATTERNS) {
    if (pattern.test(trimmed)) {
      return { ok: false, reason: `Command diblokir oleh security policy (pola berbahaya terdeteksi).` };
    }
  }

  // Cek setiap sub-command yang dipisah ; && || |
  const segments = trimmed.split(/&&|\|\||;|\|/).map((s) => s.trim()).filter(Boolean);
  for (const segment of segments) {
    const firstToken = segment.split(/\s+/)[0];
    const baseBinary = path.basename(firstToken.replace(/^\.\//, ''));
    if (!ALLOWED_BINARIES.includes(baseBinary) && !ALLOWED_BINARIES.includes(firstToken)) {
      return {
        ok: false,
        reason: `Binary "${baseBinary}" tidak ada di allowlist keamanan. Jika memang dibutuhkan dan aman, tambahkan ke ALLOWED_BINARIES di src/security/sandbox.js.`,
      };
    }
  }

  return { ok: true };
}

function resolveSafePath(workspaceRoot, relativePath) {
  const root = path.resolve(workspaceRoot);
  const target = path.resolve(root, relativePath || '.');
  if (target !== root && !target.startsWith(root + path.sep)) {
    throw new Error(`Path traversal terdeteksi: "${relativePath}" berada di luar workspace.`);
  }
  return target;
}

const PROTECTED_PATTERNS = [
  /(^|\/)server\.cfg$/i,
  /(^|\/)gamemodes\/.*\.pwn$/i,
  /(^|\/)\.env$/i,
];

function isProtected(relativePath) {
  return PROTECTED_PATTERNS.some((p) => p.test(relativePath.replace(/\\/g, '/')));
}

const MAX_FILE_SIZE_BYTES = (parseInt(process.env.MAX_FILE_SIZE_KB || '1024', 10)) * 1024;

function checkFileSize(bytes) {
  if (bytes > MAX_FILE_SIZE_BYTES) {
    throw new Error(`Ukuran file (${bytes} bytes) melebihi batas maksimum ${MAX_FILE_SIZE_BYTES} bytes (MAX_FILE_SIZE_KB).`);
  }
}

module.exports = {
  isCommandAllowed,
  resolveSafePath,
  isProtected,
  checkFileSize,
  MAX_FILE_SIZE_BYTES,
  ALLOWED_BINARIES,
};
