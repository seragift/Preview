'use strict';
require('dotenv').config();
const path = require('path');
const fs = require('fs');
const assert = require('assert');
const { execSync } = require('child_process');

const filesTool = require('../src/tools/files');
const tasksMem = require('../src/memory/tasks');

const TEST_WORKSPACE = path.join(__dirname, '.test-workspace');
const TEST_MEMORY = path.join(__dirname, '.test-memory');

function reset() {
  fs.rmSync(TEST_WORKSPACE, { recursive: true, force: true });
  fs.rmSync(TEST_MEMORY, { recursive: true, force: true });
  fs.mkdirSync(TEST_WORKSPACE, { recursive: true });
}

async function main() {
  let passed = 0;
  let failed = 0;

  function check(name, fn) {
    try { fn(); console.log(`✓ ${name}`); passed++; }
    catch (err) { console.log(`✗ ${name}: ${err.message}`); failed++; }
  }
  async function checkAsync(name, fn) {
    try { await fn(); console.log(`✓ ${name}`); passed++; }
    catch (err) { console.log(`✗ ${name}: ${err.message}`); failed++; }
  }

  reset();

  check('Test 1 - Agent dapat melihat file (list_files)', () => {
    fs.writeFileSync(path.join(TEST_WORKSPACE, 'a.txt'), 'hi');
    const res = filesTool.listFiles(TEST_WORKSPACE, '.');
    assert(res.success, 'list_files gagal');
    assert(res.entries.some((e) => e.path === 'a.txt'), 'a.txt tidak muncul di listing');
  });

  check('Test 2 - Agent dapat membaca file (read_file)', () => {
    const res = filesTool.readFile(TEST_WORKSPACE, 'a.txt');
    assert(res.success && res.content === 'hi', 'isi file tidak sesuai');
  });

  check('Test 3 - Agent dapat membuat file hello.js', () => {
    const res = filesTool.writeFile(TEST_WORKSPACE, 'hello.js', 'console.log("Hello World");');
    assert(res.success, 'write_file gagal');
    const content = fs.readFileSync(path.join(TEST_WORKSPACE, 'hello.js'), 'utf8');
    assert(content.includes('Hello World'), 'isi hello.js tidak sesuai');
  });

  check('Test 4 - Agent dapat mengedit file', () => {
    const res = filesTool.editFile(TEST_WORKSPACE, 'hello.js', 'Hello World', 'Hello SAMP');
    assert(res.success, 'edit_file gagal: ' + (res.error || ''));
    const content = fs.readFileSync(path.join(TEST_WORKSPACE, 'hello.js'), 'utf8');
    assert(content.includes('Hello SAMP'), 'hasil edit tidak sesuai');
  });

  await checkAsync('Test 5 - Agent dapat menjalankan file (node hello.js)', async () => {
    const out = execSync('node hello.js', { cwd: TEST_WORKSPACE, encoding: 'utf8' });
    assert(out.includes('Hello SAMP'), 'output run tidak sesuai');
  });

  await checkAsync('Test 6 - Agent menyimpan perubahan ke memory (changes.json)', async () => {
    const changesMem = require('../src/memory/changes');
    await changesMem.record(TEST_MEMORY, { file: 'hello.js', action: 'edit', description: 'test' });
    const recent = changesMem.recent(TEST_MEMORY, 5);
    assert(recent.length === 1 && recent[0].file === 'hello.js', 'change tidak tersimpan dengan benar');
  });

  await checkAsync('Test 7 - Restart agent, memory tetap tersedia', async () => {
    // Simulasikan restart Node.js dengan meng-clear module cache lalu baca ulang dari disk.
    delete require.cache[require.resolve('../src/memory/manager')];
    delete require.cache[require.resolve('../src/memory/changes')];
    const changesMem = require('../src/memory/changes');
    const recent = changesMem.recent(TEST_MEMORY, 5);
    assert(recent.length === 1, 'Memory harus tetap ada di filesystem setelah restart');
  });

  await checkAsync('Test 8 - "Lanjutkan pekerjaan sebelumnya" -> task terakhir diketahui', async () => {
    const t = await tasksMem.create(TEST_MEMORY, 'Task uji coba', ['step1', 'step2']);
    await tasksMem.updateStep(TEST_MEMORY, t.id, 'step1', 'completed');
    const last = tasksMem.getLastActive(TEST_MEMORY);
    assert(last && last.id === t.id, 'getLastActive tidak mengembalikan task yang benar');
    assert(last.status === 'in_progress', 'status task seharusnya masih in_progress');
    assert(last.steps.find((s) => s.title === 'step1').status === 'completed', 'step1 seharusnya completed');
    console.log('  (Ini menguji lapisan memory. Untuk uji end-to-end lewat LLM: jalankan `npm start`,');
    console.log('   buat task lewat satu perintah, lalu ketik "lanjutkan" pada sesi berikutnya - butuh OPENAI_API_KEY valid.)');
  });

  console.log(`\n${passed} passed, ${failed} failed.`);
  reset();
  process.exit(failed ? 1 : 0);
}

main();
