require('dotenv').config();
const { Client, GatewayIntentBits, Collection } = require('discord.js');
const fs = require('fs');
const path = require('path');
const config = require('./src/config/config');
const logger = require('./src/utils/logger');
const db = require('./src/database/connection');
const migrate = require('./src/database/migrate');
const marketEngine = require('./src/services/marketEngine');
const { loadStocks } = require('./src/services/companyEngine');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
  ]
});

client.commands = new Collection();

async function loadCommands(dir) {
  const files = fs.readdirSync(dir, { withFileTypes: true });
  for (const file of files) {
    const fullPath = path.join(dir, file.name);
    if (file.isDirectory()) {
      await loadCommands(fullPath);
    } else if (file.name.endsWith('.js')) {
      const cmd = require(fullPath);
      if (cmd.data && cmd.execute) {
        client.commands.set(cmd.data.name, cmd);
      }
    }
  }
}

async function loadEvents(dir) {
  const files = fs.readdirSync(dir, { withFileTypes: true });
  for (const file of files) {
    const fullPath = path.join(dir, file.name);
    if (file.isDirectory()) {
      await loadEvents(fullPath);
    } else if (file.name.endsWith('.js')) {
      const evt = require(fullPath);
      if (evt.name && evt.execute) {
        client.on(evt.name, (...args) => evt.execute(client, ...args));
      }
    }
  }
}

async function init() {
  logger.info('[INIT] Connecting Discord...');
  logger.info('[INIT] Initializing SQLite...');
  db.init();
  logger.info('[INIT] Running migrations...');
  migrate.run();
  logger.info('[INIT] Loading stocks...');
  loadStocks();
  logger.info('[INIT] Loading commands...');
  await loadCommands(path.join(__dirname, 'src', 'commands'));
  logger.info('[INIT] Loading events...');
  await loadEvents(path.join(__dirname, 'src', 'events'));
  logger.info('[INIT] Starting market engine...');
  marketEngine.start();
  logger.info('[INIT] Starting scheduled jobs...');
  require('./src/jobs/marketTick');
  require('./src/jobs/dailyReset');
  require('./src/jobs/dividendJob');
  require('./src/jobs/eventJob');
  require('./src/jobs/backupJob');
  logger.info('[INIT] Logging in...');
  await client.login(process.env.DISCORD_TOKEN);
}

init().catch(err => {
  logger.error('[INIT] Fatal error:', err);
  process.exit(1);
});
