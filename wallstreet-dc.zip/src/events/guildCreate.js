const logger = require('../utils/logger');

module.exports = {
  name: 'guildCreate',
  execute: async (client, guild) => {
    logger.info(`[GUILD] Joined ${guild.name} (${guild.id})`);
  }
};
