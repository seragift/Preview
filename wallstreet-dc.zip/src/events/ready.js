const logger = require('../utils/logger');
const achievementEngine = require('../services/achievementEngine');

module.exports = {
  name: 'ready',
  once: true,
  execute: async (client) => {
    logger.info(`[READY] Bot online as ${client.user.tag}`);
    achievementEngine.init();
    logger.info('[READY] Achievement definitions loaded.');
  }
};
