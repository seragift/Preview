const logger = require('../utils/logger');

module.exports = {
  name: 'interactionCreate',
  execute: async (client, interaction) => {
    if (interaction.isChatInputCommand()) {
      const command = client.commands.get(interaction.commandName);
      if (!command) return;
      try {
        await command.execute(interaction);
      } catch (err) {
        logger.error('[COMMAND]', err);
        if (interaction.replied || interaction.deferred) {
          await interaction.followUp({ content: 'Terjadi kesalahan!', ephemeral: true }).catch(() => {});
        } else {
          await interaction.reply({ content: 'Terjadi kesalahan!', ephemeral: true }).catch(() => {});
        }
      }
    }
    if (interaction.isButton()) {
      const [action, ...args] = interaction.customId.split(':');
      if (action === 'confirm_buy') {
        const { executeConfirmBuy } = require('../commands/trading/buy');
        await executeConfirmBuy(interaction, args);
      } else if (action === 'confirm_sell') {
        const { executeConfirmSell } = require('../commands/trading/sell');
        await executeConfirmSell(interaction, args);
      } else if (action === 'cancel_buy' || action === 'cancel_sell') {
        await interaction.update({ content: '❌ Order dibatalkan.', components: [], embeds: [] }).catch(() => {});
      } else {
        await interaction.reply({ content: 'Button belum diimplementasikan.', ephemeral: true }).catch(() => {});
      }
    }
    if (interaction.isModalSubmit()) {
      if (interaction.customId === 'company_create') {
        const { handleModal } = require('../commands/company/company');
        await handleModal(interaction);
      }
    }
  }
};
