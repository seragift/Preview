const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const portfolioEngine = require('../../services/portfolioEngine');
const transactionRepository = require('../../database/repositories/transactionRepository');
const achievementEngine = require('../../services/achievementEngine');
const formatMoney = require('../../utils/formatMoney');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('profile')
    .setDescription('View your profile'),
  execute: async (interaction) => {
    const nw = portfolioEngine.getNetWorth(interaction.user.id);
    const details = portfolioEngine.getPortfolioDetails(interaction.user.id);
    const trades = transactionRepository.getTradeCount(interaction.user.id);
    const achievements = achievementEngine.getUserAchievements(interaction.user.id);
    const embed = new EmbedBuilder()
      .setTitle(`WALLSTREET DC — @${interaction.user.username}`)
      .setThumbnail(interaction.user.displayAvatarURL({ size: 128 }))
      .addFields(
        { name: '💰 Net Worth', value: formatMoney(nw), inline: true },
        { name: '💼 Portfolio', value: formatMoney(details.stockValue), inline: true },
        { name: '💵 Cash', value: formatMoney(details.cash), inline: true },
        { name: '📊 Return', value: `${details.returnPct >= 0 ? '+' : ''}${details.returnPct.toFixed(2)}%`, inline: true },
        { name: '🔄 Trades', value: trades.toString(), inline: true },
        { name: '🏆 Achievements', value: achievements.length.toString(), inline: true }
      )
      .setColor(0x3b82f6)
      .setTimestamp();
    await interaction.reply({ embeds: [embed] });
  }
};
