const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const achievementEngine = require('../../services/achievementEngine');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('achievements')
    .setDescription('View your achievements'),
  execute: async (interaction) => {
    const achievements = achievementEngine.getUserAchievements(interaction.user.id);
    if (achievements.length === 0) return interaction.reply({ content: 'Belum ada achievement.', ephemeral: true });
    const embed = new EmbedBuilder().setTitle('🏆 Achievements').setColor(0xfbbf24);
    for (const a of achievements) {
      embed.addFields({ name: `${a.icon || '🏅'} ${a.name}`, value: a.description, inline: false });
    }
    await interaction.reply({ embeds: [embed], ephemeral: true });
  }
};
