const { SlashCommandBuilder } = require('discord.js');
const stockRepository = require('../../database/repositories/stockRepository');
const generateStockChart = require('../../canvas/stockChart');
const generateStockCard = require('../../canvas/stockCard');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('stock')
    .setDescription('View stock details')
    .addStringOption(opt => opt.setName('ticker').setDescription('Stock ticker').setRequired(true)),
  execute: async (interaction) => {
    await interaction.deferReply();
    const ticker = interaction.options.getString('ticker').toUpperCase();
    const stock = stockRepository.getByTicker(ticker);
    if (!stock) return interaction.editReply({ content: '❌ Stock tidak ditemukan.' });
    const history = stockRepository.getPriceHistoryAsc(ticker, 60);
    const chartBuffer = await generateStockChart(stock, history);
    const cardBuffer = await generateStockCard(stock);
    await interaction.editReply({
      files: [
        { attachment: chartBuffer, name: 'chart.png' },
        { attachment: cardBuffer, name: 'card.png' }
      ]
    });
  }
};
