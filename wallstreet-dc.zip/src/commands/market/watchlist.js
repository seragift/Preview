const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const db = require('../../database/connection');
const stockRepository = require('../../database/repositories/stockRepository');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('watchlist')
    .setDescription('Manage watchlist')
    .addSubcommand(s => s.setName('add').setDescription('Add stock').addStringOption(o => o.setName('ticker').setDescription('Ticker').setRequired(true)))
    .addSubcommand(s => s.setName('remove').setDescription('Remove stock').addStringOption(o => o.setName('ticker').setDescription('Ticker').setRequired(true)))
    .addSubcommand(s => s.setName('list').setDescription('View watchlist')),
  execute: async (interaction) => {
    const sub = interaction.options.getSubcommand();
    const database = db.get();

    if (sub === 'add') {
      const ticker = interaction.options.getString('ticker').toUpperCase();
      const stock = stockRepository.getByTicker(ticker);
      if (!stock) return interaction.reply({ content: '❌ Stock tidak ditemukan.', ephemeral: true });
      database.prepare('INSERT OR IGNORE INTO watchlists (discord_id, ticker) VALUES (?, ?)').run(interaction.user.id, ticker);
      return interaction.reply({ content: `✅ ${ticker} ditambahkan ke watchlist.`, ephemeral: true });
    }
    if (sub === 'remove') {
      const ticker = interaction.options.getString('ticker').toUpperCase();
      database.prepare('DELETE FROM watchlists WHERE discord_id = ? AND ticker = ?').run(interaction.user.id, ticker);
      return interaction.reply({ content: `✅ ${ticker} dihapus dari watchlist.`, ephemeral: true });
    }
    if (sub === 'list') {
      const rows = database.prepare('SELECT w.ticker, s.name, s.current_price, s.previous_price FROM watchlists w JOIN stocks s ON w.ticker = s.ticker WHERE w.discord_id = ?').all(interaction.user.id);
      if (rows.length === 0) return interaction.reply({ content: 'Watchlist kosong.', ephemeral: true });
      const embed = new EmbedBuilder().setTitle('👀 Watchlist').setColor(0x3b82f6);
      for (const r of rows) {
        const change = ((r.current_price - r.previous_price) / r.previous_price) * 100;
        embed.addFields({ name: `${r.ticker} — ${r.name}`, value: `$${r.current_price} (${change >= 0 ? '+' : ''}${change.toFixed(2)}%)`, inline: true });
      }
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }
  }
};
