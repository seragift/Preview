const { SlashCommandBuilder } = require('discord.js');
const stockRepository = require('../../database/repositories/stockRepository');
const formatMoney = require('../../utils/formatMoney');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('quote')
    .setDescription('Get quick stock quote')
    .addStringOption(opt => opt.setName('ticker').setDescription('Stock ticker').setRequired(true)),
  execute: async (interaction) => {
    const ticker = interaction.options.getString('ticker').toUpperCase();
    const stock = stockRepository.getByTicker(ticker);
    if (!stock) return interaction.reply({ content: '❌ Stock tidak ditemukan.', ephemeral: true });
    const change = ((stock.current_price - stock.previous_price) / stock.previous_price) * 100;
    const embed = {
      title: `${stock.ticker} — ${stock.name}`,
      description: `**${formatMoney(stock.current_price)}**  ${change >= 0 ? '🟢' : '🔴'} ${change >= 0 ? '+' : ''}${change.toFixed(2)}%`,
      fields: [
        { name: 'Sector', value: stock.sector, inline: true },
        { name: 'Market Cap', value: formatMoney(stock.market_cap || stock.current_price * stock.shares_outstanding), inline: true },
        { name: 'Volatility', value: `${(stock.volatility * 100).toFixed(1)}%`, inline: true },
      ],
      color: change >= 0 ? 0x22c55e : 0xef4444
    };
    await interaction.reply({ embeds: [embed] });
  }
};
