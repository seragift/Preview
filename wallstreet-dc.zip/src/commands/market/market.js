const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const marketRepository = require('../../database/repositories/marketRepository');
const generateMarketDashboard = require('../../canvas/marketDashboard');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('market')
    .setDescription('View market dashboard'),
  execute: async (interaction) => {
    await interaction.deferReply();
    const gainers = marketRepository.getTopGainers(5);
    const losers = marketRepository.getTopLosers(5);
    const sentiment = marketRepository.getSentiment();
    const buffer = await generateMarketDashboard(gainers, losers, sentiment);
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('market_gainers').setLabel('Top Gainers').setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId('market_losers').setLabel('Top Losers').setStyle(ButtonStyle.Danger),
      new ButtonBuilder().setCustomId('market_portfolio').setLabel('My Portfolio').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('market_news').setLabel('News').setStyle(ButtonStyle.Secondary)
    );
    await interaction.editReply({ files: [{ attachment: buffer, name: 'market.png' }], components: [row] });
  }
};
