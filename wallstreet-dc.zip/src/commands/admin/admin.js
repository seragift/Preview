const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const marketEngine = require('../../services/marketEngine');
const stockRepository = require('../../database/repositories/stockRepository');
const walletRepository = require('../../database/repositories/walletRepository');
const db = require('../../database/connection');
const formatMoney = require('../../utils/formatMoney');
const logger = require('../../utils/logger');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('admin')
    .setDescription('Admin commands')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand(s => s.setName('market-start').setDescription('Start market'))
    .addSubcommand(s => s.setName('market-stop').setDescription('Stop market'))
    .addSubcommand(s => s.setName('stock-create').setDescription('Create stock')
      .addStringOption(o => o.setName('ticker').setDescription('Ticker').setRequired(true))
      .addStringOption(o => o.setName('name').setDescription('Name').setRequired(true))
      .addStringOption(o => o.setName('sector').setDescription('Sector').setRequired(true))
      .addNumberOption(o => o.setName('price').setDescription('Price').setRequired(true))
      .addIntegerOption(o => o.setName('shares').setDescription('Shares').setRequired(true)))
    .addSubcommand(s => s.setName('stock-edit').setDescription('Edit stock price')
      .addStringOption(o => o.setName('ticker').setDescription('Ticker').setRequired(true))
      .addNumberOption(o => o.setName('price').setDescription('New price').setRequired(true)))
    .addSubcommand(s => s.setName('event').setDescription('Trigger event')
      .addStringOption(o => o.setName('name').setDescription('Event name').setRequired(true))
      .addStringOption(o => o.setName('sector').setDescription('Sector').setRequired(false))
      .addNumberOption(o => o.setName('impact').setDescription('Impact %').setRequired(true))
      .addIntegerOption(o => o.setName('duration').setDescription('Duration seconds').setRequired(true)))
    .addSubcommand(s => s.setName('news').setDescription('Post news')
      .addStringOption(o => o.setName('title').setDescription('Title').setRequired(true))
      .addStringOption(o => o.setName('ticker').setDescription('Ticker').setRequired(false))
      .addNumberOption(o => o.setName('impact').setDescription('Impact').setRequired(true)))
    .addSubcommand(s => s.setName('give-money').setDescription('Give money')
      .addUserOption(o => o.setName('user').setDescription('User').setRequired(true))
      .addIntegerOption(o => o.setName('amount').setDescription('Amount').setRequired(true)))
    .addSubcommand(s => s.setName('remove-money').setDescription('Remove money')
      .addUserOption(o => o.setName('user').setDescription('User').setRequired(true))
      .addIntegerOption(o => o.setName('amount').setDescription('Amount').setRequired(true)))
    .addSubcommand(s => s.setName('reset-player').setDescription('Reset player')
      .addUserOption(o => o.setName('user').setDescription('User').setRequired(true)))
    .addSubcommand(s => s.setName('stats').setDescription('Bot stats')),
  execute: async (interaction) => {
    const sub = interaction.options.getSubcommand();
    const database = db.get();

    if (sub === 'market-start') {
      marketEngine.start();
      database.prepare("INSERT INTO audit_logs (discord_id, action, details) VALUES (?, ?, ?)").run(interaction.user.id, 'MARKET_START', 'Admin started market');
      return interaction.reply({ content: '✅ Market started.', ephemeral: true });
    }
    if (sub === 'market-stop') {
      marketEngine.stop();
      database.prepare("INSERT INTO audit_logs (discord_id, action, details) VALUES (?, ?, ?)").run(interaction.user.id, 'MARKET_STOP', 'Admin stopped market');
      return interaction.reply({ content: '✅ Market stopped.', ephemeral: true });
    }
    if (sub === 'stock-create') {
      const ticker = interaction.options.getString('ticker').toUpperCase();
      const name = interaction.options.getString('name');
      const sector = interaction.options.getString('sector');
      const price = interaction.options.getNumber('price');
      const shares = interaction.options.getInteger('shares');
      stockRepository.create({ ticker, name, sector, description: '', current_price: price, shares_outstanding: shares, volatility: 0.03, fundamental_score: 50 });
      database.prepare("INSERT INTO audit_logs (discord_id, action, target, details) VALUES (?, ?, ?, ?)").run(interaction.user.id, 'STOCK_CREATE', ticker, `${name} @ ${price}`);
      return interaction.reply({ content: `✅ Stock ${ticker} created.`, ephemeral: true });
    }
    if (sub === 'stock-edit') {
      const ticker = interaction.options.getString('ticker').toUpperCase();
      const price = interaction.options.getNumber('price');
      stockRepository.updatePrice(ticker, price);
      database.prepare("INSERT INTO audit_logs (discord_id, action, target, details) VALUES (?, ?, ?, ?)").run(interaction.user.id, 'STOCK_EDIT', ticker, price.toString());
      return interaction.reply({ content: `✅ ${ticker} price set to ${formatMoney(price)}.`, ephemeral: true });
    }
    if (sub === 'event') {
      const name = interaction.options.getString('name');
      const sector = interaction.options.getString('sector') || null;
      const impact = interaction.options.getNumber('impact');
      const duration = interaction.options.getInteger('duration');
      const marketRepo = require('../../database/repositories/marketRepository');
      marketRepo.createEvent({ name, description: name, sector, impact, duration });
      database.prepare("INSERT INTO audit_logs (discord_id, action, details) VALUES (?, ?, ?)").run(interaction.user.id, 'EVENT_TRIGGER', name);
      return interaction.reply({ content: `🚨 Event "${name}" triggered!`, ephemeral: true });
    }
    if (sub === 'news') {
      const title = interaction.options.getString('title');
      const ticker = interaction.options.getString('ticker');
      const impact = interaction.options.getNumber('impact');
      const newsRepo = require('../../database/repositories/newsRepository');
      newsRepo.create({ title, content: title, ticker, sector: null, impact });
      database.prepare("INSERT INTO audit_logs (discord_id, action, details) VALUES (?, ?, ?)").run(interaction.user.id, 'NEWS_POST', title);
      return interaction.reply({ content: `📰 News posted: "${title}"`, ephemeral: true });
    }
    if (sub === 'give-money') {
      const target = interaction.options.getUser('user');
      const amount = interaction.options.getInteger('amount');
      walletRepository.updateBalance(target.id, amount);
      walletRepository.addTransaction(target.id, 'ADMIN_GIVE', amount, `Given by admin ${interaction.user.id}`);
      database.prepare("INSERT INTO audit_logs (discord_id, action, target, details) VALUES (?, ?, ?, ?)").run(interaction.user.id, 'GIVE_MONEY', target.id, amount.toString());
      return interaction.reply({ content: `✅ Gave ${formatMoney(amount)} to ${target.username}`, ephemeral: true });
    }
    if (sub === 'remove-money') {
      const target = interaction.options.getUser('user');
      const amount = interaction.options.getInteger('amount');
      walletRepository.updateBalance(target.id, -amount);
      walletRepository.addTransaction(target.id, 'ADMIN_REMOVE', -amount, `Removed by admin ${interaction.user.id}`);
      database.prepare("INSERT INTO audit_logs (discord_id, action, target, details) VALUES (?, ?, ?, ?)").run(interaction.user.id, 'REMOVE_MONEY', target.id, amount.toString());
      return interaction.reply({ content: `✅ Removed ${formatMoney(amount)} from ${target.username}`, ephemeral: true });
    }
    if (sub === 'reset-player') {
      const target = interaction.options.getUser('user');
      database.prepare('DELETE FROM portfolios WHERE discord_id = ?').run(target.id);
      database.prepare('DELETE FROM holdings WHERE discord_id = ?').run(target.id);
      database.prepare('DELETE FROM orders WHERE discord_id = ?').run(target.id);
      database.prepare('DELETE FROM trades WHERE discord_id = ?').run(target.id);
      database.prepare('UPDATE wallets SET balance = ?, total_deposited = 0, total_withdrawn = 0 WHERE discord_id = ?').run(100000, target.id);
      database.prepare("INSERT INTO audit_logs (discord_id, action, target, details) VALUES (?, ?, ?, ?)").run(interaction.user.id, 'RESET_PLAYER', target.id, 'Player reset');
      return interaction.reply({ content: `✅ ${target.username} reset.`, ephemeral: true });
    }
    if (sub === 'stats') {
      const users = database.prepare('SELECT COUNT(*) as c FROM users').get().c;
      const stocks = database.prepare('SELECT COUNT(*) as c FROM stocks').get().c;
      const trades = database.prepare('SELECT COUNT(*) as c FROM trades').get().c;
      const embed = new EmbedBuilder().setTitle('📊 Bot Stats').setColor(0x3b82f6)
        .addFields(
          { name: 'Users', value: users.toString(), inline: true },
          { name: 'Stocks', value: stocks.toString(), inline: true },
          { name: 'Trades', value: trades.toString(), inline: true },
          { name: 'Market', value: marketEngine.isRunning() ? '🟢 OPEN' : '🔴 CLOSED', inline: true }
        );
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }
  }
};
