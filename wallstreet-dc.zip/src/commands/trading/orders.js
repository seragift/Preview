const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const orderRepository = require('../../database/repositories/orderRepository');
const formatMoney = require('../../utils/formatMoney');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('orders')
    .setDescription('View your open orders'),
  execute: async (interaction) => {
    const orders = orderRepository.getByUser(interaction.user.id, 'OPEN');
    if (orders.length === 0) return interaction.reply({ content: 'Tidak ada order aktif.', ephemeral: true });
    const embed = new EmbedBuilder().setTitle('📋 Open Orders').setColor(0x3b82f6);
    for (const o of orders) {
      embed.addFields({
        name: `#${o.id} — ${o.side} ${o.ticker}`,
        value: `Type: ${o.type} | Qty: ${o.quantity} | Price: ${o.price ? formatMoney(o.price) : 'MARKET'}`,
        inline: false
      });
    }
    await interaction.reply({ embeds: [embed], ephemeral: true });
  }
};
