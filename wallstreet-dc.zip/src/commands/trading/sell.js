const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');
const stockRepository = require('../../database/repositories/stockRepository');
const walletRepository = require('../../database/repositories/walletRepository');
const portfolioRepository = require('../../database/repositories/portfolioRepository');
const transactionRepository = require('../../database/repositories/transactionRepository');
const economyEngine = require('../../services/economyEngine');
const formatMoney = require('../../utils/formatMoney');
const config = require('../../config/config');
const logger = require('../../utils/logger');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('sell')
    .setDescription('Sell stock')
    .addStringOption(o => o.setName('ticker').setDescription('Stock ticker').setRequired(true))
    .addIntegerOption(o => o.setName('quantity').setDescription('Quantity').setRequired(true)),
  execute: async (interaction) => {
    const ticker = interaction.options.getString('ticker').toUpperCase();
    const qty = interaction.options.getInteger('quantity');
    const stock = stockRepository.getByTicker(ticker);
    if (!stock) return interaction.reply({ content: '❌ Stock tidak ditemukan.', ephemeral: true });
    const holding = portfolioRepository.getHolding(interaction.user.id, ticker);
    if (!holding || holding.quantity < qty) return interaction.reply({ content: '❌ Saham tidak cukup.', ephemeral: true });
    if (qty <= 0) return interaction.reply({ content: '❌ Quantity harus positif.', ephemeral: true });

    const total = qty * stock.current_price;
    const fee = economyEngine.calculateFee(total);
    const net = total - fee;

    const embed = new EmbedBuilder()
      .setTitle('📉 SELL ORDER')
      .setDescription(`**${ticker}**\nQuantity: ${qty}\nPrice: ${formatMoney(stock.current_price)}\n\nEstimated Proceeds: ${formatMoney(total)}\nFee: ${formatMoney(fee)}\n**Net: ${formatMoney(net)}**`)
      .setColor(0xef4444);

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`confirm_sell:${ticker}:${qty}:${stock.current_price}`).setLabel('CONFIRM').setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId(`cancel_sell:${ticker}:${qty}`).setLabel('CANCEL').setStyle(ButtonStyle.Danger)
    );
    await interaction.reply({ embeds: [embed], components: [row], ephemeral: true });
  }
};

module.exports.executeConfirmSell = async (interaction, args) => {
  const [ticker, qtyStr, priceStr] = args;
  const qty = parseInt(qtyStr);
  const price = parseFloat(priceStr);
  const total = qty * price;
  const fee = total * config.transactionFee;

  const db = require('../../database/connection');
  const database = db.get();
  try {
    database.transaction(() => {
      const ok = portfolioRepository.removeHolding(interaction.user.id, ticker, qty);
      if (!ok) throw new Error('Insufficient shares');
      walletRepository.updateBalance(interaction.user.id, total - fee);
      transactionRepository.create(interaction.user.id, ticker, 'SELL', qty, price, fee, total);
    })();
    await interaction.update({ content: `✅ **SELL** ${qty} **${ticker}** @ ${formatMoney(price)} berhasil!`, components: [], embeds: [] });
  } catch (err) {
    logger.error('[SELL CONFIRM]', err);
    await interaction.update({ content: `❌ Gagal: ${err.message}`, components: [], embeds: [] });
  }
};
