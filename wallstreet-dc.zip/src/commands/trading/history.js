const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const transactionRepository = require('../../database/repositories/transactionRepository');
const formatMoney = require('../../utils/formatMoney');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('history')
    .setDescription('View trade history')
    .addStringOption(o => o.setName('ticker').setDescription('Filter by ticker').setRequired(false)),
  execute: async (interaction) => {
    const ticker = interaction.options.getString('ticker');
    const trades = transactionRepository.getByUser(interaction.user.id, 15);
    if (trades.length === 0) return interaction.reply({ content: 'Belum ada transaksi.', ephemeral: true });
    const embed = new EmbedBuilder().setTitle('📜 Trade History').setColor(0x8b5cf6);
    for (const t of trades) {
      if (ticker && t.ticker !== ticker.toUpperCase()) continue;
      const color = t.side === 'BUY' ? '🟢' : '🔴';
      embed.addFields({
        name: `${color} ${t.side} ${t.quantity} ${t.ticker}`,
        value: `@ ${formatMoney(t.price)} | Fee: ${formatMoney(t.fee)} | Total: ${formatMoney(t.total)}`,
        inline: false
      });
    }
    await interaction.reply({ embeds: [embed], ephemeral: true });
  }
};
