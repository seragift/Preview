const { SlashCommandBuilder } = require('discord.js');
const orderRepository = require('../../database/repositories/orderRepository');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('cancel-order')
    .setDescription('Cancel an order')
    .addIntegerOption(o => o.setName('id').setDescription('Order ID').setRequired(true)),
  execute: async (interaction) => {
    const id = interaction.options.getInteger('id');
    const order = orderRepository.getById(id);
    if (!order) return interaction.reply({ content: '❌ Order tidak ditemukan.', ephemeral: true });
    if (order.discord_id !== interaction.user.id) return interaction.reply({ content: '❌ Bukan order Anda.', ephemeral: true });
    if (order.status !== 'OPEN') return interaction.reply({ content: '❌ Order sudah tidak aktif.', ephemeral: true });
    orderRepository.cancel(id);
    await interaction.reply({ content: `✅ Order #${id} dibatalkan.`, ephemeral: true });
  }
};
