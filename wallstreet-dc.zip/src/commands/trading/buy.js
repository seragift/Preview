const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');
const stockRepository = require('../../database/repositories/stockRepository');
const walletRepository = require('../../database/repositories/walletRepository');
const portfolioRepository = require('../../database/repositories/portfolioRepository');
const transactionRepository = require('../../database/repositories/transactionRepository');
const economyEngine = require('../../services/economyEngine');
const achievementEngine = require('../../services/achievementEngine');
const formatMoney = require('../../utils/formatMoney');
const config = require('../../config/config');
const logger = require('../../utils/logger');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('buy')
    .setDescription('Buy stock')
    .addStringOption(o => o.setName('ticker').setDescription('Stock ticker').setRequired(true))
    .addIntegerOption(o => o.setName('quantity').setDescription('Quantity').setRequired(true)),
  execute: async (interaction) => {
    const ticker = interaction.options.getString('ticker').toUpperCase();
    const qty = interaction.options.getInteger('quantity');
    const stock = stockRepository.getByTicker(ticker);
    if (!stock) return interaction.reply({ content: '❌ Stock tidak ditemukan.', ephemeral: true });
    if (qty <= 0) return interaction.reply({ content: '❌ Quantity harus positif.', ephemeral: true });

    const total = qty * stock.current_price;
    const fee = economyEngine.calculateFee(total);
    const grandTotal = total + fee;
    const wallet = walletRepository.getById(interaction.user.id);
    if (!wallet || wallet.balance < grandTotal) return interaction.reply({ content: '❌ Saldo tidak cukup.', ephemeral: true });

    const embed = new EmbedBuilder()
      .setTitle('📈 BUY ORDER')
      .setDescription(`**${ticker}**\nQuantity: ${qty}\nPrice: ${formatMoney(stock.current_price)}\n\nEstimated Cost: ${formatMoney(total)}\nFee: ${formatMoney(fee)}\n**Total: ${formatMoney(grandTotal)}**`)
      .setColor(0x22c55e);

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`confirm_buy:${ticker}:${qty}:${stock.current_price}`).setLabel('CONFIRM').setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId(`cancel_buy:${ticker}:${qty}`).setLabel('CANCEL').setStyle(ButtonStyle.Danger)
    );
    await interaction.reply({ embeds: [embed], components: [row], ephemeral: true });
  }
};

module.exports.executeConfirmBuy = async (interaction, args) => {
  const [ticker, qtyStr, priceStr] = args;
  const qty = parseInt(qtyStr);
  const price = parseFloat(priceStr);
  const total = qty * price;
  const fee = total * config.transactionFee;

  const db = require('../../database/connection');
  const database = db.get();
  try {
    database.transaction(() => {
      const wallet = walletRepository.getById(interaction.user.id);
      if (!wallet || wallet.balance < total + fee) throw new Error('Insufficient balance');
      walletRepository.updateBalance(interaction.user.id, -(total + fee));
      portfolioRepository.addHolding(interaction.user.id, ticker, qty, price);
      transactionRepository.create(interaction.user.id, ticker, 'BUY', qty, price, fee, total);
    })();
    achievementEngine.checkFirstTrade(interaction.user.id);
    achievementEngine.checkNetWorth(interaction.user.id);
    await interaction.update({ content: `✅ **BUY** ${qty} **${ticker}** @ ${formatMoney(price)} berhasil!`, components: [], embeds: [] });
  } catch (err) {
    logger.error('[BUY CONFIRM]', err);
    await interaction.update({ content: `❌ Gagal: ${err.message}`, components: [], embeds: [] });
  }
};
