const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const walletRepository = require('../../database/repositories/walletRepository');
const formatMoney = require('../../utils/formatMoney');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('balance')
    .setDescription('Check your balance'),
  execute: async (interaction) => {
    const wallet = walletRepository.getById(interaction.user.id);
    const embed = new EmbedBuilder().setTitle('💳 Balance').setColor(0x22c55e)
      .setDescription(`**${formatMoney(wallet?.balance || 0)}**`);
    await interaction.reply({ embeds: [embed], ephemeral: true });
  }
};
