const { SlashCommandBuilder } = require('discord.js');
const portfolioEngine = require('../../services/portfolioEngine');
const generatePortfolioCard = require('../../canvas/portfolioCard');
const generatePortfolioChart = require('../../canvas/portfolioChart');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('portfolio')
    .setDescription('View your portfolio'),
  execute: async (interaction) => {
    await interaction.deferReply();
    const data = portfolioEngine.getPortfolioDetails(interaction.user.id);
    const cardBuffer = await generatePortfolioCard(data);
    const chartBuffer = await generatePortfolioChart(data);
    await interaction.editReply({
      files: [
        { attachment: cardBuffer, name: 'portfolio.png' },
        { attachment: chartBuffer, name: 'chart.png' }
      ]
    });
  }
};
