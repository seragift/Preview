const { SlashCommandBuilder } = require('discord.js');
const rankingEngine = require('../../services/rankingEngine');
const generateLeaderboardCard = require('../../canvas/leaderboardCard');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('leaderboard')
    .setDescription('View leaderboard')
    .addStringOption(o => o.setName('category').setDescription('Category')
      .addChoices(
        { name: 'Net Worth', value: 'net_worth' },
        { name: 'Best Trader', value: 'trades' },
        { name: 'Best Return', value: 'return' }
      )),
  execute: async (interaction) => {
    await interaction.deferReply();
    const category = interaction.options.getString('category') || 'net_worth';
    const board = rankingEngine.getLeaderboard(category, 10);
    const buffer = await generateLeaderboardCard(board, category === 'net_worth' ? 'Net Worth Leaderboard' : 'Leaderboard');
    await interaction.editReply({ files: [{ attachment: buffer, name: 'leaderboard.png' }] });
  }
};
