const { SlashCommandBuilder } = require('discord.js');
const rankingEngine = require('../../services/rankingEngine');
const portfolioEngine = require('../../services/portfolioEngine');
const formatMoney = require('../../utils/formatMoney');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('rank')
    .setDescription('View your rank'),
  execute: async (interaction) => {
    const board = rankingEngine.getLeaderboard('net_worth', 100);
    const myRank = board.findIndex(e => e.discord_id === interaction.user.id) + 1;
    const nw = portfolioEngine.getNetWorth(interaction.user.id);
    await interaction.reply({ content: `🏆 Rank Anda: **#${myRank}**\n💰 Net Worth: ${formatMoney(nw)}`, ephemeral: true });
  }
};
