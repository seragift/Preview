const { SlashCommandBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder, EmbedBuilder } = require('discord.js');
const companyRepository = require('../../database/repositories/companyRepository');
const companyEngine = require('../../services/companyEngine');
const generateCompanyCard = require('../../canvas/companyCard');
const formatMoney = require('../../utils/formatMoney');
const logger = require('../../utils/logger');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('company')
    .setDescription('Company system')
    .addSubcommand(s => s.setName('create').setDescription('Create a company'))
    .addSubcommand(s => s.setName('profile').setDescription('View your company'))
    .addSubcommand(s => s.setName('employees').setDescription('View company employees'))
    .addSubcommand(s => s.setName('financials').setDescription('View company financials'))
    .addSubcommand(s => s.setName('ipo').setDescription('Launch IPO'))
    .addSubcommand(s => s.setName('dividend').setDescription('Declare dividend').addIntegerOption(o => o.setName('amount').setDescription('Per share').setRequired(true)))
    .addSubcommand(s => s.setName('jobs').setDescription('View available jobs'))
    .addSubcommand(s => s.setName('apply').setDescription('Apply to company').addStringOption(o => o.setName('company').setDescription('Company ticker').setRequired(true))),
  execute: async (interaction) => {
    const sub = interaction.options.getSubcommand();

    if (sub === 'create') {
      const existing = companyRepository.getByFounder(interaction.user.id);
      if (existing) return interaction.reply({ content: '❌ Anda sudah memiliki perusahaan.', ephemeral: true });
      const modal = new ModalBuilder().setCustomId('company_create').setTitle('Create Company');
      const nameInput = new TextInputBuilder().setCustomId('name').setLabel('Company Name (3-32 chars)').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(32);
      const tickerInput = new TextInputBuilder().setCustomId('ticker').setLabel('Ticker (2-5 uppercase)').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(5);
      const sectorInput = new TextInputBuilder().setCustomId('sector').setLabel('Sector').setStyle(TextInputStyle.Short).setRequired(true);
      const descInput = new TextInputBuilder().setCustomId('description').setLabel('Description').setStyle(TextInputStyle.Paragraph).setRequired(false);
      modal.addComponents(
        new ActionRowBuilder().addComponents(nameInput),
        new ActionRowBuilder().addComponents(tickerInput),
        new ActionRowBuilder().addComponents(sectorInput),
        new ActionRowBuilder().addComponents(descInput)
      );
      await interaction.showModal(modal);
    }
    else if (sub === 'profile') {
      await interaction.deferReply();
      const company = companyRepository.getByFounder(interaction.user.id) || companyRepository.getMemberCompany(interaction.user.id);
      if (!company) return interaction.editReply({ content: '❌ Anda tidak memiliki perusahaan.' });
      const buffer = await generateCompanyCard(company);
      await interaction.editReply({ files: [{ attachment: buffer, name: 'company.png' }] });
    }
    else if (sub === 'employees') {
      const company = companyRepository.getByFounder(interaction.user.id);
      if (!company) return interaction.reply({ content: '❌ Anda bukan founder.', ephemeral: true });
      const employees = companyRepository.getEmployees(company.company_id);
      const embed = new EmbedBuilder().setTitle(`👥 ${company.name} Employees`).setColor(0x3b82f6);
      for (const e of employees) {
        embed.addFields({ name: e.role, value: `<@${e.discord_id}>`, inline: true });
      }
      await interaction.reply({ embeds: [embed], ephemeral: true });
    }
    else if (sub === 'financials') {
      const company = companyRepository.getByFounder(interaction.user.id);
      if (!company) return interaction.reply({ content: '❌ Anda bukan founder.', ephemeral: true });
      const embed = new EmbedBuilder().setTitle(`📊 ${company.name} Financials`).setColor(0x22c55e)
        .addFields(
          { name: 'Cash', value: formatMoney(company.cash), inline: true },
          { name: 'Revenue', value: formatMoney(company.revenue), inline: true },
          { name: 'Expenses', value: formatMoney(company.expenses), inline: true },
          { name: 'Profit', value: formatMoney(company.profit), inline: true },
          { name: 'Valuation', value: formatMoney(company.valuation), inline: true },
          { name: 'Reputation', value: `${company.reputation}/100`, inline: true }
        );
      await interaction.reply({ embeds: [embed], ephemeral: true });
    }
    else if (sub === 'ipo') {
      const company = companyRepository.getByFounder(interaction.user.id);
      if (!company) return interaction.reply({ content: '❌ Anda bukan founder.', ephemeral: true });
      if (company.is_public) return interaction.reply({ content: '❌ Perusahaan sudah public.', ephemeral: true });
      const { launchIPO } = require('../../services/ipoEngine');
      const result = launchIPO(company.company_id, company.valuation || 1000000, 1000000, 20, 10);
      if (!result) return interaction.reply({ content: '❌ Gagal launch IPO.', ephemeral: true });
      await interaction.reply({ content: `🚀 IPO ${company.name} (${result.ticker}) launched at ${formatMoney(result.ipo_price)}!` });
    }
    else if (sub === 'dividend') {
      const company = companyRepository.getByFounder(interaction.user.id);
      if (!company) return interaction.reply({ content: '❌ Anda bukan founder.', ephemeral: true });
      const amount = interaction.options.getInteger('amount');
      if (amount <= 0) return interaction.reply({ content: '❌ Amount harus positif.', ephemeral: true });
      const { declareDividend } = require('../../services/dividendEngine');
      const total = declareDividend(company.company_id, amount);
      await interaction.reply({ content: `💰 Dividend ${formatMoney(total)} dibagikan kepada shareholders!` });
    }
    else if (sub === 'jobs') {
      const companies = companyRepository.getAll();
      const embed = new EmbedBuilder().setTitle('🏢 Open Positions').setColor(0x8b5cf6);
      for (const c of companies.slice(0, 10)) {
        embed.addFields({ name: `${c.name} (${c.ticker})`, value: `Sector: ${c.sector} | Employees: ${c.employees}`, inline: false });
      }
      await interaction.reply({ embeds: [embed], ephemeral: true });
    }
    else if (sub === 'apply') {
      const ticker = interaction.options.getString('company').toUpperCase();
      const company = companyRepository.getByTicker(ticker);
      if (!company) return interaction.reply({ content: '❌ Perusahaan tidak ditemukan.', ephemeral: true });
      companyRepository.addEmployee(company.company_id, interaction.user.id, 'EMPLOYEE');
      await interaction.reply({ content: `✅ Lamaran ke ${company.name} dikirim!` });
    }
  }
};

module.exports.handleModal = async (interaction) => {
  const name = interaction.fields.getTextInputValue('name');
  const ticker = interaction.fields.getTextInputValue('ticker').toUpperCase();
  const sector = interaction.fields.getTextInputValue('sector');
  const description = interaction.fields.getTextInputValue('description') || '';

  if (!/^[A-Z]{2,5}$/.test(ticker)) return interaction.reply({ content: '❌ Ticker harus 2-5 huruf kapital.', ephemeral: true });
  if (name.length < 3 || name.length > 32) return interaction.reply({ content: '❌ Nama 3-32 karakter.', ephemeral: true });

  const existing = companyRepository.getByTicker(ticker);
  if (existing) return interaction.reply({ content: '❌ Ticker sudah dipakai.', ephemeral: true });

  companyEngine.createCompany({ name, ticker, sector, description, founder_id: interaction.user.id });
  logger.info(`[COMPANY] ${name} (${ticker}) created by ${interaction.user.id}`);
  await interaction.reply({ content: `🏢 **${name}** (${ticker}) berhasil dibuat!` });
};
