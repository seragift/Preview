const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const walletRepository = require('../../database/repositories/walletRepository');
const formatMoney = require('../../utils/formatMoney');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('bank')
    .setDescription('Banking options')
    .addSubcommand(s => s.setName('balance').setDescription('Check bank balance'))
    .addSubcommand(s => s.setName('deposit').setDescription('Deposit cash').addIntegerOption(o => o.setName('amount').setDescription('Amount').setRequired(true)))
    .addSubcommand(s => s.setName('withdraw').setDescription('Withdraw cash').addIntegerOption(o => o.setName('amount').setDescription('Amount').setRequired(true)))
    .addSubcommand(s => s.setName('loan').setDescription('Take a loan').addIntegerOption(o => o.setName('amount').setDescription('Amount').setRequired(true)).addIntegerOption(o => o.setName('days').setDescription('Days until due').setRequired(true)))
    .addSubcommand(s => s.setName('repay').setDescription('Repay loan').addIntegerOption(o => o.setName('loan_id').setDescription('Loan ID').setRequired(true))),
  execute: async (interaction) => {
    const sub = interaction.options.getSubcommand();
    const wallet = walletRepository.getById(interaction.user.id);
    if (!wallet) return interaction.reply({ content: '❌ Wallet tidak ditemukan.', ephemeral: true });

    if (sub === 'balance') {
      const embed = new EmbedBuilder()
        .setTitle('🏦 Bank')
        .setDescription(`Balance: **${formatMoney(wallet.balance)}**`)
        .setColor(0x3b82f6);
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    if (sub === 'deposit') {
      const amount = interaction.options.getInteger('amount');
      if (amount <= 0) return interaction.reply({ content: '❌ Amount harus positif.', ephemeral: true });
      walletRepository.addTransaction(interaction.user.id, 'DEPOSIT', amount, 'Bank deposit');
      return interaction.reply({ content: `✅ Deposited ${formatMoney(amount)}`, ephemeral: true });
    }

    if (sub === 'withdraw') {
      const amount = interaction.options.getInteger('amount');
      if (amount <= 0) return interaction.reply({ content: '❌ Amount harus positif.', ephemeral: true });
      if (wallet.balance < amount) return interaction.reply({ content: '❌ Saldo tidak cukup.', ephemeral: true });
      walletRepository.updateBalance(interaction.user.id, -amount);
      walletRepository.addTransaction(interaction.user.id, 'WITHDRAW', amount, 'Bank withdraw');
      return interaction.reply({ content: `✅ Withdrew ${formatMoney(amount)}`, ephemeral: true });
    }

    if (sub === 'loan') {
      const amount = interaction.options.getInteger('amount');
      const days = interaction.options.getInteger('days');
      if (amount <= 0 || days <= 0) return interaction.reply({ content: '❌ Amount dan days harus positif.', ephemeral: true });
      const interest = amount * 0.05;
      const due = Math.floor(Date.now() / 1000) + (days * 86400);
      const db = require('../../database/connection').get();
      db.prepare('INSERT INTO loans (discord_id, principal, interest, due_date) VALUES (?, ?, ?, ?)').run(interaction.user.id, amount, interest, due);
      walletRepository.updateBalance(interaction.user.id, amount);
      return interaction.reply({ content: `✅ Loan ${formatMoney(amount)} diterima. Bunga: ${formatMoney(interest)}. Jatuh tempo: ${days} hari.`, ephemeral: true });
    }

    if (sub === 'repay') {
      const loanId = interaction.options.getInteger('loan_id');
      const db = require('../../database/connection').get();
      const loan = db.prepare('SELECT * FROM loans WHERE id = ? AND discord_id = ? AND status = ?').get(loanId, interaction.user.id, 'ACTIVE');
      if (!loan) return interaction.reply({ content: '❌ Loan tidak ditemukan.', ephemeral: true });
      const total = loan.principal + loan.interest;
      if (wallet.balance < total) return interaction.reply({ content: '❌ Saldo tidak cukup untuk repay.', ephemeral: true });
      walletRepository.updateBalance(interaction.user.id, -total);
      db.prepare('UPDATE loans SET status = ? WHERE id = ?').run('REPAID', loanId);
      return interaction.reply({ content: `✅ Loan #${loanId} dilunasi. Total: ${formatMoney(total)}`, ephemeral: true });
    }
  }
};
