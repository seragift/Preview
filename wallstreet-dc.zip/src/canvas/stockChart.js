const { createCanvas } = require('canvas');
const canvasUtils = require('./canvasUtils');

module.exports = async function generateStockChart(stock, priceHistory) {
  const width = 800;
  const height = 400;
  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext('2d');

  // Background
  ctx.fillStyle = canvasUtils.getBg();
  ctx.fillRect(0, 0, width, height);

  // Title
  ctx.fillStyle = canvasUtils.getTextColor();
  ctx.font = 'bold 28px sans-serif';
  ctx.fillText(`${stock.ticker} — ${stock.name}`, 30, 40);

  const change = ((stock.current_price - stock.previous_price) / stock.previous_price) * 100;
  ctx.fillStyle = canvasUtils.getColor(change);
  ctx.font = 'bold 24px sans-serif';
  ctx.fillText(`${canvasUtils.formatCurrency(stock.current_price)}  ${change >= 0 ? '+' : ''}${change.toFixed(2)}%`, 30, 75);

  if (!priceHistory || priceHistory.length < 2) {
    ctx.fillStyle = canvasUtils.getMutedColor();
    ctx.font = '18px sans-serif';
    ctx.fillText('Not enough data for chart', 30, 200);
    return canvas.toBuffer('image/png');
  }

  const prices = priceHistory.map(p => p.price);
  const minPrice = Math.min(...prices) * 0.98;
  const maxPrice = Math.max(...prices) * 1.02;
  const range = maxPrice - minPrice;

  const padding = 60;
  const chartW = width - padding * 2;
  const chartH = height - padding * 2 - 40;

  // Grid
  ctx.strokeStyle = '#334155';
  ctx.lineWidth = 1;
  for (let i = 0; i <= 4; i++) {
    const y = padding + 40 + (chartH / 4) * i;
    ctx.beginPath();
    ctx.moveTo(padding, y);
    ctx.lineTo(width - padding, y);
    ctx.stroke();
  }

  // Chart line
  ctx.strokeStyle = canvasUtils.getColor(change);
  ctx.lineWidth = 3;
  ctx.beginPath();
  for (let i = 0; i < prices.length; i++) {
    const x = padding + (i / (prices.length - 1)) * chartW;
    const y = padding + 40 + chartH - ((prices[i] - minPrice) / range) * chartH;
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.stroke();

  // Fill area
  ctx.fillStyle = change >= 0 ? 'rgba(34, 197, 94, 0.1)' : 'rgba(239, 68, 68, 0.1)';
  ctx.beginPath();
  ctx.moveTo(padding, padding + 40 + chartH);
  for (let i = 0; i < prices.length; i++) {
    const x = padding + (i / (prices.length - 1)) * chartW;
    const y = padding + 40 + chartH - ((prices[i] - minPrice) / range) * chartH;
    ctx.lineTo(x, y);
  }
  ctx.lineTo(width - padding, padding + 40 + chartH);
  ctx.closePath();
  ctx.fill();

  // Time labels
  ctx.fillStyle = canvasUtils.getMutedColor();
  ctx.font = '12px sans-serif';
  ctx.fillText('Now', width - padding - 30, height - 20);

  return canvas.toBuffer('image/png');
};
