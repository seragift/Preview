const { createCanvas } = require('canvas');
const canvasUtils = require('./canvasUtils');

module.exports = async function generatePortfolioChart(portfolioData) {
  const width = 700;
  const height = 350;
  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext('2d');

  ctx.fillStyle = canvasUtils.getBg();
  ctx.fillRect(0, 0, width, height);

  ctx.fillStyle = canvasUtils.getTextColor();
  ctx.font = 'bold 24px sans-serif';
  ctx.fillText('Portfolio Overview', 30, 40);

  const { cash, stockValue, totalAssets, totalPL, returnPct, holdings } = portfolioData;

  // Stats
  ctx.font = '16px sans-serif';
  ctx.fillStyle = canvasUtils.getMutedColor();
  ctx.fillText(`Cash: ${canvasUtils.formatCurrency(cash)}`, 30, 80);
  ctx.fillText(`Stocks: ${canvasUtils.formatCurrency(stockValue)}`, 30, 105);
  ctx.fillText(`Total: ${canvasUtils.formatCurrency(totalAssets)}`, 30, 130);

  ctx.fillStyle = canvasUtils.getColor(returnPct);
  ctx.fillText(`Return: ${returnPct >= 0 ? '+' : ''}${returnPct.toFixed(2)}%`, 30, 155);

  // Pie chart for holdings
  if (holdings && holdings.length > 0) {
    const centerX = 500;
    const centerY = 175;
    const radius = 100;
    let startAngle = 0;
    const colors = ['#3b82f6', '#22c55e', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4', '#f97316', '#ec4899'];

    const totalHoldingValue = holdings.reduce((s, h) => s + (h.quantity * h.current_price), 0);

    for (let i = 0; i < holdings.length; i++) {
      const h = holdings[i];
      const value = h.quantity * h.current_price;
      const sliceAngle = (value / totalHoldingValue) * 2 * Math.PI;

      ctx.fillStyle = colors[i % colors.length];
      ctx.beginPath();
      ctx.moveTo(centerX, centerY);
      ctx.arc(centerX, centerY, radius, startAngle, startAngle + sliceAngle);
      ctx.closePath();
      ctx.fill();

      startAngle += sliceAngle;
    }

    // Legend
    let ly = 200;
    for (let i = 0; i < Math.min(holdings.length, 6); i++) {
      const h = holdings[i];
      ctx.fillStyle = colors[i % colors.length];
      ctx.fillRect(30, ly, 12, 12);
      ctx.fillStyle = canvasUtils.getTextColor();
      ctx.font = '13px sans-serif';
      ctx.fillText(`${h.ticker} — ${h.quantity} shares`, 48, ly + 11);
      ly += 22;
    }
  } else {
    ctx.fillStyle = canvasUtils.getMutedColor();
    ctx.font = '16px sans-serif';
    ctx.fillText('No holdings yet', 400, 175);
  }

  return canvas.toBuffer('image/png');
};
