const { createCanvas } = require('canvas');
const canvasUtils = require('./canvasUtils');

module.exports = async function generateLeaderboardCard(leaderboard, title = 'Leaderboard') {
  const width = 700;
  const height = 500;
  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext('2d');

  ctx.fillStyle = canvasUtils.getBg();
  ctx.fillRect(0, 0, width, height);

  ctx.fillStyle = canvasUtils.getTextColor();
  ctx.font = 'bold 28px sans-serif';
  ctx.fillText(`🏆 ${title}`, 30, 45);

  // Header row
  ctx.fillStyle = '#475569';
  ctx.fillRect(30, 60, 640, 1);
  ctx.fillStyle = canvasUtils.getMutedColor();
  ctx.font = 'bold 14px sans-serif';
  ctx.fillText('RANK', 30, 85);
  ctx.fillText('USER', 100, 85);
  ctx.fillText('NET WORTH', 450, 85);
  ctx.fillText('TRADES', 580, 85);

  let y = 115;
  const medals = ['🥇', '🥈', '🥉'];
  for (let i = 0; i < leaderboard.length; i++) {
    const entry = leaderboard[i];
    const rank = i + 1;

    ctx.fillStyle = rank <= 3 ? '#fbbf24' : canvasUtils.getTextColor();
    ctx.font = 'bold 16px sans-serif';
    ctx.fillText(`${medals[i] || rank}`, 30, y);

    ctx.fillStyle = canvasUtils.getTextColor();
    ctx.font = '16px sans-serif';
    ctx.fillText(entry.username || entry.discord_id, 100, y);

    ctx.fillStyle = '#22c55e';
    ctx.fillText(canvasUtils.formatCurrency(entry.net_worth), 450, y);

    ctx.fillStyle = canvasUtils.getMutedColor();
    ctx.fillText(entry.trades.toString(), 580, y);

    y += 35;
  }

  return canvas.toBuffer('image/png');
};
