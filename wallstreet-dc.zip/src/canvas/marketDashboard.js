const { createCanvas } = require('canvas');
const canvasUtils = require('./canvasUtils');

module.exports = async function generateMarketDashboard(gainers, losers, sentiment) {
  const width = 800;
  const height = 600;
  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext('2d');

  ctx.fillStyle = canvasUtils.getBg();
  ctx.fillRect(0, 0, width, height);

  // Header
  ctx.fillStyle = canvasUtils.getTextColor();
  ctx.font = 'bold 32px sans-serif';
  ctx.fillText('WALLSTREET DC', 30, 45);

  ctx.fillStyle = canvasUtils.getMutedColor();
  ctx.font = '16px sans-serif';
  ctx.fillText('Market Dashboard', 30, 70);

  // Market Index
  ctx.fillStyle = canvasUtils.getTextColor();
  ctx.font = 'bold 20px sans-serif';
  ctx.fillText('Market Index', 30, 110);

  const overall = sentiment?.overall || 50;
  const indexValue = 8000 + (overall - 50) * 20;
  const indexChange = ((overall - 50) / 50) * 100;

  ctx.fillStyle = canvasUtils.getColor(indexChange);
  ctx.font = 'bold 28px sans-serif';
  ctx.fillText(`DC-500  ${indexValue.toFixed(0)}  ${indexChange >= 0 ? '+' : ''}${indexChange.toFixed(2)}%`, 30, 145);

  // Top Gainers
  ctx.fillStyle = '#22c55e';
  ctx.font = 'bold 20px sans-serif';
  ctx.fillText('Top Gainers', 30, 200);

  let y = 230;
  for (const g of gainers.slice(0, 5)) {
    ctx.fillStyle = canvasUtils.getTextColor();
    ctx.font = '16px sans-serif';
    ctx.fillText(`${g.ticker}`, 30, y);
    ctx.fillStyle = '#22c55e';
    ctx.fillText(`+${g.change_pct.toFixed(2)}%`, 150, y);
    y += 28;
  }

  // Top Losers
  ctx.fillStyle = '#ef4444';
  ctx.font = 'bold 20px sans-serif';
  ctx.fillText('Top Losers', 400, 200);

  y = 230;
  for (const l of losers.slice(0, 5)) {
    ctx.fillStyle = canvasUtils.getTextColor();
    ctx.font = '16px sans-serif';
    ctx.fillText(`${l.ticker}`, 400, y);
    ctx.fillStyle = '#ef4444';
    ctx.fillText(`${l.change_pct.toFixed(2)}%`, 520, y);
    y += 28;
  }

  // Footer
  ctx.fillStyle = canvasUtils.getMutedColor();
  ctx.font = '14px sans-serif';
  ctx.fillText('Market tick: 30s | All prices virtual', 30, height - 20);

  return canvas.toBuffer('image/png');
};
