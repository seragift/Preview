const { createCanvas } = require('canvas');
const canvasUtils = require('./canvasUtils');

module.exports = async function generateStockCard(stock) {
  const width = 600;
  const height = 300;
  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext('2d');

  ctx.fillStyle = canvasUtils.getBg();
  ctx.fillRect(0, 0, width, height);

  ctx.fillStyle = canvasUtils.getTextColor();
  ctx.font = 'bold 28px sans-serif';
  ctx.fillText(`${stock.ticker}`, 30, 45);

  ctx.fillStyle = canvasUtils.getMutedColor();
  ctx.font = '18px sans-serif';
  ctx.fillText(`${stock.name} | ${stock.sector}`, 30, 75);

  const change = ((stock.current_price - stock.previous_price) / stock.previous_price) * 100;
  ctx.fillStyle = canvasUtils.getColor(change);
  ctx.font = 'bold 36px sans-serif';
  ctx.fillText(`${canvasUtils.formatCurrency(stock.current_price)}`, 30, 130);
  ctx.font = '20px sans-serif';
  ctx.fillText(`${change >= 0 ? '+' : ''}${change.toFixed(2)}%`, 30, 160);

  ctx.fillStyle = canvasUtils.getMutedColor();
  ctx.font = '14px sans-serif';
  ctx.fillText(`Market Cap: ${canvasUtils.formatCurrency(stock.market_cap || stock.current_price * stock.shares_outstanding)}`, 30, 200);
  ctx.fillText(`Shares: ${stock.shares_outstanding.toLocaleString()}`, 30, 225);
  ctx.fillText(`Volatility: ${(stock.volatility * 100).toFixed(1)}%`, 30, 250);

  return canvas.toBuffer('image/png');
};
