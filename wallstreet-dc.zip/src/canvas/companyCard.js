const { createCanvas } = require('canvas');
const canvasUtils = require('./canvasUtils');

module.exports = async function generateCompanyCard(company) {
  const width = 600;
  const height = 350;
  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext('2d');

  ctx.fillStyle = canvasUtils.getBg();
  ctx.fillRect(0, 0, width, height);

  ctx.fillStyle = canvasUtils.getTextColor();
  ctx.font = 'bold 28px sans-serif';
  ctx.fillText(`${company.name}`, 30, 45);

  ctx.fillStyle = canvasUtils.getMutedColor();
  ctx.font = '18px sans-serif';
  ctx.fillText(`${company.ticker} | ${company.sector}`, 30, 75);

  ctx.fillStyle = canvasUtils.getTextColor();
  ctx.font = '16px sans-serif';
  ctx.fillText(`Cash: ${canvasUtils.formatCurrency(company.cash)}`, 30, 120);
  ctx.fillText(`Revenue: ${canvasUtils.formatCurrency(company.revenue)}`, 30, 150);
  ctx.fillText(`Expenses: ${canvasUtils.formatCurrency(company.expenses)}`, 30, 180);
  ctx.fillText(`Profit: ${canvasUtils.formatCurrency(company.profit)}`, 30, 210);
  ctx.fillText(`Employees: ${company.employees}`, 30, 240);
  ctx.fillText(`Valuation: ${canvasUtils.formatCurrency(company.valuation)}`, 30, 270);
  ctx.fillText(`Reputation: ${company.reputation}/100`, 30, 300);

  return canvas.toBuffer('image/png');
};
