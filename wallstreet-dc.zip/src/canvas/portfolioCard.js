const { createCanvas } = require('canvas');
const canvasUtils = require('./canvasUtils');

module.exports = async function generatePortfolioCard(data) {
  const width = 700;
  const height = 400;
  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext('2d');

  ctx.fillStyle = canvasUtils.getBg();
  ctx.fillRect(0, 0, width, height);

  ctx.fillStyle = canvasUtils.getTextColor();
  ctx.font = 'bold 28px sans-serif';
  ctx.fillText('💼 PORTFOLIO', 30, 45);

  ctx.fillStyle = canvasUtils.getMutedColor();
  ctx.font = '16px sans-serif';
  ctx.fillText(`Cash: ${canvasUtils.formatCurrency(data.cash)}`, 30, 90);
  ctx.fillText(`Stocks: ${canvasUtils.formatCurrency(data.stockValue)}`, 30, 115);
  ctx.fillText(`Total Assets: ${canvasUtils.formatCurrency(data.totalAssets)}`, 30, 140);

  ctx.fillStyle = canvasUtils.getColor(data.totalPL);
  ctx.font = 'bold 18px sans-serif';
  ctx.fillText(`Total P/L: ${data.totalPL >= 0 ? '+' : ''}${canvasUtils.formatCurrency(data.totalPL)}`, 30, 175);
  ctx.fillText(`Return: ${data.returnPct >= 0 ? '+' : ''}${data.returnPct.toFixed(2)}%`, 30, 200);

  // Holdings table header
  ctx.fillStyle = '#475569';
  ctx.fillRect(30, 230, 640, 1);
  ctx.fillStyle = canvasUtils.getMutedColor();
  ctx.font = '14px sans-serif';
  ctx.fillText('TICKER', 30, 255);
  ctx.fillText('QTY', 150, 255);
  ctx.fillText('AVG PRICE', 240, 255);
  ctx.fillText('CURRENT', 360, 255);
  ctx.fillText('P/L', 480, 255);

  let y = 280;
  for (const h of data.holdings.slice(0, 5)) {
    const pl = (h.current_price - h.avg_price) * h.quantity;
    ctx.fillStyle = canvasUtils.getTextColor();
    ctx.font = '14px sans-serif';
    ctx.fillText(h.ticker, 30, y);
    ctx.fillText(h.quantity.toString(), 150, y);
    ctx.fillText(canvasUtils.formatCurrency(h.avg_price), 240, y);
    ctx.fillText(canvasUtils.formatCurrency(h.current_price), 360, y);
    ctx.fillStyle = canvasUtils.getColor(pl);
    ctx.fillText(`${pl >= 0 ? '+' : ''}${canvasUtils.formatCurrency(pl)}`, 480, y);
    y += 25;
  }

  return canvas.toBuffer('image/png');
};
