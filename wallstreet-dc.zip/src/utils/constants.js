module.exports = {
  SECTORS: [
    'Technology', 'Energy', 'Finance', 'Healthcare',
    'Automotive', 'Consumer', 'Telecommunications', 'Aerospace',
    'Entertainment', 'Industrial'
  ],
  ORDER_TYPES: ['MARKET', 'LIMIT', 'STOP'],
  ORDER_SIDES: ['BUY', 'SELL'],
  COMPANY_ROLES: ['CEO', 'CTO', 'CFO', 'MARKETING', 'ENGINEER', 'EMPLOYEE'],
  ACHIEVEMENTS: [
    'FIRST_TRADE', 'FIRST_MILLION', 'BILLIONAIRE', 'MARKET_MAKER',
    'WHALE', 'IPO_KING', 'CRASH_SURVIVOR', 'BEST_CEO'
  ],
};
