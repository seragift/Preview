module.exports = function formatNumber(num) {
  return Number(num).toLocaleString('en-US');
};
