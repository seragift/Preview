module.exports = {
  isValidTicker: (t) => /^[A-Z]{2,5}$/.test(t),
  isPositiveInt: (n) => Number.isInteger(n) && n > 0,
  isNonNegative: (n) => typeof n === 'number' && n >= 0,
};
