const walletRepository = require('../database/repositories/walletRepository');
const config = require('../config/config');

module.exports = {
  getBalance: (discord_id) => {
    const wallet = walletRepository.getById(discord_id);
    return wallet?.balance || 0;
  },
  deduct: (discord_id, amount, description) => {
    const wallet = walletRepository.getById(discord_id);
    if (wallet.balance < amount) return false;
    walletRepository.updateBalance(discord_id, -amount);
    walletRepository.addTransaction(discord_id, 'DEBIT', amount, description);
    return true;
  },
  add: (discord_id, amount, description) => {
    walletRepository.updateBalance(discord_id, amount);
    walletRepository.addTransaction(discord_id, 'CREDIT', amount, description);
    return true;
  },
  calculateFee: (amount) => {
    return amount * config.transactionFee;
  },
};
