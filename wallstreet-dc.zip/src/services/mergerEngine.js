const companyRepository = require('../database/repositories/companyRepository');
const db = require('../database/connection');
const logger = require('../utils/logger');

module.exports = {
  requestMerger: (acquirer_id, target_id, offerAmount) => {
    return db.get().prepare('INSERT INTO merger_requests (acquirer_id, target_id, offer_amount) VALUES (?, ?, ?)').run(acquirer_id, target_id, offerAmount);
  },
  approveMerger: (request_id) => {
    const req = db.get().prepare('SELECT * FROM merger_requests WHERE id = ?').get(request_id);
    if (!req || req.status !== 'PENDING') return false;
    db.get().prepare('UPDATE merger_requests SET status = 'APPROVED' WHERE id = ?').run(request_id);
    logger.info(`[MERGER] Approved merger ${req.acquirer_id} -> ${req.target_id}`);
    return true;
  },
};
