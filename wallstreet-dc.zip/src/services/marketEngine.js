const stockRepository = require('../database/repositories/stockRepository');
const marketRepository = require('../database/repositories/marketRepository');
const priceEngine = require('./priceEngine');
const orderEngine = require('./orderEngine');
const eventEngine = require('./eventEngine');
const newsEngine = require('./newsEngine');
const logger = require('../utils/logger');
const config = require('../config/config');

let running = false;
let intervalId = null;

function tick() {
  try {
    logger.debug('[MARKET] Tick starting...');
    const stocks = stockRepository.getAll();
    const sentiment = marketRepository.getSentiment();
    const events = marketRepository.getActiveEvents();

    for (const stock of stocks) {
      const newPrice = priceEngine.calculate(stock, sentiment, events);
      stockRepository.updatePrice(stock.ticker, newPrice);
      stockRepository.savePriceHistory(stock.ticker, newPrice);
      stockRepository.updateMarketCap(stock.ticker);
    }

    orderEngine.processOrders();
    eventEngine.checkEvents();
    newsEngine.checkNews();

    logger.debug('[MARKET] Tick completed.');
  } catch (err) {
    logger.error('[MARKET] Tick error:', err.message);
  }
}

module.exports = {
  start: () => {
    if (running) return;
    running = true;
    logger.info('[MARKET] Market engine started. Interval:', config.marketTickInterval, 'ms');
    tick();
    intervalId = setInterval(tick, config.marketTickInterval);
  },
  stop: () => {
    if (intervalId) clearInterval(intervalId);
    running = false;
    logger.info('[MARKET] Market engine stopped.');
  },
  isRunning: () => running,
  tick,
};
