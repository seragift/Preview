const companyRepository = require('../database/repositories/companyRepository');
const walletRepository = require('../database/repositories/walletRepository');
const db = require('../database/connection');
const logger = require('../utils/logger');

module.exports = {
  declareDividend: (company_id, amountPerShare) => {
    const database = db.get();
    const shareholders = database.prepare('SELECT * FROM shareholders WHERE company_id = ?').all(company_id);
    let total = 0;
    for (const sh of shareholders) {
      const payout = sh.shares * amountPerShare;
      if (payout > 0) {
        walletRepository.updateBalance(sh.discord_id, payout);
        walletRepository.addTransaction(sh.discord_id, 'DIVIDEND', payout, `Dividend from company ${company_id}`);
        total += payout;
      }
    }
    database.prepare('INSERT INTO dividends (company_id, amount_per_share, total_amount, paid_at) VALUES (?, ?, ?, strftime('%s','now'))').run(company_id, amountPerShare, total);
    logger.info(`[DIVIDEND] Company ${company_id} paid $${total.toFixed(2)} in dividends.`);
    return total;
  },
};
