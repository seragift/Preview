const portfolioRepository = require('../database/repositories/portfolioRepository');
const walletRepository = require('../database/repositories/walletRepository');

module.exports = {
  getNetWorth: (discord_id) => {
    const wallet = walletRepository.getById(discord_id);
    const portfolioValue = portfolioRepository.getPortfolioValue(discord_id);
    return (wallet?.balance || 0) + portfolioValue;
  },
  getPortfolioDetails: (discord_id) => {
    const wallet = walletRepository.getById(discord_id);
    const holdings = portfolioRepository.getByUser(discord_id);
    let stockValue = 0;
    let totalCost = 0;
    for (const h of holdings) {
      stockValue += h.quantity * h.current_price;
      totalCost += h.total_cost;
    }
    const totalAssets = (wallet?.balance || 0) + stockValue;
    const totalPL = totalAssets - 100000;
    const returnPct = totalCost > 0 ? ((stockValue - totalCost) / totalCost) * 100 : 0;
    return {
      cash: wallet?.balance || 0,
      stockValue,
      totalAssets,
      totalPL,
      returnPct,
      holdings,
    };
  },
};
