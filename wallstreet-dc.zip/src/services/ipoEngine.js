const companyRepository = require('../database/repositories/companyRepository');
const stockRepository = require('../database/repositories/stockRepository');
const logger = require('../utils/logger');

module.exports = {
  launchIPO: (company_id, valuation, shares, offeringPct, ipoPrice) => {
    const company = companyRepository.getById(company_id);
    if (!company) return null;
    if (company.is_public) return null;

    const ticker = company.ticker;
    const existing = stockRepository.getByTicker(ticker);
    if (existing) return null;

    stockRepository.create({
      ticker,
      name: company.name,
      sector: company.sector,
      description: company.description,
      current_price: ipoPrice,
      shares_outstanding: shares,
      volatility: 0.04,
      fundamental_score: company.reputation || 50,
    });

    const db = require('../database/connection');
    db.get().prepare('UPDATE companies SET is_public = 1, valuation = ? WHERE company_id = ?').run(valuation, company_id);

    logger.info(`[IPO] ${company.name} (${ticker}) launched at $${ipoPrice}`);
    return { ticker, ipoPrice, shares };
  },
};
