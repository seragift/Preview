const portfolioEngine = require('./portfolioEngine');
const userRepository = require('../database/repositories/userRepository');

module.exports = {
  getLeaderboard: (category = 'net_worth', limit = 10) => {
    const users = userRepository.getAll();
    const ranked = [];
    for (const user of users) {
      const netWorth = portfolioEngine.getNetWorth(user.discord_id);
      const tradeCount = require('../database/repositories/transactionRepository').getTradeCount(user.discord_id);
      ranked.push({
        discord_id: user.discord_id,
        username: user.username,
        net_worth: netWorth,
        trades: tradeCount,
      });
    }
    ranked.sort((a, b) => b.net_worth - a.net_worth);
    return ranked.slice(0, limit);
  },
};
