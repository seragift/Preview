const newsRepository = require('../database/repositories/newsRepository');
const stockRepository = require('../database/repositories/stockRepository');
const random = require('../utils/random');
const logger = require('../utils/logger');

const newsTemplates = [
  { title: "{company} announces breakthrough product", impact: 5 },
  { title: "{company} reports strong quarterly earnings", impact: 8 },
  { title: "{company} faces regulatory scrutiny", impact: -6 },
  { title: "{company} expands into new markets", impact: 4 },
  { title: "{company} CEO steps down unexpectedly", impact: -10 },
  { title: "{company} secures major government contract", impact: 12 },
  { title: "{company} recalls defective products", impact: -8 },
  { title: "{company} partners with industry leader", impact: 6 },
];

module.exports = {
  checkNews: () => {
    if (random.int(1, 100) > 8) return;
    const stocks = stockRepository.getAll();
    if (stocks.length === 0) return;
    const stock = random.choice(stocks);
    const template = random.choice(newsTemplates);
    const title = template.title.replace('{company}', stock.name);
    const impact = template.impact + random.range(-2, 2);
    newsRepository.create({
      title,
      content: title,
      ticker: stock.ticker,
      sector: stock.sector,
      impact,
    });
    logger.info(`[NEWS] ${title} (${stock.ticker})`);
  },
  getRecentNews: (limit = 5) => {
    return newsRepository.getRecent(limit);
  },
};
