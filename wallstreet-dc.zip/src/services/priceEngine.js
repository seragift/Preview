const random = require('../utils/random');
const logger = require('../utils/logger');

module.exports = {
  calculate: (stock, sentiment, events) => {
    const prev = stock.previous_price || stock.current_price;
    let priceChange = 0;

    // Market factor
    const overallSentiment = (sentiment?.overall || 50) - 50;
    const marketFactor = overallSentiment * 0.001;

    // Sector factor
    const sectorKey = stock.sector.toLowerCase();
    const sectorSentiment = (sentiment?.[sectorKey] || 50) - 50;
    const sectorFactor = sectorSentiment * 0.002;

    // Fundamental factor
    const fundamentalFactor = ((stock.fundamental_score || 50) - 50) * 0.001;

    // Volatility noise
    const volatility = stock.volatility || 0.02;
    const randomNoise = random.normal(0, volatility * prev);

    // Event factor
    let eventFactor = 0;
    if (events) {
      for (const evt of events) {
        if (!evt.sector || evt.sector === stock.sector) {
          eventFactor += (evt.impact || 0) * 0.01 * prev;
        }
      }
    }

    priceChange = marketFactor + sectorFactor + fundamentalFactor + randomNoise + eventFactor;

    // Limit change to 5% max per tick
    const maxChange = prev * 0.05;
    priceChange = Math.max(-maxChange, Math.min(maxChange, priceChange));

    let newPrice = prev + priceChange;
    newPrice = Math.max(0.01, newPrice);

    return parseFloat(newPrice.toFixed(2));
  },
};
