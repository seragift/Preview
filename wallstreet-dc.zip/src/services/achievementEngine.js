const db = require('../database/connection');
const logger = require('../utils/logger');
const fs = require('fs');
const path = require('path');

let achievementDefs = [];
try {
  const path_ = path.join(__dirname, '..', '..', 'data', 'achievements.json');
  achievementDefs = JSON.parse(fs.readFileSync(path_, 'utf8'));
} catch (e) {
  logger.warn('[ACHIEVEMENT] Could not load achievements.json');
}

function ensureAchievements() {
  const database = db.get();
  for (const a of achievementDefs) {
    database.prepare('INSERT OR IGNORE INTO achievements (code, name, description, icon) VALUES (?, ?, ?, ?)').run(a.code, a.name, a.description, a.icon);
  }
}

module.exports = {
  init: ensureAchievements,
  unlock: (discord_id, code) => {
    ensureAchievements();
    const database = db.get();
    const ach = database.prepare('SELECT * FROM achievements WHERE code = ?').get(code);
    if (!ach) return false;
    const existing = database.prepare('SELECT * FROM user_achievements WHERE discord_id = ? AND achievement_id = ?').get(discord_id, ach.id);
    if (existing) return false;
    database.prepare('INSERT INTO user_achievements (discord_id, achievement_id) VALUES (?, ?)').run(discord_id, ach.id);
    logger.info(`[ACHIEVEMENT] ${discord_id} unlocked ${code}`);
    return true;
  },
  getUserAchievements: (discord_id) => {
    ensureAchievements();
    return db.get().prepare(`SELECT a.* FROM achievements a JOIN user_achievements ua ON a.id = ua.achievement_id WHERE ua.discord_id = ?`).all(discord_id);
  },
  checkFirstTrade: (discord_id) => {
    const count = require('../database/repositories/transactionRepository').getTradeCount(discord_id);
    if (count >= 1) module.exports.unlock(discord_id, 'FIRST_TRADE');
    if (count >= 100) module.exports.unlock(discord_id, 'MARKET_MAKER');
  },
  checkNetWorth: (discord_id) => {
    const nw = require('./portfolioEngine').getNetWorth(discord_id);
    if (nw >= 1e6) module.exports.unlock(discord_id, 'FIRST_MILLION');
    if (nw >= 1e9) module.exports.unlock(discord_id, 'BILLIONAIRE');
  },
};
