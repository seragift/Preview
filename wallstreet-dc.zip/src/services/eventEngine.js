const marketRepository = require('../database/repositories/marketRepository');
const random = require('../utils/random');
const logger = require('../utils/logger');
const fs = require('fs');
const path = require('path');

let eventPool = [];

try {
  const eventsPath = path.join(__dirname, '..', '..', 'data', 'events.json');
  eventPool = JSON.parse(fs.readFileSync(eventsPath, 'utf8'));
} catch (e) {
  logger.warn('[EVENT] Could not load events.json');
}

module.exports = {
  checkEvents: () => {
    const active = marketRepository.getActiveEvents();
    const now = Math.floor(Date.now() / 1000);
    for (const evt of active) {
      if (evt.started_at + evt.duration < now) {
        marketRepository.endEvent(evt.id);
        logger.info(`[EVENT] Ended: ${evt.name}`);
      }
    }

    if (random.int(1, 100) <= 5 && eventPool.length > 0) {
      const template = random.choice(eventPool);
      marketRepository.createEvent(template);
      logger.info(`[EVENT] Started: ${template.name}`);
    }
  },
};
