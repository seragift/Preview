const orderRepository = require('../database/repositories/orderRepository');
const stockRepository = require('../database/repositories/stockRepository');
const walletRepository = require('../database/repositories/walletRepository');
const portfolioRepository = require('../database/repositories/portfolioRepository');
const transactionRepository = require('../database/repositories/transactionRepository');
const config = require('../config/config');
const logger = require('../utils/logger');

module.exports = {
  processOrders: () => {
    const orders = orderRepository.getOpenOrders();
    for (const order of orders) {
      try {
        const stock = stockRepository.getByTicker(order.ticker);
        if (!stock) continue;

        const price = stock.current_price;
        let shouldExecute = false;

        if (order.type === 'MARKET') {
          shouldExecute = true;
        } else if (order.type === 'LIMIT') {
          if (order.side === 'BUY' && price <= order.price) shouldExecute = true;
          if (order.side === 'SELL' && price >= order.price) shouldExecute = true;
        } else if (order.type === 'STOP') {
          if (order.side === 'BUY' && price >= order.stop_price) shouldExecute = true;
          if (order.side === 'SELL' && price <= order.stop_price) shouldExecute = true;
        }

        if (shouldExecute) {
          executeOrder(order, stock);
        }
      } catch (err) {
        logger.error('[ORDER] Error processing order', order.id, err.message);
      }
    }
  },
};

function executeOrder(order, stock) {
  const db = require('../database/connection');
  const database = db.get();
  const total = order.quantity * stock.current_price;
  const fee = total * config.transactionFee;

  database.transaction(() => {
    const wallet = walletRepository.getById(order.discord_id);
    if (order.side === 'BUY') {
      if (wallet.balance < total + fee) {
        orderRepository.updateStatus(order.id, 'REJECTED');
        return;
      }
      walletRepository.updateBalance(order.discord_id, -(total + fee));
      portfolioRepository.addHolding(order.discord_id, order.ticker, order.quantity, stock.current_price);
    } else {
      const success = portfolioRepository.removeHolding(order.discord_id, order.ticker, order.quantity);
      if (!success) {
        orderRepository.updateStatus(order.id, 'REJECTED');
        return;
      }
      walletRepository.updateBalance(order.discord_id, total - fee);
    }

    transactionRepository.create(order.discord_id, order.ticker, order.side, order.quantity, stock.current_price, fee, total);
    orderRepository.updateStatus(order.id, 'FILLED');
    logger.info(`[TRADE] ${order.side} ${order.quantity} ${order.ticker} @ $${stock.current_price} by ${order.discord_id}`);
  })();
}
