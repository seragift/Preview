const companyRepository = require('../database/repositories/companyRepository');
const stockRepository = require('../database/repositories/stockRepository');
const fs = require('fs');
const path = require('path');
const logger = require('../utils/logger');

module.exports = {
  loadStocks: () => {
    const stocksPath = path.join(__dirname, '..', '..', 'data', 'stocks.json');
    const stocks = JSON.parse(fs.readFileSync(stocksPath, 'utf8'));
    for (const s of stocks) {
      const existing = stockRepository.getByTicker(s.ticker);
      if (!existing) {
        stockRepository.create(s);
        logger.info(`[STOCK] Loaded ${s.ticker} - ${s.name}`);
      }
    }
  },
  createCompany: (data) => {
    return companyRepository.create(data);
  },
  getCompany: (company_id) => {
    return companyRepository.getById(company_id);
  },
  getCompanyByTicker: (ticker) => {
    return companyRepository.getByTicker(ticker);
  },
};
