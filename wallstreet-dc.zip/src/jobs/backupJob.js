const fs = require('fs');
const path = require('path');
const logger = require('../utils/logger');
const config = require('../config/config');

function backup() {
  const dbPath = config.databasePath;
  if (!fs.existsSync(dbPath)) return;
  const backupDir = path.join(path.dirname(dbPath), 'backups');
  if (!fs.existsSync(backupDir)) fs.mkdirSync(backupDir, { recursive: true });
  const backupPath = path.join(backupDir, `database.backup.${Date.now()}.sqlite`);
  try {
    fs.copyFileSync(dbPath, backupPath);
    logger.info('[BACKUP] Database backed up to', backupPath);
  } catch (e) {
    logger.error('[BACKUP] Failed:', e.message);
  }
}

setInterval(backup, 24 * 60 * 60 * 1000);
logger.info('[JOBS] backupJob loaded');
