const logger = require('../utils/logger');
const db = require('../database/connection');

function checkDividends() {
  try {
    const database = db.get();
    // Auto-dividend logic can go here
    logger.debug('[JOBS] Dividend check completed');
  } catch (e) {
    logger.error('[JOBS] Dividend check error:', e.message);
  }
}

setInterval(checkDividends, 60 * 60 * 1000); // hourly
logger.info('[JOBS] dividendJob loaded');
