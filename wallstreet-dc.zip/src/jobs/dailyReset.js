const logger = require('../utils/logger');
const db = require('../database/connection');

function dailyReset() {
  try {
    const database = db.get();
    // Reset daily stats or send daily report
    logger.info('[JOBS] Daily reset executed');
  } catch (e) {
    logger.error('[JOBS] Daily reset error:', e.message);
  }
}

setInterval(dailyReset, 24 * 60 * 60 * 1000);
logger.info('[JOBS] dailyReset loaded');
