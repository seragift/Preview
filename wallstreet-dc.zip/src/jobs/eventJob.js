const logger = require('../utils/logger');
logger.info('[JOBS] eventJob loaded (handled by eventEngine in market tick)');
