const logger = require('../utils/logger');
logger.info('[JOBS] marketTick loaded (handled by marketEngine)');
