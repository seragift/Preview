module.exports = {
  token: process.env.DISCORD_TOKEN,
  clientId: process.env.CLIENT_ID,
  guildId: process.env.GUILD_ID,
  databasePath: process.env.DATABASE_PATH || './database.sqlite',
  startingBalance: parseInt(process.env.STARTING_BALANCE) || 100000,
  marketTickInterval: parseInt(process.env.MARKET_TICK_INTERVAL) || 30000,
  marketTimezone: process.env.MARKET_TIMEZONE || 'Asia/Jakarta',
  logLevel: process.env.LOG_LEVEL || 'info',
  transactionFee: 0.002,
  marketOpen: true,
  seasonDuration: 30 * 24 * 60 * 60 * 1000,
};
