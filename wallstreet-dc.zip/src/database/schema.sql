-- Users
CREATE TABLE IF NOT EXISTS users (
  discord_id TEXT PRIMARY KEY,
  username TEXT NOT NULL,
  created_at INTEGER DEFAULT (strftime('%s','now')),
  last_active INTEGER DEFAULT (strftime('%s','now'))
);

-- Wallets
CREATE TABLE IF NOT EXISTS wallets (
  discord_id TEXT PRIMARY KEY,
  balance REAL DEFAULT 100000,
  total_deposited REAL DEFAULT 0,
  total_withdrawn REAL DEFAULT 0,
  updated_at INTEGER DEFAULT (strftime('%s','now')),
  FOREIGN KEY (discord_id) REFERENCES users(discord_id)
);

-- Transactions
CREATE TABLE IF NOT EXISTS transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  discord_id TEXT NOT NULL,
  type TEXT NOT NULL,
  amount REAL NOT NULL,
  description TEXT,
  created_at INTEGER DEFAULT (strftime('%s','now')),
  FOREIGN KEY (discord_id) REFERENCES users(discord_id)
);

-- Stocks
CREATE TABLE IF NOT EXISTS stocks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ticker TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  sector TEXT NOT NULL,
  description TEXT,
  current_price REAL DEFAULT 100,
  previous_price REAL DEFAULT 100,
  market_cap REAL DEFAULT 0,
  shares_outstanding INTEGER DEFAULT 1000000,
  volatility REAL DEFAULT 0.02,
  fundamental_score REAL DEFAULT 50,
  sentiment_score REAL DEFAULT 50,
  is_active INTEGER DEFAULT 1,
  created_at INTEGER DEFAULT (strftime('%s','now'))
);

-- Stock Prices History
CREATE TABLE IF NOT EXISTS stock_prices (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ticker TEXT NOT NULL,
  price REAL NOT NULL,
  volume INTEGER DEFAULT 0,
  timestamp INTEGER DEFAULT (strftime('%s','now')),
  FOREIGN KEY (ticker) REFERENCES stocks(ticker)
);

CREATE INDEX IF NOT EXISTS idx_stock_prices_ticker ON stock_prices(ticker);
CREATE INDEX IF NOT EXISTS idx_stock_prices_time ON stock_prices(timestamp);

-- Stock Ticks (intraday)
CREATE TABLE IF NOT EXISTS stock_ticks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ticker TEXT NOT NULL,
  price REAL NOT NULL,
  timestamp INTEGER DEFAULT (strftime('%s','now'))
);

CREATE INDEX IF NOT EXISTS idx_ticks_ticker ON stock_ticks(ticker);

-- Portfolios
CREATE TABLE IF NOT EXISTS portfolios (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  discord_id TEXT NOT NULL,
  ticker TEXT NOT NULL,
  quantity INTEGER DEFAULT 0,
  avg_price REAL DEFAULT 0,
  total_cost REAL DEFAULT 0,
  updated_at INTEGER DEFAULT (strftime('%s','now')),
  UNIQUE(discord_id, ticker),
  FOREIGN KEY (discord_id) REFERENCES users(discord_id),
  FOREIGN KEY (ticker) REFERENCES stocks(ticker)
);

-- Holdings (alias of portfolios for flexibility)
CREATE TABLE IF NOT EXISTS holdings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  discord_id TEXT NOT NULL,
  ticker TEXT NOT NULL,
  quantity INTEGER DEFAULT 0,
  avg_price REAL DEFAULT 0,
  FOREIGN KEY (discord_id) REFERENCES users(discord_id),
  FOREIGN KEY (ticker) REFERENCES stocks(ticker)
);

-- Orders
CREATE TABLE IF NOT EXISTS orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  discord_id TEXT NOT NULL,
  ticker TEXT NOT NULL,
  side TEXT NOT NULL,
  type TEXT NOT NULL,
  quantity INTEGER NOT NULL,
  price REAL,
  stop_price REAL,
  status TEXT DEFAULT 'OPEN',
  created_at INTEGER DEFAULT (strftime('%s','now')),
  FOREIGN KEY (discord_id) REFERENCES users(discord_id),
  FOREIGN KEY (ticker) REFERENCES stocks(ticker)
);

CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);

-- Trades
CREATE TABLE IF NOT EXISTS trades (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  discord_id TEXT NOT NULL,
  ticker TEXT NOT NULL,
  side TEXT NOT NULL,
  quantity INTEGER NOT NULL,
  price REAL NOT NULL,
  fee REAL DEFAULT 0,
  total REAL NOT NULL,
  created_at INTEGER DEFAULT (strftime('%s','now')),
  FOREIGN KEY (discord_id) REFERENCES users(discord_id)
);

-- Companies
CREATE TABLE IF NOT EXISTS companies (
  company_id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  ticker TEXT UNIQUE NOT NULL,
  sector TEXT NOT NULL,
  description TEXT,
  founder_id TEXT NOT NULL,
  cash REAL DEFAULT 0,
  revenue REAL DEFAULT 0,
  expenses REAL DEFAULT 0,
  profit REAL DEFAULT 0,
  employees INTEGER DEFAULT 1,
  valuation REAL DEFAULT 0,
  reputation REAL DEFAULT 50,
  is_public INTEGER DEFAULT 0,
  created_at INTEGER DEFAULT (strftime('%s','now')),
  FOREIGN KEY (founder_id) REFERENCES users(discord_id)
);

-- Company Members
CREATE TABLE IF NOT EXISTS company_members (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  company_id INTEGER NOT NULL,
  discord_id TEXT NOT NULL,
  role TEXT DEFAULT 'EMPLOYEE',
  joined_at INTEGER DEFAULT (strftime('%s','now')),
  FOREIGN KEY (company_id) REFERENCES companies(company_id),
  FOREIGN KEY (discord_id) REFERENCES users(discord_id)
);

-- Company Financials
CREATE TABLE IF NOT EXISTS company_financials (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  company_id INTEGER NOT NULL,
  period TEXT,
  revenue REAL DEFAULT 0,
  expenses REAL DEFAULT 0,
  profit REAL DEFAULT 0,
  recorded_at INTEGER DEFAULT (strftime('%s','now')),
  FOREIGN KEY (company_id) REFERENCES companies(company_id)
);

-- Company Products
CREATE TABLE IF NOT EXISTS company_products (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  company_id INTEGER NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  price REAL DEFAULT 0,
  demand REAL DEFAULT 50,
  created_at INTEGER DEFAULT (strftime('%s','now')),
  FOREIGN KEY (company_id) REFERENCES companies(company_id)
);

-- IPO
CREATE TABLE IF NOT EXISTS ipo (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  company_id INTEGER NOT NULL,
  valuation REAL NOT NULL,
  shares INTEGER NOT NULL,
  offering_percentage REAL DEFAULT 20,
  ipo_price REAL NOT NULL,
  status TEXT DEFAULT 'PENDING',
  created_at INTEGER DEFAULT (strftime('%s','now')),
  FOREIGN KEY (company_id) REFERENCES companies(company_id)
);

-- Shareholders
CREATE TABLE IF NOT EXISTS shareholders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  company_id INTEGER NOT NULL,
  discord_id TEXT NOT NULL,
  shares INTEGER DEFAULT 0,
  percentage REAL DEFAULT 0,
  FOREIGN KEY (company_id) REFERENCES companies(company_id),
  FOREIGN KEY (discord_id) REFERENCES users(discord_id)
);

-- Dividends
CREATE TABLE IF NOT EXISTS dividends (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  company_id INTEGER NOT NULL,
  amount_per_share REAL NOT NULL,
  total_amount REAL NOT NULL,
  declared_at INTEGER DEFAULT (strftime('%s','now')),
  paid_at INTEGER,
  FOREIGN KEY (company_id) REFERENCES companies(company_id)
);

-- Market Sessions
CREATE TABLE IF NOT EXISTS market_sessions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  status TEXT DEFAULT 'OPEN',
  opened_at INTEGER DEFAULT (strftime('%s','now')),
  closed_at INTEGER
);

-- Market Events
CREATE TABLE IF NOT EXISTS market_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  description TEXT,
  sector TEXT,
  impact REAL DEFAULT 0,
  duration INTEGER DEFAULT 1200,
  started_at INTEGER DEFAULT (strftime('%s','now')),
  ended_at INTEGER
);

-- News
CREATE TABLE IF NOT EXISTS news (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  content TEXT,
  ticker TEXT,
  sector TEXT,
  impact REAL DEFAULT 0,
  created_at INTEGER DEFAULT (strftime('%s','now'))
);

-- News Effects
CREATE TABLE IF NOT EXISTS news_effects (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  news_id INTEGER NOT NULL,
  ticker TEXT NOT NULL,
  effect REAL DEFAULT 0,
  FOREIGN KEY (news_id) REFERENCES news(id)
);

-- Watchlists
CREATE TABLE IF NOT EXISTS watchlists (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  discord_id TEXT NOT NULL,
  ticker TEXT NOT NULL,
  added_at INTEGER DEFAULT (strftime('%s','now')),
  UNIQUE(discord_id, ticker),
  FOREIGN KEY (discord_id) REFERENCES users(discord_id),
  FOREIGN KEY (ticker) REFERENCES stocks(ticker)
);

-- Achievements
CREATE TABLE IF NOT EXISTS achievements (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  code TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  icon TEXT
);

-- User Achievements
CREATE TABLE IF NOT EXISTS user_achievements (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  discord_id TEXT NOT NULL,
  achievement_id INTEGER NOT NULL,
  unlocked_at INTEGER DEFAULT (strftime('%s','now')),
  FOREIGN KEY (discord_id) REFERENCES users(discord_id),
  FOREIGN KEY (achievement_id) REFERENCES achievements(id)
);

-- Seasons
CREATE TABLE IF NOT EXISTS seasons (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  started_at INTEGER DEFAULT (strftime('%s','now')),
  ended_at INTEGER,
  winner_id TEXT,
  winner_net_worth REAL
);

-- Season Stats
CREATE TABLE IF NOT EXISTS season_stats (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  season_id INTEGER NOT NULL,
  discord_id TEXT NOT NULL,
  net_worth REAL DEFAULT 0,
  trades INTEGER DEFAULT 0,
  profit REAL DEFAULT 0,
  FOREIGN KEY (season_id) REFERENCES seasons(id),
  FOREIGN KEY (discord_id) REFERENCES users(discord_id)
);

-- Audit Logs
CREATE TABLE IF NOT EXISTS audit_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  discord_id TEXT,
  action TEXT NOT NULL,
  target TEXT,
  details TEXT,
  created_at INTEGER DEFAULT (strftime('%s','now'))
);

-- Bank Loans
CREATE TABLE IF NOT EXISTS loans (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  discord_id TEXT NOT NULL,
  principal REAL NOT NULL,
  interest REAL NOT NULL,
  due_date INTEGER NOT NULL,
  status TEXT DEFAULT 'ACTIVE',
  created_at INTEGER DEFAULT (strftime('%s','now')),
  FOREIGN KEY (discord_id) REFERENCES users(discord_id)
);

-- Research Projects
CREATE TABLE IF NOT EXISTS research_projects (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  company_id INTEGER NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  cost REAL DEFAULT 0,
  progress REAL DEFAULT 0,
  duration INTEGER DEFAULT 720,
  status TEXT DEFAULT 'IN_PROGRESS',
  started_at INTEGER DEFAULT (strftime('%s','now')),
  completed_at INTEGER,
  FOREIGN KEY (company_id) REFERENCES companies(company_id)
);

-- Merger Requests
CREATE TABLE IF NOT EXISTS merger_requests (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  acquirer_id INTEGER NOT NULL,
  target_id INTEGER NOT NULL,
  offer_amount REAL NOT NULL,
  status TEXT DEFAULT 'PENDING',
  created_at INTEGER DEFAULT (strftime('%s','now')),
  FOREIGN KEY (acquirer_id) REFERENCES companies(company_id),
  FOREIGN KEY (target_id) REFERENCES companies(company_id)
);

-- Market Sentiment
CREATE TABLE IF NOT EXISTS market_sentiment (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  overall REAL DEFAULT 50,
  tech REAL DEFAULT 50,
  energy REAL DEFAULT 50,
  finance REAL DEFAULT 50,
  healthcare REAL DEFAULT 50,
  automotive REAL DEFAULT 50,
  consumer REAL DEFAULT 50,
  telecom REAL DEFAULT 50,
  aerospace REAL DEFAULT 50,
  entertainment REAL DEFAULT 50,
  industrial REAL DEFAULT 50,
  updated_at INTEGER DEFAULT (strftime('%s','now'))
);

INSERT OR IGNORE INTO market_sentiment (id) VALUES (1);
