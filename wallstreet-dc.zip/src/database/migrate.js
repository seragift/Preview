const db = require('./connection');
const fs = require('fs');
const path = require('path');
const logger = require('../utils/logger');

module.exports = {
  run: () => {
    const schema = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8');
    const statements = schema.split(';').filter(s => s.trim().length > 0);
    const database = db.get();
    for (const stmt of statements) {
      try {
        database.exec(stmt + ';');
      } catch (e) {
        logger.warn('[MIGRATE] Statement skipped:', e.message);
      }
    }
    logger.info('[MIGRATE] Migrations completed.');
  }
};
