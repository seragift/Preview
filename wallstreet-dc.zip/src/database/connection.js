const Database = require('better-sqlite3');
const path = require('path');
const config = require('../config/config');
const logger = require('../utils/logger');

let db = null;

module.exports = {
  init: () => {
    db = new Database(config.databasePath);
    db.pragma('journal_mode = WAL');
    db.pragma('foreign_keys = ON');
    logger.info('[DATABASE] SQLite initialized at', config.databasePath);
  },
  get: () => {
    if (!db) throw new Error('Database not initialized');
    return db;
  },
  close: () => {
    if (db) { db.close(); db = null; }
  },
};
