const db = require('../connection');

module.exports = {
  getSentiment: () => {
    return db.get().prepare('SELECT * FROM market_sentiment WHERE id = 1').get();
  },
  updateSentiment: (sector, value) => {
    const col = sector.toLowerCase();
    db.get().prepare(`UPDATE market_sentiment SET ${col} = ?, updated_at = strftime('%s','now') WHERE id = 1`).run(value);
  },
  updateOverall: (value) => {
    db.get().prepare('UPDATE market_sentiment SET overall = ?, updated_at = strftime('%s','now') WHERE id = 1').run(value);
  },
  createEvent: (data) => {
    const { name, description, sector, impact, duration } = data;
    return db.get().prepare('INSERT INTO market_events (name, description, sector, impact, duration) VALUES (?, ?, ?, ?, ?)').run(name, description, sector, impact, duration);
  },
  getActiveEvents: () => {
    return db.get().prepare('SELECT * FROM market_events WHERE ended_at IS NULL').all();
  },
  endEvent: (id) => {
    db.get().prepare('UPDATE market_events SET ended_at = strftime('%s','now') WHERE id = ?').run(id);
  },
  getTopGainers: (limit = 5) => {
    return db.get().prepare(`SELECT ticker, name, current_price, previous_price, ((current_price - previous_price) / previous_price * 100) as change_pct FROM stocks WHERE is_active = 1 ORDER BY change_pct DESC LIMIT ?`).all(limit);
  },
  getTopLosers: (limit = 5) => {
    return db.get().prepare(`SELECT ticker, name, current_price, previous_price, ((current_price - previous_price) / previous_price * 100) as change_pct FROM stocks WHERE is_active = 1 ORDER BY change_pct ASC LIMIT ?`).all(limit);
  },
  getMostTraded: (limit = 5) => {
    return db.get().prepare(`SELECT ticker, SUM(quantity) as volume FROM trades GROUP BY ticker ORDER BY volume DESC LIMIT ?`).all(limit);
  },
};
