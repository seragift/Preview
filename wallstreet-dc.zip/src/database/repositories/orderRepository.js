const db = require('../connection');

module.exports = {
  create: (data) => {
    const { discord_id, ticker, side, type, quantity, price, stop_price } = data;
    return db.get().prepare(
      'INSERT INTO orders (discord_id, ticker, side, type, quantity, price, stop_price) VALUES (?, ?, ?, ?, ?, ?, ?)'
    ).run(discord_id, ticker, side, type, quantity, price || null, stop_price || null);
  },
  getByUser: (discord_id, status = 'OPEN') => {
    return db.get().prepare('SELECT * FROM orders WHERE discord_id = ? AND status = ? ORDER BY created_at DESC').all(discord_id, status);
  },
  getById: (id) => {
    return db.get().prepare('SELECT * FROM orders WHERE id = ?').get(id);
  },
  getOpenOrders: () => {
    return db.get().prepare('SELECT * FROM orders WHERE status = 'OPEN' ORDER BY created_at ASC').all();
  },
  updateStatus: (id, status) => {
    db.get().prepare('UPDATE orders SET status = ? WHERE id = ?').run(status, id);
  },
  cancel: (id) => {
    db.get().prepare('UPDATE orders SET status = 'CANCELLED' WHERE id = ?').run(id);
  },
};
