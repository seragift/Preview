const db = require('../connection');

module.exports = {
  create: (data) => {
    const { name, ticker, sector, description, founder_id } = data;
    return db.get().prepare(
      'INSERT INTO companies (name, ticker, sector, description, founder_id) VALUES (?, ?, ?, ?, ?)'
    ).run(name, ticker, sector, description, founder_id);
  },
  getById: (company_id) => {
    return db.get().prepare('SELECT * FROM companies WHERE company_id = ?').get(company_id);
  },
  getByTicker: (ticker) => {
    return db.get().prepare('SELECT * FROM companies WHERE ticker = ?').get(ticker);
  },
  getByFounder: (founder_id) => {
    return db.get().prepare('SELECT * FROM companies WHERE founder_id = ?').get(founder_id);
  },
  getAll: () => {
    return db.get().prepare('SELECT * FROM companies').all();
  },
  updateFinancials: (company_id, revenue, expenses, profit) => {
    db.get().prepare('UPDATE companies SET revenue = ?, expenses = ?, profit = ? WHERE company_id = ?').run(revenue, expenses, profit, company_id);
  },
  addEmployee: (company_id, discord_id, role) => {
    db.get().prepare('INSERT OR IGNORE INTO company_members (company_id, discord_id, role) VALUES (?, ?, ?)').run(company_id, discord_id, role);
  },
  getEmployees: (company_id) => {
    return db.get().prepare('SELECT * FROM company_members WHERE company_id = ?').all(company_id);
  },
  getMemberCompany: (discord_id) => {
    return db.get().prepare('SELECT c.* FROM companies c JOIN company_members cm ON c.company_id = cm.company_id WHERE cm.discord_id = ?').get(discord_id);
  },
};
