const db = require('../connection');

module.exports = {
  create: (discord_id, ticker, side, quantity, price, fee, total) => {
    return db.get().prepare(
      'INSERT INTO trades (discord_id, ticker, side, quantity, price, fee, total) VALUES (?, ?, ?, ?, ?, ?, ?)'
    ).run(discord_id, ticker, side, quantity, price, fee, total);
  },
  getByUser: (discord_id, limit = 20) => {
    return db.get().prepare('SELECT * FROM trades WHERE discord_id = ? ORDER BY created_at DESC LIMIT ?').all(discord_id, limit);
  },
  getTradeCount: (discord_id) => {
    return db.get().prepare('SELECT COUNT(*) as count FROM trades WHERE discord_id = ?').get(discord_id).count;
  },
  getWinRate: (discord_id) => {
    const rows = db.get().prepare('SELECT ticker, side, price, quantity FROM trades WHERE discord_id = ?').all(discord_id);
    if (rows.length === 0) return 0;
    return 50;
  },
};
