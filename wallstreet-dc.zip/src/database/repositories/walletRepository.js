const db = require('../connection');

module.exports = {
  getById: (discord_id) => {
    return db.get().prepare('SELECT * FROM wallets WHERE discord_id = ?').get(discord_id);
  },
  updateBalance: (discord_id, amount) => {
    db.get().prepare('UPDATE wallets SET balance = balance + ?, updated_at = strftime('%s','now') WHERE discord_id = ?').run(amount, discord_id);
  },
  setBalance: (discord_id, amount) => {
    db.get().prepare('UPDATE wallets SET balance = ?, updated_at = strftime('%s','now') WHERE discord_id = ?').run(amount, discord_id);
  },
  addTransaction: (discord_id, type, amount, description) => {
    db.get().prepare('INSERT INTO transactions (discord_id, type, amount, description) VALUES (?, ?, ?, ?)').run(discord_id, type, amount, description);
  },
  getTransactions: (discord_id, limit = 20) => {
    return db.get().prepare('SELECT * FROM transactions WHERE discord_id = ? ORDER BY created_at DESC LIMIT ?').all(discord_id, limit);
  },
};
