const db = require('../connection');

module.exports = {
  getAll: () => {
    return db.get().prepare('SELECT * FROM stocks WHERE is_active = 1').all();
  },
  getByTicker: (ticker) => {
    return db.get().prepare('SELECT * FROM stocks WHERE ticker = ?').get(ticker);
  },
  create: (data) => {
    const { ticker, name, sector, description, current_price, shares_outstanding, volatility, fundamental_score } = data;
    return db.get().prepare(
      'INSERT INTO stocks (ticker, name, sector, description, current_price, previous_price, shares_outstanding, volatility, fundamental_score) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
    ).run(ticker, name, sector, description, current_price, current_price, shares_outstanding, volatility, fundamental_score);
  },
  updatePrice: (ticker, price) => {
    db.get().prepare('UPDATE stocks SET previous_price = current_price, current_price = ? WHERE ticker = ?').run(price, ticker);
  },
  savePriceHistory: (ticker, price, volume = 0) => {
    db.get().prepare('INSERT INTO stock_prices (ticker, price, volume) VALUES (?, ?, ?)').run(ticker, price, volume);
  },
  getPriceHistory: (ticker, limit = 100) => {
    return db.get().prepare('SELECT * FROM stock_prices WHERE ticker = ? ORDER BY timestamp DESC LIMIT ?').all(ticker, limit);
  },
  getPriceHistoryAsc: (ticker, limit = 100) => {
    return db.get().prepare('SELECT * FROM stock_prices WHERE ticker = ? ORDER BY timestamp ASC LIMIT ?').all(ticker, limit);
  },
  updateMarketCap: (ticker) => {
    db.get().prepare(`UPDATE stocks SET market_cap = current_price * shares_outstanding WHERE ticker = ?`).run(ticker);
  },
};
