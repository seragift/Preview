const db = require('../connection');

module.exports = {
  getOrCreate: (discord_id, username) => {
    const database = db.get();
    let user = database.prepare('SELECT * FROM users WHERE discord_id = ?').get(discord_id);
    if (!user) {
      database.prepare('INSERT INTO users (discord_id, username) VALUES (?, ?)').run(discord_id, username);
      database.prepare('INSERT INTO wallets (discord_id, balance) VALUES (?, ?)').run(discord_id, 100000);
      user = database.prepare('SELECT * FROM users WHERE discord_id = ?').get(discord_id);
    } else {
      database.prepare('UPDATE users SET username = ?, last_active = strftime('%s','now') WHERE discord_id = ?').run(username, discord_id);
    }
    return user;
  },
  getById: (discord_id) => {
    return db.get().prepare('SELECT * FROM users WHERE discord_id = ?').get(discord_id);
  },
  updateActivity: (discord_id) => {
    db.get().prepare('UPDATE users SET last_active = strftime('%s','now') WHERE discord_id = ?').run(discord_id);
  },
  getAll: () => {
    return db.get().prepare('SELECT * FROM users').all();
  },
};
