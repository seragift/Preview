const db = require('../connection');

module.exports = {
  create: (data) => {
    const { title, content, ticker, sector, impact } = data;
    return db.get().prepare('INSERT INTO news (title, content, ticker, sector, impact) VALUES (?, ?, ?, ?, ?)').run(title, content, ticker, sector, impact);
  },
  getRecent: (limit = 10) => {
    return db.get().prepare('SELECT * FROM news ORDER BY created_at DESC LIMIT ?').all(limit);
  },
  getByTicker: (ticker, limit = 5) => {
    return db.get().prepare('SELECT * FROM news WHERE ticker = ? ORDER BY created_at DESC LIMIT ?').all(ticker, limit);
  },
};
