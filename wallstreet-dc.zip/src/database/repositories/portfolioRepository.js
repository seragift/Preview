const db = require('../connection');

module.exports = {
  getByUser: (discord_id) => {
    return db.get().prepare('SELECT p.*, s.name, s.current_price FROM portfolios p JOIN stocks s ON p.ticker = s.ticker WHERE p.discord_id = ?').all(discord_id);
  },
  getHolding: (discord_id, ticker) => {
    return db.get().prepare('SELECT * FROM portfolios WHERE discord_id = ? AND ticker = ?').get(discord_id, ticker);
  },
  addHolding: (discord_id, ticker, quantity, price) => {
    const existing = db.get().prepare('SELECT * FROM portfolios WHERE discord_id = ? AND ticker = ?').get(discord_id, ticker);
    if (existing) {
      const newQty = existing.quantity + quantity;
      const newCost = existing.total_cost + (quantity * price);
      const newAvg = newCost / newQty;
      db.get().prepare('UPDATE portfolios SET quantity = ?, avg_price = ?, total_cost = ?, updated_at = strftime('%s','now') WHERE discord_id = ? AND ticker = ?').run(newQty, newAvg, newCost, discord_id, ticker);
    } else {
      db.get().prepare('INSERT INTO portfolios (discord_id, ticker, quantity, avg_price, total_cost) VALUES (?, ?, ?, ?, ?)').run(discord_id, ticker, quantity, price, quantity * price);
    }
  },
  removeHolding: (discord_id, ticker, quantity) => {
    const existing = db.get().prepare('SELECT * FROM portfolios WHERE discord_id = ? AND ticker = ?').get(discord_id, ticker);
    if (!existing) return false;
    if (existing.quantity < quantity) return false;
    const newQty = existing.quantity - quantity;
    if (newQty <= 0) {
      db.get().prepare('DELETE FROM portfolios WHERE discord_id = ? AND ticker = ?').run(discord_id, ticker);
    } else {
      const newCost = existing.avg_price * newQty;
      db.get().prepare('UPDATE portfolios SET quantity = ?, total_cost = ?, updated_at = strftime('%s','now') WHERE discord_id = ? AND ticker = ?').run(newQty, newCost, discord_id, ticker);
    }
    return true;
  },
  getPortfolioValue: (discord_id) => {
    const rows = db.get().prepare(`SELECT p.quantity, s.current_price FROM portfolios p JOIN stocks s ON p.ticker = s.ticker WHERE p.discord_id = ?`).all(discord_id);
    return rows.reduce((sum, row) => sum + (row.quantity * row.current_price), 0);
  },
};
