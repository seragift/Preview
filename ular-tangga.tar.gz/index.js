const fs = require('fs');
const path = require('path');
const { Client, GatewayIntentBits, Collection } = require('discord.js');
const gameManager = require('./game/GameManager');
const config = require('./config.json');

if (!config.discord || !config.discord.token) {
  console.error('❌ config.json: "discord.token" belum diisi. Isi discord.token, discord.clientId, dan discord.guildId terlebih dahulu.');
  process.exit(1);
}

const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages]
});

client.commands = new Collection();

const commandsPath = path.join(__dirname, 'commands');
for (const file of fs.readdirSync(commandsPath).filter((f) => f.endsWith('.js'))) {
  const command = require(path.join(commandsPath, file));
  client.commands.set(command.data.name, command);
}

const eventsPath = path.join(__dirname, 'events');
for (const file of fs.readdirSync(eventsPath).filter((f) => f.endsWith('.js'))) {
  const event = require(path.join(eventsPath, file));
  if (event.once) {
    client.once(event.name, (...args) => event.execute(...args));
  } else {
    client.on(event.name, (...args) => event.execute(...args));
  }
}

// Cleanup: hapus game dari memori jika pesan game dihapus dari Discord.
client.on('messageDelete', (message) => {
  const game = gameManager.getGame(message.channelId);
  if (game && game.message && game.message.id === message.id) {
    gameManager.deleteGame(message.channelId);
    console.log(`🧹 Game di channel ${message.channelId} dibersihkan (pesan game dihapus).`);
  }
});

process.on('unhandledRejection', (err) => {
  console.error('⚠️ Unhandled promise rejection:', err);
});
process.on('uncaughtException', (err) => {
  console.error('⚠️ Uncaught exception:', err);
});

client.login(config.discord.token);
