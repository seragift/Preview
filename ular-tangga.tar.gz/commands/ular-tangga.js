const {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle
} = require('discord.js');
const gameManager = require('../game/GameManager');
const SnakeLadderGame = require('../game/SnakeLadderGame');
const config = require('../config.json');

function buildLobbyEmbed(game) {
  const playerList = game.players.map((p, i) => `${i + 1}. <@${p.id}>`).join('\n') || '-';
  return new EmbedBuilder()
    .setTitle('🎲 ULAR TANGGA')
    .setDescription('Ayo berlomba mencapai kotak 100!')
    .addFields(
      { name: 'Host', value: `<@${game.hostId}>`, inline: true },
      { name: `Pemain (${game.players.length}/${config.maxPlayers})`, value: playerList }
    )
    .setColor(0xfacc15);
}

function buildLobbyButtons() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('lobby_join').setLabel('➕ Join').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId('lobby_leave').setLabel('🚪 Leave').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('lobby_start').setLabel('▶️ Start').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('lobby_cancel').setLabel('❌ Cancel').setStyle(ButtonStyle.Danger)
  );
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ular-tangga')
    .setDescription('Mulai permainan Ular Tangga multiplayer di channel ini'),

  async execute(interaction) {
    const channelId = interaction.channelId;

    if (gameManager.hasGame(channelId)) {
      return interaction.reply({
        content: '⚠️ Sudah ada game Ular Tangga yang aktif di channel ini.',
        ephemeral: true
      });
    }

    const game = new SnakeLadderGame(channelId, interaction.user);
    gameManager.setGame(channelId, game);

    const embed = buildLobbyEmbed(game);
    const row = buildLobbyButtons();

    const message = await interaction.reply({ embeds: [embed], components: [row], fetchReply: true });
    game.message = message;
  },

  buildLobbyEmbed,
  buildLobbyButtons
};
