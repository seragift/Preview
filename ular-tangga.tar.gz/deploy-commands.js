const fs = require('fs');
const path = require('path');
const { REST, Routes } = require('discord.js');
const config = require('./config.json');

if (!config.discord || !config.discord.token || !config.discord.clientId || !config.discord.guildId) {
  console.error('❌ config.json: pastikan discord.token, discord.clientId, dan discord.guildId sudah diisi.');
  process.exit(1);
}

const commands = [];
const commandsPath = path.join(__dirname, 'commands');
for (const file of fs.readdirSync(commandsPath).filter((f) => f.endsWith('.js'))) {
  const command = require(path.join(commandsPath, file));
  commands.push(command.data.toJSON());
}

const rest = new REST({ version: '10' }).setToken(config.discord.token);

(async () => {
  try {
    console.log(`🚀 Mendaftarkan ${commands.length} slash command...`);
    await rest.put(Routes.applicationGuildCommands(config.discord.clientId, config.discord.guildId), {
      body: commands
    });
    console.log('✅ Slash command berhasil didaftarkan.');
  } catch (err) {
    console.error('❌ Gagal mendaftarkan command:', err);
  }
})();
