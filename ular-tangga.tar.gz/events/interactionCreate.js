const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  AttachmentBuilder
} = require('discord.js');
const gameManager = require('../game/GameManager');
const { renderBoard, renderMoveGif } = require('../game/Renderer');
const config = require('../config.json');
const { diceEmoji } = require('../utils/helpers');

module.exports = {
  name: 'interactionCreate',
  async execute(interaction) {
    try {
      if (interaction.isChatInputCommand()) {
        const command = interaction.client.commands.get(interaction.commandName);
        if (!command) return;
        await command.execute(interaction);
        return;
      }

      if (interaction.isButton()) {
        await handleButton(interaction);
      }
    } catch (err) {
      console.error('❌ Error interactionCreate:', err);
      const payload = { content: '⚠️ Terjadi kesalahan saat memproses aksi ini.', ephemeral: true };
      if (interaction.deferred || interaction.replied) {
        await interaction.followUp(payload).catch(() => {});
      } else {
        await interaction.reply(payload).catch(() => {});
      }
    }
  }
};

async function handleButton(interaction) {
  const { customId, channelId } = interaction;
  const game = gameManager.getGame(channelId);

  if (!game) {
    return interaction.reply({
      content: '⏳ Tidak ada game aktif di channel ini. Gunakan /ular-tangga untuk memulai.',
      ephemeral: true
    });
  }

  switch (customId) {
    case 'lobby_join':
      return handleJoin(interaction, game);
    case 'lobby_leave':
      return handleLeave(interaction, game);
    case 'lobby_start':
      return handleStart(interaction, game);
    case 'lobby_cancel':
      return handleCancel(interaction, game);
    case 'game_roll':
      return handleRoll(interaction, game);
    case 'game_playagain':
      return handlePlayAgain(interaction, game);
    case 'game_newgame':
      return handleNewGame(interaction, game);
    default:
      return;
  }
}

// ---------- LOBBY ----------

async function handleJoin(interaction, game) {
  if (game.status !== 'lobby') {
    return interaction.reply({ content: '⏳ Game belum dimulai... eh, sudah dimulai! Tidak bisa join.', ephemeral: true });
  }
  try {
    game.addPlayer(interaction.user);
  } catch (err) {
    return interaction.reply({ content: `❌ ${err.message}`, ephemeral: true });
  }
  await updateLobbyMessage(interaction, game);
}

async function handleLeave(interaction, game) {
  if (game.status !== 'lobby') {
    return interaction.reply({ content: '⏳ Game sudah dimulai, kamu tidak bisa leave.', ephemeral: true });
  }
  try {
    game.removePlayer(interaction.user.id);
  } catch (err) {
    return interaction.reply({ content: `❌ ${err.message}`, ephemeral: true });
  }

  if (game.players.length === 0) {
    gameManager.deleteGame(game.channelId);
    return interaction.update({ content: '🚪 Semua pemain keluar. Lobby dibubarkan.', embeds: [], components: [] });
  }

  await updateLobbyMessage(interaction, game);
}

async function handleStart(interaction, game) {
  if (!game.isHost(interaction.user.id)) {
    return interaction.reply({ content: '❌ Hanya Host yang dapat memulai game.', ephemeral: true });
  }
  if (!game.canStart()) {
    return interaction.reply({
      content: `❌ Minimal ${config.minPlayers} pemain untuk memulai.`,
      ephemeral: true
    });
  }

  game.start();
  await startGameRound(interaction, game, '▶️ Game dimulai!');
}

async function handleCancel(interaction, game) {
  if (!game.isHost(interaction.user.id)) {
    return interaction.reply({ content: '❌ Hanya Host yang dapat cancel.', ephemeral: true });
  }
  gameManager.deleteGame(game.channelId);
  await interaction.update({ content: '❌ Game dibatalkan oleh Host.', embeds: [], components: [] });
}

// ---------- GAMEPLAY ----------

async function handleRoll(interaction, game) {
  if (game.status !== 'playing') {
    return interaction.reply({ content: '🏁 Game sudah berakhir.', ephemeral: true });
  }
  if (!game.getPlayer(interaction.user.id)) {
    return interaction.reply({ content: '❌ Kamu belum bergabung dalam game.', ephemeral: true });
  }
  if (!game.isPlayerTurn(interaction.user.id)) {
    const current = game.getCurrentPlayer();
    return interaction.reply({ content: `❌ Sekarang giliran <@${current.id}>.`, ephemeral: true });
  }

  // Ack interaksi SECEPAT MUNGKIN, sebelum melakukan apapun yang berat (playTurn/render).
  // Discord cuma kasih waktu ~3 detik untuk deferUpdate(). Kalau gagal (kedaluwarsa),
  // batalkan di sini SEBELUM mengubah state game, supaya pemain bisa klik ulang dengan aman.
  try {
    await interaction.deferUpdate();
  } catch (err) {
    console.error('⚠️ Interaction kedaluwarsa sebelum sempat di-ack (deferUpdate gagal):', err.message);
    return;
  }

  game.clearTurnTimer();
  game.playTurn();

  await renderGameMessage(interaction, game);

  if (game.status === 'finished') return;
  scheduleTurnTimeout(interaction, game);
}

async function handlePlayAgain(interaction, game) {
  if (!game.isHost(interaction.user.id)) {
    return interaction.reply({ content: '❌ Hanya Host yang dapat memulai ulang.', ephemeral: true });
  }
  game.resetForReplay();
  game.start();
  await startGameRound(interaction, game, '🔄 Game dimulai ulang!');
}

async function handleNewGame(interaction, game) {
  gameManager.deleteGame(game.channelId);
  await interaction.update({
    content: 'ℹ️ Gunakan /ular-tangga untuk membuat game baru.',
    embeds: [],
    components: []
  });
}

// ---------- HELPER RENDER ----------

async function updateLobbyMessage(interaction, game) {
  const command = interaction.client.commands.get('ular-tangga');
  const embed = command.buildLobbyEmbed(game);
  const row = command.buildLobbyButtons();
  await interaction.update({ embeds: [embed], components: [row] });
}

async function startGameRound(interaction, game, note) {
  const buffer = await renderBoard(game);
  const attachment = new AttachmentBuilder(buffer, { name: 'board.png' });
  const embed = buildGameEmbed(game, note).setImage('attachment://board.png');
  const row = buildGameButtons(game);

  await interaction.update({ content: '', embeds: [embed], components: [row], files: [attachment] });
  game.message = await interaction.fetchReply().catch(() => game.message);

  scheduleTurnTimeout(interaction, game);
}

/**
 * Render hasil giliran. Jika event menghasilkan pergerakan pion (move/snake/ladder/win),
 * kirim sebagai GIF animasi pion berjalan. Jika tidak ada pergerakan (mis. 'blocked'),
 * kirim gambar statis seperti biasa.
 */
async function renderGameMessage(interaction, game) {
  const event = game.lastEvent;
  let buffer = null;
  let filename = 'board.png';

  if (event && event.type !== 'blocked') {
    try {
      buffer = await renderMoveGif(game, event);
      if (buffer) filename = 'board.gif';
    } catch (err) {
      console.error('⚠️ Gagal membuat GIF animasi, fallback ke gambar statis:', err);
      buffer = null;
    }
  }

  if (!buffer) {
    buffer = await renderBoard(game);
    filename = 'board.png';
  }

  const attachment = new AttachmentBuilder(buffer, { name: filename });
  const embed = buildGameEmbed(game).setImage(`attachment://${filename}`);
  const row = buildGameButtons(game);
  await interaction.editReply({ embeds: [embed], components: [row], files: [attachment] });
}

function buildGameEmbed(game, note) {
  const embed = new EmbedBuilder().setTitle('🎲 ULAR TANGGA').setColor(0xfacc15);

  let description = note ? `${note}\n\n` : '';
  description += formatEvent(game);

  if (game.status === 'playing') {
    const current = game.getCurrentPlayer();
    description += `\n\n🟢 Giliran: <@${current.id}>`;
  }

  if (game.status === 'finished' && game.winner) {
    description += `\n\n🏆 **PEMENANG!**\n<@${game.winner.id}> berhasil mencapai kotak 100!`;
  }

  embed.setDescription(description.trim() || '\u200b');
  return embed;
}

function formatEvent(game) {
  const e = game.lastEvent;
  if (!e) return '';
  const mention = `<@${e.playerId}>`;

  switch (e.type) {
    case 'move':
      return `🎲 ${mention} melempar dadu: ${diceEmoji(e.roll)}\n➡️ Bergerak dari ${e.from} → ${e.to}`;
    case 'blocked':
      return `🎲 ${mention} melempar dadu: ${diceEmoji(e.roll)}\n🚫 Tidak bisa bergerak (melebihi kotak 100).`;
    case 'snake':
      return `🎲 ${mention} melempar dadu: ${diceEmoji(e.roll)}\n🐍 Kena ular! Turun dari ${e.from} → ${e.to}`;
    case 'ladder':
      return `🎲 ${mention} melempar dadu: ${diceEmoji(e.roll)}\n🪜 Naik tangga! Dari ${e.from} → ${e.to}`;
    case 'win':
      return `🎲 ${mention} melempar dadu: ${diceEmoji(e.roll)}\n🏆 Mencapai kotak 100!`;
    case 'timeout':
      return `⏰ Waktu habis! ${mention} melewatkan giliran.`;
    default:
      return '';
  }
}

function buildGameButtons(game) {
  if (game.status === 'finished') {
    return new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('game_playagain').setLabel('🔄 Main Lagi').setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId('game_newgame').setLabel('🏠 Game Baru').setStyle(ButtonStyle.Secondary)
    );
  }
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('game_roll').setLabel('🎲 Lempar Dadu').setStyle(ButtonStyle.Primary)
  );
}

function scheduleTurnTimeout(interaction, game) {
  game.resetTurnTimer(async () => {
    try {
      if (game.status !== 'playing') return;

      const skipped = game.getCurrentPlayer();
      game.lastEvent = { type: 'timeout', playerId: skipped.id };
      game.advanceTurn();

      const buffer = await renderBoard(game);
      const attachment = new AttachmentBuilder(buffer, { name: 'board.png' });
      const embed = buildGameEmbed(game).setImage('attachment://board.png');
      const row = buildGameButtons(game);

      const msg = game.message || (await interaction.fetchReply().catch(() => null));
      if (msg) {
        await msg.edit({ embeds: [embed], components: [row], files: [attachment] });
      }

      scheduleTurnTimeout(interaction, game);
    } catch (err) {
      console.error('❌ Turn timeout error:', err);
    }
  });
}
