function truncate(str, max = 20) {
  if (!str) return '';
  return str.length > max ? `${str.slice(0, max - 1)}…` : str;
}

function medalEmoji(rank) {
  const medals = ['🥇', '🥈', '🥉'];
  return medals[rank] || `${rank + 1}️⃣`;
}

function diceEmoji(value) {
  const faces = ['', '1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣'];
  return faces[value] || '';
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

module.exports = { truncate, medalEmoji, diceEmoji, sleep };
