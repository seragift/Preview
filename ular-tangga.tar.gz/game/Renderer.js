const { createCanvas } = require('canvas');
const GIFEncoder = require('gifencoder');
const {
  BOARD_SIZE,
  CELL_SIZE,
  BOARD_OFFSET_X,
  BOARD_OFFSET_Y,
  PLAYER_COLORS,
  snakes,
  ladders,
  tileToPixel
} = require('./Board');

const CANVAS_WIDTH = 1000;
const HEADER_HEIGHT = 100;
const BOARD_PIXELS = BOARD_SIZE * CELL_SIZE; // 800

function getCanvasHeight(game) {
  const footerHeight = 100 + game.players.length * 34;
  return HEADER_HEIGHT + BOARD_PIXELS + footerHeight;
}

/**
 * Menggambar satu frame papan lengkap.
 * movingPlayerId + overridePos dipakai untuk animasi: pion pemain tsb
 * digambar di koordinat piksel overridePos, bukan di posisi asli game-nya.
 */
function drawFullFrame(ctx, canvasHeight, game, movingPlayerId, overridePos) {
  drawBackground(ctx, canvasHeight);
  drawHeader(ctx);
  drawGrid(ctx);
  drawBoardBorder(ctx);

  for (const [fromStr, to] of Object.entries(ladders)) {
    drawLadder(ctx, Number(fromStr), to);
  }
  for (const [fromStr, to] of Object.entries(snakes)) {
    drawSnake(ctx, Number(fromStr), to);
  }

  drawPlayers(ctx, game, movingPlayerId, overridePos);
  drawFooter(ctx, game, HEADER_HEIGHT + BOARD_PIXELS + 20);
}

async function renderBoard(game) {
  const canvasHeight = getCanvasHeight(game);
  const canvas = createCanvas(CANVAS_WIDTH, canvasHeight);
  const ctx = canvas.getContext('2d');

  drawFullFrame(ctx, canvasHeight, game, null, null);

  return canvas.toBuffer('image/png');
}

/**
 * Menyusun jalur animasi (dalam koordinat piksel) untuk sebuah event giliran:
 * - berjalan tile demi tile dari posisi awal ke tile pendaratan (hasil dadu)
 * - jika kena ular/tangga, lanjut interpolasi mengikuti lengkung ular / rel tangga
 * Mengembalikan null jika event tidak menghasilkan pergerakan (mis. 'blocked').
 */
function buildAnimationPath(event) {
  if (!event || event.type === 'blocked') return null;

  const points = [];
  const isSpecial = event.type === 'snake' || event.type === 'ladder';
  const walkEndTile = isSpecial ? event.from : event.to;

  for (let t = event.start; t <= walkEndTile; t++) {
    points.push(tileToPixel(t));
  }

  if (isSpecial) {
    const startPt = tileToPixel(event.from);
    const endPt = tileToPixel(event.to);
    const steps = 10;

    for (let i = 1; i <= steps; i++) {
      const t = i / steps;
      if (event.type === 'ladder') {
        points.push({
          x: startPt.x + (endPt.x - startPt.x) * t,
          y: startPt.y + (endPt.y - startPt.y) * t
        });
      } else {
        const bend = event.from % 2 === 0 ? 30 : -30;
        const midX = (startPt.x + endPt.x) / 2 + bend;
        const midY = (startPt.y + endPt.y) / 2;
        const x = (1 - t) * (1 - t) * startPt.x + 2 * (1 - t) * t * midX + t * t * endPt.x;
        const y = (1 - t) * (1 - t) * startPt.y + 2 * (1 - t) * t * midY + t * t * endPt.y;
        points.push({ x, y });
      }
    }
  }

  return points;
}

/**
 * Render animasi pergerakan pion sebagai GIF (dimainkan sekali, berhenti di frame akhir).
 * Mengembalikan null jika event tersebut tidak melibatkan pergerakan pion.
 */
async function renderMoveGif(game, event) {
  const path = buildAnimationPath(event);
  if (!path || path.length === 0) return null;

  const canvasHeight = getCanvasHeight(game);
  const canvas = createCanvas(CANVAS_WIDTH, canvasHeight);
  const ctx = canvas.getContext('2d');

  const encoder = new GIFEncoder(CANVAS_WIDTH, canvasHeight);
  encoder.start();
  encoder.setRepeat(-1); // mainkan sekali lalu berhenti di frame terakhir
  encoder.setQuality(10);

  path.forEach((pos, i) => {
    drawFullFrame(ctx, canvasHeight, game, event.playerId, pos);
    const isLast = i === path.length - 1;
    encoder.setDelay(isLast ? 800 : 140);
    encoder.addFrame(ctx);
  });

  encoder.finish();
  return encoder.out.getData();
}

function drawBackground(ctx, canvasHeight) {
  const grad = ctx.createLinearGradient(0, 0, 0, canvasHeight);
  grad.addColorStop(0, '#1e1b4b');
  grad.addColorStop(1, '#0f172a');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, CANVAS_WIDTH, canvasHeight);
}

function drawHeader(ctx) {
  ctx.textAlign = 'center';
  ctx.fillStyle = '#facc15';
  ctx.font = 'bold 42px sans-serif';
  ctx.fillText('🎲 ULAR TANGGA', CANVAS_WIDTH / 2, 62);
  ctx.textAlign = 'left';
}

function drawGrid(ctx) {
  for (let row = 0; row < BOARD_SIZE; row++) {
    for (let col = 0; col < BOARD_SIZE; col++) {
      const x = BOARD_OFFSET_X + col * CELL_SIZE;
      const y = BOARD_OFFSET_Y + row * CELL_SIZE;
      const isEven = (row + col) % 2 === 0;

      ctx.fillStyle = isEven ? '#f8fafc' : '#e2e8f0';
      ctx.fillRect(x, y, CELL_SIZE, CELL_SIZE);
      ctx.strokeStyle = '#94a3b8';
      ctx.lineWidth = 1;
      ctx.strokeRect(x, y, CELL_SIZE, CELL_SIZE);

      const actualRow = 9 - row; // baris dari bawah (0 = tile 1-10)
      const posInRow = actualRow % 2 === 0 ? col : 9 - col;
      const tile = actualRow * 10 + posInRow + 1;

      ctx.fillStyle = '#334155';
      ctx.font = '13px sans-serif';
      ctx.fillText(String(tile), x + 5, y + 16);
    }
  }
}

function drawBoardBorder(ctx) {
  ctx.strokeStyle = '#facc15';
  ctx.lineWidth = 4;
  ctx.strokeRect(BOARD_OFFSET_X, BOARD_OFFSET_Y, BOARD_PIXELS, BOARD_PIXELS);
}

function drawLadder(ctx, from, to) {
  const p1 = tileToPixel(from);
  const p2 = tileToPixel(to);
  const dx = p2.x - p1.x;
  const dy = p2.y - p1.y;
  const len = Math.sqrt(dx * dx + dy * dy) || 1;
  const nx = -dy / len;
  const ny = dx / len;
  const railOffset = 10;

  ctx.strokeStyle = '#a16207';
  ctx.lineWidth = 5;
  ctx.lineCap = 'round';

  ctx.beginPath();
  ctx.moveTo(p1.x + nx * railOffset, p1.y + ny * railOffset);
  ctx.lineTo(p2.x + nx * railOffset, p2.y + ny * railOffset);
  ctx.stroke();

  ctx.beginPath();
  ctx.moveTo(p1.x - nx * railOffset, p1.y - ny * railOffset);
  ctx.lineTo(p2.x - nx * railOffset, p2.y - ny * railOffset);
  ctx.stroke();

  const steps = Math.max(4, Math.floor(len / 25));
  ctx.strokeStyle = '#ca8a04';
  ctx.lineWidth = 4;
  for (let i = 1; i < steps; i++) {
    const t = i / steps;
    const cx = p1.x + dx * t;
    const cy = p1.y + dy * t;
    ctx.beginPath();
    ctx.moveTo(cx + nx * railOffset, cy + ny * railOffset);
    ctx.lineTo(cx - nx * railOffset, cy - ny * railOffset);
    ctx.stroke();
  }
}

function drawSnake(ctx, from, to) {
  const head = tileToPixel(from);
  const tail = tileToPixel(to);
  const bend = from % 2 === 0 ? 30 : -30;
  const midX = (head.x + tail.x) / 2 + bend;
  const midY = (head.y + tail.y) / 2;

  ctx.strokeStyle = '#16a34a';
  ctx.lineWidth = 8;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(head.x, head.y);
  ctx.quadraticCurveTo(midX, midY, tail.x, tail.y);
  ctx.stroke();

  // kepala
  ctx.beginPath();
  ctx.arc(head.x, head.y, 11, 0, Math.PI * 2);
  ctx.fillStyle = '#15803d';
  ctx.fill();

  // mata
  ctx.fillStyle = 'white';
  ctx.beginPath();
  ctx.arc(head.x - 4, head.y - 3, 2, 0, Math.PI * 2);
  ctx.arc(head.x + 4, head.y - 3, 2, 0, Math.PI * 2);
  ctx.fill();

  // ujung ekor
  ctx.beginPath();
  ctx.arc(tail.x, tail.y, 5, 0, Math.PI * 2);
  ctx.fillStyle = '#16a34a';
  ctx.fill();
}

function drawPlayers(ctx, game, movingPlayerId, overridePos) {
  const byTile = {};
  for (const p of game.players) {
    if (p.id === movingPlayerId) continue; // digambar terpisah di bawah, di atas token lain
    if (!byTile[p.position]) byTile[p.position] = [];
    byTile[p.position].push(p);
  }

  for (const [tileStr, players] of Object.entries(byTile)) {
    const tile = Number(tileStr);
    const { x, y } = tileToPixel(tile);
    const n = players.length;

    players.forEach((p, i) => {
      const angle = (2 * Math.PI * i) / Math.max(n, 1);
      const radius = n > 1 ? 16 : 0;
      const px = x + Math.cos(angle) * radius;
      const py = y + Math.sin(angle) * radius;
      drawToken(ctx, px, py, PLAYER_COLORS[p.colorIndex].hex);
    });
  }

  const movingPlayer = movingPlayerId && game.players.find((p) => p.id === movingPlayerId);
  if (movingPlayer) {
    const pos = overridePos || tileToPixel(movingPlayer.position);
    drawToken(ctx, pos.x, pos.y, PLAYER_COLORS[movingPlayer.colorIndex].hex);
  }
}

function drawToken(ctx, x, y, color) {
  ctx.beginPath();
  ctx.arc(x, y, 12, 0, Math.PI * 2);
  ctx.fillStyle = color;
  ctx.fill();
  ctx.lineWidth = 2;
  ctx.strokeStyle = '#1e293b';
  ctx.stroke();
}

function drawFooter(ctx, game, footerTop) {
  ctx.textAlign = 'left';
  ctx.fillStyle = '#f8fafc';
  ctx.font = 'bold 22px sans-serif';
  ctx.fillText('📊 PAPAN SKOR', 40, footerTop + 10);

  const scoreboard = game.getScoreboard();
  scoreboard.forEach((p, i) => {
    const y = footerTop + 45 + i * 34;
    const rank = ['🥇', '🥈', '🥉'][i] || `${i + 1}️⃣`;

    ctx.beginPath();
    ctx.arc(50, y - 6, 8, 0, Math.PI * 2);
    ctx.fillStyle = PLAYER_COLORS[p.colorIndex].hex;
    ctx.fill();

    ctx.fillStyle = '#f8fafc';
    ctx.font = '18px sans-serif';
    const statusTxt = p.finished ? '🏆 FINISH' : `Kotak ${p.position}`;
    const isTurn = game.status === 'playing' && game.getCurrentPlayer().id === p.id;
    const turnMark = isTurn ? ' 🟢' : '';
    ctx.fillText(`${rank} ${p.username} — ${statusTxt}${turnMark}`, 70, y);
  });
}

module.exports = { renderBoard, renderMoveGif };
