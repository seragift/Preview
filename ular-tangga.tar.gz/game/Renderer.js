const { createCanvas } = require('canvas');
const GIFEncoder = require('gif-encoder-2');
const {
  BOARD_SIZE,
  CELL_SIZE,
  BOARD_OFFSET_X,
  BOARD_OFFSET_Y,
  PLAYER_COLORS,
  snakes,
  ladders,
  tileToPixel
} = require('./Board');

const CANVAS_WIDTH = 1000;
const HEADER_HEIGHT = 100;
const BOARD_PIXELS = BOARD_SIZE * CELL_SIZE; // 800

function getCanvasHeight(game) {
  const footerHeight = 100 + game.players.length * 34;
  return HEADER_HEIGHT + BOARD_PIXELS + footerHeight;
}

/**
 * Menggambar layer statis papan (background, header, grid, border, ular, tangga).
 * Bagian ini SAMA di setiap frame animasi, jadi cukup digambar SEKALI lalu di-reuse
 * (drawImage) untuk tiap frame — bukan digambar ulang dari nol tiap frame. Ini penting
 * untuk performa: menggambar 100 kotak + kurva ular/tangga itu berat kalau diulang
 * puluhan kali per animasi, dan bisa bikin bot "membeku" (blocking event loop) sampai
 * interaction Discord kedaluwarsa.
 */
function renderStaticLayer(canvasHeight) {
  const canvas = createCanvas(CANVAS_WIDTH, canvasHeight);
  const ctx = canvas.getContext('2d');

  drawBackground(ctx, canvasHeight);
  drawHeader(ctx);
  drawGrid(ctx);
  drawBoardBorder(ctx);

  for (const [fromStr, to] of Object.entries(ladders)) {
    drawLadder(ctx, Number(fromStr), to);
  }
  for (const [fromStr, to] of Object.entries(snakes)) {
    drawSnake(ctx, Number(fromStr), to);
  }

  return canvas;
}

/**
 * Menggambar satu frame papan lengkap.
 * movingPlayerId + overridePos dipakai untuk animasi: pion pemain tsb
 * digambar di koordinat piksel overridePos, bukan di posisi asli game-nya.
 * staticLayer (opsional) adalah hasil renderStaticLayer() yang di-cache agar
 * bagian papan/ular/tangga tidak perlu digambar ulang tiap frame.
 */
function drawFullFrame(ctx, canvasHeight, game, movingPlayerId, overridePos, staticLayer) {
  if (staticLayer) {
    ctx.drawImage(staticLayer, 0, 0);
  } else {
    drawBackground(ctx, canvasHeight);
    drawHeader(ctx);
    drawGrid(ctx);
    drawBoardBorder(ctx);
    for (const [fromStr, to] of Object.entries(ladders)) {
      drawLadder(ctx, Number(fromStr), to);
    }
    for (const [fromStr, to] of Object.entries(snakes)) {
      drawSnake(ctx, Number(fromStr), to);
    }
  }

  drawPlayers(ctx, game, movingPlayerId, overridePos);
  drawFooter(ctx, game, HEADER_HEIGHT + BOARD_PIXELS + 20);
}

async function renderBoard(game) {
  const canvasHeight = getCanvasHeight(game);
  const canvas = createCanvas(CANVAS_WIDTH, canvasHeight);
  const ctx = canvas.getContext('2d');
  const staticLayer = renderStaticLayer(canvasHeight);

  drawFullFrame(ctx, canvasHeight, game, null, null, staticLayer);

  return canvas.toBuffer('image/png');
}

/**
 * Memberi jeda sekejap ke event loop Node.js. Dipanggil berkala di antara frame
 * GIF supaya proses render yang cukup berat tidak memblokir bot sepenuhnya —
 * interaction Discord lain (mis. giliran pemain lain / channel lain) tetap
 * bisa diproses tepat waktu selagi GIF sedang dibuat.
 */
function yieldToEventLoop() {
  return new Promise((resolve) => setImmediate(resolve));
}

/**
 * Menyusun jalur jalan pion (dalam koordinat piksel), dengan sub-frame interpolasi
 * di antara tiap kotak supaya gerakannya mengalir/smooth, bukan loncat kaku.
 * Jika kena ular/tangga, dilanjutkan interpolasi mengikuti lengkung ular / rel tangga.
 */
function buildWalkPath(event) {
  const SUB_STEPS = 2; // sub-frame di antara tiap kotak (dikurangi demi performa)
  const points = [];

  const isSpecial = event.type === 'snake' || event.type === 'ladder';
  const walkEndTile = isSpecial ? event.from : event.to;

  let prevPt = tileToPixel(event.start);
  for (let t = event.start + 1; t <= walkEndTile; t++) {
    const nextPt = tileToPixel(t);
    for (let s = 1; s <= SUB_STEPS; s++) {
      const ratio = s / SUB_STEPS;
      points.push({
        x: prevPt.x + (nextPt.x - prevPt.x) * ratio,
        y: prevPt.y + (nextPt.y - prevPt.y) * ratio
      });
    }
    prevPt = nextPt;
  }

  if (isSpecial) {
    const startPt = tileToPixel(event.from);
    const endPt = tileToPixel(event.to);
    const steps = 8;

    for (let i = 1; i <= steps; i++) {
      const t = i / steps;
      if (event.type === 'ladder') {
        points.push({
          x: startPt.x + (endPt.x - startPt.x) * t,
          y: startPt.y + (endPt.y - startPt.y) * t
        });
      } else {
        const bend = event.from % 2 === 0 ? 30 : -30;
        const midX = (startPt.x + endPt.x) / 2 + bend;
        const midY = (startPt.y + endPt.y) / 2;
        const x = (1 - t) * (1 - t) * startPt.x + 2 * (1 - t) * t * midX + t * t * endPt.x;
        const y = (1 - t) * (1 - t) * startPt.y + 2 * (1 - t) * t * midY + t * t * endPt.y;
        points.push({ x, y });
      }
    }
  }

  return points;
}

/**
 * Render animasi giliran sebagai GIF (dimainkan sekali, berhenti di frame akhir):
 * 1. Tampilkan hasil dadu (pip dadu asli) dulu, pion masih diam.
 * 2. Baru pion berjalan halus menuju posisi akhir (termasuk slide ular/tangga jika ada).
 * Mengembalikan null jika event tidak menghasilkan pergerakan (mis. 'blocked').
 *
 * Dioptimalkan untuk KECEPATAN: layer papan/ular/tangga digambar sekali lalu
 * di-reuse tiap frame (bukan digambar ulang), dan event loop diberi jeda berkala
 * supaya proses ini tidak memblokir bot secara total (mencegah interaction Discord
 * kedaluwarsa / DiscordAPIError 10062).
 */
async function renderMoveGif(game, event) {
  if (!event || event.type === 'blocked') return null;

  const canvasHeight = getCanvasHeight(game);
  const canvas = createCanvas(CANVAS_WIDTH, canvasHeight);
  const ctx = canvas.getContext('2d');
  const staticLayer = renderStaticLayer(canvasHeight);

  const encoder = new GIFEncoder(CANVAS_WIDTH, canvasHeight);
  encoder.start();
  encoder.setRepeat(-1); // mainkan sekali lalu berhenti di frame terakhir
  encoder.setQuality(15); // angka lebih besar = lebih cepat (kualitas warna sedikit turun)

  const movingId = event.playerId;
  const startPixel = tileToPixel(event.start);

  // FASE 1: tampilkan angka dadu dulu, pion belum bergerak
  drawFullFrame(ctx, canvasHeight, game, movingId, startPixel, staticLayer);
  drawDiceOverlay(ctx, event.roll);
  encoder.setDelay(900);
  encoder.addFrame(ctx);

  await yieldToEventLoop();

  // FASE 2: pion berjalan halus ke posisi akhir
  const walkPath = buildWalkPath(event);
  for (let i = 0; i < walkPath.length; i++) {
    drawFullFrame(ctx, canvasHeight, game, movingId, walkPath[i], staticLayer);
    const isLast = i === walkPath.length - 1;
    encoder.setDelay(isLast ? 800 : 55);
    encoder.addFrame(ctx);

    if (i % 3 === 0) await yieldToEventLoop();
  }

  encoder.finish();
  const data = encoder.out.getData();
  return Buffer.isBuffer(data) ? data : Buffer.from(data);
}

function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

function drawDicePips(ctx, x, y, size, value) {
  const layout = {
    1: [[1, 1]],
    2: [[0, 0], [2, 2]],
    3: [[0, 0], [1, 1], [2, 2]],
    4: [[0, 0], [0, 2], [2, 0], [2, 2]],
    5: [[0, 0], [0, 2], [1, 1], [2, 0], [2, 2]],
    6: [[0, 0], [0, 1], [0, 2], [2, 0], [2, 1], [2, 2]]
  };
  const pips = layout[value] || [];
  const cell = size / 3;
  const pipRadius = size * 0.09;

  ctx.fillStyle = '#1e293b';
  pips.forEach(([col, row]) => {
    const cx = x + cell * col + cell / 2;
    const cy = y + cell * row + cell / 2;
    ctx.beginPath();
    ctx.arc(cx, cy, pipRadius, 0, Math.PI * 2);
    ctx.fill();
  });
}

function drawDiceOverlay(ctx, value) {
  const size = 150;
  const x = CANVAS_WIDTH / 2 - size / 2;
  const y = BOARD_OFFSET_Y + (BOARD_PIXELS - size) / 2;

  // dim backdrop agar fokus ke dadu
  ctx.fillStyle = 'rgba(15, 23, 42, 0.55)';
  ctx.fillRect(BOARD_OFFSET_X, BOARD_OFFSET_Y, BOARD_PIXELS, BOARD_PIXELS);

  ctx.save();
  ctx.shadowColor = 'rgba(0, 0, 0, 0.4)';
  ctx.shadowBlur = 20;
  roundRect(ctx, x, y, size, size, 24);
  ctx.fillStyle = '#ffffff';
  ctx.fill();
  ctx.restore();

  ctx.strokeStyle = '#facc15';
  ctx.lineWidth = 5;
  roundRect(ctx, x, y, size, size, 24);
  ctx.stroke();

  drawDicePips(ctx, x, y, size, value);
}

function drawBackground(ctx, canvasHeight) {
  const grad = ctx.createLinearGradient(0, 0, 0, canvasHeight);
  grad.addColorStop(0, '#1e1b4b');
  grad.addColorStop(1, '#0f172a');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, CANVAS_WIDTH, canvasHeight);
}

function drawHeader(ctx) {
  ctx.textAlign = 'center';
  ctx.fillStyle = '#facc15';
  ctx.font = 'bold 42px sans-serif';
  ctx.fillText('🎲 ULAR TANGGA', CANVAS_WIDTH / 2, 62);
  ctx.textAlign = 'left';
}

function drawGrid(ctx) {
  for (let row = 0; row < BOARD_SIZE; row++) {
    for (let col = 0; col < BOARD_SIZE; col++) {
      const x = BOARD_OFFSET_X + col * CELL_SIZE;
      const y = BOARD_OFFSET_Y + row * CELL_SIZE;
      const isEven = (row + col) % 2 === 0;

      ctx.fillStyle = isEven ? '#f8fafc' : '#e2e8f0';
      ctx.fillRect(x, y, CELL_SIZE, CELL_SIZE);
      ctx.strokeStyle = '#94a3b8';
      ctx.lineWidth = 1;
      ctx.strokeRect(x, y, CELL_SIZE, CELL_SIZE);

      const actualRow = 9 - row; // baris dari bawah (0 = tile 1-10)
      const posInRow = actualRow % 2 === 0 ? col : 9 - col;
      const tile = actualRow * 10 + posInRow + 1;

      ctx.fillStyle = '#334155';
      ctx.font = '13px sans-serif';
      ctx.fillText(String(tile), x + 5, y + 16);
    }
  }
}

function drawBoardBorder(ctx) {
  ctx.strokeStyle = '#facc15';
  ctx.lineWidth = 4;
  ctx.strokeRect(BOARD_OFFSET_X, BOARD_OFFSET_Y, BOARD_PIXELS, BOARD_PIXELS);
}

function drawLadder(ctx, from, to) {
  const p1 = tileToPixel(from);
  const p2 = tileToPixel(to);
  const dx = p2.x - p1.x;
  const dy = p2.y - p1.y;
  const len = Math.sqrt(dx * dx + dy * dy) || 1;
  const nx = -dy / len;
  const ny = dx / len;
  const railOffset = 10;

  ctx.strokeStyle = '#a16207';
  ctx.lineWidth = 5;
  ctx.lineCap = 'round';

  ctx.beginPath();
  ctx.moveTo(p1.x + nx * railOffset, p1.y + ny * railOffset);
  ctx.lineTo(p2.x + nx * railOffset, p2.y + ny * railOffset);
  ctx.stroke();

  ctx.beginPath();
  ctx.moveTo(p1.x - nx * railOffset, p1.y - ny * railOffset);
  ctx.lineTo(p2.x - nx * railOffset, p2.y - ny * railOffset);
  ctx.stroke();

  const steps = Math.max(4, Math.floor(len / 25));
  ctx.strokeStyle = '#ca8a04';
  ctx.lineWidth = 4;
  for (let i = 1; i < steps; i++) {
    const t = i / steps;
    const cx = p1.x + dx * t;
    const cy = p1.y + dy * t;
    ctx.beginPath();
    ctx.moveTo(cx + nx * railOffset, cy + ny * railOffset);
    ctx.lineTo(cx - nx * railOffset, cy - ny * railOffset);
    ctx.stroke();
  }
}

function drawSnake(ctx, from, to) {
  const head = tileToPixel(from);
  const tail = tileToPixel(to);
  const bend = from % 2 === 0 ? 30 : -30;
  const midX = (head.x + tail.x) / 2 + bend;
  const midY = (head.y + tail.y) / 2;

  ctx.strokeStyle = '#16a34a';
  ctx.lineWidth = 8;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(head.x, head.y);
  ctx.quadraticCurveTo(midX, midY, tail.x, tail.y);
  ctx.stroke();

  // kepala
  ctx.beginPath();
  ctx.arc(head.x, head.y, 11, 0, Math.PI * 2);
  ctx.fillStyle = '#15803d';
  ctx.fill();

  // mata
  ctx.fillStyle = 'white';
  ctx.beginPath();
  ctx.arc(head.x - 4, head.y - 3, 2, 0, Math.PI * 2);
  ctx.arc(head.x + 4, head.y - 3, 2, 0, Math.PI * 2);
  ctx.fill();

  // ujung ekor
  ctx.beginPath();
  ctx.arc(tail.x, tail.y, 5, 0, Math.PI * 2);
  ctx.fillStyle = '#16a34a';
  ctx.fill();
}

function drawPlayers(ctx, game, movingPlayerId, overridePos) {
  const byTile = {};
  for (const p of game.players) {
    if (p.id === movingPlayerId) continue; // digambar terpisah di bawah, di atas token lain
    if (!byTile[p.position]) byTile[p.position] = [];
    byTile[p.position].push(p);
  }

  for (const [tileStr, players] of Object.entries(byTile)) {
    const tile = Number(tileStr);
    const { x, y } = tileToPixel(tile);
    const n = players.length;

    players.forEach((p, i) => {
      const angle = (2 * Math.PI * i) / Math.max(n, 1);
      const radius = n > 1 ? 16 : 0;
      const px = x + Math.cos(angle) * radius;
      const py = y + Math.sin(angle) * radius;
      drawToken(ctx, px, py, PLAYER_COLORS[p.colorIndex].hex);
    });
  }

  const movingPlayer = movingPlayerId && game.players.find((p) => p.id === movingPlayerId);
  if (movingPlayer) {
    const pos = overridePos || tileToPixel(movingPlayer.position);
    drawToken(ctx, pos.x, pos.y, PLAYER_COLORS[movingPlayer.colorIndex].hex);
  }
}

function drawToken(ctx, x, y, color) {
  ctx.beginPath();
  ctx.arc(x, y, 12, 0, Math.PI * 2);
  ctx.fillStyle = color;
  ctx.fill();
  ctx.lineWidth = 2;
  ctx.strokeStyle = '#1e293b';
  ctx.stroke();
}

function drawFooter(ctx, game, footerTop) {
  ctx.textAlign = 'left';
  ctx.fillStyle = '#f8fafc';
  ctx.font = 'bold 22px sans-serif';
  ctx.fillText('📊 PAPAN SKOR', 40, footerTop + 10);

  const scoreboard = game.getScoreboard();
  scoreboard.forEach((p, i) => {
    const y = footerTop + 45 + i * 34;
    const rank = ['🥇', '🥈', '🥉'][i] || `${i + 1}️⃣`;

    ctx.beginPath();
    ctx.arc(50, y - 6, 8, 0, Math.PI * 2);
    ctx.fillStyle = PLAYER_COLORS[p.colorIndex].hex;
    ctx.fill();

    ctx.fillStyle = '#f8fafc';
    ctx.font = '18px sans-serif';
    const statusTxt = p.finished ? '🏆 FINISH' : `Kotak ${p.position}`;
    const isTurn = game.status === 'playing' && game.getCurrentPlayer().id === p.id;
    const turnMark = isTurn ? ' 🟢' : '';
    ctx.fillText(`${rank} ${p.username} — ${statusTxt}${turnMark}`, 70, y);
  });
}

module.exports = { renderBoard, renderMoveGif };
