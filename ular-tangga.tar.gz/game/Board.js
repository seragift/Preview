const { snakes, ladders } = require('./boardConfig');

const BOARD_SIZE = 10;
const TOTAL_TILES = 100;
const CELL_SIZE = 80;
const BOARD_OFFSET_X = 100;
const BOARD_OFFSET_Y = 100;

const PLAYER_COLORS = [
  { name: 'Merah', hex: '#e74c3c' },
  { name: 'Biru', hex: '#3498db' },
  { name: 'Hijau', hex: '#2ecc71' },
  { name: 'Kuning', hex: '#f1c40f' },
  { name: 'Ungu', hex: '#9b59b6' }
];

/**
 * Papan disusun zig-zag klasik Ular Tangga:
 * baris 0 (tile 1-10)   -> kiri ke kanan naik
 * baris 1 (tile 11-20)  -> kanan ke kiri (terbalik)
 * baris 2 (tile 21-30)  -> kiri ke kanan naik
 * ...dst berselang-seling, baris 9 (91-100) berada paling atas.
 */
function tileToRowCol(tile) {
  const n = tile - 1;
  const row = Math.floor(n / 10); // 0 = baris paling bawah
  const posInRow = n % 10;
  const col = row % 2 === 0 ? posInRow : 9 - posInRow;
  return { row, col };
}

function tileToPixel(tile) {
  if (tile <= 0) {
    return {
      x: BOARD_OFFSET_X - 40,
      y: BOARD_OFFSET_Y + BOARD_SIZE * CELL_SIZE - CELL_SIZE / 2
    };
  }
  const { row, col } = tileToRowCol(tile);
  const displayRow = 9 - row; // baris tertinggi (91-100) tampil paling atas
  const x = BOARD_OFFSET_X + col * CELL_SIZE + CELL_SIZE / 2;
  const y = BOARD_OFFSET_Y + displayRow * CELL_SIZE + CELL_SIZE / 2;
  return { x, y };
}

function checkSnakeOrLadder(position) {
  if (snakes[position]) {
    return { type: 'snake', from: position, to: snakes[position] };
  }
  if (ladders[position]) {
    return { type: 'ladder', from: position, to: ladders[position] };
  }
  return null;
}

module.exports = {
  BOARD_SIZE,
  TOTAL_TILES,
  CELL_SIZE,
  BOARD_OFFSET_X,
  BOARD_OFFSET_Y,
  PLAYER_COLORS,
  snakes,
  ladders,
  tileToRowCol,
  tileToPixel,
  checkSnakeOrLadder
};
