class GameManager {
  constructor() {
    this.games = new Map();
  }

  hasGame(channelId) {
    return this.games.has(channelId);
  }

  getGame(channelId) {
    return this.games.get(channelId);
  }

  setGame(channelId, game) {
    this.games.set(channelId, game);
  }

  deleteGame(channelId) {
    const game = this.games.get(channelId);
    if (game) {
      game.destroy();
    }
    this.games.delete(channelId);
  }
}

// Singleton agar state game konsisten di seluruh bot (tanpa database).
module.exports = new GameManager();
