class Player {
  constructor(id, username, colorIndex) {
    this.id = id;
    this.username = username;
    this.colorIndex = colorIndex;
    this.position = 0;
    this.finished = false;
  }
}

module.exports = Player;
