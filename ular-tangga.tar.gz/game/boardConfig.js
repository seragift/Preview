// Konfigurasi posisi ular dan tangga.
// Disimpan terpisah dari logika game agar mudah diubah/diseimbangkan.

const snakes = {
  98: 78,
  95: 75,
  92: 88,
  64: 44,
  62: 19,
  56: 23,
  48: 26
};

const ladders = {
  4: 25,
  9: 31,
  20: 38,
  28: 84,
  40: 59,
  51: 67,
  63: 81,
  71: 91
};

module.exports = { snakes, ladders };
