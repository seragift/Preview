// Script debug mandiri: membuat satu contoh GIF animasi dan menyimpannya ke disk,
// supaya bisa dicek LANGSUNG apakah file GIF-nya valid (dibuka pakai browser/image
// viewer biasa) — terlepas dari apapun yang terjadi di sisi Discord.
//
// Jalankan di server/komputer yang sama tempat bot ini jalan (node_modules harus
// sudah ter-install):
//
//   node test-gif.js
//
// Setelah selesai, buka file "test-animasi.gif" yang muncul di folder ini.
// - Kalau file itu TERBUKA NORMAL dan pion terlihat bergerak -> masalahnya ada di
//   sisi Discord/koneksi, bukan di kode generate GIF-nya.
// - Kalau file itu GAGAL dibuka / rusak / ukurannya aneh -> kirim ke saya:
//   1. Seluruh output di terminal saat menjalankan script ini
//   2. Versi Node.js kamu (jalankan: node -v)
//   3. Isi package.json bagian dependencies (khususnya versi "canvas" dan "gif-encoder-2")

const fs = require('fs');
const path = require('path');
const { renderMoveGif } = require('./game/Renderer');
const SnakeLadderGame = require('./game/SnakeLadderGame');

async function main() {
  console.log('🧪 Membuat game contoh untuk testing...');

  const fakeHost = { id: '111111111111111111', username: 'Bayu' };
  const game = new SnakeLadderGame('debug-channel', fakeHost);
  game.addPlayer({ id: '222222222222222222', username: 'Andi' });
  game.start();

  // Event contoh: pemain bergerak dari kotak 7 ke kotak 10 dengan dadu = 3
  const event = {
    type: 'move',
    playerId: game.players[0].id,
    start: 7,
    from: 7,
    to: 10,
    roll: 3
  };
  game.players[0].position = 10; // samakan state game dengan event di atas

  console.log('⏳ Meng-generate GIF animasi (renderMoveGif)...');
  const startedAt = Date.now();
  const buffer = await renderMoveGif(game, event);
  const elapsedMs = Date.now() - startedAt;

  if (!buffer || buffer.length === 0) {
    console.error('❌ renderMoveGif mengembalikan buffer kosong/null. Ada yang salah di proses encoding.');
    process.exit(1);
  }

  console.log(`✅ Buffer GIF berhasil dibuat dalam ${elapsedMs}ms`);
  if (elapsedMs > 2000) {
    console.warn(`⚠️ PERINGATAN: render memakan ${elapsedMs}ms. Karena proses canvas/GIF ini synchronous, durasi selama itu bisa memblokir bot memproses interaction Discord lain (klik tombol pemain/channel lain), yang bisa berujung DiscordAPIError[10062] Unknown interaction pada interaction tsb.`);
  }
  console.log(`   Ukuran: ${(buffer.length / 1024).toFixed(1)} KB`);
  console.log(`   Buffer.isBuffer: ${Buffer.isBuffer(buffer)}`);

  // Cek 6 byte pertama file — GIF valid harus berupa "GIF87a" atau "GIF89a"
  const signature = buffer.slice(0, 6).toString('ascii');
  const validSignature = signature === 'GIF87a' || signature === 'GIF89a';
  console.log(`   Signature header: "${signature}" -> ${validSignature ? '✅ VALID' : '❌ TIDAK VALID (file rusak!)'}`);

  const outPath = path.join(__dirname, 'test-animasi.gif');
  fs.writeFileSync(outPath, buffer);
  console.log(`💾 Disimpan ke: ${outPath}`);
  console.log('👉 Buka file ini langsung pakai browser (drag & drop ke tab baru) atau image viewer untuk cek apakah animasinya jalan normal.');
}

main().catch((err) => {
  console.error('❌ Error saat generate GIF:', err);
  process.exit(1);
});
