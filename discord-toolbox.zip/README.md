# 🧰 Discord Toolbox

Swiss Army Knife utility bot for Discord. Built with Discord.js v14.

## Requirements

- Node.js 20+
- npm or yarn

## Installation

1. Clone/download this repository
2. Copy `.env.example` to `.env` and fill in your credentials:
   ```
   DISCORD_TOKEN=your_bot_token
   CLIENT_ID=your_application_id
   GUILD_ID=your_test_guild_id (optional)
   OWNER_ID=your_discord_user_id
   ```
3. Install dependencies:
   ```bash
   npm install
   ```
4. Deploy slash commands:
   ```bash
   npm run deploy
   ```
5. Start the bot:
   ```bash
   npm start
   ```

## Commands

| Category | Commands |
|----------|----------|
| 🖼️ Image | resize, compress, convert, rotate, info, blur, pixelate, qr |
| 📄 Text | uppercase, lowercase, reverse, count, remove-space, remove-duplicate, sort, random |
| 👨‍💻 Developer | json-format, json-minify, base64-encode, base64-decode, jwt-decode, regex, timestamp, color, hash |
| 🌐 Network | dns, ip, domain, ssl, headers, status, ping |
| 📦 File | info, hash, zip, unzip |
| 🔗 URL | encode, decode, info, expand, shorten |
| 🔐 Generator | password, uuid, hash, qr, timestamp |
| ⚙️ Utility | stats |

## Folder Structure

```
discord-toolbox/
├── index.js
├── deploy-commands.js
├── package.json
├── .env
├── .gitignore
├── README.md
├── database/
│   └── database.sqlite
├── temp/
│   └── .gitkeep
└── src/
    ├── commands/
    │   ├── toolbox.js
    │   ├── image.js
    │   ├── text.js
    │   ├── developer.js
    │   ├── network.js
    │   ├── file.js
    │   ├── url.js
    │   ├── generate.js
    │   └── utility.js
    ├── events/
    │   ├── ready.js
    │   └── interactionCreate.js
    ├── handlers/
    │   └── commandHandler.js
    ├── services/
    │   ├── imageService.js
    │   ├── networkService.js
    │   ├── fileService.js
    │   ├── qrService.js
    │   └── urlService.js
    ├── database/
    │   └── database.js
    ├── utils/
    │   ├── embed.js
    │   ├── logger.js
    │   ├── cooldown.js
    │   └── format.js
    └── config/
        └── config.js
```

## Security

- Input validation on all commands
- URL validation with HTTP/HTTPS restriction
- File size limits (25MB)
- Path traversal protection for unzip
- Temporary file cleanup
- Cooldown system (3s default)
- Error IDs for debugging without exposing internals
- No sensitive data logged to users
- Passwords are never stored in database

## Troubleshooting

- **SQLite errors**: Ensure `database/` directory exists and is writable
- **Canvas/Sharp build errors**: Run `npm rebuild` or install build tools
- **Commands not appearing**: Run `npm run deploy` after adding the bot to a server
- **Bot not responding**: Check that `DISCORD_TOKEN` is correct
