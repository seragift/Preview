const { Client, GatewayIntentBits, Collection } = require("discord.js");
const config = require("./src/config/config");
const { loadCommands } = require("./src/handlers/commandHandler");
const Logger = require("./src/utils/logger");
const fs = require("fs");
const path = require("path");

const client = new Client({
  intents: [GatewayIntentBits.Guilds],
});

client.commands = new Collection();
const { commandsCollection } = loadCommands();
for (const [name, cmd] of commandsCollection) {
  client.commands.set(name, cmd);
}

const eventsPath = path.join(__dirname, "src/events");
const eventFiles = fs.readdirSync(eventsPath).filter((file) => file.endsWith(".js"));

for (const file of eventFiles) {
  const filePath = path.join(eventsPath, file);
  const event = require(filePath);
  if (event.once) {
    client.once(event.name, (...args) => event.execute(...args, client));
  } else {
    client.on(event.name, (...args) => event.execute(...args, client));
  }
  Logger.info(`Loaded event: ${event.name}`);
}

process.on("uncaughtException", (err) => {
  Logger.error("Uncaught Exception", err);
});

process.on("unhandledRejection", (reason, promise) => {
  Logger.error("Unhandled Rejection", reason);
});

client.login(config.token);
