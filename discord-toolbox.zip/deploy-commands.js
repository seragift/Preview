const { REST, Routes } = require("discord.js");
const config = require("./src/config/config");
const { loadCommands } = require("./src/handlers/commandHandler");
const Logger = require("./src/utils/logger");

const { commands } = loadCommands();
const rest = new REST({ version: "10" }).setToken(config.token);

(async () => {
  try {
    Logger.info(`Deploying ${commands.length} commands...`);
    await rest.put(
      config.guildId
        ? Routes.applicationGuildCommands(config.clientId, config.guildId)
        : Routes.applicationCommands(config.clientId),
      { body: commands }
    );
    Logger.info("Commands deployed successfully!");
  } catch (error) {
    Logger.error("Failed to deploy commands", error);
  }
})();
