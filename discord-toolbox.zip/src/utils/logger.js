const config = require("../config/config");

class Logger {
  static info(msg) {
    console.log(`[INFO] [${new Date().toISOString()}] ${msg}`);
  }

  static warn(msg) {
    console.warn(`[WARN] [${new Date().toISOString()}] ${msg}`);
  }

  static error(msg, err = null) {
    console.error(`[ERROR] [${new Date().toISOString()}] ${msg}`, err || "");
  }

  static debug(msg) {
    console.log(`[DEBUG] [${new Date().toISOString()}] ${msg}`);
  }
}

module.exports = Logger;
