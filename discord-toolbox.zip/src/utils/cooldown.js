const config = require("../config/config");

const cooldowns = new Map();

function checkCooldown(userId, commandName) {
  const key = `${userId}-${commandName}`;
  const now = Date.now();
  const expiration = cooldowns.get(key);

  if (expiration && now < expiration) {
    const remaining = ((expiration - now) / 1000).toFixed(1);
    return { onCooldown: true, remaining };
  }

  cooldowns.set(key, now + config.cooldown);
  return { onCooldown: false, remaining: 0 };
}

function clearCooldown(userId, commandName) {
  const key = `${userId}-${commandName}`;
  cooldowns.delete(key);
}

module.exports = { checkCooldown, clearCooldown };
