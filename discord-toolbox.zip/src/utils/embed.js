const { EmbedBuilder } = require("discord.js");
const config = require("../config/config");

function createEmbed(options = {}) {
  const embed = new EmbedBuilder()
    .setColor(options.color || config.colors.primary)
    .setFooter({ text: options.footer || config.footer })
    .setTimestamp();

  if (options.title) embed.setTitle(options.title);
  if (options.description) embed.setDescription(options.description);
  if (options.fields) embed.addFields(options.fields);
  if (options.thumbnail) embed.setThumbnail(options.thumbnail);
  if (options.image) embed.setImage(options.image);
  if (options.url) embed.setURL(options.url);

  return embed;
}

function createErrorEmbed(description, errorId = null) {
  let desc = description || "❌ Terjadi kesalahan saat memproses request.";
  if (errorId) desc += "\n\n**Error ID:**\n`TBX-" + errorId + "`";
  return createEmbed({
    color: config.colors.error,
    title: "❌ Error",
    description: desc,
  });
}

function createSuccessEmbed(title, description) {
  return createEmbed({
    color: config.colors.success,
    title: title ? "✅ " + title : undefined,
    description,
  });
}

module.exports = { createEmbed, createErrorEmbed, createSuccessEmbed };
