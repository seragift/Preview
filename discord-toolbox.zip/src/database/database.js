const sqlite3 = require("sqlite3").verbose();
const path = require("path");
const config = require("../config/config");
const Logger = require("../utils/logger");

const db = new sqlite3.Database(config.dbPath, (err) => {
  if (err) {
    Logger.error("Failed to connect to SQLite database", err);
  } else {
    Logger.info("Connected to SQLite database.");
  }
});

db.serialize(() => {
  db.run(`
    CREATE TABLE IF NOT EXISTS usage_stats (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT NOT NULL,
      guild_id TEXT,
      command TEXT NOT NULL,
      created_at INTEGER NOT NULL
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS guild_settings (
      guild_id TEXT PRIMARY KEY,
      enabled INTEGER DEFAULT 1,
      log_channel_id TEXT,
      created_at INTEGER NOT NULL
    )
  `);
});

function logUsage(userId, guildId, command) {
  return new Promise((resolve, reject) => {
    const stmt = db.prepare(
      "INSERT INTO usage_stats (user_id, guild_id, command, created_at) VALUES (?, ?, ?, ?)"
    );
    stmt.run(userId, guildId || null, command, Date.now(), function (err) {
      if (err) reject(err);
      else resolve(this.lastID);
    });
    stmt.finalize();
  });
}

function getStats(userId, guildId) {
  return new Promise((resolve, reject) => {
    db.get("SELECT COUNT(*) as total FROM usage_stats", [], (err, totalRow) => {
      if (err) return reject(err);
      db.get(
        "SELECT COUNT(*) as user_total FROM usage_stats WHERE user_id = ?",
        [userId],
        (err, userRow) => {
          if (err) return reject(err);
          db.get(
            "SELECT COUNT(*) as guild_total FROM usage_stats WHERE guild_id = ?",
            [guildId],
            (err, guildRow) => {
              if (err) return reject(err);
              db.get(
                `SELECT command, COUNT(*) as cnt FROM usage_stats GROUP BY command ORDER BY cnt DESC LIMIT 1`,
                [],
                (err, mostUsedRow) => {
                  if (err) return reject(err);
                  db.get(
                    `SELECT 
                      CASE 
                        WHEN command LIKE 'image%' THEN 'image'
                        WHEN command LIKE 'text%' THEN 'text'
                        WHEN command LIKE 'developer%' THEN 'developer'
                        WHEN command LIKE 'network%' THEN 'network'
                        WHEN command LIKE 'file%' THEN 'file'
                        WHEN command LIKE 'url%' THEN 'url'
                        WHEN command LIKE 'generate%' THEN 'generate'
                        ELSE 'other'
                      END as category,
                      COUNT(*) as cnt 
                    FROM usage_stats 
                    GROUP BY category 
                    ORDER BY cnt DESC LIMIT 1`,
                    [],
                    (err, mostActiveRow) => {
                      if (err) return reject(err);
                      resolve({
                        total: totalRow.total || 0,
                        userTotal: userRow.user_total || 0,
                        guildTotal: guildRow ? (guildRow.guild_total || 0) : 0,
                        mostUsed: mostUsedRow ? mostUsedRow.command : "None",
                        mostActive: mostActiveRow ? mostActiveRow.category : "None",
                      });
                    }
                  );
                }
              );
            }
          );
        }
      );
    });
  });
}

module.exports = { db, logUsage, getStats };
