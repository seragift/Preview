const { Events } = require("discord.js");
const { checkCooldown } = require("../utils/cooldown");
const { createErrorEmbed } = require("../utils/embed");
const { generateErrorId } = require("../utils/format");
const { logUsage } = require("../database/database");
const Logger = require("../utils/logger");

module.exports = {
  name: Events.InteractionCreate,
  async execute(interaction, client) {
    if (interaction.isChatInputCommand()) {
      const command = client.commands.get(interaction.commandName);
      if (!command) return;

      const { onCooldown, remaining } = checkCooldown(
        interaction.user.id,
        interaction.commandName
      );
      if (onCooldown) {
        return interaction.reply({
          content: `⏳ Tunggu ${remaining} detik sebelum menggunakan tool ini lagi.`,
          ephemeral: true,
        });
      }

      try {
        await command.execute(interaction, client);
        await logUsage(
          interaction.user.id,
          interaction.guildId,
          interaction.commandName
        );
      } catch (error) {
        const errorId = generateErrorId();
        Logger.error(`Error executing ${interaction.commandName}: ${errorId}`, error);

        const replyOptions = {
          embeds: [createErrorEmbed(null, errorId)],
          ephemeral: true,
        };

        if (interaction.replied || interaction.deferred) {
          await interaction.followUp(replyOptions);
        } else {
          await interaction.reply(replyOptions);
        }
      }
    } else if (interaction.isStringSelectMenu() || interaction.isButton()) {
      // Handle component interactions from toolbox menu
      const command = client.commands.get("toolbox");
      if (command && command.handleComponent) {
        try {
          await command.handleComponent(interaction, client);
        } catch (error) {
          const errorId = generateErrorId();
          Logger.error(`Error handling component: ${errorId}`, error);
          if (!interaction.replied && !interaction.deferred) {
            await interaction.reply({
              embeds: [createErrorEmbed(null, errorId)],
              ephemeral: true,
            });
          }
        }
      }
    }
  },
};
