const { ActivityType } = require("discord.js");
const config = require("../config/config");
const Logger = require("../utils/logger");

module.exports = {
  name: "ready",
  once: true,
  execute(client) {
    const guildCount = client.guilds.cache.size;
    const userCount = client.guilds.cache.reduce(
      (acc, guild) => acc + guild.memberCount,
      0
    );

    client.user.setActivity("🧰 /toolbox", { type: ActivityType.Playing });

    Logger.info("━━━━━━━━━━━━━━━━━━");
    Logger.info("🧰 Discord Toolbox");
    Logger.info("━━━━━━━━━━━━━━━━━━");
    Logger.info(`Status: ONLINE`);
    Logger.info(`Commands: 40+`);
    Logger.info(`Servers: ${guildCount}`);
    Logger.info(`Users: ${userCount.toLocaleString()}`);
    Logger.info("Ready!");
  },
};
