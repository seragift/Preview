const fs = require("fs");
const path = require("path");
const { Collection } = require("discord.js");
const Logger = require("../utils/logger");

function loadCommands() {
  const commands = [];
  const commandsCollection = new Collection();
  const commandsPath = path.join(__dirname, "../commands");
  const commandFiles = fs
    .readdirSync(commandsPath)
    .filter((file) => file.endsWith(".js"));

  for (const file of commandFiles) {
    const filePath = path.join(commandsPath, file);
    const command = require(filePath);
    if ("data" in command && "execute" in command) {
      commands.push(command.data.toJSON());
      commandsCollection.set(command.data.name, command);
      Logger.info(`Loaded command: ${command.data.name}`);
    } else {
      Logger.warn(`Command at ${filePath} missing required properties.`);
    }
  }

  return { commands, commandsCollection };
}

module.exports = { loadCommands };
