const axios = require("axios");
const dns = require("dns").promises;
const { lookup } = require("dns");
const config = require("../config/config");

async function fetchStatus(url) {
  const start = Date.now();
  const response = await axios.get(url, {
    timeout: config.httpTimeout,
    maxRedirects: 5,
    validateStatus: () => true,
  });
  const time = Date.now() - start;
  return {
    status: response.status,
    statusText: response.statusText,
    time,
    contentType: response.headers["content-type"] || "Unknown",
    headers: response.headers,
  };
}

async function fetchHeaders(url) {
  const response = await axios.head(url, {
    timeout: config.httpTimeout,
    maxRedirects: 5,
    validateStatus: () => true,
  });
  return response.headers;
}

async function resolveDns(domain) {
  const [aRecords, mxRecords, txtRecords] = await Promise.all([
    dns.resolve4(domain).catch(() => []),
    dns.resolveMx(domain).catch(() => []),
    dns.resolveTxt(domain).catch(() => []),
  ]);
  return { aRecords, mxRecords, txtRecords };
}

async function pingHost(hostname) {
  return new Promise((resolve, reject) => {
    lookup(hostname, (err, address) => {
      if (err) reject(err);
      else resolve(address);
    });
  });
}

module.exports = { fetchStatus, fetchHeaders, resolveDns, pingHost };
