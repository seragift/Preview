const axios = require("axios");
const config = require("../config/config");

async function expandUrl(shortUrl) {
  const response = await axios.head(shortUrl, {
    timeout: config.httpTimeout,
    maxRedirects: 10,
    validateStatus: () => true,
  });
  // axios does not expose final URL easily in head, use get instead
  const getResponse = await axios.get(shortUrl, {
    timeout: config.httpTimeout,
    maxRedirects: 10,
    validateStatus: () => true,
  });
  return getResponse.request.res.responseUrl || shortUrl;
}

async function getUrlInfo(url) {
  const response = await axios.get(url, {
    timeout: config.httpTimeout,
    maxRedirects: 5,
    validateStatus: () => true,
  });
  return {
    finalUrl: response.request.res.responseUrl || url,
    status: response.status,
    contentType: response.headers["content-type"],
    contentLength: response.headers["content-length"],
    server: response.headers["server"],
  };
}

module.exports = { expandUrl, getUrlInfo };
