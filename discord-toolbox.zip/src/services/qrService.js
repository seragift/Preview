const QRCode = require("qrcode");
const { createCanvas } = require("canvas");
const fs = require("fs");
const path = require("path");
const { v4: uuidv4 } = require("uuid");
const config = require("../config/config");

async function generateQR(text, options = {}) {
  const id = uuidv4();
  const outputPath = path.join(config.tempDir, `${id}.png`);

  await QRCode.toFile(outputPath, text, {
    width: options.width || 512,
    margin: options.margin || 2,
    color: {
      dark: options.dark || "#000000",
      light: options.light || "#FFFFFF",
    },
  });

  return { outputPath, cleanup: () => {
    try { if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath); } catch (e) {}
  }};
}

async function generateColorCard(hexColor) {
  const canvas = createCanvas(400, 300);
  const ctx = canvas.getContext("2d");

  // Parse hex
  const r = parseInt(hexColor.slice(1, 3), 16);
  const g = parseInt(hexColor.slice(3, 5), 16);
  const b = parseInt(hexColor.slice(5, 7), 16);

  // HSL conversion
  const hsl = rgbToHsl(r, g, b);

  // Background
  ctx.fillStyle = "#1a1a2e";
  ctx.fillRect(0, 0, 400, 300);

  // Color block
  ctx.fillStyle = hexColor;
  ctx.fillRect(50, 30, 300, 120);

  // Border
  ctx.strokeStyle = "#ffffff";
  ctx.lineWidth = 2;
  ctx.strokeRect(50, 30, 300, 120);

  // Text
  ctx.fillStyle = "#ffffff";
  ctx.font = "bold 24px sans-serif";
  ctx.textAlign = "center";
  ctx.fillText(hexColor.toUpperCase(), 200, 80);

  ctx.font = "16px sans-serif";
  ctx.textAlign = "left";
  ctx.fillText(`RGB: ${r}, ${g}, ${b}`, 60, 180);
  ctx.fillText(`HSL: ${hsl.h}, ${hsl.s}%, ${hsl.l}%`, 60, 210);
  ctx.fillText(`HEX: ${hexColor.toUpperCase()}`, 60, 240);

  const id = uuidv4();
  const outputPath = path.join(config.tempDir, `${id}_color.png`);
  const buffer = canvas.toBuffer("image/png");
  fs.writeFileSync(outputPath, buffer);

  return { outputPath, cleanup: () => {
    try { if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath); } catch (e) {}
  }};
}

function rgbToHsl(r, g, b) {
  r /= 255; g /= 255; b /= 255;
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  let h, s, l = (max + min) / 2;

  if (max === min) {
    h = s = 0;
  } else {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r: h = (g - b) / d + (g < b ? 6 : 0); break;
      case g: h = (b - r) / d + 2; break;
      case b: h = (r - g) / d + 4; break;
    }
    h /= 6;
  }

  return {
    h: Math.round(h * 360),
    s: Math.round(s * 100),
    l: Math.round(l * 100),
  };
}

module.exports = { generateQR, generateColorCard };
