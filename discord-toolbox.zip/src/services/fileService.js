const fs = require("fs");
const path = require("path");
const archiver = require("archiver");
const unzipper = require("unzipper");
const crypto = require("crypto");
const { v4: uuidv4 } = require("uuid");
const config = require("../config/config");
const { sanitizeFilename } = require("../utils/format");

async function zipFiles(files) {
  const id = uuidv4();
  const outputPath = path.join(config.tempDir, `${id}.zip`);
  const output = fs.createWriteStream(outputPath);
  const archive = archiver("zip", { zlib: { level: 9 } });

  return new Promise((resolve, reject) => {
    output.on("close", () => resolve(outputPath));
    archive.on("error", (err) => reject(err));
    archive.pipe(output);

    for (const file of files) {
      const safeName = sanitizeFilename(file.name);
      archive.append(file.buffer, { name: safeName });
    }

    archive.finalize();
  });
}

async function unzipFile(buffer) {
  const id = uuidv4();
  const extractDir = path.join(config.tempDir, `${id}_extract`);
  fs.mkdirSync(extractDir, { recursive: true });

  return new Promise((resolve, reject) => {
    const entries = [];
    let totalSize = 0;

    const stream = require("stream");
    const readable = new stream.PassThrough();
    readable.end(buffer);

    readable
      .pipe(unzipper.Parse())
      .on("entry", function (entry) {
        const fileName = entry.path;
        const type = entry.type;

        if (type === "Directory") {
          entry.autodrain();
          return;
        }

        // Path traversal protection
        const fullPath = path.join(extractDir, fileName);
        const resolvedPath = path.resolve(fullPath);
        const resolvedExtractDir = path.resolve(extractDir);
        if (!resolvedPath.startsWith(resolvedExtractDir)) {
          entry.autodrain();
          return;
        }

        if (entries.length >= config.maxFilesInZip) {
          entry.autodrain();
          return;
        }

        const chunks = [];
        entry.on("data", (chunk) => {
          totalSize += chunk.length;
          if (totalSize > config.maxExtractSize) {
            entry.autodrain();
            return;
          }
          chunks.push(chunk);
        });
        entry.on("end", () => {
          const fileBuffer = Buffer.concat(chunks);
          const outPath = path.join(extractDir, sanitizeFilename(fileName));
          fs.mkdirSync(path.dirname(outPath), { recursive: true });
          fs.writeFileSync(outPath, fileBuffer);
          entries.push({ name: fileName, size: fileBuffer.length });
        });
      })
      .on("close", () => resolve({ extractDir, entries }))
      .on("error", reject);
  });
}

function hashFile(buffer, algorithm = "sha256") {
  return crypto.createHash(algorithm).update(buffer).digest("hex");
}

function cleanupFile(filePath) {
  try {
    if (fs.existsSync(filePath)) {
      const stat = fs.statSync(filePath);
      if (stat.isDirectory()) {
        fs.rmSync(filePath, { recursive: true, force: true });
      } else {
        fs.unlinkSync(filePath);
      }
    }
  } catch (e) {}
}

module.exports = { zipFiles, unzipFile, hashFile, cleanupFile };
