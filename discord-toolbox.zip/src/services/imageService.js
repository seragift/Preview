const sharp = require("sharp");
const path = require("path");
const fs = require("fs");
const { v4: uuidv4 } = require("uuid");
const config = require("../config/config");
const { sanitizeFilename } = require("../utils/format");

async function processImage(buffer, operation, options = {}) {
  const id = uuidv4();
  const inputPath = path.join(config.tempDir, `${id}_input`);
  const outputPath = path.join(config.tempDir, `${id}_output`);

  fs.writeFileSync(inputPath, buffer);

  let pipeline = sharp(inputPath);

  switch (operation) {
    case "resize": {
      const width = parseInt(options.width) || null;
      const height = parseInt(options.height) || null;
      if (!width && !height) throw new Error("Width or height required");
      pipeline = pipeline.resize(width, height, { fit: "inside" });
      break;
    }
    case "compress": {
      pipeline = pipeline.jpeg({ quality: options.quality || 70 });
      break;
    }
    case "convert": {
      const format = options.format || "png";
      if (format === "jpeg" || format === "jpg") pipeline = pipeline.jpeg();
      else if (format === "png") pipeline = pipeline.png();
      else if (format === "webp") pipeline = pipeline.webp();
      else if (format === "gif") pipeline = pipeline.gif();
      else throw new Error("Unsupported format");
      break;
    }
    case "rotate": {
      const angle = parseInt(options.angle) || 90;
      pipeline = pipeline.rotate(angle);
      break;
    }
    case "blur": {
      const sigma = parseFloat(options.sigma) || 5;
      pipeline = pipeline.blur(sigma);
      break;
    }
    case "pixelate": {
      const size = parseInt(options.size) || 10;
      const meta = await sharp(inputPath).metadata();
      pipeline = sharp(inputPath)
        .resize(Math.max(1, Math.floor(meta.width / size)), null, { kernel: "nearest" })
        .resize(meta.width, null, { kernel: "nearest" });
      break;
    }
    case "info": {
      const meta = await sharp(inputPath).metadata();
      cleanup(inputPath);
      return { info: meta };
    }
    default:
      cleanup(inputPath);
      throw new Error("Unknown operation");
  }

  await pipeline.toFile(outputPath);
  cleanup(inputPath);

  return { outputPath, cleanup: () => cleanup(outputPath) };
}

function cleanup(filePath) {
  try {
    if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
  } catch (e) {}
}

module.exports = { processImage, cleanup };
