const { SlashCommandBuilder, AttachmentBuilder } = require("discord.js");
const { createEmbed, createErrorEmbed, createSuccessEmbed } = require("../utils/embed");
const { generateQR } = require("../services/qrService");
const { generateErrorId } = require("../utils/format");
const crypto = require("crypto");
const { v4: uuidv4 } = require("uuid");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("generate")
    .setDescription("🔐 Generator tools")
    .addSubcommand((sub) =>
      sub
        .setName("password")
        .setDescription("Generate secure password")
        .addIntegerOption((opt) => opt.setName("length").setDescription("Password length").setRequired(false))
    )
    .addSubcommand((sub) =>
      sub
        .setName("uuid")
        .setDescription("Generate UUID v4")
    )
    .addSubcommand((sub) =>
      sub
        .setName("hash")
        .setDescription("Generate hash from text")
        .addStringOption((opt) => opt.setName("text").setDescription("Text").setRequired(true))
        .addStringOption((opt) =>
          opt
            .setName("algorithm")
            .setDescription("Algorithm")
            .setRequired(false)
            .addChoices(
              { name: "MD5", value: "md5" },
              { name: "SHA1", value: "sha1" },
              { name: "SHA256", value: "sha256" },
              { name: "SHA512", value: "sha512" }
            )
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName("qr")
        .setDescription("Generate QR code")
        .addStringOption((opt) => opt.setName("text").setDescription("Text/URL").setRequired(true))
    )
    .addSubcommand((sub) =>
      sub
        .setName("timestamp")
        .setDescription("Generate current timestamp")
    ),

  async execute(interaction) {
    await interaction.deferReply();
    const sub = interaction.options.getSubcommand();

    try {
      let embed;

      if (sub === "password") {
        const length = interaction.options.getInteger("length") || 16;
        const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+-=[]{}|;:,.<>?";
        let password = "";
        const randomBytes = crypto.randomBytes(length);
        for (let i = 0; i < length; i++) {
          password += charset[randomBytes[i] % charset.length];
        }
        embed = createSuccessEmbed("Password Generated", "```\n" + password + "\n```");
      } else if (sub === "uuid") {
        const id = uuidv4();
        embed = createSuccessEmbed("UUID Generated", "```\n" + id + "\n```");
      } else if (sub === "hash") {
        const text = interaction.options.getString("text");
        const algo = interaction.options.getString("algorithm") || "sha256";
        const hash = crypto.createHash(algo).update(text).digest("hex");
        embed = createSuccessEmbed("Hash Generated", `**Algorithm:** ${algo.toUpperCase()}\n\`\`\`\n${hash}\n\`\`\``);
      } else if (sub === "qr") {
        const text = interaction.options.getString("text");
        const result = await generateQR(text);
        const attachment = new AttachmentBuilder(result.outputPath, { name: "qrcode.png" });
        embed = createSuccessEmbed("QR Code Generated", `"${text}"`);
        await interaction.editReply({ embeds: [embed], files: [attachment] });
        result.cleanup();
        return;
      } else if (sub === "timestamp") {
        const now = new Date();
        embed = createEmbed({
          title: "⏰ Timestamp",
          fields: [
            { name: "ISO", value: now.toISOString(), inline: false },
            { name: "Unix (s)", value: String(Math.floor(now.getTime() / 1000)), inline: true },
            { name: "Unix (ms)", value: String(now.getTime()), inline: true },
          ],
        });
      }

      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      const errorId = generateErrorId();
      await interaction.editReply({ embeds: [createErrorEmbed(null, errorId)] });
      throw error;
    }
  },
};
