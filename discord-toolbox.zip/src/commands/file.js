const { SlashCommandBuilder, AttachmentBuilder } = require("discord.js");
const { createEmbed, createErrorEmbed, createSuccessEmbed } = require("../utils/embed");
const { zipFiles, unzipFile, hashFile, cleanupFile } = require("../services/fileService");
const { formatBytes, generateErrorId, sanitizeFilename } = require("../utils/format");
const config = require("../config/config");
const path = require("path");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("file")
    .setDescription("📦 File tools")
    .addSubcommand((sub) =>
      sub
        .setName("info")
        .setDescription("Get file info")
        .addAttachmentOption((opt) => opt.setName("file").setDescription("File").setRequired(true))
    )
    .addSubcommand((sub) =>
      sub
        .setName("hash")
        .setDescription("Hash a file")
        .addAttachmentOption((opt) => opt.setName("file").setDescription("File").setRequired(true))
        .addStringOption((opt) =>
          opt
            .setName("algorithm")
            .setDescription("Hash algorithm")
            .setRequired(false)
            .addChoices(
              { name: "MD5", value: "md5" },
              { name: "SHA1", value: "sha1" },
              { name: "SHA256", value: "sha256" },
              { name: "SHA512", value: "sha512" }
            )
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName("zip")
        .setDescription("Zip files")
        .addAttachmentOption((opt) => opt.setName("file1").setDescription("File 1").setRequired(true))
        .addAttachmentOption((opt) => opt.setName("file2").setDescription("File 2").setRequired(false))
        .addAttachmentOption((opt) => opt.setName("file3").setDescription("File 3").setRequired(false))
    )
    .addSubcommand((sub) =>
      sub
        .setName("unzip")
        .setDescription("Unzip a file")
        .addAttachmentOption((opt) => opt.setName("file").setDescription("ZIP file").setRequired(true))
    ),

  async execute(interaction) {
    await interaction.deferReply();
    const sub = interaction.options.getSubcommand();

    try {
      if (sub === "info") {
        const attachment = interaction.options.getAttachment("file");
        const embed = createEmbed({
          title: "📦 FILE INFO",
          fields: [
            { name: "Name", value: attachment.name, inline: true },
            { name: "Size", value: formatBytes(attachment.size), inline: true },
            { name: "Type", value: attachment.contentType || "Unknown", inline: true },
            { name: "URL", value: attachment.url, inline: false },
          ],
        });
        await interaction.editReply({ embeds: [embed] });
      } else if (sub === "hash") {
        const attachment = interaction.options.getAttachment("file");
        if (attachment.size > config.maxFileSize) {
          return interaction.editReply({ embeds: [createErrorEmbed("File too large")] });
        }
        const algo = interaction.options.getString("algorithm") || "sha256";
        const response = await fetch(attachment.url);
        const buffer = Buffer.from(await response.arrayBuffer());
        const hash = hashFile(buffer, algo);
        const embed = createSuccessEmbed("File Hash", `**Algorithm:** ${algo.toUpperCase()}\n\`\`\`\n${hash}\n\`\`\``);
        await interaction.editReply({ embeds: [embed] });
      } else if (sub === "zip") {
        const files = [];
        for (let i = 1; i <= 3; i++) {
          const att = interaction.options.getAttachment(`file${i}`);
          if (att) {
            if (att.size > config.maxFileSize) {
              return interaction.editReply({ embeds: [createErrorEmbed(`${att.name} too large`)] });
            }
            const res = await fetch(att.url);
            const buf = Buffer.from(await res.arrayBuffer());
            files.push({ name: att.name, buffer: buf });
          }
        }
        if (files.length === 0) return interaction.editReply({ embeds: [createErrorEmbed("No files provided")] });
        const zipPath = await zipFiles(files);
        const attachment = new AttachmentBuilder(zipPath, { name: "archive.zip" });
        const embed = createSuccessEmbed("Zipped", `Archived **${files.length}** file(s)`);
        await interaction.editReply({ embeds: [embed], files: [attachment] });
        cleanupFile(zipPath);
      } else if (sub === "unzip") {
        const attachment = interaction.options.getAttachment("file");
        if (attachment.size > config.maxFileSize) {
          return interaction.editReply({ embeds: [createErrorEmbed("File too large")] });
        }
        const response = await fetch(attachment.url);
        const buffer = Buffer.from(await response.arrayBuffer());
        const { extractDir, entries } = await unzipFile(buffer);
        const embed = createEmbed({
          title: "📦 UNZIPPED",
          description: entries.map(e => `• ${sanitizeFilename(e.name)} (${formatBytes(e.size)})`).join("\n").slice(0, 4000),
        });
        const filesToSend = entries
          .slice(0, 10)
          .map((e) => new AttachmentBuilder(path.join(extractDir, sanitizeFilename(e.name)), { name: sanitizeFilename(e.name) }));
        await interaction.editReply({ embeds: [embed], files: filesToSend });
        cleanupFile(extractDir);
      }
    } catch (error) {
      const errorId = generateErrorId();
      await interaction.editReply({ embeds: [createErrorEmbed(null, errorId)] });
      throw error;
    }
  },
};
