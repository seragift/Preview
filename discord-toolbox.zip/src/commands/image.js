const { SlashCommandBuilder, AttachmentBuilder } = require("discord.js");
const { createEmbed, createErrorEmbed, createSuccessEmbed } = require("../utils/embed");
const { processImage, cleanup } = require("../services/imageService");
const { generateQR } = require("../services/qrService");
const { formatBytes, generateErrorId } = require("../utils/format");
const config = require("../config/config");
const fs = require("fs");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("image")
    .setDescription("🖼️ Image processing tools")
    .addSubcommand((sub) =>
      sub
        .setName("resize")
        .setDescription("Resize an image")
        .addAttachmentOption((opt) =>
          opt.setName("image").setDescription("Image to resize").setRequired(true)
        )
        .addIntegerOption((opt) =>
          opt.setName("width").setDescription("Target width").setRequired(false)
        )
        .addIntegerOption((opt) =>
          opt.setName("height").setDescription("Target height").setRequired(false)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName("compress")
        .setDescription("Compress an image")
        .addAttachmentOption((opt) =>
          opt.setName("image").setDescription("Image to compress").setRequired(true)
        )
        .addIntegerOption((opt) =>
          opt.setName("quality").setDescription("JPEG quality (1-100)").setRequired(false)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName("convert")
        .setDescription("Convert image format")
        .addAttachmentOption((opt) =>
          opt.setName("image").setDescription("Image to convert").setRequired(true)
        )
        .addStringOption((opt) =>
          opt
            .setName("format")
            .setDescription("Target format")
            .setRequired(true)
            .addChoices(
              { name: "PNG", value: "png" },
              { name: "JPEG", value: "jpeg" },
              { name: "WEBP", value: "webp" }
            )
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName("rotate")
        .setDescription("Rotate an image")
        .addAttachmentOption((opt) =>
          opt.setName("image").setDescription("Image to rotate").setRequired(true)
        )
        .addIntegerOption((opt) =>
          opt
            .setName("angle")
            .setDescription("Rotation angle")
            .setRequired(true)
            .addChoices(
              { name: "90°", value: 90 },
              { name: "180°", value: 180 },
              { name: "270°", value: 270 }
            )
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName("info")
        .setDescription("Get image info")
        .addAttachmentOption((opt) =>
          opt.setName("image").setDescription("Image to analyze").setRequired(true)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName("blur")
        .setDescription("Blur an image")
        .addAttachmentOption((opt) =>
          opt.setName("image").setDescription("Image to blur").setRequired(true)
        )
        .addNumberOption((opt) =>
          opt.setName("sigma").setDescription("Blur intensity").setRequired(false)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName("pixelate")
        .setDescription("Pixelate an image")
        .addAttachmentOption((opt) =>
          opt.setName("image").setDescription("Image to pixelate").setRequired(true)
        )
        .addIntegerOption((opt) =>
          opt.setName("size").setDescription("Pixel size").setRequired(false)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName("qr")
        .setDescription("Generate QR code")
        .addStringOption((opt) =>
          opt.setName("text").setDescription("Text or URL for QR").setRequired(true)
        )
        .addIntegerOption((opt) =>
          opt.setName("width").setDescription("QR width").setRequired(false)
        )
    ),

  async execute(interaction) {
    await interaction.deferReply();
    const sub = interaction.options.getSubcommand();

    try {
      if (sub === "qr") {
        const text = interaction.options.getString("text");
        const width = interaction.options.getInteger("width") || 512;
        const result = await generateQR(text, { width });
        const attachment = new AttachmentBuilder(result.outputPath, { name: "qrcode.png" });
        const embed = createSuccessEmbed("QR Code Generated", `"${text}"`);
        await interaction.editReply({ embeds: [embed], files: [attachment] });
        result.cleanup();
        return;
      }

      const attachment = interaction.options.getAttachment("image");
      if (!attachment) {
        return interaction.editReply({ embeds: [createErrorEmbed("No image provided.")] });
      }
      if (attachment.size > config.maxFileSize) {
        return interaction.editReply({
          embeds: [createErrorEmbed(`File too large. Max ${formatBytes(config.maxFileSize)}`)],
        });
      }

      const response = await fetch(attachment.url);
      if (!response.ok) throw new Error("Failed to download image");
      const buffer = Buffer.from(await response.arrayBuffer());

      if (sub === "info") {
        const result = await processImage(buffer, "info");
        const meta = result.info;
        const embed = createEmbed({
          title: "🖼️ IMAGE INFO",
          fields: [
            { name: "Format", value: meta.format || "Unknown", inline: true },
            { name: "Width", value: String(meta.width || "?"), inline: true },
            { name: "Height", value: String(meta.height || "?"), inline: true },
            { name: "Channels", value: String(meta.channels || "?"), inline: true },
            { name: "Size", value: formatBytes(attachment.size), inline: true },
            { name: "Density", value: String(meta.density || "?"), inline: true },
          ],
        });
        await interaction.editReply({ embeds: [embed] });
        return;
      }

      const options = {};
      if (sub === "resize") {
        options.width = interaction.options.getInteger("width");
        options.height = interaction.options.getInteger("height");
      } else if (sub === "compress") {
        options.quality = interaction.options.getInteger("quality") || 70;
      } else if (sub === "convert") {
        options.format = interaction.options.getString("format");
      } else if (sub === "rotate") {
        options.angle = interaction.options.getInteger("angle");
      } else if (sub === "blur") {
        options.sigma = interaction.options.getNumber("sigma") || 5;
      } else if (sub === "pixelate") {
        options.size = interaction.options.getInteger("size") || 10;
      }

      const result = await processImage(buffer, sub, options);
      const outAttachment = new AttachmentBuilder(result.outputPath, {
        name: `processed_${attachment.name}`,
      });
      const embed = createSuccessEmbed(
        "Image Processed",
        `Operation: **${sub}**`
      );
      await interaction.editReply({ embeds: [embed], files: [outAttachment] });
      result.cleanup();
    } catch (error) {
      const errorId = generateErrorId();
      await interaction.editReply({
        embeds: [createErrorEmbed(null, errorId)],
      });
      throw error;
    }
  },
};
