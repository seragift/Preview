const {
  SlashCommandBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require("discord.js");
const { createEmbed } = require("../utils/embed");
const config = require("../config/config");

const categories = {
  image: {
    emoji: "🖼️",
    label: "Image",
    description: "Resize, compress, convert, rotate, blur, pixelate, QR",
    color: config.colors.primary,
  },
  text: {
    emoji: "📄",
    label: "Text",
    description: "Uppercase, lowercase, reverse, count, sort, random",
    color: config.colors.secondary,
  },
  developer: {
    emoji: "👨‍💻",
    label: "Developer",
    description: "JSON, Base64, JWT, regex, timestamp, color, hash",
    color: config.colors.accent,
  },
  network: {
    emoji: "🌐",
    label: "Network",
    description: "DNS, IP, domain, SSL, headers, status, ping",
    color: config.colors.primary,
  },
  file: {
    emoji: "📦",
    label: "File",
    description: "Info, hash, zip, unzip",
    color: config.colors.secondary,
  },
  url: {
    emoji: "🔗",
    label: "URL",
    description: "Encode, decode, info, expand, shorten",
    color: config.colors.accent,
  },
  generate: {
    emoji: "🔐",
    label: "Generator",
    description: "Password, UUID, hash, QR, timestamp",
    color: config.colors.primary,
  },
};

function buildMainMenu() {
  const embed = createEmbed({
    title: "🧰 DISCORD TOOLBOX",
    description:
      "Semua tools yang kamu butuhkan langsung di Discord.\n\n" +
      Object.entries(categories)
        .map(([key, cat]) => `${cat.emoji} **${cat.label}**`)
        .join("\n"),
    color: config.colors.primary,
  });

  const select = new StringSelectMenuBuilder()
    .setCustomId("toolbox_category")
    .setPlaceholder("Pilih Kategori")
    .addOptions(
      Object.entries(categories).map(([key, cat]) =>
        new StringSelectMenuOptionBuilder()
          .setLabel(cat.label)
          .setValue(key)
          .setDescription(cat.description)
          .setEmoji(cat.emoji)
      )
    );

  const row = new ActionRowBuilder().addComponents(select);

  const closeBtn = new ButtonBuilder()
    .setCustomId("toolbox_close")
    .setLabel("❌ Close")
    .setStyle(ButtonStyle.Danger);

  const btnRow = new ActionRowBuilder().addComponents(closeBtn);

  return { embeds: [embed], components: [row, btnRow] };
}

function buildCategoryMenu(categoryKey) {
  const cat = categories[categoryKey];
  if (!cat) return buildMainMenu();

  const commandMap = {
    image: [
      "/image resize",
      "/image compress",
      "/image convert",
      "/image rotate",
      "/image info",
      "/image blur",
      "/image pixelate",
      "/image qr",
    ],
    text: [
      "/text uppercase",
      "/text lowercase",
      "/text reverse",
      "/text count",
      "/text remove-space",
      "/text remove-duplicate",
      "/text sort",
      "/text random",
    ],
    developer: [
      "/developer json-format",
      "/developer json-minify",
      "/developer base64-encode",
      "/developer base64-decode",
      "/developer jwt-decode",
      "/developer regex",
      "/developer timestamp",
      "/developer color",
      "/developer hash",
    ],
    network: [
      "/network dns",
      "/network ip",
      "/network domain",
      "/network ssl",
      "/network headers",
      "/network status",
      "/network ping",
    ],
    file: [
      "/file info",
      "/file hash",
      "/file zip",
      "/file unzip",
    ],
    url: [
      "/url encode",
      "/url decode",
      "/url info",
      "/url expand",
      "/url shorten",
    ],
    generate: [
      "/generate password",
      "/generate uuid",
      "/generate hash",
      "/generate qr",
      "/generate timestamp",
    ],
  };

  const commands = commandMap[categoryKey] || [];

  const embed = createEmbed({
    title: `${cat.emoji} ${cat.label.toUpperCase()} TOOLS`,
    description:
      commands.map((cmd) => "• `" + cmd + "`").join("\n") +
      "\n\nPilih command di atas untuk menggunakannya.",
    color: cat.color,
  });

  const backBtn = new ButtonBuilder()
    .setCustomId("toolbox_back")
    .setLabel("◀️ Back")
    .setStyle(ButtonStyle.Secondary);

  const homeBtn = new ButtonBuilder()
    .setCustomId("toolbox_home")
    .setLabel("🏠 Home")
    .setStyle(ButtonStyle.Primary);

  const closeBtn = new ButtonBuilder()
    .setCustomId("toolbox_close")
    .setLabel("❌ Close")
    .setStyle(ButtonStyle.Danger);

  const row = new ActionRowBuilder().addComponents(backBtn, homeBtn, closeBtn);

  return { embeds: [embed], components: [row] };
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName("toolbox")
    .setDescription("🧰 Buka dashboard Discord Toolbox"),

  async execute(interaction) {
    await interaction.reply({ ...buildMainMenu(), ephemeral: true });
  },

  async handleComponent(interaction) {
    if (interaction.isStringSelectMenu() && interaction.customId === "toolbox_category") {
      const category = interaction.values[0];
      await interaction.update(buildCategoryMenu(category));
    } else if (interaction.isButton()) {
      if (interaction.customId === "toolbox_back") {
        await interaction.update(buildMainMenu());
      } else if (interaction.customId === "toolbox_home") {
        await interaction.update(buildMainMenu());
      } else if (interaction.customId === "toolbox_close") {
        await interaction.deleteReply();
      }
    }
  },
};
