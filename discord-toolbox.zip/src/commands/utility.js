const { SlashCommandBuilder } = require("discord.js");
const { createEmbed, createErrorEmbed } = require("../utils/embed");
const { getStats } = require("../database/database");
const { formatNumber, generateErrorId } = require("../utils/format");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("utility")
    .setDescription("⚙️ Utility commands")
    .addSubcommand((sub) =>
      sub
        .setName("stats")
        .setDescription("Show toolbox statistics")
    ),

  async execute(interaction) {
    await interaction.deferReply();
    const sub = interaction.options.getSubcommand();

    try {
      if (sub === "stats") {
        const stats = await getStats(interaction.user.id, interaction.guildId);
        const categoryEmojis = {
          image: "🖼️",
          text: "📄",
          developer: "👨‍💻",
          network: "🌐",
          file: "📦",
          url: "🔗",
          generate: "🔐",
          other: "⚙️",
        };
        const mostUsedFormatted = stats.mostUsed
          .split("-")
          .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
          .join(" ");

        const embed = createEmbed({
          title: "📊 TOOLBOX STATISTICS",
          fields: [
            { name: "Total Usage", value: formatNumber(stats.total), inline: true },
            { name: "Your Usage", value: formatNumber(stats.userTotal), inline: true },
            { name: "Server Usage", value: formatNumber(stats.guildTotal), inline: true },
            { name: "Most Used Tool", value: mostUsedFormatted, inline: true },
            { name: "Most Active Category", value: `${categoryEmojis[stats.mostActive] || "⚙️"} ${stats.mostActive.charAt(0).toUpperCase() + stats.mostActive.slice(1)}`, inline: true },
          ],
        });

        await interaction.editReply({ embeds: [embed] });
      }
    } catch (error) {
      const errorId = generateErrorId();
      await interaction.editReply({ embeds: [createErrorEmbed(null, errorId)] });
      throw error;
    }
  },
};
