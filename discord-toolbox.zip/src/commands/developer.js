const { SlashCommandBuilder, AttachmentBuilder } = require("discord.js");
const { createEmbed, createErrorEmbed, createSuccessEmbed } = require("../utils/embed");
const { generateColorCard } = require("../services/qrService");
const { generateErrorId } = require("../utils/format");
const config = require("../config/config");
const crypto = require("crypto");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("developer")
    .setDescription("👨‍💻 Developer tools")
    .addSubcommand((sub) =>
      sub
        .setName("json-format")
        .setDescription("Format JSON")
        .addStringOption((opt) =>
          opt.setName("json").setDescription("JSON string").setRequired(true)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName("json-minify")
        .setDescription("Minify JSON")
        .addStringOption((opt) =>
          opt.setName("json").setDescription("JSON string").setRequired(true)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName("base64-encode")
        .setDescription("Base64 encode")
        .addStringOption((opt) =>
          opt.setName("text").setDescription("Text to encode").setRequired(true)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName("base64-decode")
        .setDescription("Base64 decode")
        .addStringOption((opt) =>
          opt.setName("text").setDescription("Base64 string").setRequired(true)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName("jwt-decode")
        .setDescription("Decode JWT payload (no verification)")
        .addStringOption((opt) =>
          opt.setName("token").setDescription("JWT token").setRequired(true)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName("regex")
        .setDescription("Test regex")
        .addStringOption((opt) =>
          opt.setName("pattern").setDescription("Regex pattern").setRequired(true)
        )
        .addStringOption((opt) =>
          opt.setName("text").setDescription("Text to test").setRequired(true)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName("timestamp")
        .setDescription("Convert timestamp")
        .addStringOption((opt) =>
          opt.setName("input").setDescription("Unix timestamp or ISO date").setRequired(true)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName("color")
        .setDescription("Generate color card")
        .addStringOption((opt) =>
          opt.setName("hex").setDescription("Hex color (e.g. #00D4FF)").setRequired(true)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName("hash")
        .setDescription("Generate hash")
        .addStringOption((opt) =>
          opt.setName("text").setDescription("Text to hash").setRequired(true)
        )
        .addStringOption((opt) =>
          opt
            .setName("algorithm")
            .setDescription("Hash algorithm")
            .setRequired(false)
            .addChoices(
              { name: "MD5", value: "md5" },
              { name: "SHA1", value: "sha1" },
              { name: "SHA256", value: "sha256" },
              { name: "SHA512", value: "sha512" }
            )
        )
    ),

  async execute(interaction) {
    await interaction.deferReply();
    const sub = interaction.options.getSubcommand();

    try {
      if (sub === "color") {
        let hex = interaction.options.getString("hex");
        hex = hex.trim();
        if (!hex.startsWith("#")) hex = "#" + hex;
        if (!/^#[0-9A-Fa-f]{6}$/.test(hex)) {
          return interaction.editReply({
            embeds: [createErrorEmbed("Invalid hex color format. Use #RRGGBB")],
          });
        }
        const result = await generateColorCard(hex);
        const attachment = new AttachmentBuilder(result.outputPath, { name: "color.png" });
        const embed = createSuccessEmbed("Color Card", hex.toUpperCase());
        await interaction.editReply({ embeds: [embed], files: [attachment] });
        result.cleanup();
        return;
      }

      let output = "";
      let embed;

      switch (sub) {
        case "json-format": {
          const jsonStr = interaction.options.getString("json");
          const obj = JSON.parse(jsonStr);
          output = JSON.stringify(obj, null, 2);
          embed = createSuccessEmbed("Formatted JSON", "```json\\n" + output.slice(0, 4000) + "\\n```");
          break;
        }
        case "json-minify": {
          const jsonStr = interaction.options.getString("json");
          const obj = JSON.parse(jsonStr);
          output = JSON.stringify(obj);
          embed = createSuccessEmbed("Minified JSON", "```json\\n" + output.slice(0, 4000) + "\\n```");
          break;
        }
        case "base64-encode": {
          const text = interaction.options.getString("text");
          output = Buffer.from(text).toString("base64");
          embed = createSuccessEmbed("Base64 Encoded", "```\\n" + output + "\\n```");
          break;
        }
        case "base64-decode": {
          const text = interaction.options.getString("text");
          output = Buffer.from(text, "base64").toString("utf-8");
          embed = createSuccessEmbed("Base64 Decoded", "```\\n" + output.slice(0, 4000) + "\\n```");
          break;
        }
        case "jwt-decode": {
          const token = interaction.options.getString("token");
          const parts = token.split(".");
          if (parts.length !== 3) {
            return interaction.editReply({
              embeds: [createErrorEmbed("Invalid JWT format")],
            });
          }
          const payload = JSON.parse(Buffer.from(parts[1], "base64url").toString());
          output = JSON.stringify(payload, null, 2);
          embed = createEmbed({
            title: "🔓 JWT Payload",
            description:
              "⚠️ JWT decoder hanya membaca payload.\\nJangan kirim JWT sensitif ke bot.\\n\\n```json\\n" +
              output.slice(0, 4000) +
              "\\n```",
            color: config.colors.warning,
          });
          break;
        }
        case "regex": {
          const pattern = interaction.options.getString("pattern");
          const text = interaction.options.getString("text");
          const regex = new RegExp(pattern, "g");
          const matches = text.match(regex);
          embed = createEmbed({
            title: "🔍 Regex Test",
            fields: [
              { name: "Pattern", value: "`" + pattern + "`", inline: false },
              { name: "Matches", value: matches ? matches.join("\\n").slice(0, 1000) : "No matches", inline: false },
              { name: "Match Count", value: String(matches ? matches.length : 0), inline: true },
            ],
          });
          break;
        }
        case "timestamp": {
          const input = interaction.options.getString("input");
          let date;
          if (/^\\d+$/.test(input)) {
            const ts = parseInt(input);
            date = new Date(ts.toString().length > 10 ? ts : ts * 1000);
          } else {
            date = new Date(input);
          }
          if (isNaN(date.getTime())) {
            return interaction.editReply({
              embeds: [createErrorEmbed("Invalid timestamp or date")],
            });
          }
          embed = createEmbed({
            title: "⏰ Timestamp",
            fields: [
              { name: "ISO", value: date.toISOString(), inline: false },
              { name: "Local", value: date.toString(), inline: false },
              { name: "Unix (s)", value: String(Math.floor(date.getTime() / 1000)), inline: true },
              { name: "Unix (ms)", value: String(date.getTime()), inline: true },
            ],
          });
          break;
        }
        case "hash": {
          const text = interaction.options.getString("text");
          const algo = interaction.options.getString("algorithm") || "sha256";
          output = crypto.createHash(algo).update(text).digest("hex");
          embed = createSuccessEmbed("Hash Generated", `**Algorithm:** ${algo.toUpperCase()}\\n\`\`\`\\n${output}\\n\`\`\``);
          break;
        }
      }

      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      const errorId = generateErrorId();
      await interaction.editReply({ embeds: [createErrorEmbed(null, errorId)] });
      throw error;
    }
  },
};
