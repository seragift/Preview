const { SlashCommandBuilder } = require("discord.js");
const { createEmbed, createErrorEmbed, createSuccessEmbed } = require("../utils/embed");
const { generateErrorId } = require("../utils/format");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("text")
    .setDescription("📄 Text processing tools")
    .addSubcommand((sub) =>
      sub
        .setName("uppercase")
        .setDescription("Convert text to uppercase")
        .addStringOption((opt) =>
          opt.setName("text").setDescription("Text to convert").setRequired(true)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName("lowercase")
        .setDescription("Convert text to lowercase")
        .addStringOption((opt) =>
          opt.setName("text").setDescription("Text to convert").setRequired(true)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName("reverse")
        .setDescription("Reverse text")
        .addStringOption((opt) =>
          opt.setName("text").setDescription("Text to reverse").setRequired(true)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName("count")
        .setDescription("Count characters, words, and lines")
        .addStringOption((opt) =>
          opt.setName("text").setDescription("Text to analyze").setRequired(true)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName("remove-space")
        .setDescription("Remove all spaces")
        .addStringOption((opt) =>
          opt.setName("text").setDescription("Text to process").setRequired(true)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName("remove-duplicate")
        .setDescription("Remove duplicate lines")
        .addStringOption((opt) =>
          opt.setName("text").setDescription("Text to process").setRequired(true)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName("sort")
        .setDescription("Sort lines alphabetically")
        .addStringOption((opt) =>
          opt.setName("text").setDescription("Text to sort").setRequired(true)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName("random")
        .setDescription("Shuffle/randomize lines")
        .addStringOption((opt) =>
          opt.setName("text").setDescription("Text to shuffle").setRequired(true)
        )
    ),

  async execute(interaction) {
    await interaction.deferReply();
    const sub = interaction.options.getSubcommand();
    const text = interaction.options.getString("text");

    try {
      let result = "";
      let embed;

      switch (sub) {
        case "uppercase":
          result = text.toUpperCase();
          embed = createSuccessEmbed("Uppercase", "```\\n" + result + "\\n```");
          break;
        case "lowercase":
          result = text.toLowerCase();
          embed = createSuccessEmbed("Lowercase", "```\\n" + result + "\\n```");
          break;
        case "reverse":
          result = text.split("").reverse().join("");
          embed = createSuccessEmbed("Reversed", "```\\n" + result + "\\n```");
          break;
        case "count": {
          const chars = text.length;
          const charsNoSpace = text.replace(/\\s/g, "").length;
          const words = text.trim() ? text.trim().split(/\\s+/).length : 0;
          const lines = text.split("\\n").length;
          embed = createEmbed({
            title: "📝 TEXT STATISTICS",
            fields: [
              { name: "Characters", value: String(chars), inline: true },
              { name: "Characters without spaces", value: String(charsNoSpace), inline: true },
              { name: "Words", value: String(words), inline: true },
              { name: "Lines", value: String(lines), inline: true },
            ],
          });
          break;
        }
        case "remove-space":
          result = text.replace(/\\s/g, "");
          embed = createSuccessEmbed("Spaces Removed", "```\\n" + result + "\\n```");
          break;
        case "remove-duplicate": {
          const lines = text.split("\\n");
          const unique = [...new Set(lines)];
          result = unique.join("\\n");
          embed = createSuccessEmbed(
            "Duplicates Removed",
            "```\\n" + result + "\\n```"
          );
          break;
        }
        case "sort": {
          const sorted = text.split("\\n").sort((a, b) => a.localeCompare(b));
          result = sorted.join("\\n");
          embed = createSuccessEmbed("Sorted", "```\\n" + result + "\\n```");
          break;
        }
        case "random": {
          const arr = text.split("\\n");
          for (let i = arr.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [arr[i], arr[j]] = [arr[j], arr[i]];
          }
          result = arr.join("\\n");
          embed = createSuccessEmbed("Shuffled", "```\\n" + result + "\\n```");
          break;
        }
      }

      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      const errorId = generateErrorId();
      await interaction.editReply({ embeds: [createErrorEmbed(null, errorId)] });
      throw error;
    }
  },
};
