const { SlashCommandBuilder } = require("discord.js");
const { createEmbed, createErrorEmbed, createSuccessEmbed } = require("../utils/embed");
const { expandUrl, getUrlInfo } = require("../services/urlService");
const { isValidHttpUrl, generateErrorId } = require("../utils/format");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("url")
    .setDescription("🔗 URL tools")
    .addSubcommand((sub) =>
      sub
        .setName("encode")
        .setDescription("URL encode")
        .addStringOption((opt) => opt.setName("text").setDescription("Text to encode").setRequired(true))
    )
    .addSubcommand((sub) =>
      sub
        .setName("decode")
        .setDescription("URL decode")
        .addStringOption((opt) => opt.setName("text").setDescription("Text to decode").setRequired(true))
    )
    .addSubcommand((sub) =>
      sub
        .setName("info")
        .setDescription("Get URL info")
        .addStringOption((opt) => opt.setName("url").setDescription("URL").setRequired(true))
    )
    .addSubcommand((sub) =>
      sub
        .setName("expand")
        .setDescription("Expand shortened URL")
        .addStringOption((opt) => opt.setName("url").setDescription("Short URL").setRequired(true))
    )
    .addSubcommand((sub) =>
      sub
        .setName("shorten")
        .setDescription("Shorten URL (configure API in .env)")
        .addStringOption((opt) => opt.setName("url").setDescription("URL to shorten").setRequired(true))
    ),

  async execute(interaction) {
    await interaction.deferReply();
    const sub = interaction.options.getSubcommand();

    try {
      let embed;

      if (sub === "encode") {
        const text = interaction.options.getString("text");
        const encoded = encodeURIComponent(text);
        embed = createSuccessEmbed("URL Encoded", "```\n" + encoded + "\n```");
      } else if (sub === "decode") {
        const text = interaction.options.getString("text");
        const decoded = decodeURIComponent(text);
        embed = createSuccessEmbed("URL Decoded", "```\n" + decoded + "\n```");
      } else if (sub === "info") {
        const url = interaction.options.getString("url");
        if (!isValidHttpUrl(url)) return interaction.editReply({ embeds: [createErrorEmbed("Invalid URL")] });
        const info = await getUrlInfo(url);
        embed = createEmbed({
          title: "🔗 URL INFO",
          fields: [
            { name: "Final URL", value: info.finalUrl, inline: false },
            { name: "Status", value: String(info.status), inline: true },
            { name: "Content-Type", value: info.contentType || "Unknown", inline: true },
            { name: "Size", value: info.contentLength || "Unknown", inline: true },
            { name: "Server", value: info.server || "Unknown", inline: true },
          ],
        });
      } else if (sub === "expand") {
        const url = interaction.options.getString("url");
        if (!isValidHttpUrl(url)) return interaction.editReply({ embeds: [createErrorEmbed("Invalid URL")] });
        const expanded = await expandUrl(url);
        embed = createSuccessEmbed("URL Expanded", `**Original:** ${url}\n**Expanded:** ${expanded}`);
      } else if (sub === "shorten") {
        embed = createErrorEmbed("URL shortener API not configured. Set it up in .env or use an external service.");
      }

      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      const errorId = generateErrorId();
      await interaction.editReply({ embeds: [createErrorEmbed(null, errorId)] });
      throw error;
    }
  },
};
