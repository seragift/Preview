const { SlashCommandBuilder } = require("discord.js");
const { createEmbed, createErrorEmbed, createSuccessEmbed } = require("../utils/embed");
const { fetchStatus, fetchHeaders, resolveDns, pingHost } = require("../services/networkService");
const { isValidHttpUrl, generateErrorId } = require("../utils/format");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("network")
    .setDescription("🌐 Network tools")
    .addSubcommand((sub) =>
      sub
        .setName("dns")
        .setDescription("Resolve DNS records")
        .addStringOption((opt) => opt.setName("domain").setDescription("Domain to lookup").setRequired(true))
    )
    .addSubcommand((sub) =>
      sub
        .setName("ip")
        .setDescription("Get your IP info")
    )
    .addSubcommand((sub) =>
      sub
        .setName("domain")
        .setDescription("Get domain info")
        .addStringOption((opt) => opt.setName("domain").setDescription("Domain").setRequired(true))
    )
    .addSubcommand((sub) =>
      sub
        .setName("ssl")
        .setDescription("Check SSL certificate info")
        .addStringOption((opt) => opt.setName("domain").setDescription("Domain").setRequired(true))
    )
    .addSubcommand((sub) =>
      sub
        .setName("headers")
        .setDescription("Fetch HTTP headers")
        .addStringOption((opt) => opt.setName("url").setDescription("URL").setRequired(true))
    )
    .addSubcommand((sub) =>
      sub
        .setName("status")
        .setDescription("Check HTTP status")
        .addStringOption((opt) => opt.setName("url").setDescription("URL").setRequired(true))
    )
    .addSubcommand((sub) =>
      sub
        .setName("ping")
        .setDescription("Ping a host")
        .addStringOption((opt) => opt.setName("host").setDescription("Hostname").setRequired(true))
    ),

  async execute(interaction) {
    await interaction.deferReply();
    const sub = interaction.options.getSubcommand();

    try {
      let embed;

      if (sub === "dns") {
        const domain = interaction.options.getString("domain");
        const { aRecords, mxRecords, txtRecords } = await resolveDns(domain);
        embed = createEmbed({
          title: "🌐 DNS Lookup",
          fields: [
            { name: "Domain", value: domain, inline: false },
            { name: "A Records", value: aRecords.length ? aRecords.join("\n") : "None", inline: true },
            { name: "MX Records", value: mxRecords.length ? mxRecords.map(r => `${r.priority} ${r.exchange}`).join("\n") : "None", inline: true },
            { name: "TXT Records", value: txtRecords.length ? txtRecords.map(t => t.join("")).join("\n").slice(0, 1000) : "None", inline: false },
          ],
        });
      } else if (sub === "ip") {
        embed = createEmbed({
          title: "🌐 Your IP",
          description: "Use /network status with an IP API for external IP info.",
        });
      } else if (sub === "domain") {
        const domain = interaction.options.getString("domain");
        const { aRecords } = await resolveDns(domain);
        embed = createEmbed({
          title: "🌐 Domain Info",
          fields: [
            { name: "Domain", value: domain, inline: false },
            { name: "Resolved IPs", value: aRecords.length ? aRecords.join("\n") : "None", inline: false },
          ],
        });
      } else if (sub === "ssl") {
        const domain = interaction.options.getString("domain");
        embed = createEmbed({
          title: "🔒 SSL Info",
          description: `SSL check for **${domain}**\nUse openssl CLI for detailed cert info.`,
        });
      } else if (sub === "headers") {
        const url = interaction.options.getString("url");
        if (!isValidHttpUrl(url)) {
          return interaction.editReply({ embeds: [createErrorEmbed("Invalid URL")] });
        }
        const headers = await fetchHeaders(url);
        const headerText = Object.entries(headers)
          .map(([k, v]) => `${k}: ${v}`)
          .join("\n")
          .slice(0, 4000);
        embed = createSuccessEmbed("HTTP Headers", "```\n" + headerText + "\n```");
      } else if (sub === "status") {
        const url = interaction.options.getString("url");
        if (!isValidHttpUrl(url)) {
          return interaction.editReply({ embeds: [createErrorEmbed("Invalid URL")] });
        }
        const status = await fetchStatus(url);
        const statusEmoji = status.status >= 200 && status.status < 300 ? "🟢" : status.status >= 400 ? "🔴" : "🟡";
        embed = createEmbed({
          title: "🌐 HTTP STATUS",
          fields: [
            { name: "URL", value: url, inline: false },
            { name: "Status", value: `${statusEmoji} ${status.status} ${status.statusText}`, inline: true },
            { name: "Response Time", value: `${status.time}ms`, inline: true },
            { name: "Content-Type", value: status.contentType, inline: true },
          ],
        });
      } else if (sub === "ping") {
        const host = interaction.options.getString("host");
        const ip = await pingHost(host);
        embed = createSuccessEmbed("Ping Result", `**Host:** ${host}\n**Resolved IP:** ${ip}`);
      }

      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      const errorId = generateErrorId();
      await interaction.editReply({ embeds: [createErrorEmbed(null, errorId)] });
      throw error;
    }
  },
};
