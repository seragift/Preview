const path = require("path");
require("dotenv").config();

module.exports = {
  token: process.env.DISCORD_TOKEN,
  clientId: process.env.CLIENT_ID,
  guildId: process.env.GUILD_ID,
  ownerId: process.env.OWNER_ID,
  colors: {
    primary: 0x00D4FF,
    secondary: 0x7C3AED,
    accent: 0x00FFB3,
    error: 0xFF4444,
    success: 0x00FFB3,
    warning: 0xFFA500,
  },
  cooldown: 3000,
  maxFileSize: 25 * 1024 * 1024,
  maxExtractSize: 100 * 1024 * 1024,
  maxFilesInZip: 50,
  tempDir: path.join(__dirname, "../../temp"),
  dbPath: path.join(__dirname, "../../database/database.sqlite"),
  footer: "Discord Toolbox • Utility Suite",
  httpTimeout: 15000,
};
