# 🛡️ Discord Security Bot + Web Dashboard

Full-stack Discord security bot (Anti Link, Anti Toxic, Anti Spam, Anti Multi Channel Spam,
Anti Raid, Anti Nuke) with a realtime web dashboard, built on **Discord.js v14**, **Express.js**,
**SQLite3**, **Passport Discord OAuth2**, and **Socket.IO**. Bot and dashboard run in a **single
Node.js process** — ideal for low-RAM Pterodactyl hosting.

---

## 1. Requirements

- Node.js **20+**
- A Discord Application (Bot Token, Client ID, Client Secret) — https://discord.com/developers/applications
- Pterodactyl panel (or any Node.js host)

## 2. Configuration

Edit **`config.json`** (or use `.env` — env vars override `config.json`):

| Key | Description |
|---|---|
| `token` | Your bot token |
| `clientId` | Your application client ID |
| `clientSecret` | Your application client secret (for OAuth2 login) |
| `ownerServerId` | Your private server ID (for global logs) |
| `globalLogsChannelId` | Channel ID in your private server where all security events across every server are mirrored |
| `ownerIds` | Array of Discord user IDs who get dashboard access to **every** server the bot is in |
| `port` | Default **7014** |
| `host` | Default `0.0.0.0` |
| `callbackURL` | OAuth2 redirect URL, e.g. `https://yourdomain.com/auth/discord/callback` |
| `sessionSecret` | Random long string for session signing |

In the Discord Developer Portal → OAuth2, add the redirect URL exactly matching `callbackURL`,
and enable the **`bot`**, **`applications.commands`**, **`identify`**, **`guilds`**, and
**`guilds.members.read`** scopes.

Required bot Privileged Gateway Intents (enable in Developer Portal → Bot):
- Server Members Intent
- Message Content Intent

## 3. Install & Run

```bash
npm install
npm start
```

The dashboard will be available at `http://<host>:7014`.
Slash commands (`/antinuke`, `/whitelist`, `/antinukelist`, `/setlogs`, `/removelogs`) are
registered globally on startup — global propagation can take up to 1 hour on first deploy.

## 4. Pterodactyl Deployment

1. Create a **Node.js** egg server (Node 20+).
2. Upload/clone this repository into the container.
3. Set the **Startup Command** to:
   ```
   node index.js
   ```
4. Set environment variable `PORT=7014` (or edit `config.json`) and allocate/forward port **7014**.
5. Run `npm install` from the panel console (or set it as the pre-start/install script).
6. Start the server. Console is stdin-only on Pterodactyl — this app does not require any
   interactive stdin input, so it runs unattended.

## 5. Project Structure

```
├── config.json           # Bot + dashboard configuration
├── index.js               # Entry point: Discord client + Express + Socket.IO
├── package.json
├── .env                   # Optional secret overrides
src/
├── commands/              # Slash commands (/antinuke, /whitelist, /antinukelist, /setlogs, /removelogs)
├── events/                # Discord gateway event handlers (messageCreate, guildMemberAdd, channelCreate, ...)
├── dashboard/
│   ├── routes/             # auth.js, dashboard.js, api.js
│   ├── views/               # EJS templates (landing, server-select, dashboard)
│   ├── public/               # Static client-side assets (dashboard.js)
│   └── middleware/            # auth guards
├── database/
│   └── schema.js            # SQLite3 schema + query helpers
└── utils/                  # antilink, antitoxic, antispam, antiraid, antinuke, logger
```

## 6. Slash Commands

| Command | Description |
|---|---|
| `/antinuke type:ON\|OFF` | Enable/disable **all** security systems at once |
| `/whitelist type:channel\|role\|user mode:ON\|OFF target:# [role] [user]` | Manage whitelist |
| `/antinukelist` | Show current security status embed |
| `/setlogs #channel` | Set the server's security log channel |
| `/removelogs` | Remove the configured log channel |

Dashboard toggles each security module individually (Anti Link / Anti Toxic / Anti Spam /
Anti Multi Channel Spam / Anti Raid / Anti Nuke) and changes sync to the bot in realtime via
Socket.IO — no restart needed.

## 7. Security Hardening Included

- Helmet HTTP headers
- Gzip compression
- Rate limiting (120 req/min per IP)
- CSRF protection (cookie-based token, required on all state-changing `/api` calls)
- Signed, HTTP-only session cookies (SQLite-backed session store)
- Parameterized SQL queries (no string concatenation)
- Global `unhandledRejection` / `uncaughtException` handlers + Discord auto-reconnect

## 8. Notes

- Dashboard access: bot owners (listed in `ownerIds`) can manage every server the bot is in.
  Regular users only see/manage servers where they hold **Administrator** or **Manage Guild**.
- All destructive Anti Nuke punishments never target the server owner.
- SQLite database file is created automatically at `src/database/database.sqlite` on first run.
