/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './src/dashboard/views/**/*.ejs',
    './src/dashboard/public/js/**/*.js',
  ],
  theme: {
    extend: {},
  },
  plugins: [],
};
