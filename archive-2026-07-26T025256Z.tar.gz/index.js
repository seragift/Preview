require('dotenv').config();
const fs = require('fs');
const path = require('path');
const express = require('express');
const session = require('express-session');
const SQLiteStore = require('connect-sqlite3')(session);
const cookieParser = require('cookie-parser');
const csrf = require('csurf');
const helmet = require('helmet');
const compression = require('compression');
const rateLimit = require('express-rate-limit');
const http = require('http');
const { Server: SocketIOServer } = require('socket.io');
const { Client, GatewayIntentBits, Partials, Collection } = require('discord.js');

const config = require('./config.json');
const setupPassport = require('./src/dashboard/passport');
const { attachIO } = require('./src/utils/logger');
const { getBotIdentity } = require('./src/utils/botIdentity');

const TOKEN = config.token || process.env.DISCORD_TOKEN;
const PORT = process.env.PORT || config.port || 7014;
const HOST = process.env.HOST || config.host || '0.0.0.0';

// ---------------------------------------------------------------------------
// Discord Client
// ---------------------------------------------------------------------------
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildPresences, // needed for "member online" count — also enable "Presence Intent" in the Discord Developer Portal
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildModeration,
    GatewayIntentBits.GuildWebhooks
  ],
  partials: [Partials.Message, Partials.Channel, Partials.GuildMember]
});

client.commands = new Collection();

const commandsPath = path.join(__dirname, 'src', 'commands');
for (const file of fs.readdirSync(commandsPath).filter((f) => f.endsWith('.js'))) {
  const command = require(path.join(commandsPath, file));
  if (command?.data?.name) client.commands.set(command.data.name, command);
}

const eventsPath = path.join(__dirname, 'src', 'events');
for (const file of fs.readdirSync(eventsPath).filter((f) => f.endsWith('.js'))) {
  const event = require(path.join(eventsPath, file));
  if (event.once) client.once(event.name, (...args) => event.execute(...args));
  else client.on(event.name, (...args) => event.execute(...args));
}

const ticketManager = require('./src/utils/ticketManager');

client.on('interactionCreate', async (interaction) => {
  if (interaction.isChatInputCommand()) {
    const command = client.commands.get(interaction.commandName);
    if (!command) return;

    try {
      await command.execute(interaction);
    } catch (err) {
      console.error(`[COMMAND ERROR] /${interaction.commandName}:`, err);
      const payload = { content: '❌ Terjadi kesalahan saat menjalankan perintah ini.', ephemeral: true };
      if (interaction.replied || interaction.deferred) await interaction.followUp(payload).catch(() => {});
      else await interaction.reply(payload).catch(() => {});
    }
    return;
  }

  if (interaction.isButton() && interaction.customId.startsWith('ticket_')) {
    // ticket_open buttons carry the source panel id, e.g. "ticket_open:12"
    const [action, panelId] = interaction.customId.split(':');
    try {
      switch (action) {
        case 'ticket_open':
          await ticketManager.openTicket(interaction, panelId);
          break;
        case 'ticket_claim':
          await ticketManager.claimTicket(interaction);
          break;
        case 'ticket_close':
          await ticketManager.closeTicket(interaction);
          break;
        case 'ticket_transcript':
          await ticketManager.sendTranscriptButton(interaction);
          break;
        case 'ticket_delete':
          await ticketManager.deleteTicketChannel(interaction);
          break;
      }
    } catch (err) {
      console.error(`[TICKET ERROR] ${interaction.customId}:`, err);
      const payload = { content: '❌ Terjadi kesalahan pada sistem ticket.', ephemeral: true };
      if (interaction.replied || interaction.deferred) await interaction.followUp(payload).catch(() => {});
      else await interaction.reply(payload).catch(() => {});
    }
  }
});

client.on('error', (err) => console.error('[DISCORD CLIENT ERROR]', err));
client.on('shardDisconnect', () => console.warn('[DISCORD] Shard disconnected, attempting reconnect...'));
client.on('shardReconnecting', () => console.log('[DISCORD] Reconnecting...'));
client.on('shardResume', () => console.log('[DISCORD] Reconnected.'));

// ---------------------------------------------------------------------------
// Express + Socket.IO
// ---------------------------------------------------------------------------
const app = express();
const server = http.createServer(app);
const io = new SocketIOServer(server, { cors: { origin: true, credentials: true } });

client.io = io;
attachIO(io);

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'src', 'dashboard', 'views'));

app.use(helmet({
  contentSecurityPolicy: false // relaxed to allow Tailwind CDN + inline scripts in views
}));
app.use(compression());
app.use(express.json({ limit: '20mb' })); // raised from default 100kb to allow base64 image uploads (bot avatar/banner, announcement image/icon)
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

app.use('/dashboard-assets', express.static(path.join(__dirname, 'src', 'dashboard', 'public'), {
  maxAge: '7d',
  etag: true
}));

const limiter = rateLimit({
  windowMs: 60 * 1000,
  max: 120,
  standardHeaders: true,
  legacyHeaders: false
});
app.use(limiter);

const sessionMiddleware = session({
  store: new SQLiteStore({ db: 'sessions.sqlite', dir: path.join(__dirname, 'src', 'database') }),
  secret: config.sessionSecret || process.env.SESSION_SECRET || 'change-this-secret',
  resave: false,
  saveUninitialized: false,
  cookie: {
    maxAge: 7 * 24 * 60 * 60 * 1000,
    secure: process.env.NODE_ENV === 'production' && process.env.FORCE_HTTPS === 'true',
    httpOnly: true,
    sameSite: 'lax'
  }
});
app.use(sessionMiddleware);

const passport = setupPassport();
app.use(passport.initialize());
app.use(passport.session());

// Share session with Socket.IO
io.engine.use(sessionMiddleware);

io.on('connection', (socket) => {
  socket.on('joinGuild', (guildId) => {
    if (typeof guildId === 'string') socket.join(`guild:${guildId}`);
  });
});

// CSRF protection (cookie-based) for state-changing API requests
const csrfProtection = csrf({ cookie: true });
app.get('/api/csrf-token', csrfProtection, (req, res) => {
  res.json({ csrfToken: req.csrfToken() });
});
app.use(['/api/guild', '/api/owner'], (req, res, next) => {
  if (['POST', 'PUT', 'DELETE', 'PATCH'].includes(req.method)) {
    return csrfProtection(req, res, next);
  }
  next();
});

// ---------------------------------------------------------------------------
// Routes
// ---------------------------------------------------------------------------
app.get('/', (req, res) => {
  const inviteUrl = `https://discord.com/api/oauth2/authorize?client_id=${config.clientId}&permissions=1099511931126&scope=bot%20applications.commands`;
  res.render('landing', { ...getBotIdentity(client), inviteUrl });
});

app.use('/auth', require('./src/dashboard/routes/auth')());
app.use('/dashboard', require('./src/dashboard/routes/dashboard')(client));
app.use('/api', require('./src/dashboard/routes/api')(client, io));
app.use('/api/owner', require('./src/dashboard/routes/owner')(client));

// Global error handler
app.use((err, req, res, next) => {
  if (err.code === 'EBADCSRFTOKEN') {
    return res.status(403).json({ error: 'Invalid CSRF token' });
  }
  console.error('[EXPRESS ERROR]', err);
  res.status(500).json({ error: 'Internal server error' });
});

server.listen(PORT, HOST, () => {
  console.log(`[DASHBOARD] Listening on http://${HOST}:${PORT}`);
});

// ---------------------------------------------------------------------------
// Global process safety nets
// ---------------------------------------------------------------------------
process.on('unhandledRejection', (reason) => {
  console.error('[UNHANDLED REJECTION]', reason);
});
process.on('uncaughtException', (err) => {
  console.error('[UNCAUGHT EXCEPTION]', err);
});

client.login(TOKEN).catch((err) => {
  console.error('[DISCORD] Failed to login. Check your bot token in config.json or .env:', err.message);
  process.exit(1);
});
