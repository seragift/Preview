const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('removerole')
    .setDescription('Hapus role dari member')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
    .addUserOption((option) =>
      option
        .setName('user')
        .setDescription('User yang ingin dihapus role-nya')
        .setRequired(true)
    )
    .addRoleOption((option) =>
      option
        .setName('role')
        .setDescription('Role yang ingin dihapus')
        .setRequired(true)
    ),

  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const role = interaction.options.getRole('role');

    const member = await interaction.guild.members.fetch(target.id).catch(() => null);

    if (!member) {
      return interaction.reply({ content: '❌ User tidak ditemukan di server ini.', ephemeral: true });
    }

    if (role.position >= interaction.guild.members.me.roles.highest.position) {
      return interaction.reply({ content: '❌ Bot tidak memiliki izin untuk menghapus role ini (posisi role terlalu tinggi).', ephemeral: true });
    }

    if (!member.roles.cache.has(role.id)) {
      return interaction.reply({ content: `❌ **${target.tag}** tidak memiliki role <@&${role.id}>.`, ephemeral: true });
    }

    await member.roles.remove(role);

    const embed = new EmbedBuilder()
      .setColor(0xff4d4d)
      .setTitle('🗑️ Role Dihapus')
      .setDescription(`<@&${role.id}> telah dihapus dari **${target.tag}**.`)
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  }
};
