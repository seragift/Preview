const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('giverole')
    .setDescription('Berikan role ke member')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
    .addUserOption((option) =>
      option
        .setName('user')
        .setDescription('User yang ingin diberi role')
        .setRequired(true)
    )
    .addRoleOption((option) =>
      option
        .setName('role')
        .setDescription('Role yang ingin diberikan')
        .setRequired(true)
    ),

  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const role = interaction.options.getRole('role');

    const member = await interaction.guild.members.fetch(target.id).catch(() => null);

    if (!member) {
      return interaction.reply({ content: '❌ User tidak ditemukan di server ini.', ephemeral: true });
    }

    if (role.position >= interaction.guild.members.me.roles.highest.position) {
      return interaction.reply({ content: '❌ Bot tidak memiliki izin untuk memberikan role ini (posisi role terlalu tinggi).', ephemeral: true });
    }

    if (member.roles.cache.has(role.id)) {
      return interaction.reply({ content: `❌ **${target.tag}** sudah memiliki role <@&${role.id}>.`, ephemeral: true });
    }

    await member.roles.add(role);

    const embed = new EmbedBuilder()
      .setColor(0x00ffb3)
      .setTitle('✅ Role Diberikan')
      .setDescription(`<@&${role.id}> telah diberikan kepada **${target.tag}**.`)
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  }
};
