const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('kick')
    .setDescription('Kick member dari server')
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers)
    .addUserOption((option) =>
      option
        .setName('user')
        .setDescription('User yang ingin di-kick')
        .setRequired(true)
    )
    .addStringOption((option) =>
      option
        .setName('reason')
        .setDescription('Alasan kick')
        .setRequired(false)
    ),

  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason') || 'Tidak ada alasan diberikan';

    const member = await interaction.guild.members.fetch(target.id).catch(() => null);

    if (!member) {
      return interaction.reply({ content: '❌ User tidak ditemukan di server ini.', ephemeral: true });
    }

    if (!member.kickable) {
      return interaction.reply({ content: '❌ Bot tidak memiliki izin untuk kick user ini.', ephemeral: true });
    }

    await member.kick(reason);

    const embed = new EmbedBuilder()
      .setColor(0xff4d4d)
      .setTitle('👢 Member Dikeluarkan')
      .setDescription(`**${target.tag}** telah di-kick dari server.`)
      .addFields({ name: 'Alasan', value: reason })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  }
};
