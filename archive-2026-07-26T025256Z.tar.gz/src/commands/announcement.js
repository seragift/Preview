const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType
} = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('announcement')
    .setDescription('Kirim pengumuman ke sebuah channel')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addChannelOption((option) =>
      option
        .setName('channel')
        .setDescription('Channel tujuan pengumuman')
        .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement)
        .setRequired(true)
    )
    .addStringOption((option) =>
      option
        .setName('title')
        .setDescription('Judul pengumuman')
        .setRequired(true)
        .setMaxLength(256)
    )
    .addStringOption((option) =>
      option
        .setName('deskripsi')
        .setDescription('Isi / deskripsi pengumuman')
        .setRequired(true)
        .setMaxLength(4000)
    )
    .addAttachmentOption((option) =>
      option
        .setName('image')
        .setDescription('Gambar besar untuk pengumuman (opsional)')
        .setRequired(false)
    )
    .addAttachmentOption((option) =>
      option
        .setName('icon')
        .setDescription('Icon / thumbnail kecil untuk pengumuman (opsional)')
        .setRequired(false)
    )
    .addStringOption((option) =>
      option
        .setName('tag')
        .setDescription('Mention sebelum pengumuman dikirim')
        .setRequired(false)
        .addChoices(
          { name: 'Tidak ada', value: 'none' },
          { name: '@everyone', value: 'everyone' },
          { name: '@here', value: 'here' },
          { name: 'Role tertentu', value: 'role' }
        )
    )
    .addRoleOption((option) =>
      option
        .setName('role')
        .setDescription('Role yang ingin di-tag (wajib jika tag: Role tertentu)')
        .setRequired(false)
    )
    .addStringOption((option) =>
      option
        .setName('button_title')
        .setDescription('Judul tombol (opsional, wajib diisi bersama button_link)')
        .setRequired(false)
        .setMaxLength(80)
    )
    .addStringOption((option) =>
      option
        .setName('button_link')
        .setDescription('URL tujuan tombol (opsional, wajib diisi bersama button_title)')
        .setRequired(false)
    ),

  async execute(interaction) {
    const channel = interaction.options.getChannel('channel');
    const title = interaction.options.getString('title');
    const description = interaction.options.getString('deskripsi');
    const image = interaction.options.getAttachment('image');
    const icon = interaction.options.getAttachment('icon');
    const tag = interaction.options.getString('tag') || 'none';
    const role = interaction.options.getRole('role');
    const buttonTitle = interaction.options.getString('button_title');
    const buttonLink = interaction.options.getString('button_link');

    if (tag === 'role' && !role) {
      return interaction.reply({ content: '❌ Parameter `role` wajib diisi jika `tag` diatur ke "Role tertentu".', ephemeral: true });
    }

    if ((buttonTitle && !buttonLink) || (buttonLink && !buttonTitle)) {
      return interaction.reply({ content: '❌ `button_title` dan `button_link` harus diisi bersamaan.', ephemeral: true });
    }

    if (buttonLink && !/^https?:\/\//i.test(buttonLink)) {
      return interaction.reply({ content: '❌ `button_link` harus berupa URL valid (diawali http:// atau https://).', ephemeral: true });
    }

    if (image && !image.contentType?.startsWith('image/')) {
      return interaction.reply({ content: '❌ File `image` harus berupa gambar.', ephemeral: true });
    }

    if (icon && !icon.contentType?.startsWith('image/')) {
      return interaction.reply({ content: '❌ File `icon` harus berupa gambar.', ephemeral: true });
    }

    const embed = new EmbedBuilder()
      .setColor(0x00d4ff)
      .setTitle(title)
      .setDescription(description)
      .setTimestamp()
      .setFooter({ text: `Diumumkan oleh ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL() });

    if (image) embed.setImage(image.url);
    if (icon) embed.setThumbnail(icon.url);

    const components = [];
    if (buttonTitle && buttonLink) {
      components.push(
        new ActionRowBuilder().addComponents(
          new ButtonBuilder().setLabel(buttonTitle).setURL(buttonLink).setStyle(ButtonStyle.Link)
        )
      );
    }

    let content;
    let allowedMentions = { parse: [] };
    if (tag === 'everyone') {
      content = '@everyone';
      allowedMentions = { parse: ['everyone'] };
    } else if (tag === 'here') {
      content = '@here';
      allowedMentions = { parse: ['everyone'] };
    } else if (tag === 'role' && role) {
      content = `<@&${role.id}>`;
      allowedMentions = { roles: [role.id] };
    }

    try {
      await channel.send({ content, embeds: [embed], components, allowedMentions });
    } catch (err) {
      return interaction.reply({ content: `❌ Gagal mengirim pengumuman: ${err.message}`, ephemeral: true });
    }

    const confirmEmbed = new EmbedBuilder()
      .setColor(0x00ffb3)
      .setTitle('📢 Pengumuman Terkirim')
      .setDescription(`Pengumuman berhasil dikirim ke <#${channel.id}>.`)
      .setTimestamp();

    await interaction.reply({ embeds: [confirmEmbed], ephemeral: true });
  }
};
