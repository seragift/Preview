const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('Ban member dari server')
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .addUserOption((option) =>
      option
        .setName('user')
        .setDescription('User yang ingin di-ban')
        .setRequired(true)
    )
    .addStringOption((option) =>
      option
        .setName('reason')
        .setDescription('Alasan ban')
        .setRequired(false)
    )
    .addIntegerOption((option) =>
      option
        .setName('delete_days')
        .setDescription('Hapus pesan user dari berapa hari terakhir (0-7)')
        .setMinValue(0)
        .setMaxValue(7)
        .setRequired(false)
    ),

  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason') || 'Tidak ada alasan diberikan';
    const deleteDays = interaction.options.getInteger('delete_days') || 0;

    const member = await interaction.guild.members.fetch(target.id).catch(() => null);

    if (member && !member.bannable) {
      return interaction.reply({ content: '❌ Bot tidak memiliki izin untuk ban user ini.', ephemeral: true });
    }

    await interaction.guild.members.ban(target.id, {
      reason,
      deleteMessageSeconds: deleteDays * 24 * 60 * 60
    });

    const embed = new EmbedBuilder()
      .setColor(0xff4d4d)
      .setTitle('🔨 Member Diban')
      .setDescription(`**${target.tag}** telah di-ban dari server.`)
      .addFields({ name: 'Alasan', value: reason })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  }
};
