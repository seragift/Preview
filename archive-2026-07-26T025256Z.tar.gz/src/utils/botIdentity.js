const config = require('../../config.json');

/**
 * Returns the bot's real, live Discord identity (username + avatar) instead
 * of a hardcoded name/emoji from config.json. Falls back gracefully if the
 * client hasn't finished logging in yet.
 */
function getBotIdentity(client) {
  const user = client?.user;
  return {
    botName: user?.username || config.botName || 'Bot',
    botAvatar: user ? user.displayAvatarURL({ size: 128, extension: 'png' }) : null
  };
}

module.exports = { getBotIdentity };
