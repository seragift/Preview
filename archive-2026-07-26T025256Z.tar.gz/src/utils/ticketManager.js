const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  PermissionFlagsBits,
  AttachmentBuilder,
  ChannelType
} = require('discord.js');
const {
  getTicketPanelById,
  nextTicketNumber,
  createTicket,
  getTicketByChannel,
  claimTicketRow,
  closeTicketRow,
  getOpenTicketByUser
} = require('../database/schema');

function parseColor(hex, fallback = 0x00d4ff) {
  if (!hex) return fallback;
  const cleaned = hex.replace('#', '');
  const parsed = parseInt(cleaned, 16);
  return Number.isNaN(parsed) ? fallback : parsed;
}

function applyPlaceholders(text, { user, role }) {
  return (text || '')
    .replaceAll('{user}', user ? `<@${user.id}>` : '')
    .replaceAll('{role}', role ? `<@&${role.id}>` : 'Staff');
}

// ---------------------------------------------------------------------------
// Panel (posted by admin via /ticket-panel)
// ---------------------------------------------------------------------------
function buildPanelPayload(settings) {
  const emoji = settings.panelEmoji || '🎫';
  const button = new ButtonBuilder()
    .setCustomId(`ticket_open:${settings.id}`)
    .setLabel('Buka Ticket')
    .setStyle(ButtonStyle.Primary)
    .setEmoji(emoji);

  const row = new ActionRowBuilder().addComponents(button);

  if (settings.panelType === 'message') {
    return {
      content: `**${settings.panelTitle}**\n${settings.panelDescription}`,
      embeds: [],
      components: [row]
    };
  }

  const embed = new EmbedBuilder()
    .setColor(parseColor(settings.panelColor))
    .setTitle(`${emoji} ${settings.panelTitle}`)
    .setDescription(settings.panelDescription)
    .setTimestamp();

  return { content: '', embeds: [embed], components: [row] };
}

// ---------------------------------------------------------------------------
// Opening a ticket
// ---------------------------------------------------------------------------
async function openTicket(interaction, panelId) {
  const { guild, user } = interaction;
  const settings = panelId ? await getTicketPanelById(panelId) : null;

  if (!settings || !settings.category || !settings.staffRoleId) {
    return interaction.reply({ content: '❌ Panel ticket ini sudah tidak valid (mungkin sudah dihapus). Hubungi admin untuk membuat ulang panel dari dashboard.', ephemeral: true });
  }

  const existing = await getOpenTicketByUser(guild.id, user.id);
  if (existing) {
    const existingChannel = guild.channels.cache.get(existing.channelId);
    if (existingChannel) {
      return interaction.reply({ content: `❌ Kamu sudah memiliki ticket yang masih terbuka di <#${existing.channelId}>.`, ephemeral: true });
    }
  }

  const category = guild.channels.cache.get(settings.category);
  if (!category || category.type !== ChannelType.GuildCategory) {
    return interaction.reply({ content: '❌ Kategori ticket tidak ditemukan. Hubungi admin untuk mengatur ulang `/ticket-panel`.', ephemeral: true });
  }

  await interaction.deferReply({ ephemeral: true });

  const ticketNumber = await nextTicketNumber(guild.id);
  const channelName = `ticket-${String(ticketNumber).padStart(4, '0')}`;

  let channel;
  try {
    channel = await guild.channels.create({
      name: channelName,
      type: ChannelType.GuildText,
      parent: category.id,
      topic: `Ticket milik ${user.tag} (${user.id})`,
      permissionOverwrites: [
        { id: guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
        {
          id: user.id,
          allow: [
            PermissionFlagsBits.ViewChannel,
            PermissionFlagsBits.SendMessages,
            PermissionFlagsBits.ReadMessageHistory,
            PermissionFlagsBits.AttachFiles
          ]
        },
        {
          id: settings.staffRoleId,
          allow: [
            PermissionFlagsBits.ViewChannel,
            PermissionFlagsBits.SendMessages,
            PermissionFlagsBits.ReadMessageHistory,
            PermissionFlagsBits.ManageMessages,
            PermissionFlagsBits.AttachFiles
          ]
        },
        {
          id: guild.members.me.id,
          allow: [
            PermissionFlagsBits.ViewChannel,
            PermissionFlagsBits.SendMessages,
            PermissionFlagsBits.ManageChannels,
            PermissionFlagsBits.ManageMessages,
            PermissionFlagsBits.ReadMessageHistory,
            PermissionFlagsBits.AttachFiles
          ]
        }
      ]
    });
  } catch (err) {
    console.error('[TICKET] Gagal membuat channel:', err.message);
    return interaction.editReply({ content: '❌ Gagal membuat channel ticket. Pastikan bot punya izin `Manage Channels`.' });
  }

  await createTicket(guild.id, settings.id, channel.id, user.id);

  const role = guild.roles.cache.get(settings.staffRoleId);
  const welcomeText = applyPlaceholders(settings.welcomeMessage, { user, role });

  const embed = new EmbedBuilder()
    .setColor(parseColor(settings.panelColor))
    .setTitle(`🎫 Ticket #${String(ticketNumber).padStart(4, '0')}`)
    .setDescription(welcomeText)
    .addFields(
      { name: 'Dibuka oleh', value: `<@${user.id}>`, inline: true },
      { name: 'Status', value: 'Belum diklaim', inline: true }
    )
    .setTimestamp();

  const buttons = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('ticket_claim').setLabel('Claim').setStyle(ButtonStyle.Success).setEmoji('🙋'),
    new ButtonBuilder().setCustomId('ticket_close').setLabel('Close').setStyle(ButtonStyle.Danger).setEmoji('🔒'),
    new ButtonBuilder().setCustomId('ticket_transcript').setLabel('Transcript').setStyle(ButtonStyle.Secondary).setEmoji('📄')
  );

  await channel.send({
    content: `<@${user.id}> ${role ? `<@&${role.id}>` : ''}`,
    embeds: [embed],
    components: [buttons],
    allowedMentions: { users: [user.id], roles: role ? [role.id] : [] }
  });

  await interaction.editReply({ content: `✅ Ticket kamu berhasil dibuat: <#${channel.id}>` });
}

// ---------------------------------------------------------------------------
// Claiming a ticket
// ---------------------------------------------------------------------------
async function claimTicket(interaction) {
  const { guild, user, channel } = interaction;
  const ticket = await getTicketByChannel(channel.id);
  const settings = ticket?.panelId ? await getTicketPanelById(ticket.panelId) : null;

  if (!ticket) {
    return interaction.reply({ content: '❌ Ticket tidak ditemukan di database.', ephemeral: true });
  }
  if (ticket.status === 'closed') {
    return interaction.reply({ content: '❌ Ticket ini sudah ditutup.', ephemeral: true });
  }
  if (ticket.claimedBy) {
    return interaction.reply({ content: `❌ Ticket ini sudah diklaim oleh <@${ticket.claimedBy}>.`, ephemeral: true });
  }

  const member = await guild.members.fetch(user.id).catch(() => null);
  const isStaff = member?.roles.cache.has(settings?.staffRoleId) || member?.permissions.has(PermissionFlagsBits.ManageChannels);
  if (!isStaff) {
    return interaction.reply({ content: '❌ Hanya staff yang bisa claim ticket ini.', ephemeral: true });
  }

  await claimTicketRow(channel.id, user.id);

  const originalEmbed = interaction.message.embeds[0];
  const updatedEmbed = EmbedBuilder.from(originalEmbed).setFields(
    { name: 'Dibuka oleh', value: originalEmbed.fields[0]?.value || '-', inline: true },
    { name: 'Status', value: `Diklaim oleh <@${user.id}>`, inline: true }
  );

  const row = ActionRowBuilder.from(interaction.message.components[0]);
  row.components[0] = ButtonBuilder.from(row.components[0])
    .setLabel(`Diklaim oleh ${member.displayName}`)
    .setDisabled(true);

  await interaction.update({ embeds: [updatedEmbed], components: [row] });
  await channel.send({ content: `🙋 Ticket diklaim oleh <@${user.id}>.` });
}

// ---------------------------------------------------------------------------
// Transcript generation
// ---------------------------------------------------------------------------
async function generateTranscript(channel) {
  const collected = [];
  let lastId;

  for (let i = 0; i < 20; i++) {
    const batch = await channel.messages.fetch({ limit: 100, before: lastId });
    if (!batch.size) break;
    collected.push(...batch.values());
    lastId = batch.last().id;
    if (batch.size < 100) break;
  }

  collected.sort((a, b) => a.createdTimestamp - b.createdTimestamp);

  const lines = collected.map((m) => {
    const time = new Date(m.createdTimestamp).toISOString().replace('T', ' ').substring(0, 19);
    let line = `[${time}] ${m.author.tag} (${m.author.id}): ${m.content || ''}`;
    if (m.embeds.length) line += ` [${m.embeds.length} embed(s)]`;
    if (m.attachments.size) {
      line += ` [Lampiran: ${[...m.attachments.values()].map((a) => a.url).join(', ')}]`;
    }
    return line;
  });

  const header = [
    `Transcript channel: #${channel.name} (${channel.id})`,
    `Guild: ${channel.guild.name} (${channel.guild.id})`,
    `Dibuat: ${new Date().toISOString()}`,
    `Total pesan: ${collected.length}`,
    '-----------------------------------------'
  ];

  const content = [...header, ...lines].join('\n') || 'Tidak ada pesan.';
  return new AttachmentBuilder(Buffer.from(content, 'utf-8'), { name: `transcript-${channel.name}.txt` });
}

async function sendTranscriptButton(interaction) {
  const { channel } = interaction;
  await interaction.deferReply({ ephemeral: true });
  const attachment = await generateTranscript(channel);
  await interaction.editReply({ content: '📄 Transcript ticket ini:', files: [attachment] });
}

// ---------------------------------------------------------------------------
// Closing a ticket
// ---------------------------------------------------------------------------
async function closeTicket(interaction) {
  const { guild, user, channel } = interaction;
  const ticket = await getTicketByChannel(channel.id);
  const settings = ticket?.panelId ? await getTicketPanelById(ticket.panelId) : null;

  if (!ticket) {
    return interaction.reply({ content: '❌ Ticket tidak ditemukan di database.', ephemeral: true });
  }
  if (ticket.status === 'closed') {
    return interaction.reply({ content: '❌ Ticket ini sudah ditutup sebelumnya.', ephemeral: true });
  }

  const member = await guild.members.fetch(user.id).catch(() => null);
  const isStaff = member?.roles.cache.has(settings?.staffRoleId) || member?.permissions.has(PermissionFlagsBits.ManageChannels);
  const isOwner = ticket.userId === user.id;
  if (!isStaff && !isOwner) {
    return interaction.reply({ content: '❌ Kamu tidak memiliki izin untuk menutup ticket ini.', ephemeral: true });
  }

  await interaction.deferUpdate();

  const attachment = await generateTranscript(channel);
  await closeTicketRow(channel.id, user.id);

  // Send transcript to log channel if configured
  if (settings?.transcriptChannelId) {
    const logChannel = guild.channels.cache.get(settings.transcriptChannelId);
    if (logChannel) {
      const logEmbed = new EmbedBuilder()
        .setColor(0xff4d4d)
        .setTitle('🔒 Ticket Ditutup')
        .addFields(
          { name: 'Channel', value: `#${channel.name}`, inline: true },
          { name: 'Pembuka', value: `<@${ticket.userId}>`, inline: true },
          { name: 'Ditutup oleh', value: `<@${user.id}>`, inline: true }
        )
        .setTimestamp();
      await logChannel.send({ embeds: [logEmbed], files: [attachment] }).catch(() => {});
    }
  }

  // Also drop a fresh copy of the attachment in-channel (buffer gets consumed once sent, so regenerate)
  const attachmentForChannel = await generateTranscript(channel);

  const closedEmbed = new EmbedBuilder()
    .setColor(0xff4d4d)
    .setTitle('🔒 Ticket Ditutup')
    .setDescription(`Ticket ditutup oleh <@${user.id}>. Channel ini akan dikunci.`)
    .setTimestamp();

  const deleteRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('ticket_delete').setLabel('Hapus Channel').setStyle(ButtonStyle.Danger).setEmoji('🗑️')
  );

  await channel.send({ embeds: [closedEmbed], files: [attachmentForChannel], components: [deleteRow] });

  // Lock the channel: ticket owner can no longer send messages
  await channel.permissionOverwrites.edit(ticket.userId, { SendMessages: false }).catch(() => {});

  const renamed = channel.name.startsWith('closed-') ? channel.name : `closed-${channel.name}`;
  await channel.setName(renamed).catch(() => {});

  // Disable the original claim/close/transcript buttons
  try {
    const disabledRow = ActionRowBuilder.from(interaction.message.components[0]);
    disabledRow.components = disabledRow.components.map((c) => ButtonBuilder.from(c).setDisabled(true));
    await interaction.message.edit({ components: [disabledRow] });
  } catch (err) {
    // message may already be edited/deleted, ignore
  }
}

async function deleteTicketChannel(interaction) {
  const { guild, user, channel } = interaction;
  const ticket = await getTicketByChannel(channel.id);
  const settings = ticket?.panelId ? await getTicketPanelById(ticket.panelId) : null;
  const member = await guild.members.fetch(user.id).catch(() => null);
  const isStaff = member?.roles.cache.has(settings?.staffRoleId) || member?.permissions.has(PermissionFlagsBits.ManageChannels);

  if (!isStaff) {
    return interaction.reply({ content: '❌ Hanya staff yang bisa menghapus channel ticket.', ephemeral: true });
  }

  await interaction.reply({ content: '🗑️ Channel akan dihapus dalam 5 detik...', ephemeral: false });
  setTimeout(() => {
    channel.delete().catch((err) => console.error('[TICKET] Gagal hapus channel:', err.message));
  }, 5000);
}

module.exports = {
  buildPanelPayload,
  openTicket,
  claimTicket,
  closeTicket,
  deleteTicketChannel,
  sendTranscriptButton,
  generateTranscript
};
