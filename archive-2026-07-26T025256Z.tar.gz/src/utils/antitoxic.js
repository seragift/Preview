const { listToxicWords } = require('../database/schema');

// Base toxic word list (Indonesian + English), always active.
const DEFAULT_BLACKLIST = [
  // English
  'fuck', 'shit', 'bitch', 'asshole', 'nigger', 'nigga', 'cunt', 'faggot', 'retard', 'whore', 'slut',
  // Indonesian
  'anjing', 'bangsat', 'bajingan', 'kontol', 'memek', 'pepek', 'ngentot', 'goblok', 'tolol', 'kampret',
  'babi', 'monyet', 'idiot', 'jancok', 'asu', 'brengsek', 'sialan', 'keparat', 'pelacur', 'lonte'
];

// Custom words are managed per-server from the dashboard and persisted in the
// `toxic_words` table. Cached in memory per guild to avoid a DB hit on every
// message; the cache is invalidated whenever the dashboard adds/removes a word.
const CACHE_TTL_MS = 5 * 60 * 1000;
const customWordsCache = new Map(); // guildId -> { words: Set<string>, loadedAt: number }

function escapeRegex(str) {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

async function getCustomWords(guildId) {
  const cached = customWordsCache.get(guildId);
  if (cached && Date.now() - cached.loadedAt < CACHE_TTL_MS) return cached.words;

  const rows = await listToxicWords(guildId).catch(() => []);
  const words = new Set(rows.map((r) => r.word.toLowerCase()));
  customWordsCache.set(guildId, { words, loadedAt: Date.now() });
  return words;
}

// Called by the dashboard API right after a word is added/removed so the
// running bot picks up the change immediately instead of waiting for the TTL.
function invalidateCache(guildId) {
  customWordsCache.delete(guildId);
}

async function getBlacklist(guildId) {
  const custom = await getCustomWords(guildId);
  return [...DEFAULT_BLACKLIST, ...custom];
}

async function containsToxic(content, guildId) {
  if (!content) return false;
  const lowered = content.toLowerCase();
  const list = await getBlacklist(guildId);
  return list.some((word) => {
    const pattern = new RegExp(`\\b${escapeRegex(word)}\\b`, 'i');
    return pattern.test(lowered);
  });
}

module.exports = { containsToxic, getBlacklist, invalidateCache, DEFAULT_BLACKLIST };
