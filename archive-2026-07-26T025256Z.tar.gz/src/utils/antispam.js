const { THRESHOLD_DEFAULTS } = require('../database/schema');

// userId -> { timestamps: number[], channels: Map<channelId, number[]> }
const userActivity = new Map();

function getActivity(userId) {
  if (!userActivity.has(userId)) {
    userActivity.set(userId, { timestamps: [], channels: new Map() });
  }
  return userActivity.get(userId);
}

function cleanupOld(arr, windowMs, now) {
  return arr.filter((t) => now - t <= windowMs);
}

// Reads per-server thresholds from the guild_settings row (falls back to the
// global defaults if a field is missing, e.g. right after a fresh migration).
function resolveConfig(settings) {
  const s = settings || {};
  return {
    windowShortMs: s.antispam_windowShortMs ?? THRESHOLD_DEFAULTS.antispam_windowShortMs,
    windowShortCount: s.antispam_windowShortCount ?? THRESHOLD_DEFAULTS.antispam_windowShortCount,
    windowLongMs: s.antispam_windowLongMs ?? THRESHOLD_DEFAULTS.antispam_windowLongMs,
    windowLongCount: s.antispam_windowLongCount ?? THRESHOLD_DEFAULTS.antispam_windowLongCount,
    multiChannelWindowMs: s.antispam_multiChannelWindowMs ?? THRESHOLD_DEFAULTS.antispam_multiChannelWindowMs,
    multiChannelThreshold: s.antispam_multiChannelThreshold ?? THRESHOLD_DEFAULTS.antispam_multiChannelThreshold,
    repeatedCharThreshold: s.antispam_repeatedCharThreshold ?? THRESHOLD_DEFAULTS.antispam_repeatedCharThreshold,
    mentionThreshold: s.antispam_mentionThreshold ?? THRESHOLD_DEFAULTS.antispam_mentionThreshold,
    emojiThreshold: s.antispam_emojiThreshold ?? THRESHOLD_DEFAULTS.antispam_emojiThreshold
  };
}

/**
 * Records a message and checks whether it violates spam thresholds.
 * `settings` is the guild_settings row for this server (per-server thresholds).
 * Returns { spam: boolean, reason: string|null, multiChannel: boolean }
 */
function checkSpam(userId, channelId, content, attachmentCount = 0, settings = null) {
  const now = Date.now();
  const activity = getActivity(userId);
  const cfg = resolveConfig(settings);

  activity.timestamps.push(now);
  activity.timestamps = cleanupOld(activity.timestamps, cfg.windowLongMs, now);

  const shortWindowCount = activity.timestamps.filter((t) => now - t <= cfg.windowShortMs).length;
  const longWindowCount = activity.timestamps.length;

  if (shortWindowCount >= cfg.windowShortCount) {
    return { spam: true, reason: `Spam terdeteksi: ${shortWindowCount} pesan dalam ${cfg.windowShortMs / 1000} detik`, multiChannel: false };
  }
  if (longWindowCount >= cfg.windowLongCount) {
    return { spam: true, reason: `Spam terdeteksi: ${longWindowCount} pesan dalam ${cfg.windowLongMs / 1000} detik`, multiChannel: false };
  }

  if (content) {
    const emojiMatches = content.match(/(<a?:\w+:\d+>|\p{Extended_Pictographic})/gu) || [];
    if (emojiMatches.length >= cfg.emojiThreshold) {
      return { spam: true, reason: `Spam emoji terdeteksi (${emojiMatches.length} emoji)`, multiChannel: false };
    }

    const mentionMatches = content.match(/<@!?\d+>/g) || [];
    if (mentionMatches.length >= cfg.mentionThreshold) {
      return { spam: true, reason: `Spam mention terdeteksi (${mentionMatches.length} mention)`, multiChannel: false };
    }

    const repeatedCharMatch = content.match(new RegExp(`(.)\\1{${Math.max(cfg.repeatedCharThreshold - 1, 1)},}`));
    if (repeatedCharMatch) {
      return { spam: true, reason: 'Spam huruf berulang terdeteksi', multiChannel: false };
    }
  }

  if (attachmentCount > 0) {
    if (!activity.attachmentTimestamps) activity.attachmentTimestamps = [];
    activity.attachmentTimestamps.push(now);
    activity.attachmentTimestamps = cleanupOld(activity.attachmentTimestamps, cfg.windowShortMs, now);
    if (activity.attachmentTimestamps.length >= 4) {
      return { spam: true, reason: 'Spam attachment terdeteksi', multiChannel: false };
    }
  }

  // Multi-channel spam check
  if (!activity.channels.has(channelId)) activity.channels.set(channelId, []);
  activity.channels.get(channelId).push(now);

  const activeChannels = [...activity.channels.entries()].filter(([, times]) => {
    const filtered = cleanupOld(times, cfg.multiChannelWindowMs, now);
    return filtered.length > 0;
  });

  if (activeChannels.length >= cfg.multiChannelThreshold) {
    return {
      spam: true,
      reason: `Multi Channel Spam terdeteksi: pesan ke ${activeChannels.length} channel berbeda dalam ${cfg.multiChannelWindowMs / 1000} detik`,
      multiChannel: true
    };
  }

  return { spam: false, reason: null, multiChannel: false };
}

function clearUser(userId) {
  userActivity.delete(userId);
}

module.exports = { checkSpam, clearUser };
