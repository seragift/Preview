const { THRESHOLD_DEFAULTS } = require('../database/schema');

// key: `${guildId}:${executorId}` -> timestamps[]
const actionActivity = new Map();

// `settings` is the guild_settings row for this server (per-server thresholds).
function recordAction(guildId, executorId, settings = null) {
  const now = Date.now();
  const key = `${guildId}:${executorId}`;
  const s = settings || {};
  const actionThreshold = s.antinuke_actionThreshold ?? THRESHOLD_DEFAULTS.antinuke_actionThreshold;
  const actionWindowMs = s.antinuke_actionWindowMs ?? THRESHOLD_DEFAULTS.antinuke_actionWindowMs;

  if (!actionActivity.has(key)) actionActivity.set(key, []);
  const arr = actionActivity.get(key).filter((t) => now - t <= actionWindowMs);
  arr.push(now);
  actionActivity.set(key, arr);

  return arr.length >= actionThreshold;
}

async function punishExecutor(guild, executorId, reason) {
  try {
    const member = await guild.members.fetch(executorId).catch(() => null);
    if (!member) return false;
    if (member.id === guild.ownerId) return false; // never punish owner

    // Strip dangerous permissions by removing all roles that grant admin-level perms
    const dangerousRoles = member.roles.cache.filter((role) =>
      role.permissions.has('Administrator') ||
      role.permissions.has('ManageGuild') ||
      role.permissions.has('ManageChannels') ||
      role.permissions.has('ManageRoles') ||
      role.permissions.has('BanMembers') ||
      role.permissions.has('KickMembers')
    );

    for (const [, role] of dangerousRoles) {
      await member.roles.remove(role).catch(() => {});
    }

    if (member.moderatable) {
      await member.timeout(10 * 60 * 1000, reason).catch(() => {});
    } else if (member.kickable) {
      await member.kick(reason).catch(() => {});
    }

    return true;
  } catch (err) {
    console.error('[ANTINUKE] Failed to punish executor:', err.message);
    return false;
  }
}

module.exports = { recordAction, punishExecutor };
