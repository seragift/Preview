const { EmbedBuilder } = require('discord.js');
const { addLog, getGuildSettings } = require('../database/schema');
const config = require('../../config.json');

let ioInstance = null;
function attachIO(io) {
  ioInstance = io;
}

const VIOLATION_LABELS = {
  'Anti Link': '🔗 Dilarang mengirim link/undangan Discord di server ini.',
  'Anti Toxic': '🤬 Dilarang menggunakan kata-kata toxic/tidak pantas.',
  'Anti Spam': '⏱️ Dilarang mengirim pesan secara spam.',
  'Anti Multi Channel Spam': '⏱️ Dilarang mengirim pesan spam ke banyak channel sekaligus.'
};

/**
 * Sends a short-lived warning embed in the channel where the violation
 * happened, so the user actually sees why their message was removed
 * instead of it just silently disappearing.
 */
async function sendViolationWarning(channel, user, action, reason) {
  if (!channel?.isTextBased()) return;
  const description = VIOLATION_LABELS[action] || reason || 'Pelanggaran aturan server terdeteksi.';

  const embed = new EmbedBuilder()
    .setColor(0xff4d4d)
    .setDescription(`⚠️ ${user}, pesanmu dihapus otomatis.\n${description}`);

  try {
    const sent = await channel.send({ embeds: [embed] });
    setTimeout(() => sent.delete().catch(() => {}), 8000);
  } catch (err) {
    console.error('[LOGGER] Failed to send in-channel warning:', err.message);
  }
}

/**
 * Log a security event: persists to DB, sends embed to guild's log channel,
 * forwards to the global security logs channel, and pushes a realtime
 * update to any connected dashboard clients via Socket.IO.
 */
async function logSecurityEvent(client, guild, { action, user, reason }) {
  const userId = user?.id || 'unknown';
  const userTag = user?.tag || user?.username || 'Unknown User';

  try {
    await addLog(guild.id, action, userId, reason);
  } catch (err) {
    console.error('[LOGGER] Failed to persist log:', err.message);
  }

  const embed = new EmbedBuilder()
    .setColor(0x00d4ff)
    .setTitle('🛡️ Security Log')
    .addFields(
      { name: 'User', value: `${userTag} (${userId})`, inline: true },
      { name: 'Aksi', value: action, inline: true },
      { name: 'Alasan', value: reason || '-', inline: false },
      { name: 'Waktu', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: false }
    )
    .setTimestamp();

  try {
    const settings = await getGuildSettings(guild.id);
    if (settings?.logsChannel) {
      const channel = await guild.channels.fetch(settings.logsChannel).catch(() => null);
      if (channel?.isTextBased()) {
        await channel.send({ embeds: [embed] }).catch(() => {});
      }
    }
  } catch (err) {
    console.error('[LOGGER] Failed to send guild log:', err.message);
  }

  // Global logs to owner's private server
  try {
    if (config.globalLogsChannelId) {
      const globalChannel = await client.channels.fetch(config.globalLogsChannelId).catch(() => null);
      if (globalChannel?.isTextBased()) {
        const globalEmbed = new EmbedBuilder()
          .setColor(0x7c3aed)
          .setTitle('🌐 GLOBAL SECURITY LOG')
          .addFields(
            { name: 'Server', value: `${guild.name}\n${guild.id}`, inline: true },
            { name: 'User', value: `${userTag}\n${userId}`, inline: true },
            { name: 'Pelanggaran', value: action, inline: false },
            { name: 'Waktu', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: false }
          )
          .setTimestamp();
        await globalChannel.send({ embeds: [globalEmbed] }).catch(() => {});
      }
    }
  } catch (err) {
    console.error('[LOGGER] Failed to send global log:', err.message);
  }

  // Realtime dashboard update
  if (ioInstance) {
    ioInstance.to(`guild:${guild.id}`).emit('newLog', {
      guildId: guild.id,
      action,
      userId,
      userTag,
      reason,
      timestamp: Date.now()
    });
  }
}

module.exports = { logSecurityEvent, sendViolationWarning, attachIO };
