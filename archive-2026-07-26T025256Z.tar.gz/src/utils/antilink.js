const LINK_REGEX = /(https?:\/\/[^\s]+)|(discord\.gg\/[^\s]+)|(discord(?:app)?\.com\/invite\/[^\s]+)/i;

function containsLink(content) {
  if (!content) return false;
  return LINK_REGEX.test(content);
}

module.exports = { containsLink };
