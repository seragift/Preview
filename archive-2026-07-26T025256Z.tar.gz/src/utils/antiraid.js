const { THRESHOLD_DEFAULTS } = require('../database/schema');

// guildId -> { joins: number[] }
const guildJoinActivity = new Map();

function getJoinActivity(guildId) {
  if (!guildJoinActivity.has(guildId)) {
    guildJoinActivity.set(guildId, { joins: [] });
  }
  return guildJoinActivity.get(guildId);
}

/**
 * Evaluates a new member join for raid indicators.
 * `settings` is the guild_settings row for this server (per-server thresholds).
 * Returns { raid: boolean, reason: string|null, newAccount: boolean, isBot: boolean }
 */
function checkRaid(guildId, member, settings = null) {
  const now = Date.now();
  const s = settings || {};
  const cfg = {
    joinWindowMs: s.antiraid_joinWindowMs ?? THRESHOLD_DEFAULTS.antiraid_joinWindowMs,
    joinThreshold: s.antiraid_joinThreshold ?? THRESHOLD_DEFAULTS.antiraid_joinThreshold,
    newAccountAgeMs: s.antiraid_newAccountAgeMs ?? THRESHOLD_DEFAULTS.antiraid_newAccountAgeMs
  };
  const activity = getJoinActivity(guildId);

  activity.joins.push(now);
  activity.joins = activity.joins.filter((t) => now - t <= cfg.joinWindowMs);

  const accountAge = now - member.user.createdTimestamp;
  const isNewAccount = accountAge < cfg.newAccountAgeMs;
  const isBot = member.user.bot;

  const massJoin = activity.joins.length >= cfg.joinThreshold;

  let reason = null;
  if (massJoin) {
    reason = `Join massal terdeteksi: ${activity.joins.length} member bergabung dalam ${cfg.joinWindowMs / 1000} detik`;
  } else if (isBot && isNewAccount) {
    reason = 'Bot raid terdeteksi: bot dengan akun baru bergabung';
  } else if (isNewAccount) {
    reason = 'Akun baru terdeteksi bergabung (berpotensi raid)';
  }

  return {
    raid: massJoin || (isBot && isNewAccount),
    reason,
    newAccount: isNewAccount,
    isBot,
    massJoin
  };
}

function resetGuild(guildId) {
  guildJoinActivity.delete(guildId);
}

module.exports = { checkRaid, resetGuild };
