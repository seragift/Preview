const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const fs = require('fs');

// Default values for per-server security thresholds (previously hardcoded in config.json).
// These only seed new rows / migrate old databases; the source of truth at runtime is
// always the guild_settings row in the database, editable per-server via the dashboard's
// Security tab.
const THRESHOLD_DEFAULTS = {
  antinuke_actionThreshold: 3,
  antinuke_actionWindowMs: 10000,
  antispam_windowShortMs: 5000,
  antispam_windowShortCount: 3,
  antispam_windowLongMs: 10000,
  antispam_windowLongCount: 8,
  antispam_multiChannelWindowMs: 10000,
  antispam_multiChannelThreshold: 2,
  antispam_repeatedCharThreshold: 10,
  antispam_mentionThreshold: 5,
  antispam_emojiThreshold: 8,
  antiraid_joinWindowMs: 10000,
  antiraid_joinThreshold: 8,
  antiraid_newAccountAgeMs: 604800000,
  antiraid_lockdownDurationMs: 300000
};

const THRESHOLD_FIELDS = Object.keys(THRESHOLD_DEFAULTS);

const dbDir = path.join(__dirname);
if (!fs.existsSync(dbDir)) fs.mkdirSync(dbDir, { recursive: true });

const dbPath = path.join(dbDir, 'database.sqlite');
const db = new sqlite3.Database(dbPath, (err) => {
  if (err) {
    console.error('[DATABASE] Failed to connect:', err.message);
    process.exit(1);
  }
});

db.serialize(() => {
  db.run('PRAGMA journal_mode = WAL;');
  db.run('PRAGMA foreign_keys = ON;');

  db.run(`
    CREATE TABLE IF NOT EXISTS guild_settings (
      guildId TEXT PRIMARY KEY,
      antinuke INTEGER DEFAULT 0,
      antilink INTEGER DEFAULT 0,
      antitoxic INTEGER DEFAULT 0,
      antispam INTEGER DEFAULT 0,
      antimultichannelspam INTEGER DEFAULT 0,
      antiraid INTEGER DEFAULT 0,
      logsChannel TEXT,
      lockdown INTEGER DEFAULT 0,
      createdAt INTEGER,
      antinuke_actionThreshold INTEGER DEFAULT ${THRESHOLD_DEFAULTS.antinuke_actionThreshold},
      antinuke_actionWindowMs INTEGER DEFAULT ${THRESHOLD_DEFAULTS.antinuke_actionWindowMs},
      antispam_windowShortMs INTEGER DEFAULT ${THRESHOLD_DEFAULTS.antispam_windowShortMs},
      antispam_windowShortCount INTEGER DEFAULT ${THRESHOLD_DEFAULTS.antispam_windowShortCount},
      antispam_windowLongMs INTEGER DEFAULT ${THRESHOLD_DEFAULTS.antispam_windowLongMs},
      antispam_windowLongCount INTEGER DEFAULT ${THRESHOLD_DEFAULTS.antispam_windowLongCount},
      antispam_multiChannelWindowMs INTEGER DEFAULT ${THRESHOLD_DEFAULTS.antispam_multiChannelWindowMs},
      antispam_multiChannelThreshold INTEGER DEFAULT ${THRESHOLD_DEFAULTS.antispam_multiChannelThreshold},
      antispam_repeatedCharThreshold INTEGER DEFAULT ${THRESHOLD_DEFAULTS.antispam_repeatedCharThreshold},
      antispam_mentionThreshold INTEGER DEFAULT ${THRESHOLD_DEFAULTS.antispam_mentionThreshold},
      antispam_emojiThreshold INTEGER DEFAULT ${THRESHOLD_DEFAULTS.antispam_emojiThreshold},
      antiraid_joinWindowMs INTEGER DEFAULT ${THRESHOLD_DEFAULTS.antiraid_joinWindowMs},
      antiraid_joinThreshold INTEGER DEFAULT ${THRESHOLD_DEFAULTS.antiraid_joinThreshold},
      antiraid_newAccountAgeMs INTEGER DEFAULT ${THRESHOLD_DEFAULTS.antiraid_newAccountAgeMs},
      antiraid_lockdownDurationMs INTEGER DEFAULT ${THRESHOLD_DEFAULTS.antiraid_lockdownDurationMs}
    )
  `);

  // ---- Column migration: add threshold columns to a guild_settings table that
  // already existed before these columns were introduced. ----
  db.all('PRAGMA table_info(guild_settings)', [], (err, cols) => {
    if (err) return;
    const existing = new Set((cols || []).map((c) => c.name));
    Object.keys(THRESHOLD_DEFAULTS).forEach((field) => {
      if (!existing.has(field)) {
        db.run(`ALTER TABLE guild_settings ADD COLUMN ${field} INTEGER DEFAULT ${THRESHOLD_DEFAULTS[field]}`, (alterErr) => {
          if (alterErr) console.error(`[DATABASE] Failed to add ${field} column:`, alterErr.message);
          else console.log(`[DATABASE] Migrated: added ${field} column to guild_settings table.`);
        });
      }
    });
  });


  db.run(`
    CREATE TABLE IF NOT EXISTS whitelist (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guildId TEXT,
      type TEXT,
      targetId TEXT,
      feature TEXT DEFAULT 'all',
      createdAt INTEGER
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS security_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guildId TEXT,
      action TEXT,
      userId TEXT,
      reason TEXT,
      timestamp INTEGER
    )
  `);

  // Custom Anti Toxic word list, per guild (in addition to the built-in default list)
  db.run(`
    CREATE TABLE IF NOT EXISTS toxic_words (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guildId TEXT,
      word TEXT,
      createdAt INTEGER
    )
  `);
  db.run('CREATE UNIQUE INDEX IF NOT EXISTS idx_toxic_words_unique ON toxic_words(guildId, word);');
  db.run('CREATE INDEX IF NOT EXISTS idx_toxic_words_guild ON toxic_words(guildId);');

  // Multiple ticket panels per guild (list, editable, deletable independently)
  db.run(`
    CREATE TABLE IF NOT EXISTS ticket_panels (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guildId TEXT,
      panelChannelId TEXT,
      panelMessageId TEXT,
      category TEXT,
      staffRoleId TEXT,
      panelType TEXT DEFAULT 'embed',
      panelTitle TEXT DEFAULT 'Support Ticket',
      panelDescription TEXT DEFAULT 'Klik tombol di bawah untuk membuka ticket.',
      panelEmoji TEXT DEFAULT '🎫',
      panelColor TEXT DEFAULT '#00d4ff',
      welcomeMessage TEXT DEFAULT 'Halo {user}, terima kasih telah membuka ticket. Tim {role} akan segera membantu Anda. Mohon jelaskan kendala Anda secara detail.',
      transcriptChannelId TEXT,
      createdAt INTEGER
    )
  `);

  // Shared ticket-number counter per guild (independent of how many panels exist)
  db.run(`
    CREATE TABLE IF NOT EXISTS ticket_counters (
      guildId TEXT PRIMARY KEY,
      counter INTEGER DEFAULT 0
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS tickets (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guildId TEXT,
      panelId INTEGER,
      channelId TEXT UNIQUE,
      userId TEXT,
      claimedBy TEXT,
      status TEXT DEFAULT 'open',
      createdAt INTEGER,
      closedAt INTEGER,
      closedBy TEXT,
      FOREIGN KEY (panelId) REFERENCES ticket_panels(id) ON DELETE SET NULL
    )
  `);

  // ---- Column migration: CREATE TABLE IF NOT EXISTS above does nothing to
  // an already-existing `tickets` table from before panelId existed, so add
  // it explicitly if it's missing. ----
  db.all('PRAGMA table_info(tickets)', [], (err, cols) => {
    if (err) return;
    const hasPanelId = (cols || []).some((c) => c.name === 'panelId');
    if (!hasPanelId) {
      db.run('ALTER TABLE tickets ADD COLUMN panelId INTEGER', (alterErr) => {
        if (alterErr) console.error('[DATABASE] Failed to add panelId column:', alterErr.message);
        else console.log('[DATABASE] Migrated: added panelId column to tickets table.');
      });
    }
  });

  db.run('CREATE INDEX IF NOT EXISTS idx_whitelist_guild ON whitelist(guildId);');
  db.run('CREATE INDEX IF NOT EXISTS idx_logs_guild ON security_logs(guildId);');
  db.run('CREATE INDEX IF NOT EXISTS idx_tickets_guild ON tickets(guildId);');
  db.run('CREATE INDEX IF NOT EXISTS idx_tickets_channel ON tickets(channelId);');
  db.run('CREATE INDEX IF NOT EXISTS idx_panels_guild ON ticket_panels(guildId);');

  // ---- One-time migration from the old single-panel-per-guild schema ----
  db.all("SELECT name FROM sqlite_master WHERE type='table' AND name='ticket_settings'", [], (err, rows) => {
    if (err || !rows || !rows.length) return;
    db.all('SELECT * FROM ticket_settings', [], (err2, oldRows) => {
      if (err2 || !oldRows) return;
      oldRows.forEach((row) => {
        db.run(
          `INSERT INTO ticket_panels
            (guildId, panelChannelId, panelMessageId, category, staffRoleId, panelType, panelTitle,
             panelDescription, panelEmoji, panelColor, welcomeMessage, transcriptChannelId, createdAt)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [row.guildId, row.panelChannelId, row.panelMessageId, row.category, row.staffRoleId, row.panelType,
            row.panelTitle, row.panelDescription, row.panelEmoji, row.panelColor, row.welcomeMessage,
            row.transcriptChannelId, row.createdAt || Date.now()],
          function (insertErr) {
            if (insertErr) return;
            const newPanelId = this.lastID;
            db.run('INSERT OR IGNORE INTO ticket_counters (guildId, counter) VALUES (?, ?)', [row.guildId, row.ticketCounter || 0]);
            db.run('UPDATE tickets SET panelId = ? WHERE guildId = ? AND panelId IS NULL', [newPanelId, row.guildId]);
          }
        );
      });
      db.run('DROP TABLE IF EXISTS ticket_settings');
    });
  });
});

// ---- Promise helpers (prepared statements under the hood via parameter binding) ----
function dbRun(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function (err) {
      if (err) return reject(err);
      resolve({ lastID: this.lastID, changes: this.changes });
    });
  });
}

function dbGet(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => {
      if (err) return reject(err);
      resolve(row);
    });
  });
}

function dbAll(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.all(sql, params, (err, rows) => {
      if (err) return reject(err);
      resolve(rows);
    });
  });
}

async function getGuildSettings(guildId) {
  let row = await dbGet('SELECT * FROM guild_settings WHERE guildId = ?', [guildId]);
  if (!row) {
    await dbRun(
      'INSERT INTO guild_settings (guildId, createdAt) VALUES (?, ?)',
      [guildId, Date.now()]
    );
    row = await dbGet('SELECT * FROM guild_settings WHERE guildId = ?', [guildId]);
  }
  return row;
}

async function updateGuildSetting(guildId, field, value) {
  const allowed = [
    'antinuke', 'antilink', 'antitoxic', 'antispam',
    'antimultichannelspam', 'antiraid', 'logsChannel', 'lockdown',
    ...THRESHOLD_FIELDS
  ];
  if (!allowed.includes(field)) throw new Error('Invalid field: ' + field);
  await getGuildSettings(guildId); // ensure row exists
  await dbRun(`UPDATE guild_settings SET ${field} = ? WHERE guildId = ?`, [value, guildId]);
  return getGuildSettings(guildId);
}

// ---- Security thresholds (per-server, editable via dashboard) ----
async function updateGuildThresholds(guildId, fields) {
  const setFields = THRESHOLD_FIELDS.filter((f) => fields[f] !== undefined);
  if (!setFields.length) return getGuildSettings(guildId);
  await getGuildSettings(guildId); // ensure row exists
  const setClause = setFields.map((f) => `${f} = ?`).join(', ');
  await dbRun(`UPDATE guild_settings SET ${setClause} WHERE guildId = ?`, [...setFields.map((f) => fields[f]), guildId]);
  return getGuildSettings(guildId);
}

async function setAllSecurity(guildId, state) {
  await getGuildSettings(guildId);
  await dbRun(
    `UPDATE guild_settings
     SET antinuke = ?, antilink = ?, antitoxic = ?, antispam = ?, antimultichannelspam = ?, antiraid = ?
     WHERE guildId = ?`,
    [state, state, state, state, state, state, guildId]
  );
  return getGuildSettings(guildId);
}

async function addWhitelist(guildId, type, targetId, feature = 'all') {
  return dbRun(
    'INSERT INTO whitelist (guildId, type, targetId, feature, createdAt) VALUES (?, ?, ?, ?, ?)',
    [guildId, type, targetId, feature, Date.now()]
  );
}

async function removeWhitelist(guildId, type, targetId) {
  return dbRun(
    'DELETE FROM whitelist WHERE guildId = ? AND type = ? AND targetId = ?',
    [guildId, type, targetId]
  );
}

async function getWhitelist(guildId) {
  return dbAll('SELECT * FROM whitelist WHERE guildId = ?', [guildId]);
}

async function isWhitelisted(guildId, { channelId, roleIds = [], userId }) {
  const rows = await getWhitelist(guildId);
  return rows.some((row) => {
    if (row.type === 'channel' && row.targetId === channelId) return true;
    if (row.type === 'user' && row.targetId === userId) return true;
    if (row.type === 'role' && roleIds.includes(row.targetId)) return true;
    return false;
  });
}

async function addLog(guildId, action, userId, reason) {
  return dbRun(
    'INSERT INTO security_logs (guildId, action, userId, reason, timestamp) VALUES (?, ?, ?, ?, ?)',
    [guildId, action, userId, reason, Date.now()]
  );
}

async function getLogs(guildId, limit = 50, offset = 0) {
  return dbAll(
    'SELECT * FROM security_logs WHERE guildId = ? ORDER BY timestamp DESC LIMIT ? OFFSET ?',
    [guildId, limit, offset]
  );
}

async function countLogs(guildId) {
  const row = await dbGet('SELECT COUNT(*) as c FROM security_logs WHERE guildId = ?', [guildId]);
  return row ? row.c : 0;
}

// ---- Anti Toxic custom word list (per guild) ----
async function listToxicWords(guildId) {
  return dbAll('SELECT * FROM toxic_words WHERE guildId = ? ORDER BY word ASC', [guildId]);
}

async function addToxicWord(guildId, word) {
  return dbRun(
    'INSERT OR IGNORE INTO toxic_words (guildId, word, createdAt) VALUES (?, ?, ?)',
    [guildId, word.toLowerCase().trim(), Date.now()]
  );
}

async function removeToxicWord(guildId, word) {
  return dbRun('DELETE FROM toxic_words WHERE guildId = ? AND word = ?', [guildId, word.toLowerCase().trim()]);
}

// ---- Ticket system (multiple panels per guild) ----
const TICKET_PANEL_FIELDS = [
  'panelChannelId', 'panelMessageId', 'category', 'staffRoleId', 'panelType',
  'panelTitle', 'panelDescription', 'panelEmoji', 'panelColor',
  'welcomeMessage', 'transcriptChannelId'
];

async function listTicketPanels(guildId) {
  return dbAll('SELECT * FROM ticket_panels WHERE guildId = ? ORDER BY id DESC', [guildId]);
}

async function getTicketPanelById(id) {
  return dbGet('SELECT * FROM ticket_panels WHERE id = ?', [id]);
}

async function getTicketPanelByChannelId(channelId) {
  return dbGet('SELECT * FROM ticket_panels WHERE panelChannelId = ?', [channelId]);
}

async function getTicketPanelByMessageId(messageId) {
  return dbGet('SELECT * FROM ticket_panels WHERE panelMessageId = ?', [messageId]);
}

async function createTicketPanel(guildId, fields) {
  const setFields = TICKET_PANEL_FIELDS.filter((f) => fields[f] !== undefined);
  const cols = ['guildId', 'createdAt', ...setFields];
  const vals = [guildId, Date.now(), ...setFields.map((f) => fields[f])];
  const placeholders = cols.map(() => '?').join(', ');
  const { lastID } = await dbRun(`INSERT INTO ticket_panels (${cols.join(', ')}) VALUES (${placeholders})`, vals);
  await dbRun('INSERT OR IGNORE INTO ticket_counters (guildId, counter) VALUES (?, 0)', [guildId]);
  return getTicketPanelById(lastID);
}

async function updateTicketPanel(id, fields) {
  const setFields = TICKET_PANEL_FIELDS.filter((f) => fields[f] !== undefined);
  if (setFields.length) {
    const setClause = setFields.map((f) => `${f} = ?`).join(', ');
    await dbRun(`UPDATE ticket_panels SET ${setClause} WHERE id = ?`, [...setFields.map((f) => fields[f]), id]);
  }
  return getTicketPanelById(id);
}

async function deleteTicketPanel(id) {
  return dbRun('DELETE FROM ticket_panels WHERE id = ?', [id]);
}

async function deleteTicketPanelByChannel(channelId) {
  return dbRun('DELETE FROM ticket_panels WHERE panelChannelId = ?', [channelId]);
}

async function deleteTicketPanelByMessage(messageId) {
  return dbRun('DELETE FROM ticket_panels WHERE panelMessageId = ?', [messageId]);
}

async function nextTicketNumber(guildId) {
  await dbRun('INSERT OR IGNORE INTO ticket_counters (guildId, counter) VALUES (?, 0)', [guildId]);
  await dbRun('UPDATE ticket_counters SET counter = counter + 1 WHERE guildId = ?', [guildId]);
  const row = await dbGet('SELECT counter FROM ticket_counters WHERE guildId = ?', [guildId]);
  return row ? row.counter : 1;
}

async function createTicket(guildId, panelId, channelId, userId) {
  await dbRun(
    'INSERT INTO tickets (guildId, panelId, channelId, userId, status, createdAt) VALUES (?, ?, ?, ?, ?, ?)',
    [guildId, panelId, channelId, userId, 'open', Date.now()]
  );
  return dbGet('SELECT * FROM tickets WHERE channelId = ?', [channelId]);
}

async function deleteTicketByChannel(channelId) {
  return dbRun('DELETE FROM tickets WHERE channelId = ?', [channelId]);
}

async function getTicketByChannel(channelId) {
  return dbGet('SELECT * FROM tickets WHERE channelId = ?', [channelId]);
}

async function claimTicketRow(channelId, staffId) {
  await dbRun('UPDATE tickets SET claimedBy = ?, status = ? WHERE channelId = ?', [staffId, 'claimed', channelId]);
  return getTicketByChannel(channelId);
}

async function closeTicketRow(channelId, closedBy) {
  await dbRun(
    'UPDATE tickets SET status = ?, closedAt = ?, closedBy = ? WHERE channelId = ?',
    ['closed', Date.now(), closedBy, channelId]
  );
  return getTicketByChannel(channelId);
}

async function getOpenTicketByUser(guildId, userId) {
  return dbGet(
    "SELECT * FROM tickets WHERE guildId = ? AND userId = ? AND status != 'closed'",
    [guildId, userId]
  );
}

module.exports = {
  db,
  dbRun,
  dbGet,
  dbAll,
  getGuildSettings,
  updateGuildSetting,
  updateGuildThresholds,
  THRESHOLD_DEFAULTS,
  setAllSecurity,
  addWhitelist,
  removeWhitelist,
  getWhitelist,
  isWhitelisted,
  addLog,
  getLogs,
  countLogs,
  listToxicWords,
  addToxicWord,
  removeToxicWord,
  listTicketPanels,
  getTicketPanelById,
  getTicketPanelByChannelId,
  getTicketPanelByMessageId,
  createTicketPanel,
  updateTicketPanel,
  deleteTicketPanel,
  deleteTicketPanelByChannel,
  deleteTicketPanelByMessage,
  nextTicketNumber,
  createTicket,
  deleteTicketByChannel,
  getTicketByChannel,
  claimTicketRow,
  closeTicketRow,
  getOpenTicketByUser
};
