const { AuditLogEvent } = require('discord.js');
const { getGuildSettings, isWhitelisted } = require('../database/schema');
const { recordAction, punishExecutor } = require('../utils/antinuke');
const { logSecurityEvent } = require('../utils/logger');

module.exports = {
  name: 'guildMemberRemove',
  async execute(member) {
    const guild = member.guild;
    const settings = await getGuildSettings(guild.id).catch(() => null);
    if (!settings) return;

    // Check if this was a kick (audit log entry) for Anti Nuke Mass Kick detection
    if (settings.antinuke) {
      const auditLogs = await guild.fetchAuditLogs({ type: AuditLogEvent.MemberKick, limit: 1 }).catch(() => null);
      const entry = auditLogs?.entries.first();

      if (entry && Date.now() - entry.createdTimestamp <= 5000 && entry.target?.id === member.id) {
        const executor = entry.executor;
        if (executor && executor.id !== guild.ownerId) {
          const whitelisted = await isWhitelisted(guild.id, { userId: executor.id, roleIds: [] });
          if (!whitelisted) {
            const triggered = recordAction(guild.id, executor.id, settings);
            if (triggered) {
              await punishExecutor(guild, executor.id, 'Anti Nuke: Mass Kick terdeteksi');
              await logSecurityEvent(member.client, guild, {
                action: 'Anti Nuke - Mass Kick',
                user: executor,
                reason: `Melakukan kick massal (target terakhir: ${member.user.tag})`
              });
              return;
            }
          }
        }
      }
    }

    await logSecurityEvent(member.client, guild, {
      action: 'Member Left',
      user: member.user,
      reason: 'Member keluar atau di-kick dari server'
    });
  }
};
