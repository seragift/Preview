const { getTicketPanelByMessageId, deleteTicketPanelByMessage } = require('../database/schema');

module.exports = {
  name: 'messageDelete',
  async execute(message) {
    if (!message.guild || !message.id) return;

    // If the deleted message was a ticket panel (embed or plain-message type),
    // its DB row is now pointing at nothing — clean it up.
    const panel = await getTicketPanelByMessageId(message.id).catch(() => null);
    if (panel) await deleteTicketPanelByMessage(message.id).catch(() => {});
  }
};
