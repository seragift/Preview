const { getGuildSettings, isWhitelisted } = require('../database/schema');
const { containsLink } = require('../utils/antilink');
const { containsToxic } = require('../utils/antitoxic');
const { checkSpam } = require('../utils/antispam');
const { logSecurityEvent, sendViolationWarning } = require('../utils/logger');
const { PermissionsBitField } = require('discord.js');

async function safeDelete(message) {
  const botMember = message.guild.members.me;
  if (!botMember?.permissionsIn(message.channel).has(PermissionsBitField.Flags.ManageMessages)) {
    console.warn(
      `[AUTOMOD] Bot tidak punya izin "Manage Messages" di #${message.channel.name} (${message.guild.name}). Pesan tidak bisa dihapus.`
    );
    return false;
  }
  try {
    await message.delete();
    return true;
  } catch (err) {
    console.error('[AUTOMOD] Gagal menghapus pesan:', err.message);
    return false;
  }
}

module.exports = {
  name: 'messageCreate',
  async execute(message) {
    if (!message.guild || message.author.bot) return;

    const settings = await getGuildSettings(message.guild.id).catch(() => null);
    if (!settings) return;

    const anySecurityOn =
      settings.antilink || settings.antitoxic || settings.antispam || settings.antimultichannelspam;
    if (!anySecurityOn) return;

    const member = message.member;
    const roleIds = member ? [...member.roles.cache.keys()] : [];

    const whitelisted = await isWhitelisted(message.guild.id, {
      channelId: message.channel.id,
      roleIds,
      userId: message.author.id
    });
    if (whitelisted) return;

    // Members with Administrator/ManageGuild are exempt from auto-moderation
    if (member?.permissions.has('Administrator') || member?.permissions.has('ManageGuild')) return;

    // --- Anti Link ---
    if (settings.antilink && containsLink(message.content)) {
      const deleted = await safeDelete(message);
      if (deleted) await sendViolationWarning(message.channel, message.author, 'Anti Link');
      await logSecurityEvent(message.client, message.guild, {
        action: 'Anti Link',
        user: message.author,
        reason: 'Mengirim link yang tidak diizinkan'
      });
      return;
    }

    // --- Anti Toxic ---
    if (settings.antitoxic && await containsToxic(message.content, message.guild.id)) {
      const deleted = await safeDelete(message);
      if (deleted) await sendViolationWarning(message.channel, message.author, 'Anti Toxic');
      await logSecurityEvent(message.client, message.guild, {
        action: 'Anti Toxic',
        user: message.author,
        reason: 'Menggunakan kata-kata toxic/tidak pantas'
      });
      return;
    }

    // --- Anti Spam / Anti Multi Channel Spam ---
    if (settings.antispam || settings.antimultichannelspam) {
      const result = checkSpam(message.author.id, message.channel.id, message.content, message.attachments.size, settings);

      if (result.spam) {
        if (result.multiChannel && !settings.antimultichannelspam) return;
        if (!result.multiChannel && !settings.antispam) return;

        const deleted = await safeDelete(message);
        if (deleted) {
          await sendViolationWarning(
            message.channel,
            message.author,
            result.multiChannel ? 'Anti Multi Channel Spam' : 'Anti Spam',
            result.reason
          );
        }

        if (result.multiChannel && member?.moderatable) {
          await member.timeout(10 * 60 * 1000, result.reason).catch(() => {});
        }

        await logSecurityEvent(message.client, message.guild, {
          action: result.multiChannel ? 'Anti Multi Channel Spam' : 'Anti Spam',
          user: message.author,
          reason: result.reason
        });
      }
    }
  }
};
