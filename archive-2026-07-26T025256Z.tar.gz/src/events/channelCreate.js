const { AuditLogEvent } = require('discord.js');
const { getGuildSettings, isWhitelisted } = require('../database/schema');
const { recordAction, punishExecutor } = require('../utils/antinuke');
const { logSecurityEvent } = require('../utils/logger');

module.exports = {
  name: 'channelCreate',
  async execute(channel) {
    if (!channel.guild) return;
    const guild = channel.guild;

    const settings = await getGuildSettings(guild.id).catch(() => null);
    if (!settings || !settings.antinuke) return;

    const auditLogs = await guild.fetchAuditLogs({ type: AuditLogEvent.ChannelCreate, limit: 1 }).catch(() => null);
    const entry = auditLogs?.entries.first();
    if (!entry || Date.now() - entry.createdTimestamp > 5000) return;

    const executor = entry.executor;
    if (!executor || executor.id === guild.ownerId) return;

    const whitelisted = await isWhitelisted(guild.id, { userId: executor.id, roleIds: [] });
    if (whitelisted) return;

    const triggered = recordAction(guild.id, executor.id, settings);
    if (triggered) {
      await punishExecutor(guild, executor.id, 'Anti Nuke: Mass Channel Create terdeteksi');
      await logSecurityEvent(channel.client, guild, {
        action: 'Anti Nuke - Channel Create',
        user: executor,
        reason: `Membuat channel #${channel.name} secara massal`
      });
    }
  }
};
