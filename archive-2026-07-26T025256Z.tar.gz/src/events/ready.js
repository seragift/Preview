const { REST, Routes, ActivityType } = require('discord.js');
const config = require('../../config.json');

module.exports = {
  name: 'ready',
  once: true,
  async execute(client) {
    console.log(`[BOT] Logged in as ${client.user.tag}`);

    client.user.setPresence({
      activities: [{ name: `${client.guilds.cache.size} servers`, type: ActivityType.Watching }],
      status: 'idle'
    });

    // Register global slash commands
    try {
      const commands = client.commands.map((cmd) => cmd.data.toJSON());
      const rest = new REST({ version: '10' }).setToken(config.token || process.env.DISCORD_TOKEN);

      console.log(`[COMMANDS] Registering ${commands.length} global slash commands...`);
      await rest.put(Routes.applicationCommands(config.clientId || process.env.DISCORD_CLIENT_ID), {
        body: commands
      });
      console.log('[COMMANDS] Global slash commands registered successfully.');
    } catch (err) {
      console.error('[COMMANDS] Failed to register slash commands:', err);
    }

    // Keep presence + stats fresh every 5 minutes
    setInterval(() => {
      client.user.setPresence({
        activities: [{ name: `${client.guilds.cache.size} servers`, type: ActivityType.Watching }],
        status: 'idle'
      });
    }, 5 * 60 * 1000);
  }
};
