const { AuditLogEvent } = require('discord.js');
const {
  getGuildSettings,
  isWhitelisted,
  getTicketPanelByChannelId,
  deleteTicketPanelByChannel,
  getTicketByChannel,
  deleteTicketByChannel
} = require('../database/schema');
const { recordAction, punishExecutor } = require('../utils/antinuke');
const { logSecurityEvent } = require('../utils/logger');

module.exports = {
  name: 'channelDelete',
  async execute(channel) {
    if (!channel.guild) return;
    const guild = channel.guild;

    // ---- Ticket data cleanup: always runs, regardless of antinuke state ----
    // If the deleted channel was hosting a ticket panel, its DB config is now orphaned — remove it.
    const panel = await getTicketPanelByChannelId(channel.id).catch(() => null);
    if (panel) await deleteTicketPanelByChannel(channel.id).catch(() => {});

    // If the deleted channel was an open/closed ticket channel itself, drop its DB row too.
    const ticket = await getTicketByChannel(channel.id).catch(() => null);
    if (ticket) await deleteTicketByChannel(channel.id).catch(() => {});

    const settings = await getGuildSettings(guild.id).catch(() => null);
    if (!settings || !settings.antinuke) return;

    const auditLogs = await guild.fetchAuditLogs({ type: AuditLogEvent.ChannelDelete, limit: 1 }).catch(() => null);
    const entry = auditLogs?.entries.first();
    if (!entry || Date.now() - entry.createdTimestamp > 5000) return;

    const executor = entry.executor;
    if (!executor || executor.id === guild.ownerId) return;

    const whitelisted = await isWhitelisted(guild.id, { userId: executor.id, roleIds: [] });
    if (whitelisted) return;

    const triggered = recordAction(guild.id, executor.id, settings);
    if (triggered) {
      await punishExecutor(guild, executor.id, 'Anti Nuke: Mass Channel Delete terdeteksi');
      await logSecurityEvent(channel.client, guild, {
        action: 'Anti Nuke - Channel Delete',
        user: executor,
        reason: `Menghapus channel #${channel.name} secara massal`
      });
    }
  }
};
