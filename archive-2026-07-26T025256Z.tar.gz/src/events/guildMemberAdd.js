const { PermissionFlagsBits } = require('discord.js');
const { getGuildSettings } = require('../database/schema');
const { checkRaid } = require('../utils/antiraid');
const { logSecurityEvent } = require('../utils/logger');

module.exports = {
  name: 'guildMemberAdd',
  async execute(member) {
    const settings = await getGuildSettings(member.guild.id).catch(() => null);
    if (!settings || !settings.antiraid) return;

    const result = checkRaid(member.guild.id, member, settings);

    if (result.raid) {
      // Kick the suspicious member unless already gone
      if (member.kickable) {
        await member.kick('Terdeteksi sebagai bagian dari raid').catch(() => {});
      }

      await logSecurityEvent(member.client, member.guild, {
        action: 'Anti Raid',
        user: member.user,
        reason: result.reason
      });

      // Trigger temporary lockdown on mass join
      if (result.massJoin && !settings.lockdown) {
        const { updateGuildSetting } = require('../database/schema');
        await updateGuildSetting(member.guild.id, 'lockdown', 1);

        try {
          const everyoneRole = member.guild.roles.everyone;
          await everyoneRole.setPermissions(
            everyoneRole.permissions.remove(PermissionFlagsBits.CreateInstantInvite)
          ).catch(() => {});
        } catch (err) {
          console.error('[ANTIRAID] Lockdown failed:', err.message);
        }

        const { THRESHOLD_DEFAULTS } = require('../database/schema');
        const lockdownDurationMs = settings.antiraid_lockdownDurationMs ?? THRESHOLD_DEFAULTS.antiraid_lockdownDurationMs;
        setTimeout(async () => {
          await updateGuildSetting(member.guild.id, 'lockdown', 0).catch(() => {});
        }, lockdownDurationMs);
      }
    }
  }
};
