const { AuditLogEvent } = require('discord.js');
const { getGuildSettings, isWhitelisted } = require('../database/schema');
const { recordAction, punishExecutor } = require('../utils/antinuke');
const { logSecurityEvent } = require('../utils/logger');

module.exports = {
  name: 'webhooksUpdate',
  async execute(channel) {
    const guild = channel.guild;
    if (!guild) return;

    const settings = await getGuildSettings(guild.id).catch(() => null);
    if (!settings || !settings.antinuke) return;

    const auditLogs = await guild
      .fetchAuditLogs({ type: AuditLogEvent.WebhookCreate, limit: 1 })
      .catch(() => null);
    const createEntry = auditLogs?.entries.first();

    const auditLogsDelete = await guild
      .fetchAuditLogs({ type: AuditLogEvent.WebhookDelete, limit: 1 })
      .catch(() => null);
    const deleteEntry = auditLogsDelete?.entries.first();

    const entry = [createEntry, deleteEntry]
      .filter(Boolean)
      .sort((a, b) => b.createdTimestamp - a.createdTimestamp)[0];

    if (!entry || Date.now() - entry.createdTimestamp > 5000) return;

    const executor = entry.executor;
    if (!executor || executor.id === guild.ownerId) return;

    const whitelisted = await isWhitelisted(guild.id, { userId: executor.id, roleIds: [] });
    if (whitelisted) return;

    const actionName = entry === createEntry ? 'Webhook Create' : 'Webhook Delete';

    const triggered = recordAction(guild.id, executor.id, settings);
    if (triggered) {
      await punishExecutor(guild, executor.id, `Anti Nuke: Mass ${actionName} terdeteksi`);
      await logSecurityEvent(guild.client, guild, {
        action: `Anti Nuke - ${actionName}`,
        user: executor,
        reason: `${actionName} terdeteksi secara massal di #${channel.name}`
      });
    }
  }
};
