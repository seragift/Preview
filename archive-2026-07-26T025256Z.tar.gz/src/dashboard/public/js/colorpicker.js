/**
 * Lightweight color picker widget: SV box + hue slider + hex/RGB inputs + swatches.
 * No dependencies. Attaches to any text input holding a "#rrggbb" value.
 *
 * Usage:
 *   attachColorPicker(triggerButtonEl, textInputEl, mountEl, { onChange(hex) {} });
 */
(function () {
  const PRESETS = [
    '#ED4245', '#E67E22', '#FEE75C', '#8B5A2B', '#57F287', '#2E7D32',
    '#EB459E', '#9B59B6', '#3498DB', '#1ABC9C', '#95E5C4', '#000000',
    '#5C5F66', '#99AAB5', '#FFFFFF'
  ];

  function clamp(v, min, max) { return Math.min(max, Math.max(min, v)); }

  function hexToRgb(hex) {
    const clean = (hex || '').replace('#', '').trim();
    if (!/^[0-9a-f]{6}$/i.test(clean)) return null;
    return {
      r: parseInt(clean.slice(0, 2), 16),
      g: parseInt(clean.slice(2, 4), 16),
      b: parseInt(clean.slice(4, 6), 16)
    };
  }

  function rgbToHex(r, g, b) {
    const toHex = (n) => clamp(Math.round(n), 0, 255).toString(16).padStart(2, '0');
    return `#${toHex(r)}${toHex(g)}${toHex(b)}`.toLowerCase();
  }

  function rgbToHsv(r, g, b) {
    r /= 255; g /= 255; b /= 255;
    const max = Math.max(r, g, b), min = Math.min(r, g, b);
    const d = max - min;
    let h = 0;
    if (d !== 0) {
      if (max === r) h = ((g - b) / d) % 6;
      else if (max === g) h = (b - r) / d + 2;
      else h = (r - g) / d + 4;
      h *= 60;
      if (h < 0) h += 360;
    }
    const s = max === 0 ? 0 : d / max;
    const v = max;
    return { h, s, v };
  }

  function hsvToRgb(h, s, v) {
    const c = v * s;
    const x = c * (1 - Math.abs(((h / 60) % 2) - 1));
    const m = v - c;
    let r, g, b;
    if (h < 60) { r = c; g = x; b = 0; }
    else if (h < 120) { r = x; g = c; b = 0; }
    else if (h < 180) { r = 0; g = c; b = x; }
    else if (h < 240) { r = 0; g = x; b = c; }
    else if (h < 300) { r = x; g = 0; b = c; }
    else { r = c; g = 0; b = x; }
    return { r: (r + m) * 255, g: (g + m) * 255, b: (b + m) * 255 };
  }

  function attachColorPicker(triggerEl, inputEl, mountEl, opts = {}) {
    const onChange = opts.onChange || (() => {});
    const defaultHex = opts.defaultHex || '#00d4ff';

    let state = hexToRgb(inputEl.value) || hexToRgb(defaultHex);
    let hsv = rgbToHsv(state.r, state.g, state.b);
    let open = false;

    // ---- Build DOM ----
    const panel = document.createElement('div');
    panel.className = 'cp-panel hidden';
    panel.innerHTML = `
      <canvas class="cp-sv" width="220" height="150"></canvas>
      <div class="cp-sv-cursor"></div>
      <div class="cp-hue-wrap">
        <canvas class="cp-hue" width="220" height="14"></canvas>
        <div class="cp-hue-cursor"></div>
      </div>
      <div class="cp-fields">
        <div class="cp-field cp-field-hex"><input maxlength="7" /><label>Hex</label></div>
        <div class="cp-field"><input maxlength="3" /><label>R</label></div>
        <div class="cp-field"><input maxlength="3" /><label>G</label></div>
        <div class="cp-field"><input maxlength="3" /><label>B</label></div>
      </div>
      <div class="cp-swatches"></div>
      <div class="cp-actions">
        <button type="button" class="cp-clear">Clear</button>
        <button type="button" class="cp-hide">Hide</button>
      </div>
    `;
    // Portaled onto <body> (not mountEl) so position:fixed works correctly
    // regardless of ancestor stacking contexts (see .cp-panel CSS comment).
    document.body.appendChild(panel);

    const svCanvas = panel.querySelector('.cp-sv');
    const svCtx = svCanvas.getContext('2d');
    const svCursor = panel.querySelector('.cp-sv-cursor');
    const hueCanvas = panel.querySelector('.cp-hue');
    const hueCtx = hueCanvas.getContext('2d');
    const hueCursor = panel.querySelector('.cp-hue-cursor');
    const [hexField, rField, gField, bField] = panel.querySelectorAll('.cp-field input');
    const swatchesEl = panel.querySelector('.cp-swatches');
    const clearBtn = panel.querySelector('.cp-clear');
    const hideBtn = panel.querySelector('.cp-hide');

    swatchesEl.innerHTML = PRESETS.map((c) => `<button type="button" class="cp-swatch" style="background:${c}" data-hex="${c}"></button>`).join('');

    function drawHue() {
      const grad = hueCtx.createLinearGradient(0, 0, hueCanvas.width, 0);
      for (let i = 0; i <= 6; i++) {
        const rgb = hsvToRgb(i * 60, 1, 1);
        grad.addColorStop(i / 6, `rgb(${rgb.r | 0},${rgb.g | 0},${rgb.b | 0})`);
      }
      hueCtx.fillStyle = grad;
      hueCtx.fillRect(0, 0, hueCanvas.width, hueCanvas.height);
    }

    function drawSV() {
      const hueRgb = hsvToRgb(hsv.h, 1, 1);
      svCtx.fillStyle = `rgb(${hueRgb.r | 0},${hueRgb.g | 0},${hueRgb.b | 0})`;
      svCtx.fillRect(0, 0, svCanvas.width, svCanvas.height);

      const whiteGrad = svCtx.createLinearGradient(0, 0, svCanvas.width, 0);
      whiteGrad.addColorStop(0, 'rgba(255,255,255,1)');
      whiteGrad.addColorStop(1, 'rgba(255,255,255,0)');
      svCtx.fillStyle = whiteGrad;
      svCtx.fillRect(0, 0, svCanvas.width, svCanvas.height);

      const blackGrad = svCtx.createLinearGradient(0, 0, 0, svCanvas.height);
      blackGrad.addColorStop(0, 'rgba(0,0,0,0)');
      blackGrad.addColorStop(1, 'rgba(0,0,0,1)');
      svCtx.fillStyle = blackGrad;
      svCtx.fillRect(0, 0, svCanvas.width, svCanvas.height);
    }

    function positionCursors() {
      svCursor.style.left = `${hsv.s * svCanvas.width}px`;
      svCursor.style.top = `${(1 - hsv.v) * svCanvas.height}px`;
      hueCursor.style.left = `${(hsv.h / 360) * hueCanvas.width}px`;
    }

    function updateSwatchButton() {
      const hex = rgbToHex(state.r, state.g, state.b);
      if (triggerEl) triggerEl.style.background = hex;
    }

    function updateFields() {
      const hex = rgbToHex(state.r, state.g, state.b);
      hexField.value = hex;
      rField.value = Math.round(state.r);
      gField.value = Math.round(state.g);
      bField.value = Math.round(state.b);
      updateSwatchButton();
    }

    function commit(hex) {
      inputEl.value = hex;
      onChange(hex);
    }

    function setFromRgb(r, g, b, { silent } = {}) {
      state = { r, g, b };
      hsv = rgbToHsv(r, g, b);
      drawSV();
      positionCursors();
      updateFields();
      if (!silent) commit(rgbToHex(r, g, b));
    }

    function setFromHsv(h, s, v) {
      hsv = { h, s, v };
      const rgb = hsvToRgb(h, s, v);
      state = rgb;
      drawSV();
      positionCursors();
      updateFields();
      commit(rgbToHex(rgb.r, rgb.g, rgb.b));
    }

    function svPointerHandler(e) {
      const rect = svCanvas.getBoundingClientRect();
      const clientX = e.touches ? e.touches[0].clientX : e.clientX;
      const clientY = e.touches ? e.touches[0].clientY : e.clientY;
      const s = clamp((clientX - rect.left) / rect.width, 0, 1);
      const v = 1 - clamp((clientY - rect.top) / rect.height, 0, 1);
      setFromHsv(hsv.h, s, v);
    }

    function huePointerHandler(e) {
      const rect = hueCanvas.getBoundingClientRect();
      const clientX = e.touches ? e.touches[0].clientX : e.clientX;
      const h = clamp((clientX - rect.left) / rect.width, 0, 1) * 360;
      setFromHsv(h, hsv.s, hsv.v);
    }

    function bindDrag(el, handler) {
      let dragging = false;
      const move = (e) => { if (dragging) { handler(e); e.preventDefault(); } };
      const start = (e) => { dragging = true; handler(e); };
      const end = () => { dragging = false; };
      el.addEventListener('mousedown', start);
      el.addEventListener('touchstart', start, { passive: true });
      window.addEventListener('mousemove', move);
      window.addEventListener('touchmove', move, { passive: false });
      window.addEventListener('mouseup', end);
      window.addEventListener('touchend', end);
    }

    bindDrag(svCanvas, svPointerHandler);
    bindDrag(hueCanvas, huePointerHandler);

    hexField.addEventListener('change', () => {
      const rgb = hexToRgb(hexField.value);
      if (!rgb) { updateFields(); return; }
      setFromRgb(rgb.r, rgb.g, rgb.b);
    });

    [rField, gField, bField].forEach((field, idx) => {
      field.addEventListener('change', () => {
        const n = clamp(parseInt(field.value, 10) || 0, 0, 255);
        const next = { r: state.r, g: state.g, b: state.b };
        if (idx === 0) next.r = n; else if (idx === 1) next.g = n; else next.b = n;
        setFromRgb(next.r, next.g, next.b);
      });
    });

    swatchesEl.querySelectorAll('.cp-swatch').forEach((btn) => {
      btn.addEventListener('click', () => {
        const rgb = hexToRgb(btn.dataset.hex);
        if (rgb) setFromRgb(rgb.r, rgb.g, rgb.b);
      });
    });

    clearBtn.addEventListener('click', () => {
      const rgb = hexToRgb(defaultHex);
      setFromRgb(rgb.r, rgb.g, rgb.b);
    });

    hideBtn.addEventListener('click', () => togglePanel(false));

    function positionPanel() {
      if (!triggerEl) return;
      const rect = triggerEl.getBoundingClientRect();
      const panelWidth = 240;
      const maxHeight = 420;
      const spaceBelow = window.innerHeight - rect.bottom;
      const spaceRight = window.innerWidth - rect.right;

      // Align right edge of panel to right edge of trigger by default, but
      // keep it on-screen if that would push it off the left edge.
      let left = rect.right - panelWidth;
      if (left < 8) left = Math.max(8, rect.left);
      if (left + panelWidth > window.innerWidth - 8) left = window.innerWidth - panelWidth - 8;
      panel.style.left = `${left}px`;

      if (spaceBelow < 300 && rect.top > spaceBelow) {
        panel.style.top = 'auto';
        panel.style.bottom = `${window.innerHeight - rect.top + 8}px`;
      } else {
        panel.style.bottom = 'auto';
        panel.style.top = `${rect.bottom + 8}px`;
      }
    }

    function togglePanel(force) {
      open = typeof force === 'boolean' ? force : !open;
      panel.classList.toggle('hidden', !open);
      if (open) { positionPanel(); drawHue(); drawSV(); positionCursors(); updateFields(); }
    }

    if (triggerEl) triggerEl.addEventListener('click', (e) => { e.stopPropagation(); togglePanel(); });
    document.addEventListener('click', (e) => {
      if (open && !panel.contains(e.target) && e.target !== triggerEl) togglePanel(false);
    });

    // Page scroll would leave the fixed panel floating in the wrong spot
    // (it doesn't move with the trigger), so close it — but ignore scrolls
    // that originate from inside the panel itself (e.g. if content inside
    // ever becomes scrollable), same guard as the dropdown fix.
    window.addEventListener('scroll', (e) => {
      if (!open) return;
      if (e.target === panel || panel.contains(e.target)) return;
      togglePanel(false);
    }, true);
    window.addEventListener('resize', () => { if (open) positionPanel(); });

    inputEl.addEventListener('change', () => {
      const rgb = hexToRgb(inputEl.value);
      if (rgb) setFromRgb(rgb.r, rgb.g, rgb.b, { silent: true });
    });

    // Public API so callers can sync the widget when the underlying input is
    // populated programmatically (e.g. loading a panel into the edit form).
    return {
      setHex(hex) {
        const rgb = hexToRgb(hex);
        if (rgb) setFromRgb(rgb.r, rgb.g, rgb.b, { silent: true });
      },
      close() { togglePanel(false); }
    };
  }

  window.attachColorPicker = attachColorPicker;
})();
