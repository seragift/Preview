(function () {
  const guildId = window.__GUILD_ID__;
  const socket = io();
  socket.emit('joinGuild', guildId);

  let csrfToken = null;
  async function getCsrfToken() {
    if (csrfToken) return csrfToken;
    const res = await fetch('/api/csrf-token');
    const data = await res.json();
    csrfToken = data.csrfToken;
    return csrfToken;
  }

  async function apiMutate(url, options = {}) {
    const token = await getCsrfToken();
    return fetch(url, {
      ...options,
      headers: {
        ...(options.headers || {}),
        'CSRF-Token': token
      }
    });
  }

  const SECURITY_META = {
    antinuke: { label: 'Anti Nuke', icon: '💥', desc: 'Cegah aksi berbahaya massal: hapus channel/role atau ban member secara mendadak dalam jumlah besar.' },
    antilink: { label: 'Anti Link', icon: '🔗', desc: 'Otomatis hapus link mencurigakan yang dikirim member di chat.' },
    antitoxic: { label: 'Anti Toxic', icon: '🤬', desc: 'Deteksi dan filter kata-kata toxic atau kasar secara otomatis.' },
    antispam: { label: 'Anti Spam', icon: '⚡', desc: 'Cegah member mengirim pesan bertubi-tubi dalam waktu singkat.' },
    antimultichannelspam: { label: 'Anti Multi Channel Spam', icon: '📡', desc: 'Cegah pesan yang sama disebar ke banyak channel sekaligus.' },
    antiraid: { label: 'Anti Raid', icon: '🚨', desc: 'Deteksi dan cegah serangan raid saat banyak akun baru join bersamaan.' }
  };

  // Threshold fields shown inside each card's expandable settings panel.
  // unit: how the raw ms value from the DB is displayed/edited in the UI.
  const SECURITY_CONFIG_FIELDS = {
    antinuke: [
      { key: 'antinuke_actionThreshold', label: 'Ambang Aksi (kali)', unit: null, min: 1, max: 50 },
      { key: 'antinuke_actionWindowMs', label: 'Rentang Waktu (detik)', unit: 'seconds', min: 1, max: 600 }
    ],
    antispam: [
      { key: 'antispam_windowShortCount', label: 'Pesan (jangka pendek)', unit: null, min: 1, max: 50 },
      { key: 'antispam_windowShortMs', label: 'Rentang Waktu Pendek (detik)', unit: 'seconds', min: 1, max: 60 },
      { key: 'antispam_windowLongCount', label: 'Pesan (jangka panjang)', unit: null, min: 1, max: 100 },
      { key: 'antispam_windowLongMs', label: 'Rentang Waktu Panjang (detik)', unit: 'seconds', min: 1, max: 300 },
      { key: 'antispam_mentionThreshold', label: 'Ambang Mention', unit: null, min: 1, max: 50 },
      { key: 'antispam_emojiThreshold', label: 'Ambang Emoji', unit: null, min: 1, max: 50 },
      { key: 'antispam_repeatedCharThreshold', label: 'Ambang Huruf Berulang', unit: null, min: 2, max: 100 }
    ],
    antimultichannelspam: [
      { key: 'antispam_multiChannelThreshold', label: 'Ambang Jumlah Channel', unit: null, min: 1, max: 20 },
      { key: 'antispam_multiChannelWindowMs', label: 'Rentang Waktu (detik)', unit: 'seconds', min: 1, max: 120 }
    ],
    antiraid: [
      { key: 'antiraid_joinThreshold', label: 'Ambang Join Massal (member)', unit: null, min: 1, max: 100 },
      { key: 'antiraid_joinWindowMs', label: 'Rentang Waktu Join (detik)', unit: 'seconds', min: 1, max: 300 },
      { key: 'antiraid_newAccountAgeMs', label: 'Umur Akun Baru (hari)', unit: 'days', min: 0, max: 365 },
      { key: 'antiraid_lockdownDurationMs', label: 'Durasi Lockdown (menit)', unit: 'minutes', min: 0, max: 1440 }
    ]
    // antitoxic has its own word-list panel (rendered separately, not numeric fields)
  };
  const THRESHOLD_UNIT_DIVISOR = { seconds: 1000, minutes: 60000, days: 86400000 };

  let currentLogsPage = 1;
  let currentMembersPage = 1;
  let currentMemberSearch = '';
  let searchDebounce = null;

  // ---- Toast notifications (replaces native alert()) ----
  function ensureToastContainer() {
    return document.getElementById('toast-container');
  }

  function toast(message, type = 'info', duration = 3500) {
    const container = ensureToastContainer();
    if (!container) return;
    const icons = { success: '✅', error: '⚠️', info: 'ℹ️' };
    const el = document.createElement('div');
    el.className = `toast toast-${type}`;
    el.innerHTML = `<span class="flex-shrink-0">${icons[type] || icons.info}</span><span class="flex-1">${message}</span>`;
    container.appendChild(el);

    const remove = () => {
      el.classList.add('toast-out');
      setTimeout(() => el.remove(), 180);
    };
    const timer = setTimeout(remove, duration);
    el.addEventListener('click', () => { clearTimeout(timer); remove(); });
  }

  // ---- Confirm modal (replaces native confirm()) ----
  function confirmDialog(message) {
    const backdrop = document.getElementById('confirm-modal-backdrop');
    const modal = document.getElementById('confirm-modal');
    if (!backdrop || !modal) return Promise.resolve(window.confirm(message));

    return new Promise((resolve) => {
      document.getElementById('confirm-modal-message').textContent = message;
      backdrop.classList.remove('hidden');
      backdrop.classList.add('flex');
      requestAnimationFrame(() => {
        backdrop.style.opacity = '1';
        modal.style.opacity = '1';
        modal.classList.remove('scale-95');
        modal.classList.add('scale-100');
      });

      const okBtn = document.getElementById('confirm-modal-ok');
      const cancelBtn = document.getElementById('confirm-modal-cancel');

      function cleanup(result) {
        modal.style.opacity = '0';
        modal.classList.add('scale-95');
        modal.classList.remove('scale-100');
        backdrop.style.opacity = '0';
        setTimeout(() => {
          backdrop.classList.add('hidden');
          backdrop.classList.remove('flex');
        }, 180);
        okBtn.removeEventListener('click', onOk);
        cancelBtn.removeEventListener('click', onCancel);
        resolve(result);
      }
      function onOk() { cleanup(true); }
      function onCancel() { cleanup(false); }

      okBtn.addEventListener('click', onOk);
      cancelBtn.addEventListener('click', onCancel);
    });
  }

  // ---- Custom dropdown (progressively enhances <select> so mobile never
  // falls back to the ugly native OS picker sheet). The underlying <select>
  // stays in the DOM (hidden) as the single source of truth: its .value and
  // 'change' event keep working exactly as before, so existing code doesn't
  // need to change. Call syncDropdownOptions(select) any time its innerHTML
  // is repopulated dynamically. ----
  function enhanceDropdown(select, placeholder) {
    if (!select || select.dataset.enhanced) return select && select._dropdownApi;
    select.dataset.enhanced = 'true';

    const wrapper = document.createElement('div');
    wrapper.className = 'dropdown';
    select.parentNode.insertBefore(wrapper, select);

    const trigger = document.createElement('button');
    trigger.type = 'button';
    trigger.className = 'dropdown-trigger';
    trigger.innerHTML = `<span class="dropdown-label"></span><svg class="dropdown-chevron w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 9l6 6 6-6"/></svg>`;

    // The panel is portaled directly onto <body> (position: fixed) instead of
    // living inside the wrapper. Cards on this page use .glass, which sets
    // backdrop-filter — that creates a new CSS stacking context, so a
    // descendant's z-index (however high) can never paint above a *later*
    // sibling .glass card. Portaling escapes that entirely. Position is
    // computed from the trigger's bounding rect each time it opens.
    const panel = document.createElement('div');
    panel.className = 'dropdown-panel';
    document.body.appendChild(panel);

    wrapper.appendChild(trigger);
    wrapper.appendChild(select);

    function buildOptions() {
      panel.innerHTML = '';
      const opts = Array.from(select.options);
      if (opts.length === 0) {
        panel.innerHTML = '<div class="dropdown-empty">Tidak ada opsi</div>';
        return;
      }
      opts.forEach((opt) => {
        const item = document.createElement('div');
        item.className = 'dropdown-option' + (opt.value === select.value ? ' selected' : '');
        item.textContent = opt.textContent;
        item.addEventListener('click', () => {
          if (select.value !== opt.value) {
            select.value = opt.value;
            select.dispatchEvent(new Event('change', { bubbles: true }));
          }
          updateTriggerLabel();
          panel.querySelectorAll('.dropdown-option').forEach((o) => o.classList.remove('selected'));
          item.classList.add('selected');
          closeDropdown();
        });
        panel.appendChild(item);
      });
    }

    function updateTriggerLabel() {
      const selectedOpt = select.options[select.selectedIndex];
      const label = trigger.querySelector('.dropdown-label');
      if (selectedOpt) {
        label.textContent = selectedOpt.textContent;
        label.classList.remove('placeholder');
      } else {
        label.textContent = placeholder || 'Pilih...';
        label.classList.add('placeholder');
      }
    }

    function positionPanel() {
      const rect = trigger.getBoundingClientRect();
      const maxHeight = 260;
      const spaceBelow = window.innerHeight - rect.bottom;
      panel.style.left = `${rect.left}px`;
      panel.style.width = `${rect.width}px`;
      if (spaceBelow < maxHeight && rect.top > spaceBelow) {
        panel.style.top = 'auto';
        panel.style.bottom = `${window.innerHeight - rect.top + 6}px`;
        panel.style.maxHeight = `${Math.max(rect.top - 12, 120)}px`;
      } else {
        panel.style.bottom = 'auto';
        panel.style.top = `${rect.bottom + 6}px`;
        panel.style.maxHeight = `${Math.min(maxHeight, spaceBelow - 12)}px`;
      }
    }

    function openDropdown() {
      document.querySelectorAll('.dropdown.open').forEach((d) => {
        if (d !== wrapper) { d.classList.remove('open'); if (d._panel) d._panel.classList.remove('open'); }
      });
      positionPanel();
      wrapper.classList.add('open');
      panel.classList.add('open');
    }
    function closeDropdown() {
      wrapper.classList.remove('open');
      panel.classList.remove('open');
    }

    trigger.addEventListener('click', (e) => {
      e.stopPropagation();
      wrapper.classList.contains('open') ? closeDropdown() : openDropdown();
    });

    // Scrolling the PAGE while open would leave the fixed panel floating in
    // the wrong spot (it doesn't move with the trigger), so close it then.
    // But this listener uses capture:true, so it also sees scroll events
    // bubbling up (in the capture phase) from the panel's own internal
    // scrollbar (options list has overflow-y: auto) — without the guard
    // below, simply scrolling through a long options list would instantly
    // close the dropdown.
    window.addEventListener('scroll', (e) => {
      if (!wrapper.classList.contains('open')) return;
      if (e.target === panel || panel.contains(e.target)) return;
      closeDropdown();
    }, true);
    window.addEventListener('resize', () => { if (wrapper.classList.contains('open')) positionPanel(); });

    buildOptions();
    updateTriggerLabel();

    wrapper._panel = panel;
    const api = { refresh() { buildOptions(); updateTriggerLabel(); }, close: closeDropdown };
    select._dropdownApi = api;
    return api;
  }

  function syncDropdownOptions(select) {
    if (select && select._dropdownApi) select._dropdownApi.refresh();
  }

  document.addEventListener('click', (e) => {
    document.querySelectorAll('.dropdown.open').forEach((d) => {
      const panel = d._panel;
      if (!d.contains(e.target) && !(panel && panel.contains(e.target))) {
        d.classList.remove('open');
        if (panel) panel.classList.remove('open');
      }
    });
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      document.querySelectorAll('.dropdown.open').forEach((d) => {
        d.classList.remove('open');
        if (d._panel) d._panel.classList.remove('open');
      });
    }
  });

  // ---- Mobile sidebar toggle ----
  const sidebar = document.getElementById('sidebar');
  const backdrop = document.getElementById('sidebar-backdrop');
  const sidebarToggle = document.getElementById('sidebar-toggle');

  function openSidebar() {
    sidebar.classList.add('open');
    backdrop.classList.remove('hidden');
    requestAnimationFrame(() => {
      backdrop.style.opacity = '1';
      backdrop.style.backdropFilter = 'blur(6px)';
      backdrop.style.webkitBackdropFilter = 'blur(6px)';
    });
  }
  function closeSidebar() {
    sidebar.classList.remove('open');
    backdrop.style.opacity = '0';
    backdrop.style.backdropFilter = 'blur(0px)';
    backdrop.style.webkitBackdropFilter = 'blur(0px)';
    setTimeout(() => backdrop.classList.add('hidden'), 300);
  }
  if (sidebarToggle) sidebarToggle.addEventListener('click', openSidebar);
  if (backdrop) backdrop.addEventListener('click', closeSidebar);

  // ---- Tab switching ----
  document.querySelectorAll('.nav-item').forEach((btn) => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.nav-item').forEach((b) => b.classList.remove('active'));
      btn.classList.add('active');
      document.querySelectorAll('.tab-section').forEach((s) => { s.classList.add('hidden'); s.classList.remove('tab-visible'); });
      document.querySelectorAll('.dropdown.open').forEach((d) => { d.classList.remove('open'); if (d._panel) d._panel.classList.remove('open'); });
      const tab = btn.dataset.tab;
      const section = document.getElementById('tab-' + tab);
      section.classList.remove('hidden');
      // force reflow so the fade-in animation replays every time
      void section.offsetWidth;
      section.classList.add('tab-visible');

      closeSidebar();

      if (tab === 'overview') { loadOverview(); loadOwnerInfo('ov-owner'); loadOverviewMembers(1, ''); }
      if (tab === 'botinfo') loadBotInfo();
      if (tab === 'security') loadSecurity();
      if (tab === 'logs') { loadLogs(1); loadSettings(); loadWhitelistOptions().then(loadWhitelist); }
      if (tab === 'announcement') loadAnnouncementOptions();
      if (tab === 'ticket') loadTicketOptions();
      if (tab === 'members') { loadOwnerInfo('members-owner'); loadMembers(1, ''); }
      if (tab === 'botsettings') loadBotProfile();
    });
  });

  // ---- Owner info (shown in Overview + Members) ----
  let ownerId = null;
  async function loadOwnerInfo(targetId) {
    const el = document.getElementById(targetId);
    if (!el) return;
    try {
      const res = await fetch(`/api/guild/${guildId}/owner`);
      if (!res.ok) { el.textContent = '-'; return; }
      const owner = await res.json();
      el.textContent = owner.tag;
      ownerId = owner.id;
    } catch (err) {
      el.textContent = '-';
    }
  }

  // ---- Overview (guild-scoped stats only) ----
  async function loadOverview() {
    const res = await fetch(`/api/guild/${guildId}/overview`);
    if (!res.ok) return;
    const data = await res.json();
    document.getElementById('ov-members').textContent = data.memberCount;
    document.getElementById('ov-bots').textContent = data.botCount;
    document.getElementById('ov-members-online').textContent = data.onlineMembers;
    document.getElementById('ov-channels').textContent = data.channelCount;
    document.getElementById('ov-roles').textContent = data.roleCount;
    document.getElementById('ov-admin-roles').textContent = data.adminRoleCount;
  }

  // ---- Bot Info (global stats, not tied to a single server) ----
  async function loadBotInfo() {
    try {
      const res = await fetch('/api/bot/info');
      if (!res.ok) return;
      const data = await res.json();

      document.getElementById('bi-avatar').src = data.botAvatar || '';
      document.getElementById('bi-name').textContent = data.botName || '-';
      document.getElementById('bi-tag').textContent = data.botTag || '';

      if (data.owner) {
        document.getElementById('bi-owner-avatar').src = data.owner.avatar || '';
        document.getElementById('bi-owner-name').textContent = data.owner.username || '-';
        document.getElementById('bi-owner-tag').textContent = data.owner.tag || '';
      } else {
        document.getElementById('bi-owner-name').textContent = 'Tidak diketahui';
        document.getElementById('bi-owner-tag').textContent = '';
      }

      document.getElementById('bi-servers').textContent = data.serverCount;
      document.getElementById('bi-members').textContent = data.totalMembers;
      document.getElementById('bi-ping').textContent = data.ping + ' ms';
      document.getElementById('bi-ram').textContent = data.ramUsageMB + ' MB';
      document.getElementById('bi-cpu').textContent = data.cpuLoad;

      const hours = Math.floor(data.uptimeSeconds / 3600);
      const minutes = Math.floor((data.uptimeSeconds % 3600) / 60);
      document.getElementById('bi-uptime').textContent = `${hours}j ${minutes}m`;

      loadGuildList();
    } catch (err) {
      console.error('Failed to load bot info', err);
    }
  }

  // ---- Server list (Info Bot -> everyone), sorted by most members first ----
  let guildListLoaded = false;
  async function loadGuildList() {
    const container = document.getElementById('bi-guild-list');
    if (!container || guildListLoaded) return; // cache-only data, no need to poll every refresh
    try {
      const res = await fetch('/api/bot/guilds');
      if (!res.ok) {
        container.innerHTML = '<div class="p-5 text-white/40 text-sm">Gagal memuat daftar server.</div>';
        return;
      }
      const data = await res.json();
      guildListLoaded = true;

      if (!data.guilds || data.guilds.length === 0) {
        container.innerHTML = '<div class="p-5 text-white/40 text-sm">Bot belum berada di server manapun.</div>';
        return;
      }

      container.innerHTML = data.guilds.map((g) => `
        <button class="bi-guild-row row-enter flex items-center gap-3 p-4 w-full text-left hover:bg-white/5 transition" data-id="${g.id}">
          ${g.icon
            ? `<img src="${g.icon}" class="w-10 h-10 rounded-full flex-shrink-0 object-cover" />`
            : `<div class="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center text-sm font-bold flex-shrink-0">${g.name.charAt(0)}</div>`}
          <div class="min-w-0 flex-1">
            <p class="font-medium truncate">${g.name}</p>
            <p class="text-white/40 text-xs truncate">${g.memberCount.toLocaleString()} member</p>
          </div>
          <span class="text-white/30 text-xs flex-shrink-0">Detail →</span>
        </button>
      `).join('');

      container.querySelectorAll('.bi-guild-row').forEach((btn) => {
        btn.addEventListener('click', () => openGuildDetailModal(btn.dataset.id));
      });
    } catch (err) {
      container.innerHTML = '<div class="p-5 text-white/40 text-sm">Gagal memuat daftar server.</div>';
    }
  }

  const guildModalBackdrop = document.getElementById('guild-modal-backdrop');
  const guildModal = document.getElementById('guild-modal');
  const guildModalClose = document.getElementById('guild-modal-close');

  async function openGuildDetailModal(guildIdToOpen) {
    if (!guildModalBackdrop) return;

    document.getElementById('gm-name').textContent = 'Memuat...';
    document.getElementById('gm-icon').src = '';
    document.getElementById('gm-owner').textContent = '-';
    document.getElementById('gm-members').textContent = '-';
    document.getElementById('gm-online').textContent = '-';
    document.getElementById('gm-roles').textContent = '-';
    document.getElementById('gm-channels').textContent = '-';

    guildModalBackdrop.classList.remove('hidden');
    guildModalBackdrop.classList.add('flex');
    requestAnimationFrame(() => {
      guildModalBackdrop.style.opacity = '1';
      guildModal.style.opacity = '1';
      guildModal.classList.remove('scale-95');
      guildModal.classList.add('scale-100');
    });

    try {
      const res = await fetch(`/api/bot/guilds/${guildIdToOpen}/detail`);
      if (!res.ok) {
        document.getElementById('gm-name').textContent = 'Gagal memuat server.';
        return;
      }
      const g = await res.json();

      document.getElementById('gm-name').textContent = g.name;
      if (g.icon) document.getElementById('gm-icon').src = g.icon;
      document.getElementById('gm-owner').textContent = g.owner ? g.owner.tag : 'Tidak diketahui';
      document.getElementById('gm-members').textContent = g.memberCount.toLocaleString();
      document.getElementById('gm-online').textContent = g.onlineMembers.toLocaleString();
      document.getElementById('gm-roles').textContent = g.roleCount.toLocaleString();
      document.getElementById('gm-channels').textContent = g.channelCount.toLocaleString();
    } catch (err) {
      document.getElementById('gm-name').textContent = 'Gagal memuat server.';
    }
  }

  function closeGuildDetailModal() {
    if (!guildModalBackdrop) return;
    guildModal.style.opacity = '0';
    guildModal.classList.remove('scale-100');
    guildModal.classList.add('scale-95');
    guildModalBackdrop.style.opacity = '0';
    setTimeout(() => {
      guildModalBackdrop.classList.add('hidden');
      guildModalBackdrop.classList.remove('flex');
    }, 200);
  }
  if (guildModalClose) guildModalClose.addEventListener('click', closeGuildDetailModal);
  if (guildModalBackdrop) guildModalBackdrop.addEventListener('click', (e) => {
    if (e.target === guildModalBackdrop) closeGuildDetailModal();
  });

  // ---- All member list (Overview) — includes bots, searchable, paginated ----
  let currentOvMembersPage = 1;
  let currentOvMemberSearch = '';
  let ovSearchDebounce = null;

  async function loadOverviewMembers(page, search) {
    currentOvMembersPage = page;
    currentOvMemberSearch = search;
    const spinner = document.getElementById('ov-member-search-spinner');
    const container = document.getElementById('ov-members-list');
    if (!container) return;
    if (spinner) spinner.classList.remove('hidden');

    try {
      const res = await fetch(`/api/guild/${guildId}/members?page=${page}&search=${encodeURIComponent(search)}`);
      if (!res.ok) {
        container.innerHTML = '<div class="p-5 text-white/40 text-sm">Gagal memuat member.</div>';
        return;
      }
      const data = await res.json();

      if (data.members.length === 0) {
        container.innerHTML = '<div class="p-5 text-white/40 text-sm">Tidak ada member ditemukan.</div>';
      } else {
        container.innerHTML = data.members.map((m) => `
          <button class="ov-member-row row-enter flex items-center gap-3 p-4 w-full text-left hover:bg-white/5 transition" data-id="${m.id}">
            <img src="${m.avatar}" class="w-10 h-10 rounded-full flex-shrink-0" />
            <div class="min-w-0 flex-1">
              <p class="font-medium truncate flex items-center gap-2">${m.displayName} ${m.isOwner ? '<span class="text-yellow-400 text-xs">👑</span>' : ''} ${m.isBot ? '<span class="text-[10px] px-1.5 py-0.5 rounded bg-[#7C3AED]/30 text-[#c9a6ff]">BOT</span>' : ''}</p>
              <p class="text-white/40 text-xs truncate">${m.tag}</p>
            </div>
            <span class="text-white/30 text-xs flex-shrink-0">Detail →</span>
          </button>
        `).join('');

        container.querySelectorAll('.ov-member-row').forEach((btn) => {
          btn.addEventListener('click', () => openMemberInfoModal(btn.dataset.id));
        });
      }

      document.getElementById('ov-members-page').textContent = `Page ${data.page} / ${data.totalPages}`;
    } catch (err) {
      container.innerHTML = '<div class="p-5 text-white/40 text-sm">Gagal memuat member.</div>';
    } finally {
      if (spinner) spinner.classList.add('hidden');
    }
  }

  const ovMemberSearchInput = document.getElementById('ov-member-search');
  if (ovMemberSearchInput) {
    ovMemberSearchInput.addEventListener('input', () => {
      clearTimeout(ovSearchDebounce);
      const value = ovMemberSearchInput.value;
      ovSearchDebounce = setTimeout(() => loadOverviewMembers(1, value.trim()), 400);
    });
  }

  const ovMembersPrevBtn = document.getElementById('ov-members-prev');
  const ovMembersNextBtn = document.getElementById('ov-members-next');
  if (ovMembersPrevBtn) ovMembersPrevBtn.addEventListener('click', () => {
    if (currentOvMembersPage > 1) loadOverviewMembers(currentOvMembersPage - 1, currentOvMemberSearch);
  });
  if (ovMembersNextBtn) ovMembersNextBtn.addEventListener('click', () => {
    loadOverviewMembers(currentOvMembersPage + 1, currentOvMemberSearch);
  });

  const ovOwnerCard = document.getElementById('ov-owner-card');
  if (ovOwnerCard) ovOwnerCard.addEventListener('click', () => {
    if (ownerId) openMemberInfoModal(ownerId);
  });

  // ---- Member info modal (detail, kick, ban) ----
  const memberModalBackdrop = document.getElementById('member-modal-backdrop');
  const memberModal = document.getElementById('member-modal');
  const memberModalClose = document.getElementById('member-modal-close');
  let currentMemberDetailId = null;

  function fmtDate(ts) {
    if (!ts) return '-';
    return new Date(ts).toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' });
  }

  async function openMemberInfoModal(memberId) {
    if (!memberModalBackdrop) return;
    currentMemberDetailId = memberId;

    document.getElementById('mm-name').textContent = 'Memuat...';
    document.getElementById('mm-tag').textContent = '';
    document.getElementById('mm-avatar').src = '';
    document.getElementById('mm-roles').innerHTML = '';
    document.getElementById('mm-owner-badge').classList.add('hidden');
    document.getElementById('mm-owner-note').classList.add('hidden');
    document.getElementById('mm-readonly-note').classList.add('hidden');
    document.getElementById('mm-actions').classList.remove('hidden');

    memberModalBackdrop.classList.remove('hidden');
    memberModalBackdrop.classList.add('flex');
    requestAnimationFrame(() => {
      memberModalBackdrop.style.opacity = '1';
      memberModal.style.opacity = '1';
      memberModal.classList.remove('scale-95');
      memberModal.classList.add('scale-100');
    });

    try {
      const res = await fetch(`/api/guild/${guildId}/members/${memberId}/detail`);
      if (!res.ok) {
        document.getElementById('mm-name').textContent = 'Gagal memuat member.';
        return;
      }
      const m = await res.json();

      document.getElementById('mm-avatar').src = m.avatar;
      document.getElementById('mm-name').textContent = m.displayName;
      document.getElementById('mm-tag').textContent = m.tag;
      document.getElementById('mm-created').textContent = fmtDate(m.createdAt);
      document.getElementById('mm-joined').textContent = fmtDate(m.joinedAt);
      if (m.isOwner) document.getElementById('mm-owner-badge').classList.remove('hidden');

      const rolesContainer = document.getElementById('mm-roles');
      if (m.roles.length === 0) {
        rolesContainer.innerHTML = '<span class="text-white/30 text-xs">Tidak ada role</span>';
      } else {
        rolesContainer.innerHTML = m.roles.map((r) => `<span class="text-[11px] px-2 py-1 rounded-full bg-white/10" style="color:${r.color !== '#000000' ? r.color : '#ffffff99'}">${r.name}</span>`).join('');
      }

      const hasAdminAccess = window.__IS_ADMIN__;
      const kickBtn = document.getElementById('mm-kick');
      const banBtn = document.getElementById('mm-ban');
      const manageBtn = document.getElementById('mm-manage-role');

      if (!hasAdminAccess) {
        document.getElementById('mm-actions').classList.add('hidden');
        document.getElementById('mm-readonly-note').classList.remove('hidden');
      } else if (m.isOwner) {
        kickBtn.classList.add('hidden');
        banBtn.classList.add('hidden');
        document.getElementById('mm-owner-note').classList.remove('hidden');
      } else {
        kickBtn.classList.remove('hidden');
        banBtn.classList.remove('hidden');
      }
    } catch (err) {
      document.getElementById('mm-name').textContent = 'Gagal memuat member.';
    }
  }

  function closeMemberModal() {
    if (!memberModalBackdrop) return;
    memberModal.style.opacity = '0';
    memberModal.classList.remove('scale-100');
    memberModal.classList.add('scale-95');
    memberModalBackdrop.style.opacity = '0';
    setTimeout(() => {
      memberModalBackdrop.classList.add('hidden');
      memberModalBackdrop.classList.remove('flex');
    }, 200);
  }
  if (memberModalClose) memberModalClose.addEventListener('click', closeMemberModal);
  if (memberModalBackdrop) memberModalBackdrop.addEventListener('click', (e) => {
    if (e.target === memberModalBackdrop) closeMemberModal();
  });

  const mmManageRole = document.getElementById('mm-manage-role');
  if (mmManageRole) mmManageRole.addEventListener('click', () => {
    if (!currentMemberDetailId) return;
    const name = document.getElementById('mm-name').textContent;
    closeMemberModal();
    setTimeout(() => openRoleModal(currentMemberDetailId, name), 200);
  });

  const mmKick = document.getElementById('mm-kick');
  if (mmKick) mmKick.addEventListener('click', async () => {
    if (!currentMemberDetailId) return;
    const name = document.getElementById('mm-name').textContent;
    const confirmed = await confirmDialog(`Yakin ingin kick ${name} dari server ini?`);
    if (!confirmed) return;
    mmKick.disabled = true;
    try {
      const res = await apiMutate(`/api/guild/${guildId}/members/${currentMemberDetailId}/kick`, { method: 'POST' });
      const data = await res.json();
      if (!res.ok) return toast(data.error || 'Gagal kick member.', 'error');
      toast(`${data.tag || name} berhasil di-kick.`, 'success');
      closeMemberModal();
      if (!document.getElementById('tab-overview').classList.contains('hidden')) loadOverviewMembers(currentOvMembersPage, currentOvMemberSearch);
      if (!document.getElementById('tab-members').classList.contains('hidden')) loadMembers(currentMembersPage, currentMemberSearch);
    } catch (err) {
      toast('Gagal kick member.', 'error');
    } finally {
      mmKick.disabled = false;
    }
  });

  const mmBan = document.getElementById('mm-ban');
  if (mmBan) mmBan.addEventListener('click', async () => {
    if (!currentMemberDetailId) return;
    const name = document.getElementById('mm-name').textContent;
    const confirmed = await confirmDialog(`Yakin ingin ban ${name} dari server ini? Tindakan ini bisa dibatalkan manual lewat Discord.`);
    if (!confirmed) return;
    mmBan.disabled = true;
    try {
      const res = await apiMutate(`/api/guild/${guildId}/members/${currentMemberDetailId}/ban`, { method: 'POST' });
      const data = await res.json();
      if (!res.ok) return toast(data.error || 'Gagal ban member.', 'error');
      toast(`${data.tag || name} berhasil di-ban.`, 'success');
      closeMemberModal();
      if (!document.getElementById('tab-overview').classList.contains('hidden')) loadOverviewMembers(currentOvMembersPage, currentOvMemberSearch);
      if (!document.getElementById('tab-members').classList.contains('hidden')) loadMembers(currentMembersPage, currentMemberSearch);
    } catch (err) {
      toast('Gagal ban member.', 'error');
    } finally {
      mmBan.disabled = false;
    }
  });

  // ---- Security ----
  function escHtml(str) {
    return String(str).replace(/[&<>"']/g, (c) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[c]));
  }

  function renderConfigPanelHTML(field, config) {
    const fields = SECURITY_CONFIG_FIELDS[field] || [];
    const inputsHtml = fields.map((f) => {
      const divisor = f.unit ? THRESHOLD_UNIT_DIVISOR[f.unit] : 1;
      const raw = config[f.key];
      const displayVal = raw !== undefined && raw !== null ? Math.round(raw / divisor) : '';
      return `
        <div>
          <p class="text-white/50 text-xs mb-1">${f.label}</p>
          <input type="number" min="${f.min}" max="${f.max}" data-key="${f.key}" data-unit="${f.unit || ''}" value="${displayVal}" class="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-[#00D4FF] transition" />
        </div>
      `;
    }).join('');

    return `
      <p class="text-white/40 text-xs mb-4">Atur sensitivitas deteksi khusus untuk server ini.</p>
      <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">${inputsHtml}</div>
      <div class="flex justify-end">
        <button type="button" data-save-config class="btn-press bg-gradient-to-r from-[#00D4FF] to-[#7C3AED] rounded-lg px-5 py-2 text-sm font-semibold">Simpan</button>
      </div>
    `;
  }

  function renderToxicPanelHTML(words) {
    const tagsHtml = words.length
      ? words.map((w) => `
          <span class="inline-flex items-center gap-1.5 bg-white/5 border border-white/10 rounded-full px-3 py-1 text-xs">
            ${escHtml(w.word)}
            <button type="button" data-remove-word="${escHtml(w.word)}" aria-label="Hapus kata ${escHtml(w.word)}" class="text-white/40 hover:text-red-400">✕</button>
          </span>
        `).join('')
      : '<p class="text-white/30 text-xs">Belum ada kata custom untuk server ini.</p>';

    return `
      <p class="text-white/40 text-xs mb-3">Tambahkan kata kasar/toxic khusus untuk server ini, di luar daftar bawaan bot.</p>
      <div class="flex flex-wrap gap-2 mb-4" data-word-tags>${tagsHtml}</div>
      <div class="flex gap-2">
        <input type="text" maxlength="64" placeholder="Kata baru..." data-word-input class="flex-1 min-w-0 bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-[#00D4FF] transition" />
        <button type="button" data-add-word class="btn-press bg-gradient-to-r from-[#00D4FF] to-[#7C3AED] rounded-lg px-4 py-2 text-sm font-semibold flex-shrink-0">+ Tambah</button>
      </div>
    `;
  }

  function securityRowState(isOn) {
    return {
      iconClass: `sec-icon w-11 h-11 rounded-xl flex items-center justify-center text-xl flex-shrink-0 transition-colors ${isOn ? 'bg-[#00FFB3]/15' : 'bg-white/5'}`,
      badgeClass: `sec-badge text-[10px] font-semibold px-2 py-0.5 rounded-full flex-shrink-0 ${isOn ? 'bg-[#00FFB3]/15 text-[#00FFB3]' : 'bg-white/10 text-white/40'}`,
      badgeText: isOn ? 'Aktif' : 'Nonaktif'
    };
  }

  function updateSecurityActiveCount() {
    const el = document.getElementById('sec-active-count');
    if (!el) return;
    const total = Object.keys(SECURITY_META).length;
    const active = document.querySelectorAll('#security-list .toggle-on').length;
    el.textContent = `${active} dari ${total} fitur`;
  }

  async function loadSecurity() {
    const [secRes, cfgRes, wordsRes] = await Promise.all([
      fetch(`/api/guild/${guildId}/security`),
      fetch(`/api/guild/${guildId}/security-config`),
      fetch(`/api/guild/${guildId}/toxic-words`)
    ]);
    if (!secRes.ok) return;
    const settings = await secRes.json();
    const config = cfgRes.ok ? await cfgRes.json() : {};
    const toxicWords = wordsRes.ok ? await wordsRes.json() : [];

    const container = document.getElementById('security-list');
    // Remember which panels were open so re-renders (e.g. from realtime sync) don't collapse them.
    const openPanels = new Set(
      [...container.querySelectorAll('[data-panel]:not(.hidden)')].map((el) => el.dataset.panel)
    );
    container.innerHTML = '';

    Object.keys(SECURITY_META).forEach((field) => {
      const meta = SECURITY_META[field];
      const isOn = !!settings[field];
      const state = securityRowState(isOn);
      const hasConfig = !!SECURITY_CONFIG_FIELDS[field] || field === 'antitoxic';
      const isOpen = openPanels.has(field);

      const wrap = document.createElement('div');
      wrap.className = 'glass rounded-2xl overflow-hidden';
      wrap.innerHTML = `
        <div class="card-hover p-5 flex items-center gap-4">
          <div class="${state.iconClass}">${meta.icon}</div>
          <div class="min-w-0 flex-1">
            <div class="flex items-center gap-2 mb-0.5">
              <span class="font-semibold">${meta.label}</span>
              <span class="${state.badgeClass}">${state.badgeText}</span>
            </div>
            <p class="text-white/40 text-xs leading-snug">${meta.desc}</p>
          </div>
          ${hasConfig ? `<button type="button" data-gear="${field}" aria-label="Pengaturan ${meta.label}" aria-expanded="${isOpen}" class="gear-btn w-9 h-9 rounded-lg bg-white/5 hover:bg-white/10 flex items-center justify-center flex-shrink-0 transition text-base">⚙️</button>` : ''}
          <button data-field="${field}" aria-label="Toggle ${meta.label}" class="toggle-btn w-12 h-6 rounded-full bg-white/10 toggle-track relative flex-shrink-0 ${isOn ? 'toggle-on' : ''}">
            <span class="toggle-thumb absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white block"></span>
          </button>
        </div>
        ${hasConfig ? `<div data-panel="${field}" class="${isOpen ? '' : 'hidden'} border-t border-white/5 p-5">${field === 'antitoxic' ? renderToxicPanelHTML(toxicWords) : renderConfigPanelHTML(field, config)}</div>` : ''}
      `;
      container.appendChild(wrap);
    });

    updateSecurityActiveCount();

    // ---- Toggle on/off (unchanged behavior, applies instantly) ----
    container.querySelectorAll('.toggle-btn').forEach((btn) => {
      btn.addEventListener('click', async () => {
        const field = btn.dataset.field;
        const newValue = !btn.classList.contains('toggle-on');
        const row = btn.closest('.card-hover');
        const icon = row.querySelector('.sec-icon');
        const badge = row.querySelector('.sec-badge');

        function applyState(isOn) {
          const state = securityRowState(isOn);
          btn.classList.toggle('toggle-on', isOn);
          icon.className = state.iconClass;
          badge.className = state.badgeClass;
          badge.textContent = state.badgeText;
          updateSecurityActiveCount();
        }

        applyState(newValue);

        try {
          const res = await apiMutate(`/api/guild/${guildId}/security`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ field, value: newValue })
          });
          if (!res.ok) throw new Error();
          toast(`${SECURITY_META[field].label} ${newValue ? 'diaktifkan' : 'dinonaktifkan'}.`, 'success');
        } catch (err) {
          applyState(!newValue);
          toast(`Gagal memperbarui ${SECURITY_META[field].label}.`, 'error');
        }
      });
    });

    // ---- Gear button: expand/collapse the settings panel inside the card ----
    container.querySelectorAll('.gear-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        const field = btn.dataset.gear;
        const panel = container.querySelector(`[data-panel="${field}"]`);
        if (!panel) return;
        const nowOpen = panel.classList.toggle('hidden') === false;
        btn.setAttribute('aria-expanded', String(nowOpen));
      });
    });

    // ---- Numeric threshold panels: Simpan button ----
    container.querySelectorAll('[data-save-config]').forEach((saveBtn) => {
      saveBtn.addEventListener('click', async () => {
        const panel = saveBtn.closest('[data-panel]');
        const body = {};
        panel.querySelectorAll('input[data-key]').forEach((input) => {
          const raw = Number(input.value);
          if (!Number.isFinite(raw)) return;
          const unit = input.dataset.unit;
          const divisor = unit ? THRESHOLD_UNIT_DIVISOR[unit] : 1;
          body[input.dataset.key] = divisor ? raw * divisor : raw;
        });

        saveBtn.disabled = true;
        const originalText = saveBtn.textContent;
        saveBtn.textContent = 'Menyimpan...';

        try {
          const res = await apiMutate(`/api/guild/${guildId}/security-config`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body)
          });
          if (!res.ok) throw new Error();
          toast('Pengaturan berhasil disimpan.', 'success');
        } catch (err) {
          toast('Gagal menyimpan pengaturan.', 'error');
        } finally {
          saveBtn.disabled = false;
          saveBtn.textContent = originalText;
        }
      });
    });

    // ---- Anti Toxic custom word list: add/remove ----
    const toxicPanel = container.querySelector('[data-panel="antitoxic"]');
    if (toxicPanel) {
      async function refreshToxicTags() {
        const res = await fetch(`/api/guild/${guildId}/toxic-words`);
        const words = res.ok ? await res.json() : [];
        const tagsWrap = toxicPanel.querySelector('[data-word-tags]');
        tagsWrap.innerHTML = words.length
          ? words.map((w) => `
              <span class="inline-flex items-center gap-1.5 bg-white/5 border border-white/10 rounded-full px-3 py-1 text-xs">
                ${escHtml(w.word)}
                <button type="button" data-remove-word="${escHtml(w.word)}" aria-label="Hapus kata ${escHtml(w.word)}" class="text-white/40 hover:text-red-400">✕</button>
              </span>
            `).join('')
          : '<p class="text-white/30 text-xs">Belum ada kata custom untuk server ini.</p>';
        wireRemoveButtons();
      }

      function wireRemoveButtons() {
        toxicPanel.querySelectorAll('[data-remove-word]').forEach((btn) => {
          btn.addEventListener('click', async () => {
            const word = btn.dataset.removeWord;
            try {
              const res = await apiMutate(`/api/guild/${guildId}/toxic-words`, {
                method: 'DELETE',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ word })
              });
              if (!res.ok) throw new Error();
              toast(`Kata "${word}" dihapus.`, 'success');
              await refreshToxicTags();
            } catch (err) {
              toast('Gagal menghapus kata.', 'error');
            }
          });
        });
      }

      wireRemoveButtons();

      const addBtn = toxicPanel.querySelector('[data-add-word]');
      const wordInput = toxicPanel.querySelector('[data-word-input]');
      async function addWord() {
        const word = wordInput.value.trim().toLowerCase();
        if (!word || /\s/.test(word)) {
          toast('Masukkan satu kata tanpa spasi.', 'error');
          return;
        }
        try {
          const res = await apiMutate(`/api/guild/${guildId}/toxic-words`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ word })
          });
          if (!res.ok) throw new Error();
          wordInput.value = '';
          toast(`Kata "${word}" ditambahkan.`, 'success');
          await refreshToxicTags();
        } catch (err) {
          toast('Gagal menambahkan kata.', 'error');
        }
      }
      addBtn.addEventListener('click', addWord);
      wordInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') { e.preventDefault(); addWord(); }
      });
    }
  }

  // ---- Whitelist ----
  const wlTypeSelect = document.getElementById('wl-type');
  const wlTargetSelect = document.getElementById('wl-target');
  enhanceDropdown(wlTypeSelect);
  enhanceDropdown(wlTargetSelect, 'Pilih target...');

  async function loadWhitelistOptions() {
    const type = wlTypeSelect.value;
    wlTargetSelect.innerHTML = '<option>Loading...</option>';
    syncDropdownOptions(wlTargetSelect);

    const endpoint = type === 'channel' ? 'channels' : type === 'role' ? 'roles' : null;

    if (endpoint) {
      const res = await fetch(`/api/guild/${guildId}/${endpoint}`);
      const items = await res.json();
      wlTargetSelect.innerHTML = items.map((i) => `<option value="${i.id}">${i.name}</option>`).join('');
    } else {
      wlTargetSelect.innerHTML = '<option value="">Masukkan User ID di bawah</option>';
    }
    syncDropdownOptions(wlTargetSelect);
  }

  wlTypeSelect.addEventListener('change', loadWhitelistOptions);

  document.getElementById('wl-add').addEventListener('click', async () => {
    const type = wlTypeSelect.value;
    const targetId = wlTargetSelect.value;
    if (!targetId) return toast('Pilih target terlebih dahulu.', 'error');

    try {
      const res = await apiMutate(`/api/guild/${guildId}/whitelist`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type, targetId })
      });
      if (!res.ok) throw new Error();
      toast('Berhasil ditambahkan ke whitelist.', 'success');
      loadWhitelist();
    } catch (err) {
      toast('Gagal menambahkan whitelist.', 'error');
    }
  });

  async function loadWhitelist() {
    const res = await fetch(`/api/guild/${guildId}/whitelist`);
    if (!res.ok) return;
    const rows = await res.json();
    const container = document.getElementById('whitelist-list');

    if (rows.length === 0) {
      container.innerHTML = '<div class="p-5 text-white/40 text-sm">Belum ada whitelist.</div>';
      return;
    }

    container.innerHTML = rows.map((row) => `
      <div class="flex items-center justify-between p-5">
        <div>
          <span class="text-xs uppercase text-white/40 mr-2">${row.type}</span>
          <span class="font-medium">${row.label}</span>
        </div>
        <button class="wl-remove text-red-400 hover:text-red-300 text-sm" data-type="${row.type}" data-target="${row.targetId}">Hapus</button>
      </div>
    `).join('');

    container.querySelectorAll('.wl-remove').forEach((btn) => {
      btn.addEventListener('click', async () => {
        try {
          const res = await apiMutate(`/api/guild/${guildId}/whitelist`, {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ type: btn.dataset.type, targetId: btn.dataset.target })
          });
          if (!res.ok) throw new Error();
          toast('Berhasil dihapus dari whitelist.', 'success');
          loadWhitelist();
        } catch (err) {
          toast('Gagal menghapus whitelist.', 'error');
        }
      });
    });
  }

  // ---- Announcement ----
  const anChannelSelect = document.getElementById('an-channel');
  const anTagSelect = document.getElementById('an-tag');
  const anRoleSelect = document.getElementById('an-role');
  const anRoleWrap = document.getElementById('an-role-wrap');
  enhanceDropdown(anChannelSelect, 'Pilih channel...');
  enhanceDropdown(anTagSelect);
  enhanceDropdown(anRoleSelect, 'Pilih role...');

  let anRolesLoaded = false;

  async function loadAnnouncementOptions() {
    anChannelSelect.innerHTML = '<option value="">Memuat channel...</option>';
    syncDropdownOptions(anChannelSelect);
    try {
      const res = await fetch(`/api/guild/${guildId}/channels`);
      if (!res.ok) throw new Error();
      const channels = await res.json();
      if (!Array.isArray(channels) || channels.length === 0) {
        anChannelSelect.innerHTML = '<option value="">Tidak ada channel tersedia</option>';
      } else {
        anChannelSelect.innerHTML = channels.map((c) => `<option value="${c.id}">#${c.name}</option>`).join('');
      }
    } catch (err) {
      anChannelSelect.innerHTML = '<option value="">Gagal memuat channel</option>';
      toast('Gagal memuat daftar channel. Coba buka ulang tab ini.', 'error');
    }
    syncDropdownOptions(anChannelSelect);
  }

  async function loadAnnouncementRoles() {
    if (anRolesLoaded) return;
    anRoleSelect.innerHTML = '<option value="">Memuat role...</option>';
    syncDropdownOptions(anRoleSelect);
    try {
      const res = await fetch(`/api/guild/${guildId}/roles`);
      if (!res.ok) throw new Error();
      const roles = await res.json();
      anRoleSelect.innerHTML = roles.map((r) => `<option value="${r.id}">${r.name}</option>`).join('');
      anRolesLoaded = true;
    } catch (err) {
      anRoleSelect.innerHTML = '<option value="">Gagal memuat role</option>';
      toast('Gagal memuat daftar role. Coba pilih ulang "Role tertentu".', 'error');
    }
    syncDropdownOptions(anRoleSelect);
  }

  anTagSelect.addEventListener('change', () => {
    if (anTagSelect.value === 'role') {
      anRoleWrap.classList.remove('hidden');
      loadAnnouncementRoles();
    } else {
      anRoleWrap.classList.add('hidden');
    }
  });

  function wireImagePreview(inputId, labelId, previewId) {
    const input = document.getElementById(inputId);
    const label = document.getElementById(labelId);
    const preview = document.getElementById(previewId);
    if (!input) return;
    input.addEventListener('change', () => {
      const file = input.files[0];
      label.textContent = file ? file.name : 'Tidak ada file dipilih';
      if (file) {
        const reader = new FileReader();
        reader.onload = () => {
          preview.src = reader.result;
          preview.classList.remove('hidden');
        };
        reader.readAsDataURL(file);
      } else {
        preview.classList.add('hidden');
        preview.src = '';
      }
    });
  }
  wireImagePreview('an-image-file', 'an-image-filename', 'an-image-preview');
  wireImagePreview('an-icon-file', 'an-icon-filename', 'an-icon-preview');

  const anSendBtn = document.getElementById('an-send');
  if (anSendBtn) anSendBtn.addEventListener('click', async () => {
    const channelId = anChannelSelect.value;
    const title = document.getElementById('an-title').value.trim();
    const description = document.getElementById('an-description').value.trim();
    const tag = anTagSelect.value;
    const roleId = anRoleSelect.value;
    const buttonTitle = document.getElementById('an-button-title').value.trim();
    const buttonLink = document.getElementById('an-button-link').value.trim();
    const imageFile = document.getElementById('an-image-file').files[0];
    const iconFile = document.getElementById('an-icon-file').files[0];

    if (!channelId) return toast('Pilih channel tujuan.', 'error');
    if (!title) return toast('Judul wajib diisi.', 'error');
    if (!description) return toast('Deskripsi wajib diisi.', 'error');
    if (tag === 'role' && !roleId) return toast('Pilih role yang ingin di-tag.', 'error');
    if ((buttonTitle && !buttonLink) || (buttonLink && !buttonTitle)) {
      return toast('Judul tombol dan link tombol harus diisi bersamaan.', 'error');
    }

    anSendBtn.disabled = true;
    try {
      const [image, icon] = await Promise.all([
        imageFile ? fileToDataUrl(imageFile) : Promise.resolve(null),
        iconFile ? fileToDataUrl(iconFile) : Promise.resolve(null)
      ]);

      const res = await apiMutate(`/api/guild/${guildId}/announcement`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ channelId, title, description, image, icon, tag, roleId, buttonTitle, buttonLink })
      });
      const data = await res.json();
      if (!res.ok) return toast(data.error || 'Gagal mengirim pengumuman.', 'error');

      toast('Pengumuman berhasil dikirim.', 'success');
      document.getElementById('an-title').value = '';
      document.getElementById('an-description').value = '';
      document.getElementById('an-button-title').value = '';
      document.getElementById('an-button-link').value = '';
      document.getElementById('an-image-file').value = '';
      document.getElementById('an-icon-file').value = '';
      document.getElementById('an-image-filename').textContent = 'Tidak ada file dipilih';
      document.getElementById('an-icon-filename').textContent = 'Tidak ada file dipilih';
      document.getElementById('an-image-preview').classList.add('hidden');
      document.getElementById('an-icon-preview').classList.add('hidden');
    } catch (err) {
      toast('Gagal mengirim pengumuman.', 'error');
    } finally {
      anSendBtn.disabled = false;
    }
  });

  // ---- Ticket ----
  const tkChannelSelect = document.getElementById('tk-channel');
  const tkCategorySelect = document.getElementById('tk-category');
  const tkRoleSelect = document.getElementById('tk-role');
  const tkTypeSelect = document.getElementById('tk-type');
  const tkTranscriptChannelSelect = document.getElementById('tk-transcript-channel');
  enhanceDropdown(tkChannelSelect, 'Pilih channel...');
  enhanceDropdown(tkCategorySelect, 'Pilih kategori...');
  enhanceDropdown(tkRoleSelect, 'Pilih role...');
  enhanceDropdown(tkTypeSelect);
  enhanceDropdown(tkTranscriptChannelSelect, 'Tidak ada (opsional)...');

  const tkPanelIdInput = document.getElementById('tk-panel-id');
  const tkFormHeading = document.getElementById('tk-form-heading');
  const tkCancelEditBtn = document.getElementById('tk-cancel-edit');
  const tkPanelListEl = document.getElementById('tk-panel-list');
  const tkNewPanelBtn = document.getElementById('tk-new-panel');
  const tkColorInput = document.getElementById('tk-color');
  const tkColorSwatchBtn = document.getElementById('tk-color-swatch');
  const tkColorPickerMount = document.getElementById('tk-color-picker-mount');

  let ticketOptionsLoaded = false;
  let ticketPanelsCache = [];

  if (tkColorSwatchBtn && tkColorPickerMount && window.attachColorPicker) {
    window.attachColorPicker(tkColorSwatchBtn, tkColorInput, tkColorPickerMount, {
      defaultHex: '#00d4ff',
      onChange: (hex) => { tkColorInput.value = hex; }
    });
  }

  async function loadTicketOptions() {
    if (!ticketOptionsLoaded) {
      tkChannelSelect.innerHTML = '<option value="">Memuat channel...</option>';
      tkCategorySelect.innerHTML = '<option value="">Memuat kategori...</option>';
      tkRoleSelect.innerHTML = '<option value="">Memuat role...</option>';
      tkTranscriptChannelSelect.innerHTML = '<option value="">Memuat channel...</option>';
      [tkChannelSelect, tkCategorySelect, tkRoleSelect, tkTranscriptChannelSelect].forEach(syncDropdownOptions);

      try {
        const [channelsRes, categoriesRes, rolesRes] = await Promise.all([
          fetch(`/api/guild/${guildId}/channels`),
          fetch(`/api/guild/${guildId}/categories`),
          fetch(`/api/guild/${guildId}/roles`)
        ]);
        if (!channelsRes.ok || !categoriesRes.ok || !rolesRes.ok) throw new Error();

        const channels = await channelsRes.json();
        const categories = await categoriesRes.json();
        const roles = await rolesRes.json();

        const channelOptions = channels.map((c) => `<option value="${c.id}">#${c.name}</option>`).join('');
        tkChannelSelect.innerHTML = channelOptions || '<option value="">Tidak ada channel tersedia</option>';
        tkTranscriptChannelSelect.innerHTML = `<option value="">Tidak ada</option>${channelOptions}`;
        tkCategorySelect.innerHTML = categories.length
          ? categories.map((c) => `<option value="${c.id}">${c.name}</option>`).join('')
          : '<option value="">Tidak ada kategori tersedia</option>';
        tkRoleSelect.innerHTML = roles.map((r) => `<option value="${r.id}">${r.name}</option>`).join('');

        ticketOptionsLoaded = true;
      } catch (err) {
        tkChannelSelect.innerHTML = '<option value="">Gagal memuat</option>';
        tkCategorySelect.innerHTML = '<option value="">Gagal memuat</option>';
        tkRoleSelect.innerHTML = '<option value="">Gagal memuat</option>';
        toast('Gagal memuat data channel/kategori/role. Coba buka ulang tab ini.', 'error');
      }
      [tkChannelSelect, tkCategorySelect, tkRoleSelect, tkTranscriptChannelSelect].forEach(syncDropdownOptions);
    }
    loadTicketPanels();
  }

  function panelChannelName(channelId) {
    if (!channelId) return '-';
    const opt = tkChannelSelect.querySelector(`option[value="${CSS.escape(channelId)}"]`);
    return opt ? opt.textContent : `#${channelId}`;
  }

  function renderTicketPanels() {
    if (!ticketPanelsCache.length) {
      tkPanelListEl.innerHTML = '<p class="text-white/30 text-sm">Belum ada panel ticket. Klik "+ Panel Baru" untuk membuat.</p>';
      return;
    }
    tkPanelListEl.innerHTML = ticketPanelsCache.map((p) => `
      <div class="flex items-center justify-between gap-3 bg-white/5 border border-white/10 rounded-xl px-4 py-3 row-enter">
        <div class="flex items-center gap-3 min-w-0">
          <span class="w-4 h-4 rounded-full flex-shrink-0 border border-white/20" style="background:${p.panelColor || '#00d4ff'}"></span>
          <div class="min-w-0">
            <p class="font-medium text-sm truncate">${p.panelTitle || 'Support Ticket'}</p>
            <p class="text-white/40 text-xs truncate">${panelChannelName(p.panelChannelId)} • ${p.panelMessageId ? 'Terkirim' : 'Belum dikirim'}</p>
          </div>
        </div>
        <div class="flex items-center gap-2 flex-shrink-0">
          <button data-edit="${p.id}" class="btn-press glass rounded-lg px-3 py-1.5 text-xs font-semibold">✏️ Edit</button>
          <button data-delete="${p.id}" class="btn-press bg-red-500/20 text-red-300 rounded-lg px-3 py-1.5 text-xs font-semibold">🗑️ Hapus</button>
        </div>
      </div>
    `).join('');

    tkPanelListEl.querySelectorAll('[data-edit]').forEach((btn) => {
      btn.addEventListener('click', () => loadPanelIntoForm(btn.dataset.edit));
    });
    tkPanelListEl.querySelectorAll('[data-delete]').forEach((btn) => {
      btn.addEventListener('click', () => deleteTicketPanelHandler(btn.dataset.delete));
    });
  }

  async function loadTicketPanels() {
    try {
      const res = await fetch(`/api/guild/${guildId}/ticket-panels`);
      if (!res.ok) throw new Error();
      ticketPanelsCache = await res.json();
      renderTicketPanels();
    } catch (err) {
      tkPanelListEl.innerHTML = '<p class="text-red-300 text-sm">Gagal memuat daftar panel.</p>';
    }
  }

  function resetTicketForm() {
    tkPanelIdInput.value = '';
    tkFormHeading.textContent = 'Buat Panel Baru';
    tkCancelEditBtn.classList.add('hidden');
    tkChannelSelect.value = '';
    tkCategorySelect.value = '';
    tkRoleSelect.value = '';
    tkTypeSelect.value = 'embed';
    tkTranscriptChannelSelect.value = '';
    document.getElementById('tk-title').value = '';
    document.getElementById('tk-emoji').value = '';
    tkColorInput.value = '#00d4ff';
    if (window.attachColorPicker) tkColorSwatchBtn.style.background = '#00d4ff';
    document.getElementById('tk-message').value = '';
    document.getElementById('tk-welcome').value = '';
    document.getElementById('tk-send').textContent = '🎫 Simpan & Kirim Panel';
    [tkChannelSelect, tkCategorySelect, tkRoleSelect, tkTypeSelect, tkTranscriptChannelSelect].forEach(syncDropdownOptions);
  }

  function loadPanelIntoForm(panelId) {
    const panel = ticketPanelsCache.find((p) => String(p.id) === String(panelId));
    if (!panel) return;

    tkPanelIdInput.value = panel.id;
    tkFormHeading.textContent = `Edit Panel: ${panel.panelTitle || 'Support Ticket'}`;
    tkCancelEditBtn.classList.remove('hidden');

    if (panel.panelChannelId) tkChannelSelect.value = panel.panelChannelId;
    if (panel.category) tkCategorySelect.value = panel.category;
    if (panel.staffRoleId) tkRoleSelect.value = panel.staffRoleId;
    tkTypeSelect.value = panel.panelType || 'embed';
    tkTranscriptChannelSelect.value = panel.transcriptChannelId || '';
    document.getElementById('tk-title').value = panel.panelTitle || '';
    document.getElementById('tk-emoji').value = panel.panelEmoji || '';
    tkColorInput.value = panel.panelColor || '#00d4ff';
    tkColorSwatchBtn.style.background = panel.panelColor || '#00d4ff';
    document.getElementById('tk-message').value = panel.panelDescription || '';
    document.getElementById('tk-welcome').value = panel.welcomeMessage || '';
    document.getElementById('tk-send').textContent = panel.panelMessageId ? '🎫 Update Panel Terkirim' : '🎫 Simpan & Kirim Panel';

    [tkChannelSelect, tkCategorySelect, tkRoleSelect, tkTypeSelect, tkTranscriptChannelSelect].forEach(syncDropdownOptions);
    document.getElementById('tk-form-heading').scrollIntoView({ behavior: 'smooth', block: 'center' });
  }

  async function deleteTicketPanelHandler(panelId) {
    const ok = await confirmDialog('Hapus panel ticket ini? Pesan panel di Discord (jika ada) dan semua datanya di database akan ikut terhapus.');
    if (!ok) return;
    try {
      const res = await apiMutate(`/api/guild/${guildId}/ticket-panels/${panelId}`, { method: 'DELETE' });
      const data = await res.json();
      if (!res.ok) return toast(data.error || 'Gagal menghapus panel.', 'error');
      toast('Panel ticket dihapus.', 'success');
      if (String(tkPanelIdInput.value) === String(panelId)) resetTicketForm();
      loadTicketPanels();
    } catch (err) {
      toast('Gagal menghapus panel.', 'error');
    }
  }

  function collectTicketPayload() {
    return {
      channelId: tkChannelSelect.value,
      category: tkCategorySelect.value,
      roleId: tkRoleSelect.value,
      panelType: tkTypeSelect.value,
      title: document.getElementById('tk-title').value.trim(),
      message: document.getElementById('tk-message').value.trim(),
      emoji: document.getElementById('tk-emoji').value.trim(),
      color: tkColorInput.value.trim(),
      welcomeMessage: document.getElementById('tk-welcome').value.trim(),
      transcriptChannelId: tkTranscriptChannelSelect.value || null
    };
  }

  function validateTicketPayload(payload) {
    if (!payload.channelId) return 'Pilih channel untuk panel ticket.';
    if (!payload.category) return 'Pilih kategori untuk channel ticket.';
    if (!payload.roleId) return 'Pilih role admin/handler ticket.';
    if (!payload.message) return 'Isi pesan/deskripsi panel wajib diisi.';
    if (payload.color && !/^#?[0-9a-f]{6}$/i.test(payload.color)) return 'Format warna harus hex, contoh #00d4ff.';
    return null;
  }

  async function submitTicketSettings(sendPanel) {
    const payload = collectTicketPayload();
    const error = validateTicketPayload(payload);
    if (error) return toast(error, 'error');

    const editingId = tkPanelIdInput.value;
    const btn = sendPanel ? document.getElementById('tk-send') : document.getElementById('tk-save');
    btn.disabled = true;
    try {
      const url = editingId ? `/api/guild/${guildId}/ticket-panels/${editingId}` : `/api/guild/${guildId}/ticket-panels`;
      const method = editingId ? 'PUT' : 'POST';
      const bodyKey = editingId ? 'resendPanel' : 'sendPanel';
      const res = await apiMutate(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...payload, [bodyKey]: sendPanel })
      });
      const data = await res.json();
      if (!res.ok) return toast(data.error || 'Gagal menyimpan pengaturan ticket.', 'error');

      toast(editingId
        ? (sendPanel ? 'Panel ticket berhasil diperbarui.' : 'Perubahan panel disimpan.')
        : (sendPanel ? 'Panel ticket berhasil dikirim.' : 'Panel ticket disimpan.'), 'success');

      await loadTicketPanels();
      if (editingId) loadPanelIntoForm(editingId);
    } catch (err) {
      toast('Gagal menyimpan pengaturan ticket.', 'error');
    } finally {
      btn.disabled = false;
    }
  }

  const tkSaveBtn = document.getElementById('tk-save');
  const tkSendBtn = document.getElementById('tk-send');
  if (tkSaveBtn) tkSaveBtn.addEventListener('click', () => submitTicketSettings(false));
  if (tkSendBtn) tkSendBtn.addEventListener('click', () => submitTicketSettings(true));
  if (tkNewPanelBtn) tkNewPanelBtn.addEventListener('click', resetTicketForm);
  if (tkCancelEditBtn) tkCancelEditBtn.addEventListener('click', resetTicketForm);

  // ---- Members (Owner only) ----
  const memberSearchInput = document.getElementById('member-search');
  if (memberSearchInput) {
    memberSearchInput.addEventListener('input', () => {
      clearTimeout(searchDebounce);
      const value = memberSearchInput.value;
      searchDebounce = setTimeout(() => {
        currentMemberSearch = value.trim();
        loadMembers(1, currentMemberSearch);
      }, 400);
    });
  }

  async function loadMembers(page, search) {
    currentMembersPage = page;
    currentMemberSearch = search;
    const spinner = document.getElementById('member-search-spinner');
    const container = document.getElementById('members-list');
    if (spinner) spinner.classList.remove('hidden');

    try {
      const res = await fetch(`/api/guild/${guildId}/members?page=${page}&search=${encodeURIComponent(search)}`);
      if (!res.ok) {
        container.innerHTML = '<div class="p-5 text-white/40 text-sm">Gagal memuat member.</div>';
        return;
      }
      const data = await res.json();

      if (data.members.length === 0) {
        container.innerHTML = '<div class="p-5 text-white/40 text-sm">Tidak ada member ditemukan.</div>';
      } else {
        container.innerHTML = data.members.map((m) => `
          <div class="row-enter flex items-center justify-between p-4 gap-3">
            <div class="flex items-center gap-3 min-w-0">
              <img src="${m.avatar}" class="w-10 h-10 rounded-full flex-shrink-0" />
              <div class="min-w-0">
                <p class="font-medium truncate flex items-center gap-2">${m.displayName} ${m.isOwner ? '<span class="text-yellow-400 text-xs">👑</span>' : ''}</p>
                <p class="text-white/40 text-xs truncate">${m.tag}</p>
                <div class="flex flex-wrap gap-1 mt-1">
                  ${m.roles.slice(0, 3).map((r) => `<span class="text-[10px] px-2 py-0.5 rounded-full bg-white/10" style="color:${r.color !== '#000000' ? r.color : '#ffffff99'}">${r.name}</span>`).join('')}
                  ${m.roles.length > 3 ? `<span class="text-[10px] px-2 py-0.5 rounded-full bg-white/10 text-white/40">+${m.roles.length - 3}</span>` : ''}
                </div>
              </div>
            </div>
            <div class="flex items-center gap-3 flex-shrink-0">
              <button class="member-detail btn-press text-white/60 hover:text-white text-sm" data-id="${m.id}">Detail</button>
              <button class="member-edit-role btn-press text-[#00D4FF] hover:text-white text-sm" data-id="${m.id}" data-name="${m.displayName}">Kelola Role</button>
            </div>
          </div>
        `).join('');

        container.querySelectorAll('.member-edit-role').forEach((btn) => {
          btn.addEventListener('click', () => openRoleModal(btn.dataset.id, btn.dataset.name));
        });
        container.querySelectorAll('.member-detail').forEach((btn) => {
          btn.addEventListener('click', () => openMemberInfoModal(btn.dataset.id));
        });
      }

      document.getElementById('members-page').textContent = `Page ${data.page} / ${data.totalPages}`;
    } catch (err) {
      container.innerHTML = '<div class="p-5 text-white/40 text-sm">Gagal memuat member.</div>';
    } finally {
      if (spinner) spinner.classList.add('hidden');
    }
  }

  const membersPrevBtn = document.getElementById('members-prev');
  const membersNextBtn = document.getElementById('members-next');
  if (membersPrevBtn) membersPrevBtn.addEventListener('click', () => {
    if (currentMembersPage > 1) loadMembers(currentMembersPage - 1, currentMemberSearch);
  });
  if (membersNextBtn) membersNextBtn.addEventListener('click', () => {
    loadMembers(currentMembersPage + 1, currentMemberSearch);
  });

  // ---- Role edit modal ----
  const roleModalBackdrop = document.getElementById('role-modal-backdrop');
  const roleModal = document.getElementById('role-modal');
  const roleModalClose = document.getElementById('role-modal-close');
  let allGuildRoles = null;

  async function getAllGuildRoles() {
    if (allGuildRoles) return allGuildRoles;
    const res = await fetch(`/api/guild/${guildId}/roles`);
    allGuildRoles = await res.json();
    return allGuildRoles;
  }

  async function openRoleModal(memberId, memberName) {
    if (!roleModalBackdrop) return;
    document.getElementById('role-modal-username').textContent = memberName;
    document.getElementById('role-modal-list').innerHTML = '<div class="text-white/40 text-sm py-4 text-center">Memuat role...</div>';

    roleModalBackdrop.classList.remove('hidden');
    roleModalBackdrop.classList.add('flex');
    requestAnimationFrame(() => {
      roleModalBackdrop.style.opacity = '1';
      roleModal.style.opacity = '1';
      roleModal.classList.remove('scale-95');
      roleModal.classList.add('scale-100');
    });

    const [roles, memberRow] = await Promise.all([
      getAllGuildRoles(),
      fetch(`/api/guild/${guildId}/members?search=${encodeURIComponent(memberName)}&page=1`).then((r) => r.json())
    ]);

    const current = (memberRow.members.find((m) => m.id === memberId)?.roles || []).map((r) => r.id);
    renderRoleModalList(memberId, roles, current);
  }

  function renderRoleModalList(memberId, roles, currentRoleIds) {
    const list = document.getElementById('role-modal-list');
    list.innerHTML = roles.map((r) => {
      const active = currentRoleIds.includes(r.id);
      return `
        <button class="role-toggle flex items-center justify-between px-3 py-2 rounded-lg text-sm transition ${active ? 'bg-[#00D4FF]/15 text-[#00D4FF]' : 'bg-white/5 text-white/70 hover:bg-white/10'}" data-role-id="${r.id}">
          <span>${r.name}</span>
          <span>${active ? '✓' : '+'}</span>
        </button>
      `;
    }).join('');

    list.querySelectorAll('.role-toggle').forEach((btn) => {
      btn.addEventListener('click', async () => {
        const roleId = btn.dataset.roleId;
        const isActive = currentRoleIds.includes(roleId);
        btn.disabled = true;
        try {
          const result = await apiMutate(`/api/guild/${guildId}/members/${memberId}/roles`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ roleId, action: isActive ? 'remove' : 'add' })
          });
          const data = await result.json();
          if (!result.ok) { toast(data.error || 'Gagal mengubah role.', 'error'); return; }
          const newIds = data.roles.map((r) => r.id);
          renderRoleModalList(memberId, allGuildRoles, newIds);
          loadMembers(currentMembersPage, currentMemberSearch);
          toast(isActive ? 'Role berhasil dihapus.' : 'Role berhasil ditambahkan.', 'success');
        } catch (err) {
          toast('Gagal mengubah role.', 'error');
        } finally {
          btn.disabled = false;
        }
      });
    });
  }

  function closeRoleModal() {
    if (!roleModalBackdrop) return;
    roleModal.style.opacity = '0';
    roleModal.classList.remove('scale-100');
    roleModal.classList.add('scale-95');
    roleModalBackdrop.style.opacity = '0';
    setTimeout(() => {
      roleModalBackdrop.classList.add('hidden');
      roleModalBackdrop.classList.remove('flex');
    }, 200);
  }
  if (roleModalClose) roleModalClose.addEventListener('click', closeRoleModal);
  if (roleModalBackdrop) roleModalBackdrop.addEventListener('click', (e) => {
    if (e.target === roleModalBackdrop) closeRoleModal();
  });

  // ---- Logs ----
  async function loadLogs(page) {
    currentLogsPage = page;
    const res = await fetch(`/api/guild/${guildId}/logs?page=${page}`);
    if (!res.ok) return;
    const data = await res.json();
    const container = document.getElementById('logs-list');

    if (data.logs.length === 0) {
      container.innerHTML = '<div class="p-5 text-white/40 text-sm">Belum ada log.</div>';
    } else {
      container.innerHTML = data.logs.map((log) => `
        <div class="p-5">
          <div class="flex items-center justify-between mb-1">
            <span class="font-semibold text-[#00D4FF]">${log.action}</span>
            <span class="text-white/40 text-xs">${new Date(log.timestamp).toLocaleString('id-ID')}</span>
          </div>
          <p class="text-white/60 text-sm">User: ${log.userId}</p>
          <p class="text-white/50 text-sm">${log.reason || '-'}</p>
        </div>
      `).join('');
    }

    document.getElementById('logs-page').textContent = `Page ${data.page} / ${data.totalPages}`;
  }

  document.getElementById('logs-prev').addEventListener('click', () => {
    if (currentLogsPage > 1) loadLogs(currentLogsPage - 1);
  });
  document.getElementById('logs-next').addEventListener('click', () => {
    loadLogs(currentLogsPage + 1);
  });

  // ---- Settings ----
  const settingsLogsSelect = document.getElementById('settings-logschannel');
  enhanceDropdown(settingsLogsSelect);

  async function loadSettings() {
    const [channelsRes, securityRes] = await Promise.all([
      fetch(`/api/guild/${guildId}/channels`),
      fetch(`/api/guild/${guildId}/security`)
    ]);
    const channels = await channelsRes.json();
    const settings = await securityRes.json();

    settingsLogsSelect.innerHTML = '<option value="">Tidak ada</option>' +
      channels.map((c) => `<option value="${c.id}" ${settings.logsChannel === c.id ? 'selected' : ''}>#${c.name}</option>`).join('');
    syncDropdownOptions(settingsLogsSelect);
  }

  document.getElementById('settings-save-logs').addEventListener('click', async () => {
    const channelId = settingsLogsSelect.value;
    try {
      const res = await apiMutate(`/api/guild/${guildId}/logschannel`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ channelId: channelId || null })
      });
      if (!res.ok) throw new Error();
      toast('Logs channel disimpan.', 'success');
    } catch (err) {
      toast('Gagal menyimpan logs channel.', 'error');
    }
  });

  // ---- Bot Settings (Owner only) ----
  function fileToDataUrl(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }

  async function loadBotProfile() {
    try {
      const res = await fetch('/api/owner/bot/profile');
      if (!res.ok) return;
      const data = await res.json();
      document.getElementById('bs-current-avatar').src = data.avatar;
      document.getElementById('bs-current-username').textContent = data.username;
      document.getElementById('bs-username').placeholder = data.username;
      document.getElementById('bs-description').value = data.description || '';
    } catch (err) {
      console.error('Failed to load bot profile', err);
    }
  }

  // ---- Custom file input filename display ----
  function wireFileInput(inputId, labelId) {
    const input = document.getElementById(inputId);
    const label = document.getElementById(labelId);
    if (!input || !label) return;
    input.addEventListener('change', () => {
      const file = input.files[0];
      label.textContent = file ? file.name : 'Tidak ada file dipilih';
    });
  }
  wireFileInput('bs-avatar-file', 'bs-avatar-filename');
  wireFileInput('bs-banner-file', 'bs-banner-filename');

  const bsSaveUsername = document.getElementById('bs-save-username');
  if (bsSaveUsername) bsSaveUsername.addEventListener('click', async () => {
    const username = document.getElementById('bs-username').value.trim();
    if (!username) return toast('Masukkan username baru.', 'error');
    bsSaveUsername.disabled = true;
    try {
      const result = await apiMutate('/api/owner/bot/username', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username })
      });
      const data = await result.json();
      if (!result.ok) return toast(data.error || 'Gagal mengubah username.', 'error');
      toast('Username bot berhasil diubah.', 'success');
      loadBotProfile();
    } catch (err) {
      toast('Gagal mengubah username.', 'error');
    } finally {
      bsSaveUsername.disabled = false;
    }
  });

  const bsSaveAvatar = document.getElementById('bs-save-avatar');
  if (bsSaveAvatar) bsSaveAvatar.addEventListener('click', async () => {
    const file = document.getElementById('bs-avatar-file').files[0];
    if (!file) return toast('Pilih file gambar terlebih dahulu.', 'error');
    bsSaveAvatar.disabled = true;
    try {
      const image = await fileToDataUrl(file);
      const result = await apiMutate('/api/owner/bot/avatar', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ image })
      });
      const data = await result.json();
      if (!result.ok) return toast(data.error || 'Gagal mengubah avatar.', 'error');
      toast('Avatar bot berhasil diubah.', 'success');
      document.getElementById('bs-avatar-file').value = '';
      document.getElementById('bs-avatar-filename').textContent = 'Tidak ada file dipilih';
      loadBotProfile();
    } catch (err) {
      toast('Gagal mengubah avatar.', 'error');
    } finally {
      bsSaveAvatar.disabled = false;
    }
  });

  const bsSaveBanner = document.getElementById('bs-save-banner');
  if (bsSaveBanner) bsSaveBanner.addEventListener('click', async () => {
    const file = document.getElementById('bs-banner-file').files[0];
    if (!file) return toast('Pilih file gambar terlebih dahulu.', 'error');
    bsSaveBanner.disabled = true;
    try {
      const image = await fileToDataUrl(file);
      const result = await apiMutate('/api/owner/bot/banner', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ image })
      });
      const data = await result.json();
      if (!result.ok) return toast(data.error || 'Gagal mengubah banner.', 'error');
      toast('Banner bot berhasil diubah.', 'success');
      document.getElementById('bs-banner-file').value = '';
      document.getElementById('bs-banner-filename').textContent = 'Tidak ada file dipilih';
    } catch (err) {
      toast('Gagal mengubah banner.', 'error');
    } finally {
      bsSaveBanner.disabled = false;
    }
  });

  const bsSaveDescription = document.getElementById('bs-save-description');
  if (bsSaveDescription) bsSaveDescription.addEventListener('click', async () => {
    const description = document.getElementById('bs-description').value;
    bsSaveDescription.disabled = true;
    try {
      const result = await apiMutate('/api/owner/bot/description', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ description })
      });
      const data = await result.json();
      if (!result.ok) return toast(data.error || 'Gagal mengubah deskripsi.', 'error');
      toast('Deskripsi bot berhasil disimpan.', 'success');
    } catch (err) {
      toast('Gagal mengubah deskripsi.', 'error');
    } finally {
      bsSaveDescription.disabled = false;
    }
  });

  const bsRestart = document.getElementById('bs-restart');
  if (bsRestart) bsRestart.addEventListener('click', async () => {
    const confirmed = await confirmDialog('Yakin ingin restart bot sekarang? Bot akan offline sesaat.');
    if (!confirmed) return;
    try {
      const res = await apiMutate('/api/owner/bot/restart', { method: 'POST' });
      if (!res.ok) throw new Error();
      toast('Perintah restart terkirim. Bot akan online kembali dalam beberapa detik.', 'success');
    } catch (err) {
      toast('Gagal mengirim perintah restart.', 'error');
    }
  });

  // ---- Realtime sync via Socket.IO ----
  socket.on('settingsUpdated', (payload) => {
    if (payload.guildId !== guildId) return;
    if (!document.getElementById('tab-security').classList.contains('hidden')) loadSecurity();
    if (!document.getElementById('tab-logs').classList.contains('hidden')) loadSettings();
  });

  socket.on('whitelistUpdated', (payload) => {
    if (payload.guildId !== guildId) return;
    if (!document.getElementById('tab-logs').classList.contains('hidden')) loadWhitelist();
  });

  socket.on('newLog', (payload) => {
    if (payload.guildId !== guildId) return;
    if (!document.getElementById('tab-logs').classList.contains('hidden') && currentLogsPage === 1) {
      loadLogs(1);
    }
  });

  // Initial load
  loadOverview();
  loadOwnerInfo('ov-owner');
  loadOverviewMembers(1, '');
  setInterval(() => {
    if (!document.getElementById('tab-overview').classList.contains('hidden')) loadOverview();
    if (!document.getElementById('tab-botinfo').classList.contains('hidden')) loadBotInfo();
  }, 10000);
})();
