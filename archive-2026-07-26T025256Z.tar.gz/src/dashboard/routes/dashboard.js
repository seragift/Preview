const express = require('express');
const fs = require('fs');
const path = require('path');
const { ensureAuthenticated, isOwner, resolveGuildAccess } = require('../middleware/auth');
const { getBotIdentity } = require('../../utils/botIdentity');

// Cache-busting version for /dashboard-assets/js/dashboard.js. The static
// middleware serves that file with a 7-day browser cache (maxAge: '7d'), so
// without a version query string, browsers keep running old cached JS after
// every deploy — new features/fixes silently don't take effect until the
// cache expires or the user hard-refreshes. Using the file's mtime as the
// version means the query string only changes when the file actually changes.
let dashboardJsVersion = String(Date.now());
try {
  const jsPath = path.join(__dirname, '..', 'public', 'js', 'dashboard.js');
  dashboardJsVersion = String(fs.statSync(jsPath).mtimeMs);
} catch (e) {
  // fall back to boot-time timestamp if the file can't be stat'd
}

let colorpickerJsVersion = String(Date.now());
try {
  const cpPath = path.join(__dirname, '..', 'public', 'js', 'colorpicker.js');
  colorpickerJsVersion = String(fs.statSync(cpPath).mtimeMs);
} catch (e) {
  // fall back to boot-time timestamp if the file can't be stat'd
}

module.exports = function dashboardRoutes(client) {
  const router = express.Router();

  // List of servers the user belongs to (or all servers if bot owner).
  // Any member — not just admins — can see and open their server's
  // dashboard; what they can do once inside depends on their access level
  // (resolved per-guild in the "/:guildId" route below).
  router.get('/', ensureAuthenticated, (req, res) => {
    const ownerAccess = isOwner(req.user);

    let visibleGuildIds;
    if (ownerAccess) {
      visibleGuildIds = new Set(client.guilds.cache.map((g) => g.id));
    } else {
      visibleGuildIds = new Set(
        (req.user.guilds || [])
          .map((g) => g.id)
          .filter((id) => client.guilds.cache.has(id))
      );
    }

    const guilds = [...visibleGuildIds]
      .map((id) => client.guilds.cache.get(id))
      .filter(Boolean)
      .map((g) => ({
        id: g.id,
        name: g.name,
        icon: g.iconURL({ size: 128 }),
        memberCount: g.memberCount
      }));

    res.render('server-select', { user: req.user, guilds, ...getBotIdentity(client) });
  });

  router.get('/:guildId', ensureAuthenticated, async (req, res) => {
    const guild = client.guilds.cache.get(req.params.guildId);
    if (!guild) return res.redirect('/dashboard');

    const access = await resolveGuildAccess(client, req.user, req.params.guildId);
    if (access.level === 'none') return res.redirect('/dashboard');

    res.render('dashboard', {
      user: req.user,
      guildId: guild.id,
      guildName: guild.name,
      guildIcon: guild.iconURL({ size: 128 }),
      accessLevel: access.level, // 'owner' | 'admin' | 'member'
      isOwnerAccess: access.level === 'owner',
      isAdminAccess: access.level === 'owner' || access.level === 'admin',
      dashboardJsVersion,
      colorpickerJsVersion,
      ...getBotIdentity(client)
    });
  });

  return router;
};
