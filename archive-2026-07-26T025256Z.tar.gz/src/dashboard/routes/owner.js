const express = require('express');
const { ensureAuthenticated, isOwner } = require('../middleware/auth');

function requireOwner(req, res, next) {
  if (!req.isAuthenticated || !req.isAuthenticated()) return res.redirect('/');
  if (!isOwner(req.user)) return res.status(403).json({ error: 'Fitur ini khusus untuk Owner Bot.' });
  next();
}

module.exports = function ownerRoutes(client) {
  const router = express.Router();
  router.use(ensureAuthenticated, requireOwner);

  // ---- Rename bot ----
  router.post('/bot/username', async (req, res) => {
    try {
      const { username } = req.body;
      if (!username || username.length < 2 || username.length > 32) {
        return res.status(400).json({ error: 'Username harus 2-32 karakter.' });
      }
      await client.user.setUsername(username);
      res.json({ ok: true, username: client.user.username });
    } catch (err) {
      // Discord rate-limits username changes to ~2x/hour
      res.status(500).json({ error: err.message });
    }
  });

  // ---- Avatar (profile picture) ----
  router.post('/bot/avatar', async (req, res) => {
    try {
      const { image } = req.body; // base64 data URI
      if (!image) return res.status(400).json({ error: 'Gambar diperlukan.' });
      await client.user.setAvatar(image);
      res.json({ ok: true, avatar: client.user.displayAvatarURL({ size: 256 }) });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // ---- Banner ----
  router.post('/bot/banner', async (req, res) => {
    try {
      const { image } = req.body; // base64 data URI
      if (!image) return res.status(400).json({ error: 'Gambar diperlukan.' });
      await client.user.setBanner(image);
      res.json({ ok: true });
    } catch (err) {
      res.status(500).json({ error: err.message + ' (Fitur banner memerlukan boost level tertentu pada beberapa akun bot).' });
    }
  });

  // ---- Bio / Application description ----
  router.post('/bot/description', async (req, res) => {
    try {
      const { description } = req.body;
      if (typeof description !== 'string' || description.length > 400) {
        return res.status(400).json({ error: 'Deskripsi maksimal 400 karakter.' });
      }
      if (!client.application) await client.application.fetch();
      await client.application.edit({ description });
      res.json({ ok: true, description });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // ---- Current profile snapshot ----
  router.get('/bot/profile', async (req, res) => {
    try {
      if (client.application && !client.application.description) await client.application.fetch().catch(() => {});
      res.json({
        username: client.user.username,
        avatar: client.user.displayAvatarURL({ size: 256 }),
        description: client.application?.description || ''
      });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // ---- Restart process ----
  // Requires the bot to run under a process manager (pm2, systemd, docker --restart)
  // that automatically restarts the process after it exits.
  router.post('/bot/restart', (req, res) => {
    res.json({ ok: true, message: 'Bot sedang restart...' });
    setTimeout(() => process.exit(0), 500);
  });

  return router;
};
