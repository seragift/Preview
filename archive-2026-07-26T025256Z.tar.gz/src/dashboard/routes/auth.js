const express = require('express');
const passport = require('passport');

module.exports = function authRoutes() {
  const router = express.Router();

  router.get('/discord', passport.authenticate('discord'));

  router.get(
    '/discord/callback',
    passport.authenticate('discord', { failureRedirect: '/' }),
    (req, res) => {
      res.redirect('/dashboard');
    }
  );

  router.get('/logout', (req, res) => {
    req.logout(() => {
      req.session.destroy(() => {
        res.redirect('/');
      });
    });
  });

  return router;
};
