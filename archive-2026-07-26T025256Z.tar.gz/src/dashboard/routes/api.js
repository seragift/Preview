const express = require('express');
const os = require('os');
const { AttachmentBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType } = require('discord.js');
const config = require('../../../config.json');
const {
  getGuildSettings,
  updateGuildSetting,
  updateGuildThresholds,
  THRESHOLD_DEFAULTS,
  setAllSecurity,
  getWhitelist,
  addWhitelist,
  removeWhitelist,
  getLogs,
  countLogs,
  addLog,
  listToxicWords,
  addToxicWord,
  removeToxicWord,
  listTicketPanels,
  getTicketPanelById,
  createTicketPanel,
  updateTicketPanel,
  deleteTicketPanel
} = require('../../database/schema');
const { buildPanelPayload } = require('../../utils/ticketManager');
const { invalidateCache: invalidateToxicCache } = require('../../utils/antitoxic');
const { ensureAuthenticated, ensureGuildAccess, ensureGuildMember, canModerateMember, isOwner } = require('../middleware/auth');

const SECURITY_FIELDS = ['antinuke', 'antilink', 'antitoxic', 'antispam', 'antimultichannelspam', 'antiraid'];

// Per-server security thresholds (moved out of config.json so each server's admin can
// tune them independently from the dashboard). min/max keep values sane.
const THRESHOLD_LIMITS = {
  antinuke_actionThreshold: { min: 1, max: 50 },
  antinuke_actionWindowMs: { min: 1000, max: 600000 },
  antispam_windowShortMs: { min: 1000, max: 60000 },
  antispam_windowShortCount: { min: 1, max: 50 },
  antispam_windowLongMs: { min: 1000, max: 300000 },
  antispam_windowLongCount: { min: 1, max: 100 },
  antispam_multiChannelWindowMs: { min: 1000, max: 120000 },
  antispam_multiChannelThreshold: { min: 1, max: 20 },
  antispam_repeatedCharThreshold: { min: 2, max: 100 },
  antispam_mentionThreshold: { min: 1, max: 50 },
  antispam_emojiThreshold: { min: 1, max: 50 },
  antiraid_joinWindowMs: { min: 1000, max: 300000 },
  antiraid_joinThreshold: { min: 1, max: 100 },
  antiraid_newAccountAgeMs: { min: 0, max: 31536000000 },
  antiraid_lockdownDurationMs: { min: 0, max: 86400000 }
};
const THRESHOLD_FIELDS = Object.keys(THRESHOLD_LIMITS);

module.exports = function apiRoutes(client, io) {
  const router = express.Router();

  // ---- Public stats for landing page ----
  router.get('/public/stats', (req, res) => {
    const totalMembers = client.guilds.cache.reduce((acc, g) => acc + (g.memberCount || 0), 0);
    res.json({
      totalServers: client.guilds.cache.size,
      totalMembers,
      uptime: process.uptime(),
      status: client.ws.status === 0 ? 'online' : 'connecting',
      ping: client.ws.ping
    });
  });

  // ---- Bot info (global, not tied to a single guild) ----
  router.get('/bot/info', ensureAuthenticated, async (req, res) => {
    try {
      const memUsage = process.memoryUsage();
      const totalMembers = client.guilds.cache.reduce((acc, g) => acc + (g.memberCount || 0), 0);

      let owner = null;
      const ownerId = (config.ownerIds || [])[0];
      if (ownerId) {
        try {
          const ownerUser = await client.users.fetch(ownerId);
          owner = {
            id: ownerUser.id,
            tag: ownerUser.tag,
            username: ownerUser.username,
            avatar: ownerUser.displayAvatarURL({ size: 128 })
          };
        } catch (e) {
          // owner id not resolvable (invalid config or bot can't see the user) — skip silently
        }
      }

      res.json({
        botName: client.user ? client.user.username : null,
        botTag: client.user ? client.user.tag : null,
        botAvatar: client.user ? client.user.displayAvatarURL({ size: 128 }) : null,
        owner,
        serverCount: client.guilds.cache.size,
        totalMembers,
        ping: client.ws.ping,
        ramUsageMB: Math.round(memUsage.rss / 1024 / 1024),
        cpuLoad: os.loadavg()[0].toFixed(2),
        uptimeSeconds: process.uptime()
      });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // ---- Global server list (all authenticated users) — lightweight, cache-only data ----
  router.get('/bot/guilds', ensureAuthenticated, (req, res) => {
    try {
      const guilds = client.guilds.cache
        .map((g) => ({
          id: g.id,
          name: g.name,
          icon: g.iconURL({ size: 64 }),
          memberCount: g.memberCount || 0
        }))
        .sort((a, b) => b.memberCount - a.memberCount);

      res.json({ guilds });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // ---- Global server detail (all authenticated users) ----
  router.get('/bot/guilds/:guildId/detail', ensureAuthenticated, async (req, res) => {
    try {
      const guild = client.guilds.cache.get(req.params.guildId);
      if (!guild) return res.status(404).json({ error: 'Bot tidak berada di server ini.' });

      const fetched = await guild.members.fetch();
      const onlineMembers = fetched.filter(
        (m) => m.presence && m.presence.status && m.presence.status !== 'offline'
      ).size;

      let owner = null;
      try {
        const ownerMember = await guild.fetchOwner();
        owner = {
          id: ownerMember.id,
          tag: ownerMember.user.tag,
          username: ownerMember.user.username,
          avatar: ownerMember.user.displayAvatarURL({ size: 128 })
        };
      } catch (e) {
        // owner not resolvable — skip silently
      }

      res.json({
        id: guild.id,
        name: guild.name,
        icon: guild.iconURL({ size: 128 }),
        owner,
        memberCount: guild.memberCount || 0,
        onlineMembers,
        roleCount: Math.max(guild.roles.cache.size - 1, 0),
        channelCount: guild.channels.cache.size
      });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // ---- Overview (guild-scoped only, read-only for any member) ----
  router.get('/guild/:guildId/overview', ensureAuthenticated, ensureGuildMember(client), async (req, res) => {
    try {
      const guild = client.guilds.cache.get(req.params.guildId);
      const fetched = await guild.members.fetch();
      const members = [...fetched.values()];

      const botCount = members.filter((m) => m.user.bot).length;
      const memberCount = members.length - botCount;

      // Online members relies on presence cache (needs GuildPresences intent + the
      // "Presence Intent" toggle enabled in the Discord Developer Portal). If the
      // intent isn't enabled, presence will be undefined for everyone and this
      // will read 0 — that's expected, not a bug.
      const onlineMembers = members.filter(
        (m) => m.presence && m.presence.status && m.presence.status !== 'offline'
      ).length;

      const roleCount = Math.max(guild.roles.cache.size - 1, 0); // exclude @everyone
      const adminRoleCount = guild.roles.cache.filter(
        (r) => r.id !== guild.id && r.permissions.has('Administrator')
      ).size;

      res.json({
        memberCount,
        botCount,
        onlineMembers,
        channelCount: guild.channels.cache.size,
        roleCount,
        adminRoleCount
      });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // ---- Administrators list (non-bot members holding Administrator, or the guild owner) ----
  router.get('/guild/:guildId/admins', ensureAuthenticated, ensureGuildAccess(client), async (req, res) => {
    try {
      const guild = client.guilds.cache.get(req.params.guildId);
      const fetched = await guild.members.fetch();
      const search = (req.query.search || '').trim().toLowerCase();

      let admins = [...fetched.values()].filter(
        (m) => !m.user.bot && (m.id === guild.ownerId || m.permissions.has('Administrator'))
      );

      if (search) {
        admins = admins.filter(
          (m) => m.user.username.toLowerCase().includes(search) || m.displayName.toLowerCase().includes(search)
        );
      }

      const result = admins
        .map((m) => ({
          id: m.id,
          tag: m.user.tag,
          displayName: m.displayName,
          avatar: m.user.displayAvatarURL({ size: 64 }),
          isOwner: m.id === guild.ownerId,
          category: m.id === guild.ownerId ? 'Owner' : 'Administrator',
          status: m.presence ? m.presence.status : 'offline'
        }))
        .sort((a, b) => (b.isOwner - a.isOwner) || a.displayName.localeCompare(b.displayName));

      res.json(result);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // ---- Security settings ----
  router.get('/guild/:guildId/security', ensureAuthenticated, ensureGuildAccess(client), async (req, res) => {
    try {
      const settings = await getGuildSettings(req.params.guildId);
      res.json(settings);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  router.post('/guild/:guildId/security', ensureAuthenticated, ensureGuildAccess(client), async (req, res) => {
    try {
      const { field, value } = req.body;

      if (field === 'all') {
        const settings = await setAllSecurity(req.params.guildId, value ? 1 : 0);
        io.to(`guild:${req.params.guildId}`).emit('settingsUpdated', { guildId: req.params.guildId });
        return res.json(settings);
      }

      if (!SECURITY_FIELDS.includes(field)) {
        return res.status(400).json({ error: 'Invalid security field' });
      }

      const settings = await updateGuildSetting(req.params.guildId, field, value ? 1 : 0);
      io.to(`guild:${req.params.guildId}`).emit('settingsUpdated', { guildId: req.params.guildId });
      res.json(settings);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // ---- Security thresholds (per-server, previously in config.json) ----
  router.get('/guild/:guildId/security-config', ensureAuthenticated, ensureGuildAccess(client), async (req, res) => {
    try {
      const settings = await getGuildSettings(req.params.guildId);
      const config = {};
      THRESHOLD_FIELDS.forEach((field) => {
        config[field] = settings[field] ?? THRESHOLD_DEFAULTS[field];
      });
      res.json(config);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  router.post('/guild/:guildId/security-config', ensureAuthenticated, ensureGuildAccess(client), async (req, res) => {
    try {
      const updates = {};
      for (const field of THRESHOLD_FIELDS) {
        if (req.body[field] === undefined) continue;
        const limits = THRESHOLD_LIMITS[field];
        const raw = Number(req.body[field]);
        if (!Number.isFinite(raw)) {
          return res.status(400).json({ error: `Nilai ${field} tidak valid` });
        }
        updates[field] = Math.min(limits.max, Math.max(limits.min, Math.round(raw)));
      }

      if (!Object.keys(updates).length) {
        return res.status(400).json({ error: 'Tidak ada field yang diperbarui' });
      }

      const settings = await updateGuildThresholds(req.params.guildId, updates);
      io.to(`guild:${req.params.guildId}`).emit('settingsUpdated', { guildId: req.params.guildId });
      res.json(settings);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // ---- Anti Toxic custom word list (per-server) ----
  router.get('/guild/:guildId/toxic-words', ensureAuthenticated, ensureGuildAccess(client), async (req, res) => {
    try {
      const words = await listToxicWords(req.params.guildId);
      res.json(words);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  router.post('/guild/:guildId/toxic-words', ensureAuthenticated, ensureGuildAccess(client), async (req, res) => {
    try {
      const word = String(req.body.word || '').toLowerCase().trim();
      if (!word || word.length > 64 || /\s/.test(word)) {
        return res.status(400).json({ error: 'Kata tidak valid' });
      }
      await addToxicWord(req.params.guildId, word);
      invalidateToxicCache(req.params.guildId);
      const words = await listToxicWords(req.params.guildId);
      res.json(words);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  router.delete('/guild/:guildId/toxic-words', ensureAuthenticated, ensureGuildAccess(client), async (req, res) => {
    try {
      const word = String(req.body.word || '').toLowerCase().trim();
      await removeToxicWord(req.params.guildId, word);
      invalidateToxicCache(req.params.guildId);
      const words = await listToxicWords(req.params.guildId);
      res.json(words);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  router.post('/guild/:guildId/logschannel', ensureAuthenticated, ensureGuildAccess(client), async (req, res) => {
    try {
      const { channelId } = req.body;
      const settings = await updateGuildSetting(req.params.guildId, 'logsChannel', channelId || null);
      io.to(`guild:${req.params.guildId}`).emit('settingsUpdated', { guildId: req.params.guildId });
      res.json(settings);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  router.get('/guild/:guildId/channels', ensureAuthenticated, ensureGuildAccess(client), (req, res) => {
    const guild = client.guilds.cache.get(req.params.guildId);
    const channels = guild.channels.cache
      .filter((c) => c.isTextBased() && !c.isThread())
      .map((c) => ({ id: c.id, name: c.name }));
    res.json(channels);
  });

  router.get('/guild/:guildId/roles', ensureAuthenticated, ensureGuildAccess(client), (req, res) => {
    const guild = client.guilds.cache.get(req.params.guildId);
    const roles = guild.roles.cache
      .filter((r) => r.id !== guild.id)
      .map((r) => ({ id: r.id, name: r.name, color: r.hexColor }));
    res.json(roles);
  });

  router.get('/guild/:guildId/categories', ensureAuthenticated, ensureGuildAccess(client), (req, res) => {
    const guild = client.guilds.cache.get(req.params.guildId);
    const categories = guild.channels.cache
      .filter((c) => c.type === ChannelType.GuildCategory)
      .map((c) => ({ id: c.id, name: c.name }));
    res.json(categories);
  });

  // ---- Ticket panels (list, create, edit, delete — multiple panels per guild) ----
  function validateTicketPayload(body) {
    const { channelId, category, roleId, panelType, message, color } = body;
    if (!channelId || !category || !roleId || !panelType || !message) {
      return 'Channel, kategori, role, tipe, dan pesan wajib diisi.';
    }
    if (color && !/^#?[0-9a-f]{6}$/i.test(color)) {
      return 'Format warna tidak valid. Gunakan format hex, contoh #00d4ff.';
    }
    return null;
  }

  router.get('/guild/:guildId/ticket-panels', ensureAuthenticated, ensureGuildAccess(client), async (req, res) => {
    try {
      const panels = await listTicketPanels(req.params.guildId);
      res.json(panels);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  router.post('/guild/:guildId/ticket-panels', ensureAuthenticated, ensureGuildAccess(client), async (req, res) => {
    try {
      const {
        channelId, category, roleId, panelType, title, message,
        emoji, color, welcomeMessage, transcriptChannelId, sendPanel
      } = req.body;

      const validationError = validateTicketPayload(req.body);
      if (validationError) return res.status(400).json({ error: validationError });

      const guild = client.guilds.cache.get(req.params.guildId);

      let panel = await createTicketPanel(req.params.guildId, {
        panelChannelId: channelId,
        category,
        staffRoleId: roleId,
        panelType,
        panelTitle: title || 'Support Ticket',
        panelDescription: message,
        panelEmoji: emoji || '🎫',
        panelColor: color || '#00d4ff',
        welcomeMessage: welcomeMessage || 'Halo {user}, terima kasih telah membuka ticket. Tim {role} akan segera membantu Anda. Mohon jelaskan kendala Anda secara detail.',
        transcriptChannelId: transcriptChannelId || null
      });

      if (sendPanel) {
        const channel = guild.channels.cache.get(channelId);
        if (!channel) return res.status(400).json({ error: 'Channel tujuan tidak ditemukan.' });

        const payload = buildPanelPayload(panel);
        let panelMessage;
        try {
          panelMessage = await channel.send(payload);
        } catch (err) {
          return res.status(500).json({ error: `Gagal mengirim panel: ${err.message}` });
        }
        panel = await updateTicketPanel(panel.id, { panelMessageId: panelMessage.id });
      }

      res.json(panel);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  router.put('/guild/:guildId/ticket-panels/:panelId', ensureAuthenticated, ensureGuildAccess(client), async (req, res) => {
    try {
      const existing = await getTicketPanelById(req.params.panelId);
      if (!existing || existing.guildId !== req.params.guildId) {
        return res.status(404).json({ error: 'Panel tidak ditemukan.' });
      }

      const {
        channelId, category, roleId, panelType, title, message,
        emoji, color, welcomeMessage, transcriptChannelId, resendPanel
      } = req.body;

      const validationError = validateTicketPayload(req.body);
      if (validationError) return res.status(400).json({ error: validationError });

      const guild = client.guilds.cache.get(req.params.guildId);

      let panel = await updateTicketPanel(existing.id, {
        panelChannelId: channelId,
        category,
        staffRoleId: roleId,
        panelType,
        panelTitle: title || 'Support Ticket',
        panelDescription: message,
        panelEmoji: emoji || '🎫',
        panelColor: color || '#00d4ff',
        welcomeMessage: welcomeMessage || 'Halo {user}, terima kasih telah membuka ticket. Tim {role} akan segera membantu Anda. Mohon jelaskan kendala Anda secara detail.',
        transcriptChannelId: transcriptChannelId || null
      });

      // Keep the live Discord message in sync with the edited panel, when possible.
      const channel = guild?.channels.cache.get(panel.panelChannelId);
      if (channel && panel.panelMessageId) {
        const existingMessage = await channel.messages.fetch(panel.panelMessageId).catch(() => null);
        if (existingMessage) {
          await existingMessage.edit(buildPanelPayload(panel)).catch(() => {});
        } else if (resendPanel && channel) {
          const sent = await channel.send(buildPanelPayload(panel)).catch(() => null);
          if (sent) panel = await updateTicketPanel(panel.id, { panelMessageId: sent.id });
        }
      } else if (resendPanel && channel) {
        const sent = await channel.send(buildPanelPayload(panel)).catch(() => null);
        if (sent) panel = await updateTicketPanel(panel.id, { panelMessageId: sent.id });
      }

      res.json(panel);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  router.delete('/guild/:guildId/ticket-panels/:panelId', ensureAuthenticated, ensureGuildAccess(client), async (req, res) => {
    try {
      const existing = await getTicketPanelById(req.params.panelId);
      if (!existing || existing.guildId !== req.params.guildId) {
        return res.status(404).json({ error: 'Panel tidak ditemukan.' });
      }

      // Best-effort: remove the live panel message/embed from Discord too.
      const guild = client.guilds.cache.get(req.params.guildId);
      const channel = guild?.channels.cache.get(existing.panelChannelId);
      if (channel && existing.panelMessageId) {
        const msg = await channel.messages.fetch(existing.panelMessageId).catch(() => null);
        if (msg) await msg.delete().catch(() => {});
      }

      await deleteTicketPanel(existing.id);
      res.json({ success: true });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // ---- Announcement ----
  function parseImageDataUrl(dataUrl, name) {
    const match = /^data:(image\/[a-zA-Z0-9.+-]+);base64,(.+)$/.exec(dataUrl || '');
    if (!match) return null;
    const ext = match[1].split('/')[1].split('+')[0];
    const buffer = Buffer.from(match[2], 'base64');
    return new AttachmentBuilder(buffer, { name: `${name}.${ext}` });
  }

  router.post('/guild/:guildId/announcement', ensureAuthenticated, ensureGuildAccess(client), async (req, res) => {
    try {
      const guild = client.guilds.cache.get(req.params.guildId);
      const { channelId, title, description, image, icon, tag, roleId, buttonTitle, buttonLink } = req.body;

      if (!channelId || !title || !description) {
        return res.status(400).json({ error: 'Channel, title, dan deskripsi wajib diisi.' });
      }

      const channel = guild.channels.cache.get(channelId);
      if (!channel || !channel.isTextBased()) {
        return res.status(400).json({ error: 'Channel tidak valid.' });
      }

      if (tag === 'role' && !roleId) {
        return res.status(400).json({ error: 'Role wajib dipilih jika tag: Role tertentu.' });
      }

      if ((buttonTitle && !buttonLink) || (buttonLink && !buttonTitle)) {
        return res.status(400).json({ error: 'Judul tombol dan link tombol harus diisi bersamaan.' });
      }

      if (buttonLink && !/^https?:\/\//i.test(buttonLink)) {
        return res.status(400).json({ error: 'Link tombol harus berupa URL valid (diawali http:// atau https://).' });
      }

      const files = [];
      const embed = new EmbedBuilder()
        .setColor(0x00d4ff)
        .setTitle(title)
        .setDescription(description)
        .setTimestamp()
        .setFooter({ text: `Diumumkan oleh ${req.user.username}` });

      if (image) {
        const attachment = parseImageDataUrl(image, 'image');
        if (!attachment) return res.status(400).json({ error: 'Format gambar image tidak valid.' });
        files.push(attachment);
        embed.setImage(`attachment://${attachment.name}`);
      }

      if (icon) {
        const attachment = parseImageDataUrl(icon, 'icon');
        if (!attachment) return res.status(400).json({ error: 'Format gambar icon tidak valid.' });
        files.push(attachment);
        embed.setThumbnail(`attachment://${attachment.name}`);
      }

      const components = [];
      if (buttonTitle && buttonLink) {
        components.push(
          new ActionRowBuilder().addComponents(
            new ButtonBuilder().setLabel(buttonTitle).setURL(buttonLink).setStyle(ButtonStyle.Link)
          )
        );
      }

      let content;
      let allowedMentions = { parse: [] };
      if (tag === 'everyone') {
        content = '@everyone';
        allowedMentions = { parse: ['everyone'] };
      } else if (tag === 'here') {
        content = '@here';
        allowedMentions = { parse: ['everyone'] };
      } else if (tag === 'role' && roleId) {
        content = `<@&${roleId}>`;
        allowedMentions = { roles: [roleId] };
      }

      await channel.send({ content, embeds: [embed], files, components, allowedMentions });
      await addLog(req.params.guildId, 'ANNOUNCEMENT_SENT', req.user.id, `#${channel.name}: ${title}`);
      io.to(`guild:${req.params.guildId}`).emit('newLog', { guildId: req.params.guildId });

      res.json({ ok: true });
    } catch (err) {
      res.status(500).json({ error: err.message || 'Gagal mengirim pengumuman.' });
    }
  });

  // ---- Whitelist ----
  router.get('/guild/:guildId/whitelist', ensureAuthenticated, ensureGuildAccess(client), async (req, res) => {
    try {
      const guild = client.guilds.cache.get(req.params.guildId);
      const rows = await getWhitelist(req.params.guildId);

      const enriched = rows.map((row) => {
        let label = row.targetId;
        if (row.type === 'channel') label = guild.channels.cache.get(row.targetId)?.name || row.targetId;
        if (row.type === 'role') label = guild.roles.cache.get(row.targetId)?.name || row.targetId;
        if (row.type === 'user') label = guild.members.cache.get(row.targetId)?.user.tag || row.targetId;
        return { ...row, label };
      });

      res.json(enriched);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  router.post('/guild/:guildId/whitelist', ensureAuthenticated, ensureGuildAccess(client), async (req, res) => {
    try {
      const { type, targetId } = req.body;
      if (!['channel', 'role', 'user'].includes(type) || !targetId) {
        return res.status(400).json({ error: 'Invalid whitelist payload' });
      }
      await addWhitelist(req.params.guildId, type, targetId);
      io.to(`guild:${req.params.guildId}`).emit('whitelistUpdated', { guildId: req.params.guildId });
      res.json({ ok: true });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  router.delete('/guild/:guildId/whitelist', ensureAuthenticated, ensureGuildAccess(client), async (req, res) => {
    try {
      const { type, targetId } = req.body;
      await removeWhitelist(req.params.guildId, type, targetId);
      io.to(`guild:${req.params.guildId}`).emit('whitelistUpdated', { guildId: req.params.guildId });
      res.json({ ok: true });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // ---- Guild owner info (any member can view) ----
  router.get('/guild/:guildId/owner', ensureAuthenticated, ensureGuildMember(client), async (req, res) => {
    try {
      const guild = client.guilds.cache.get(req.params.guildId);
      const owner = await guild.fetchOwner();
      res.json({
        id: owner.id,
        tag: owner.user.tag,
        avatar: owner.user.displayAvatarURL({ size: 64 })
      });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // ---- Members (viewable by any guild member; mutations further down are admin-only + role-hierarchy checked) ----
  router.get('/guild/:guildId/members', ensureAuthenticated, ensureGuildMember(client), async (req, res) => {
    try {
      const guild = client.guilds.cache.get(req.params.guildId);
      const search = (req.query.search || '').trim().toLowerCase();
      const page = Math.max(parseInt(req.query.page) || 1, 1);
      const limit = 15;

      let members;
      if (search) {
        const fetched = await guild.members.fetch({ query: search, limit: 100 });
        members = [...fetched.values()];
      } else {
        const fetched = await guild.members.fetch({ limit: 1000 });
        members = [...fetched.values()];
      }

      members.sort((a, b) => a.user.username.localeCompare(b.user.username));

      const total = members.length;
      const start = (page - 1) * limit;
      const pageItems = members.slice(start, start + limit).map((m) => ({
        id: m.id,
        tag: m.user.tag,
        username: m.user.username,
        displayName: m.displayName,
        avatar: m.user.displayAvatarURL({ size: 64 }),
        isOwner: m.id === guild.ownerId,
        isBot: m.user.bot,
        roles: m.roles.cache
          .filter((r) => r.id !== guild.id)
          .map((r) => ({ id: r.id, name: r.name, color: r.hexColor }))
      }));

      res.json({ members: pageItems, total, page, totalPages: Math.max(Math.ceil(total / limit), 1) });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // ---- Member detail (created date, join date, roles, status) — any guild member can view ----
  router.get('/guild/:guildId/members/:memberId/detail', ensureAuthenticated, ensureGuildMember(client), async (req, res) => {
    try {
      const guild = client.guilds.cache.get(req.params.guildId);
      const member = await guild.members.fetch(req.params.memberId);

      res.json({
        id: member.id,
        tag: member.user.tag,
        username: member.user.username,
        displayName: member.displayName,
        avatar: member.user.displayAvatarURL({ size: 128 }),
        isOwner: member.id === guild.ownerId,
        isBot: member.user.bot,
        isAdministrator: member.permissions.has('Administrator'),
        createdAt: member.user.createdTimestamp,
        joinedAt: member.joinedTimestamp,
        status: member.presence ? member.presence.status : 'offline',
        roles: member.roles.cache
          .filter((r) => r.id !== guild.id)
          .sort((a, b) => b.position - a.position)
          .map((r) => ({ id: r.id, name: r.name, color: r.hexColor }))
      });
    } catch (err) {
      res.status(404).json({ error: 'Member tidak ditemukan.' });
    }
  });

  // ---- Kick member (guild admins, respecting role hierarchy — bot owner bypasses) ----
  router.post('/guild/:guildId/members/:memberId/kick', ensureAuthenticated, ensureGuildAccess(client), async (req, res) => {
    try {
      const guild = client.guilds.cache.get(req.params.guildId);
      const member = await guild.members.fetch(req.params.memberId);

      if (member.id === guild.ownerId) {
        return res.status(400).json({ error: 'Tidak bisa kick Owner Server.' });
      }

      const modCheck = await canModerateMember(client, req.params.guildId, req.user, req.params.memberId);
      if (!modCheck.allowed) return res.status(403).json({ error: modCheck.reason });

      if (!member.kickable) {
        return res.status(400).json({ error: 'Bot tidak memiliki izin untuk kick member ini. Pastikan posisi role bot lebih tinggi.' });
      }

      const reason = (req.body && req.body.reason) || `Kick via dashboard oleh ${req.user.username}`;
      const tag = member.user.tag;
      await member.kick(reason);
      await addLog(req.params.guildId, 'MEMBER_KICK', member.id, reason);
      io.to(`guild:${req.params.guildId}`).emit('newLog', { guildId: req.params.guildId });
      res.json({ ok: true, tag });
    } catch (err) {
      res.status(500).json({ error: err.message || 'Gagal kick member.' });
    }
  });

  // ---- Ban member (guild admins, respecting role hierarchy — bot owner bypasses) ----
  router.post('/guild/:guildId/members/:memberId/ban', ensureAuthenticated, ensureGuildAccess(client), async (req, res) => {
    try {
      const guild = client.guilds.cache.get(req.params.guildId);
      const member = await guild.members.fetch(req.params.memberId);

      if (member.id === guild.ownerId) {
        return res.status(400).json({ error: 'Tidak bisa ban Owner Server.' });
      }

      const modCheck = await canModerateMember(client, req.params.guildId, req.user, req.params.memberId);
      if (!modCheck.allowed) return res.status(403).json({ error: modCheck.reason });

      if (!member.bannable) {
        return res.status(400).json({ error: 'Bot tidak memiliki izin untuk ban member ini. Pastikan posisi role bot lebih tinggi.' });
      }

      const reason = (req.body && req.body.reason) || `Ban via dashboard oleh ${req.user.username}`;
      const deleteMessageSeconds = Math.min(Math.max(parseInt(req.body?.deleteMessageDays) || 0, 0), 7) * 86400;
      const tag = member.user.tag;
      await member.ban({ reason, deleteMessageSeconds });
      await addLog(req.params.guildId, 'MEMBER_BAN', member.id, reason);
      io.to(`guild:${req.params.guildId}`).emit('newLog', { guildId: req.params.guildId });
      res.json({ ok: true, tag });
    } catch (err) {
      res.status(500).json({ error: err.message || 'Gagal ban member.' });
    }
  });

  router.post('/guild/:guildId/members/:memberId/roles', ensureAuthenticated, ensureGuildAccess(client), async (req, res) => {
    try {
      const guild = client.guilds.cache.get(req.params.guildId);
      const { roleId, action } = req.body;
      if (!roleId || !['add', 'remove'].includes(action)) {
        return res.status(400).json({ error: 'Payload tidak valid.' });
      }

      const role = guild.roles.cache.get(roleId);
      if (!role) return res.status(404).json({ error: 'Role tidak ditemukan.' });

      // Member-level hierarchy: can't manage a member whose highest role
      // outranks (or ties) yours. Also requires Manage Roles permission.
      const modCheck = await canModerateMember(client, req.params.guildId, req.user, req.params.memberId, {
        requireManageRoles: true
      });
      if (!modCheck.allowed) return res.status(403).json({ error: modCheck.reason });

      // Role-level hierarchy: bot owner bypasses; everyone else can only
      // assign/remove a role positioned below their own highest role.
      if (!isOwner(req.user) && modCheck.actorMember && modCheck.actorMember.id !== guild.ownerId) {
        if (role.position >= modCheck.actorMember.roles.highest.position) {
          return res.status(403).json({ error: 'Anda tidak bisa mengelola role yang sejajar atau lebih tinggi dari role Anda.' });
        }
      }

      const member = modCheck.targetMember || (await guild.members.fetch(req.params.memberId));

      if (action === 'add') await member.roles.add(role);
      else await member.roles.remove(role);

      res.json({
        ok: true,
        roles: member.roles.cache
          .filter((r) => r.id !== guild.id)
          .map((r) => ({ id: r.id, name: r.name, color: r.hexColor }))
      });
    } catch (err) {
      res.status(500).json({ error: err.message || 'Gagal mengubah role. Pastikan posisi role bot lebih tinggi dari role target.' });
    }
  });

  // ---- Logs ----
  router.get('/guild/:guildId/logs', ensureAuthenticated, ensureGuildAccess(client), async (req, res) => {
    try {
      const page = Math.max(parseInt(req.query.page) || 1, 1);
      const limit = 50;
      const offset = (page - 1) * limit;

      const [logs, total] = await Promise.all([
        getLogs(req.params.guildId, limit, offset),
        countLogs(req.params.guildId)
      ]);

      res.json({ logs, total, page, totalPages: Math.max(Math.ceil(total / limit), 1) });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  return router;
};
