const passport = require('passport');
const { Strategy: DiscordStrategy } = require('passport-discord');
const config = require('../../config.json');

const SCOPES = ['identify', 'guilds', 'guilds.members.read'];

function setupPassport() {
  passport.serializeUser((user, done) => done(null, user));
  passport.deserializeUser((user, done) => done(null, user));

  passport.use(
    new DiscordStrategy(
      {
        clientID: config.clientId || process.env.DISCORD_CLIENT_ID,
        clientSecret: config.clientSecret || process.env.DISCORD_CLIENT_SECRET,
        callbackURL: config.callbackURL || process.env.CALLBACK_URL,
        scope: SCOPES
      },
      (accessToken, refreshToken, profile, done) => {
        profile.accessToken = accessToken;
        process.nextTick(() => done(null, profile));
      }
    )
  );

  return passport;
}

module.exports = setupPassport;
