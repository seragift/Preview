const config = require('../../../config.json');

function ensureAuthenticated(req, res, next) {
  if (req.isAuthenticated && req.isAuthenticated()) return next();
  return res.redirect('/');
}

function isOwner(user) {
  const ownerIds = config.ownerIds || [];
  return ownerIds.includes(user.id);
}

const ADMINISTRATOR = 0x8;
const MANAGE_GUILD = 0x20;

/**
 * Checks OAuth2 guild permission bitfield (from req.user.guilds, the Discord
 * OAuth "guilds" scope list) for Administrator / Manage Guild.
 */
function hasAdminPermFlags(userGuild) {
  if (!userGuild) return false;
  const permissions = BigInt(userGuild.permissions || 0);
  return (
    (permissions & BigInt(ADMINISTRATOR)) === BigInt(ADMINISTRATOR) ||
    (permissions & BigInt(MANAGE_GUILD)) === BigInt(MANAGE_GUILD)
  );
}

/**
 * Resolves the user's access tier for a given guild:
 * - 'owner'  → global bot owner (config.ownerIds). Full access, bypasses role hierarchy.
 * - 'admin'  → guild owner, or holds ADMINISTRATOR / MANAGE_GUILD in that guild.
 *              Full dashboard access except the Owner Bot section.
 * - 'member' → any other member the bot can see in the guild. Read-only
 *              access (Overview + Info Bot only).
 * - 'none'   → not a member of the guild at all (or bot not in guild).
 *
 * Also resolves the member's highest role position (used for role-hierarchy
 * checks) and whether they hold Manage Roles.
 */
async function resolveGuildAccess(client, user, guildId) {
  const guild = client.guilds.cache.get(guildId);
  if (!guild) return { level: 'none', guild: null };

  if (isOwner(user)) {
    return { level: 'owner', guild, isGuildOwner: false, highestRolePosition: Infinity, manageRoles: true };
  }

  const userGuild = (user.guilds || []).find((g) => g.id === guildId);
  if (!userGuild) return { level: 'none', guild: null };

  let member = guild.members.cache.get(user.id);
  if (!member) {
    member = await guild.members.fetch(user.id).catch(() => null);
  }

  const isGuildOwner = !!member && member.id === guild.ownerId;
  const adminByOAuthFlags = hasAdminPermFlags(userGuild);
  const adminByMemberPerms = !!member && (member.permissions.has('Administrator') || member.permissions.has('ManageGuild'));
  const manageRoles = !!member && (member.permissions.has('Administrator') || member.permissions.has('ManageRoles'));

  const level = isGuildOwner || adminByOAuthFlags || adminByMemberPerms ? 'admin' : 'member';
  const highestRolePosition = isGuildOwner ? Infinity : member ? member.roles.highest.position : 0;

  return { level, guild, isGuildOwner, highestRolePosition, manageRoles };
}

/**
 * Ensures the logged-in user either:
 * - is a global bot owner (access to all servers), or
 * - has ADMINISTRATOR or MANAGE_GUILD permission on the requested guild.
 * The guild id is expected as req.params.guildId.
 * Use this to gate admin-only features (Security, Whitelist, Members
 * mutations, Bot Settings, Logs, Settings, etc).
 */
function ensureGuildAccess(client) {
  return async (req, res, next) => {
    if (!req.isAuthenticated || !req.isAuthenticated()) return res.redirect('/');

    const { guildId } = req.params;

    // Bot must actually be present in this guild — checked first, for
    // everyone (including the bot owner), so a bad/stale guildId in the
    // URL never reaches a route handler and crashes it.
    const guild = client.guilds.cache.get(guildId);
    if (!guild) return res.status(404).json({ error: 'Bot tidak berada di server ini.' });

    if (isOwner(req.user)) return next();

    const access = await resolveGuildAccess(client, req.user, guildId);
    if (access.level === 'none') return res.status(403).json({ error: 'Anda tidak memiliki akses ke server ini.' });
    if (access.level !== 'admin') {
      return res.status(403).json({ error: 'Anda memerlukan izin Administrator atau Manage Guild.' });
    }

    next();
  };
}

/**
 * Ensures the logged-in user is at least a plain member of the requested
 * guild (bot owner, admin, or regular member all pass). Use this for
 * read-only, guild-scoped data that every member should be able to see
 * (Overview stats, guild owner info, member list/detail for viewing).
 */
function ensureGuildMember(client) {
  return async (req, res, next) => {
    if (!req.isAuthenticated || !req.isAuthenticated()) return res.redirect('/');

    const { guildId } = req.params;
    const guild = client.guilds.cache.get(guildId);
    if (!guild) return res.status(404).json({ error: 'Bot tidak berada di server ini.' });

    if (isOwner(req.user)) return next();

    const access = await resolveGuildAccess(client, req.user, guildId);
    if (access.level === 'none') return res.status(403).json({ error: 'Anda bukan anggota server ini.' });

    next();
  };
}

/**
 * Checks whether `actorUser` is allowed to moderate (kick/ban/manage roles
 * of) `targetMemberId` in `guildId`, honoring Discord's natural role
 * hierarchy: a lower-ranked admin cannot act on an equally- or
 * higher-ranked admin. Bot owners bypass this check entirely. The guild
 * owner can moderate anyone (except itself, handled by the caller).
 */
async function canModerateMember(client, guildId, actorUser, targetMemberId, options = {}) {
  const guild = client.guilds.cache.get(guildId);
  if (!guild) return { allowed: false, reason: 'Bot tidak berada di server ini.' };

  if (isOwner(actorUser)) return { allowed: true };

  const targetMember = await guild.members.fetch(targetMemberId).catch(() => null);
  if (!targetMember) return { allowed: false, reason: 'Member tidak ditemukan.' };

  if (targetMember.id === guild.ownerId) {
    return { allowed: false, reason: 'Tidak bisa memoderasi Owner Server.' };
  }

  let actorMember = guild.members.cache.get(actorUser.id);
  if (!actorMember) actorMember = await guild.members.fetch(actorUser.id).catch(() => null);
  if (!actorMember) return { allowed: false, reason: 'Anda bukan anggota server ini.' };

  if (options.requireManageRoles && !actorMember.permissions.has('Administrator') && !actorMember.permissions.has('ManageRoles')) {
    return { allowed: false, reason: 'Anda memerlukan izin Manage Roles untuk mengelola role.' };
  }

  // Guild owner outranks everyone else automatically.
  if (actorMember.id === guild.ownerId) return { allowed: true, actorMember, targetMember };

  const actorTop = actorMember.roles.highest.position;
  const targetTop = targetMember.roles.highest.position;

  if (targetTop >= actorTop) {
    return {
      allowed: false,
      reason: 'Role tertinggi target sejajar atau lebih tinggi dari role Anda. Tidak bisa memoderasi member ini.'
    };
  }

  return { allowed: true, actorMember, targetMember };
}

module.exports = {
  ensureAuthenticated,
  ensureGuildAccess,
  ensureGuildMember,
  resolveGuildAccess,
  canModerateMember,
  isOwner
};
