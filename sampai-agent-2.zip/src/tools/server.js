'use strict';
const fs = require('fs');
const path = require('path');
const https = require('https');
const { spawn, spawnSync } = require('child_process');
const { resolveSafePath } = require('../security/sandbox');
const { isDownloadUrlAllowed } = require('../security/network');
const manager = require('../memory/manager');

const STOP_TIMEOUT_MS = parseInt(process.env.SERVER_STOP_TIMEOUT_MS || '8000', 10);

function stateFile(memoryDir) { return path.join(memoryDir, 'server.json'); }

const DEFAULT_STATE = {
  installed: false,
  install_dir: null,
  binary: null,
  cwd: null,
  args: [],
  pid: null,
  status: 'stopped', // stopped | running
  port: null,
  started_at: null,
  stopped_at: null,
  last_action: null,
};

function getState(memoryDir) {
  return manager.readJSON(stateFile(memoryDir), DEFAULT_STATE);
}

function saveState(memoryDir, partial) {
  return manager.update(stateFile(memoryDir), DEFAULT_STATE, (current) => ({
    ...current,
    ...partial,
    last_action: new Date().toISOString(),
  }));
}

function isPidAlive(pid) {
  if (!pid) return false;
  try {
    process.kill(pid, 0); // signal 0 = cuma cek proses ada, tidak benar2 mengirim sinyal
    return true;
  } catch (err) {
    return false;
  }
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// Download lewat https bawaan Node (bukan curl/wget di shell) supaya bisa divalidasi
// ketat lewat isDownloadUrlAllowed sebelum ada satu byte pun yang diambil.
function downloadToFile(url, destPath, timeoutMs = 120000, redirectsLeft = 5) {
  return new Promise((resolve, reject) => {
    const check = isDownloadUrlAllowed(url);
    if (!check.ok) return reject(new Error(check.reason));

    const file = fs.createWriteStream(destPath);
    const req = https.get(url, { headers: { 'User-Agent': 'sampai-agent' } }, (res) => {
      if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location) {
        file.close();
        try { fs.unlinkSync(destPath); } catch (_) {}
        if (redirectsLeft <= 0) return reject(new Error('Terlalu banyak redirect saat download.'));
        return downloadToFile(res.headers.location, destPath, timeoutMs, redirectsLeft - 1).then(resolve).catch(reject);
      }
      if (res.statusCode !== 200) {
        file.close();
        try { fs.unlinkSync(destPath); } catch (_) {}
        return reject(new Error(`Download gagal, HTTP status ${res.statusCode}.`));
      }
      res.pipe(file);
      file.on('finish', () => file.close(() => resolve()));
    });
    req.on('error', (err) => {
      try { fs.unlinkSync(destPath); } catch (_) {}
      reject(err);
    });
    req.setTimeout(timeoutMs, () => req.destroy(new Error('Download timeout.')));
  });
}

// Ekstraksi pakai spawnSync dengan argv array (BUKAN string command lewat shell),
// jadi nama file arsip yang aneh-aneh (kutip, titik koma, dst) tidak bisa dipakai
// untuk command injection - argv array tidak pernah diparse oleh shell.
function extractArchive(archiveFullPath, destDir) {
  fs.mkdirSync(destDir, { recursive: true });
  const lower = archiveFullPath.toLowerCase();
  let result;
  if (lower.endsWith('.zip')) {
    result = spawnSync('unzip', ['-o', archiveFullPath, '-d', destDir], { encoding: 'utf8' });
  } else if (lower.endsWith('.tar.gz') || lower.endsWith('.tgz')) {
    result = spawnSync('tar', ['-xzf', archiveFullPath, '-C', destDir], { encoding: 'utf8' });
  } else if (lower.endsWith('.tar')) {
    result = spawnSync('tar', ['-xf', archiveFullPath, '-C', destDir], { encoding: 'utf8' });
  } else {
    throw new Error('Format arsip tidak dikenal/didukung. Gunakan .zip, .tar.gz, .tgz, atau .tar.');
  }
  if (result.error) throw result.error;
  if (result.status !== 0) {
    throw new Error(`Proses ekstraksi keluar dengan kode ${result.status}: ${(result.stderr || '').slice(0, 500)}`);
  }
  return result;
}

async function installServer(workspace, { source_archive, download_url, install_dir, binary }) {
  if (!install_dir) {
    return { success: false, error: 'install_dir wajib diisi (folder tujuan instalasi, relatif workspace).' };
  }
  const destDir = resolveSafePath(workspace, install_dir);
  fs.mkdirSync(destDir, { recursive: true });

  let archiveFull;
  let tempDownload = false;

  if (source_archive) {
    archiveFull = resolveSafePath(workspace, source_archive);
    if (!fs.existsSync(archiveFull)) {
      return { success: false, error: `Arsip tidak ditemukan di workspace: ${source_archive}` };
    }
  } else if (download_url) {
    const check = isDownloadUrlAllowed(download_url);
    if (!check.ok) return { success: false, error: check.reason };
    let fileName = path.basename(new URL(download_url).pathname) || 'server-package.tmp';
    fileName = fileName.replace(/[^a-zA-Z0-9._-]/g, '_') || 'server-package.tmp';
    archiveFull = path.join(destDir, `._download_${fileName}`);
    tempDownload = true;
    try {
      await downloadToFile(download_url, archiveFull);
    } catch (err) {
      return { success: false, error: `Download gagal: ${err.message}` };
    }
  } else {
    return {
      success: false,
      error: 'Isi salah satu: source_archive (arsip yang sudah diupload user ke workspace) atau download_url (host harus ada di allowlist).',
    };
  }

  try {
    extractArchive(archiveFull, destDir);
  } catch (err) {
    return { success: false, error: `Ekstraksi gagal: ${err.message}` };
  } finally {
    if (tempDownload) { try { fs.unlinkSync(archiveFull); } catch (_) {} }
  }

  let binaryRelPath = null;
  if (binary) {
    const binFull = resolveSafePath(workspace, path.join(install_dir, binary));
    if (fs.existsSync(binFull)) {
      try { fs.chmodSync(binFull, 0o755); } catch (_) {}
      binaryRelPath = path.join(install_dir, binary).replace(/\\/g, '/');
    }
  }

  const entries = fs.readdirSync(destDir);
  return {
    success: true,
    install_dir,
    extracted_entries: entries.slice(0, 100),
    binary: binaryRelPath,
    note: binaryRelPath
      ? undefined
      : 'Binary belum diverifikasi - cek isi folder (list_files) lalu tentukan nama binary server yang benar untuk start_server.',
  };
}

// Baca "port" (dan "bind" kalau ada) langsung dari server.cfg di cwd tempat server dijalankan,
// supaya info port/IP yang dilaporkan itu port SUNGGUHAN yang dipakai server - bukan cuma
// parameter yang (mungkin lupa) dikasih ke start_server.
function readServerCfgNetwork(cwdFull) {
  const cfgPath = path.join(cwdFull, 'server.cfg');
  if (!fs.existsSync(cfgPath)) return { port: null, bind: null, cfg_found: false };
  try {
    const content = fs.readFileSync(cfgPath, 'utf8');
    const portMatch = content.match(/^\s*port\s+(\d+)/mi);
    const bindMatch = content.match(/^\s*bind\s+(\S+)/mi);
    return {
      port: portMatch ? parseInt(portMatch[1], 10) : null,
      bind: bindMatch ? bindMatch[1] : null,
      cfg_found: true,
    };
  } catch (err) {
    return { port: null, bind: null, cfg_found: true, read_error: err.message };
  }
}

function startServer(workspace, memoryDir, { binary, cwd, args, port }) {
  const binFull = resolveSafePath(workspace, binary);
  if (!fs.existsSync(binFull)) {
    return { success: false, error: `Binary server tidak ditemukan: ${binary}` };
  }
  if (fs.statSync(binFull).isDirectory()) {
    return { success: false, error: `${binary} adalah folder, bukan executable.` };
  }

  const state = getState(memoryDir);
  if (state.pid && isPidAlive(state.pid)) {
    return { success: false, error: `Server sepertinya sudah jalan (PID ${state.pid}). Pakai stop_server dulu sebelum start lagi, atau restart_server.` };
  }

  try { fs.chmodSync(binFull, 0o755); } catch (_) {}

  const runCwd = cwd ? resolveSafePath(workspace, cwd) : path.dirname(binFull);
  const logsDir = path.join(memoryDir, '..', 'logs');
  fs.mkdirSync(logsDir, { recursive: true });
  const outFd = fs.openSync(path.join(logsDir, 'server-stdout.log'), 'a');
  const errFd = fs.openSync(path.join(logsDir, 'server-stderr.log'), 'a');

  // spawn dengan argv array (bukan shell string) -> aman dari injection walau
  // isi args berasal dari model, karena tidak pernah diparse oleh shell.
  const child = spawn(binFull, Array.isArray(args) ? args : [], {
    cwd: runCwd,
    detached: true,
    stdio: ['ignore', outFd, errFd],
  });
  child.unref();

  // Port yang dilaporkan = port yang benar-benar dibaca dari server.cfg (kalau ada),
  // fallback ke parameter `port` kalau user/model eksplisit isi, atau null kalau tidak diketahui.
  const cfgNet = readServerCfgNetwork(runCwd);
  const effectivePort = cfgNet.port ?? (port || null);

  return {
    success: true,
    pid: child.pid,
    binary,
    cwd: path.relative(workspace, runCwd).replace(/\\/g, '/') || '.',
    port: effectivePort,
    port_source: cfgNet.port ? 'server.cfg' : (port ? 'parameter' : 'tidak diketahui'),
    bind: cfgNet.bind || null,
    note: cfgNet.cfg_found
      ? undefined
      : `server.cfg tidak ditemukan di ${path.relative(workspace, runCwd) || '.'} - port/bind tidak bisa diverifikasi otomatis.`,
  };
}

async function stopServer(pid, timeoutMs = STOP_TIMEOUT_MS) {
  if (!pid) {
    return { success: false, error: 'Tidak ada PID server yang tercatat (server mungkin belum pernah dijalankan lewat agent ini).' };
  }
  if (!isPidAlive(pid)) {
    return { success: true, already_stopped: true };
  }

  try {
    process.kill(pid, 'SIGTERM');
  } catch (err) {
    return { success: false, error: `Gagal mengirim SIGTERM ke PID ${pid}: ${err.message}` };
  }

  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (!isPidAlive(pid)) return { success: true, forced: false };
    await sleep(300);
  }

  try { process.kill(pid, 'SIGKILL'); } catch (_) {}
  await sleep(200);
  return { success: !isPidAlive(pid), forced: true };
}

function serverStatus(memoryDir, workspace) {
  const state = getState(memoryDir);
  const alive = isPidAlive(state.pid);
  let configured = { port: null, bind: null, cfg_found: false };
  if (workspace && state.cwd) {
    try {
      const cwdFull = resolveSafePath(workspace, state.cwd);
      configured = readServerCfgNetwork(cwdFull);
    } catch (_) { /* cwd lama mungkin sudah tidak valid, abaikan */ }
  }
  return {
    ...state,
    process_alive: alive,
    configured_port: configured.port,
    configured_bind: configured.bind,
  };
}

module.exports = {
  getState, saveState, isPidAlive, readServerCfgNetwork,
  installServer, startServer, stopServer, serverStatus,
};
