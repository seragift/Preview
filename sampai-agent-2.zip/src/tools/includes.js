'use strict';
const fs = require('fs');
const path = require('path');
const https = require('https');
const { resolveSafePath } = require('../security/sandbox');
const { isDownloadUrlAllowed } = require('../security/network');

// Registry KECIL tapi TERVERIFIKASI - tiap URL di sini sudah dicek manual beneran
// mengarah ke file .inc yang benar (bukan hasil tebakan pola "raw.githubusercontent.com/
// user/repo/master/nama.inc" yang sering salah kalau path/branch-nya beda). Nambah entri
// baru HARUS diverifikasi dulu, jangan asal tebak - link download rusak lebih parah
// daripada bilang jujur "belum didukung, upload manual".
const INCLUDE_REGISTRY = {
  sscanf2: {
    url: 'https://raw.githubusercontent.com/Y-Less/sscanf/master/sscanf2.inc',
    filename: 'sscanf2.inc',
    note: 'Include untuk sscanf (parsing command/data). Plugin binary sscanf (.so) TETAP harus ada terpisah di folder plugins/ - ini cuma file .inc-nya, bukan plugin-nya.',
  },
  zcmd: {
    url: 'https://raw.githubusercontent.com/Southclaws/zcmd/master/zcmd.inc',
    filename: 'zcmd.inc',
    note: 'Command processor single-file, TIDAK butuh plugin binary terpisah - langsung include dan pakai.',
  },
};

function listKnownIncludes() {
  return Object.keys(INCLUDE_REGISTRY);
}

function downloadToFile(url, destPath, timeoutMs = 30000, redirectsLeft = 5) {
  return new Promise((resolve, reject) => {
    const check = isDownloadUrlAllowed(url);
    if (!check.ok) return reject(new Error(check.reason));

    const file = fs.createWriteStream(destPath);
    const req = https.get(url, { headers: { 'User-Agent': 'sampai-agent' } }, (res) => {
      if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location) {
        file.close();
        try { fs.unlinkSync(destPath); } catch (_) {}
        if (redirectsLeft <= 0) return reject(new Error('Terlalu banyak redirect.'));
        return downloadToFile(res.headers.location, destPath, timeoutMs, redirectsLeft - 1).then(resolve).catch(reject);
      }
      if (res.statusCode !== 200) {
        file.close();
        try { fs.unlinkSync(destPath); } catch (_) {}
        return reject(new Error(`Download gagal, HTTP status ${res.statusCode}.`));
      }
      res.pipe(file);
      file.on('finish', () => file.close(() => resolve()));
    });
    req.on('error', (err) => {
      try { fs.unlinkSync(destPath); } catch (_) {}
      reject(err);
    });
    req.setTimeout(timeoutMs, () => req.destroy(new Error('Download timeout.')));
  });
}

async function fetchInclude(workspace, name, destDir) {
  const key = String(name || '').trim().toLowerCase().replace(/\.inc$/, '');
  const entry = INCLUDE_REGISTRY[key];
  if (!entry) {
    return {
      success: false,
      error: `Include "${name}" tidak ada di registry known-includes agent (baru ada ${listKnownIncludes().length}: ${listKnownIncludes().join(', ')}). Untuk include lain, minta user upload manual ke workspace.`,
      known_includes: listKnownIncludes(),
    };
  }

  const dir = destDir || 'pawno/include';
  const destDirFull = resolveSafePath(workspace, dir);
  fs.mkdirSync(destDirFull, { recursive: true });
  const destFile = path.join(destDirFull, entry.filename);

  try {
    await downloadToFile(entry.url, destFile);
  } catch (err) {
    return { success: false, error: `Gagal download ${key}: ${err.message}` };
  }

  return {
    success: true,
    name: key,
    path: path.join(dir, entry.filename).replace(/\\/g, '/'),
    source: entry.url,
    note: entry.note,
  };
}

module.exports = { fetchInclude, listKnownIncludes, INCLUDE_REGISTRY };
