'use strict';
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');
const { resolveSafePath, isCommandAllowed } = require('../security/sandbox');
const { listKnownIncludes } = require('./includes');

const TIMEOUT_MS = parseInt(process.env.COMMAND_TIMEOUT_MS || '30000', 10);
const MAX_OUTPUT_BYTES = (parseInt(process.env.MAX_COMMAND_OUTPUT_KB || '64', 10)) * 1024;
const PAWNCC_BIN = process.env.PAWNCC_PATH || 'pawncc';

// Format baris diagnostic pawncc, contoh:
//   gamemodes/main.pwn(245) : error 017: undefined symbol "PlayerData"
//   gamemodes/main.pwn(12) : warning 217: loose indentation
//   gamemodes/main.pwn(1) : fatal error 100: cannot read from file: "a_samp.inc"
const DIAG_REGEX = /^(.*?)\((\d+)(?:\s*--?\s*\d+)?\)\s*:\s*(fatal error|error|warning)\s+(\d+)\s*:\s*(.*)$/i;

function parseDiagnostics(output) {
  const lines = (output || '').split(/\r?\n/);
  const diagnostics = [];
  for (const line of lines) {
    const m = line.match(DIAG_REGEX);
    if (m) {
      diagnostics.push({
        file: m[1].trim(),
        line: parseInt(m[2], 10),
        severity: m[3].toLowerCase().includes('fatal') ? 'fatal' : m[3].toLowerCase(),
        code: m[4],
        message: m[5].trim(),
      });
    }
  }
  return diagnostics;
}

// Deteksi "cannot read from file: sscanf2.inc" dst dari diagnostics, dan tandai
// mana yang ada di registry auto-fetch (fetch_include) supaya agent nggak perlu
// nebak sendiri include mana yang bisa langsung di-download otomatis.
const MISSING_INCLUDE_RE = /cannot read from file:\s*"?([\w.\-]+\.inc)"?/i;

function detectMissingIncludes(diagnostics) {
  const known = listKnownIncludes();
  const names = new Set();
  for (const d of diagnostics) {
    const m = (d.message || '').match(MISSING_INCLUDE_RE);
    if (m) names.add(m[1].replace(/\.inc$/i, '').toLowerCase());
  }
  return Array.from(names).map((name) => ({ name, fetchable: known.includes(name) }));
}

function compilePawn(workspace, relPath, opts = {}) {
  if (!relPath || !relPath.toLowerCase().endsWith('.pwn')) {
    return { success: false, error: `File harus berekstensi .pwn: ${relPath}` };
  }
  const full = resolveSafePath(workspace, relPath);
  if (!fs.existsSync(full)) {
    return { success: false, error: `File tidak ditemukan: ${relPath}` };
  }

  const dir = path.dirname(full);
  const fileName = path.basename(full);
  const amxName = fileName.replace(/\.pwn$/i, '.amx');

  let cmd = `${PAWNCC_BIN} "${fileName}" -o"${amxName}"`;

  if (Array.isArray(opts.include_dirs)) {
    for (const inc of opts.include_dirs) {
      const safeInc = resolveSafePath(workspace, inc); // validasi tetap di dalam workspace
      cmd += ` -i"${path.relative(dir, safeInc)}"`;
    }
  }
  if (opts.args) cmd += ` ${opts.args}`;

  // Command hasil rakitan tetap divalidasi lewat security policy yang sama dengan run_command,
  // supaya opts.args (yang datang dari model) tidak bisa dipakai untuk command injection.
  const allowCheck = isCommandAllowed(cmd);
  if (!allowCheck.ok) {
    return { success: false, error: `Command compile ditolak security policy: ${allowCheck.reason}` };
  }

  try {
    const output = execSync(cmd, {
      cwd: dir,
      timeout: TIMEOUT_MS,
      maxBuffer: MAX_OUTPUT_BYTES,
      encoding: 'utf8',
      shell: '/bin/bash',
    });
    const diagnostics = parseDiagnostics(output);
    const amxPath = path.join(dir, amxName);
    const amxGenerated = fs.existsSync(amxPath);
    const hasBlockingDiag = diagnostics.some((d) => d.severity !== 'warning');
    const missingIncludes = detectMissingIncludes(diagnostics);
    return {
      success: amxGenerated && !hasBlockingDiag,
      compiled: amxGenerated,
      amx_path: amxGenerated ? path.relative(workspace, amxPath).replace(/\\/g, '/') : null,
      diagnostics,
      warning_count: diagnostics.filter((d) => d.severity === 'warning').length,
      error_count: diagnostics.filter((d) => d.severity !== 'warning').length,
      missing_includes: missingIncludes.length ? missingIncludes : undefined,
      raw_output: output.slice(0, MAX_OUTPUT_BYTES),
    };
  } catch (err) {
    const out = (err.stdout || '') + (err.stderr || '');
    const diagnostics = parseDiagnostics(out);
    const notFound = err.status === 127 || /command not found|no such file or directory/i.test(out);
    if (notFound && diagnostics.length === 0) {
      return {
        success: false,
        error: `Compiler "${PAWNCC_BIN}" tidak ditemukan/tidak bisa dijalankan. Pastikan pawncc terinstall dan PAWNCC_PATH di .env sudah benar (bisa path absolut, atau nama binary kalau sudah ada di $PATH).`,
      };
    }
    const missingIncludes = detectMissingIncludes(diagnostics);
    return {
      success: false,
      error: err.killed ? 'Compile timeout.' : 'Compile gagal (ada error dari compiler).',
      diagnostics,
      warning_count: diagnostics.filter((d) => d.severity === 'warning').length,
      error_count: diagnostics.filter((d) => d.severity !== 'warning').length,
      missing_includes: missingIncludes.length ? missingIncludes : undefined,
      raw_output: out.slice(0, MAX_OUTPUT_BYTES),
    };
  }
}

module.exports = { compilePawn, parseDiagnostics };
