'use strict';
const fs = require('fs');
const path = require('path');
const { resolveSafePath } = require('../security/sandbox');

// Plugin/component SA-MP/open.mp kadang dideklarasikan TANPA ekstensi .so
// (config.json modern) atau DENGAN .so (server.cfg legacy) - cek dua-duanya
// biar nggak false-positive "hilang" gara-gara beda konvensi penamaan.
function fileExistsWithOptionalSoExt(dirFull, name) {
  const candidates = new Set([name]);
  if (name.endsWith('.so')) candidates.add(name.slice(0, -3));
  else candidates.add(`${name}.so`);
  for (const c of candidates) {
    if (fs.existsSync(path.join(dirFull, c))) return { found: true, matched: c };
  }
  return { found: false, matched: null };
}

// open.mp modern: config.json -> pawn.legacy_plugins (folder plugins/) +
// components (folder components/, termasuk subfolder seperti "additions/xxx").
function checkPluginsConfigJson(cwdFull) {
  const cfgPath = path.join(cwdFull, 'config.json');
  if (!fs.existsSync(cfgPath)) return null;

  let data;
  try { data = JSON.parse(fs.readFileSync(cfgPath, 'utf8')); }
  catch (err) { return { format: 'config.json', parse_error: err.message }; }

  const legacyPlugins = (data.pawn && Array.isArray(data.pawn.legacy_plugins)) ? data.pawn.legacy_plugins : [];
  const components = Array.isArray(data.components) ? data.components : [];

  const pluginsDir = path.join(cwdFull, 'plugins');
  const componentsDir = path.join(cwdFull, 'components');

  const checkList = (names, dir) => {
    const found = [];
    const missing = [];
    for (const name of names) {
      const r = fileExistsWithOptionalSoExt(dir, name);
      (r.found ? found : missing).push(name);
    }
    return { declared: names, found, missing };
  };

  return {
    format: 'config.json',
    legacy_plugins: checkList(legacyPlugins, pluginsDir),
    components: checkList(components, componentsDir),
  };
}

// SA-MP legacy / open.mp mode legacy: server.cfg -> baris "plugins a.so b.so ...".
function checkPluginsServerCfg(cwdFull) {
  const cfgPath = path.join(cwdFull, 'server.cfg');
  if (!fs.existsSync(cfgPath)) return null;

  const content = fs.readFileSync(cfgPath, 'utf8');
  const match = content.match(/^\s*plugins\s+(.+)$/mi);
  const declared = match ? match[1].trim().split(/\s+/).filter(Boolean) : [];

  const pluginsDir = path.join(cwdFull, 'plugins');
  const found = [];
  const missing = [];
  for (const name of declared) {
    const r = fileExistsWithOptionalSoExt(pluginsDir, name);
    (r.found ? found : missing).push(name);
  }

  return { format: 'server.cfg', legacy_plugins: { declared, found, missing } };
}

function checkMissingPlugins(workspace, cwd) {
  let cwdFull;
  try {
    cwdFull = resolveSafePath(workspace, cwd || '.');
  } catch (err) {
    return { success: false, error: err.message };
  }
  if (!fs.existsSync(cwdFull)) {
    return { success: false, error: `Folder tidak ditemukan: ${cwd || '.'}` };
  }

  const jsonResult = checkPluginsConfigJson(cwdFull);
  if (jsonResult) {
    if (jsonResult.parse_error) {
      return { success: false, error: `config.json tidak valid (gagal parse): ${jsonResult.parse_error}` };
    }
    const totalMissing = jsonResult.legacy_plugins.missing.length + jsonResult.components.missing.length;
    return {
      success: true,
      format: 'config.json',
      all_present: totalMissing === 0,
      legacy_plugins: jsonResult.legacy_plugins,
      components: jsonResult.components,
    };
  }

  const cfgResult = checkPluginsServerCfg(cwdFull);
  if (cfgResult) {
    return {
      success: true,
      format: 'server.cfg',
      all_present: cfgResult.legacy_plugins.missing.length === 0,
      legacy_plugins: cfgResult.legacy_plugins,
    };
  }

  return { success: false, error: `Tidak ada config.json atau server.cfg di ${cwd || '.'} - tidak bisa cek plugin.` };
}

module.exports = { checkMissingPlugins, fileExistsWithOptionalSoExt };
