require('dotenv').config();
const deployCommands = require('./src/deployCommands');

(async () => {
  await deployCommands(); // reset lalu daftarkan ulang slash command tiap kali start
  require('./src/bot');
})();
