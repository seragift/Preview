const { PREFIX } = require('../config');
const { parseIpPort } = require('../utils/ipUtils');
const serverRepo = require('../database/serverRepo');
const { errorEmbed, successEmbed } = require('../utils/embeds');

module.exports = async function handleSetIp(message, args) {
  const input = args.join(' ').trim();

  if (!input) {
    return message.reply({
      embeds: [
        errorEmbed(
          `Gunakan format: \`${PREFIX}setip <ip:port>\`\nContoh: \`${PREFIX}setip 51.222.13.10:7777\``
        ),
      ],
    });
  }

  const parsed = parseIpPort(input);
  if (!parsed) {
    return message.reply({ embeds: [errorEmbed('Format IP:Port tidak valid. Contoh: `51.222.13.10:7777`')] });
  }

  const existing = serverRepo.getServer(message.guildId);
  if (existing) {
    return message.reply({
      embeds: [
        errorEmbed(
          `Server ini sudah punya IP terpasang: \`${existing.ip}:${existing.port}\`\n` +
            `1 server Discord hanya bisa punya 1 IP. Gunakan \`${PREFIX}ipedit <ip:port baru>\` untuk menggantinya.`
        ),
      ],
    });
  }

  serverRepo.createServer(message.guildId, parsed.ip, parsed.port);

  return message.reply({
    embeds: [successEmbed(`IP server berhasil disimpan: \`${parsed.ip}:${parsed.port}\``)],
  });
};
