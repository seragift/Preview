const { PREFIX, WEAPON_ID_MIN, WEAPON_ID_MAX } = require('../config');
const { findWeapon } = require('../services/weaponService');
const { errorEmbed, resultEmbed } = require('../utils/embeds');

module.exports = async function handleWeapon(message, args) {
  const query = args.join(' ').trim();

  if (!query) {
    return message.reply({
      embeds: [
        errorEmbed(
          `Gunakan format: \`${PREFIX}weapon <id/nama>\`\nContoh: \`${PREFIX}weapon 30\` atau \`${PREFIX}weapon ak47\``
        ),
      ],
    });
  }

  const weapon = findWeapon(query);
  if (!weapon) {
    const hint = /^\d+$/.test(query)
      ? `ID weapon harus antara ${WEAPON_ID_MIN}-${WEAPON_ID_MAX}.`
      : `Weapon dengan nama \`${query}\` tidak ditemukan.`;
    return message.reply({ embeds: [errorEmbed(hint)] });
  }

  const embed = resultEmbed({
    color: 0xfaa61a,
    title: `${weapon.name} (ID: ${weapon.id})`,
    imageUrl: weapon.image,
  });

  return message.reply({ embeds: [embed] });
};
