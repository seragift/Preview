const { PREFIX, MONITOR_INTERVAL_MS } = require('../config');
const serverRepo = require('../database/serverRepo');
const monitorRepo = require('../database/monitorRepo');
const { startMonitor } = require('../monitor/monitorManager');
const { errorEmbed, successEmbed } = require('../utils/embeds');

module.exports = async function handleMonitor(message, args) {
  const server = serverRepo.getServer(message.guildId);
  if (!server) {
    return message.reply({
      embeds: [errorEmbed(`IP server belum diset. Gunakan \`${PREFIX}setip <ip:port>\` dulu sebelum \`${PREFIX}monitor\`.`)],
    });
  }

  const channel = message.mentions.channels.first();
  if (!channel) {
    return message.reply({
      embeds: [errorEmbed(`Gunakan format: \`${PREFIX}monitor #channel\`\nContoh: \`${PREFIX}monitor #status-server\``)],
    });
  }

  const permissions = channel.permissionsFor(message.guild.members.me);
  if (!permissions?.has(['ViewChannel', 'SendMessages', 'EmbedLinks', 'ReadMessageHistory'])) {
    return message.reply({
      embeds: [
        errorEmbed(
          `Bot butuh izin View Channel, Send Messages, Embed Links, dan Read Message History di ${channel}. Cek permission bot di channel tersebut.`
        ),
      ],
    });
  }

  // Set dulu (message_id null -> dibuat baru oleh monitorManager saat refresh pertama)
  monitorRepo.setMonitor(message.guildId, channel.id, null);
  startMonitor(message.client, message.guildId);

  return message.reply({
    embeds: [
      successEmbed(
        `Monitoring diaktifkan di ${channel}, auto-refresh tiap ${MONITOR_INTERVAL_MS / 1000} detik.`
      ),
    ],
  });
};
