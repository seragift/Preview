const { PREFIX, VEHICLE_ID_MIN, VEHICLE_ID_MAX } = require('../config');
const { findVehicle } = require('../services/vehicleService');
const { errorEmbed, resultEmbed } = require('../utils/embeds');

module.exports = async function handleCar(message, args) {
  const query = args.join(' ').trim();

  if (!query) {
    return message.reply({
      embeds: [
        errorEmbed(
          `Gunakan format: \`${PREFIX}car <id>\`\nContoh: \`${PREFIX}car 500\` atau \`${PREFIX}car mesa\``
        ),
      ],
    });
  }

  const vehicle = findVehicle(query);
  if (!vehicle) {
    const hint = /^\d+$/.test(query)
      ? `ID kendaraan harus antara ${VEHICLE_ID_MIN}-${VEHICLE_ID_MAX}.`
      : `Kendaraan dengan nama \`${query}\` tidak ditemukan.`;
    return message.reply({ embeds: [errorEmbed(hint)] });
  }

  const embed = resultEmbed({
    color: 0x57f287,
    title: `${vehicle.name} (ID: ${vehicle.id})`,
    imageUrl: vehicle.image,
  });

  return message.reply({ embeds: [embed] });
};
