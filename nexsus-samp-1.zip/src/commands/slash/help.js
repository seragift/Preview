const {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require('discord.js');
const { PREFIX, BOT_NAME, DONATE_URL, SUPPORT_SERVER_URL } = require('../../config');
const { footerText } = require('../../utils/embeds');

const data = new SlashCommandBuilder()
  .setName('help')
  .setDescription(`Penjelasan dan cara pakai ${BOT_NAME}`);

async function execute(interaction) {
  const embed = new EmbedBuilder()
    .setColor(0x5865f2)
    .setTitle(`👋 ${BOT_NAME}`)
    .setDescription(
      `${BOT_NAME} adalah bot untuk komunitas SA-MP: cari skin, kendaraan, dan weapon lengkap dengan gambarnya, ` +
        `sampai monitoring status server SA-MP — semua langsung dari Discord.\n\n` +
        `Semua command di bawah pakai prefix \`${PREFIX}\` (bukan slash), contoh: \`${PREFIX}skin 1\`.`
    )
    .addFields(
      {
        name: '📖 Umum',
        value: `\`${PREFIX}help\` — lihat daftar command singkat`,
      },
      {
        name: '🎨 Skin, Vehicle & Weapon',
        value:
          `\`${PREFIX}skin <id/nama>\` (alias \`${PREFIX}s\`) — cari skin, ID 0-311\n` +
          `\`${PREFIX}car <id/nama>\` (alias \`${PREFIX}c\`) — cari kendaraan, ID 400-611\n` +
          `\`${PREFIX}weapon <id/nama>\` (alias \`${PREFIX}w\`) — cari weapon, ID 0-46`,
      },
      {
        name: '📡 Monitoring Server SA-MP',
        value:
          `\`${PREFIX}setip <ip:port>\` — set IP server (1 server Discord = 1 IP)\n` +
          `\`${PREFIX}ipedit <ip:port baru>\` — ganti IP yang sudah diset\n` +
          `\`${PREFIX}ipdell <ip:port aktif>\` — hapus IP (ketik ulang sebagai konfirmasi)\n` +
          `\`${PREFIX}monitor #channel\` — auto-refresh status server tiap 30 detik\n` +
          `\`${PREFIX}monitordell\` — hentikan & hapus monitoring`,
      },
      {
        name: '🌐 Auto-responder',
        value: `\`${PREFIX}resip on\` / \`${PREFIX}resip off\` — aktif/nonaktifkan balasan otomatis saat ada yang ketik kata "ip"`,
      }
    )
    .setFooter({ text: footerText() });

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setLabel('💰 Donasi').setStyle(ButtonStyle.Link).setURL(DONATE_URL),
    new ButtonBuilder().setLabel('💬 Join Server').setStyle(ButtonStyle.Link).setURL(SUPPORT_SERVER_URL)
  );

  await interaction.reply({ embeds: [embed], components: [row] });
}

module.exports = { data, execute };
