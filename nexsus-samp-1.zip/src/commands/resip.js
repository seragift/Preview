const { PREFIX } = require('../config');
const serverRepo = require('../database/serverRepo');
const settingsRepo = require('../database/settingsRepo');
const { errorEmbed, successEmbed } = require('../utils/embeds');

module.exports = async function handleResip(message, args) {
  const server = serverRepo.getServer(message.guildId);
  if (!server) {
    return message.reply({
      embeds: [errorEmbed(`IP server belum diset. Gunakan \`${PREFIX}setip <ip:port>\` dulu sebelum \`${PREFIX}resip\`.`)],
    });
  }

  const mode = (args[0] || '').toLowerCase();
  if (mode !== 'on' && mode !== 'off') {
    const current = settingsRepo.isResipEnabled(message.guildId) ? 'on' : 'off';
    return message.reply({
      embeds: [
        errorEmbed(
          `Gunakan format: \`${PREFIX}resip on\` atau \`${PREFIX}resip off\`\nStatus saat ini: **${current}**`
        ),
      ],
    });
  }

  settingsRepo.setResip(message.guildId, mode === 'on');

  return message.reply({
    embeds: [successEmbed(`Auto-responder IP sekarang **${mode.toUpperCase()}**.`)],
  });
};
