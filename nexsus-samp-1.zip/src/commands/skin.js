const { PREFIX, SKIN_ID_MIN, SKIN_ID_MAX } = require('../config');
const { getSkinImageUrl, findSkin } = require('../services/skinService');
const { errorEmbed, resultEmbed } = require('../utils/embeds');

module.exports = async function handleSkin(message, args) {
  const query = args.join(' ').trim();

  if (!query) {
    return message.reply({
      embeds: [
        errorEmbed(
          `Gunakan format: \`${PREFIX}skin <id>\`\nContoh: \`${PREFIX}skin 1\` atau \`${PREFIX}skin ballas1\``
        ),
      ],
    });
  }

  const skin = findSkin(query);
  if (!skin) {
    const hint = /^\d+$/.test(query)
      ? `ID skin harus antara ${SKIN_ID_MIN}-${SKIN_ID_MAX}.`
      : `Skin dengan nama \`${query}\` tidak ditemukan.`;
    return message.reply({ embeds: [errorEmbed(hint)] });
  }

  const embed = resultEmbed({
    color: 0x3ba7e0,
    title: `${skin.name} (ID: ${skin.id})`,
    imageUrl: getSkinImageUrl(skin.id),
  });

  return message.reply({ embeds: [embed] });
};
