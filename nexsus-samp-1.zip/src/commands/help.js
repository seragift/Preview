const { EmbedBuilder } = require('discord.js');
const { PREFIX, BOT_NAME } = require('../config');
const { footerText } = require('../utils/embeds');

module.exports = async function handleHelp(message) {
  const embed = new EmbedBuilder()
    .setColor(0x5865f2)
    .setTitle(`${BOT_NAME} — Daftar Command`)
    .addFields(
      { name: `${PREFIX}skin <id/nama>` + ` (alias: ${PREFIX}s)`, value: `Contoh: \`${PREFIX}skin 1\` atau \`${PREFIX}skin ballas\`` },
      { name: `${PREFIX}car <id/nama>` + ` (alias: ${PREFIX}c)`, value: `Contoh: \`${PREFIX}car 500\` atau \`${PREFIX}car mesa\`` },
      { name: `${PREFIX}weapon <id/nama>` + ` (alias: ${PREFIX}w)`, value: `Contoh: \`${PREFIX}weapon 30\` atau \`${PREFIX}weapon ak47\`` },
      { name: `${PREFIX}setip <ip:port>`, value: 'Set IP server SA-MP untuk server Discord ini (sekali saja).' },
      { name: `${PREFIX}ipedit <ip:port baru>`, value: 'Ganti IP server yang sudah diset.' },
      { name: `${PREFIX}ipdell <ip:port aktif>`, value: 'Hapus IP server (ketik ulang IP aktif sebagai konfirmasi).' },
      { name: `${PREFIX}monitor #channel`, value: 'Mulai auto-refresh status server tiap 30 detik di channel tsb.' },
      { name: `${PREFIX}monitordell`, value: 'Hentikan & hapus monitoring di server ini.' },
      { name: `${PREFIX}resip <on/off>`, value: 'Aktif/nonaktifkan auto-responder saat ada yang ketik IP server.' }
    )
    .setFooter({ text: footerText() });

  return message.reply({ embeds: [embed] });
};
