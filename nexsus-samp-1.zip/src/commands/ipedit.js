const { PREFIX } = require('../config');
const { parseIpPort } = require('../utils/ipUtils');
const serverRepo = require('../database/serverRepo');
const { errorEmbed, successEmbed } = require('../utils/embeds');

module.exports = async function handleIpEdit(message, args) {
  const input = args.join(' ').trim();

  const existing = serverRepo.getServer(message.guildId);
  if (!existing) {
    return message.reply({
      embeds: [errorEmbed(`Server ini belum punya IP. Gunakan \`${PREFIX}setip <ip:port>\` dulu.`)],
    });
  }

  if (!input) {
    return message.reply({
      embeds: [
        errorEmbed(
          `Gunakan format: \`${PREFIX}ipedit <ip:port baru>\`\nIP saat ini: \`${existing.ip}:${existing.port}\``
        ),
      ],
    });
  }

  const parsed = parseIpPort(input);
  if (!parsed) {
    return message.reply({ embeds: [errorEmbed('Format IP:Port tidak valid. Contoh: `51.222.13.10:7777`')] });
  }

  serverRepo.updateServer(message.guildId, parsed.ip, parsed.port);

  return message.reply({
    embeds: [
      successEmbed(
        `IP server berhasil diubah:\n\`${existing.ip}:${existing.port}\` → \`${parsed.ip}:${parsed.port}\``
      ),
    ],
  });
};
