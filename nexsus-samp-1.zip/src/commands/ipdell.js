const { PREFIX } = require('../config');
const { parseIpPort } = require('../utils/ipUtils');
const serverRepo = require('../database/serverRepo');
const monitorRepo = require('../database/monitorRepo');
const { stopMonitor } = require('../monitor/monitorManager');
const { errorEmbed, successEmbed } = require('../utils/embeds');

module.exports = async function handleIpDell(message, args) {
  const existing = serverRepo.getServer(message.guildId);
  if (!existing) {
    return message.reply({ embeds: [errorEmbed('Server ini belum punya IP yang tersimpan.')] });
  }

  const input = args.join(' ').trim();
  const current = `${existing.ip}:${existing.port}`;

  if (!input) {
    return message.reply({
      embeds: [
        errorEmbed(
          `Untuk konfirmasi, ketik ulang IP yang sedang aktif:\n\`${PREFIX}ipdell ${current}\``
        ),
      ],
    });
  }

  const parsed = parseIpPort(input);
  if (!parsed || `${parsed.ip}:${parsed.port}` !== current) {
    return message.reply({
      embeds: [
        errorEmbed(`IP yang kamu ketik tidak cocok dengan IP aktif saat ini: \`${current}\``),
      ],
    });
  }

  serverRepo.deleteServer(message.guildId);

  // IP dihapus otomatis matikan monitor & auto-responder yang menempel padanya
  if (monitorRepo.getMonitor(message.guildId)) {
    stopMonitor(message.guildId);
    monitorRepo.deleteMonitor(message.guildId);
  }

  return message.reply({ embeds: [successEmbed(`IP server \`${current}\` berhasil dihapus.`)] });
};
