const monitorRepo = require('../database/monitorRepo');
const { stopMonitor } = require('../monitor/monitorManager');
const { errorEmbed, successEmbed } = require('../utils/embeds');

module.exports = async function handleMonitorDell(message) {
  const monitor = monitorRepo.getMonitor(message.guildId);
  if (!monitor) {
    return message.reply({ embeds: [errorEmbed('Tidak ada monitoring yang aktif di server ini.')] });
  }

  stopMonitor(message.guildId);
  monitorRepo.deleteMonitor(message.guildId);

  return message.reply({ embeds: [successEmbed('Monitoring dihentikan dan datanya sudah dihapus.')] });
};
