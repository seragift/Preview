const { Client, GatewayIntentBits, ActivityType, EmbedBuilder } = require('discord.js');
const { PREFIX, BOT_NAME, TOKEN, LOG_CHANNEL_ID, COOLDOWN_MS } = require('./config');
const { errorEmbed, ipAddressEmbed, footerText } = require('./utils/embeds');
const { isIpKeyword } = require('./utils/ipUtils');
const { isAdmin } = require('./utils/permissions');
const { getRemainingCooldown, setCooldown } = require('./utils/cooldown');

require('./database/db'); // pastikan koneksi & tabel sudah siap sebelum dipakai repo manapun
const serverRepo = require('./database/serverRepo');
const settingsRepo = require('./database/settingsRepo');
const { restoreAllMonitors } = require('./monitor/monitorManager');

const handleSkin = require('./commands/skin');
const handleCar = require('./commands/car');
const handleWeapon = require('./commands/weapon');
const handleHelp = require('./commands/help');
const handleSetIp = require('./commands/setip');
const handleIpEdit = require('./commands/ipedit');
const handleIpDell = require('./commands/ipdell');
const handleMonitor = require('./commands/monitor');
const handleMonitorDell = require('./commands/monitordell');
const handleResip = require('./commands/resip');
const slashCommands = require('./commands/slash');

const slashCommandMap = new Map(slashCommands.map((cmd) => [cmd.data.name, cmd]));

// Daftar semua command prefix (!). cooldownKey diisi cuma untuk command yang
// perlu dibatasi jeda pemakaiannya (skin/car/weapon) — command lain (setip,
// monitor, dll) tidak perlu cooldown karena memang jarang dipanggil berulang.
const commandRoutes = {
  skin: { handler: handleSkin, cooldownKey: 'skin' },
  s: { handler: handleSkin, cooldownKey: 'skin' },
  car: { handler: handleCar, cooldownKey: 'car' },
  vehicle: { handler: handleCar, cooldownKey: 'car' },
  c: { handler: handleCar, cooldownKey: 'car' },
  weapon: { handler: handleWeapon, cooldownKey: 'weapon' },
  gun: { handler: handleWeapon, cooldownKey: 'weapon' },
  w: { handler: handleWeapon, cooldownKey: 'weapon' },
  help: { handler: handleHelp },
  menu: { handler: handleHelp },
  setip: { handler: handleSetIp },
  ipedit: { handler: handleIpEdit },
  ipdell: { handler: handleIpDell },
  monitor: { handler: handleMonitor },
  monitordell: { handler: handleMonitorDell },
  resip: { handler: handleResip },
};

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
});

client.once('clientReady', () => {
  console.log(`${BOT_NAME} online sebagai ${client.user.tag}`);
  client.user.setActivity(`${PREFIX}help | ${BOT_NAME}`, { type: ActivityType.Watching });
  restoreAllMonitors(client);
});

/**
 * Kirim log ke channel log (di server owner) tiap kali bot ditambahkan ke
 * server baru. LOG_CHANNEL_ID diatur di .env / src/config.js — bot harus
 * sudah jadi member di server yang punya channel tersebut.
 */
client.on('guildCreate', async (guild) => {
  console.log(`📥 Bot ditambahkan ke server baru: ${guild.name} (${guild.id})`);

  if (!LOG_CHANNEL_ID) return;

  try {
    const logChannel = await client.channels.fetch(LOG_CHANNEL_ID);
    const embed = new EmbedBuilder()
      .setColor(0x57f287)
      .setTitle('📥 Bot ditambahkan ke server baru')
      .addFields(
        { name: 'Nama Server', value: guild.name, inline: true },
        { name: 'Server ID', value: guild.id, inline: true },
        { name: 'Jumlah Member', value: `${guild.memberCount}`, inline: true }
      )
      .setFooter({ text: footerText() })
      .setTimestamp();

    await logChannel.send({ embeds: [embed] });
  } catch (err) {
    console.error('Gagal kirim log guildCreate ke channel log:', err.message);
  }
});

client.on('messageCreate', async (message) => {
  if (message.author.bot || !message.guild) return;

  if (!message.content.startsWith(PREFIX)) {
    await handleAutoResponder(message);
    return;
  }

  const args = message.content.slice(PREFIX.length).trim().split(/\s+/);
  const command = args.shift().toLowerCase();

  const route = commandRoutes[command];
  if (!route) return; // command tidak dikenal, diamkan seperti biasa

  // Semua command prefix (!) cuma buat Administrator. /help (slash command)
  // sengaja dikecualikan dari aturan ini karena memang untuk semua orang.
  if (!isAdmin(message)) {
    return message.reply({
      embeds: [errorEmbed(`Command \`${PREFIX}${command}\` cuma bisa dipakai oleh Administrator.`)],
    });
  }

  if (route.cooldownKey) {
    const remaining = getRemainingCooldown(route.cooldownKey, message.author.id);
    if (remaining > 0) {
      return message.reply({
        embeds: [errorEmbed(`Tunggu ${(remaining / 1000).toFixed(1)} detik lagi sebelum pakai \`${PREFIX}${route.cooldownKey}\` lagi.`)],
      });
    }
    setCooldown(route.cooldownKey, message.author.id, COOLDOWN_MS);
  }

  try {
    await route.handler(message, args);
  } catch (err) {
    console.error('Command error:', err);
    await message.reply({ embeds: [errorEmbed('Terjadi kesalahan saat memproses command.')] });
  }
});

client.on('interactionCreate', async (interaction) => {
  if (!interaction.isChatInputCommand()) return;

  const command = slashCommandMap.get(interaction.commandName);
  if (!command) return;

  try {
    await command.execute(interaction);
  } catch (err) {
    console.error('Slash command error:', err);
    const payload = { content: '❌ Terjadi kesalahan saat memproses command.', ephemeral: true };
    if (interaction.replied || interaction.deferred) {
      await interaction.followUp(payload);
    } else {
      await interaction.reply(payload);
    }
  }
});

/**
 * Auto-responder: kalau ada yang ketik kata "ip" (berdiri sendiri) di chat
 * dan !resip dalam kondisi ON, bot balas dengan embed berisi IP:Port server.
 * Ini bukan command prefix, jadi tidak kena aturan Administrator-only di atas.
 */
async function handleAutoResponder(message) {
  const server = serverRepo.getServer(message.guildId);
  if (!server) return;
  if (!settingsRepo.isResipEnabled(message.guildId)) return;
  if (!isIpKeyword(message.content)) return;

  await message.reply({ embeds: [ipAddressEmbed(server)] });
}

client.login(TOKEN);

module.exports = client;
