const { REST, Routes } = require('discord.js');
const { TOKEN, CLIENT_ID } = require('./config');
const slashCommands = require('./commands/slash');

const commandsPayload = slashCommands.map((cmd) => cmd.data.toJSON());

/**
 * Deploy slash command secara global (tanpa guild ID, berlaku di semua server
 * tempat bot di-invite). Selalu reset (hapus semua command lama) dulu sebelum
 * mendaftarkan ulang, supaya command yang sudah dihapus dari kode ikut hilang
 * dari Discord juga — bukan cuma numpuk/dobel.
 */
async function deployCommands() {
  if (!TOKEN || !CLIENT_ID) {
    console.warn('⚠️  DISCORD_TOKEN atau CLIENT_ID belum diisi di .env, lewati deploy slash command.');
    return;
  }

  const rest = new REST().setToken(TOKEN);

  try {
    console.log('🧹 Menghapus slash command lama...');
    await rest.put(Routes.applicationCommands(CLIENT_ID), { body: [] });

    console.log(`🚀 Mendaftarkan ${commandsPayload.length} slash command...`);
    await rest.put(Routes.applicationCommands(CLIENT_ID), { body: commandsPayload });

    console.log('✅ Slash command berhasil di-deploy.');
  } catch (err) {
    console.error('❌ Gagal deploy slash command:', err);
  }
}

module.exports = deployCommands;
