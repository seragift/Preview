const dgram = require('dgram');
const dns = require('dns').promises;
const { QUERY_TIMEOUT_MS } = require('../config');

/**
 * Implementasi SA-MP Query Protocol (UDP).
 * Opcode yang dipakai:
 *  'i' -> info dasar server (hostname, gamemode, jumlah pemain, dll)
 *  'r' -> rules server (mapname, weather, worldtime, version, weburl, dll)
 * Opcode 'c' (client list / daftar pemain) SENGAJA TIDAK dipakai sesuai permintaan.
 */

function buildPacket(ip, port, opcode) {
  const header = Buffer.from('SAMP');
  const ipBuf = Buffer.from(ip.split('.').map(Number));
  const portBuf = Buffer.alloc(2);
  portBuf.writeUInt16LE(port, 0);
  const opcodeBuf = Buffer.from(opcode);
  return Buffer.concat([header, ipBuf, portBuf, opcodeBuf]);
}

function sendQuery(ip, port, opcode) {
  return new Promise((resolve, reject) => {
    const packet = buildPacket(ip, port, opcode);
    const socket = dgram.createSocket('udp4');
    let settled = false;

    const finish = (fn, value) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      socket.close();
      fn(value);
    };

    const timer = setTimeout(() => {
      finish(reject, new Error('Timeout: server tidak merespons.'));
    }, QUERY_TIMEOUT_MS);

    socket.once('error', (err) => finish(reject, err));
    socket.once('message', (msg) => finish(resolve, msg));

    socket.send(packet, port, ip, (err) => {
      if (err) finish(reject, err);
    });
  });
}

// Header respons ("SAMP" + 4 byte ip + 2 byte port + 1 byte opcode) di-echo
// balik oleh server, jadi parsing data sebenarnya mulai dari offset 11.
const HEADER_LENGTH = 11;

function parseInfo(buf) {
  let offset = HEADER_LENGTH;

  const passworded = buf.readUInt8(offset); offset += 1;
  const players = buf.readUInt16LE(offset); offset += 2;
  const maxPlayers = buf.readUInt16LE(offset); offset += 2;

  const hostnameLen = buf.readUInt32LE(offset); offset += 4;
  const hostname = buf.toString('utf8', offset, offset + hostnameLen); offset += hostnameLen;

  const gamemodeLen = buf.readUInt32LE(offset); offset += 4;
  const gamemode = buf.toString('utf8', offset, offset + gamemodeLen); offset += gamemodeLen;

  const languageLen = buf.readUInt32LE(offset); offset += 4;
  const language = buf.toString('utf8', offset, offset + languageLen); offset += languageLen;

  return { passworded: !!passworded, players, maxPlayers, hostname, gamemode, language };
}

function parseRules(buf) {
  let offset = HEADER_LENGTH;
  const ruleCount = buf.readUInt16LE(offset); offset += 2;
  const rules = {};

  for (let i = 0; i < ruleCount; i += 1) {
    const nameLen = buf.readUInt8(offset); offset += 1;
    const name = buf.toString('utf8', offset, offset + nameLen); offset += nameLen;

    const valueLen = buf.readUInt8(offset); offset += 1;
    const value = buf.toString('utf8', offset, offset + valueLen); offset += valueLen;

    rules[name] = value;
  }

  return rules;
}

/**
 * Query info + rules server. Melempar error kalau server offline/timeout.
 */
async function querySampServer(host, port) {
  const ip = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(host)
    ? host
    : (await dns.lookup(host, { family: 4 })).address;

  const [infoBuf, rulesBuf] = await Promise.all([
    sendQuery(ip, port, 'i'),
    sendQuery(ip, port, 'r').catch(() => null),
  ]);

  const info = parseInfo(infoBuf);
  const rules = rulesBuf ? parseRules(rulesBuf) : {};

  return { ...info, rules };
}

module.exports = { querySampServer };
