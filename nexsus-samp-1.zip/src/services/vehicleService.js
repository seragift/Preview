const vehicles = require('../data/vehicles.json');
const { VEHICLE_ID_MIN, VEHICLE_ID_MAX } = require('../config');

/**
 * Data kendaraan (nama + URL gambar) disimpan statis di src/data/vehicles.json.
 *
 * Alasan: gambar di SA-MP Wiki disimpan di path MediaWiki yang di-hash
 * (contoh: /wroot/images2/6/6c/Vehicle_500.jpg) dan wiki lama ini tidak
 * mendukung pemanggilan api.php untuk resolve URL secara live. Karena
 * hash tersebut permanen (tidak berubah), URL-nya diambil sekali langsung
 * dari halaman wiki dan disimpan di sini — jadi hasilnya selalu sama
 * dengan yang ada di sampwiki.blast.hk tanpa perlu request tambahan.
 */
function getVehicleImageUrl(id) {
  return vehicles[String(id)]?.image ?? null;
}

/**
 * Mencari kendaraan berdasarkan ID numerik atau potongan nama.
 * Mengembalikan { id, name, image } atau null kalau tidak ketemu.
 */
function findVehicle(query) {
  if (/^\d+$/.test(query)) {
    const id = parseInt(query, 10);
    if (id < VEHICLE_ID_MIN || id > VEHICLE_ID_MAX || !(String(id) in vehicles)) {
      return null;
    }
    const v = vehicles[String(id)];
    return { id, name: v.name, image: v.image };
  }

  const q = query.toLowerCase();
  const match = Object.entries(vehicles).find(([, v]) => v.name.toLowerCase().includes(q));
  if (!match) return null;

  const [id, v] = match;
  return { id: parseInt(id, 10), name: v.name, image: v.image };
}

module.exports = { getVehicleImageUrl, findVehicle };
