const skinNames = require('../data/skins.json');
const { SKIN_ID_MIN, SKIN_ID_MAX, SKIN_IMAGE_BASE_URL } = require('../config');

/**
 * URL gambar skin mengikuti pola situs gta.com.ua secara langsung,
 * jadi tidak perlu request tambahan untuk mendapatkan gambarnya.
 */
function getSkinImageUrl(id) {
  return `${SKIN_IMAGE_BASE_URL}/skin_${id}.png`;
}

/**
 * Mencari skin berdasarkan ID numerik atau potongan nama model.
 * Mengembalikan { id, name } atau null kalau tidak ketemu.
 */
function findSkin(query) {
  if (/^\d+$/.test(query)) {
    const id = parseInt(query, 10);
    if (id < SKIN_ID_MIN || id > SKIN_ID_MAX || !(String(id) in skinNames)) {
      return null;
    }
    return { id, name: skinNames[String(id)] };
  }

  const q = query.toLowerCase();
  const match = Object.entries(skinNames).find(([, name]) => name.toLowerCase().includes(q));
  if (!match) return null;

  return { id: parseInt(match[0], 10), name: match[1] };
}

module.exports = { getSkinImageUrl, findSkin };
