const weapons = require('../data/weapons.json');
const { WEAPON_ID_MIN, WEAPON_ID_MAX } = require('../config');

function normalize(str) {
  return str.toLowerCase().replace(/[^a-z0-9]/g, '');
}

/**
 * Mencari weapon berdasarkan ID numerik atau potongan nama.
 * Mengembalikan { id, name, image } atau null kalau tidak ketemu.
 */
function findWeapon(query) {
  if (/^\d+$/.test(query)) {
    const id = parseInt(query, 10);
    if (id < WEAPON_ID_MIN || id > WEAPON_ID_MAX || !(String(id) in weapons)) {
      return null;
    }
    const w = weapons[String(id)];
    return { id, name: w.name, image: w.image };
  }

  const q = normalize(query);
  const match = Object.entries(weapons).find(([, w]) => normalize(w.name).includes(q));
  if (!match) return null;

  const [id, w] = match;
  return { id: parseInt(id, 10), name: w.name, image: w.image };
}

module.exports = { findWeapon };
