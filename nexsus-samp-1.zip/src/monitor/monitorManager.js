const { EmbedBuilder } = require('discord.js');
const { MONITOR_INTERVAL_MS, BRAND_NAME } = require('../config');
const { querySampServer } = require('../services/sampQueryService');
const monitorRepo = require('../database/monitorRepo');
const serverRepo = require('../database/serverRepo');

// guildId -> intervalId. Ini satu-satunya state yang disimpan di memori
// (wajib, karena setInterval butuh handle-nya buat di-clear) — semua data
// lain (IP, channel, message_id) selalu dibaca ulang dari database tiap
// siklus refresh, tidak ada cache pesan di memori.
const activeIntervals = new Map();

function footerText() {
  return `${BRAND_NAME} © ${new Date().getFullYear()} • Update tiap ${MONITOR_INTERVAL_MS / 1000} detik`;
}

function codeBlock(value) {
  return '```' + value + '```';
}

function buildOnlineEmbed(server, data) {
  const fields = [
    { name: 'IP:Port', value: codeBlock(`${server.ip}:${server.port}`), inline: true },
    { name: 'Gamemode', value: codeBlock(data.gamemode || '-'), inline: true },
    { name: 'Bahasa', value: codeBlock(data.language || '-'), inline: true },
    { name: 'Pemain', value: codeBlock(`${data.players}/${data.maxPlayers}`), inline: true },
    { name: 'Password', value: codeBlock(data.passworded ? 'Ya' : 'Tidak'), inline: true },
  ];

  if (data.rules.mapname) fields.push({ name: 'Map', value: codeBlock(data.rules.mapname), inline: true });
  if (data.rules.weather) fields.push({ name: 'Cuaca', value: codeBlock(data.rules.weather), inline: true });
  if (data.rules.worldtime) fields.push({ name: 'Waktu', value: codeBlock(data.rules.worldtime), inline: true });
  if (data.rules.version) fields.push({ name: 'Versi', value: codeBlock(data.rules.version), inline: true });

  return new EmbedBuilder()
    .setColor(0x57f287)
    .setTitle(`🟢 ${data.hostname || 'Server SA-MP'}`)
    .addFields(fields)
    .setFooter({ text: footerText() })
    .setTimestamp();
}

/**
 * Struktur field sengaja disamakan persis dengan buildOnlineEmbed — cuma
 * warna merah dan semua value diganti "-" karena tidak ada data yang bisa
 * diambil sama sekali waktu server offline.
 */
function buildOfflineEmbed(server) {
  const fields = [
    { name: 'IP:Port', value: codeBlock(`${server.ip}:${server.port}`), inline: true },
    { name: 'Gamemode', value: codeBlock('-'), inline: true },
    { name: 'Bahasa', value: codeBlock('-'), inline: true },
    { name: 'Pemain', value: codeBlock('-'), inline: true },
    { name: 'Password', value: codeBlock('-'), inline: true },
  ];

  return new EmbedBuilder()
    .setColor(0xed4245)
    .setTitle('🔴 Server tidak dapat dijangkau')
    .addFields(fields)
    .setFooter({ text: footerText() })
    .setTimestamp();
}

async function refresh(client, guildId) {
  // Selalu baca ulang dari database — sama seperti IP, tidak ada yang
  // disimpan/diandalkan dari memori proses.
  const server = serverRepo.getServer(guildId);
  const monitor = monitorRepo.getMonitor(guildId);

  // Kalau data sudah dihapus (mis. lewat !monitordell) tapi interval lama
  // masih sempat jalan, hentikan supaya tidak nyangkut.
  if (!server || !monitor) {
    stopMonitor(guildId);
    return;
  }

  let embed;
  try {
    const data = await querySampServer(server.ip, server.port);
    embed = buildOnlineEmbed(server, data);
  } catch (err) {
    embed = buildOfflineEmbed(server);
  }

  try {
    const channel = await client.channels.fetch(monitor.channel_id);
    const message = monitor.message_id
      ? await channel.messages.fetch(monitor.message_id).catch((err) => {
          console.error(`Pesan monitor lama tidak ditemukan untuk guild ${guildId}:`, err.message);
          return null;
        })
      : null;

    if (message) {
      await message.edit({ embeds: [embed] });
      return;
    }

    // Belum pernah ada pesan, atau pesan lama sudah dihapus/tidak bisa
    // diambil -> kirim baru dan simpan message_id-nya ke database.
    const sent = await channel.send({ embeds: [embed] });
    monitorRepo.setMonitorMessageId(guildId, sent.id);
  } catch (err) {
    console.error(`Gagal update monitor untuk guild ${guildId}:`, err.message);
  }
}

function startMonitor(client, guildId) {
  stopMonitor(guildId); // cegah interval dobel kalau !monitor dipanggil ulang

  refresh(client, guildId); // update pertama kali langsung, tanpa nunggu 30 detik
  const intervalId = setInterval(() => refresh(client, guildId), MONITOR_INTERVAL_MS);
  activeIntervals.set(guildId, intervalId);
}

function stopMonitor(guildId) {
  const intervalId = activeIntervals.get(guildId);
  if (intervalId) {
    clearInterval(intervalId);
    activeIntervals.delete(guildId);
  }
}

function restoreAllMonitors(client) {
  const monitors = monitorRepo.getAllMonitors();
  for (const m of monitors) {
    startMonitor(client, m.guild_id);
  }
}

module.exports = { startMonitor, stopMonitor, restoreAllMonitors };
