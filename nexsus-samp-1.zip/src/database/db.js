const path = require('path');
const Database = require('better-sqlite3');
const { DB_PATH } = require('../config');

const db = new Database(path.join(process.cwd(), DB_PATH));
db.pragma('journal_mode = WAL');

// 1 server Discord (guild) hanya boleh terhubung ke 1 IP SA-MP saja,
// makanya guild_id dijadikan PRIMARY KEY di semua tabel ini.
db.exec(`
  CREATE TABLE IF NOT EXISTS servers (
    guild_id TEXT PRIMARY KEY,
    ip TEXT NOT NULL,
    port INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS monitors (
    guild_id TEXT PRIMARY KEY,
    channel_id TEXT NOT NULL,
    message_id TEXT
  );

  CREATE TABLE IF NOT EXISTS resip_settings (
    guild_id TEXT PRIMARY KEY,
    enabled INTEGER NOT NULL DEFAULT 1
  );
`);

module.exports = db;
