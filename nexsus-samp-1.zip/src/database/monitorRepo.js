const db = require('./db');

const getStmt = db.prepare('SELECT channel_id, message_id FROM monitors WHERE guild_id = ?');
const getAllStmt = db.prepare('SELECT guild_id, channel_id, message_id FROM monitors');
const upsertStmt = db.prepare(`
  INSERT INTO monitors (guild_id, channel_id, message_id)
  VALUES (?, ?, ?)
  ON CONFLICT(guild_id) DO UPDATE SET channel_id = excluded.channel_id, message_id = excluded.message_id
`);
const updateMessageIdStmt = db.prepare('UPDATE monitors SET message_id = ? WHERE guild_id = ?');
const deleteStmt = db.prepare('DELETE FROM monitors WHERE guild_id = ?');

function getMonitor(guildId) {
  return getStmt.get(guildId) || null;
}

function getAllMonitors() {
  return getAllStmt.all();
}

function setMonitor(guildId, channelId, messageId = null) {
  upsertStmt.run(guildId, channelId, messageId);
}

function setMonitorMessageId(guildId, messageId) {
  updateMessageIdStmt.run(messageId, guildId);
}

function deleteMonitor(guildId) {
  deleteStmt.run(guildId);
}

module.exports = { getMonitor, getAllMonitors, setMonitor, setMonitorMessageId, deleteMonitor };
