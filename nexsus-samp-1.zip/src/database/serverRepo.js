const db = require('./db');

const getStmt = db.prepare('SELECT ip, port FROM servers WHERE guild_id = ?');
const insertStmt = db.prepare('INSERT INTO servers (guild_id, ip, port) VALUES (?, ?, ?)');
const updateStmt = db.prepare('UPDATE servers SET ip = ?, port = ? WHERE guild_id = ?');
const deleteStmt = db.prepare('DELETE FROM servers WHERE guild_id = ?');

function getServer(guildId) {
  return getStmt.get(guildId) || null;
}

function createServer(guildId, ip, port) {
  insertStmt.run(guildId, ip, port);
}

function updateServer(guildId, ip, port) {
  updateStmt.run(ip, port, guildId);
}

function deleteServer(guildId) {
  deleteStmt.run(guildId);
}

module.exports = { getServer, createServer, updateServer, deleteServer };
