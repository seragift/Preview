const db = require('./db');

const getStmt = db.prepare('SELECT enabled FROM resip_settings WHERE guild_id = ?');
const upsertStmt = db.prepare(`
  INSERT INTO resip_settings (guild_id, enabled) VALUES (?, ?)
  ON CONFLICT(guild_id) DO UPDATE SET enabled = excluded.enabled
`);

/**
 * Default aktif (true) kalau guild belum pernah mengatur !resip sama sekali.
 */
function isResipEnabled(guildId) {
  const row = getStmt.get(guildId);
  return row ? !!row.enabled : true;
}

function setResip(guildId, enabled) {
  upsertStmt.run(guildId, enabled ? 1 : 0);
}

module.exports = { isResipEnabled, setResip };
