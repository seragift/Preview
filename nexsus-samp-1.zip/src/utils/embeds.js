const { EmbedBuilder } = require('discord.js');
const { BRAND_NAME } = require('../config');

function footerText() {
  return `${BRAND_NAME} © ${new Date().getFullYear()}`;
}

function errorEmbed(description) {
  return new EmbedBuilder()
    .setColor(0xed4245)
    .setDescription(`❌ ${description}`)
    .setFooter({ text: footerText() });
}

function successEmbed(description) {
  return new EmbedBuilder()
    .setColor(0x57f287)
    .setDescription(`✅ ${description}`)
    .setFooter({ text: footerText() });
}

function resultEmbed({ color, title, imageUrl }) {
  return new EmbedBuilder()
    .setColor(color)
    .setTitle(title)
    .setImage(imageUrl)
    .setFooter({ text: footerText() });
}

/**
 * Embed auto-responder untuk !resip: cuma judul + kotak IP:Port + footer,
 * ditampilkan saat ada yang ketik kata "ip" di chat.
 */
function ipAddressEmbed(server) {
  return new EmbedBuilder()
    .setColor(0x5865f2)
    .setTitle('🌐 IP ADDRESS')
    .setDescription('```' + `${server.ip}:${server.port}` + '```')
    .setFooter({ text: footerText() })
    .setTimestamp();
}

module.exports = { errorEmbed, successEmbed, resultEmbed, ipAddressEmbed, footerText };
