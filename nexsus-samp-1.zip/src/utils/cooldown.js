// key: `${commandKey}:${userId}` -> timestamp kapan cooldown berakhir (ms)
const cooldowns = new Map();

/**
 * Sisa waktu cooldown dalam ms. 0 kalau sudah boleh pakai lagi.
 */
function getRemainingCooldown(commandKey, userId) {
  const expiry = cooldowns.get(`${commandKey}:${userId}`);
  if (!expiry) return 0;

  const remaining = expiry - Date.now();
  return remaining > 0 ? remaining : 0;
}

function setCooldown(commandKey, userId, durationMs) {
  cooldowns.set(`${commandKey}:${userId}`, Date.now() + durationMs);
}

module.exports = { getRemainingCooldown, setCooldown };
