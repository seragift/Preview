const { PermissionFlagsBits } = require('discord.js');

/**
 * Semua command prefix (!) di bot ini cuma boleh dipakai Administrator.
 * message.member bisa null di kondisi tertentu (mis. member tidak ke-cache),
 * jadi default-nya ditolak (aman) kalau tidak bisa dipastikan.
 */
function isAdmin(message) {
  return message.member?.permissions.has(PermissionFlagsBits.Administrator) ?? false;
}

module.exports = { isAdmin };
