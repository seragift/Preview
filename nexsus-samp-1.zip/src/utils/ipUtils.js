function isValidIp(ip) {
  return ip.split('.').every((octet) => Number(octet) >= 0 && Number(octet) <= 255);
}

function isValidPort(port) {
  return port >= 1 && port <= 65535;
}

/**
 * Parse string "ip:port" secara ketat (harus persis format itu).
 * Dipakai untuk validasi argumen command seperti !setip / !ipedit.
 */
function parseIpPort(input) {
  const match = input.trim().match(/^(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}):(\d{1,5})$/);
  if (!match) return null;

  const ip = match[1];
  const port = parseInt(match[2], 10);

  if (!isValidIp(ip) || !isValidPort(port)) return null;

  return { ip, port };
}

/**
 * Cari pola "ip:port" di dalam teks bebas (untuk auto-responder !resip),
 * tidak perlu seluruh pesan persis format itu.
 */
function findIpPortInText(text) {
  const match = text.match(/(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}):(\d{1,5})/);
  if (!match) return null;

  const ip = match[1];
  const port = parseInt(match[2], 10);

  if (!isValidIp(ip) || !isValidPort(port)) return null;

  return { ip, port };
}

/**
 * Deteksi kata "ip" berdiri sendiri (bukan bagian kata lain seperti "trip"),
 * dipakai untuk auto-responder !resip. Case-insensitive.
 */
function isIpKeyword(text) {
  return /\bip\b/i.test(text);
}

module.exports = { parseIpPort, findIpPortInText, isIpKeyword };
