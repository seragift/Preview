const { spawn } = require('child_process');
const path = require('path');

/**
 * Wrapper sederhana untuk berkomunikasi dengan binary Stockfish via UCI protocol.
 *
 * PENTING (baca ini dulu sebelum deploy ke Pterodactyl):
 * - Binary Stockfish HARUS sudah ada di server, ini bukan npm package.
 * - Set path lewat environment variable STOCKFISH_PATH, atau taruh
 *   binary-nya di root project dengan nama "stockfish" (Linux) lalu
 *   `chmod +x stockfish`.
 * - Kalau di Pterodactyl kamu tidak bisa apt-get / tidak ada akses compile,
 *   download prebuilt binary Linux x64 dari halaman resmi Stockfish,
 *   upload manual via file manager, lalu chmod +x.
 * - Kalau ternyata binary tidak bisa dijalankan sama sekali di environment
 *   kamu, fallback-nya ada di utils/simpleAI.js (random-weighted, tanpa
 *   dependency eksternal apapun) — tinggal ganti import di commands/catur.js.
 */

const STOCKFISH_PATH = process.env.STOCKFISH_PATH || path.join(process.cwd(), 'stockfish');

class StockfishEngine {
  constructor() {
    this.process = null;
    this.ready = false;
    this.queue = [];
    this.buffer = '';
  }

  start() {
    return new Promise((resolve, reject) => {
      try {
        this.process = spawn(STOCKFISH_PATH);
      } catch (err) {
        return reject(new Error(`Gagal spawn Stockfish di path "${STOCKFISH_PATH}": ${err.message}`));
      }

      this.process.on('error', (err) => {
        reject(new Error(`Stockfish tidak bisa dijalankan (cek STOCKFISH_PATH & permission chmod +x): ${err.message}`));
      });

      this.process.stdout.on('data', (chunk) => {
        this.buffer += chunk.toString();
        this._processBuffer();
      });

      this.send('uci');
      this._waitFor('uciok').then(() => {
        this.ready = true;
        resolve();
      }).catch(reject);
    });
  }

  _processBuffer() {
    const lines = this.buffer.split('\n');
    this.buffer = lines.pop();
    for (const line of lines) {
      if (this.queue.length > 0) {
        this.queue[0].lines.push(line);
        if (this.queue[0].test(line)) {
          const finished = this.queue.shift();
          finished.resolve(finished.lines);
        }
      }
    }
  }

  _waitFor(matchString) {
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => reject(new Error('Timeout menunggu respons Stockfish')), 10000);
      this.queue.push({
        lines: [],
        test: (line) => line.includes(matchString),
        resolve: (lines) => { clearTimeout(timeout); resolve(lines); },
      });
    });
  }

  send(cmd) {
    if (!this.process) throw new Error('Stockfish belum di-start');
    this.process.stdin.write(cmd + '\n');
  }

  /**
   * Minta Stockfish menghitung gerakan terbaik dari posisi FEN tertentu.
   * @param {string} fen posisi papan saat ini
   * @param {number} skillLevel 0-20, makin tinggi makin kuat
   * @param {number} moveTimeMs waktu berpikir dalam milidetik
   * @returns {Promise<string>} gerakan terbaik dalam notasi UCI (contoh: "e2e4")
   */
  async getBestMove(fen, skillLevel = 10, moveTimeMs = 1000) {
    this.send(`setoption name Skill Level value ${skillLevel}`);
    this.send(`position fen ${fen}`);
    this.send(`go movetime ${moveTimeMs}`);
    const lines = await this._waitFor('bestmove');
    const bestMoveLine = lines.find((l) => l.startsWith('bestmove'));
    if (!bestMoveLine) throw new Error('Stockfish tidak mengembalikan bestmove');
    const move = bestMoveLine.split(' ')[1];
    if (!move || move === '(none)') return null;
    return move;
  }

  stop() {
    if (this.process) {
      this.send('quit');
      this.process.kill();
      this.process = null;
      this.ready = false;
    }
  }
}

module.exports = { StockfishEngine, STOCKFISH_PATH };
