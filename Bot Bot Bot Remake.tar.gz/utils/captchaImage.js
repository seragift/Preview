const { createCanvas } = require('@napi-rs/canvas');

/**
 * Generate kode captcha numerik acak.
 * @param {number} length - jumlah digit
 * @returns {string}
 */
function generateCaptchaCode(length = 4) {
  let result = '';
  for (let i = 0; i < length; i++) {
    result += Math.floor(Math.random() * 10).toString();
  }
  return result;
}

/**
 * Render gambar captcha bergaya "wave" — angka target berwarna biru terang
 * disisipkan di antara angka pengganggu (noise) berwarna redup, lalu
 * keduanya digambar di atas garis gelombang sinus + grid + partikel,
 * meniru gaya pada referensi "VERIFY TO PROCEED".
 *
 * @param {string} code - kode target, mis. "3625"
 * @returns {Buffer} PNG buffer
 */
function renderCaptchaImage(code) {
  const width = 700;
  const height = 260;
  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext('2d');

  // ── Background gradient (deep navy, sesuai referensi) ──
  const bg = ctx.createLinearGradient(0, 0, width, height);
  bg.addColorStop(0, '#0b1220');
  bg.addColorStop(1, '#131b2e');
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, width, height);

  // ── Grid halus ──
  ctx.strokeStyle = 'rgba(120, 150, 200, 0.08)';
  ctx.lineWidth = 1;
  const gridSize = 28;
  for (let x = 0; x < width; x += gridSize) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, height);
    ctx.stroke();
  }
  for (let y = 0; y < height; y += gridSize) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(width, y);
    ctx.stroke();
  }

  // ── Partikel titik acak (kesan "noise" digital) ──
  for (let i = 0; i < 60; i++) {
    ctx.fillStyle = `rgba(150, 180, 230, ${Math.random() * 0.25})`;
    const r = Math.random() * 1.6 + 0.3;
    ctx.beginPath();
    ctx.arc(Math.random() * width, Math.random() * height, r, 0, Math.PI * 2);
    ctx.fill();
  }

  // ── Garis gelombang sinus (2 lapis, warna teal & indigo) ──
  function drawWave(color, amplitude, frequency, phase, yOffset, lineWidth) {
    ctx.strokeStyle = color;
    ctx.lineWidth = lineWidth;
    ctx.beginPath();
    for (let x = 0; x <= width; x++) {
      const y = yOffset + Math.sin(x * frequency + phase) * amplitude;
      if (x === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();
  }
  drawWave('rgba(56, 189, 178, 0.55)', 28, 0.018, 0, height * 0.62, 2);
  drawWave('rgba(88, 101, 242, 0.45)', 22, 0.024, 2, height * 0.45, 2);

  // ── Label judul kecil pojok kiri atas ──
  ctx.fillStyle = 'rgba(120, 170, 255, 0.55)';
  ctx.font = 'bold 20px sans-serif';
  ctx.fillText('VERIFY TO PROCEED', 24, 38);

  // ── Susun slot: digit target (biru terang) diselingi digit noise (abu redup) ──
  const totalSlots = code.length + 2; // tambahan noise agar tidak terlalu mudah ditebak posisinya
  const slotWidth = width / (totalSlots + 1);
  const targetPositions = new Set();
  while (targetPositions.size < code.length) {
    targetPositions.add(1 + Math.floor(Math.random() * totalSlots));
  }
  const sortedTargets = [...targetPositions].sort((a, b) => a - b);

  let codeIndex = 0;
  for (let slot = 1; slot <= totalSlots; slot++) {
    const isTarget = sortedTargets.includes(slot);
    const digit = isTarget ? code[codeIndex++] : Math.floor(Math.random() * 10).toString();

    const baseX = slot * slotWidth;
    const wobbleY = Math.sin(baseX * 0.02) * 30;
    const x = baseX + (Math.random() * 14 - 7);
    const y = height * 0.55 + wobbleY + (Math.random() * 16 - 8);
    const rotation = (Math.random() * 0.5 - 0.25);
    const fontSize = isTarget ? 52 : 40;

    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(rotation);
    ctx.font = `bold ${fontSize}px sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';

    if (isTarget) {
      // Glow biru terang — ini adalah "blue numbers" yang harus ditebak
      ctx.shadowColor = 'rgba(90, 140, 255, 0.9)';
      ctx.shadowBlur = 18;
      ctx.fillStyle = '#6f9bff';
      ctx.fillText(digit, 0, 0);
      ctx.shadowBlur = 0;
      ctx.fillStyle = '#bcd2ff';
      ctx.fillText(digit, 0, 0);
    } else {
      // Noise — redup, tanpa glow, agar kontras jelas dengan target
      ctx.fillStyle = 'rgba(140, 150, 170, 0.35)';
      ctx.fillText(digit, 0, 0);
    }
    ctx.restore();
  }

  // ── Border tipis ──
  ctx.strokeStyle = 'rgba(120, 150, 220, 0.25)';
  ctx.lineWidth = 2;
  ctx.strokeRect(1, 1, width - 2, height - 2);

  return canvas.toBuffer('image/png');
}

module.exports = { generateCaptchaCode, renderCaptchaImage };
