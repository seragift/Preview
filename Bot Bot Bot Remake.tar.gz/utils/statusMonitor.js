const os = require('os');
const fs = require('fs');
const { EmbedBuilder } = require('discord.js');
const config = require('../config.json');

module.exports = (client) => {
  let statusMessage = null;

  // ==========================================
  // UTILITY FUNCTIONS
  // ==========================================
  const utils = {
    /**
     * Membuat progress bar dinamis sepanjang 10 karakter
     */
    makeProgressBar: (percentage) => {
      const totalBlocks = 10;
      const filledBlocks = Math.round((percentage / 100) * totalBlocks);
      const emptyBlocks = totalBlocks - filledBlocks;
      
      // Memastikan batas minimum/maksimum blok agar tidak error
      const safeFilled = Math.max(0, Math.min(totalBlocks, filledBlocks));
      const safeEmpty = Math.max(0, Math.min(totalBlocks, emptyBlocks));

      return `[${'▬'.repeat(safeFilled)}${'▭'.repeat(safeEmpty)}]`;
    },

    /**
     * Mengambil data penggunaan Disk (Penyimpanan) bawaan Node.js
     */
    getDiskUsage: () => {
      try {
        // Membaca root directory (gunakan '/' untuk Linux/Hosting, 'C:' untuk Windows)
        const stats = fs.statfsSync(process.platform === 'win32' ? 'C:' : '/');
        const totalDisk = stats.bsize * stats.blocks;
        const freeDisk = stats.bsize * stats.bfree;
        const usedDisk = totalDisk - freeDisk;
        const diskPercentage = ((usedDisk / totalDisk) * 100).toFixed(2);

        return {
          used: (usedDisk / (1024 * 1024 * 1024)).toFixed(1) + 'GB',
          total: (totalDisk / (1024 * 1024 * 1024)).toFixed(0) + 'GB',
          percentage: diskPercentage
        };
      } catch (e) {
        // Fallback jika terjadi error pembacaan disk
        return { used: '0GB', total: '2GB', percentage: 0 };
      }
    },

    /**
     * Mengambil persentase penggunaan CPU
     */
    getCPUUsage: () => {
      return new Promise((resolve) => {
        const cpusFirst = os.cpus();
        setTimeout(() => {
          const cpusSecond = os.cpus();
          let totalIdle = 0;
          let totalTick = 0;

          for (let i = 0; i < cpusFirst.length; i++) {
            const first = cpusFirst[i].times;
            const second = cpusSecond[i].times;
            const idle = second.idle - first.idle;
            const total = Object.keys(second).reduce((acc, key) => acc + (second[key] - first[key]), 0);
            totalIdle += idle;
            totalTick += total;
          }

          const usage = totalTick ? ((1 - totalIdle / totalTick) * 100).toFixed(2) : "0.00";
          resolve(usage);
        }, 1000);
      });
    }
  };

  // ==========================================
  // CORE MONITORING FUNCTION
  // ==========================================
  const updateStatus = async (channel) => {
    try {
      // 1. Ambil Data Resource
      const cpuUsage = await utils.getCPUUsage();
      
      const totalMem = os.totalmem();
      const usedMem = totalMem - os.freemem();
      const memPercentage = ((usedMem / totalMem) * 100).toFixed(2);
      
      // Konversi RAM ke format MB/GB terdekat
      const usedMemMB = (usedMem / (1024 * 1024)).toFixed(0) + 'MB';
      const totalMemGB = (totalMem / (1024 * 1024 * 1024)).toFixed(0) + 'GB';

      const disk = utils.getDiskUsage();

      // Format Waktu WIB (Waktu Indonesia Barat)
      const wibTime = new Date().toLocaleTimeString('id-ID', {
        timeZone: 'Asia/Jakarta',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false
      }).replace(/\./g, ':'); // Mengubah format 09.13.43 menjadi 09:13:43

      // 2. Build Tampilan Persis Seperti Gambar
      const monitoringText = 
        `┏ **CPU:** ${cpuUsage}%︱100%\n` +
        ` ${utils.makeProgressBar(cpuUsage)} \n` +
        `┣ **RAM:** ${usedMemMB}︱${totalMemGB}\n` +
        ` ${utils.makeProgressBar(memPercentage)} \n` +
        `┣ **DSK:** ${disk.used}︱${disk.total}\n` +
        ` ${utils.makeProgressBar(disk.percentage)} \n` +
        `┗ **Update:** ${wibTime} WIB`;

      const statusEmbed = new EmbedBuilder()
        .setTitle('MONITORING BOT')
        .setColor(0x2B2D31) // Warna gelap sleek agar tampak menyatu dengan background Discord
        .setDescription(monitoringText);

      // 3. Edit atau Kirim Pesan
      if (statusMessage) {
        await statusMessage.edit({ embeds: [statusEmbed] }).catch(() => null);
      } else {
        statusMessage = await channel.send({ embeds: [statusEmbed] }).catch(() => null);
      }

    } catch (err) {
      console.error('❌ Error update status monitor:', err);
    }
  };

  // ==========================================
  // INITIALIZATION EVENT
  // ==========================================
  client.once('ready', async () => {
    const channelId = config.MONITORING_HOST;
    const channel = await client.channels.fetch(channelId).catch(() => null);
    
    if (!channel) {
      return console.warn(`❌ Channel dengan ID [${channelId}] tidak ditemukan!`);
    }

    // Jalankan pertama kali
    await updateStatus(channel);

    // Loop otomatis setiap 5 detik[span_2](start_span)[span_2](end_span)
    setInterval(() => updateStatus(channel), 5000);
  });
};


