console.log('🚀 [AzesZ Bot] Memulai proses inisialisasi...');

const fs = require('fs');
const path = require('path');

// ==========================================
// 📦 AUTO-INSTALLER DEPENDENCY
// ==========================================
const { ensurePackagesInstalled } = require('./utils/autoInstall');

// ==========================================
// 📦 AUTO-INSTALL NPM DEPENDENCIES
// ==========================================
ensurePackagesInstalled([
  '@napi-rs/canvas',      // captcha image generator + render papan catur
  '@distube/ytdl-core',   // download audio YouTube (pure JS, tanpa binary)
  'chess.js',             // logic aturan catur untuk fitur /catur
]);

// CATATAN: Fitur /catur pakai canvas untuk gambar papan (BUKAN Stockfish,
// tidak perlu upload binary apapun). AI lawan bot pakai minimax ringan
// tanpa dependency eksternal (utils/simpleAI.js).

// Error handler global
process.on('unhandledRejection', err => {
  console.error('❌ [Global] Unhandled Promise Rejection:', err);
});

process.on('uncaughtException', err => {
 // console.error('❌ [Global] Uncaught Exception:', err);
});

const { Client, Collection, GatewayIntentBits, Partials, REST, Routes } = require('discord.js');
const config = require('./config.json');

// Monitoring helper
const statusMonitor = require('./utils/statusMonitor');
const errorMonitoring = require('./utils/errormonitoring');

// Inisialisasi client Discord (Mendukung Fitur Server & DM AI)
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,   // Membaca isi teks pesan (Wajib untuk AI)
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.DirectMessages    // ✨ Mengizinkan bot menerima pesan masuk dari DM/PM privat
  ],
  partials: [
    Partials.Channel,                   // ✨ Mengizinkan bot memproses event di dalam channel DM privat
    Partials.Message                    // Mengizinkan penanganan pesan belum ter-cache
  ]
});

// Collections & map
client.commands = new Collection();
client.pendingRequests = new Map();

console.log('✅ [Init] Module dan client Discord berhasil di-load.');

// Status & error monitoring
statusMonitor(client);
errorMonitoring(client);

// Load command handler
const commandsArray = [];
const foldersPath = path.join(__dirname, 'commands');
const commandFolders = fs.readdirSync(foldersPath);

for (const folder of commandFolders) {
  const commandsPath = path.join(foldersPath, folder);
  const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));

  for (const file of commandFiles) {
    const filePath = path.join(commandsPath, file);
    try {
      const command = require(filePath);
      if ('data' in command && 'execute' in command) {
        client.commands.set(command.data.name, command);
        commandsArray.push(command.data.toJSON());
        console.log(`✅ [Command] Berhasil dimuat: ${file}`);
      } else {
        console.warn(`⚠️ [Command] Format salah di: ${file}`);
      }
    } catch (err) {
      console.error(`❌ [Command] Gagal load ${file}:`, err);
    }
  }
}

// Deploy slash commands
const rest = new REST({ version: '10' }).setToken(config.token);
rest.put(Routes.applicationCommands(config.clientId), { body: commandsArray })
  .then(() => console.log('📤 [Deploy] Slash commands berhasil di-deploy!'))
  .catch(err => console.error('❌ [Deploy] Gagal deploy commands:', err));

// Load event handler
const eventsPath = path.join(__dirname, 'events');
const eventFiles = fs.readdirSync(eventsPath).filter(file => file.endsWith('.js'));

for (const file of eventFiles) {
  const filePath = path.join(eventsPath, file);
  try {
    const event = require(filePath);
    const eventType = event.once ? 'once' : 'on';
    client[eventType](event.name, (...args) => event.execute(...args, client));
    console.log(`✅ [Event] Berhasil dimuat: ${file}`);
  } catch (err) {
    console.error(`❌ [Event] Gagal load ${file}:`, err);
  }
}

// Login bot
client.login(config.token)
  .then(() => console.log('🔐 [Login] Bot berhasil login ke Discord!'))
  .catch(err => console.error('❌ [Login] Gagal login ke Discord:', err));
