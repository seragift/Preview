const { EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
const dbPath = path.join(__dirname, '../stickyData.json');

module.exports = {
  name: 'messageCreate',
  async execute(message) {
    // Abaikan jika pesan dikirim oleh bot itu sendiri agar tidak terjadi looping tanpa akhir
    if (message.author.bot) return;

    if (!fs.existsSync(dbPath)) return;
    const db = JSON.parse(fs.readFileSync(dbPath, 'utf8'));

    const channelId = message.channel.id;

    // Cek apakah channel saat ini terdaftar memiliki program sticky aktif
    if (db[channelId]) {
      const stickyConfig = db[channelId];

      // KUNCI PENGAMAN SPAM FLUX: Menghapus pesan sticky lama yang sudah tertimbun chat user
      const oldStickyMessage = await message.channel.messages.fetch(stickyConfig.lastMessageId).catch(() => null);
      if (oldStickyMessage) {
        await oldStickyMessage.delete().catch(() => null);
      }

      // Kirim ulang pesan sticky baru agar posisinya kembali ke baris paling bawah layar
      let newStickyMessage;
      if (stickyConfig.tipe === 'text') {
        newStickyMessage = await message.channel.send({
          content: stickyConfig.konten
        });
      } else {
        const embedSticky = new EmbedBuilder()
          .setTitle(stickyConfig.judul)
          .setDescription(stickyConfig.konten)
          .setColor(stickyConfig.warna)
          .setTimestamp();
          
        newStickyMessage = await message.channel.send({
          embeds: [embedSticky]
        });
      }

      // Perbarui ID pesan terbaru ke database agar bisa dihapus pada chat user berikutnya
      db[channelId].lastMessageId = newStickyMessage.id;
      fs.writeFileSync(dbPath, JSON.stringify(db, null, 2));
    }
  }
};


