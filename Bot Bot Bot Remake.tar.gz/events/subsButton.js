// events/subButtonHandler.js
const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder, EmbedBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { SUBSCRIBE_ROLE_ID, REQ_SUBSCRIBE_CHANNEL_ID } = require('../config.json');

module.exports = {
  name: 'interactionCreate',
  async execute(interaction) {

    // ───────── BAGIAN 1: PROSES KLIK TOMBOL OLEH ADMIN ─────────
    if (interaction.isButton() && interaction.customId.startsWith('sub_')) {
      if (!interaction.member.permissions.has('Administrator')) {
        return interaction.reply({ content: '🚫 Hanya Administrator yang dapat memverifikasi berkas subscriber!', ephemeral: true });
      }

      const [, status, userId, reqMsgId] = interaction.customId.split('_');
      const targetMember = await interaction.guild.members.fetch(userId).catch(() => null);

      if (!targetMember) {
        return interaction.reply({ content: '❌ Pengguna sudah keluar dari server ini. Pengajuan hangus.', ephemeral: true });
      }

      // KONDISI A: JIKA BUKTI DINYATAKAN VALID
      if (status === 'valid') {
        await interaction.deferReply({ ephemeral: true });

        // Beri Role & Ganti Nickname
        const role = interaction.guild.roles.cache.get(SUBSCRIBE_ROLE_ID);
        if (role) await targetMember.roles.add(role).catch(() => null);
        await targetMember.setNickname(`FLWRS | ${targetMember.user.displayName}`).catch(() => null);

        // Notifikasi via DM ke User
        try {
          await targetMember.send(`🎉 Selamat, bukti screenshot **Follow** Anda di **AzesZ Page** dinyatakan **VALID** oleh Admin! Role subscriber Anda telah aktif.`);
        } catch {
          console.log(`Gagal kirim DM ke ${targetMember.user.tag} karena DM ditutup.`);
        }

        const reqChannel = interaction.guild.channels.cache.get(REQ_SUBSCRIBE_CHANNEL_ID);
        if (reqChannel) {
          const origMsg = await reqChannel.messages.fetch(reqMsgId).catch(() => null);
          if (origMsg) {
            await origMsg.react('✅').catch(() => null);
            
            // Cari pesan bot yang merespons kiriman user tersebut
            const channelMessages = await reqChannel.messages.fetch({ limit: 10 });
            const botReply = channelMessages.find(m => m.author.id === interaction.client.user.id && m.reference?.messageId === reqMsgId);
            
            if (botReply) {
              await botReply.edit(`✅ **Sukses di-accept oleh admin!** Role dan nama kamu telah diperbarui.`);
            }
          }
        }

        // Perbarui pesan log panel admin
        const updatedEmbed = EmbedBuilder.from(interaction.message.embeds[0])
          .setColor('#2ECC71')
          .setTitle('✅ REQUEST SUDAH DI-APPROVE')
          .setDescription(`Request Followers milik <@${userId}> telah **DITERIMA** oleh <@${interaction.user.id}>.`);

        const disabledRow = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId('v_d').setLabel('Status: Valid & Terverifikasi').setStyle(ButtonStyle.Success).setDisabled(true)
        );

        await interaction.message.edit({ embeds: [updatedEmbed], components: [disabledRow] });
        return interaction.editReply({ content: `✅ Berhasil memverifikasi <@${userId}> sebagai subscriber.` });
      }

      // KONDISI B: JIKA BUKTI DINYATAKAN INVALID (PANGGIL POP-UP REASON)
      if (status === 'invalid') {
        const modal = new ModalBuilder()
          .setCustomId(`sub_modal_${userId}_${reqMsgId}`)
          .setTitle('❌ ALASAN PENOLAKAN BUKTI');

        const reasonInput = new TextInputBuilder()
          .setCustomId('tolak_reason')
          .setLabel('Mengapa berkas ini ditolak?')
          .setStyle(TextInputStyle.Paragraph)
          .setPlaceholder('Contoh: Gambar tidak buram/nama channel tidak sesuai/belum klik lonceng.')
          .setRequired(true)
          .setMaxLength(300);

        modal.addComponents(new ActionRowBuilder().addComponents(reasonInput));
        return interaction.showModal(modal);
      }
    }

    // ───────── BAGIAN 2: PROSES SUBMIT MODAL REASON OLEH ADMIN ─────────
    if (interaction.isModalSubmit() && interaction.customId.startsWith('sub_modal_')) {
      await interaction.deferReply({ ephemeral: true });

      const [, , userId, reqMsgId] = interaction.customId.split('_');
      const reasonText = interaction.fields.getTextInputValue('tolak_reason');
      const targetMember = await interaction.guild.members.fetch(userId).catch(() => null);

      if (targetMember) {
        try {
          await targetMember.send(`❌ DiTolak!, bukti screenshot pengajuan subscribe Anda di **AzesZ Page** dinyatakan **INVALID**.\n\n> **Alasan :**\n *${reasonText}*\n\nSilakan kirim ulang bukti screenshot yang benar di channel sebelumnya.`);
        } catch {
          console.log(`Gagal kirim DM penolakan ke ${userId} karena DM terkunci.`);
        }
      }

      // 🔄 UPDATE PESAN DI CHANNEL REQUEST (REJECTED)
      const reqChannel = interaction.guild.channels.cache.get(REQ_SUBSCRIBE_CHANNEL_ID);
      if (reqChannel) {
        const origMsg = await reqChannel.messages.fetch(reqMsgId).catch(() => null);
        if (origMsg) {
          await origMsg.react('❌').catch(() => null);
         
          const channelMessages = await reqChannel.messages.fetch({ limit: 10 });
          const botReply = channelMessages.find(m => m.author.id === interaction.client.user.id && m.reference?.messageId === reqMsgId);
          
          if (botReply) {
            await botReply.edit(`❌ **DiTolak!, pengajuan kamu ditolak oleh admin.** Silakan cek DM kamu dari bot untuk melihat alasannya.`);
          }
        }
      }

      // Perbarui pesan log panel admin
      const rejectedEmbed = EmbedBuilder.from(interaction.message.embeds[0])
        .setColor('#E74C3C')
        .setTitle('❌ REQUEST DITOLAK')
        .setDescription(`Request subscribe milik <@${userId}> telah **DITOLAK** oleh <@${interaction.user.id}>.\n\n💬 **Alasan:**\n ${reasonText}`);

      const disabledRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('i_d').setLabel('Status: Ditolak / Invalid').setStyle(ButtonStyle.Danger).setDisabled(true)
      );

      await interaction.message.edit({ embeds: [rejectedEmbed], components: [disabledRow] });
      return interaction.editReply({ content: `❌ Request milik <@${userId}> sukses ditolak dengan alasan yang dikirim.` });
    }
  }
};
