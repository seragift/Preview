const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { ANTRI_CHANNEL_ID, SELLER_ROLE_ID } = require('../config.json');
const fs = require('fs');
const path = require('path');

// ─── PATH FILE JSON ───
const ANTRI_FILE = path.join(process.cwd(), 'data', 'antri.json');

// ─── INISIALISASI: Buat file & folder JSON otomatis saat bot start ───
function initAntriFile() {
  const dir = path.dirname(ANTRI_FILE);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  if (!fs.existsSync(ANTRI_FILE)) {
    fs.writeFileSync(ANTRI_FILE, JSON.stringify([], null, 2), 'utf-8');
    console.log('[ANTRI] antri.json dibuat otomatis di:', ANTRI_FILE);
  }
}
initAntriFile(); // Dijalankan sekali saat modul pertama kali dimuat

// ─── HELPER: Load JSON ───
function loadAntri() {
  try {
    const raw = fs.readFileSync(ANTRI_FILE, 'utf-8');
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch (err) {
    console.error('[ANTRI] Gagal membaca antri.json:', err.message);
    // Jika file rusak, reset ke array kosong
    fs.writeFileSync(ANTRI_FILE, JSON.stringify([], null, 2), 'utf-8');
    return [];
  }
}

// ─── HELPER: Save JSON ───
function saveAntri(data) {
  try {
    fs.writeFileSync(ANTRI_FILE, JSON.stringify(data, null, 2), 'utf-8');
  } catch (err) {
    console.error('[ANTRI] Gagal menyimpan antri.json:', err.message);
  }
}

// ─── HELPER: ID berikutnya ───
function getNextId(queue) {
  if (queue.length === 0) return 1;
  return Math.max(...queue.map(q => q.id)) + 1;
}

// ─── PROGRESS BAR ───
function renderProgressBar(percentage) {
  const totalBlocks = 10;
  const filledBlocks = Math.round(percentage / 10);
  const emptyBlocks = totalBlocks - filledBlocks;
  const filledChar = '▬';
  const emptyChar = '▭';
  return `${filledChar.repeat(filledBlocks)}${emptyChar.repeat(emptyBlocks)} **${percentage}%**`;
}

// ─── EKSPOR loadAntri agar bisa dipakai autocomplete di antri.js ───
module.exports = {
  name: 'interactionCreate',
  loadAntri,

  async execute(interaction) {

    // ── HANDLE AUTOCOMPLETE ──
    if (interaction.isAutocomplete()) {
      if (interaction.commandName !== 'antri') return;
      const antriCommand = interaction.client.commands?.get('antri');
      if (antriCommand?.autocomplete) {
        await antriCommand.autocomplete(interaction);
      }
      return;
    }

    if (!interaction.isChatInputCommand()) return;
    if (interaction.commandName !== 'antri') return;

    const subcommand = interaction.options.getSubcommand();

    // ─── CEK ROLE SELLER ───
    const isSeller = interaction.member.roles.cache.has(SELLER_ROLE_ID);
    if (!isSeller) {
      return interaction.reply({ content: '❌ Hanya **Seller** yang dapat menggunakan command ini.', ephemeral: true });
    }

    const queueChannel = await interaction.client.channels.fetch(ANTRI_CHANNEL_ID).catch(() => null);
    if (!queueChannel) {
      return interaction.reply({ content: '❌ Channel log antrian tidak ditemukan.', ephemeral: true });
    }

    // ─── SUB-COMMAND: BUAT ───
    if (subcommand === 'buat') {
      await interaction.deferReply({ ephemeral: true });

      const queue = loadAntri();
      const currentNumber = getNextId(queue);
      const product = interaction.options.getString('produk');
      const buyerTarget = interaction.options.getUser('buyer') || interaction.user;

      const queueData = {
        id: currentNumber,
        buyerId: buyerTarget.id,
        buyerTag: buyerTarget.tag || buyerTarget.username,
        productName: product,
        progress: 10,
        createdAt: new Date().toISOString(),
        messageId: null
      };

      const embedQueue = new EmbedBuilder()
        .setColor('#3498DB')
        .setTitle(`🛒 Antrian Pesanan #${currentNumber}`)
        .setDescription(
          `👤 **Pembeli:** <@${buyerTarget.id}>   |   🛒 **Produk:** \`${product}\`\n\n` +
          `📊 **Progress Kerja:**\n${renderProgressBar(10)}`
        )
        .setFooter({ text: `ID Antrian: #${currentNumber}` })
        .setTimestamp();

      const sentMessage = await queueChannel.send({
        content: `Progress Untuk <@${buyerTarget.id}>`,
        embeds: [embedQueue]
      });

      queueData.messageId = sentMessage.id;
      queue.push(queueData);
      saveAntri(queue);

      console.log(`[ANTRI] Antrian #${currentNumber} dibuat. Total antrian: ${queue.length}`);
      return interaction.editReply({ content: `✅ Antrian **#${currentNumber}** berhasil dibuat!\n📋 Gunakan \`/antri list\` untuk melihat semua antrian aktif.` });
    }

    // ─── SUB-COMMAND: LIST ───
    if (subcommand === 'list') {
      await interaction.deferReply({ ephemeral: true });

      const queue = loadAntri();

      if (queue.length === 0) {
        return interaction.editReply({ content: '📋 Tidak ada antrian yang sedang berjalan saat ini.' });
      }

      const embed = new EmbedBuilder()
        .setColor('#F39C12')
        .setTitle('📋 Daftar Antrian Aktif')
        .setDescription(`Total antrian berjalan: **${queue.length}**`)
        .setTimestamp();

      const displayed = queue.slice(0, 25);
      for (const item of displayed) {
        embed.addFields({
          name: `#${item.id} — ${item.productName}`,
          value: `👤 <@${item.buyerId}> | 📊 ${renderProgressBar(item.progress)}`,
          inline: false
        });
      }

      if (queue.length > 25) {
        embed.setFooter({ text: `... dan ${queue.length - 25} antrian lainnya.` });
      }

      return interaction.editReply({ embeds: [embed] });
    }

    // ─── SUB-COMMAND: UPDATE ───
    if (subcommand === 'update') {
      await interaction.deferReply({ ephemeral: true });

      const queueNumber = interaction.options.getInteger('nomor');
      const newProduct = interaction.options.getString('produk');
      const newProgress = interaction.options.getInteger('progress');

      const queue = loadAntri();

      // ── Validasi: cek apakah antrian ada di JSON ──
      if (queue.length === 0) {
        return interaction.editReply({ content: '📋 Belum ada antrian yang berjalan saat ini.' });
      }

      const queueIndex = queue.findIndex(q => q.id === queueNumber);
      if (queueIndex === -1) {
        const aktif = queue.map(q => `#${q.id}`).join(', ');
        return interaction.editReply({
          content: `❌ Antrian **#${queueNumber}** tidak ditemukan.\n📋 Antrian aktif: ${aktif}`
        });
      }

      const dataPesanan = queue[queueIndex];

      if (newProgress !== null && newProgress !== undefined) {
        if (!interaction.member.permissions.has(PermissionFlagsBits.ManageMessages)) {
          return interaction.editReply({ content: '❌ Anda tidak memiliki izin untuk memperbarui progress bar.' });
        }
        dataPesanan.progress = newProgress;
      }

      if (newProduct) {
        if (interaction.user.id !== dataPesanan.buyerId && !interaction.member.permissions.has(PermissionFlagsBits.ManageMessages)) {
          return interaction.editReply({ content: '❌ Anda tidak dapat mengubah produk antrian orang lain.' });
        }
        dataPesanan.productName = newProduct;
      }

      try {
        const targetMessage = await queueChannel.messages.fetch(dataPesanan.messageId);
        if (targetMessage) {
          const updatedEmbed = new EmbedBuilder()
            .setColor(dataPesanan.progress === 100 ? '#2ECC71' : '#3498DB')
            .setTitle(`🛒 Antrian Pesanan #${dataPesanan.id}`)
            .setDescription(
              `👤 **Pembeli:** <@${dataPesanan.buyerId}>   |   🛒 **Produk:** \`${dataPesanan.productName}\`\n\n` +
              `📊 **Progress Kerja:**\n${renderProgressBar(dataPesanan.progress)}`
            )
            .setFooter({ text: `ID Antrian: #${dataPesanan.id}` })
            .setTimestamp();

          await targetMessage.edit({
            content: `🔄 Update Progress: <@${dataPesanan.buyerId}>`,
            embeds: [updatedEmbed]
          });
        }
      } catch (err) {
        return interaction.editReply({ content: '❌ Gagal memperbarui pesan papan antrian.' });
      }

      queue[queueIndex] = dataPesanan;
      saveAntri(queue);

      console.log(`[ANTRI] Antrian #${queueNumber} diupdate. Progress: ${dataPesanan.progress}%`);
      return interaction.editReply({ content: `✅ Antrian **#${queueNumber}** berhasil diperbarui!` });
    }

    // ─── SUB-COMMAND: SELESAI ───
    if (subcommand === 'selesai') {
      await interaction.deferReply({ ephemeral: true });

      if (!interaction.member.permissions.has(PermissionFlagsBits.ManageMessages)) {
        return interaction.editReply({ content: '❌ Anda tidak memiliki izin untuk menyelesaikan antrian ini.' });
      }

      const queueNumber = interaction.options.getInteger('nomor');
      const queue = loadAntri();

      // ── Validasi: cek apakah antrian ada di JSON ──
      if (queue.length === 0) {
        return interaction.editReply({ content: '📋 Belum ada antrian yang berjalan saat ini.' });
      }

      const queueIndex = queue.findIndex(q => q.id === queueNumber);
      if (queueIndex === -1) {
        const aktif = queue.map(q => `#${q.id}`).join(', ');
        return interaction.editReply({
          content: `❌ Antrian **#${queueNumber}** tidak ditemukan.\n📋 Antrian aktif: ${aktif}`
        });
      }

      const dataPesanan = queue[queueIndex];

      try {
        const targetMessage = await queueChannel.messages.fetch(dataPesanan.messageId);
        if (targetMessage) {
          const finishedEmbed = new EmbedBuilder()
            .setColor('#2ECC71')
            .setTitle(`✅ Antrian Pesanan #${dataPesanan.id} — SELESAI`)
            .setDescription(
              `👤 **Pembeli:** <@${dataPesanan.buyerId}>   |   🛒 **Produk:** \`${dataPesanan.productName}\`\n\n` +
              `📊 **Status Akhir:**\n${renderProgressBar(100)}`
            )
            .setFooter({ text: `ID Antrian: #${dataPesanan.id} • Diselesaikan` })
            .setTimestamp();

          await targetMessage.edit({
            content: `🎉 Selesai: <@${dataPesanan.buyerId}> Pesanan Anda siap!`,
            embeds: [finishedEmbed]
          });

          const buyerUser = await interaction.client.users.fetch(dataPesanan.buyerId).catch(() => null);
          if (buyerUser) {
            await buyerUser.send({
              content: `🎉 Halo! <@${dataPesanan.buyerId}>\nProses pesanan Anda **#${dataPesanan.id}** produk **${dataPesanan.productName}** telah **Selesai 100%**.\nSilakan cek kembali **Tiket** atau Hubungi admin untuk penyerahan produk!.\nTerimakasih sudah menggunakan Layanan kami.\n\n> AzesZ Page`
            }).catch(() => null);
          }
        }
      } catch (err) {
        console.error('[ANTRI] Error saat selesaikan antrian:', err.message);
      }

      // ── Hapus dari JSON & simpan ──
      queue.splice(queueIndex, 1);
      saveAntri(queue);

      console.log(`[ANTRI] Antrian #${queueNumber} selesai & dihapus. Sisa antrian: ${queue.length}`);
      return interaction.editReply({ content: `✅ Sukses! Antrian **#${queueNumber}** ditandai selesai dan dihapus dari daftar.\n📋 Sisa antrian aktif: **${queue.length}**` });
    }
  }
};
