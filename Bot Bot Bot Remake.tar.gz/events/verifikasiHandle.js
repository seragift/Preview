const {
  EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, AttachmentBuilder
} = require('discord.js');
const { VERIFY_ROLE_ID, VERIFY_LOG_CHANNEL_ID } = require('../config.json');
const { generateCaptchaCode, renderCaptchaImage } = require('../utils/captchaImage.js');

// ── Konfigurasi ──
const CODE_LENGTH = 4;          // jumlah digit captcha
const SESSION_DURATION_MS = 5 * 60 * 1000; // 5 menit
const MAX_ATTEMPTS = 3;

// Penyimpanan sesi captcha aktif per user: userId -> sessionObj
const sessions = new Map();


function buildCaptchaEmbed(session, statusText = null) {
  const filled = session.input.split('');
  const slots = Array.from({ length: CODE_LENGTH }, (_, i) => filled[i] ?? '_').join('  ');

  const remainingMs = session.expiresAt - Date.now();
  const remainingMin = Math.max(0, Math.ceil(remainingMs / 60000));

  const embed = new EmbedBuilder()
    .setColor(statusText?.type === 'error' ? '#FF0000' : '#2B2D31')
    .setTitle('Verify Untuk Akeses!')
    .setDescription(
      'Silakan masukkan kode berikut ini.\n' +
      `Selesaikan **Captcha** dengan menekan yang tertera pada gambar.\n\n` +
      `**Input:** \`${slots}\`\n` +
      `• Berlaku ${remainingMin} menit lagi  •  Maks ${MAX_ATTEMPTS} percobaan  •  Sisa: **${session.attemptsLeft}x**`
    )
    .setImage('attachment://captcha.png')
    .setFooter({ text: 'Tekan angka pada tombol di bawah' })
    .setTimestamp();

  if (statusText) {
    embed.addFields({ name: '\u200B', value: statusText.message });
  }

  return embed;
}


function buildCaptchaComponents(disabled = false) {
  const numRow1 = new ActionRowBuilder().addComponents(
    ['1', '2', '3', '4', '5'].map(n =>
      new ButtonBuilder().setCustomId(`cap_digit_${n}`).setLabel(n).setStyle(ButtonStyle.Secondary).setDisabled(disabled)
    )
  );
  const numRow2 = new ActionRowBuilder().addComponents(
    ['6', '7', '8', '9', '0'].map(n =>
      new ButtonBuilder().setCustomId(`cap_digit_${n}`).setLabel(n).setStyle(ButtonStyle.Secondary).setDisabled(disabled)
    )
  );
  const controlRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('cap_clear').setLabel('Hapus').setEmoji('🗑️').setStyle(ButtonStyle.Danger).setDisabled(disabled),
    new ButtonBuilder().setCustomId('cap_refresh').setLabel('Refresh').setEmoji('🔄').setStyle(ButtonStyle.Secondary).setDisabled(disabled),
    new ButtonBuilder().setCustomId('cap_submit').setLabel('Submit').setEmoji('✅').setStyle(ButtonStyle.Success).setDisabled(disabled)
  );
  return [numRow1, numRow2, controlRow];
}

/**
 * Buat sesi captcha baru untuk seorang user dan kembalikan payload siap kirim.
 */
function createSession(userId) {
  const code = generateCaptchaCode(CODE_LENGTH);
  const imageBuffer = renderCaptchaImage(code);

  const session = {
    code,
    input: '',
    attemptsLeft: MAX_ATTEMPTS,
    expiresAt: Date.now() + SESSION_DURATION_MS,
    timeout: null
  };
  sessions.set(userId, session);

  // Auto-bersihkan sesi setelah expired agar tidak menumpuk di memori
  session.timeout = setTimeout(() => {
    const current = sessions.get(userId);
    if (current === session) sessions.delete(userId);
  }, SESSION_DURATION_MS + 5000);

  const attachment = new AttachmentBuilder(imageBuffer, { name: 'captcha.png' });
  const embed = buildCaptchaEmbed(session);
  const components = buildCaptchaComponents();

  return { embed, components, attachment };
}

function clearSession(userId) {
  const session = sessions.get(userId);
  if (session?.timeout) clearTimeout(session.timeout);
  sessions.delete(userId);
}

async function sendVerifyLog(interaction, member) {
  try {
    const logChannel = await interaction.client.channels.fetch(VERIFY_LOG_CHANNEL_ID).catch(() => null);
    if (!logChannel) return;

    const waktuWIB = new Intl.DateTimeFormat('id-ID', {
      timeZone: 'Asia/Jakarta',
      weekday: 'long', year: 'numeric', month: 'long', day: 'numeric',
      hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false
    }).format(new Date()) + ' WIB';

    const embedLog = new EmbedBuilder()
      .setColor('#2B2D31')
      .setTitle('Member Verified')
      .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
      .setDescription(
        `👤 **Akun Pengguna:** <@${member.id}>\n` +
        `🆔 **ID Pengguna:** \`${member.id}\`\n` +
        `🕒 **Waktu (WIB):** \`${waktuWIB}\`\n\n` +
        `📝 *Keterangan: User berhasil menyelesaikan verifikasi.*`
      )
      .setFooter({ text: 'Logs Verify', iconURL: interaction.guild.iconURL({ dynamic: true }) })
      .setTimestamp();

    await logChannel.send({ embeds: [embedLog] });
  } catch (err) {
    console.error('Gagal mengirim log verifikasi:', err);
  }
}

module.exports = {
  name: 'interactionCreate',
  async execute(interaction) {
    if (!interaction.isButton()) return;

    const userId = interaction.user.id;
    const member = interaction.member;

    // ─── STAGE 1: KLIK "MULAI VERIFIKASI" → BUKA SESI CAPTCHA PRIBADI (EPHEMERAL) ───
    if (interaction.customId === 'start_verify') {
      if (member.roles.cache.has(VERIFY_ROLE_ID)) {
        return interaction.reply({ content: '✅ Anda sudah terverifikasi di server ini!', ephemeral: true });
      }

      const { embed, components, attachment } = createSession(userId);
      return interaction.reply({
        embeds: [embed],
        components,
        files: [attachment],
        ephemeral: true
      });
    }

    // ─── STAGE 2: SEMUA TOMBOL DI DALAM PANEL CAPTCHA (digit / hapus / refresh / submit) ───
    const isCaptchaButton =
      interaction.customId.startsWith('cap_digit_') ||
      ['cap_clear', 'cap_refresh', 'cap_submit'].includes(interaction.customId);

    if (!isCaptchaButton) return;

    const session = sessions.get(userId);

    if (!session) {
      return interaction.reply({
        content: '⌛ Sesi captcha Anda tidak ditemukan atau sudah kedaluwarsa. Silakan klik **Mulai Verifikasi** lagi.',
        ephemeral: true
      });
    }

    if (Date.now() > session.expiresAt) {
      clearSession(userId);
      const expiredEmbed = buildCaptchaEmbed(session, { type: 'error', message: '⌛ **Waktu habis.** Silakan mulai ulang verifikasi.' });
      return interaction.update({ embeds: [expiredEmbed], components: buildCaptchaComponents(true), files: [] });
    }

    // ── Tombol angka: tambahkan digit ke input, lalu langsung edit embed ──
    if (interaction.customId.startsWith('cap_digit_')) {
      const digit = interaction.customId.replace('cap_digit_', '');

      if (session.input.length >= CODE_LENGTH) {
        // Input sudah penuh, abaikan penekanan tambahan
        return interaction.deferUpdate();
      }

      session.input += digit;
      const embed = buildCaptchaEmbed(session);
      return interaction.update({ embeds: [embed] }); // gambar & tombol tidak perlu dikirim ulang
    }

    // ── Tombol Hapus: hapus 1 digit terakhir ──
    if (interaction.customId === 'cap_clear') {
      session.input = session.input.slice(0, -1);
      const embed = buildCaptchaEmbed(session);
      return interaction.update({ embeds: [embed] });
    }

    // ── Tombol Refresh: buat ulang kode captcha + gambar baru, reset input ──
    if (interaction.customId === 'cap_refresh') {
      const newCode = generateCaptchaCode(CODE_LENGTH);
      const imageBuffer = renderCaptchaImage(newCode);
      session.code = newCode;
      session.input = '';

      const attachment = new AttachmentBuilder(imageBuffer, { name: 'captcha.png' });
      const embed = buildCaptchaEmbed(session, { type: 'info', message: '🔄 Captcha baru telah dibuat.' });
      return interaction.update({ embeds: [embed], files: [attachment] });
    }

    // ── Tombol Submit: validasi kode ──
    if (interaction.customId === 'cap_submit') {
      if (session.input.length < CODE_LENGTH) {
        const embed = buildCaptchaEmbed(session, { type: 'error', message: `⚠️ Lengkapi semua ${CODE_LENGTH} digit terlebih dahulu.` });
        return interaction.update({ embeds: [embed] });
      }

      if (session.input !== session.code) {
        session.attemptsLeft -= 1;
        session.input = '';

        if (session.attemptsLeft <= 0) {
          clearSession(userId);
          const failEmbed = buildCaptchaEmbed(
            { ...session, attemptsLeft: 0 },
            { type: 'error', message: '❌ **Verifikasi gagal.** Percobaan habis. Klik **Mulai Verifikasi** untuk mencoba lagi.' }
          );
          return interaction.update({ embeds: [failEmbed], components: buildCaptchaComponents(true) });
        }

        // Kode salah, buat ulang captcha agar tidak bisa ditebak ulang dengan kode lama
        const newCode = generateCaptchaCode(CODE_LENGTH);
        const imageBuffer = renderCaptchaImage(newCode);
        session.code = newCode;

        const attachment = new AttachmentBuilder(imageBuffer, { name: 'captcha.png' });
        const embed = buildCaptchaEmbed(session, { type: 'error', message: '❌ Kode salah. Captcha diperbarui, silakan coba lagi.' });
        return interaction.update({ embeds: [embed], files: [attachment] });
      }

      // ── Kode benar ──
      clearSession(userId);

      const targetRole = interaction.guild.roles.cache.get(VERIFY_ROLE_ID);
      if (targetRole) {
        await member.roles.add(targetRole).catch(() => null);
      }

      const successEmbed = new EmbedBuilder()
        .setColor('#2B2D31')
        .setTitle('🎉 Verifikasi Berhasil')
        .setDescription('Akses server Anda telah dibuka seutuhnya. Selamat bergabung dan selamat bersenang-senang! ✨')
        .setTimestamp();

      await interaction.update({ embeds: [successEmbed], components: [], files: [] });

      await sendVerifyLog(interaction, member);

      try {
        await member.send({
          content: `👋 Selamat bergabung di **${interaction.guild.name}**!\nProses verifikasi Anda telah disetujui seutuhnya. Selamat bersenang-senang! ✨`
        });
      } catch {
        console.log(`Gagal mengirim DM ke ${member.user.tag} (DM tertutup).`);
      }
    }
  }
};
