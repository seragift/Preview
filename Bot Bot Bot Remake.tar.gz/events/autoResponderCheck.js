const fs = require('fs');
const path = require('path');

module.exports = {
  name: 'messageCreate', 
  async execute(message, client) { 
    // 1. Abaikan pesan bot sendiri & obrolan privat DM[span_1](start_span)[span_1](end_span)
    if (message.author.bot || !message.guild) return; 

    // Cari file responderData.json di folder utama (root project)
    const dbPath = path.join(process.cwd(), 'responderData.json');

    // JIKA MAU CEK DI TERMINAL: Hapus tanda // di bawah ini untuk melihat apakah event berjalan
    // console.log(`[LOG DEBUG] Ada pesan masuk: "${message.content}" di channel: ${message.channel.name}`);

    if (!fs.existsSync(dbPath)) {
      // console.log('❌ [LOG DEBUG] File responderData.json tidak ditemukan di root folder!');
      return;
    }

    try {
      const db = JSON.parse(fs.readFileSync(dbPath, 'utf8'));
      const contentLower = message.content.toLowerCase();

      // Periksa setiap kata kunci pemicu yang tersimpan
      for (const trigger in db) {
        if (contentLower.includes(trigger.toLowerCase().trim())) {
          const balasanPesan = db[trigger];
          
          // Kirim balasan dengan sistem Reply/Tag pesan user
          return await message.reply({
            content: balasanPesan,
            allowedMentions: { repliedUser: true }
          });
        }
      }
    } catch (error) {
      console.error('❌ [LOG DEBUG] Gagal memproses data auto responder:', error);
    }
  }
};
