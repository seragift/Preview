const { ActivityType } = require('discord.js');

module.exports = {
  name: 'ready',
  once: true,

  async execute(client) {
    console.log(`✅ [Ready] Bot ${client.user.tag} berhasil online!`);

    // ─── DATA STATS YANG AKAN DIROTASI ───
    // Setiap 15 detik tampilan activity berganti otomatis
    const getActivities = () => {
      const totalMembers = client.guilds.cache.reduce((acc, g) => acc + g.memberCount, 0);
      const totalServers = client.guilds.cache.size;
      const totalCommands = client.commands?.size ?? 0;

      return [
        {
          // Tampilan 1: Jumlah member
          name: `NanoSpray | ${totalMembers.toLocaleString('id-ID')} Members | /help`,
          type: ActivityType.Watching,
          status: 'online'
        }
      ];
    };

    // ─── FUNGSI SET ACTIVITY ───
    let index = 0;

    function rotatePresence() {
      const activities = getActivities(); // refresh stats setiap rotasi
      const activity = activities[index % activities.length];

      client.user.setPresence({
        activities: [{
          name: activity.name,
          type: activity.type
        }],
        status: activity.status
      });

      console.log(`[Presence] ➜ ${activity.name}`);
      index++;
    }

    // Langsung set saat bot ready
    rotatePresence();

    // Rotasi setiap 15 detik
    setInterval(rotatePresence, 150000_000);
  }
};
