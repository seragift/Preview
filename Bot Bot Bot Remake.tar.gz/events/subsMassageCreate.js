const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { REQ_SUBSCRIBE_CHANNEL_ID, SUBSCRIBE_LOG_CHANNEL_ID, SUBSCRIBE_ROLE_ID } = require('../config.json');

module.exports = {
  name: 'messageCreate',
  async execute(message) {
    if (message.author.bot) return;
    if (message.channel.id !== REQ_SUBSCRIBE_CHANNEL_ID) return;
    if (!message.attachments.size) return;

    const member = message.member;
    if (!member) return;

    // Jika user sudah memiliki role subscriber
    if (member.roles.cache.has(SUBSCRIBE_ROLE_ID)) {
      return message.reply('✅ Kamu sudah terdaftar sebagai subscriber toko kami.')
        .then(msg => setTimeout(() => msg.delete().catch(() => {}), 5000));
    }

    const attachment = message.attachments.first();
    const logChannel = message.guild.channels.cache.get(SUBSCRIBE_LOG_CHANNEL_ID);

    if (!logChannel) {
      return message.reply('❌ Sistem error: Channel log subscriber tidak ditemukan! Hubungi admin.').catch(() => null);
    }

    // Berikan respons tenang di channel request agar pembeli tahu berkasnya diajukan
    await message.reply('⏳ Bukti screenshot kamu telah diajukan! Mohon tunggu Admin memeriksa screenshot kamu.').catch(() => null);

    // KARTU VERIFIKASI UNTUK ADMIN (DIKIRIM KE CHANNEL LOGS)
    const embedVerifAdmin = new EmbedBuilder()
      .setColor('#3498DB')
      .setAuthor({ name: 'AzesZ Page • REQUEST VERIFICATION', iconURL: message.guild.iconURL({ dynamic: true }) })
      .setTitle('REQUEST FOLLOWERS BARU')
      .setDescription(`User <@${member.id}> telah mengirimkan bukti screenshot untuk diklaim. Silakan periksa gambar di bawah dan tentukan keputusan.`)
      .addFields(
        { name: '> 👤 Pemohon', value: `<@${member.id}> (\`${member.id}\`)`, inline: true },
        { name: '> 🕒 Waktu Pada', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
      )
      .setImage(attachment.url)
      .setTimestamp()
      .setFooter({ text: 'AzesZ Page • Manual Verification System' });

    // Tombol Aksi Admin (Membawa muatan ID pemohon dan ID pesan request asal)
    const rowAction = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`sub_valid_${member.id}_${message.id}`).setLabel('Valid (Terima)').setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId(`sub_invalid_${member.id}_${message.id}`).setLabel('Invalid (Tolak)').setStyle(ButtonStyle.Danger)
    );

    await logChannel.send({ embeds: [embedVerifAdmin], components: [rowAction] });
  }
};


