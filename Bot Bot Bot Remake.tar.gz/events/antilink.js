const { 
  CHAT_PUBLIC_CHANNEL_ID, 
  OWNER_ID,
  ADMIN_LOG_CHANNEL_ID 
} = require('../config.json');

const { EmbedBuilder } = require('discord.js');

const violations = new Map();

const linkRegex = /(https?:\/\/|www\.|discord\.gg|discord\.com\/invite)/i;
const TIMEOUT_DURATION = 5 * 24 * 60 * 60 * 1000; // 5 hari

module.exports = {
  name: 'messageCreate',
  async execute(message) {

    if (message.author.bot) return;
    if (message.channel.id !== CHAT_PUBLIC_CHANNEL_ID) return;
    if (!linkRegex.test(message.content)) return;

    const member = message.member;
    if (!member) return;

    if (member.permissions.has('Administrator')) return;

    const adminLogChannel = message.guild.channels.cache.get(ADMIN_LOG_CHANNEL_ID);

    await message.delete().catch(() => null);

    const userId = member.id;
    const count = violations.get(userId) || 0;
    const newCount = count + 1;
    violations.set(userId, newCount);

    // ⚠️ Warning Message
    const warningMsg = await message.channel.send(
      `⚠️ <@${userId}> dilarang kirim link di sini, kan sudah di sediakan Chanel nya oleh <@${OWNER_ID}>.\n` +
      `Pelanggaran: ${newCount}/3`
    );

    setTimeout(() => {
      warningMsg.delete().catch(() => null);
    }, 5000);

    // 📜 Log Warning
    if (adminLogChannel) {
      const warnEmbed = new EmbedBuilder()
        .setColor('#2B2D31')
        .setTitle('⚠️ ANTI LINK WARNING')
        .addFields(
          { name: '👤 User', value: `<@${userId}>`, inline: true },
          { name: '📊 Pelanggaran', value: `${newCount}/3`, inline: true },
          { name: '📍 Channel', value: `<#${CHAT_PUBLIC_CHANNEL_ID}>`, inline: true },
          { name: '🔗 Pesan', value: `||${message.content}||`, inline: false }
        )
        .setFooter({ text: 'NanoSpray Anti Link' })
        .setTimestamp();

      await adminLogChannel.send({ embeds: [warnEmbed] });
    }

    // 🚫 Timeout jika 3x
    if (newCount >= 3) {

      await member.timeout(TIMEOUT_DURATION, 'Spam link 3x').catch(() => null);

      await message.channel.send(
        `🚫 <@${userId}> telah di timeout 5 hari karena mengirim link sebanyak 3x.`
      );

      if (adminLogChannel) {
        const timeoutEmbed = new EmbedBuilder()
          .setColor('#ED4245')
          .setTitle('🚫 USER TIMEOUT (5 HARI)')
          .addFields(
            { name: '👤 User', value: `<@${userId}>`, inline: true },
            { name: '⏳ Durasi', value: '5 Hari', inline: true },
            { name: '📍 Channel', value: `<#${CHAT_PUBLIC_CHANNEL_ID}>`, inline: true }
          )
          .setFooter({ text: 'NanoSpray Anti Link' })
          .setTimestamp();

        await adminLogChannel.send({ embeds: [timeoutEmbed] });
      }

      violations.delete(userId);
    }
  }
};