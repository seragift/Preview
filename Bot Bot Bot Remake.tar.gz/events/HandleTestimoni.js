const { EmbedBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { RATING_CHANNEL_ID, TESTIMONI_CHANNEL_ID } = require('../config.json');

module.exports = {
  name: 'interactionCreate',
  async execute(interaction) {
    if (interaction.isButton() && interaction.customId.startsWith('tgm_')) {
      const [, skorStar, adminId, totalHarga, msgTestiId, ...namaProdukArray] = interaction.customId.split('_');
      const namaProduk = namaProdukArray.join('_');

      const modal = new ModalBuilder()
        .setCustomId(`mdl_${skorStar}_${adminId}_${totalHarga}_${msgTestiId}_${namaProduk}`)
        .setTitle('📝 Isi Ulasan Anda!');

      const inputReview = new TextInputBuilder()
        .setCustomId('txt_review')
        .setLabel(`Berikan ulasan Anda (${skorStar} Bintang)`)
        .setStyle(TextInputStyle.Paragraph)
        .setPlaceholder('Tulis kepuasan belanja Anda di AzesZ Page...')
        .setRequired(true)
        .setMaxLength(500);

      modal.addComponents(new ActionRowBuilder().addComponents(inputReview));
      return interaction.showModal(modal);
    }

    if (interaction.isModalSubmit() && interaction.customId.startsWith('mdl_')) {
      await interaction.deferReply();

      const [, skorStar, adminId, totalHarga, msgTestiId, ...namaProdukArray] = interaction.customId.split('_');
      const namaProduk = namaProdukArray.join('_');
      const ulasanUser = interaction.fields.getTextInputValue('txt_review');

      const ratingAngka = parseInt(skorStar);
      const hargaAngka = parseFloat(totalHarga);
      const visualBintang = '⭐'.repeat(ratingAngka) + '☆'.repeat(5 - ratingAngka);

      const formatRupiah = new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(hargaAngka);

      try {
        const channelTesti = await interaction.client.channels.fetch(TESTIMONI_CHANNEL_ID).catch(() => null);
        if (channelTesti) {
          const targetMessage = await channelTesti.messages.fetch(msgTestiId).catch(() => null);
          if (targetMessage && targetMessage.embeds[0]) {
            const oldEmbed = targetMessage.embeds[0];
            const updatedEmbed = EmbedBuilder.from(oldEmbed)
              .setColor('#2B2D31')
              .setDescription(
                `**DETAIL TRANSAKSI:**\n` +
                `> 👤 **Pembeli:** <@${interaction.user.id}>\n` +
                `> 🛒 **Penjual:** <@${adminId}>\n` +
                `> 📦 **Produk:** ${namaProduk}\n` +
                `> 💰 **Total:** ${formatRupiah}\n\n` +
                `⭐ **Rating:** ${visualBintang} (${ratingAngka}/5)\n` +
                `**Ulasan Buyer:**\n\`\`\`${ulasanUser}\`\`\`\n\n` +
                 `**🔗 Bukti Pembayaran**`
              );

            await targetMessage.edit({ embeds: [updatedEmbed] }).catch(() => null);
          }
        }

        const channelRating = await interaction.client.channels.fetch(RATING_CHANNEL_ID).catch(() => null);
        if (channelRating) {
          const embedLogRating = new EmbedBuilder()
            .setColor('#2B2D31')
            .setTitle('New Feedback Received')
            .setDescription(
              `Ulasan baru telah diterima oleh sistem otomatis!\n\n` +
              `**Data Penilaian:**\n` +
              `> 👤 **Customer:** <@${interaction.user.id}>\n` +
              `> 🛒 **Seller:** <@${adminId}>\n` +
              `> 📦 **Produk:** \`${namaProduk}\`\n` +
              `> 🌟 **Rating:** ${visualBintang} (\`${ratingAngka}/5\`)\n\n` +
              `**Ulasan Buyer:**\n` +
              `\`\`\`${ulasanUser}\`\`\``
            )
            .setThumbnail(interaction.user.displayAvatarURL({ dynamic: true }))
            .setTimestamp()
            .setFooter({ text: 'AzesZ Page • Ratings Record' });

          await channelRating.send({ embeds: [embedLogRating] });
        }

        const disabledRow = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId('done_dis').setLabel('Rating Berhasil Diberikan').setStyle(ButtonStyle.Success).setDisabled(true)
        );
        await interaction.message.edit({ components: [disabledRow] }).catch(() => null);

        await interaction.editReply({
          content: `✅ **Terima kasih!** Rating berhasil direkam, ulasan testimoni di server sudah di update.`
        });

      } catch (err) {
        console.error('Error pada Testi Rating Automator:', err);
        await interaction.editReply({ content: '❌ Terjadi kegagalan sistem saat memproses rating Anda.' });
      }
    }
  }
};