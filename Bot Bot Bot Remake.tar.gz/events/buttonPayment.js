const { EmbedBuilder } = require('discord.js');

//ATUR NOMOR
const AKUN_GOPAY = "isi nomer";
const AKUN_DANA  = "isi nomer";
const LINK_QRIS   = "Gamabr qris";

module.exports = {
  name: 'interactionCreate',
  async execute(interaction) {
    if (!interaction.isButton()) return;
    if (!interaction.customId.startsWith('pay_')) return;

    // Pecah muatan data dari custom ID tombol
    const [, metode, pembeliId, totalHarga] = interaction.customId.split('_');

    // PROTEKSI: Cuma user pembeli yang di-tag yang bisa menekan tombol ini!
    if (interaction.user.id !== pembeliId) {
      return interaction.reply({
        content: '❌ Maaf, invoice tagihan ini bukan ditujukan untuk Anda.',
        ephemeral: true
      });
    }

    // Tahan interaksi berupa ephemeral (hanya bisa dilihat oleh pembeli itu sendiri secara privat)
    await interaction.deferReply({ ephemeral: true });

    const hargaAngka = parseFloat(totalHarga);
    const formatRupiah = new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(hargaAngka);

    const embedInstruksi = new EmbedBuilder()
      .setTimestamp()
      .setFooter({ text: 'Harap kirim bukti transfer' });

    // PILIHAN LOGIKA STRUKTUR METODE PEMBAYARAN
    if (metode === 'gopay') {
      embedInstruksi
        .setColor('#2B2D31')
        .setTitle('INSTRUKSI PEMBAYARAN GOPAY')
        .setDescription(
          `Silakan lakukan transfer ke akun **GOPAY** resmi kami dengan detail berikut:\n\n` +
          `📌 **Nomor GoPay:** \`${AKUN_GOPAY}\`\n` +
          `💰 **Jumlah Transfer:** **${formatRupiah}**\n\n` +
          `⚠️ **PENTING:** Pastikan nominal transfer sesuai angka di atas. Jika sudah transfer, segera kirimkan bukti screenshot ke admin/seller yang menghandle Anda!`
        );
    } 
    
    else if (metode === 'dana') {
      embedInstruksi
        .setColor('#2B2D31')
        .setTitle('INSTRUKSI PEMBAYARAN DANA')
        .setDescription(
          `Silakan lakukan transfer ke akun **DANA** resmi kami dengan detail berikut:\n\n` +
          `📌 **Nomor DANA:** \`${AKUN_DANA}\`\n` +
          `💰 **Jumlah Transfer:** **${formatRupiah}**\n\n` +
          `⚠️ **PENTING:** Pastikan nominal transfer sesuai angka di atas. Jika sudah transfer, segera kirimkan bukti screenshot ke admin/seller yang menghandle Anda!`
        );
    } 
    
    else if (metode === 'qris') {
      embedInstruksi
        .setColor('#2B2D31')
        .setTitle('INSTRUKSI PEMBAYARAN QRIS')
        .setDescription(
          `Silakan scan kode **QRIS** di bawah ini menggunakan aplikasi Bank Anda atau E-Wallet (Gopay/Dana/OVO/LinkAja):\n\n` +
          `💰 **Jumlah Nominal:** **${formatRupiah}**\n\n` +
          `*Silakan simpan/scan barcode di bawah ini:*`
        )
        .setImage(LINK_QRIS);
    }

    // Kirim instruksi pembayaran aman yang hanya bisa dibaca oleh pembeli tersebut (ephemeral)
    await interaction.editReply({ embeds: [embedInstruksi] });
  }
};


