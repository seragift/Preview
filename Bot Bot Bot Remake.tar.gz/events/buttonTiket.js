const {
  EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle,
  PermissionFlagsBits, ModalBuilder, TextInputBuilder, TextInputStyle,
} = require('discord.js');
const { TICKET_CATEGORY_ID, TICKET_LOG_CHANNEL_ID, SELLER_ROLE_ID } = require('../config.json');

const activeSessions = new Map();
const clickTracker   = new Map();
const sellerCooldown = new Map();

const KATEGORI = {
  ORDER:   { emoji: '<a:keranjang:1534897798774788216>', label: 'Order',       placeholder: 'Contoh: Mau order Layanan Premium Paket A, jumlah 1 pcs.' },
  TANYA:   { emoji: '<a:suspray:1534898079399022652>', label: 'Ask/Reward',   placeholder: 'Contoh: Ingin tanya cara integrasi bot ke server saya.' },
  GARANSI: { emoji: '<a:sield:1534897921084887040>', label: 'Claim Garansi',  placeholder: 'Contoh: ID Invoice #123, produk tidak bisa digunakan sejak kemarin.' },
};

function embedTiket(jenis, userId, jawaban) {
  const k = KATEGORI[jenis] ?? { emoji: '🎟️', label: jenis };
  return new EmbedBuilder()
    .setColor(0x2B2D31)
    .setTitle(`${k.emoji}  ${k.label}`)
    .setDescription(
      `Halo <@${userId}>, tiket kamu sudah dibuat.\n` +
      `<@&${SELLER_ROLE_ID}> akan segera menghubungimu.\n\n` +
      `**Tujuan**\n\`\`\`${jawaban}\`\`\``
    )
    .addFields(
      { name: '👤 Opened by',  value: `<@${userId}>`,    inline: true },
      { name: '📁 Category',   value: `\`${k.label}\``,  inline: true },
      { name: '📌 Status',     value: '`Waiting for Staff...`', inline: true },
    )
    .setFooter({ text: 'NanoSpray • Tiket Created' })
    .setTimestamp();
}

function rowAksiTiket(userId) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`t_call_${userId}`).setLabel('Panggil Seller').setEmoji('📢').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('t_claim').setLabel('Claim Tiket').setEmoji('✋').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`t_closeinit_${userId}`).setLabel('Close Ticket').setEmoji('🔐').setStyle(ButtonStyle.Danger),
  );
}

// ════════════════════════════════════════════════════════════════════════════
module.exports = {
  name: 'interactionCreate',
  async execute(interaction) {

    // ── 1. Tombol panel → konfirmasi ─────────────────────────────────────
    if (interaction.isButton() && interaction.customId.startsWith('t_init_')) {
      const jenis = interaction.customId.split('_')[2].toUpperCase();


      activeSessions.set(interaction.user.id, jenis);
      clickTracker.set(interaction.user.id, 0);

      const k = KATEGORI[jenis] ?? { emoji: '🎟️', label: jenis };
      return interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(0x2B2D31)
            .setTitle('Konfirmasi Ticket')
            .setDescription(`Kamu akan membuat tiket dengan kategori **${k.emoji} ${k.label}**.\nApakah Lanjutkan?`),
        ],
        components: [
          new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId(`t_confirm_${jenis}`).setLabel('Lanjutkan').setStyle(ButtonStyle.Success),
            new ButtonBuilder().setCustomId('t_cancel').setLabel('Batalkan').setStyle(ButtonStyle.Danger),
          ),
        ],
        ephemeral: true,
      });
    }

    // ── 2. Cancel ─────────────────────────────────────────────────────────
    if (interaction.isButton() && interaction.customId === 't_cancel') {
      activeSessions.delete(interaction.user.id);
      clickTracker.delete(interaction.user.id);
      return interaction.update({ content: '❌ Pembuatan tiket Dibatalkan.', embeds: [], components: [] }).catch(() => null);
    }

    // ── 3. Konfirmasi → modal ─────────────────────────────────────────────
    if (interaction.isButton() && interaction.customId.startsWith('t_confirm_')) {
      const jenis = interaction.customId.split('_')[2];
      const k     = KATEGORI[jenis] ?? { label: jenis, placeholder: 'Jelaskan kebutuhanmu.' };

      return interaction.showModal(
        new ModalBuilder()
          .setCustomId(`t_form_${jenis}`)
          .setTitle(`📋 Kategori — ${k.label}`)
          .addComponents(
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('user_kebutuhan')
                .setLabel('Describe your request')
                .setPlaceholder(k.placeholder)
                .setStyle(TextInputStyle.Paragraph)
                .setRequired(true),
            ),
          ),
      );
    }

    // ── 4. Submit form → buat channel tiket ──────────────────────────────
    if (interaction.isModalSubmit() && interaction.customId.startsWith('t_form_')) {
      await interaction.update({ content: '⏳ Membuat channel tiket...', embeds: [], components: [] }).catch(() => null);

      const jenis       = interaction.customId.split('_')[2];
      const jawaban     = interaction.fields.getTextInputValue('user_kebutuhan');
      const username    = interaction.user.username.toLowerCase().replace(/[^a-z0-9]/g, '');
      const channelName = `${jenis.toLowerCase()}-${username}`;

      const existing = interaction.guild.channels.cache.find(c => c.name === channelName && c.parentId === TICKET_CATEGORY_ID);
      if (existing) {
        activeSessions.delete(interaction.user.id);
        clickTracker.delete(interaction.user.id);
        return interaction.editReply({ content: `⚠️ Kamu sudah punya tiket aktif di <#${existing.id}>.` });
      }

      const ch = await interaction.guild.channels.create({
        name: channelName,
        parent: TICKET_CATEGORY_ID,
        permissionOverwrites: [
          { id: interaction.guild.id, deny:  [PermissionFlagsBits.ViewChannel] },
          { id: interaction.user.id,  allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] },
          { id: SELLER_ROLE_ID,       allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] },
        ],
      });

      await ch.send({
        content: `<@${interaction.user.id}> <@&${SELLER_ROLE_ID}>`,
        embeds:  [embedTiket(jenis, interaction.user.id, jawaban)],
        components: [rowAksiTiket(interaction.user.id)],
      });

      activeSessions.delete(interaction.user.id);
      clickTracker.delete(interaction.user.id);
      return interaction.editReply({ content: `✅ Ticket created! Menuju ke <#${ch.id}>` });
    }

    // ── 5. Ping Seller ────────────────────────────────────────────────────
    if (interaction.isButton() && interaction.customId.startsWith('t_call_')) {
      const now      = Date.now();
      const cooldown = sellerCooldown.get(interaction.user.id);
      if (cooldown && now - cooldown < 60_000) {
        const sisa = Math.ceil((60_000 - (now - cooldown)) / 1000);
        return interaction.reply({ content: `⏱️ Cooldown aktif! Coba lagi dalam \`${sisa}s\`.`, ephemeral: true });
      }
      sellerCooldown.set(interaction.user.id, now);
      return interaction.reply({ content: `📣 <@&${SELLER_ROLE_ID}> — dipanggil oleh <@${interaction.user.id}>!` });
    }

    // ── 6. Take Over (Claim) ──────────────────────────────────────────────
    if (interaction.isButton() && interaction.customId === 't_claim') {
      if (!interaction.member.roles.cache.has(SELLER_ROLE_ID) && !interaction.member.permissions.has('Administrator')) {
        return interaction.reply({ content: '⛔ Hanya Staff/Seller yang dapat mengambil tiket ini.', ephemeral: true });
      }

      const updatedEmbed = EmbedBuilder.from(interaction.message.embeds[0])
        .spliceFields(2, 1, { name: '📌 Status', value: `Handled by <@${interaction.user.id}>`, inline: true });

      const updatedRow = ActionRowBuilder.from(interaction.message.components[0]);
      updatedRow.components[1].setDisabled(true);

      await interaction.message.edit({ embeds: [updatedEmbed], components: [updatedRow] });
      return interaction.reply({ content: `✅ Ticket diambil alih oleh <@${interaction.user.id}>.` });
    }

    // ── 7. Close Ticket → modal alasan ───────────────────────────────────
    if (interaction.isButton() && interaction.customId.startsWith('t_closeinit_')) {
      if (!interaction.member.roles.cache.has(SELLER_ROLE_ID) && !interaction.member.permissions.has('Administrator')) {
        return interaction.reply({ content: '⛔ Hanya Admin/Seller yang dapat menutup tiket.', ephemeral: true });
      }

      const pembuatId = interaction.customId.split('_')[2];
      return interaction.showModal(
        new ModalBuilder()
          .setCustomId(`t_modalclose_${pembuatId}`)
          .setTitle('Close Ticket')
          .addComponents(
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('close_reason')
                .setLabel('Closing reason')
                .setPlaceholder('Contoh: Issue resolved / Order completed.')
                .setStyle(TextInputStyle.Paragraph)
                .setRequired(true),
            ),
          ),
      );
    }

    // ── 8. Submit penutupan → arsip & hapus channel ───────────────────────
    if (interaction.isModalSubmit() && interaction.customId.startsWith('t_modalclose_')) {
      await interaction.deferReply();

      const pembuatId = interaction.customId.split('_')[2];
      const reason    = interaction.fields.getTextInputValue('close_reason');
      const messages  = await interaction.channel.messages.fetch({ limit: 100 });

      const transcript =
        `TICKET ARCHIVE: ${interaction.channel.name}\n` +
        `Closed by: ${interaction.user.tag}  |  Reason: ${reason}\n` +
        `${'─'.repeat(52)}\n\n` +
        Array.from(messages.values()).reverse()
          .filter(m => !m.author.bot)
          .map(m => `[${m.createdAt.toLocaleString('id-ID')}] ${m.author.tag}: ${m.content}`)
          .join('\n');

      const embedClose = new EmbedBuilder()
        .setColor(0x2B2D31)
        .setTitle('Ticket Closed')
        .addFields(
          { name: '📁 Channel',  value: `\`${interaction.channel.name}\``, inline: true },
          { name: '🚫 Closed by', value: `<@${interaction.user.id}>`,      inline: true },
          { name: '📝 Reason',   value: `\`\`\`${reason}\`\`\``,           inline: false },
        )
        .setTimestamp()
        .setFooter({ text: 'NanoSpray  •  Ticket Closed' });

      const file = { attachment: Buffer.from(transcript, 'utf-8'), name: `transcript-${interaction.channel.name}.txt` };

      const user = await interaction.client.users.fetch(pembuatId).catch(() => null);
      if (user) await user.send({ embeds: [embedClose], files: [file] }).catch(() => null);

      const logCh = await interaction.client.channels.fetch(TICKET_LOG_CHANNEL_ID).catch(() => null);
      if (logCh) await logCh.send({ embeds: [embedClose], files: [file] });

      await interaction.editReply({ content: '📦 Archiving... Channel akan dihapus dalam 3 detik.' });
      setTimeout(() => interaction.channel.delete().catch(() => null), 3000);
    }
  },
};
