module.exports = {
  name: 'interactionCreate',
  async execute(interaction) {
    
    // 1. HANDLER UNTUK PILIHAN OTOMATIS (AUTOCOMPLETE / REMOVE AUTO RESPONDER)
    if (interaction.isAutocomplete()) {
      const command = interaction.client.commands.get(interaction.commandName);
      if (!command) return;

      try {
        await command.autocomplete(interaction);
      } catch (error) {
        console.error('❌ Error saat menjalankan autocomplete:', error);
        await interaction.respond([]).catch(() => null);
      }
      return; 
    }

    // 2. HANDLER UNTUK SLASH COMMAND UTAMA (/respon, /verify, dll)
    if (interaction.isChatInputCommand()) {
      const command = interaction.client.commands.get(interaction.commandName);
      if (!command) return;

      try {
        await command.execute(interaction);
      } catch (error) {
        console.error(error);
        if (interaction.replied || interaction.deferred) {
          await interaction.followUp({ content: 'Terjadi error saat mengeksekusi command ini!', ephemeral: true });
        } else {
          await interaction.reply({ content: 'Terjadi error saat mengeksekusi command ini!', ephemeral: true });
        }
      }
      return;
    }

    // 3. HANDLER UNTUK BUTTON & SELECT MENU BERBASIS PREFIX customId
    // Setiap command bisa punya properti opsional:
    //   - componentPrefix: string (prefix customId, misal 'catur_')
    //   - handleComponent(interaction): fungsi async untuk proses button/select
    // Ini TIDAK mengganggu ticket system atau button lain yang sudah kamu
    // proses dengan cara lain (misal lewat collector per-pesan) — hanya
    // dijalankan kalau customId cocok prefix dan command-nya punya
    // handleComponent.
    if (interaction.isButton() || interaction.isStringSelectMenu()) {
      const matchedCommand = [...interaction.client.commands.values()].find(
        (cmd) => cmd.componentPrefix && interaction.customId.startsWith(cmd.componentPrefix)
      );
      if (!matchedCommand || !matchedCommand.handleComponent) return;

      try {
        await matchedCommand.handleComponent(interaction);
      } catch (error) {
        console.error('❌ Error saat memproses komponen:', error);
        if (interaction.replied || interaction.deferred) {
          await interaction.followUp({ content: 'Terjadi error saat memproses interaksi ini!', ephemeral: true }).catch(() => null);
        } else {
          await interaction.reply({ content: 'Terjadi error saat memproses interaksi ini!', ephemeral: true }).catch(() => null);
        }
      }
    }
  },
};


