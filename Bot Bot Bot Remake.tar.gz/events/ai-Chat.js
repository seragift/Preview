const fs = require('fs');
const path = require('path');

// Sistem Multi-Path Resolver agar aman di VPS/Pterodactyl
const pathsToTry = [
  path.join(process.cwd(), 'aiConfig.json'),
  path.join(__dirname, '../aiConfig.json'),
  path.join(__dirname, '../../aiConfig.json')
];

let dbPath = pathsToTry[0];
for (const p of pathsToTry) {
  if (fs.existsSync(p)) {
    dbPath = p;
    break;
  }
}

// Inisialisasi Map memory lokal jika belum ada di global scope
if (!global.aiMemory) global.aiMemory = new Map();

module.exports = {
  name: 'messageCreate',
  async execute(message) {
    // Abaikan jika pengirim adalah bot itu sendiri
    if (message.author.bot) return;

    if (!fs.existsSync(dbPath)) return;
    const db = JSON.parse(fs.readFileSync(dbPath, 'utf8'));

    if (!db.enabled) return; 
    if (!db.apiKey) return;  

    const isDM = !message.guild; 
    const isSpecialChannel = message.channel.id === db.channelId;

    // Hanya merespons jika lewat DM atau Channel Khusus AI
    if (!isDM && !isSpecialChannel) return;

    const userPrompt = message.content.trim();
    if (userPrompt.length === 0) return;

    // ─── FILTRASI KATA KU

    // ─── PROSES KE AI JIKA LOLOS FILTER ───
    await message.channel.sendTyping();

    const userId = message.author.id;
    if (!global.aiMemory.has(userId)) {
      global.aiMemory.set(userId, []);
    }
    const userHistory = global.aiMemory.get(userId);

    try {
      // Prompt Instruksi Kepribadian: Pelayan dingin, efisien, to-the-point, dan berorientasi ingatan privat.
      const systemInstruction = 
        "Anda adalah ai biasa";

      const messagesBody = [
        { role: 'system', content: systemInstruction }
      ];

      // Masukkan memori ingatan chat sebelumnya agar AI mengingat konteks obrolan user
      userHistory.forEach(chat => {
        messagesBody.push({ role: chat.role, content: chat.content });
      });

      messagesBody.push({ role: 'user', content: userPrompt });

      const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${db.apiKey}`
        },
        body: JSON.stringify({
          model: 'llama-3.1-8b-instant',
          messages: messagesBody,
          temperature: 0.4, // Diturunkan agar jawaban AI lebih konsisten dan tidak bertele-tele
          max_tokens: 150   // Ditambah sedikit agar bisa memberikan jawaban yang berbobot namun tetap singkat
        })
      });

      const data = await response.json();

      if (!response.ok) {
        return message.reply({ content: 'Eror tolol cek dulu.' });
      }

      const replyContent = data.choices?.[0]?.message?.content;

      if (!replyContent) {
        return message.reply({ content: 'Gagal memuat jawaban pelayan.' });
      }

      // Simpan percakapan baru ke dalam ingatan memori lokal user
      userHistory.push({ role: 'user', content: userPrompt });
      userHistory.push({ role: 'assistant', content: replyContent });

      // Batasi ingatan agar tidak menyebabkan memory leak (Mengingat hingga 15 percakapan terakhir)
      if (userHistory.length > 30) {
        userHistory.splice(0, 2);
      }
      global.aiMemory.set(userId, userHistory);

      await message.reply({ content: replyContent });

    } catch (error) {
      console.error(error);
      await message.reply({ content: 'Eror cekk dulu cuk.' });
    }
  }
};
