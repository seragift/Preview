const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
  name: 'interactionCreate',
  async execute(interaction) {
    
    // ───────── KONDISI 1: ADMIN MEN-SUBMIT DATA MODAL ─────────
    if (interaction.isModalSubmit() && interaction.customId.startsWith('br_modal_')) {
      await interaction.deferReply({ ephemeral: true });

      // Pecah customId untuk mengambil data RoleID dan Emoji bawaan
      const [, , roleId, emojiParam] = interaction.customId.split('_');
      const emoji = emojiParam === 'noemoji' ? null : emojiParam;

      // Ambil string hasil ketikan admin dari formulir modal
      const judulEmbed = interaction.fields.getTextInputValue('br_title');
      const deskripsiEmbed = interaction.fields.getTextInputValue('br_desc');
      const namaTombol = interaction.fields.getTextInputValue('br_btnname');

      // Bangun tampilan embed yang rapi sesuai input admin
      const embedPanel = new EmbedBuilder()
        .setColor('#5865F2')
        .setTitle(judulEmbed)
        .setDescription(deskripsiEmbed)
        .setTimestamp();

      // Bangun komponen tombol interaktifnya
      const tombolRole = new ButtonBuilder()
        .setCustomId(`br_trigger_${roleId}`)
        .setLabel(namaTombol)
        .setStyle(ButtonStyle.Primary);

      // Pasang emoji ke tombol jika diisi oleh admin
      if (emoji) {
        tombolRole.setEmoji(emoji);
      }

      const rowTombol = new ActionRowBuilder().addComponents(tombolRole);

      // Kirim panel utama ke channel saat ini
      await interaction.channel.send({ embeds: [embedPanel], components: [rowTombol] });
      
      // Beri laporan sukses privat ke admin agar tidak mengotori chat log publik
      return interaction.editReply({ content: '✅ Panel Button Role sukses dibuat dan dikirimkan!' });
    }

    // ───────── KONDISI 2: USER KLIK TOMBOL AMBIL/HAPUS ROLE ─────────
    if (interaction.isButton() && interaction.customId.startsWith('br_trigger_')) {
      // Defer update secara ephemeral agar loading wheel hilang dan respon privat ke user
      await interaction.deferReply({ ephemeral: true });

      const roleId = interaction.customId.split('_')[2];
      const targetRole = interaction.guild.roles.cache.get(roleId);

      // Jika role tidak sengaja terhapus oleh admin di server setting
      if (!targetRole) {
        return interaction.editReply({ content: '❌ Gagal memproses. Role ini tidak ditemukan atau sudah dihapus dari server ini.' });
      }

      // Cek posisi hierarki bot, pastikan posisi role bot berada di atas role yang ingin dibagikan
      const botMember = interaction.guild.members.me;
      if (targetRole.position >= botMember.roles.highest.position) {
        return interaction.editReply({ content: '❌ Sistem Error: Posisi tingkat role saya lebih rendah dari role yang akan dibagikan. Hubungi admin untuk menaikkan posisi role bot di Server Settings!' });
      }

      const member = interaction.member;

      // LOGIKA TOGGLE: JIKA SUDAH PUNYA -> HAPUS, JIKA BELUM -> BERIKAN
      if (member.roles.cache.has(roleId)) {
        await member.roles.remove(roleId).catch(() => null);
        return interaction.editReply({ content: `🗑️ Role **${targetRole.name}** telah **dicabut** dari akun Anda.` });
      } else {
        await member.roles.add(roleId).catch(() => null);
        return interaction.editReply({ content: `✅ Berhasil! Role **${targetRole.name}** sekarang telah **ditambahkan** ke akun Anda.` });
      }
    }
  }
};


