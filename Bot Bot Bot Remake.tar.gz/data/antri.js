const { SlashCommandBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

// ─── Path JSON: sesuaikan jika struktur folder berbeda ───
// Asumsi: commands/antri.js → data/antri.json ada di root project
const ANTRI_FILE = path.join(__dirname, '..', 'data', 'antri.json');

function loadAntriDirect() {
  try {
    if (!fs.existsSync(ANTRI_FILE)) {
      console.warn('[ANTRI AUTOCOMPLETE] antri.json tidak ditemukan di:', ANTRI_FILE);
      return [];
    }
    const raw = fs.readFileSync(ANTRI_FILE, 'utf-8');
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch (err) {
    console.error('[ANTRI AUTOCOMPLETE] Gagal baca antri.json:', err.message);
    return [];
  }
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('antri')
    .setDescription('📌 Sistem Manajemen Antrian Pesanan')
    .addSubcommand(sub =>
      sub.setName('buat')
        .setDescription('🛒 Membuat nomor antrian baru')
        .addStringOption(opt => opt.setName('produk').setDescription('Nama produk yang dibeli').setRequired(true))
        .addUserOption(opt => opt.setName('buyer').setDescription('User pembeli (kosongkan jika untuk diri sendiri)').setRequired(false))
    )
    .addSubcommand(sub =>
      sub.setName('update')
        .setDescription('⚙️ Memperbarui data antrian atau status bar progress')
        .addIntegerOption(opt =>
          opt.setName('nomor')
            .setDescription('Nomor urut antrian yang ingin diubah')
            .setRequired(true)
            .setAutocomplete(true)
        )
        .addStringOption(opt => opt.setName('produk').setDescription('Ubah nama produk (Buyer/Admin)').setRequired(false))
        .addIntegerOption(opt =>
          opt.setName('progress')
            .setDescription('Ubah persentase progress (Khusus Admin/Staff)')
            .setRequired(false)
            .addChoices(
              { name: '10%', value: 10 },
              { name: '20%', value: 20 },
              { name: '30%', value: 30 },
              { name: '40%', value: 40 },
              { name: '50%', value: 50 },
              { name: '60%', value: 60 },
              { name: '70%', value: 70 },
              { name: '80%', value: 80 },
              { name: '90%', value: 90 },
              { name: '100% (Selesai)', value: 100 }
            )
        )
    )
    .addSubcommand(sub =>
      sub.setName('selesai')
        .setDescription('✅ Menyelesaikan antrian pesanan (Admin/Staff Only)')
        .addIntegerOption(opt =>
          opt.setName('nomor')
            .setDescription('Nomor urut antrian yang telah selesai')
            .setRequired(true)
            .setAutocomplete(true)
        )
    )
    .addSubcommand(sub =>
      sub.setName('list')
        .setDescription('📋 Melihat semua daftar antrian yang sedang berjalan')
    ),

  async execute(interaction) {
    // Logika dieksekusi di events/antriHandle.js
  },

  // ─── AUTOCOMPLETE: Baca langsung dari antri.json (tanpa require antriHandle) ───
  async autocomplete(interaction) {
    try {
      const subcommand = interaction.options.getSubcommand();
      if (!['update', 'selesai'].includes(subcommand)) {
        return await interaction.respond([]);
      }

      const focusedValue = String(interaction.options.getFocused()).toLowerCase();
      const queue = loadAntriDirect();

      if (queue.length === 0) {
        // Tidak ada antrian — tampilkan info
        return await interaction.respond([
          { name: '📋 Tidak ada antrian aktif saat ini', value: -1 }
        ]);
      }

      // Filter berdasarkan nomor atau nama produk
      const filtered = queue
        .filter(q =>
          String(q.id).includes(focusedValue) ||
          q.productName.toLowerCase().includes(focusedValue)
        )
        .slice(0, 25)
        .map(q => ({
          name: `#${q.id} — ${q.productName} (${q.progress}%)`,
          value: q.id
        }));

      if (filtered.length === 0) {
        return await interaction.respond([
          { name: '❌ Tidak ada antrian yang cocok', value: -1 }
        ]);
      }

      await interaction.respond(filtered);
    } catch (err) {
      console.error('[ANTRI AUTOCOMPLETE] Error:', err.message);
      try { await interaction.respond([]); } catch {}
    }
  }
};
