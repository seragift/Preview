const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('verify')
    .setDescription('Kirim panel verifikasi CAPTCHA (Admin Only)')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setColor('#2B2D31')
      .setTitle('Verifikasi Keamanan | NanoSpray')
      .setDescription(
        'Selamat datang! Untuk melanjutkan akses ke server ini, silakan selesaikan ' +
        'Verifikasi singkat di bawah.\n\n' +
        '**Cara verifikasi:**\n' +
        '1. Klik tombol **Verify** di bawah.\n' +
        '2. Captcha akan muncul.\n' +
        '3. Selesaikan Captcha berikut.\n'
      )
      .setFooter({ text: 'Klik tombol di bawah untuk memulai' })
      .setTimestamp();

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('start_verify')
        .setLabel('Verify')
        .setStyle(ButtonStyle.Success)
    );

    await interaction.channel.send({ embeds: [embed], components: [row] });
    return interaction.reply({ content: '✅ Panel verify berhasil terkirim!', ephemeral: true });
  }
};
