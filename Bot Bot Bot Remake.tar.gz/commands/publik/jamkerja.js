const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('jamkerja')
    .setDescription('Cek jadwal operasional'),

  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setTitle('Jam Operasional NanoSpray')
      .setDescription(
        'Berikut jadwal operasional kami. Pastikan melakukan order sesuai jam agar respon cepat!\n\n' +
        'Senin : 15:00 - 22:00 WIB\n' +
        'Selasa : 15:00 - 22:00 WIB\n' +
        'Rabu : 15:00 - 22:00 WIB\n' +
        'Kamis : 15:00 - 22:00 WIB\n' +
        'Jumat : 13:00 - 00:00 WIB\n' +
        'Sabtu : 10:00 - 00:00 WIB\n' +
        'Minggu : 10:00 - 00:00 WIB'
      )
      .setColor(0x2B2D31)
      .setThumbnail('https://cdn.discordapp.com/attachments/1534589788580089897/1534906674731552891/dc-monogram-logo-esport-or-gaming-initial-concept-free-vector.jpg?ex=6a75d4bc&is=6a74833c&hm=7cd731e3ca9a88e4ed7f6cc272ea99ddb2e39d77a1e589f4212a1f1a8b0a835d&') // ganti dengan logo toko
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  }
};