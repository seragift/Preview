
const { SlashCommandBuilder, AttachmentBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('obf')
    .setDescription('Obfuscate Lua - Advanced Level')
    .addAttachmentOption(opt =>
      opt.setName('file')
        .setDescription('Upload .lua file')
        .setRequired(true)
    ),

  async execute(interaction) {
    await interaction.deferReply();

    const attachment = interaction.options.getAttachment('file');
    const fileName = attachment.name ?? 'output.lua';

    if (!fileName.endsWith('.lua')) {
      return interaction.editReply('❌ Only `.lua` files supported.');
    }
    if (attachment.size > 5_000_000) {
      return interaction.editReply('❌ Max 5 MB.');
    }

    let source;
    try {
      const res = await fetch(attachment.url);
      source = await res.text();
    } catch {
      return interaction.editReply('❌ Failed to download.');
    }

    if (!source || !source.trim()) {
      return interaction.editReply('❌ Empty file.');
    }

    let result;
    try {
      result = obfuscateLua(source);
    } catch (e) {
      return interaction.editReply(`❌ Error: ${e.message}`);
    }

    const outName = fileName.replace(/\.lua$/, '_obf.lua');
    const file = new AttachmentBuilder(Buffer.from(result, 'utf-8'), { name: outName });
    const ratio = ((result.length / source.length - 1) * 100).toFixed(0);

    await interaction.editReply({
      content:
        `🔒 **Obfuscation Complete!**\n` +
        `📄 \`${fileName}\` → \`${outName}\`\n` +
        `📊 Size: \`${(source.length / 1024).toFixed(1)} KB\` → \`${(result.length / 1024).toFixed(1)} KB\` (+${ratio}%)\n` +
        `> ✅ Fully functional - NanoSpray.`,
      files: [file],
    });
  },
};

// ════════════════════════════════════════════════════════════════════════════
//  LUA OBFUSCATOR v4.0 - ADVANCED ENGINE
// ════════════════════════════════════════════════════════════════════════════

const LUA_KEYWORDS = new Set([
  'and','break','do','else','elseif','end','false','for','function',
  'goto','if','in','local','nil','not','or','repeat','return',
  'then','true','until','while',
]);

const LUA_GLOBALS = new Set([
  'print','pairs','ipairs','next','select','type','tostring','tonumber',
  'rawget','rawset','rawequal','rawlen','setmetatable','getmetatable',
  'pcall','xpcall','error','assert','load','loadstring','loadfile',
  'dofile','require','module','unpack','collectgarbage','gcinfo',
  'coroutine','table','string','math','io','os','debug','package','utf8',
  'bit','bit32','jit','_G','_VERSION','_ENV',
  'format','find','match','gmatch','gsub','sub','byte','char','rep',
  'reverse','upper','lower','len','insert','remove','sort','concat',
  'write','read','open','close','lines','time','clock','date','difftime',
]);

// ── LEXER / TOKENIZER ──────────────────────────────────────────────────────

class LuaLexer {
  constructor(src) {
    this.src = src;
    this.pos = 0;
    this.tokens = [];
  }

  tokenize() {
    const s = this.src;
    let i = 0;

    while (i < s.length) {
      // Skip whitespace
      if (/[ \t\r\n]/.test(s[i])) { i++; continue; }

      // Comments
      if (s[i] === '-' && s[i+1] === '-') {
        if (s[i+2] === '[') {
          let lvl = 0, j = i + 3;
          while (s[j] === '=') { lvl++; j++; }
          if (s[j] === '[') {
            const close = ']' + '='.repeat(lvl) + ']';
            const end = s.indexOf(close, j + 1);
            if (end !== -1) { i = end + close.length; continue; }
          }
        }
        while (i < s.length && s[i] !== '\n') i++;
        continue;
      }

      // Long strings
      if (s[i] === '[' && (s[i+1] === '[' || s[i+1] === '=')) {
        let lvl = 0, j = i + 1;
        while (s[j] === '=') { lvl++; j++; }
        if (s[j] === '[') {
          const close = ']' + '='.repeat(lvl) + ']';
          const end = s.indexOf(close, j + 1);
          if (end !== -1) {
            const content = s.slice(j + 1, end);
            this.tokens.push({ type: 'string', value: content, raw: true });
            i = end + close.length;
            continue;
          }
        }
      }

      // Quoted strings
      if (s[i] === '"' || s[i] === "'") {
        const quote = s[i];
        let j = i + 1;
        let value = '';
        while (j < s.length) {
          if (s[j] === '\\') {
            value += s[j] + (s[j+1] || '');
            j += 2;
            continue;
          }
          if (s[j] === quote) break;
          value += s[j];
          j++;
        }
        j++;
        this.tokens.push({ type: 'string', value: value });
        i = j;
        continue;
      }

      // Numbers
      const numMatch = s.slice(i).match(/^0[xX][0-9a-fA-F]+|^\d+\.?\d*(?:[eE][+-]?\d+)?/);
      if (numMatch) {
        this.tokens.push({ type: 'number', value: numMatch[0] });
        i += numMatch[0].length;
        continue;
      }

      // Identifiers
      const idMatch = s.slice(i).match(/^[a-zA-Z_][a-zA-Z0-9_]*/);
      if (idMatch) {
        const word = idMatch[0];
        this.tokens.push({
          type: LUA_KEYWORDS.has(word) ? 'keyword' : 'ident',
          value: word
        });
        i += word.length;
        continue;
      }

      // Operators
      const op2 = s.slice(i, i+2);
      if (['..','==','~=','<=','>=','::','//','<<','>>','**'].includes(op2)) {
        this.tokens.push({ type: 'operator', value: op2 });
        i += 2;
        continue;
      }

      this.tokens.push({ type: 'operator', value: s[i] });
      i++;
    }

    return this.tokens;
  }
}

// ── ENCODERS ──────────────────────────────────────────────────────────────────

function parseEscape(raw) {
  let result = '';
  for (let i = 0; i < raw.length; i++) {
    if (raw[i] === '\\') {
      const c = raw[++i];
      switch (c) {
        case 'n': result += '\n'; break;
        case 't': result += '\t'; break;
        case 'r': result += '\r'; break;
        case 'b': result += '\b'; break;
        case 'f': result += '\f'; break;
        case 'v': result += '\v'; break;
        case 'a': result += '\x07'; break;
        case '\\': result += '\\'; break;
        case '"': result += '"'; break;
        case "'": result += "'"; break;
        default:
          if (/[0-9]/.test(c)) {
            let num = c, j = i + 1;
            while (j < raw.length && /[0-9]/.test(raw[j]) && j - i < 3) {
              num += raw[j++];
            }
            result += String.fromCharCode(parseInt(num, 10));
            i = j - 1;
          } else {
            result += c;
          }
      }
    } else {
      result += raw[i];
    }
  }
  return result;
}

function encodeStringAdvanced(raw) {
  const decoded = parseEscape(raw);
  if (decoded.length === 0) return "''";

  // Multi-layer encoding ala LuaObfuscation.com
  const chars = [];
  for (const ch of decoded) {
    chars.push(ch.charCodeAt(0));
  }

  // Method 1: string.char dengan chunk
  const chunks = [];
  const chunkSize = 30;
  for (let i = 0; i < chars.length; i += chunkSize) {
    const chunk = chars.slice(i, i + chunkSize);
    chunks.push(`string.char(${chunk.join(',')})`);
  }

  let encoded = chunks.length === 1 ? chunks[0] : `(${chunks.join('..')})`;

  // Method 2: Bungkus dengan loadstring untuk extra layer
  if (chars.length > 5 && Math.random() > 0.5) {
    const wrapper = `loadstring(${encoded})()`;
    // Tambahkan garbage di dalam string
    const garbage = Math.random().toString(36).substring(2, 8);
    encoded = `(function() return ${wrapper} end)()`;
  }

  // Method 3: Menggunakan table.concat
  if (chars.length > 10 && Math.random() > 0.4) {
    const tbl = chars.map(c => `string.char(${c})`).join(',');
    encoded = `table.concat({${tbl}})`;
  }

  return encoded;
}

function encodeNumberAdvanced(val) {
  const n = Number(val);
  if (!Number.isFinite(n)) return val;
  if (!Number.isInteger(n)) return `tonumber("${n}")`;

  if (n === 0) return '(1-1)';
  if (n === 1) return '(1*1)';
  if (n === 2) return '(1+1)';

  // Bitwise obfuscation
  if (n > 0 && n <= 0xffff) {
    const methods = [
      // XOR
      () => {
        const a = Math.floor(Math.random() * 0xffff);
        const b = a ^ n;
        return `bit.bxor(${a},${b})`;
      },
      // Shift
      () => {
        if (n % 2 === 0) {
          const shift = Math.floor(Math.random() * 8) + 1;
          const base = n >> shift;
          return `bit.lshift(${base},${shift})`;
        }
        return null;
      },
      // Math expression
      () => {
        const factors = [];
        let temp = n;
        for (let i = 2; i <= 5 && temp > 1; i++) {
          if (temp % i === 0) {
            factors.push(i);
            temp /= i;
          }
        }
        if (factors.length >= 2) {
          const expr = factors.map(f => f.toString()).join('*');
          return `(${expr})`;
        }
        return null;
      },
      // Subtraction
      () => {
        const a = Math.floor(Math.random() * 100) + 1;
        const b = n + a;
        return `(${b}-${a})`;
      }
    ];

    // Try random methods
    const shuffled = methods.sort(() => Math.random() - 0.5);
    for (const method of shuffled) {
      try {
        const result = method();
        if (result && !result.includes('undefined')) {
          return result;
        }
      } catch {}
    }
  }

  // Fallback
  const a = Math.floor(Math.random() * 50) + 1;
  const b = n + a;
  return `(${b}-${a})`;
}

// ── OBFUSCATION ENGINE ──────────────────────────────────────────────────────

function obfuscateLua(source) {
  // 1. Tokenize
  const lexer = new LuaLexer(source);
  const tokens = lexer.tokenize();

  // 2. Build rename map with scope
  const renameMap = {};
  let counter = 0;
  const scopes = [new Set()];
  let inFunction = false;

  for (let i = 0; i < tokens.length; i++) {
    const t = tokens[i];

    if (t.type === 'keyword' && t.value === 'function') {
      inFunction = true;
      scopes.push(new Set());
      continue;
    }
    if (t.type === 'keyword' && t.value === 'end') {
      if (inFunction) {
        inFunction = false;
        if (scopes.length > 1) scopes.pop();
      }
      continue;
    }

    if (t.type !== 'ident') continue;

    // Check if local/param
    let isLocal = false;
    let isParam = false;
    let isFuncName = false;

    for (let j = i - 1; j >= Math.max(0, i - 5); j--) {
      const prev = tokens[j];
      if (prev && prev.type === 'keyword') {
        if (prev.value === 'local') { isLocal = true; break; }
        if (prev.value === 'function') { isFuncName = true; break; }
      }
      if (prev && prev.type === 'operator' && prev.value === '(') break;
    }

    if (!isLocal && !isFuncName) {
      for (let j = i - 1; j >= Math.max(0, i - 10); j--) {
        const prev = tokens[j];
        if (prev && prev.type === 'keyword' && prev.value === 'function') {
          isParam = true;
          break;
        }
        if (prev && (prev.value === ')' || prev.value === 'end')) break;
      }
    }

    if (LUA_GLOBALS.has(t.value)) continue;

    // Skip method names
    let prevReal = null;
    for (let j = i - 1; j >= 0; j--) {
      if (tokens[j].type !== 'ident' && tokens[j].type !== 'keyword') {
        prevReal = tokens[j];
        break;
      }
    }
    if (prevReal && (prevReal.value === '.' || prevReal.value === ':')) continue;

    if (isLocal || isParam || isFuncName) {
      if (!renameMap[t.value]) {
        renameMap[t.value] = `_0x${(counter++).toString(16).padStart(4, '0')}`;
      }
      if (scopes.length > 0) {
        scopes[scopes.length - 1].add(t.value);
      }
      continue;
    }

    // Check scope
    let inScope = false;
    for (let s = scopes.length - 1; s >= 0; s--) {
      if (scopes[s].has(t.value)) { inScope = true; break; }
    }

    if (!inScope && !renameMap[t.value]) {
      renameMap[t.value] = `_0x${(counter++).toString(16).padStart(4, '0')}`;
    }
  }

  // 3. Generate obfuscated code
  let obf = '';
  let lastType = null;

  for (let i = 0; i < tokens.length; i++) {
    const t = tokens[i];

    // Smart spacing
    if (i > 0 && lastType) {
      const prev = tokens[i - 1];
      const needSpace =
        (t.type === 'ident' || t.type === 'keyword') &&
        (prev.type === 'ident' || prev.type === 'keyword' || prev.type === 'number');
      if (needSpace) obf += ' ';
    }

    if (t.type === 'ident') {
      obf += renameMap[t.value] || t.value;
      lastType = 'ident';
    } else if (t.type === 'keyword') {
      obf += t.value;
      lastType = 'keyword';
    } else if (t.type === 'string') {
      obf += encodeStringAdvanced(t.value);
      lastType = 'string';
    } else if (t.type === 'number') {
      obf += encodeNumberAdvanced(t.value);
      lastType = 'number';
    } else if (t.type === 'operator') {
      obf += t.value;
      lastType = 'operator';
    }
  }

  // 4. Add noise (variables, functions, tables)
  const noise = [];
  const used = new Set();

  // Variable noise
  for (let i = 0; i < 12; i++) {
    const name = `_0xn${i.toString(16).padStart(3, '0')}`;
    if (used.has(name)) continue;
    used.add(name);
    const v = Math.floor(Math.random() * 0xffff) + 1;
    noise.push(`local ${name}=${encodeNumberAdvanced(v)}`);
  }

  // Function noise
  for (let i = 0; i < 6; i++) {
    const name = `_0xf${i.toString(16).padStart(4, '0')}`;
    if (used.has(name)) continue;
    used.add(name);
    const v = Math.floor(Math.random() * 100) + 1;
    noise.push(`local ${name}=function() return ${encodeNumberAdvanced(v)} end`);
  }

  // Table noise
  for (let i = 0; i < 4; i++) {
    const name = `_0xt${i.toString(16).padStart(3, '0')}`;
    if (used.has(name)) continue;
    used.add(name);
    const k = encodeNumberAdvanced(Math.floor(Math.random() * 50) + 1);
    const v = encodeNumberAdvanced(Math.floor(Math.random() * 50) + 1);
    noise.push(`local ${name}={[${k}]=${v}}`);
  }

  obf = noise.join(';') + ';' + obf;

  // 5. Multi-layer wrapper
  obf = `
    local _0xres = nil
    local _0xok, _0xerr = xpcall(function()
      ${obf}
    end, function(err)
      return err
    end)
    if not _0xok then
      error(_0xerr)
    end
    return _0xres
  `;

  // 6. Minify: remove unnecessary whitespace
  obf = obf.replace(/\n/g, ' ').replace(/\s+/g, ' ').trim();

  return obf;
}

// ── EXPORT ──────────────────────────────────────────────────────────────────

module.exports.obfuscateLua = obfuscateLua;