const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { TESTIMONI_CHANNEL_ID, SELLER_ROLE_ID } = require('../../config.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('testimoni')
    .setDescription('Kirim bukti testimoni transaksi pembeli & minta rating otomatis')
    .addIntegerOption(option =>
      option.setName('nomor').setDescription('Nomor urut testimoni saat ini').setRequired(true))
    .addUserOption(option =>
      option.setName('pembeli').setDescription('Pilih/Mention user pembeli').setRequired(true))
    .addStringOption(option =>
      option.setName('produk').setDescription('Nama barang / jasa yang dibeli').setRequired(true))
    .addNumberOption(option =>
      option.setName('harga').setDescription('Total harga transaksi (Angka saja)').setRequired(true))
    .addAttachmentOption(option =>
      option.setName('bukti').setDescription('Unggah foto/screenshot bukti transaksi/serah terima barang').setRequired(true))
    .addStringOption(option =>
      option.setName('catatan').setDescription('Pesan/catatan dari Seller untuk pembeli di DM').setRequired(true)),

  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });

    if (!interaction.member.roles.cache.has(SELLER_ROLE_ID)) {
      return interaction.editReply({ content: '❌ Kamu tidak memiliki izin akses (`SELLER_ROLE`) untuk menggunakan perintah ini.' });
    }

    const nomor = interaction.options.getInteger('nomor');
    const pembeli = interaction.options.getUser('pembeli');
    const produk = interaction.options.getString('produk');
    const harga = interaction.options.getNumber('harga');
    const bukti = interaction.options.getAttachment('bukti');
    const catatan = interaction.options.getString('catatan');

    if (pembeli.bot) return interaction.editReply({ content: '❌ Tidak bisa mengirimkan testimoni/rating ke bot.' });

    const testiChannel = await interaction.client.channels.fetch(TESTIMONI_CHANNEL_ID).catch(() => null);
    if (!testiChannel) {
      return interaction.editReply({ content: '❌ Channel testimoni tidak ditemukan! Periksa config.json.' });
    }

    const formatRupiah = new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(harga);

    const embedTestiServer = new EmbedBuilder()
      .setColor('#2B2D31')
      .setTitle(`Testimoni | NanoSpray #${nomor}`)
      .setDescription(
        `**DETAIL TRANSAKSI:**\n` +
        `> 👤 **Pembeli:** <@${pembeli.id}>\n` +
        `> 🛒 **Penjual:** <@${interaction.user.id}>\n` +
        `> 📦 **Produk:** ${produk}\n` +
        `> 💰 **Harga:** ${formatRupiah}\n\n` +
        `⭐ **Rating:** **Menunggu...**\n\n` +
        `**🔗 Bukti Pembayaran**`
      )
      .setThumbnail(pembeli.displayAvatarURL({ dynamic: true }))
      .setImage(bukti.url)
      .setTimestamp()
      .setFooter({ text: 'NanoSpray' });

    const msgTestiServer = await testiChannel.send({
      content: `**Testimoni ** <@${pembeli.id}> | **Penjual:** <@${interaction.user.id}>`,
      embeds: [embedTestiServer]
    });

    const embedDM = new EmbedBuilder()
      .setColor('#2B2D31')
      .setTitle('Transaksi Berhasil | NanoSpray')
      .setDescription(
        `Halo kak <@${pembeli.id}>, pesanan Anda telah selesai diproses!\n\n` +
        `**INFO TRANSAKSI:**\n` +
        `├ 📦 **Produk:** ${produk}\n` +
        `├ 💰 **Total Harga:** ${formatRupiah}\n` +
        `└ 📝 **Status:** *Selesai*\n\n` +
        `**Pesan Seller:**\n` +
        `\`\`\`${catatan}\`\`\`\n\n` +
        `**🔗 Bukti Pembayaran**`
      )
      .setImage(bukti.url)
      .setFooter({ text: 'Klik bintang untuk memberi rating' })
      .setTimestamp();

    const rowStars = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`tgm_1_${interaction.user.id}_${harga}_${msgTestiServer.id}_${produk}`).setLabel('1 ⭐').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId(`tgm_2_${interaction.user.id}_${harga}_${msgTestiServer.id}_${produk}`).setLabel('2 ⭐').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId(`tgm_3_${interaction.user.id}_${harga}_${msgTestiServer.id}_${produk}`).setLabel('3 ⭐').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId(`tgm_4_${interaction.user.id}_${harga}_${msgTestiServer.id}_${produk}`).setLabel('4 ⭐').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId(`tgm_5_${interaction.user.id}_${harga}_${msgTestiServer.id}_${produk}`).setLabel('5 ⭐').setStyle(ButtonStyle.Primary)
    );

    try {
      await pembeli.send({ embeds: [embedDM], components: [rowStars] });
      await interaction.editReply({ content: `✅ Sukses! Terkirim ke DM pembeli & Testimoni #${nomor} berhasil dipajang di <#${TESTIMONI_CHANNEL_ID}>.` });
    } catch (err) {
      await msgTestiServer.delete().catch(() => null);
      console.error(err);
      await interaction.editReply({ content: '❌ Gagal mengirim! DM pembeli ditutup atau diblokir. Post testimoni dibatalkan.' });
    }
  }
};