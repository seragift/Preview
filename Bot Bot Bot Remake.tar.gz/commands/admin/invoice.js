const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('invoice')
        .setDescription('Membuat & mengirim struk pembayaran resmi (AzesZ Page)')
        // Membatasi command ini hanya bisa digunakan oleh Administrator
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator) 
        .addStringOption(option =>
            option.setName('produk')
                .setDescription('Nama produk yang dibeli')
                .setRequired(true))
        .addUserOption(option =>
            option.setName('pembeli')
                .setDescription('Pilih/Mention user pembeli')
                .setRequired(true))
        .addNumberOption(option =>
            option.setName('harga')
                .setDescription('Harga produk (Hanya angka)')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('metode')
                .setDescription('Metode pembayaran (Contoh: BCA, DANA, GoPay)')
                .setRequired(true)),

    async execute(interaction) {
        // Tahan interaksi agar bot tidak terkena timeout/invalid interaction
        await interaction.deferReply();

        // --- KONFIGURASI CHANNEL LOGS ---
        const LOG_CHANNEL_ID = 'LOGS_PEMBAYARAN_CHANNEL_ID'; //

        // Mengambil data dari input slash command
        const produk = interaction.options.getString('produk');
        const pembeli = interaction.options.getUser('pembeli');
        const harga = interaction.options.getNumber('harga');
        const metode = interaction.options.getString('metode');

        // Mengubah format angka menjadi format Rupiah otomatis
        const formatHarga = new Intl.NumberFormat('id-ID', { 
            style: 'currency', 
            currency: 'IDR',
            maximumFractionDigits: 0 
        }).format(harga);

        // PEMBARUAN DESAIN: Struk Pembayaran Premium (AzesZ Page Layout)
        const strukEmbed = new EmbedBuilder()
            .setTitle('Struk Pembayaran | NanoSpray')
            .setColor('#2B2D31') // Warna hijau sukses
            .setDescription(
                `**🛒 Kasir:** <@${interaction.user.id}>\n\n` +
                `**DATA:**\n` +
                `┌ 👤 **Pembeli:** <@${pembeli.id}>\n` +
                `├ 📦 **Produk:** ${produk}\n` +
                `├ 💰 **Harga:** ${formatHarga}\n` +
                `├ 💳 **Metode:** ${metode.toUpperCase()}\n` +
                `└ 🛡️ **Status Paid:** \ Selesai`
            )
            .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
            .setTimestamp() // Otomatis menambahkan waktu
            .setFooter({ 
                text: `NanoSpray • Seller: ${interaction.user.username}`, 
                iconURL: interaction.user.displayAvatarURL({ dynamic: true }) 
            });

        try {
            // 1. Mengirim struk ke channel tempat command diketik (menggunakan editReply karena sudah di-defer)
            await interaction.editReply({ embeds: [strukEmbed] });

            // PERBAIKAN UTAMA: Menggunakan fetch() agar log pasti terkirim walaupun cache kosong
            const logChannel = await interaction.client.channels.fetch(LOG_CHANNEL_ID).catch(() => null);
            
            // 2. Mengirim duplikat struk ke channel Logs
            if (logChannel) {
                await logChannel.send({ 
                    content: `**[STRUK PEMBAYARAN]** Struk ini diberikan kepada <@${pembeli.id}>.`,
                    embeds: [strukEmbed] 
                });
            } else {
                console.error('❌ Channel log tidak ditemukan! Periksa kembali ID di invoice.js.');
            }

        } catch (error) {
            console.error('❌ Terjadi kesalahan saat mengirim struk:', error);
            // Jika terjadi error, beri tahu admin secara diam-diam
            if (interaction.deferred) {
                await interaction.editReply({ content: '❌ Terjadi kesalahan internal saat memproses struk.' }).catch(() => null);
            }
        }
    },
};


