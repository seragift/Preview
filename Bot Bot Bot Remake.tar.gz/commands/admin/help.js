const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('help')
    .setDescription('Menampilkan daftar semua perintah beserta sub-command dan deskripsinya.'),

  async execute(interaction) {
    const commands = interaction.client.commands;
    let helpText = '';

    commands.forEach((cmd) => {
      const cmdData = cmd.data.toJSON ? cmd.data.toJSON() : cmd.data;
      const mainName = cmdData.name;
      const mainDesc = cmdData.description || 'Tidak ada deskripsi.';
      const options = cmdData.options || [];

      const subcommands = options.filter(opt => opt.type === 1);
      const subcommandGroups = options.filter(opt => opt.type === 2);

      helpText += `\n**\`/${mainName}\`** - ${mainDesc}\n`;

      if (subcommands.length > 0) {
        subcommands.forEach(sub => {
          helpText += `└ • \`/${mainName} ${sub.name}\` - ${sub.description || 'Tanpa deskripsi'}\n`;
        });
      }

      if (subcommandGroups.length > 0) {
        subcommandGroups.forEach(group => {
          helpText += `└ **Group \`${group.name}\`**\n`;
          const groupSubs = group.options?.filter(opt => opt.type === 1) || [];
          groupSubs.forEach(sub => {
            helpText += `  └ • \`/${mainName} ${group.name} ${sub.name}\` - ${sub.description || 'Tanpa deskripsi'}\n`;
          });
        });
      }
    });

    if (helpText.length > 4000) {
      helpText = helpText.substring(0, 3990) + '\n\n*(Daftar terlalu panjang, sebagian dipotong)*';
    }

    const helpEmbed = new EmbedBuilder()
      .setTitle('Daftar Perintah Bot')
      .setDescription(helpText.trim() || 'Tidak ada perintah yang ditemukan.')
      .setTimestamp()
      .setFooter({ 
        text: `Total Command Utama: ${commands.size}`, 
        iconURL: interaction.client.user.displayAvatarURL() 
      });

    await interaction.reply({ embeds: [helpEmbed] });
  },
};
