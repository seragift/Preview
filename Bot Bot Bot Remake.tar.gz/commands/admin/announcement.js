const {
  SlashCommandBuilder,
  PermissionFlagsBits,
} = require('discord.js');

// Pastikan ID Channel di bawah ini sudah sesuai dengan channel utama kamu
const ANNOUNCE_CHANNEL_ID = 'CHANNEL_ID_INFORMASI'; 

module.exports = {
  data: new SlashCommandBuilder()
    .setName('informasi')
    .setDescription('Kirim pengumuman ke channel utama')
    .addStringOption(o =>
      o.setName('judul')
        .setDescription('Judul pengumuman')
        .setRequired(true))
    .addStringOption(o =>
      o.setName('deskripsi')
        .setDescription('Isi pengumuman')
        .setRequired(true))
    .addAttachmentOption(o =>
      o.setName('gambar')
        .setDescription('Gambar opsional')
        .setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    // Menahan interaksi agar bot tidak terkena timeout/invalid interaction saat memproses
    await interaction.deferReply({ ephemeral: true });

    const judul = interaction.options.getString('judul');
    const deskripsi = interaction.options.getString('deskripsi');
    const gambar = interaction.options.getAttachment('gambar');

    // Mengambil channel secara real-time
    const channel = await interaction.client.channels.fetch(ANNOUNCE_CHANNEL_ID).catch(() => null);
    
    if (!channel) {
      return interaction.editReply({ 
        content: `❌ Gagal menemukan channel utama. Mohon periksa kembali apakah ID \`${ANNOUNCE_CHANNEL_ID}\` sudah benar dan bot memiliki izin akses ke channel tersebut.` 
      });
    }

    // MENYUSUN TEKS BIASA (BUKAN EMBED)
    // Di awal ada tag @everyone, di tengah ada isi informasi, di akhir ada > Owner Server
    let pesanTeks = `@everyone\n\n📢 **${judul.toUpperCase()}**\n${deskripsi}\n\n> Owner Server`;

    // Objek pesan yang akan dikirim ke Discord
    const payloadPesan = { content: pesanTeks };

    // Jika admin memasukkan gambar, gambar tersebut akan dikirim bersamaan sebagai file
    if (gambar) {
      payloadPesan.files = [gambar.url];
    }

    try {
      // Mengirim pesan teks biasa ke channel tujuan
      await channel.send(payloadPesan);

      // Memberikan respon sukses ke admin yang mengetik command
      await interaction.editReply({
        content: `✅ Pengumuman berhasil dikirim ke <#${ANNOUNCE_CHANNEL_ID}>`
      });
      
    } catch (error) {
      console.error('❌ Gagal mengirim pesan pengumuman:', error);
      await interaction.editReply({
        content: `❌ Bot menemukan channel-nya, tetapi GAGAL mengirim pesan. Pastikan bot memiliki izin **Send Messages** di channel tersebut.`
      });
    }
  }
};
