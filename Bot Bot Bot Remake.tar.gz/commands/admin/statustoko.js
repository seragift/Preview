const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const config = require('../../config.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('statustoko')
    .setDescription('Ubah status toko (buka / tutup)')
    .addStringOption(option =>
      option.setName('status')
        .setDescription('Pilih status toko')
        .setRequired(true)
        .addChoices(
          { name: 'Buka', value: 'open' },
          { name: 'Tutup', value: 'close' }
        )
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    const status = interaction.options.getString('status');
    const member = interaction.member;
    const ADMIN_ROLE_ID = config.ADMIN_ROLE_ID;

    // Role check
    if (!member.roles.cache.has(ADMIN_ROLE_ID)) {
      return interaction.reply({
        content: '🚫 Kamu tidak punya izin untuk menggunakan perintah ini.',
        ephemeral: true
      });
    }

    const isOpen = status === 'open';

    const embed = new EmbedBuilder()
      .setTitle(isOpen ? 'STORE OPENN' : 'STORE CLOSE')
        .setDescription(isOpen? 'NanoSpary Store **dibuka!**\nSilakan order via PM atau buat tiket\n\n**©NanoSpray**.'
    : 'Informasi NanoSpray telah **ditutup.**\nTunggu info selanjutnya terimakasih yang sudah order!\n\n**©NanoSpray**.'
)
      .setImage(isOpen
        ? 'https://i.imgur.com/Rvt1xOy.gif'
        : 'https://i.imgur.com/PNYHH61.gif')
      .setColor(isOpen ? 0x2B2D31 : 0x2B2D31) // hijau & merah modern Discord
      .setFooter({ text:'NanoSpary' })
      .setTimestamp();

    // Kirim ke channel
    await interaction.channel.send({
      content: '@everyone',
      embeds: [embed],
      allowedMentions: { parse: ['everyone'] }
    });

    // Balasan sukses ke admin
    await interaction.reply({
      content: `✅ Status toko berhasil diubah menjadi **${isOpen ? 'BUKA' : 'TUTUP'}**.`,
      ephemeral: true
    });
  }
};