const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

const pathsToTry = [
  path.join(process.cwd(), 'aiConfig.json'),
  path.join(__dirname, '../aiConfig.json'),
  path.join(__dirname, '../../aiConfig.json')
];

let dbPath = pathsToTry[0];
for (const p of pathsToTry) {
  if (fs.existsSync(p)) {
    dbPath = p;
    break;
  }
}

if (!global.aiMemory) global.aiMemory = new Map();

function readDB() {
  if (!fs.existsSync(dbPath)) {
    fs.writeFileSync(dbPath, JSON.stringify({ channelId: null, apiKey: null, enabled: true }, null, 2));
  }
  return JSON.parse(fs.readFileSync(dbPath, 'utf8'));
}

function writeDB(data) {
  fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ai')
    .setDescription('Manajemen dan pengaturan sistem AI Groq')
    
    // Subcommand: SET CHANNEL CHAT
    .addSubcommand(sub => sub
      .setName('channel')
      .setDescription('Admin: Tentukan channel khusus tempat user bisa chat dengan AI')
      .addChannelOption(opt => opt.setName('target').setDescription('Pilih channel teks').setRequired(true))
    )
    
    // Subcommand: SET API KEY GROQ
    .addSubcommand(sub => sub
      .setName('apikey')
      .setDescription('Admin: Masukkan Groq API Key Anda (gsk_...)')
      .addStringOption(opt => opt.setName('key').setDescription('Groq API Key Anda').setRequired(true))
    )
    
    // Subcommand: TOGGLE ON/OFF (PUBLIK)
    .addSubcommand(sub => sub
      .setName('status')
      .setDescription('Admin: Aktifkan atau matikan fitur AI Chat agar diketahui semua member')
      .addBooleanOption(opt => opt.setName('aktif').setDescription('Pilih status keaktifan').setRequired(true))
    )
    
    // Subcommand: INFO SEKARANG
    .addSubcommand(sub => sub
      .setName('info')
      .setDescription('Lihat status konfigurasi AI & Panduan cara mendapatkan API Key')
    )

    // Subcommand: HAPUS INGATAN MEMORI AI
    .addSubcommand(sub => sub
      .setName('clear')
      .setDescription('Bersihkan/reset seluruh ingatan memori percakapan AI Groq saat ini')
    ),

  async execute(interaction) {
    const subcommand = interaction.options.getSubcommand();
    const db = readDB();

    if (['channel', 'apikey', 'status'].includes(subcommand)) {
      if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
        return interaction.reply({ content: '❌ Anda tidak memiliki izin Administrator untuk mengubah pengaturan ini.', ephemeral: true });
      }
    }

    if (subcommand === 'channel') {
      const channel = interaction.options.getChannel('target');
      if (channel.type !== 0) {
        return interaction.reply({ content: '❌ **Gagal:** Harap pilih channel bertipe **Teks biasa**!', ephemeral: true });
      }

      db.channelId = channel.id;
      writeDB(db);
      return interaction.reply({ content: `✅ **Sukses:** Channel AI diatur ke <#${channel.id}>.`, ephemeral: true });
    }

    if (subcommand === 'apikey') {
      const key = interaction.options.getString('key').trim();
      db.apiKey = key;
      writeDB(db);
      return interaction.reply({ content: '✅ **Sukses:** API Key Groq AI berhasil disimpan dengan aman!', ephemeral: true });
    }

    // Status terlihat publik menggunakan Embed informatif
    if (subcommand === 'status') {
      const aktif = interaction.options.getBoolean('aktif');
      db.enabled = aktif;
      writeDB(db);

      const embedStatus = new EmbedBuilder()
        .setAuthor({ name: 'Sistem Informasi AI Server', iconURL: interaction.guild.iconURL({ dynamic: true }) })
        .setTimestamp();

      if (aktif) {
        embedStatus
          .setColor('#2ECC71')
          .setTitle('FITUR AI AKTIF')
          .setDescription(`Hallow bre! Fitur **Groq AI (Llama 3.1)** sudah **AKTIF**. <#${db.channelId}>!`);
      } else {
        embedStatus
          .setColor('#E74C3C')
          .setTitle('FITUR AI CHAT MATOT')
          .setDescription('Fitur **Groq AI (Llama 3.1)** di **NONAKTIFKAN** oleh Administrator.');
      }

      return interaction.reply({ embeds: [embedStatus] });
    }

    if (subcommand === 'clear-memory') {
      global.aiMemory.clear();
      return interaction.reply({ content: '🗑️ **Info:** Seluruh ingatan BOT telah dihapus!' });
    }

    if (subcommand === 'info') {
      const activeChannel = db.channelId ? `<#${db.channelId}>` : '`Belum ditentukan`';
      const keyStatus = db.apiKey ? '`Tersedia (Sangat Aman) 🔑`' : '`Belum dimasukkan ❌`';
      const systemStatus = db.enabled ? '🟢 Aktif' : '🔴 Nonaktif';

      const embedInfo = new EmbedBuilder()
        .setColor('#F1C40F')
        .setTitle('⚡ KONFIGURASI AI CHAT GROQ (LLAMA 3.1)')
        .addFields(
          { name: '📺 Channel AI', value: activeChannel, inline: true },
          { name: '🔐 Status API Key', value: keyStatus, inline: true },
          { name: '⚡ Status Fitur', value: systemStatus, inline: true },
          { 
            name: '🔑 Di mana mendapatkan API Key Groq?', 
            value: [
              'Anda bisa mendapatkan API Key Groq secara **Gratis**:',
              '1. Buka situs web **Groq Console**: https://console.groq.com/',
              '2. Login menggunakan Akun Google atau GitHub Anda.',
              '3. Klik menu **"API Keys"** di panel sebelah kiri.',
              '4. Klik tombol **"Create API Key"**, beri nama bebas, lalu salin kodenya.',
              '5. Masukkan ke bot menggunakan perintah: `/ai apikey key: [gsk_...]`'
            ].join('\n'), 
            inline: false 
          }
        )
        .setTimestamp();

      return interaction.reply({ embeds: [embedInfo], ephemeral: true });
    }
  }
};