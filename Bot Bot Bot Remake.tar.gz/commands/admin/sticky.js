const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
const dbPath = path.join(__dirname, '../../stickyData.json');

// Fungsi pembantu membaca & menulis database
function readDB() {
  if (!fs.existsSync(dbPath)) fs.writeFileSync(dbPath, '{}');
  return JSON.parse(fs.readFileSync(dbPath, 'utf8'));
}
function writeDB(data) {
  fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('sticky')
    .setDescription('Manajemen fitur Sticky Message di channel')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    
    // Subcommand 1: SET (Pasang Baru)
    .addSubcommand(sub => sub
      .setName('set')
      .setDescription('Pasang sticky message baru di channel ini')
      .addStringOption(opt => opt.setName('tipe').setDescription('Pilih format pesan').setRequired(true).addChoices(
        { name: '📝 Teks Biasa', value: 'text' },
        { name: '🖼️ Embed Premium', value: 'embed' }
      ))
      .addStringOption(opt => opt.setName('konten').setDescription('Isi pesan (Gunakan \\n untuk baris baru)').setRequired(true))
      .addStringOption(opt => opt.setName('judul').setDescription('Khusus tipe Embed: Tentukan judul atas embed').setRequired(false))
      .addStringOption(opt => opt.setName('warna').setDescription('Khusus tipe Embed: Kode Hex Warna (Contoh: #FF0000)').setRequired(false))
    )
    
    // Subcommand 2: EDIT (Ubah Isi)
    .addSubcommand(sub => sub
      .setName('edit')
      .setDescription('Ubah isi konten sticky message yang sudah aktif di channel ini')
      .addStringOption(opt => opt.setName('konten').setDescription('Isi pesan terbaru Anda').setRequired(true))
      .addStringOption(opt => opt.setName('judul').setDescription('Ubah judul (Khusus tipe Embed)').setRequired(false))
    )
    
    // Subcommand 3: REMOVE (Hapus)
    .addSubcommand(sub => sub
      .setName('remove')
      .setDescription('Hapus dan matikan sticky message di channel ini')
    ),

  async execute(interaction) {
    const subcommand = interaction.options.getSubcommand();
    const channelId = interaction.channel.id;
    const db = readDB();

    // ───────────────── LOGIKA: SET STICKY ─────────────────
    if (subcommand === 'set') {
      const tipe = interaction.options.getString('tipe');
      const konten = interaction.options.getString('konten').replace(/\\n/g, '\n');
      const judul = interaction.options.getString('judul') || '📌 STICKY ANNOUNCEMENT';
      const warna = interaction.options.getString('warna') || '#5865F2';

      // Jika channel sudah punya sticky aktif, bersihkan pesan lamanya dulu di Discord
      if (db[channelId]) {
        const oldMsg = await interaction.channel.messages.fetch(db[channelId].lastMessageId).catch(() => null);
        if (oldMsg) await oldMsg.delete().catch(() => null);
      }

      // Kirim pesan pemicu pertama kalinya
      let freshMessage;
      if (tipe === 'text') {
        freshMessage = await interaction.channel.send({ content: konten });
      } else {
        const embed = new EmbedBuilder().setTitle(judul).setDescription(konten).setColor(warna).setTimestamp();
        freshMessage = await interaction.channel.send({ embeds: [embed] });
      }

      // Simpan konfigurasi ke dalam database lokal
      db[channelId] = {
        tipe,
        konten,
        judul,
        warna,
        lastMessageId: freshMessage.id
      };
      writeDB(db);

      return interaction.reply({ content: `✅ **Sukses:** Sticky message berformat **${tipe.toUpperCase()}** berhasil diaktifkan di channel ini!`, ephemeral: true });
    }

    // ───────────────── LOGIKA: EDIT STICKY ─────────────────
    if (subcommand === 'edit') {
      if (!db[channelId]) {
        return interaction.reply({ content: '❌ **Gagal:** Tidak ada sticky message yang aktif di channel ini untuk diedit.', ephemeral: true });
      }

      const kontenBaru = interaction.options.getString('konten').replace(/\\n/g, '\n');
      const judulBaru = interaction.options.getString('judul');

      db[channelId].konten = kontenBaru;
      if (judulBaru) db[channelId].judul = judulBaru;

      // Ambil pesan lama dan langsung lakukan edit instan di tempat jika memungkinkan
      const oldMsg = await interaction.channel.messages.fetch(db[channelId].lastMessageId).catch(() => null);
      if (oldMsg) {
        if (db[channelId].tipe === 'text') {
          await oldMsg.edit({ content: kontenBaru }).catch(() => null);
        } else {
          const updatedEmbed = EmbedBuilder.from(oldMsg.embeds[0]).setDescription(kontenBaru);
          if (judulBaru) updatedEmbed.setTitle(judulBaru);
          await oldMsg.edit({ embeds: [updatedEmbed] }).catch(() => null);
        }
      }
      
      writeDB(db);
      return interaction.reply({ content: '✅ **Sukses:** Konten data sticky message berhasil diperbarui!', ephemeral: true });
    }

    // ───────────────── LOGIKA: REMOVE STICKY ─────────────────
    if (subcommand === 'remove') {
      if (!db[channelId]) {
        return interaction.reply({ content: '❌ **Info:** Channel ini memang tidak memiliki sticky message aktif.', ephemeral: true });
      }

      // Hapus pesan fisik terakhirnya dari ruang obrolan Discord
      const oldMsg = await interaction.channel.messages.fetch(db[channelId].lastMessageId).catch(() => null);
      if (oldMsg) await oldMsg.delete().catch(() => null);

      // Buang data dari memory JSON
      delete db[channelId];
      writeDB(db);

      return interaction.reply({ content: '🗑️ **Sukses:** Sticky message telah dicabut dan dinonaktifkan dari channel ini.', ephemeral: true });
    }
  }
};


