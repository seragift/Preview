const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('deletechannel')
    .setDescription('Hapus banyak channel sekaligus (paste mention atau ID, max 10)')
    .addStringOption(o =>
      o.setName('daftar')
        .setDescription('Mention / ID channel dipisah spasi, contoh: #spam 123456789012345678')
        .setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),

  async execute(interaction) {
    const raw = interaction.options.getString('daftar');

    // ambil semua angka 17-19 digit dari mention/ID (<#123> atau 123)
    const ids = [...raw.matchAll(/\d{17,19}/g)].map(m => m[0]).slice(0, 10);

    if (!ids.length) {
      return interaction.reply({ content: '❌ Tidak ada ID channel valid.', ephemeral: true });
    }

    await interaction.reply({ content: `⏳ Menghapus ${ids.length} channel…`, ephemeral: true });

    const results = [];

    for (const id of ids) {
      const ch = await interaction.guild.channels.fetch(id).catch(() => null);
      if (!ch) {
        results.push(`❌ <#${id}> (tidak ditemukan)`);
        continue;
      }

      try {
        await ch.delete(`Dihapus oleh ${interaction.user.tag} via /deletechannel`);
        results.push(`✅ ${ch.name}`);
      } catch (e) {
        results.push(`❌ ${ch.name} (${e.message})`);
      }
    }

    await interaction.editReply({ content: `**Hasil:**\n${results.join('\n')}`, ephemeral: true });
  }
};