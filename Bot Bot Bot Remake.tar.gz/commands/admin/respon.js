const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
const dbPath = path.join(__dirname, '../../responderData.json');

function readDB() {
  if (!fs.existsSync(dbPath)) fs.writeFileSync(dbPath, '{}');
  return JSON.parse(fs.readFileSync(dbPath, 'utf8'));
}

function writeDB(data) {
  fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('respon')
    .setDescription('Manajemen fitur Auto Responder (Tambah/Edit/Hapus)')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    
    // Subcommand: TAMBAH ATAU EDIT
    .addSubcommand(sub => sub
      .setName('add')
      .setDescription('Tambah baru atau edit balasan kata kunci yang sudah ada')
      .addStringOption(opt => opt.setName('trigger').setDescription('Kata kunci pemicu').setRequired(true))
      .addStringOption(opt => opt.setName('balasan').setDescription('Isi pesan respons (Gunakan \\n untuk enter)').setRequired(true))
    )
    
    // Subcommand: LIHAT SEMUA DATA
    .addSubcommand(sub => sub
      .setName('list')
      .setDescription('Lihat daftar semua kata kunci yang terdaftar')
    )
    
    // Subcommand: HAPUS DATA (DENGAN PILIHAN OTOMATIS / AUTOCOMPLETE)
    .addSubcommand(sub => sub
      .setName('remove')
      .setDescription('Hapus kata kunci auto responder dari database')
      .addStringOption(opt => 
        opt.setName('trigger')
          .setDescription('Pilih kata kunci yang ingin dihapus')
          .setRequired(true)
          .setAutocomplete(true) // AKTIFKAN FITUR PILIHAN OTOMATIS
      )
    ),

  // ───────── FITUR AUTOCOMPLETE HANDLER ─────────
  async autocomplete(interaction) {
    const focusedValue = interaction.options.getFocused().toLowerCase();
    const db = readDB();
    const triggers = Object.keys(db);

    // Filter daftar trigger berdasarkan apa yang sedang diketik oleh admin
    const filtered = triggers.filter(choice => choice.toLowerCase().includes(focusedValue));

    // Discord membatasi maksimal 25 pilihan yang muncul di layar monitor
    const respondChoices = filtered.slice(0, 25).map(choice => ({ name: choice, value: choice }));

    await interaction.respond(respondChoices).catch(() => null);
  },

  // ───────── UTAMA EXECUTE COMMAND ─────────
  async execute(interaction) {
    const subcommand = interaction.options.getSubcommand();
    const db = readDB();

    // 1. LOGIKA: ADD / EDIT
    if (subcommand === 'add') {
      const trigger = interaction.options.getString('trigger').toLowerCase().trim();
      const balasan = interaction.options.getString('balasan').replace(/\\n/g, '\n');

      if (trigger.length < 1) {
        return interaction.reply({ content: '❌ Trigger minimal harus terdiri dari 1 kata!', ephemeral: true });
      }

      const isEdit = db[trigger] !== undefined;
      db[trigger] = balasan;
      writeDB(db);

      return interaction.reply({
        content: isEdit 
          ? `📝 **Sukses Mengedit:** Data lama untuk pemicu \`${trigger}\` berhasil diperbarui!\n> 💬 **Balasan Baru:** ${balasan}`
          : `✅ **Sukses Menambahkan:** Auto responder baru berhasil disimpan!\n> 📋 **Trigger:** \`${trigger}\`\n> 💬 **Balasan:** ${balasan}`,
        ephemeral: true
      });
    }

    // 2. LOGIKA: LIST DATA
    if (subcommand === 'list') {
      const triggers = Object.keys(db);

      if (triggers.length === 0) {
        return interaction.reply({ content: 'ℹ️ Belum ada data auto responder yang terdaftar di database.', ephemeral: true });
      }

      const embedList = new EmbedBuilder()
        .setColor('#5865F2')
        .setTitle('🗂️ DAFTAR AUTO RESPONDER AKTIF')
        .setDescription('Gunakan `/respon add` dengan kata kunci yang sama jika ingin mengedit isinya.')
        .setTimestamp();

      triggers.forEach((trig, index) => {
        const shortReply = db[trig].length > 100 ? db[trig].substring(0, 95) + '...' : db[trig];
        embedList.addFields({ name: `${index + 1}. Pemicu: "${trig}"`, value: `↳ *${shortReply}*`, inline: false });
      });

      return interaction.reply({ embeds: [embedList], ephemeral: true });
    }

    // 3. LOGIKA: REMOVE (HAPUS DATA DENGAN SISTEM AUTOCOMPLETE)
    if (subcommand === 'remove') {
      const trigger = interaction.options.getString('trigger').toLowerCase().trim();

      if (!db[trigger]) {
        return interaction.reply({ 
          content: `❌ **Gagal:** Kata kunci \`${trigger}\` tidak valid atau tidak terdaftar di dalam data database saat ini.`, 
          ephemeral: true 
        });
      }

      // Jalankan proses hapus data dari object JSON
      delete db[trigger];
      writeDB(db);

      return interaction.reply({ 
        content: `🗑️ **Sukses Dihapus:** Kata kunci \`${trigger}\` resmi dihapus! Bot tidak akan merespons kata tersebut lagi.`, 
        ephemeral: true 
      });
    }
  }
};
