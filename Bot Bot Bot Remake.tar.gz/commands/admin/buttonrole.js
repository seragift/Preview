const { 
  SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder, 
  ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle 
} = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('buttonrole')
    .setDescription('Buat panel self-role interaktif menggunakan tombol')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addRoleOption(opt => 
      opt.setName('role')
        .setDescription('Role yang akan diberikan saat tombol diklik')
        .setRequired(true)
    )
    .addStringOption(opt => 
      opt.setName('emoji')
        .setDescription('Emoji untuk tombol (Opsional, gunakan emoji bawaan atau ID emoji custom)')
        .setRequired(false)
    ),

  async execute(interaction) {
    const targetRole = interaction.options.getRole('role');
    const emoji = interaction.options.getString('emoji') || null;

    // Proteksi: Mencegah admin memilih role @everyone atau bot itu sendiri
    if (targetRole.id === interaction.guild.id) {
      return interaction.reply({ content: '❌ Anda tidak bisa menggunakan role `@everyone`.', ephemeral: true });
    }

    // Buat Modal Pop-up untuk input teks kustom dari Admin
    const modal = new ModalBuilder()
      .setCustomId(`br_modal_${targetRole.id}_${emoji || 'noemoji'}`)
      .setTitle('CONFIG PANEL BUTTON ROLE');

    const inputTitle = new TextInputBuilder()
      .setCustomId('br_title')
      .setLabel('Judul Embed')
      .setStyle(TextInputStyle.Short)
      .setPlaceholder('Contoh: VERIFIKASI MEMBER / AMBIL ROLE')
      .setRequired(true);

    const inputDesc = new TextInputBuilder()
      .setCustomId('br_desc')
      .setLabel('Deskripsi Embed')
      .setStyle(TextInputStyle.Paragraph)
      .setPlaceholder('Contoh: Silakan klik tombol di bawah ini untuk mendapatkan akses ke server!')
      .setRequired(true);

    const inputButtonName = new TextInputBuilder()
      .setCustomId('br_btnname')
      .setLabel('Nama / Label Tombol')
      .setStyle(TextInputStyle.Short)
      .setPlaceholder('Contoh: Dapatkan Role')
      .setRequired(true);

    // Satukan input ke dalam baris komponen modal
    modal.addComponents(
      new ActionRowBuilder().addComponents(inputTitle),
      new ActionRowBuilder().addComponents(inputDesc),
      new ActionRowBuilder().addComponents(inputButtonName)
    );

    // Tampilkan modal ke layar monitor admin
    return interaction.showModal(modal);
  }
};


