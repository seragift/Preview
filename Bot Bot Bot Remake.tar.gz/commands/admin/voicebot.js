const { SlashCommandBuilder } = require('discord.js');
const { joinVoiceChannel, getVoiceConnection } = require('@discordjs/voice');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('join')
        .setDescription('Menyuruh bot masuk ke Voice Channel kamu secara 24/7'),

    async execute(interaction) {
        // Mengecek apakah user yang mengetik command sedang berada di dalam Voice Channel
        const voiceChannel = interaction.member.voice.channel;

        if (!voiceChannel) {
            return interaction.reply({ 
                content: '❌ Kamu harus berada di dalam Voice Channel terlebih dahulu agar bot bisa bergabung!', 
                ephemeral: true // Hanya bisa dilihat oleh user tersebut
            });
        }

        // Mengecek apakah bot sudah ada di Voice Channel tersebut
        const existingConnection = getVoiceConnection(voiceChannel.guild.id);
        if (existingConnection && existingConnection.joinConfig.channelId === voiceChannel.id) {
            return interaction.reply({ 
                content: '⚠️ Bot sudah berada di Voice Channel kamu.', 
                ephemeral: true 
            });
        }

        try {
            // Proses Bot masuk ke Voice Channel
            joinVoiceChannel({
                channelId: voiceChannel.id,
                guildId: voiceChannel.guild.id,
                adapterCreator: voiceChannel.guild.voiceAdapterCreator,
                selfDeaf: true, // Bot otomatis Tuli (Deafen) untuk menghemat bandwidth
                selfMute: false
            });

            await interaction.reply({ 
                content: `✅ Berhasil bergabung ke **${voiceChannel.name}**! Bot akan menetap di sini (24/7).` 
            });

        } catch (error) {
            console.error(error);
            await interaction.reply({ 
                content: 'Terjadi kesalahan saat mencoba bergabung ke Voice Channel.', 
                ephemeral: true 
            });
        }
    },
};


