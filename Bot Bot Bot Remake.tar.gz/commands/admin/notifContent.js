const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { CONTENT_CHANNEL_ID, SELLER_ROLE_ID } = require('../../config.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('upload')
    .setDescription('Mengumumkan upload konten baru (YouTube/TikTok) ke server AzesZ Page')
    .addStringOption(option =>
      option.setName('judul')
        .setDescription('Masukkan judul konten / video baru Anda')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('link')
        .setDescription('Masukkan URL / link tautan konten (YouTube/TikTok/dll)')
        .setRequired(true)),

  async execute(interaction) {
    // Menahan interaksi agar bot tidak timeout
    await interaction.deferReply({ ephemeral: true });

    // Validasi Izin Akses (Seller / Admin)
    if (!interaction.member.roles.cache.has(SELLER_ROLE_ID) && !interaction.member.permissions.has('Administrator')) {
      return interaction.editReply({
        content: '❌ Kamu tidak memiliki izin akses untuk menggunakan perintah ini.'
      });
    }

    const judulKonten = interaction.options.getString('judul');
    let linkKonten = interaction.options.getString('link').trim(); // .trim() untuk menghapus spasi tidak sengaja

    const channelContent = await interaction.client.channels.fetch(CONTENT_CHANNEL_ID).catch(() => null);
    if (!channelContent) {
      return interaction.editReply({
        content: '❌ Gagal mengirim. Channel tujuan konten tidak ditemukan! Periksa kembali file config.json.'
      });
    }

    // 🔧 PERBAIKAN VALIDASI LINK: Menggunakan RegEx yang mendukung query string (? & = dll)
    const urlPattern = /^https?:\/\/(www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&//=]*)$/;
    
    if (!urlPattern.test(linkKonten)) {
      return interaction.editReply({
        content: '❌ Link yang kamu masukkan tidak valid! Pastikan format link diawali dengan http:// atau https:// dan tidak mengandung spasi.'
      });
    }

    const pesanKontenRaw = 
      `📢 @everyone\n` +
      `**${interaction.user.displayName}** telah posting vidio baru!\n\n` +
      `📌 **${judulKonten}**\n` +
      `${linkKonten}`;

    const rowButton = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setLabel('Watch Video 🔗')
        .setURL(linkKonten)
        .setStyle(ButtonStyle.Link)
    );

    try {
      // Kirim pesan ke channel konten upload
      const sentMessage = await channelContent.send({ 
        content: pesanKontenRaw,
        components: [rowButton]
      });

      // 3️⃣ SENTUHAN SEMPURNA: Otomatis memberikan reaksi emoji checkmark setelah terkirim
      await sentMessage.react('✅').catch(() => null);

      await interaction.editReply({
        content: `✅ **Sistem Berhasil!** Konten berjudul *"${judulKonten}"* resmi di-upload ke <#${CONTENT_CHANNEL_ID}>.`
      });
    } catch (error) {
      console.error('❌ Gagal mengeksekusi perintah upload:', error);
      await interaction.editReply({
        content: '❌ Terjadi kesalahan internal sistem saat mencoba mengirim pesan pengumuman.'
      });
    }
  }
};


