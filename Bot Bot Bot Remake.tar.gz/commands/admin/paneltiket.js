const {
  SlashCommandBuilder, EmbedBuilder,
  ActionRowBuilder, ButtonBuilder, ButtonStyle,
} = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('panelticket')
    .setDescription('Pasang panel tiket'),

  async execute(interaction) {
    if (!interaction.member.permissions.has('Administrator')) {
      return interaction.reply({ content: '⛔ Hanya Administrator yang dapat memasang panel tiket.', ephemeral: true });
    }

    const embed = new EmbedBuilder()
      .setColor(0x2B2D31)
      .setAuthor({
        name: 'NanoSpray Panel Ticket',
        iconURL: interaction.guild.iconURL({ dynamic: true }),
      })
      .setTitle('Create Ticket | NanoSpary')
      .setDescription(
        '-# Pilih kategori yang sesuai, lalu ikuti langkah berikutnya.\n\n' +
        '<a:keranjang:1534897798774788216> **Order**\n' +
        '> Pembelian layanan, produk, atau jasa baru.\n\n' +
        '<a:suspray:1534898079399022652> **Ask/Rewaed**\n' +
        '> Pertanyaan seputar produk atau diskusi umum dan claim hadiah dari admin hasil giveaway.\n\n' +
        '<a:sield:1534897921084887040> **Claim Garansi**\n' +
        '> Kendala teknis atau pengajuan garansi setalah pembelian wajib mengrimkan bukti.'
      )
      .setImage('https://cdn.discordapp.com/attachments/1534236385337282640/1534869702541705386/standard.gif?ex=6a75b24d&is=6a7460cd&hm=aae41688ffed0a7e6736a08778137b1ab49af151ef16c61568fdafe3df98f625&')
      .setFooter({ text: 'Gunakan tiket dengan bijak' });

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('t_init_order').setLabel('Order').setEmoji('<a:keranjang:1534897798774788216>').setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId('t_init_tanya').setLabel('Ask/Reward').setEmoji('<a:suspray:1534898079399022652>').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('t_init_garansi').setLabel('Claim Garansi').setEmoji('<a:sield:1534897921084887040>').setStyle(ButtonStyle.Danger),
    );

    await interaction.channel.send({ embeds: [embed], components: [row] });
    return interaction.reply({ content: '✅ Panel tiket berhasil dipasang!', ephemeral: true });
  },
};
