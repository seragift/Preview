const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { SELLER_ROLE_ID } = require('../../config.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('payment')
    .setDescription('Buat invoice pembayaran kustom untuk pembeli (AzesZ Page)')
    .addUserOption(option =>
      option.setName('pembeli')
        .setDescription('Pilih user pembeli yang harus membayar')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('produk')
        .setDescription('Nama produk / jasa yang dibeli')
        .setRequired(true))
    .addNumberOption(option =>
      option.setName('harga')
        .setDescription('Total harga yang harus dibayar (Angka saja, contoh: 50000)')
        .setRequired(true)),

  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });

    // Validasi izin akses Seller atau Administrator
    if (!interaction.member.roles.cache.has(SELLER_ROLE_ID) && !interaction.member.permissions.has('Administrator')) {
      return interaction.editReply({ content: '❌ Kamu tidak memiliki izin akses untuk membuat link pembayaran.' });
    }

    const pembeli = interaction.options.getUser('pembeli');
    const produk = interaction.options.getString('produk');
    const harga = interaction.options.getNumber('harga');

    if (pembeli.bot) return interaction.editReply({ content: '❌ Tidak bisa membuat tagihan pembayaran untuk bot.' });

  
    const formatRupiah = new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(harga)
    
    const embedInvoice = new EmbedBuilder()
      .setColor('#2B2D31')
      .setTitle('Tagihan Pembayaran | NanoSpray')
      .setDescription(
        `Halo <@${pembeli.id}>, Silakan pilih salah satu metode pembayaran.`
      )
      .addFields(
        { name: '👤 Kepada', value: `<@${pembeli.id}>`, inline: true },
        { name: '🛒 Produk', value: `${produk}`, inline: true },
        { name: '💰 Tagihan', value: `**${formatRupiah}**`, inline: false }
      )
      .setThumbnail(pembeli.displayAvatarURL({ dynamic: true }))
      .setTimestamp()
      .setFooter({ text: 'NanoSpray • Metode Pembayaran' });

    // TOMBOL METODE PEMBAYARAN
    // Menyimpan data harga, pembeli, dan produk ke dalam customId button agar bisa dibaca di handler
    const rowPayment = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`pay_gopay_${pembeli.id}_${harga}`)
        .setLabel('GOPAY')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId(`pay_dana_${pembeli.id}_${harga}`)
        .setLabel('DANA')
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId(`pay_qris_${pembeli.id}_${harga}`)
        .setLabel('QRIS')
        .setStyle(ButtonStyle.Secondary)
    );

    try {
      // Kirim Invoice terbuka ke channel agar bisa dilihat pembeli
      await interaction.channel.send({
        content: `<@${pembeli.id}>!`,
        embeds: [embedInvoice],
        components: [rowPayment]
      });

      await interaction.editReply({ content: `✅ Invoice sukses diterbitkan untuk <@${pembeli.id}>.` });
    } catch (error) {
      console.error(error);
      await interaction.editReply({ content: '❌ Terjadi kesalahan saat mencoba menerbitkan invoice pembayaran.' });
    }
  }
};


