const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('embed')
        .setDescription('Kelola embed bot')
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
        .addSubcommand(subcommand =>
            subcommand
                .setName('create')
                .setDescription('Buat embed baru')
                .addStringOption(option => option.setName('judul').setDescription('Judul embed').setRequired(true))
                .addStringOption(option => option.setName('isi').setDescription('Isi embed').setRequired(true))
                .addStringOption(option => option.setName('warna').setDescription('Kode warna HEX, contoh: #FF0000').setRequired(false))
                .addAttachmentOption(option => option.setName('gambar1').setDescription('Gambar utama (image)').setRequired(false))
                .addAttachmentOption(option => option.setName('gambar2').setDescription('Gambar thumbnail').setRequired(false))
                .addAttachmentOption(option => option.setName('gambar3').setDescription('Gambar footer').setRequired(false))
                .addAttachmentOption(option => option.setName('gambar4').setDescription('Gambar author').setRequired(false))
        )
        .addSubcommand(subcommand =>
            subcommand
                .setName('edit')
                .setDescription('Edit embed yang sudah ada')
                .addStringOption(option => option.setName('id').setDescription('ID pesan embed').setRequired(true))
                .addStringOption(option => option.setName('judul').setDescription('Judul baru').setRequired(false))
                .addStringOption(option => option.setName('isi').setDescription('Isi baru').setRequired(false))
                .addStringOption(option => option.setName('warna').setDescription('Kode warna HEX baru').setRequired(false))
                .addAttachmentOption(option => option.setName('gambar1').setDescription('Gambar utama baru').setRequired(false))
                .addAttachmentOption(option => option.setName('gambar2').setDescription('Gambar thumbnail baru').setRequired(false))
                .addAttachmentOption(option => option.setName('gambar3').setDescription('Gambar footer baru').setRequired(false))
        ),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();

        if (subcommand === 'create') {
            const judul = interaction.options.getString('judul');
            const isi = interaction.options.getString('isi');
            const warna = interaction.options.getString('warna');
            const gambar1 = interaction.options.getAttachment('gambar1');
            const gambar2 = interaction.options.getAttachment('gambar2');
            const gambar3 = interaction.options.getAttachment('gambar3');
            const gambar4 = interaction.options.getAttachment('gambar4');

            const embed = new EmbedBuilder()
                .setTitle(judul)
                .setDescription(isi)
                .setTimestamp();

            if (warna) {
                const hexColor = warna.startsWith('#') ? warna : `#${warna}`;
                embed.setColor(hexColor);
            }

            if (gambar1) embed.setImage(gambar1.url);
            if (gambar2) embed.setThumbnail(gambar2.url);
            if (gambar3) embed.setFooter({ text: interaction.guild.name, iconURL: gambar3.url });
            if (gambar4) embed.setAuthor({ name: interaction.user.username, iconURL: gambar4.url });

            await interaction.deferReply();
            await interaction.deleteReply();
            return await interaction.channel.send({ embeds: [embed] });
        }

        if (subcommand === 'edit') {
            const messageId = interaction.options.getString('id');
            const judul = interaction.options.getString('judul');
            const isi = interaction.options.getString('isi');
            const warna = interaction.options.getString('warna');
            const gambar1 = interaction.options.getAttachment('gambar1');
            const gambar2 = interaction.options.getAttachment('gambar2');
            const gambar3 = interaction.options.getAttachment('gambar3');

            try {
                const targetMessage = await interaction.channel.messages.fetch(messageId);

                if (targetMessage.author.id !== interaction.client.user.id) {
                    await interaction.deferReply();
                    return await interaction.deleteReply();
                }

                const existingEmbed = targetMessage.embeds[0];
                if (!existingEmbed) {
                    await interaction.deferReply();
                    return await interaction.deleteReply();
                }

                const updatedEmbed = EmbedBuilder.from(existingEmbed)
                    .setTimestamp();

                if (judul) updatedEmbed.setTitle(judul);
                if (isi) updatedEmbed.setDescription(isi);
                if (warna) {
                    const hexColor = warna.startsWith('#') ? warna : `#${warna}`;
                    updatedEmbed.setColor(hexColor);
                }

                if (gambar1) updatedEmbed.setImage(gambar1.url);
                if (gambar2) updatedEmbed.setThumbnail(gambar2.url);
                if (gambar3) {
                    const currentFooterText = existingEmbed.footer ? existingEmbed.footer.text : interaction.guild.name;
                    updatedEmbed.setFooter({ text: currentFooterText, iconURL: gambar3.url });
                }

                await targetMessage.edit({ embeds: [updatedEmbed] });
                await interaction.deferReply();
                return await interaction.deleteReply();

            } catch (error) {
                await interaction.deferReply();
                return await interaction.deleteReply();
            }
        }
    },
};
