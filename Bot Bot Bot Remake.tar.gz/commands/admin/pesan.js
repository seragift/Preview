const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('pesan')
    .setDescription('Mengirimkan pesan teks biasa melalui bot')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addStringOption(option =>
      option
        .setName('isi')
        .setDescription('Isi pesan yang ingin dikirim')
        .setRequired(true)
    )
    .addAttachmentOption(option =>
      option
        .setName('gambar1')
        .setDescription('Lampiran gambar 1 (opsional)')
        .setRequired(false)
    )
    .addAttachmentOption(option =>
      option
        .setName('gambar2')
        .setDescription('Lampiran gambar 2 (opsional)')
        .setRequired(false)
    )
    .addAttachmentOption(option =>
      option
        .setName('gambar3')
        .setDescription('Lampiran gambar 3 (opsional)')
        .setRequired(false)
    )
    .addAttachmentOption(option =>
      option
        .setName('gambar4')
        .setDescription('Lampiran gambar 4 (opsional)')
        .setRequired(false)
    )
    .addAttachmentOption(option =>
      option
        .setName('gambar5')
        .setDescription('Lampiran gambar 5 (opsional)')
        .setRequired(false)
    ),

  async execute(interaction) {
    if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
      return interaction.reply({
        content: '❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.',
        ephemeral: true,
      });
    }

    const isiPesan = interaction.options.getString('isi');
    const gambar1 = interaction.options.getAttachment('gambar1');
    const gambar2 = interaction.options.getAttachment('gambar2');
    const gambar3 = interaction.options.getAttachment('gambar3');
    const gambar4 = interaction.options.getAttachment('gambar4');
    const gambar5 = interaction.options.getAttachment('gambar5');

    const files = [];
    if (gambar1) files.push(gambar1.url);
    if (gambar2) files.push(gambar2.url);
    if (gambar3) files.push(gambar3.url);
    if (gambar4) files.push(gambar4.url);
    if (gambar5) files.push(gambar5.url);

    const messageData = { content: isiPesan };
    if (files.length > 0) {
      messageData.files = files;
    }

    await interaction.channel.send(messageData);

    return interaction.reply({
      content: '✅ Pesan berhasil dikirim!',
      ephemeral: true,
    });
  },
};