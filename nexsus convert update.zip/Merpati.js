const { 

    Client, 

    GatewayIntentBits, 

    EmbedBuilder,

    REST, 

    Routes, 

    ApplicationCommandOptionType 

} = require('discord.js');

const ytsr = require('ytsr'); 

const path = require('path');

const fs = require('fs');

// --- PATH FILE KONFIGURASI ---

const CHANNEL_CONFIG_PATH = path.join(__dirname, 'channelConfig.json');

const VIP_CONFIG_PATH = path.join(__dirname, 'vipConfig.json');

const CONVERSION_DATA_PATH = path.join(__dirname, 'conversionData.json');

const VIP_DISPLAY_CONFIG_PATH = path.join(__dirname, 'vipDisplayConfig.json'); // BARU

// -----------------------------

// --- KONFIGURASI BATAS VIP ---

const VIP_LIMITS = {

    'Non-VIP': { maxConversions: 3, maxDurationMinutes: 30, durationText: '30 Menit' },

    'VIP 1': { maxConversions: 10, maxDurationMinutes: 60, durationText: '60 Menit' },

    'VIP 2': { maxConversions: 20, maxDurationMinutes: 120, durationText: '120 Menit' },

    'VIP 3': { maxConversions: 30, maxDurationMinutes: Infinity, durationText: 'Unlimited' }

};

// -----------------------------

// --- MUAT KONFIGURASI DARI config.json ---

let TOKEN;

let OWNER_ID; 

try {

    const config = require('./config.json');

    if (!config.token || !config.ownerId) {

        throw new Error("Token atau Owner ID bot tidak ditemukan di config.json.");

    }

    TOKEN = config.token;

    OWNER_ID = config.ownerId; 

} catch (e) {

    console.error("Gagal memuat config.json. Pastikan file ada dan berisi 'token' dan 'ownerId'.", e.message);

    process.exit(1);

}

// ----------------------------------------

const YOUTUBE_ID_REGEX = /(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([a-zA-Z0-9_-]{11})/i;

const TIKTOK_URL_REGEX = /https:\/\/(?:www\.|vt\.)?tiktok\.com\/[^\s]+/i; 

const SPECIFIC_PLACEHOLDER_LINK = 'https://b.top4top.io/m_3601orj5l1.mp3';

const bot = new Client({ 

    intents: [

        GatewayIntentBits.Guilds,

        GatewayIntentBits.GuildMessages,

        GatewayIntentBits.MessageContent 

    ]

});

// =========================================================

//                  STATE & FUNGSI KONFIGURASI FILE

// =========================================================

let allowedConversionChannels = {};

let vipUsers = {}; 

let dailyConversionCount = {}; 

let vipDisplayConfig = { channelId: null, messageId: null }; // STATE BARU

function loadChannelConfig() {

    if (fs.existsSync(CHANNEL_CONFIG_PATH)) {

        try {

            allowedConversionChannels = JSON.parse(fs.readFileSync(CHANNEL_CONFIG_PATH, 'utf8'));

        } catch (error) { console.error("Gagal membaca channelConfig.json:", error.message); }

    }

}

function saveChannelConfig() {

    try {

        fs.writeFileSync(CHANNEL_CONFIG_PATH, JSON.stringify(allowedConversionChannels, null, 2), 'utf8');

    } catch (error) { console.error("Gagal menulis ke channelConfig.json:", error.message); }

}

function loadVipConfig() {

    if (fs.existsSync(VIP_CONFIG_PATH)) {

        try {

            vipUsers = JSON.parse(fs.readFileSync(VIP_CONFIG_PATH, 'utf8'));

        } catch (error) { console.error("Gagal membaca vipConfig.json:", error.message); }

    }

    if (fs.existsSync(CONVERSION_DATA_PATH)) {

        try {

            dailyConversionCount = JSON.parse(fs.readFileSync(CONVERSION_DATA_PATH, 'utf8'));

        } catch (error) { console.error("Gagal membaca conversionData.json:", error.message); }

    }

}

function saveVipConfig() {

    try {

        fs.writeFileSync(VIP_CONFIG_PATH, JSON.stringify(vipUsers, null, 2), 'utf8');

    } catch (error) { console.error("Gagal menulis ke vipConfig.json:", error.message); }

}

function saveConversionData() {

    try {

        fs.writeFileSync(CONVERSION_DATA_PATH, JSON.stringify(dailyConversionCount, null, 2), 'utf8');

    } catch (error) { console.error("Gagal menulis ke conversionData.json:", error.message); }

}

// FUNGSI BARU

function loadVipDisplayConfig() {

    if (fs.existsSync(VIP_DISPLAY_CONFIG_PATH)) {

        try {

            vipDisplayConfig = JSON.parse(fs.readFileSync(VIP_DISPLAY_CONFIG_PATH, 'utf8'));

        } catch (error) { console.error("Gagal membaca vipDisplayConfig.json:", error.message); }

    }

}

// FUNGSI BARU

function saveVipDisplayConfig() {

    try {

        fs.writeFileSync(VIP_DISPLAY_CONFIG_PATH, JSON.stringify(vipDisplayConfig, null, 2), 'utf8');

    } catch (error) { console.error("Gagal menulis ke vipDisplayConfig.json:", error.message); }

}

loadChannelConfig(); 

loadVipConfig(); 

loadVipDisplayConfig(); // Panggil fungsi baru
// =========================================================

//                  FUNGSI UTILITY & EMBED

// =========================================================

// Mengubah durasi string seperti "3:45" menjadi total detik

function durationToSeconds(durationString) {

    if (!durationString || durationString === 'N/A') return 0;

    const parts = durationString.split(':').reverse(); 

    let seconds = 0;

    

    for (let i = 0; i < parts.length; i++) {

        seconds += parseInt(parts[i]) * Math.pow(60, i);

    }

    return seconds;

}

// Mendapatkan Status VIP Pengguna dan membersihkan data kadaluarsa

function getUserVipStatus(userId) {

    const now = Date.now();

    const userData = vipUsers[userId];

    if (userData && userData.expiry !== 0 && userData.expiry < now) {

        delete vipUsers[userId];

        saveVipConfig();

        return { level: 'Non-VIP', ...VIP_LIMITS['Non-VIP'] };

    }

    

    const level = userData ? userData.level : 'Non-VIP';

    return { level, ...VIP_LIMITS[level] };

}

// Memformat waktu kedaluwarsa

function formatExpiry(timestamp) {

    if (timestamp === 0) {

        return "Permanen";

    }

    const expiryDate = new Date(timestamp);

    const now = new Date();

    if (expiryDate < now) {

        return "Kedaluwarsa";

    }

    const formatter = new Intl.DateTimeFormat('id-ID', {

        year: 'numeric', month: 'short', day: '2-digit',

        hour: '2-digit', minute: '2-digit', hour12: false

    });

    return formatter.format(expiryDate) + ' WIB'; 

}

// Membuat Embed Benefit VIP untuk Pesan Pribadi (DM)

function createVipBenefitEmbed(user, level, durationText) {

    const limits = VIP_LIMITS[level];

    let color;

    

    if (level === 'VIP 3') color = '#FFD700';

    else if (level === 'VIP 2') color = '#C0C0C0';

    else if (level === 'VIP 1') color = '#A97142';

    else color = '#AAAAAA'; 

    const title = level === 'Non-VIP' 

        ? 'ℹ️ Status Anda Dikembalikan ke Non-VIP' 

        : `👑 Selamat, Anda sekarang adalah ${level}!`;

        

    const description = level === 'Non-VIP' 

        ? `Status VIP Anda telah dihapus atau kedaluwarsa. Anda kembali ke batas standar.`

        : `Anda mendapatkan akses ke batas konversi ${level} selama **${durationText}**!`;

    return new EmbedBuilder()

        .setColor(color)

        .setTitle(title)

        .setDescription(description)

        .addFields(

            { name: '👤 Pengguna', value: user.toString(), inline: false },

            { name: '⏱️ Durasi VIP', value: durationText, inline: true },

            { name: '✨ Benefit', value: `Maks Konversi/Hari: **${limits.maxConversions}x**\nMaks Durasi Video: **${limits.durationText}**`, inline: true }

        )

        .setTimestamp()

        .setFooter({ text: 'Terima kasih telah mendukung layanan kami!' });

}

// Mengambil metadata video YouTube

async function getVideoMetadata(videoId) { 

    try {

        const filters = await ytsr.getFilters(videoId);

        const videoFilter = filters.get('Type').get('Video');

        const results = await ytsr(videoFilter.url, { limit: 1 });

        

        if (!results.items || results.items.length === 0) return null;

        const item = results.items[0];

        const duration = item.duration || '0:00';

        

        return {

            source: 'YouTube', title: item.title, creator: item.author.name,

            duration: duration, thumbnail: item.bestThumbnail.url, url: item.url

        };

    } catch (error) { return null; }

}

// Metadata placeholder untuk TikTok

function getTikTokMetadata(url) {

    return {

        source: 'TikTok', title: `Video TikTok (Konversi Instan)`, 

        creator: `Link Pengguna: ${url.substring(0, 30)}...`, duration: 'N/A', 

        thumbnail: null, url: url

    };

}

// Membuat Embed Proses

function createProcessingEmbed(user, step = 1, type = 'YouTube') {

    let title, color, progressBar, description;

    const typeColors = {

        'YouTube': { c: '#FFA500', t: 'Video YouTube' },

        'TikTok': { c: '#E94F64', t: 'Link TikTok' },

    };

    

    const { c: baseColor, t: typeText } = typeColors[type] || typeColors['YouTube'];

    if (step === 1) {

        title = `🛠️ Proses Konversi Dimulai (1/2)`; color = baseColor;

        progressBar = '`[█⬜⬜⬜]` Mempersiapkan Proses...';

        description = `Permintaan ${typeText} dari **${user.tag}** diterima.`;

    } else if (step === 2) {

        title = `🔍 Sedang Menganalisis ${typeText} (2/2)`;

        color = (type === 'YouTube') ? '#FFD700' : '#FF69B4';

        progressBar = '`[███⬜]` Mengambil Metadata & Mempersiapkan Download...';

        description = `Bot sedang memproses ${typeText}.`;

    }

    return new EmbedBuilder()

        .setColor(color)

        .setTitle(title)

        .setDescription(description)

        .addFields({ name: 'Progres Konversi', value: progressBar, inline: false })

        .setTimestamp()

        .setFooter({ text: 'Convert by nexsus auto' });

}

// Membuat Embed Hasil

function createMusicEmbed(metadata, placeholderLink, user) { 

    const { source, title, creator, duration, url } = metadata;

    let color, sourceText;

    

    if (source === 'TikTok') {

        color = '#E94F64'; sourceText = 'TikTok Video (No WM)';

    } else { 

        color = '#FF0000'; sourceText = 'YouTube Video/Music';

    }

    return new EmbedBuilder()

        .setColor(color) 

        .setTitle(`✅ Konversi Berhasil! [${sourceText}]`)

        .setDescription(`**${title}** berhasil diproses untuk <@${user.id}>.`)

        .addFields(

            { name: '📝 Judul', value: title || 'N/A', inline: false },

            { name: '👤 Channel/Artis', value: creator || 'N/A', inline: true },

            { name: '⏱️ Durasi', value: duration || 'N/A', inline: true },

            { name: '🔗 Link Sumber', value: `[Klik di sini](${url})`, inline: true },

            { name: '⬇️ Link Download', value: placeholderLink, inline: false }

        )

        .setFooter({ text: `convert by nexsus auto | Sumber: ${source}`});

}

/**

 * Membuat Embed Daftar VIP (Hanya VIP 1, 2, 3)

 */

async function getVipListEmbed() {

    const activeVips = Object.entries(vipUsers).filter(([userId, data]) => {

        const isVipLevel = data.level !== 'Non-VIP';

        const isActive = data.expiry === 0 || data.expiry > Date.now();

        return isVipLevel && isActive;

    });

    const usernames = [];

    const levels = [];

    const expiryTimes = [];

    const sortOrder = { 'VIP 3': 3, 'VIP 2': 2, 'VIP 1': 1 };

    activeVips.sort(([, dataA], [, dataB]) => sortOrder[dataB.level] - sortOrder[dataA.level]);

    for (const [userId, data] of activeVips) {

        let usernameTag = `ID: ${userId}`;

        try {

            const user = await bot.users.fetch(userId, { force: false });

            usernameTag = user.tag;

        } catch {

        }

        usernames.push(`\`${usernameTag}\``);

        levels.push(data.level);

        expiryTimes.push(formatExpiry(data.expiry));

    }

    saveVipConfig(); 

    let description, fields;

    if (usernames.length === 0) {

        description = 'Saat ini tidak ada pengguna VIP aktif (VIP 1, 2, atau 3).';

        fields = [];

    } else {

        description = `Total **${usernames.length}** pengguna VIP aktif.`;

        fields = [

            { name: '👤 Username', value: usernames.join('\n').substring(0, 1024), inline: true },

            { name: '✨ Level', value: levels.join('\n').substring(0, 1024), inline: true },

            { name: '🗓️ Waktu Habis', value: expiryTimes.join('\n').substring(0, 1024), inline: true }

        ];

    }

    return new EmbedBuilder()

        .setColor('#2ecc71')

        .setTitle('👑 Daftar Pengguna VIP Aktif')

        .setDescription(description)

        .addFields(fields)

        .setTimestamp()

        .setFooter({ text: 'Diperbarui secara otomatis saat ada perubahan VIP. Non-VIP tidak ditampilkan.' });

}

/**

 * Fungsi untuk memicu update pada pesan daftar VIP.

 */

async function triggerVipListUpdate() {

    if (!vipDisplayConfig.channelId || !vipDisplayConfig.messageId) {

        return; 

    }

    

    try {

        const channel = bot.channels.cache.get(vipDisplayConfig.channelId);

        if (!channel) return;

        const newEmbed = await getVipListEmbed();

        

        const oldMessage = await channel.messages.fetch(vipDisplayConfig.messageId).catch(() => null);

        if (oldMessage) {

            await oldMessage.edit({ embeds: [newEmbed], content: null });

        } else {

            // Jika pesan hilang, hapus konfigurasi agar owner bisa menyetelnya lagi

            vipDisplayConfig = { channelId: null, messageId: null };

            saveVipDisplayConfig();

        }

    } catch (error) {

        console.error("Gagal mengupdate embed daftar VIP:", error.message);

    }

}
// =========================================================

//                      HANDLER UTAMA (handleConversion)

// =========================================================

async function handleConversion(message, type, linkMatch) {

    const guildId = message.guild.id;

    const channelId = message.channel.id;

    const userId = message.author.id;

    const today = new Date().toISOString().slice(0, 10);

    // 1. Pengecekan Batasan Saluran

    if (allowedConversionChannels[guildId] && allowedConversionChannels[guildId] !== channelId) {

        await message.delete().catch(() => {});

        return; 

    }

    

    // 2. Pengecekan dan Penentuan Batas VIP

    const userStatus = getUserVipStatus(userId);

    const { maxConversions, maxDurationMinutes, durationText, level } = userStatus;

    

    if (!dailyConversionCount[today]) dailyConversionCount[today] = {};

    const currentCount = dailyConversionCount[today][userId] || 0;

    // A. Cek Batas Harian Konversi

    if (currentCount >= maxConversions) {

        await message.delete().catch(() => {});

        

        // --- EMBED GAGAL: BATAS KONVERSI ---

        const limitEmbed = new EmbedBuilder()

            .setColor('#ff4444')

            .setTitle('🚫 Gagal Konversi: Batas Harian Tercapai')

            .setDescription(`Hai <@${userId}>, Anda saat ini **${level}** dan telah mencapai batas harian **${maxConversions}x** konversi.`)

            .addFields({ 

                name: '✨ Ingin Convert Lebih Banyak?', 

                value: 'Tingkatkan ke level **VIP** untuk mendapatkan batas konversi yang lebih tinggi (hingga **Unlimited**!). Hubungi Owner bot untuk detail upgrade.', 

                inline: false 

            })

            .setFooter({ text: `Batas Anda: ${maxConversions}x konversi per hari. Pesan akan hilang dalam 10 detik.` });

        

        return message.channel.send({ embeds: [limitEmbed] }).then(msg => setTimeout(() => msg.delete().catch(() => {}), 10000));

    }

    

    let processingMessage;

    try {

        const typeName = type === 'youtube' ? 'YouTube' : 'TikTok';

        

        await message.delete().catch(() => {});

        const processingEmbedStep1 = createProcessingEmbed(message.author, 1, typeName);

        processingMessage = await message.channel.send({ embeds: [processingEmbedStep1] });

        

        await new Promise(resolve => setTimeout(resolve, 750)); 

        

        const processingEmbedStep2 = createProcessingEmbed(message.author, 2, typeName);

        await processingMessage.edit({ embeds: [processingEmbedStep2] });

        

        let metadata;

        if (type === 'youtube') {

            const videoId = linkMatch[1];

            metadata = await getVideoMetadata(videoId);

            if (!metadata) throw new Error("Gagal mengambil metadata video YouTube.");

            

            // B. Cek Batas Durasi Video

            const videoSeconds = durationToSeconds(metadata.duration);

            const maxDurationSeconds = maxDurationMinutes * 60;

            

            if (videoSeconds > maxDurationSeconds) {

                await processingMessage.delete().catch(() => {});

                // --- EMBED GAGAL: BATAS DURASI ---

                const durationEmbed = new EmbedBuilder()

                    .setColor('#ff4444')

                    .setTitle('📏 Gagal Konversi: Video Terlalu Panjang')

                    .setDescription(`Video (${metadata.duration}) melebihi batas durasi **${durationText}** yang diizinkan untuk level **${level}** Anda.`)

                    .addFields(

                        { 

                            name: '✨ Ingin Durasi Lebih Panjang?', 

                            value: 'Upgrade ke **VIP 1/2** untuk batas durasi yang lebih besar, atau **VIP 3** untuk durasi **Unlimited**! Hubungi Owner bot untuk detail upgrade.', 

                            inline: false 

                        }

                    )

                    .setFooter({ text: `Video tidak diproses. Hitungan harian tidak bertambah. Pesan akan hilang dalam 15 detik.` });

                    

                return message.channel.send({ embeds: [durationEmbed] }).then(msg => setTimeout(() => msg.delete().catch(() => {}), 15000));

            }

        } else { // tiktok

            metadata = getTikTokMetadata(linkMatch[0]);

        }

        

        // C. Update Hitungan Konversi Harian

        dailyConversionCount[today][userId] = currentCount + 1;

        saveConversionData(); 

        const placeholderLink = SPECIFIC_PLACEHOLDER_LINK; 

        

        await new Promise(resolve => setTimeout(resolve, 750)); 

        

        const embed = createMusicEmbed(metadata, placeholderLink, message.author);

        

        await processingMessage.edit({ 

            content: `**Konversi Selesai!** (Konversi hari ini: ${currentCount + 1}/${maxConversions})`, 

            embeds: [embed] 

        });

    } catch (error) {

        console.error(`ERROR PADA KONVERSI ${type.toUpperCase()}:`, error.message); 

        

        const errorMessage = `❌ **Gagal memproses link!** Detail: \`${error.message.substring(0, 300)}\``;

        const errorEmbed = new EmbedBuilder().setColor('#FF0000').setTitle('❌ Proses Konversi Gagal!').setDescription(errorMessage).setFooter({ text: `Dicoba oleh: ${message.author.tag}` });

        

        if (processingMessage) { 

            await processingMessage.edit({ content: null, embeds: [errorEmbed] }); 

        } else { 

            message.channel.send({ content: `Hai <@${message.author.id}>, ${errorMessage}`, embeds: [] }); 

        }

    }

}
// =========================================================

//                     PENDAFTARAN SLASH COMMAND

// =========================================================

const commands = [

    {

        name: 'setchanel',

        description: 'Set saluran yang hanya diizinkan untuk konversi (HANYA OWNER).',

        options: [{ name: 'saluran', description: 'Saluran konversi.', type: ApplicationCommandOptionType.Channel, required: true, }],

    },

    {

        name: 'hapuschanel',

        description: 'Hapus batasan saluran konversi (HANYA OWNER).',

        options: [],

    },

    {

        name: 'setvip',

        description: 'Atur level VIP dan durasi untuk pengguna (HANYA OWNER).',

        options: [

            { name: 'user', description: 'Pengguna yang akan diatur VIP-nya.', type: ApplicationCommandOptionType.User, required: true, },

            { name: 'level', description: 'Pilih level VIP pengguna.', type: ApplicationCommandOptionType.String, required: true, choices: [

                    { name: 'Non-VIP', value: 'Non-VIP' }, { name: 'VIP 1', value: 'VIP 1' }, 

                    { name: 'VIP 2', value: 'VIP 2' }, { name: 'VIP 3', value: 'VIP 3' }

                ],

            },

            { name: 'durasi_hari', description: 'Durasi VIP dalam hari (0 untuk permanen, maks 30 hari).', type: ApplicationCommandOptionType.Integer, required: true, minValue: 0, maxValue: 30 }

        ],

    },

    {

        name: 'unvip',

        description: 'Hapus level VIP pengguna, mengembalikannya ke Non-VIP (HANYA OWNER).',

        options: [{ name: 'user', description: 'Pengguna yang akan dihapus status VIP-nya.', type: ApplicationCommandOptionType.User, required: true, }],

    },

    {

        name: 'listvip',

        description: 'Tampilkan daftar pengguna VIP aktif (hanya VIP 1/2/3).',

        options: [],

    },

    {

        name: 'setvipdisplay', // COMMAND BARU

        description: 'Mengatur pesan untuk daftar VIP auto-update (HANYA OWNER).',

        options: [

            {

                name: 'saluran',

                description: 'Saluran tempat daftar VIP akan diposting.',

                type: ApplicationCommandOptionType.Channel,

                required: true,

            }

        ],

    },

];

async function registerSlashCommands(clientId) {

    const rest = new REST({ version: '10' }).setToken(TOKEN);

    try {

        console.log('Memulai penyegaran (/) commands aplikasi.');

        await rest.put(Routes.applicationCommands(clientId), { body: commands });

        console.log('Berhasil memuat ulang (/) commands aplikasi secara global.');

    } catch (error) {

        console.error("Gagal mendaftarkan slash commands:", error);

    }

}

// =========================================================

//                          EVENT

// =========================================================

bot.on('ready', async () => {

    console.log(`Bot Merpati Lite siap! Logged in sebagai ${bot.user.tag}!`);

    bot.user.setActivity(`Otomatis convert link!`),
        bot.user.setActivity(`Made By Alex!`),
        
        
    await registerSlashCommands(bot.user.id);

});

bot.on('messageCreate', async message => {

    if (message.author.bot || !message.content || !message.guild) return;

    const tiktokMatch = message.content.match(TIKTOK_URL_REGEX);

    const youtubeMatch = message.content.match(YOUTUBE_ID_REGEX);

    if (tiktokMatch || youtubeMatch) {

        if (message.interaction) return; 

        

        if (tiktokMatch) {

            await handleConversion(message, 'tiktok', tiktokMatch);

        } else if (youtubeMatch) {

            await handleConversion(message, 'youtube', youtubeMatch);

        }

    }

});
// =========================================================

//                  HANDLER INTERAKSI SLASH COMMAND

// =========================================================

bot.on('interactionCreate', async interaction => {

    if (!interaction.isCommand() || !interaction.guild) return;

    const { commandName } = interaction;

    const guildId = interaction.guild.id;

    // Pengecekan Owner ID untuk semua command ini

    if (interaction.user.id !== OWNER_ID) {

        const errorEmbed = new EmbedBuilder()

            .setColor('#FF0000')

            .setTitle('Akses Ditolak')

            .setDescription('❌ Hanya **Owner Bot** yang diizinkan menggunakan perintah ini.')

            .setFooter({ text: 'Permintaan oleh: ' + interaction.user.tag });

        return interaction.reply({ embeds: [errorEmbed], ephemeral: true });

    }

    if (commandName === 'setchanel') {

        const channel = interaction.options.getChannel('saluran');

        if (!channel || channel.type !== 0) { 

            return interaction.reply({ content: '❌ Harap berikan saluran teks yang valid.', ephemeral: true });

        }

        allowedConversionChannels[guildId] = channel.id;

        saveChannelConfig();

        const successEmbed = new EmbedBuilder().setColor('#00FF00').setTitle('✅ Saluran Konversi Diatur').setDescription(`Semua konversi sekarang **hanya** akan diproses di saluran: ${channel}.`).setFooter({ text: 'Konfigurasi disimpan.' });

        await interaction.reply({ embeds: [successEmbed] });

        

    } else if (commandName === 'hapuschanel') {

        if (!allowedConversionChannels[guildId]) {

            return interaction.reply({ content: 'ℹ️ Tidak ada batasan saluran konversi yang saat ini diatur.', ephemeral: true });

        }

        delete allowedConversionChannels[guildId];

        saveChannelConfig(); 

        const successEmbed = new EmbedBuilder().setColor('#FFFF00').setTitle('✅ Batasan Saluran Dihapus').setDescription('Semua konversi sekarang dapat diproses di **saluran mana pun** di server ini.').setFooter({ text: 'Konfigurasi disimpan.' });

        await interaction.reply({ embeds: [successEmbed] });

    } else if (commandName === 'setvip') {

        const targetUser = interaction.options.getUser('user');

        const level = interaction.options.getString('level');

        const durationDays = interaction.options.getInteger('durasi_hari');

        const userId = targetUser.id;

        let expiryTime;

        let durationText;

        if (durationDays === 0) {

            expiryTime = 0; 

            durationText = 'Permanen';

        } else {

            const expiryDate = new Date();

            expiryDate.setDate(expiryDate.getDate() + durationDays);

            expiryTime = expiryDate.getTime();

            durationText = `${durationDays} hari`;

        }

        vipUsers[userId] = { level, expiry: expiryTime };

        saveVipConfig();

        // Panggil update setelah modifikasi data

        triggerVipListUpdate();

        // KIRIM DM OTOMATIS

        const dmEmbed = createVipBenefitEmbed(targetUser, level, durationText);

        targetUser.send({ embeds: [dmEmbed] }).catch(e => console.error(`Gagal mengirim DM ke ${targetUser.tag}: ${e.message}`));

        const successEmbed = new EmbedBuilder()

            .setColor('#0099ff').setTitle('👑 Level VIP Diperbarui').setDescription(`**${targetUser.tag}** telah diatur sebagai **${level}**!`)

            .addFields({ name: 'Level VIP', value: level, inline: true }, { name: 'Durasi', value: durationText, inline: true })

            .setFooter({ text: 'Konfigurasi disimpan.' });

            

        await interaction.reply({ embeds: [successEmbed] });

        

    } else if (commandName === 'unvip') {

        const targetUser = interaction.options.getUser('user');

        const userId = targetUser.id;

        

        if (!vipUsers[userId] || vipUsers[userId].level === 'Non-VIP') {

            return interaction.reply({ content: `ℹ️ **${targetUser.tag}** sudah berstatus Non-VIP atau tidak terdaftar sebagai VIP.`, ephemeral: true });

        }

        

        delete vipUsers[userId];

        saveVipConfig();

        // Panggil update setelah modifikasi data

        triggerVipListUpdate();

        // KIRIM DM OTOMATIS

        const dmEmbed = createVipBenefitEmbed(targetUser, 'Non-VIP', 'N/A');

        targetUser.send({ embeds: [dmEmbed] }).catch(e => console.error(`Gagal mengirim DM ke ${targetUser.tag}: ${e.message}`));

        const successEmbed = new EmbedBuilder().setColor('#AAAAAA').setTitle('🗑️ Status VIP Dihapus').setDescription(`**${targetUser.tag}** telah dihapus dari daftar VIP. Statusnya dikembalikan ke **Non-VIP** (batas standar).`).setFooter({ text: 'Konfigurasi disimpan.' });

            

        await interaction.reply({ embeds: [successEmbed] });

    

    } else if (commandName === 'listvip') {

        await interaction.deferReply({ ephemeral: true }); 

        if (!vipDisplayConfig.channelId) {

            return interaction.editReply({ content: '❌ Lokasi tampilan daftar VIP belum diatur. Silakan gunakan `/setvipdisplay` terlebih dahulu.', ephemeral: true });

        }

        // Panggil fungsi update

        await triggerVipListUpdate(); 

        const successEmbed = new EmbedBuilder()

            .setColor('#2ecc71')

            .setDescription(`✅ Daftar VIP berhasil di-update dan dapat dilihat di saluran <#${vipDisplayConfig.channelId}>.`);

        await interaction.editReply({ embeds: [successEmbed] });

    

    } else if (commandName === 'setvipdisplay') { // HANDLER COMMAND BARU

        const channel = interaction.options.getChannel('saluran');

        

        if (!channel || channel.type !== 0) {

            return interaction.reply({ content: '❌ Harap berikan saluran teks yang valid.', ephemeral: true });

        }

        

        await interaction.deferReply();

        

        // 1. Kirim pesan baru

        const initialEmbed = new EmbedBuilder()

            .setTitle('Membuat Daftar VIP...')

            .setDescription('Daftar ini akan diisi dan diperbarui secara otomatis saat status VIP pengguna berubah.')

            .setColor('#3498db');

            

        const newMessage = await channel.send({ embeds: [initialEmbed] });

        // 2. Simpan konfigurasi

        vipDisplayConfig.channelId = channel.id;

        vipDisplayConfig.messageId = newMessage.id;

        saveVipDisplayConfig();

        // 3. Update konten segera

        await triggerVipListUpdate(); 

        

        const successReplyEmbed = new EmbedBuilder()

            .setColor('#00FF00')

            .setDescription(`✅ Daftar VIP sekarang diatur untuk auto-update di ${channel}. Pesan di atas akan otomatis diperbarui.`);

        await interaction.editReply({ embeds: [successReplyEmbed] });

    }

});

bot.login(TOKEN);